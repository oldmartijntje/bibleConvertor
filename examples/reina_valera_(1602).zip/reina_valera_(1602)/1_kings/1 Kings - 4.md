---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_kings"
  - "#bible/testament/old"
aliases:
  - "1 Kings - 4 - Reina Valera (1602)"
---
[[1 Kings - 3|<--]] 1 Kings - 4 [[1 Kings - 5|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Kings]]

# 1 Kings - 4

FUÉ pues el rey Salomón rey sobre todo Israel. [^1] Y estos fueron los príncipes que tuvo: Azarías hijo de Sadoc, sacerdote; [^2] Elioreph y Ahía, hijos de Sisa, escribas; Josaphat hijo de Ahilud, canciller; [^3] Benaía hijo de Joiada era sobre el ejército; y Sadoc y Abiathar eran los sacerdotes; [^4] Azaría hijo de Nathán era sobre los gobernadores; Zabud hijo de Nathán era principal oficial, amigo del rey; [^5] Y Ahisar era mayordomo; y Adoniram hijo de Abda era sobre el tributo. [^6] Y tenía Salomón doce gobernadores sobre todo Israel, los cuales mantenían al rey y á su casa. Cada uno de ellos estaba obligado á abastecer por un mes en el año. [^7] Y estos son los nombres de ellos: el hijo de Hur en el monte de Ephraim; [^8] El hijo de Decar, en Maccas, y en Saalbim, y en Beth-semes, y en Elón, y en Beth-hanan; [^9] El hijo de Hesed, en Aruboth; éste tenía también á Sochô y toda la tierra de Ephet. [^10] El hijo de Abinadab, en todos los términos de Dor: éste tenía por mujer á Thaphat hija de Salomón; [^11] Baana hijo de Ahilud, en Taanach y Megiddo, y en toda Beth-san, que es cerca de Zaretán, por bajo de Jezreel, desde Beth-san hasta Abel-mehola, y hasta la otra parte de Jocmeam; [^12] El hijo de Geber, en Ramoth de Galaad; éste tenía también las ciudades de Jair hijo de Manasés, las cuales estaban en Galaad; tenía también la provincia de Argob, que era en Basán, sesenta grandes ciudades con muro y cerraduras de bronce; [^13] Ahinadab hijo de Iddo, en Mahanaim; [^14] Ahimaas en Nephtalí; éste tomó también por mujer á Basemath hija de Salomón. [^15] Baana hijo de Husai, en Aser y en Aloth; [^16] Josaphat hijo de Pharua, en Issachâr; [^17] Semei hijo de Ela, en Benjamín; [^18] Geber hijo de Uri, en la tierra de Galaad, la tierra de Sehón rey de los Amorrheos, y de Og rey de Basán; éste era el único gobernador en aquella tierra. [^19] Judá é Israel eran muchos, como la arena que está junto á la mar en multitud, comiendo y bebiendo y alegrándose. [^20] Y Salomón señoreaba sobre todos los reinos, desde el río de la tierra de los Filisteos hasta el término de Egipto: y traían presentes, y sirvieron á Salomón todos los días que vivió. [^21] Y la despensa de Salomón era cada día treinta coros de flor de harina, y sesenta coros de harina. [^22] Diez bueyes engordados, y veinte bueyes de pasto, y cien ovejas; sin los ciervos, cabras, búfalos, y aves engordadas. [^23] Porque él señoreaba en toda la región que estaba de la otra parte del río, desde Tiphsa hasta Gaza, sobre todos los reyes de la otra parte del río; y tuvo paz por todos lados en derredor suyo. [^24] Y Judá é Israel vivían seguros, cada uno debajo de su parra y debajo de su higuera, desde Dan hasta Beer-seba, todos los días de Salomón. [^25] Tenía además de esto Salomón cuarenta mil caballos en sus caballerizas para sus carros, y doce mil jinetes. [^26] Y estos gobernadores mantenían al rey Salomón, y á todos los que á la mesa del rey Salomón venían, cada uno un mes; y hacían que nada faltase. [^27] Hacían también traer cebada y paja para los caballos y para las bestias de carga, al lugar donde él estaba, cada uno conforme al cargo que tenía. [^28] Y dió Dios á Salomón sabiduría, y prudencia muy grande, y anchura de corazón como la arena que está á la orilla del mar. [^29] Que fué mayor la sabiduría de Salomón que la de todos los orientales, y que toda la sabiduría de los Egipcios. [^30] Y aun fué más sabio que todos los hombres; más que Ethán Ezrahita, y que Emán y Calchôl y Darda, hijos de Mahol: y fué nombrado entre todas las naciones de alrededor. [^31] Y propuso tres mil parábolas; y sus versos fueron mil y cinco. [^32] También disertó de los árboles, desde el cedro del Líbano hasta el hisopo que nace en la pared. Asimismo disertó de los animales, de las aves, de los reptiles, y de los peces. [^33] Y venían de todos los pueblos á oir la sabiduría de Salomón, y de todos los reyes de la tierra, donde había llegado la fama de su sabiduría. [^34] 

[[1 Kings - 3|<--]] 1 Kings - 4 [[1 Kings - 5|-->]]

---
# Notes
