---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_kings"
  - "#bible/testament/old"
aliases:
  - "1 Kings - 17 - Reina Valera (1602)"
---
[[1 Kings - 16|<--]] 1 Kings - 17 [[1 Kings - 18|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Kings]]

# 1 Kings - 17

ENTONCES Elías Thisbita, que era de los moradores de Galaad, dijo á Achâb: Vive Jehová Dios de Israel, delante del cual estoy, que no habrá lluvia ni rocío en estos años, sino por mi palabra. [^1] Y fué á él palabra de Jehová, diciendo: [^2] Apártate de aquí, y vuélvete al oriente, y escóndete en el arroyo de Cherith, que está delante del Jordán; [^3] Y beberás del arroyo; y yo he mandado á los cuervos que te den allí de comer. [^4] Y él fué, é hizo conforme á la palabra de Jehová; pues se fué y asentó junto al arroyo de Cherith, que está antes del Jordán. [^5] Y los cuervos le traían pan y carne por la mañana, y pan y carne á la tarde; y bebía del arroyo. [^6] Pasados algunos días, secóse el arroyo; porque no había llovido sobre la tierra. [^7] Y fué á él palabra de Jehová, diciendo: [^8] Levántate, vete á Sarepta de Sidón, y allí morarás: he aquí yo he mandado allí á una mujer viuda que te sustente. [^9] Entonces él se levantó, y se fué á Sarepta. Y como llegó á la puerta de la ciudad, he aquí una mujer viuda que estaba allí cogiendo serojas; y él la llamó, y díjole: Ruégote que me traigas una poca de agua en un vaso, para que beba. [^10] Y yendo ella para traérsela, él la volvió á llamar, y díjole: Ruégote que me traigas también un bocado de pan en tu mano. [^11] Y ella respondió: Vive Jehová Dios tuyo, que no tengo pan cocido; que solamente un puñado de harina tengo en la tinaja, y un poco de aceite en una botija: y ahora cogía dos serojas, para entrarme y aderezarlo para mí y para mi hijo, y que lo comamos, y nos muramos. [^12] Y Elías le dijo: No hayas temor; ve, haz como has dicho: empero hazme á mí primero de ello una pequeña torta cocida debajo de la ceniza, y tráemela; y después harás para ti y para tu hijo. [^13] Porque Jehová Dios de Israel ha dicho así: La tinaja de la harina no escaseará, ni se disminuirá la botija del aceite, hasta aquel día que Jehová dará lluvia sobre la haz de la tierra. [^14] Entonces ella fué, é hizo como le dijo Elías; y comió él, y ella y su casa, muchos días. [^15] Y la tinaja de la harina no escaseó, ni menguó la botija del aceite, conforme á la palabra de Jehová que había dicho por Elías. [^16] Después de estas cosas aconteció que cayó enfermo el hijo del ama de la casa, y la enfermedad fué tan grave, que no quedó en él resuello. [^17] Y ella dijo á Elías: ¿Qué tengo yo contigo, varón de Dios? ¿has venido á mí para traer en memoria mis iniquidades, y para hacerme morir mi hijo? [^18] Y él le dijo: Dame acá tu hijo. Entonces él lo tomó de su regazo, y llevólo á la cámara donde él estaba, y púsole sobre su cama; [^19] Y clamando á Jehová, dijo: Jehová Dios mío, ¿aun á la viuda en cuya casa yo estoy hospedado has afligido, matándole su hijo? [^20] Y midióse sobre el niño tres veces, y clamó á Jehová, y dijo: Jehová Dios mío, ruégote que vuelva el alma de este niño á sus entrañas. [^21] Y Jehová oyó la voz de Elías, y el alma del niño volvió á sus entrañas, y revivió. [^22] Tomando luego Elías al niño, trájolo de la cámara á la casa, y diólo á su madre, y díjole Elías: Mira, tu hijo vive. [^23] Entonces la mujer dijo á Elías: Ahora conozco que tú eres varón de Dios, y que la palabra de Jehová es verdad en tu boca. [^24] 

[[1 Kings - 16|<--]] 1 Kings - 17 [[1 Kings - 18|-->]]

---
# Notes
