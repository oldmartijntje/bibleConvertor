---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_kings"
  - "#bible/testament/old"
aliases:
  - "1 Kings - 5 - Reina Valera (1602)"
---
[[1 Kings - 4|<--]] 1 Kings - 5 [[1 Kings - 6|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Kings]]

# 1 Kings - 5

HIRAM rey de Tiro envió también sus siervos á Salomón, luego que oyó que lo habían ungido por rey en lugar de su padre: porque Hiram había siempre amado á David. [^1] Entonces Salomón envió á decir á Hiram: [^2] Tú sabes como mi padre David no pudo edificar casa al nombre de Jehová su Dios, por las guerras que le cercaron, hasta que Jehová puso sus enemigos bajo las plantas de sus pies. [^3] Ahora Jehová mi Dios me ha dado reposo por todas partes; que ni hay adversarios, ni mal encuentro. [^4] Yo por tanto he determinado ahora edificar casa al nombre de Jehová mi Dios, como Jehová lo habló á David mi padre, diciendo: Tu hijo, que yo pondré en lugar tuyo en tu trono, él edificará casa á mi nombre. [^5] Manda pues ahora que me corten cedros del Líbano; y mis siervos estarán con los tuyos, y yo te daré por tus siervos el salario que tú dijeres: porque tú sabes bien que ninguno hay entre nosotros que sepa labrar la madera como los Sidonios. [^6] Y como Hiram oyó las palabras de Salomón, holgóse en gran manera, y dijo: Bendito sea hoy Jehová, que dió hijo sabio á David sobre este pueblo tan grande. [^7] Y envió Hiram á decir á Salomón: He oído lo que me mandaste á decir: yo haré todo lo que te pluguiere acerca de la madera de cedro, y la madera de haya. [^8] Mis siervos la llevarán desde el Líbano á la mar; y yo la pondré en balsas por la mar hasta el lugar que tú me señalares, y allí se desatará, y tú la tomarás: y tú harás mi voluntad en dar de comer á mi familia. [^9] Dió pues Hiram á Salomón madera de cedro y madera de haya todo lo que quiso. [^10] Y Salomón daba á Hiram veinte mil coros de trigo para el sustento de su familia, y veinte coros de aceite limpio: esto daba Salomón á Hiram cada un año. [^11] Dió pues Jehová á Salomón sabiduría como le había dicho: y hubo paz entre Hiram y Salomón, é hicieron alianza entre ambos. [^12] Y el rey Salomón impuso tributo á todo Israel, y el tributo fué de treinta mil hombres: [^13] Los cuales enviaba al Líbano de diez mil en diez mil, cada mes por su turno, viniendo así á estar un mes en el Líbano, y dos meses en sus casas: y Adoniram estaba sobre aquel tributo. [^14] Tenía también Salomón setenta mil que llevaban las cargas, y ochenta mil cortadores en el monte; [^15] Sin los principales oficiales de Salomón que estaban sobre la obra, tres mil y trescientos, los cuales tenían cargo del pueblo que hacía la obra. [^16] Y mandó el rey que trajesen grandes piedras, piedras de precio, para los cimientos de la casa, y piedras labradas. [^17] Y los albañiles de Salomón y los de Hiram, y los aparejadores, cortaron y aparejaron la madera y la cantería para labrar la casa. [^18] 

[[1 Kings - 4|<--]] 1 Kings - 5 [[1 Kings - 6|-->]]

---
# Notes
