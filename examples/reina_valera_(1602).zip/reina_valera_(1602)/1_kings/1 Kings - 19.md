---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_kings"
  - "#bible/testament/old"
aliases:
  - "1 Kings - 19 - Reina Valera (1602)"
---
[[1 Kings - 18|<--]] 1 Kings - 19 [[1 Kings - 20|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Kings]]

# 1 Kings - 19

Y Achâb dió la nueva á Jezabel de todo lo que Elías había hecho, de como había muerto á cuchillo á todos los profetas. [^1] Entonces envió Jezabel á Elías un mensajero, diciendo: Así me hagan los dioses, y así me añadan, si mañana á estas horas yo no haya puesto tu persona como la de uno de ellos. [^2] Viendo pues el peligro, levantóse y fuése por salvar su vida, y vino á Beer-seba, que es en Judá, y dejó allí su criado. [^3] Y él se fué por el desierto un día de camino, y vino y sentóse debajo de un enebro; y deseando morirse, dijo: Baste ya, oh Jehová, quita mi alma; que no soy yo mejor que mis padres. [^4] Y echándose debajo del enebro, quedóse dormido: y he aquí luego un ángel que le tocó, y le dijo: Levántate, come. [^5] Entonces él miró, y he aquí á su cabecera una torta cocida sobre las ascuas, y un vaso de agua: y comió y bebió y volvióse á dormir. [^6] Y volviendo el ángel de Jehová la segunda vez, tocóle, diciendo: Levántate, come: porque gran camino te resta. [^7] Levantóse pues, y comió y bebió; y caminó con la fortaleza de aquella comida cuarenta días y cuarenta noches, hasta el monte de Dios, Horeb. [^8] Y allí se metió en una cueva, donde tuvo la noche. Y fué á él palabra de Jehová, el cual le dijo: ¿Qué haces aquí, Elías? [^9] Y él respondió: Sentido he un vivo celo por Jehová Dios de los ejércitos; porque los hijos de Israel han dejado tu alianza, han derribado tus altares, y han muerto á cuchillo tus profetas: y yo solo he quedado, y me buscan para quitarme la vida. [^10] Y él le dijo: Sal fuera, y ponte en el monte delante de Jehová. Y he aquí Jehová que pasaba, y un grande y poderoso viento que rompía los montes, y quebraba las peñas delante de Jehová: mas Jehová no estaba en el viento. Y tras el viento un terremoto: mas Jehová no estaba en el terremoto. [^11] Y tras el terremoto un fuego: mas Jehová no estaba en el fuego. Y tras el fuego un silvo apacible y delicado. [^12] Y cuando lo oyó Elías, cubrió su rostro con su manto, y salió, y paróse á la puerta de la cueva. Y he aquí llegó una voz á él, diciendo: ¿Qué haces aquí, Elías? [^13] Y él respondió: Sentido he un vivo celo por Jehová Dios de los ejércitos; porque los hijos de Israel han dejado tu alianza, han derribado tus altares, y han muerto á cuchillo tus profetas: y yo solo he quedado, y me buscan para quitarme la vida. [^14] Y díjole Jehová: Ve, vuélvete por tu camino, por el desierto de Damasco: y llegarás, y ungirás á Hazael por rey de Siria; [^15] Y á Jehú hijo de Nimsi, ungirás por rey sobre Israel; y á Eliseo hijo de Saphat, de Abel-mehula, ungirás para que sea profeta en lugar de ti. [^16] Y será, que el que escapare del cuchillo, de Hazael, Jehú lo matará; y el que escapare del cuchillo de Jehú, Eliseo lo matará. [^17] Y yo haré que queden en Israel siete mil; todas rodillas que no se encorvaron á Baal, y bocas todas que no lo besaron. [^18] Y partiéndose él de allí, halló á Eliseo hijo de Saphat, que araba con doce yuntas delante de sí; y él era uno de los doce gañanes. Y pasando Elías por delante de él, echó sobre él su manto. [^19] Entonces dejando él los bueyes, vino corriendo en pos de Elías, y dijo: Ruégote que me dejes besar mi padre y mi madre, y luego te seguiré. Y él le dijo: Ve, vuelve: ¿qué te he hecho yo? [^20] Y volvióse de en pos de él, y tomó un par de bueyes, y matólos, y con el arado de los bueyes coció la carne de ellos, y dióla al pueblo que comiesen. Después se levantó, y fué tras Elías, y servíale. [^21] 

[[1 Kings - 18|<--]] 1 Kings - 19 [[1 Kings - 20|-->]]

---
# Notes
