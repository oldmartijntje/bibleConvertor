---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 21 - Reina Valera (1602)"
---
[[2 Kings - 20|<--]] 2 Kings - 21 [[2 Kings - 22|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Kings]]

# 2 Kings - 21

DE doce años era Manasés cuando comenzó á reinar, y reinó en Jerusalem cincuenta y cinco años: el nombre de su madre fué Hepsiba. [^1] E hizo lo malo en ojos de Jehová, según las abominaciones de las gentes que Jehová había echado delante de los hijos de Israel. [^2] Porque él volvió á edificar los altos que Ezechîas su padre había derribado, y levantó altares á Baal, é hizo bosque, como había hecho Achâb rey de Israel: y adoró á todo el ejército del cielo, y sirvió á aquellas cosas. [^3] Asimismo edificó altares en la casa de Jehová, de la cual Jehová había dicho: Yo pondré mi nombre en Jerusalem. [^4] Y edificó altares para todo el ejército del cielo en los dos atrios de la casa de Jehová. [^5] Y pasó á su hijo por fuego, y miró en tiempos, y fué agorero, é instituyó pythones y adivinos, multiplicando así el hacer lo malo en ojos de Jehová, para provocarlo á ira. [^6] Y puso una entalladura del bosque que él había hecho, en la casa de la cual había Jehová dicho á David y á Salomón su hijo: Yo pondré mi nombre para siempre en esta casa, y en Jerusalem, á la cual escogí de todas las tribus de Israel: [^7] Y no volveré á hacer que el pie de Israel sea movido de la tierra que dí á sus padres, con tal que guarden y hagan conforme á todas las cosas que yo les he mandado, y conforme á toda la ley que mi siervo Moisés les mandó. [^8] Mas ellos no escucharon; y Manasés los indujo á que hiciesen más mal que las gentes que Jehová destruyó delante de los hijos de Israel. [^9] Y habló Jehová por mano de sus siervos los profetas, diciendo: [^10] Por cuanto Manasés rey de Judá ha hecho estas abominaciones, y ha hecho más mal que todo lo que hicieron los Amorrheos que fueron antes de él, y también ha hecho pecar á Judá en sus ídolos; [^11] Por tanto, así ha dicho Jehová el Dios de Israel: He aquí yo traigo tal mal sobre Jerusalem y sobre Judá, que el que lo oyere, le retiñirán ambos oídos. [^12] Y extenderé sobre Jerusalem el cordel de Samaria, y el plomo de la casa de Achâb: y yo limpiaré á Jerusalem como se limpia una escudilla, que después que la han limpiado, la vuelven sobre su haz. [^13] Y desampararé las reliquias de mi heredad, y entregarlas he en manos de sus enemigos; y serán para saco y para robo á todos sus adversarios; [^14] Por cuanto han hecho lo malo en mis ojos, y me han provocado á ira, desde el día que sus padres salieron de Egipto hasta hoy. [^15] Fuera de esto, derramó Manasés mucha sangre inocente en gran manera, hasta henchir á Jerusalem de cabo á cabo: además de su pecado con que hizo pecar á Judá, para que hiciese lo malo en ojos de Jehová. [^16] Lo demás de los hechos de Manasés, y todas las cosas que hizo, y su pecado que cometió, ¿no está todo escrito en el libro de las crónicas de los reyes de Judá? [^17] Y durmió Manasés con sus padres, y fué sepultado en el huerto de su casa, en el huerto de Uzza; y reinó en su lugar Amón su hijo. [^18] De veinte y dos años era Amón cuando comenzó á reinar, y reinó dos años en Jerusalem. El nombre de su madre fué Mesalemeth hija de Harus de Jotba. [^19] E hizo lo malo en ojos de Jehová, como había hecho Manasés su padre. [^20] Y anduvo en todos los caminos en que su padre anduvo, y sirvió á las inmundicias á las cuales había servido su padre, y á ellas adoró; [^21] Y dejó á Jehová el Dios de sus padres, y no anduvo en el camino de Jehová. [^22] Y los siervos de Amón conspiraron contra él, y mataron al rey en su casa. [^23] Entonces el pueblo de la tierra hirió á todos los que habían conspirado contra el rey Amón; y puso el pueblo de la tierra por rey en su lugar á Josías su hijo. [^24] Lo demás de los hechos de Amón, que efectuara, ¿no está todo escrito en el libro de las crónicas de los reyes de Judá? [^25] Y fué sepultado en su sepulcro en el huerto de Uzza, y reinó en su lugar Josías su hijo. [^26] 

[[2 Kings - 20|<--]] 2 Kings - 21 [[2 Kings - 22|-->]]

---
# Notes
