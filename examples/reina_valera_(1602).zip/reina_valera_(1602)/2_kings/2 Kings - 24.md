---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 24 - Reina Valera (1602)"
---
[[2 Kings - 23|<--]] 2 Kings - 24 [[2 Kings - 25|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Kings]]

# 2 Kings - 24

EN su tiempo subió Nabucodonosor rey de Babilonia, al cual sirvió Joacim tres años; volvióse luego, y se rebeló contra él. [^1] Jehová empero envió contra él tropas de Caldeos, y tropas de Siros, y tropas de Moabitas, y tropas de Ammonitas; los cuales envió contra Judá para que la destruyesen, conforme á la palabra de Jehová que había hablado por sus siervos los profetas. [^2] Ciertamente vino esto contra Judá por dicho de Jehová, para quitarla de su presencia, por los pecados de Manasés, conforme á todo lo que hizo; [^3] Asimismo por la sangre inocente que derramó, pues hinchió á Jerusalem de sangre inocente: Jehová por tanto, no quiso perdonar. [^4] Lo demás de los hechos de Joacim, y todas las cosas que hizo, ¿no está escrito en el libro de las crónicas de los reyes de Judá? [^5] Y durmió Joacim con sus padres, y reinó en su lugar Joachîn su hijo. [^6] Y nunca más el rey de Egipto salió de su tierra: porque el rey de Babilonia le tomó todo lo que era suyo, desde el río de Egipto hasta el río de Eufrates. [^7] De dieciocho años era Joachîn cuando comenzó á reinar, y reinó en Jerusalem tres meses. El nombre de su madre fué Neusta hija de Elnathán, de Jerusalem. [^8] E hizo lo malo en ojos de Jehová, conforme á todas las cosas que había hecho su padre. [^9] En aquel tiempo subieron los siervos de Nabucodonosor rey de Babilonia contra Jerusalem y la ciudad fué cercada. [^10] Vino también Nabucodonosor rey de Babilonia contra la ciudad, cuando sus siervos la tenían cercada. [^11] Entonces salió Joachîn rey de Judá al rey de Babilonia, él, y su madre, y sus siervos, y sus príncipes, y sus eunucos: y prendiólo el rey de Babilonia en el octavo año de su reinado. [^12] Y sacó de allí todos los tesoros de la casa de Jehová, y los tesoros de la casa real, y quebró en piezas todos los vasos de oro que había hecho Salomón rey de Israel en la casa de Jehová, como Jehová había dicho. [^13] Y llevó en cautiverio á toda Jerusalem, á todos los príncipes, y á todos los hombres valientes, hasta diez mil cautivos, y á todos los oficiales y herreros; que no quedó nadie, excepto los pobres del pueblo de la tierra. [^14] Asimismo trasportó á Joachîn á Babilonia, y á la madre del rey, y á las mujeres del rey, y á sus eunucos, y á los poderosos de la tierra; cautivos los llevó de Jerusalem á Babilonia. [^15] A todos los hombre de guerra, que fueron siete mil, y á los oficiales y herrreros, que fueron mil, y á todos los valientes para hacer la guerra, llevó cautivos el rey de Babilonia. [^16] Y el rey de Babilonia puso por rey en lugar de Joachîn á Mathanías su tío, y mudóle el nombre en el de Sedecías. [^17] De veintiún años era Sedecías cuando comenzó á reinar, y reinó en Jerusalem once años. El nombre de su madre fué Amutal hija de Jeremías, de Libna. [^18] E hizo lo malo en ojos de Jehová, conforme á todo lo que había hecho Joacim. [^19] Fué pues la ira de Jehová contra Jerusalem y Judá, hasta que los echó de su presencia. Y Sedecías se rebeló contra el rey de Babilonia. [^20] 

[[2 Kings - 23|<--]] 2 Kings - 24 [[2 Kings - 25|-->]]

---
# Notes
