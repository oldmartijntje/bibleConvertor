---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 16 - Reina Valera (1602)"
---
[[2 Kings - 15|<--]] 2 Kings - 16 [[2 Kings - 17|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Kings]]

# 2 Kings - 16

EN el año diecisiete de Peka hijo de Remalías, comenzó á reinar Achâz hijo de Jotham rey de Judá. [^1] Cuando comenzó á reinar Achâz, era de veinte años, y reinó en Jerusalem dieciséis años: y no hizo lo recto en ojos de Jehová su Dios, como David su padre; [^2] Antes anduvo en el camino de los reyes de Israel, y aun hizo pasar por el fuego á su hijo, según las abominaciones de las gentes que Jehová echó de delante de los hijos de Israel. [^3] Asimismo sacrificó, y quemó perfumes en los altos, y sobre los collados, y debajo de todo árbol umbroso. [^4] Entonces Resín rey de Siria, y Peka hijo de Remalías rey de Israel, subieron á Jerusalem para hacer guerra, y cercar á Achâz; mas no pudieron tomarla. [^5] En aquel tiempo Resín rey de Siria restituyó Elath á Siria, y echó á los Judíos de Elath; y los Siros vinieron á Elath, y habitaron allí hasta hoy. [^6] Entonces Achâz envió embajadores á Tiglath-pileser rey de Asiria, diciendo: Yo soy tu siervo y tu hijo: sube, y defiéndeme de mano del rey de Siria, y de mano del rey de Israel, que se han levantado contra mí. [^7] Y tomando Achâz la plata y el oro que se halló en la casa de Jehová, y en los tesoros de la casa real, envió al rey de Asiria un presente. [^8] Y atendióle el rey de Asiria; pues subió el rey de Asiria contra Damasco, y tomóla, y trasportó los moradores á Kir, y mató á Resín. [^9] Y fué el rey Achâz á encontrar á Tiglath-pileser rey de Asiria en Damasco; y visto que hubo el rey Achâz el altar que estaba en Damasco, envió á Urías sacerdote el diseño y la descripción del altar, conforme á toda su hechura. [^10] Y Urías el sacerdote edificó el altar; conforme á todo lo que el rey Achâz había enviado de Damasco, así lo hizo el sacerdote Urías, entre tanto que el rey Achâz venía de Damasco. [^11] Y luego que vino el rey de Damasco, y hubo visto el altar, acercóse el rey á él, y sacrificó en él; [^12] Y encendió su holocausto, y su presente, y derramó sus libaciones, y esparció la sangre de sus pacíficos junto al altar. [^13] Y el altar de bronce que estaba delante de Jehová, hízolo acercar delante de la frontera de la casa, entre el altar y el templo de Jehová, y púsolo al lado del altar hacia el aquilón. [^14] Y mandó el rey Achâz al sacerdote Urías, diciendo: En el gran altar encenderás el holocausto de la mañana y el presente de la tarde, y el holocausto del rey y su presente, y asimismo el holocausto de todo el pueblo de la tierra y su presente y sus libaciones: y esparcirás sobre él toda la sangre de holocausto, y toda la sangre de sacrificio: y el altar de bronce será mío para preguntar en él. [^15] E hizo el sacerdote Urías conforme á todas las cosas que el rey Achâz le mandó. [^16] Y cortó el rey Achâz las cintas de las basas, y quitóles las fuentes; quitó también el mar de sobre los bueyes de bronce que estaban debajo de él, y púsolo sobre el solado de piedra. [^17] Asimismo la tienda del sábado que habían edificado en la casa, y el pasadizo de afuera del rey, mudólos del templo de Jehová, por causa del rey de Asiria. [^18] Lo demás de los hechos de Achâz que puso por obra, ¿no está todo escrito en el libro de las crónicas de los reyes de Judá? [^19] Y durmió el rey Achâz con sus padres y fué sepultado con sus padres en la ciudad de David: y reinó en su lugar Ezechîas su hijo. [^20] 

[[2 Kings - 15|<--]] 2 Kings - 16 [[2 Kings - 17|-->]]

---
# Notes
