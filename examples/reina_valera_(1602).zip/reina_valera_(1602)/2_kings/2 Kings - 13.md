---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 13 - Reina Valera (1602)"
---
[[2 Kings - 12|<--]] 2 Kings - 13 [[2 Kings - 14|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Kings]]

# 2 Kings - 13

EN el año veintitrés de Joas hijo de Ochôzías, rey de Judá, comenzó á reinar Joachâz hijo de Jehú sobre Israel en Samaria; y reinó diecisiete años. [^1] E hizo lo malo en ojos de Jehová, y siguió los pecados de Jeroboam hijo de Nabat, el que hizo pecar á Israel; y no se apartó de ellos. [^2] Y encendióse el furor de Jehová contra Israel, y entrególos en mano de Hazael rey de Siria, y en mano de Ben-adad hijo de Hazael, por largo tiempo. [^3] Mas Joachâz oró á la faz de Jehová, y Jehová lo oyó: porque miró la aflicción de Israel, pues el rey de Siria los afligía. [^4] (Y dió Jehová salvador á Israel, y salieron de bajo la mano de los Siros; y habitaron los hijos de Israel en sus estancias, como antes. [^5] Con todo eso no se apartaron de los pecados de la casa de Jeroboam, el que hizo pecar á Israel: en ellos anduvieron; y también el bosque permaneció en Samaria.) [^6] Porque no le había quedado gente á Joachâz, sino cincuenta hombres de á caballo, y diez carros, y diez mil hombres de á pié; pues el rey de Siria los había destruído, y los había puesto como polvo para hollar. [^7] Lo demás de los hechos de Joachâz, y todo lo que hizo, y sus valentías, ¿no está escrito en el libro de las crónicas de los reyes de Israel? [^8] Y durmió Joachâz con sus padres, y sepultáronlo en Samaria: y reinó en su lugar Joas su hijo. [^9] El año treinta y siete de Joas rey de Judá, comenzó á reinar Joas hijo de Joachâz sobre Israel en Samaria; y reinó dieciséis años. [^10] E hizo lo malo en ojos de Jehová: no se apartó de todos los pecados de Jeroboam hijo de Nabat, el que hizo pecar á Israel; en ellos anduvo. [^11] Lo demás de los hechos de Joas, y todas las cosas que hizo, y su esfuerzo con que guerreó contra Amasías rey de Judá, ¿no está escrito en el libro de las crónicas de los reyes de Israel? [^12] Y durmió Joas con sus padres, y sentóse Jeroboam sobre su trono: y Joas fué sepultado en Samaria con los reyes de Israel. [^13] Estaba Eliseo enfermo de aquella su enfermedad de que murió. Y descendió á él Joas rey de Israel, y llorando delante de él, dijo: ­Padre mío, padre mío, carro de Israel y su gente de á caballo! [^14] Y díjole Eliseo: Toma un arco y unas saetas. Tomóse él entonces un arco y unas saetas. [^15] Y dijo Eliseo al rey de Israel: Pon tu mano sobre el arco. Y puso él su mano sobre el arco. Entonces puso Eliseo sus manos sobre las manos del rey, [^16] Y dijo: Abre la ventana de hacia el oriente. Y como él la abrió dijo Eliseo: Tira. Y tirando él, dijo Eliseo: Saeta de salud de Jehová, y saeta de salud contra Siria: porque herirás á los Siros en Aphec, hasta consumirlos. [^17] Y tornóle á decir: Toma las saetas. Y luego que el rey de Israel las hubo tomado, díjole: Hiere la tierra. Y él hirió tres veces, y cesó. [^18] Entonces el varón de Dios, enojado con él, le dijo: A herir cinco ó seis veces, herirías á Siria, hasta no quedar ninguno: empero ahora tres veces herirás á Siria. [^19] Y murió Eliseo, y sepultáronlo. Entrado el año vinieron partidas de Moabitas á la tierra. [^20] Y aconteció que al sepultar unos un hombre, súbitamente vieron una partida, y arrojaron al hombre en el sepulcro de Eliseo: y cuando llegó á tocar el muerto los huesos de Eliseo, revivió, y levantóse sobre sus pies. [^21] Hazael pues, rey de Siria, afligió á Israel todo el tiempo de Joachâz. [^22] Mas Jehová tuvo misericordia de ellos, y compadecióse de ellos, y mirólos, por amor de su pacto con Abraham, Isaac y Jacob; y no quiso destruirlos ni echarlos de delante de sí hasta ahora. [^23] Y murió Hazael rey de Siria, y reinó en su lugar Ben-adad su hijo. [^24] Y volvió Joas hijo de Joachâz, y tomó de mano de Ben-adad hijo de Hazael, las ciudades que él había tomado de mano de Joachâz su padre en guerra. Tres veces lo batió Joas, y restituyó las ciudades á Israel. [^25] 

[[2 Kings - 12|<--]] 2 Kings - 13 [[2 Kings - 14|-->]]

---
# Notes
