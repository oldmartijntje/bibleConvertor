---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 11 - Reina Valera (1602)"
---
[[2 Kings - 10|<--]] 2 Kings - 11 [[2 Kings - 12|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Kings]]

# 2 Kings - 11

Y ATHALIA madre de Ochôzías, viendo que su hijo era muerto, levantóse, y destruyó toda la simiente real. [^1] Pero tomando Josaba hija del rey Joram, hermana de Ochôzías, á Joas hijo de Ochôzías, sacólo furtivamente de entre los hijos del rey, que se mataban, y ocultólo de delante de Athalía, á él y á su ama, en la cámara de las camas, y así no lo mataron. [^2] Y estuvo con ella escondido en la casa de Jehová seis años: y Athalía fué reina sobre el país. [^3] Mas al séptimo año envió Joiada, y tomó centuriones, capitanes, y gente de la guardia, y metiólos consigo en la casa de Jehová: é hizo con ellos liga, juramentándolos en la casa de Jehová; y mostróles al hijo del rey. [^4] Y mandóles, diciendo: Esto es lo que habéis de hacer: la tercera parte de vosotros, los que entrarán el sábado, tendrán la guardia de la casa del rey; [^5] Y la otra tercera parte estará á la puerta del sur, y la otra tercera parte á la puerta del postigo de los de la guardia: así guardaréis la casa, para que no sea allanada. [^6] Y las dos partes de vosotros, es á saber, todos los que salen el sábado, tendréis la guarda de la casa de Jehová junto al rey. [^7] Y estaréis alrededor del rey de todas partes, teniendo cada uno sus armas en las manos, y cualquiera que entrare dentro de estos órdenes, sea muerto. Y habéis de estar con el rey cuando saliere, y cuando entrare. [^8] Los centuriones pues, hicieron todo como el sacerdote Joiada les mandó: y tomando cada uno los suyos, es á saber, los que habían de entrar el sábado, y los que habían salido el sábado, viniéronse á Joiada el sacerdote. [^9] Y el sacerdote dió á los centuriones las picas y los escudos que habían sido del rey David, que estaban en la casa de Jehová. [^10] Y los de la guardia se pusieron en orden, teniendo cada uno sus armas en sus manos, desde el lado derecho de la casa hasta el lado izquierdo, junto al altar y el templo, en derredor del rey. [^11] Sacando luego Joiada al hijo del rey, púsole la corona y el testimonio, é hiciéronle rey ungiéndole; y batiendo las manos dijeron: ­Viva el rey! [^12] Y oyendo Athalía el estruendo del pueblo que corría, entró al pueblo en el templo de Jehová; [^13] Y como miró, he aquí el rey que estaba junto á la columna, conforme á la costumbre, y los príncipes y los trompetas junto al rey; y que todo el pueblo del país hacía alegrías, y que tocaban las trompetas. Entonces Athalía, rasgando sus vestidos, clamó á voz en grito: ­Traición, traición! [^14] Mas el sacerdote Joiada mandó á los centuriones que gobernaban el ejército, y díjoles: Sacadla fuera del recinto del templo, y al que la siguiere, matadlo á cuchillo. (Porque el sacerdote dijo que no la matasen en el templo de Jehová.) [^15] Diéronle pues lugar, y como iba el camino por donde entran los de á caballo á la casa del rey, allí la mataron. [^16] Entonces Joiada hizo alianza entre Jehová y el rey y el pueblo, que serían pueblo de Jehová: y asimismo entre el rey y el pueblo. [^17] Y todo el pueblo de la tierra entró en el templo de Baal, y derribáronlo: asimismo despedazaron enteramente sus altares y sus imágenes, y mataron á Mathán sacerdote de Baal delante de los altares. Y el sacerdote puso guarnición sobre la casa de Jehová. [^18] Después tomó los centuriones, y capitanes, y los de la guardia, y á todo el pueblo de la tierra, y llevaron al rey desde la casa de Jehová, y vinieron por el camino de la puerta de los de la guardia á la casa del rey; y sentóse el rey sobre el trono de los reyes. [^19] Y todo el pueblo de la tierra hizo alegrías, y la ciudad estuvo en reposo, habiendo sido Athalía muerta á cuchillo junto á la casa del rey. [^20] Era Joas de siete años cuando comenzó á reinar. [^21] 

[[2 Kings - 10|<--]] 2 Kings - 11 [[2 Kings - 12|-->]]

---
# Notes
