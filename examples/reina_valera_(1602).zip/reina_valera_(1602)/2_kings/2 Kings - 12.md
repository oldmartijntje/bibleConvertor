---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 12 - Reina Valera (1602)"
---
[[2 Kings - 11|<--]] 2 Kings - 12 [[2 Kings - 13|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Kings]]

# 2 Kings - 12

EN el séptimo año de Jehú comenzó á reinar Joas, y reinó cuarenta años en Jerusalem. El nombre de su madre fué Sibia, de Beer-seba. [^1] Y Joas hizo lo recto en ojos de Jehová todo el tiempo que le dirigió el sacerdote Joiada. [^2] Con todo eso los altos no se quitaron; que aún sacrificaba y quemaba el pueblo perfumes en los altos. [^3] Y Joas dijo á los sacerdotes: Todo el dinero de las santificaciones que se suele traer á la casa de Jehová, el dinero de los que pasan en cuenta, el dinero por las personas, cada cual según su tasa, y todo el dinero que cada uno de su propia voluntad mete en la casa de Jehová, [^4] Recíbanlo los sacerdotes, cada uno de sus familiares, y reparen los portillos del templo donde quiera que se hallare abertura. [^5] Pero el año veintitrés del rey Joas, no habían aún reparado los sacerdotes las aberturas del templo. [^6] Llamando entonces el rey Joas al pontífice Joiada y á los sacerdotes, díjoles: ¿Por qué no reparáis las aberturas del templo? Ahora pues, no toméis más el dinero de vuestros familiares, sino dadlo para reparar las roturas del templo. [^7] Y los sacerdotes consintieron en no tomar más dinero del pueblo, ni tener cargo de reparar las aberturas del templo. [^8] Mas el pontífice Joiada tomó un arca, é hízole en la tapa un agujero, y púsola junto al altar, á la mano derecha como se entra en le templo de Jehová; y los sacerdotes que guardaban la puerta, ponían allí todo el dinero que se metía en la casa de Jehová. [^9] Y cuando veían que había mucho dinero en el arca, venía el notario del rey y el gran sacerdote, y contaban el dinero que hallaban en el templo de Jehová, y guardábanlo. [^10] Y daban el dinero suficiente en mano de los que hacían la obra, y de los que tenían el cargo de la casa de Jehová; y ellos lo expendían en pagar los carpinteros y maestros que reparaban la casa de Jehová, [^11] Y los albañiles y canteros; y en comprar la madera y piedra de cantería para reparar las aberturas de la casa de Jehová; y en todo lo que se gastaba en la casa para repararla. [^12] Mas de aquel dinero que se traía á la casa de Jehová, no se hacían tazas de plata, ni salterios, ni jofainas, ni trompetas; ni ningún otro vaso de oro ni de plata se hacía para el templo de Jehová: [^13] Porque lo daban á los que hacían la obra, y con él reparaban la casa de Jehová. [^14] Y no se tomaba en cuenta á los hombres en cuyas manos el dinero era entregado, para que ellos lo diesen á los que hacían la obra: porque lo hacían ellos fielmente. [^15] El dinero por el delito, y el dinero por los pecados, no se metía en la casa de Jehová; porque era de los sacerdotes. [^16] Entonces subió Hazael rey de Siria, y peleó contra Gath, y tomóla: y puso Hazael su rostro para subir contra Jerusalem; [^17] Por lo que tomó Joas rey de Judá todas las ofrendas que había dedicado Josaphat, y Joram y Ochôzías sus padres, reyes de Judá, y las que él había dedicado, y todo el oro que se halló en los tesoros de la casa de Jehová, y en la casa del rey, y enviólo á Hazael rey de Siria: y él se partió de Jerusalem. [^18] Lo demás de los hechos de Joas, y todas las cosas que hizo, ¿no está escrito en el libro de las crónicas de los reyes de Judá? [^19] Y levantáronse sus siervos, y conspiraron en conjuración, y mataron á Joas en la casa de Millo, descendiendo él á Silla; [^20] Pues Josachâr hijo de Simaath, y Jozabad hijo de Somer, sus siervos, hiriéronle, y murió. Y sepultáronle con sus padres en la ciudad de David, y reinó en su lugar Amasías su hijo. [^21] 

[[2 Kings - 11|<--]] 2 Kings - 12 [[2 Kings - 13|-->]]

---
# Notes
