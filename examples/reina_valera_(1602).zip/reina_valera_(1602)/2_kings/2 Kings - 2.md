---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 2 - Reina Valera (1602)"
---
[[2 Kings - 1|<--]] 2 Kings - 2 [[2 Kings - 3|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Kings]]

# 2 Kings - 2

Y ACONTECIO que, cuando quiso Jehová alzar á Elías en un torbellino al cielo, Elías venía con Eliseo de Gilgal. [^1] Y dijo Elías á Eliseo: Quédate ahora aquí, porque Jehová me ha enviado á Beth-el. Y Eliseo dijo: Vive Jehová, y vive tu alma, que no te dejaré. Descendieron pues á Beth-el. [^2] Y saliendo á Eliseo los hijos de los profetas que estaban en Beth-el, dijéronle: ¿Sabes cómo Jehová quitará hoy á tu señor de tu cabeza? Y él dijo: Sí, yo lo sé; callad. [^3] Y Elías le volvió á decir: Eliseo, quédate aquí ahora, porque Jehová me ha enviado á Jericó. Y él dijo: Vive Jehová, y vive tu alma, que no te dejaré. Vinieron pues á Jericó. [^4] Y llegáronse á Eliseo los hijos de los profetas que estaban en Jericó, y dijéronle: ¿Sabes cómo Jehová quitará hoy á tu señor de tu cabeza? Y él respondió: Sí, yo lo sé; callad. [^5] Y Elías le dijo: Ruégote que te quedes aquí, porque Jehová me ha enviado al Jordán. Y él dijo: Vive Jehová, y vive tu alma, que no te dejaré. Fueron pues ambos á dos. [^6] Y vinieron cincuenta varones de los hijos de los profetas, y paráronse enfrente á lo lejos: y ellos dos se pararon junto al Jordán. [^7] Tomando entonces Elías su manto, doblólo, é hirió las aguas, las cuales se apartaron á uno y á otro lado, y pasaron ambos en seco. [^8] Y como hubieron pasado, Elías dijo á Eliseo: Pide lo que quieres que haga por ti, antes que sea quitado de contigo. Y dijo Eliseo: Ruégote que las dos partes de tu espíritu sean sobre mí. [^9] Y él le dijo: Cosa difícil has pedido. Si me vieres cuando fuere quitado de ti, te será así hecho; mas si no, no. [^10] Y aconteció que, yendo ellos hablando, he aquí, un carro de fuego con caballos de fuego apartó á los dos: y Elías subió al cielo en un torbellino. [^11] Y viéndolo Eliseo, clamaba: ­Padre mío, padre mío, carro de Israel y su gente de á caballo! Y nunca más le vió, y trabando de sus vestidos, rompiólos en dos partes. [^12] Alzó luego el manto de Elías que se le había caído, y volvió, y paróse á la orilla del Jordán. [^13] Y tomando el manto de Elías que se le había caído, hirió las aguas, y dijo: ¿Dónde está Jehová, el Dios de Elías? Y así que hubo del mismo modo herido las aguas, apartáronse á uno y á otro lado, y pasó Eliseo. [^14] Y viéndole los hijos de los profetas que estaban en Jericó de la otra parte, dijeron: El espíritu de Elías reposó sobre Eliseo. Y viniéronle á recibir, é inclináronse á él hasta la tierra. [^15] Y dijéronle: He aquí hay con tus siervos cincuenta varones fuertes: vayan ahora y busquen á tu señor; quizá lo ha levantado el espíritu de Jehová, y lo ha echado en algún monte ó en algún valle. Y él les dijo: No enviéis. [^16] Mas ellos le importunaron, hasta que avergonzándose, dijo: Enviad. Entonces ellos enviaron cincuenta hombres, los cuales lo buscaron tres días, mas no lo hallaron. [^17] Y cuando volvieron á él, que se había quedado en Jericó, él les dijo: ¿No os dije yo que no fueseis? [^18] Y los hombres de la ciudad dijeron á Eliseo: He aquí el asiento de esta ciudad es bueno, como mi señor ve; mas las aguas son malas, y la tierra enferma. [^19] Entonces él dijo: Traedme una botija nueva, y poned en ella sal. Y trajéronsela. [^20] Y saliendo él á los manaderos de las aguas, echó dentro la sal, y dijo: Así ha dicho Jehová: Yo sané estas aguas, y no habrá más en ellas muerte ni enfermedad. [^21] Y fueron sanas las aguas hasta hoy, conforme á la palabra que habló Eliseo. [^22] Después subió de allí á Beth-el; y subiendo por el camino, salieron los muchachos de la ciudad, y se burlaban de él, diciendo: ­Calvo, sube! ­calvo, sube! [^23] Y mirando él atrás, viólos, y maldíjolos en el nombre de Jehová. Y salieron dos osos del monte, y despedazaron de ellos cuarenta y dos muchachos. [^24] De allí fué al monte de Carmelo, y de allí volvió á Samaria. [^25] 

[[2 Kings - 1|<--]] 2 Kings - 2 [[2 Kings - 3|-->]]

---
# Notes
