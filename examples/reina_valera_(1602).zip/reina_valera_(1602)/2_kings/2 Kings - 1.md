---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 1 - Reina Valera (1602)"
---
2 Kings - 1 [[2 Kings - 2|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Kings]]

# 2 Kings - 1

DESPUÉS de la muerte de Achâb rebelóse Moab contra Israel. [^1] Y Ochôzías cayó por las celosías de una sala de la casa que tenía en Samaria; y estando enfermo envió mensajeros, y díjoles: Id, y consultad á Baal-zebub dios de Ecrón, si tengo de sanar de esta mi enfermedad. [^2] Entonces el ángel de Jehová habló á Elías Thisbita, diciendo: Levántate, y sube á encontrarte con los mensajeros del rey de Samaria, y les dirás: ¿No hay Dios en Israel, que vosotros vais á consultar á Baal-zebub dios de Ecrón? [^3] Por tanto así ha dicho Jehová: Del lecho en que subiste no descenderás, antes morirás ciertamente. Y Elías se fué. [^4] Y como los mensajeros se volvieron al rey, él les dijo: ¿Por qué pues os habéis vuelto? [^5] Y ellos le respondieron: Encontramos un varón que nos dijo: Id, y volveos al rey que os envió, y decidle: Así ha dicho Jehová: ¿No hay Dios en Israel, que tú envías á consultar á Baal-zebub dios de Ecrón? Por tanto, del lecho en que subiste no descenderás, antes morirás de cierto. [^6] Entonces él les dijo: ¿Qué hábito era el de aquel varón que encontrasteis, y os dijo tales palabras? [^7] Y ellos le respondieron: Un varón velloso, y ceñía sus lomos con un cinto de cuero. Entonces él dijo: Elías Thisbita es. [^8] Y envió luego á él un capitán de cincuenta con sus cincuenta, el cual subió á él; y he aquí que él estaba sentado en la cumbre del monte. Y él le dijo: Varón de Dios, el rey ha dicho que desciendas. [^9] Y Elías respondió, y dijo al capitán de cincuenta: Si yo soy varón de Dios, descienda fuego del cielo, y consúmate con tus cincuenta. Y descendió fuego del cielo, que lo consumió á él y á sus cincuenta. [^10] Volvió el rey á enviar á él otro capitán de cincuenta con sus cincuenta; y hablóle, y dijo: Varon de Dios, el rey ha dicho así: Desciende presto. [^11] Y respondióle Elías, y dijo: Si yo soy varón de Dios, descienda fuego del cielo, y consúmate con tus cincuenta. Y descendió fuego del cielo, que lo consumió á él y á sus cincuenta. [^12] Y volvió á enviar el tercer capitán de cincuenta con sus cincuenta: y subiendo aquel tercer capitán de cincuenta, hincóse de rodillas delante de Elías, y rogóle, diciendo: Varón de Dios, ruégote que sea de valor delante de tus ojos mi vida y la vida de estos tus cincuenta siervos. [^13] He aquí ha descendido fuego del cielo, y ha consumido los dos primeros capitanes de cincuenta, con sus cincuenta; sea ahora mi vida de valor delante de tus ojos. [^14] Entonces el ángel de Jehová dijo á Elías: Desciende con él; no hayas de él miedo. Y él se levantó, y descendió con él al rey. [^15] Y díjole: Así ha dicho Jehová: Pues que enviaste mensajeros á consultar á Baal-zebub dios de Ecrón, ¿no hay Dios en Israel para consultar en su palabra? No descenderás, por tanto, del lecho en que subiste, antes morirás de cierto. [^16] Y murió conforme á la palabra de Jehová que había hablado Elías; y reinó en su lugar Joram, en el segundo año de Joram, hijo de Josaphat rey de Judá; porque Ochôzías no tenía hijo. [^17] Y lo demás de los hechos de Ochôzías, ¿no está escrito en el libro de las crónicas de los reyes de Israel? [^18] 

2 Kings - 1 [[2 Kings - 2|-->]]

---
# Notes
