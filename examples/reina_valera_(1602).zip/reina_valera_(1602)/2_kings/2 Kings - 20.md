---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 20 - Reina Valera (1602)"
---
[[2 Kings - 19|<--]] 2 Kings - 20 [[2 Kings - 21|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Kings]]

# 2 Kings - 20

EN aquellos días cayó Ezechîas enfermo de muerte, y vino á él Isaías profeta hijo de Amós, y díjole: Jehová dice así: Dispón de tu casa, porque has de morir, y no vivirás. [^1] Entonces volvió él su rostro á la pared, y oró á Jehová, y dijo: [^2] Ruégote, oh Jehová, ruégote hagas memoria de que he andado delante de ti en verdad é íntegro corazón, y que he hecho las cosas que te agradan. Y lloró Ezechîas con gran lloro. [^3] Y antes que Isaías saliese hasta la mitad del patio, fué palabra de Jehová á Isaías, diciendo: [^4] Vuelve, y di á Ezechîas, príncipe de mi pueblo: Así dice Jehová, el Dios de David tu padre: Yo he oído tu oración, y he visto tus lágrimas: he aquí yo te sano; al tercer día subirás á la casa de Jehová. [^5] Y añadiré á tus días quince años, y te libraré á ti y á esta ciudad de mano del rey de Asiria; y ampararé esta ciudad por amor de mí, y por amor de David mi siervo. [^6] Y dijo Isaías: Tomad masa de higos. Y tomándola, pusieron sobre la llaga, y sanó. [^7] Y Ezechîas había dicho á Isaías: ¿Qué señal tendré de que Jehová me sanará, y que subiré á la casa de Jehová al tercer día? [^8] Y respondió Isaías: Esta señal tendrás de Jehová, de que hará Jehová esto que ha dicho: ¿Avanzará la sombra diez grados, ó retrocederá diez grados? [^9] Y Ezechîas respondió: Fácil cosa es que la sombra decline diez grados: pero, que la sombra vuelva atrás diez grados. [^10] Entonces el profeta Isaías clamó á Jehová; é hizo volver la sombra por los grados que había descendido en el reloj de Achâz, diez grados atrás. [^11] En aquel tiempo Berodach-baladán hijo de Baladán, rey de Babilonia, envió letras y presentes á Ezechîas, porque había oído que Ezechîas había caído enfermo. [^12] Y Ezechîas los oyó, y mostróles toda la casa de las cosas preciosas, plata, oro, y especiería, y preciosos ungüentos; y la casa de sus armas, y todo lo que había en sus tesoros: ninguna cosa quedó que Ezechîas no les mostrase, así en su casa como en todo su señorío. [^13] Entonces el profeta Isaías vino al rey Ezechîas, y díjole: ¿Qué dijeron aquellos varones, y de dónde vinieron á ti? Y Ezechîas le respondió: De lejanas tierras han venido, de Babilonia. [^14] Y él le volvió á decir: ¿Qué vieron en tu casa? Y Ezechîas respondió: Vieron todo lo que había en mi casa; nada quedó en mis tesoros que no les mostrase. [^15] Entonces Isaías dijo á Ezechîas: Oye palabra de Jehová: [^16] He aquí vienen días, en que todo lo que está en tu casa, y todo lo que tus padres han atesorado hasta hoy, será llevado á Babilonia, sin quedar nada, dijo Jehová. [^17] Y de tus hijos que saldrán de ti, que habrás engendrado, tomarán; y serán eunucos en el palacio del rey de Babilonia. [^18] Entonces Ezechîas dijo á Isaías: La palabra de Jehová que has hablado, es buena. Después dijo: ¿Mas no habrá paz y verdad en mis días? [^19] Lo demás de los hechos de Ezechîas, y todo su vigor, y cómo hizo el estanque, y el conducto, y metió las aguas en la ciudad, ¿no está escrito en el libro de las crónicas de los reyes de Judá? [^20] Y durmió Ezechîas con sus padres, y reinó en su lugar Manasés su hijo. [^21] 

[[2 Kings - 19|<--]] 2 Kings - 20 [[2 Kings - 21|-->]]

---
# Notes
