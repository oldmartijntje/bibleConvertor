---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 22 - Reina Valera (1602)"
---
[[2 Kings - 21|<--]] 2 Kings - 22 [[2 Kings - 23|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Kings]]

# 2 Kings - 22

CUANDO Josías comenzó á reinar era de ocho años, y reinó en Jerusalem treinta y un años. El nombre de su madre fué Idida hija de Adaía de Boscath. [^1] E hizo lo recto en ojos de Jehová, y anduvo en todo el camino de David su padre, sin apartarse á diestra ni á siniestra. [^2] Y á los dieciocho años del rey Josías, fué que envió el rey á Saphán hijo de Azalía, hijo de Mesullam, escriba, á la casa de Jehová, diciendo: [^3] Ve á Hilcías, sumo sacerdote: dile que recoja el dinero que se ha metido en la casa de Jehová, que han juntado del pueblo los guardianes de la puerta, [^4] Y que lo pongan en manos de los que hacen la obra, que tienen cargo de la casa de Jehová, y que lo entreguen á los que hacen la obra de la casa de Jehová, para reparar las aberturas de la casa: [^5] A los carpinteros, á los maestros y albañiles, para comprar madera y piedra de cantería para reparar la casa; [^6] Y que no se les cuente el dinero cuyo manejo se les confiare, porque ellos proceden con fidelidad. [^7] Entonces dijo el sumo sacerdote Hilcías á Saphán escriba: El libro de la ley he hallado en la casa de Jehová. E Hilcías dió el libro á Saphán, y leyólo. [^8] Viniendo luego Saphán escriba al rey, dió al rey la respuesta, y dijo: Tus siervos han juntado el dinero que se halló en el templo, y lo han entregado en poder de los que hacen la obra, que tienen cargo de la casa de Jehová. [^9] Asimismo Saphán escriba declaró al rey, diciendo: Hilcías el sacerdote me ha dado un libro. Y leyólo Saphán delante del rey. [^10] Y cuando el rey hubo oído las palabras del libro de la ley, rasgó sus vestidos. [^11] Luego mandó el rey á Hilcías el sacerdote, y á Ahicam hijo de Saphán, y á Achbor hijo de Michâía, y á Saphán escriba, y á Asaía siervo del rey, diciendo: [^12] Id, y preguntad á Jehová por mí, y por el pueblo, y por todo Judá, acerca de las palabras de este libro que se ha hallado: porque grande ira de Jehová es la que ha sido encendida contra nosotros, por cuanto nuestros padres no escucharon las palabras de este libro, para hacer conforme á todo lo que nos fué escrito. [^13] Entonces fué Hilcías el sacerdote, y Ahicam y Achbor y Saphán y Asaía, á Hulda profetisa, mujer de Sallum hijo de Ticva hijo de Araas, guarda de las vestiduras, la cual moraba en Jerusalem en la segunda parte de la ciudad, y hablaron con ella. [^14] Y ella les dijo: Así ha dicho Jehová el Dios de Israel: Decid al varón que os envió á mí: [^15] Así dijo Jehová: He aquí yo traigo mal sobre este lugar, y sobre los que en él moran, á saber, todas las palabras del libro que ha leído el rey de Judá: [^16] Por cuanto me dejaron á mí, y quemaron perfumes á dioses ajenos, provocándome á ira en toda obra de sus manos; y mi furor se ha encendido contra este lugar, y no se apagará. [^17] Mas al rey de Judá que os ha enviado para que preguntaseis á Jehová, diréis así: Así ha dicho Jehová el Dios de Israel: Por cuanto oíste las palabras del libro, [^18] Y tu corazón se enterneció, y te humillaste delante de Jehová, cuando oíste lo que yo he pronunciado contra este lugar y contra sus moradores, que vendrían á ser asolados y malditos, y rasgaste tus vestidos, y lloraste en mi presencia, también yo te he oído, dice Jehová. [^19] Por tanto, he aquí yo te recogeré con tus padres, y tú serás recogido á tu sepulcro en paz, y no verán tus ojos todo el mal que yo traigo sobre este lugar. Y ellos dieron al rey la respuesta. [^20] 

[[2 Kings - 21|<--]] 2 Kings - 22 [[2 Kings - 23|-->]]

---
# Notes
