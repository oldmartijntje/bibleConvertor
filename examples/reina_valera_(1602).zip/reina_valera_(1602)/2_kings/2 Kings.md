---
translation: Reina Valera (1602)
aliases:
  - "2 Kings - Reina Valera (1602)"
tags:
  - "#bible/type/book"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
---
[[1 Kings|<--]] 2 Kings [[1 Chronicles|-->]]

# 2 Kings - Reina Valera (1602)

The 2 Kings book has 25 chapters. It is part of the old testament.

## Chapters

- 2 Kings [[2 Kings - 1|chapter 1]]
- 2 Kings [[2 Kings - 2|chapter 2]]
- 2 Kings [[2 Kings - 3|chapter 3]]
- 2 Kings [[2 Kings - 4|chapter 4]]
- 2 Kings [[2 Kings - 5|chapter 5]]
- 2 Kings [[2 Kings - 6|chapter 6]]
- 2 Kings [[2 Kings - 7|chapter 7]]
- 2 Kings [[2 Kings - 8|chapter 8]]
- 2 Kings [[2 Kings - 9|chapter 9]]
- 2 Kings [[2 Kings - 10|chapter 10]]
- 2 Kings [[2 Kings - 11|chapter 11]]
- 2 Kings [[2 Kings - 12|chapter 12]]
- 2 Kings [[2 Kings - 13|chapter 13]]
- 2 Kings [[2 Kings - 14|chapter 14]]
- 2 Kings [[2 Kings - 15|chapter 15]]
- 2 Kings [[2 Kings - 16|chapter 16]]
- 2 Kings [[2 Kings - 17|chapter 17]]
- 2 Kings [[2 Kings - 18|chapter 18]]
- 2 Kings [[2 Kings - 19|chapter 19]]
- 2 Kings [[2 Kings - 20|chapter 20]]
- 2 Kings [[2 Kings - 21|chapter 21]]
- 2 Kings [[2 Kings - 22|chapter 22]]
- 2 Kings [[2 Kings - 23|chapter 23]]
- 2 Kings [[2 Kings - 24|chapter 24]]
- 2 Kings [[2 Kings - 25|chapter 25]]

[[1 Kings|<--]] 2 Kings [[1 Chronicles|-->]]

---
# Notes
