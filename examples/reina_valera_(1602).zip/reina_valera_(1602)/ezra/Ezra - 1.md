---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/ezra"
  - "#bible/testament/old"
aliases:
  - "Ezra - 1 - Reina Valera (1602)"
---
Ezra - 1 [[Ezra - 2|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Ezra]]

# Ezra - 1

Y EN el primer año de Ciro rey de Persia, para que se cumpliese la palabra de Jehová por boca de Jeremías, excitó Jehová el espíritu de Ciro rey de Persia, el cual hizo pasar pregón por todo su reino, y también por escrito, diciendo: [^1] Así ha dicho Ciro rey de Persia: Jehová Dios de los cielos me ha dado todos los reinos de la tierra, y me ha mandado que le edifique casa en Jerusalem, que está en Judá. [^2] ¿Quién hay entre vosotros de todo su pueblo? Sea Dios con él, y suba á Jerusalem que está en Judá, y edifique la casa á Jehová Dios de Israe la cual está en Jerusalem. [^3] Y á cualquiera que hubiere quedado de todos los lugares donde peregrinare, los hombres de su lugar le ayuden con plata, y oro, y hacienda, y con bestias; con dones voluntarios para la casa de Dios, la cuál está en Jerusalem. [^4] Entonces se levantaron los cabezas de las familias de Judá y de Benjamín, y los sacerdotes y Levitas, todos aquellos cuyo espíritu despertó Dios para subir á edificar la casa de Jehová, la cual está en Jerusalem. [^5] Y todos los que estaban en sus alrededores confortaron las manos de ellos con vasos de plata y de oro, con hacienda y bestias, y con cosas preciosas, á más de lo que se ofreció voluntariamente. [^6] Y el rey Ciro sacó los vasos de la casa de Jehová, que Nabucodonosor había traspasado de Jerusalem, y puesto en la casa de sus dioses. [^7] Sacólos pues Ciro rey de Persia, por mano de Mitrídates tesorero, el cual los dió por cuenta á Sesbassar príncipe de Judá. [^8] Y esta es la cuenta de ellos: treinta tazones de oro, mil tazones de plata, veinte y nueve cuchillos, [^9] Treinta tazas de oro, cuatrocientas y diez otras tazas de plata, y mil otros vasos. [^10] Todos los vasos de oro y de plata, cinco mil y cuatrocientos. Todos los hizo llevar Sesbassar con los que subieron del cautiverio de Babilonia á Jerusalem. [^11] 

Ezra - 1 [[Ezra - 2|-->]]

---
# Notes
