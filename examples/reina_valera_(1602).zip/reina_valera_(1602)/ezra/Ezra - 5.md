---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/ezra"
  - "#bible/testament/old"
aliases:
  - "Ezra - 5 - Reina Valera (1602)"
---
[[Ezra - 4|<--]] Ezra - 5 [[Ezra - 6|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Ezra]]

# Ezra - 5

Y PROFETIZARON Haggeo profeta, y Zacarías hijo de Iddo, profetas, á los Judíos que estaba en Judá y en Jerusalem yendo en nombre del Dios de Israel á ellos. [^1] Entonces se levantaron Zorobabel hijo de Sealthiel, y Jesuá hijo de Josadec; y comenzaron á edificar la casa de Dios que estaba en Jerusalem; y con ellos los profetas de Dios que les ayudaban. [^2] En aquel tiempo vino á ellos Tatnai, capitán de la parte allá del río, y Setharboznai y sus compañeros, y dijéronles así: ¿Quién os dió mandamiento para edificar esta casa, y restablecer estos muros? [^3] Entonces les dijimos en orden á esto cuáles eran los nombres de los varones que edificaban este edificio. [^4] Mas los ojos de su Dios fueron sobre los ancianos de los Judíos, y no les hicieron cesar hasta que el negocio viniese á Darío: y entonces respondieron por carta sobre esto. [^5] Traslado de la carta que Tatnai, capitán de la parte allá del río, y Sethar-boznai, y sus compañeros los Apharsachêos, que estaban á la parte allá del río, enviaron al rey Darío. [^6] Enviáronle carta, y de esta manera estaba escrito en ella. Al rey Darío toda paz. [^7] Sea notorio al rey, que fuimos á la provincia de Judea, á la casa del gran Dios, la cual se edifica de piedra de mármol; y los maderos son puestos en las paredes, y la obra se hace apriesa, y prospera en sus manos. [^8] Entonces preguntamos á los ancianos, diciéndoles así: ¿Quién os dió mandameinto para edificar esta casa, y para restablecer estos muros? [^9] Y también les preguntamos sus nombres para hacértelo saber, para escribir te los nombres de los varones que estaban por cabezas de ellos. [^10] Y respondiéronnos, diciendo así: Nosotros somos siervos de Dios del cielo y de la tierra, y reedificamos la casa que ya muchos años antes había sido edificada, la cual edificó y fundó el gran rey de Israel. [^11] Mas después que nuestros padres ensañaron al Dios de los cielos, él los entregó en mano de Nabucodonosor rey de Babilonia, Caldeo, el cual destruyó esta casa, é hizo trasportar el pueblo á Babilonia. [^12] Empero el primer año de Ciro rey de Babilonia, el mismo rey Ciro dió mandamiento para que esta casa de Dios fuese edificada. [^13] Y también los vasos de oro y de plata de la casa de Dios, que Nabucodonosor había sacado del templo que estaba en Jerusalem, y los había metido en el templo de Babilonia, el rey Ciro los sacó del templo de Babilonia, y fueron entregados á Sesbassar, al cual había puesto por gobernador; [^14] Y le dijo: Toma estos vasos, ve y ponlos en el templo que está en Jerusalem; y la casa de Dios sea edificada en su lugar. [^15] Entonces este Sesbassar vino, y puso los fundamentos de la casa de Dios que estaba en Jerusalem, y desde entonces hasta ahora se edifica, y aun no está acabada. [^16] Y ahora, si al rey parece bien, búsquese en la casa de los tesoros del rey que está allí en Babilonia, si es así que por el rey Ciro había sido dado mandamiento para edificar esta casa de Dios en Jerusalem, y envíenos á decir la voluntad del rey sobre esto. [^17] 

[[Ezra - 4|<--]] Ezra - 5 [[Ezra - 6|-->]]

---
# Notes
