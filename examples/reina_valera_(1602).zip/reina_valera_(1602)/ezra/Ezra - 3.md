---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/ezra"
  - "#bible/testament/old"
aliases:
  - "Ezra - 3 - Reina Valera (1602)"
---
[[Ezra - 2|<--]] Ezra - 3 [[Ezra - 4|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Ezra]]

# Ezra - 3

Y LLEGADO el mes séptimo, y ya los hijos de Israel en las ciudades, juntóse el pueblo como un solo hombre en Jerusalem. [^1] Entonces se levantó Jesuá hijo de Josadec, y sus hermanos los sacerdotes, y Zorobabel hijo de Sealthiel, y sus hermanos, y edificaron el altar del Dios de Israel, para ofrecer sobre él holocaustos como está escrito en la ley de Moisés varón de Dios. [^2] Y asentaron el altar sobre sus basas, bien que tenían miedo de los pueblos de las tierras, y ofrecieron sobre él holocaustos á Jehová, holocaustos á la mañana y á la tarde. [^3] Hicieron asimismo la solemnidad de las cabañas, como está escrito, y holocaustos cada día por cuenta, conforme al rito, cada cosa en su día; [^4] Y á más de esto, el holocausto continuo, y las nuevas lunas, y todas las fiestas santificadas de Jehová, y todo sacrificio espontáneo, toda ofrenda voluntaria á Jehova. [^5] Desde el primer día del mes séptimo comenzaron á ofrecer holocaustos á Jehová; mas el templo de Jehová no estaba aún fundado. [^6] Y dieron dinero á los carpinteros y oficiales; asimismo comida y bebida y aceite á los Sidonios y Tirios, para que trajesen madera de cedro del Líbano á la mar de Joppe, conforme á la voluntad de Ciro rey de Persia acerca de esto. [^7] Y en el año segundo de su venida á la casa de Dios en Jerusalem, en el mes segundo, comenzaron Zorobabel hijo de Sealthiel, y Jesuá hijo de Josadec, y los otros sus hermanos, los sacerdotes y los Levitas, y todos los que habían venido de la cautividad á Jerusalem; y pusieron á los Levitas de veinte años arriba para que tuviesen cargo de la obra de la casa de Jehová. [^8] Jesuá también, sus hijos y sus hermanos, Cadmiel y sus hijos, hijos de Judá, como un solo hombre asistían para dar priesa á los que hacían la obra en la casa de Dios: los hijos de Henadad, sus hijos y sus hermanos, Levitas. [^9] Y cuando los albañiles del templo de Jehová echaban los cimientos, pusieron á los sacerdotes vestidos de sus ropas, con trompetas, y á Levitas hijos de Asaph con címbalos, para que alabasen á Jehová, según ordenanza de David rey de Israel. [^10] Y cantaban, alabando y confesando á Jehová, y decían: Porque es bueno, porque para siempre es su misericordia sobre Israel. Y todo el pueblo aclamaba con grande júbilo, alabando á Jehová, porque á la casa de Jehová se echaba el cimiento. [^11] Y muchos de los sacerdotes y de los Levitas y de los cabezas de los padres, ancianos que habían visto la casa primera, viendo fundar esta casa, lloraban en alta voz, mientras muchos otros daban grandes gritos de alegría. [^12] Y no podía discernir el pueblo el clamor de los gritos de alegría, de la voz del lloro del pueblo: porque clamaba el pueblo con grande júbilo, y oíase el ruido hasta de lejos. [^13] 

[[Ezra - 2|<--]] Ezra - 3 [[Ezra - 4|-->]]

---
# Notes
