---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/ezra"
  - "#bible/testament/old"
aliases:
  - "Ezra - 9 - Reina Valera (1602)"
---
[[Ezra - 8|<--]] Ezra - 9 [[Ezra - 10|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Ezra]]

# Ezra - 9

Y ACABADAS estas cosas, los príncipes se llegaron á mí, diciendo: El pueblo de Israel, y los sacerdotes y levitas, no se han apartado de los pueblos de las tierras, de los Cananeos, Hetheos, Pherezeos, Jebuseos, Ammonitas, y Moabitas, Egipcios, y Amorrheos, haciendo conforme á sus abominaciones. [^1] Porque han tomado de sus hijas para sí y para sus hijos, y la simiente santa ha sido mezclada con los pueblos de las tierras; y la mano de los príncipes y de los gobernadores ha sido la primera en esta prevaricación. [^2] Lo cual oyendo yo, rasgué mi vestido y mi manto, y arranqué de los cabellos de mi cabeza y de mi barba, y sentéme atónito. [^3] Y juntáronse á mí todos los temerosos de las palabras del Dios de Israel, á causa de la prevaricación de los de la transmigración; mas yo estuve sentado atónito hasta el sacrificio de la tarde. [^4] Y al sacrificio de la tarde levantéme de mi aflicción; y habiendo rasgado mi vestido y mi manto, postréme de rodillas, y extendí mis palmas á Jehová mi Dios, [^5] Y dije: Dios mío, confuso y avergonzado estoy para levantar, oh Dios mío, mi rostro á ti: porque nuestras iniquidades se han multiplicado sobre nuestra cabeza, y nuestros delitos han crecido hasta el cielo. [^6] Desde los días de nuestros padres hasta este día estamos en grande culpa; y por nuestras iniquidades nosotros, nuestros reyes, y nuestros sacerdotes, hemos sido entregados en manos de los reyes de las tierras, á cuchillo, á cautiverio, y á robo, y á confusión de rostro, como hoy día. [^7] Y ahora como por un breve momento fué la misericordia de Jehová nuestro Dios, para hacer que nos quedase un resto libre, y para darnos estaca en el lugar de su santuario, á fin de alumbrar nuestros ojos nuestro Dios, y darnos una poca de vida en nuestra servidumbre. [^8] Porque siervos éramos: mas en nuestra servidumbre no nos desamparó nuestro Dios, antes inclinó sobre nosotros misericordia delante de los reyes de Persia, para que se nos diese vida para alzar la casa de nuestro Dios, y para hacer restaurar sus asolamientos, y para darnos vallado en Judá y en Jerusalem. [^9] Mas ahora, ¿qué diremos, oh Dios nuestro, después de esto? porque nosotros hemos dejado tus mandamientos, [^10] Los cuales prescribiste por mano de tus siervos los profetas, diciendo: La tierra á la cual entráis para poseerla, tierra inmunda es á causa de la inmundicia de los pueblos de aquellas regiones, por las abominaciones de que la han henchido de uno á otro extremo con su inmundicia. [^11] Ahora pues, no daréis vuestras hijas á los hijos de ellos, ni sus hijas tomaréis para vuestros hijos, ni procuraréis su paz ni su bien para siempre; para que seáis corroborados, y comáis el bien de la tierra, y la dejéis por heredad á vuestros hijos para siempre. [^12] Mas después de todo lo que nos ha sobrevenido á causa de nuestras malas obras, y á causa de nuestro grande delito, ya que tú, Dios nuestro, estorbaste que fuésemos oprimidos bajo de nuestras iniquidades, y nos diste este tal efugio; [^13] ¿Hemos de volver á infringir tus mandamientos, y á emparentar con los pueblos de estas abominaciones? ¿No te ensañarías contra nosotros hasta consumirnos, sin que quedara resto ni escapatoria? [^14] Jehová, Dios de Israel, tú eres justo: pues que hemos quedado algunossalvos, como este día, henos aquí delante de ti en nuestros delitos; porque no es posible subsistir en tu presencia á causa de esto. [^15] 

[[Ezra - 8|<--]] Ezra - 9 [[Ezra - 10|-->]]

---
# Notes
