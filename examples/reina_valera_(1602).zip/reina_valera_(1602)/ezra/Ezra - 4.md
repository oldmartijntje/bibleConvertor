---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/ezra"
  - "#bible/testament/old"
aliases:
  - "Ezra - 4 - Reina Valera (1602)"
---
[[Ezra - 3|<--]] Ezra - 4 [[Ezra - 5|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Ezra]]

# Ezra - 4

Y OYENDO los enemigos de Judá y de Benjamín, que los venidos de la cautividad edificaban el templo de Jehová Dios de Israel, [^1] Llegáronse á Zorobabel, y á los cabezas de los padres, y dijéronles: Edificaremos con vosotros, porque como vosotros buscaremos á vuestro Dios, y á él sacrificamos desde los días de Esar-haddón rey de Asiria, que nos hizo subir aquí. [^2] Y dijóles Zorobabel, y Jesuá, y los demás cabezas de los padres de Israel: No nos conviene edificar con vosotros casa á nuestro Dios, sino que nosotros solos la edificaremos á Jehová Dios de Israel, como nos mandó el rey Ciro, rey de Persia. [^3] Mas el pueblo de la tierra debilitaba las manos del pueblo de Judá, y los arredraban de edificar. [^4] Cohecharon además contra ellos consejeros para disipar su consejo, todo el tiempo de Ciro rey de Persia, y hasta el reinado de Darío rey de Persia. [^5] Y en el reinado de Assuero, en el principio de su reinado, escribieron acusaciones contra los moradores de Judá y de Jerusalem. [^6] Y en días de Artajerjes, Bislam, Mitrídates, Tabeel, y los demás sus compañeros, escribieron á Artajerjes rey de Persia; y la escritura de la carta estaba hecha en siriaco, y declarada en siriaco. [^7] Rehum canciller, y Simsai secretario, escribieron una carta contra Jerusalem al rey Artajerjes, como se sigue. [^8] Entonces Rehum canciller, y Simsai secretario, y los demás sus compañeros, los Dineos, y los Apharsathachêos, Thepharleos, Apharseos, los Erchûeos, los Babilonios, Susaschêos, Dieveos, y Elamitas; [^9] Y los demás pueblos que el grande y glorioso Asnappar trasportó, é hizo habitar en las ciudades de Samaria, y los demás de la otra parte del río, etcétera, escribieron. [^10] Este es el traslado de la carta que enviaron: Al rey Artajerjes: Tus siervos de otra la parte del río, etcétera. [^11] Sea notorio al rey, que los Judíos que subieron de tí á nosotros, vinieron á Jerusalem; y edifican la ciudad rebelde y mala, y han erigido los muros; y compuesto los fundamentos. [^12] Ahora, notorio sea al rey, que si aquella ciudad fuere reedificada, y los muros fueren establecidos, el tributo, pecho, y rentas no darán, y el catastro de lo reyes será menoscabado. [^13] Ya pues que estamos mantenidos de palacio, no nos es justo ver el menosprecio del rey: hemos enviado por tanto, y hécho lo saber al rey, [^14] Para que busque en el libro de las historias de nuestros padres; y hallarás en el libro de las historias, y sabrás que esta ciudad es ciudad rebelde, y perjudicial á los reyes y á las provincias, y que de tiempo antiguo forman en medio de ella rebeliones; por lo que esta ciudad fué destruída. [^15] Hacemos saber al rey, que si esta ciudad fuere edificada, y erigidos sus muros, la parte allá del río no será tuya. [^16] El rey envió esta respuesta á Rehum canciller, y á Simsai secretario, y á los demás sus compañeros que habitan en Samaria, y á los demás de la parte allá del río: Paz, etc. [^17] La carta que nos enviasteis claramente fué leída delante de mí. [^18] Y por mí fué dado mandamiento, y buscaron; y hallaron que aquella ciudad de tiempo antiguo se levanta contra los reyes, y se rebela, y se forma en ella sedición: [^19] Y que reyes fuertes hubo en Jerusalem, quienes señorearon en todo lo que está á la parte allá del río; y que tributo, y pecho, y rentas se les daba. [^20] Ahora pues dad orden que cesen aquellos hombres, y no sea esa ciudad edificada, hasta que por mí sea dado mandamiento. [^21] Y mirad bien que no hagáis error en esto: ¿por qué habrá de crecer el daño para perjuicio de los reyes? [^22] Entonces, cuando el traslado de la carta del rey Artajerjes fué leído delante de Rehum, y de Simsai secretario, y sus compañeros, fueron prestamente á Jerusalem á los Judíos, é hiciéronles cesar con poder y fuerza. [^23] Cesó entonces la obra de la casa de Dios, la cual estaba en Jerusalem: y cesó hasta el año segundo del reinado de Darío rey de Persia. [^24] 

[[Ezra - 3|<--]] Ezra - 4 [[Ezra - 5|-->]]

---
# Notes
