---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 18 - Reina Valera (1602)"
---
[[1 Chronicles - 17|<--]] 1 Chronicles - 18 [[1 Chronicles - 19|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Chronicles]]

# 1 Chronicles - 18

DESPUÉS de estas cosas aconteció que David hirió á los Filisteos, y los humilló; y tomó á Gath y sus villas de mano de los Filisteos. [^1] También hirió á Moab; y los Moabitas fueron siervos de David trayéndole presentes. [^2] Asimismo hirió David á Adarezer rey de Soba, en Hamath, yendo él á asegurar su dominio al río de Eufrates. [^3] Y tomóles David mil carros, y siete mil de á caballo, y veinte mil hombres de á pie: y desjarretó David los caballos de todos los carros, excepto los de cien carros que dejó. [^4] Y viniendo los Siros de Damasco en ayuda de Adarezer rey de Soba, David hirió de los Siros veintidós mil hombres. [^5] Y puso David guarnición en Siria la de Damasco, y los Siros fueron hechos siervos de David, trayéndole presentes: porque Jehová salvaba á David donde quiera que iba. [^6] Tomó también David los escudos de oro que llevaban los siervos de Adarezer, y trájolos á Jerusalem. [^7] Asimismo de Thibath y de Chûn ciudades de Adarezer, tomó David muy mucho metal, de que Salomón hizo el mar de bronce, las columnas, y vasos de bronce. [^8] Y oyendo Tou rey de Hamath, que David había deshecho todo el ejército de Adarezer, rey de Soba, [^9] Envió á Adoram su hijo al rey David, á saludarle y á bendecirle por haber peleado con Adarezer, y haberle vencido; porque Tou tenía guerra con Adarezer. Envióle también toda suerte de vasos de oro, de plata y de metal; [^10] Los cuales el rey David dedicó á Jehová, con la plata y oro que había tomado de todas las naciones, de Edom, de Moab, de los hijos de Ammón, de los Filisteos, y de Amalec. [^11] A más de esto Abisai hijo de Sarvia hirió en el valle de la Sal dieciocho mil Idumeos. [^12] Y puso guarnición en Edom, y todos los Idumeos fueron siervos de David: porque Jehová guardaba á David donde quiera que iba. [^13] Y reinó David sobre todo Israel, y hacía juicio y justicia á todo su pueblo. [^14] Y Joab hijo de Sarvia era general del ejército; y Josaphat hijo de Ahilud, canciller; [^15] Y Sadoc hijo de Achîtob, y Abimelec hijo de Abiathar, eran sacerdotes; y Sausa, secretario; [^16] Y Benaías hijo de Joiada era sobre los Ceretheos y Peletheos; y los hijos de David eran los príncipes cerca del rey. [^17] 

[[1 Chronicles - 17|<--]] 1 Chronicles - 18 [[1 Chronicles - 19|-->]]

---
# Notes
