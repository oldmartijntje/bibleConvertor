---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 19 - Reina Valera (1602)"
---
[[1 Chronicles - 18|<--]] 1 Chronicles - 19 [[1 Chronicles - 20|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Chronicles]]

# 1 Chronicles - 19

DESPUÉS de estas cosas aconteció que murió Naas rey de los hijos de Ammón, y reinó en su lugar su hijo. [^1] Y dijo David: Haré misericordia con Hanán hijo de Naas, porque también su padre hizo conmigo misericordia. Así David envió embajadores que lo consolasen de la muerte de su padre. Mas venidos los siervos de David en la tierra de los hijos de Ammón á Hanán, para consolarle, [^2] Los príncipes de los hijos de Ammón dijeron á Hanán: ¿A tu parecer honra David á tu padre, que te ha enviado consoladores? ¿no vienen antes sus siervos á ti para escudriñar, é inquirir, y reconocer la tierra? [^3] Entonces Hanán tomó los siervos de David, y rapólos, y cortóles los vestidos por medio, hasta las nalgas, y despachólos. [^4] Fuéronse pues, y dada que fué la nueva á David de aquellos varones, él envió á recibirlos, porque estaban muy afrentados. E hízoles decir el rey: Estaos en Jericó hasta que os crezca la barba, y entonces volveréis. [^5] Y viendo los hijos de Ammón que se habían hecho odiosos á David, Hanán y los hijos de Ammón enviaron mil talentos de plata, para tomar á sueldo carros y gente de á caballo de Siria de los ríos, y de la Siria de Maachâ, y de Soba. [^6] Y tomaron á sueldo treinta y dos mil carros, y al rey de Maachâ y á su pueblo, los cuales vinieron y asentaron su campo delante de Medeba. Y juntáronse también los hijos de Ammón de sus ciudades, y vinieron á la guerra. [^7] Oyéndolo David, envió á Joab con todo el ejército de los hombres valientes. [^8] Y los hijos de Ammón salieron, y ordenaron su tropa á la entrada de la ciudad; y los reyes que habían venido, estaban por sí en el campo. [^9] Y viendo Joab que la haz de la batalla estaba contra él delante y á las espaldas, escogió de todos los más aventajados que había en Israel, y ordenó su escuadrón contra los Sirios. [^10] Puso luego el resto de la gente en mano de Abisai su hermano, ordenándolos en batalla contra los Ammonitas. [^11] Y dijo: Si los Siros fueren más fuertes que yo, tú me salvarás; y si los Ammonitas fueren más fuertes que tú, yo te salvaré. [^12] Esfuérzate, y esforcémonos por nuestro pueblo, y por las ciudades de nuestro Dios; y haga Jehová lo que bien le pareciere. [^13] Acercóse luego Joab y el pueblo que tenía consigo, para pelear contra los Siros; mas ellos huyeron delante de él. [^14] Y los hijos de Ammón, viendo que los Siros habían huído, huyeron también ellos delante de Abisai su hermano, y entráronse en la ciudad. Entonces Joab se volvió á Jerusalem. [^15] Y viendo los Siros que habían caído delante de Israel, enviaron embajadores, y trajeron á los Siros que estaban de la otra parte del río, cuyo capitán era Sophach, general del ejército de Adarezer. [^16] Luego que fué dado aviso á David, juntó á todo Israel, y pasando el Jordán vino á ellos, y ordenó contra ellos su ejército. Y como David hubo ordenado su tropa contra ellos, pelearon con él los Siros. [^17] Mas el Siro huyó delante de Israel; y mató David de los Siros siete mil hombres de los carros, y cuarenta mil hombres de á pie: asimismo mató á Sophach, general del ejército. [^18] Y viendo los Siros de Adarezer que habían caído delante de Israel, concertaron paz con David, y fueron sus siervos; y nunca más quiso el Siro ayudar á los hijos de Ammón. [^19] 

[[1 Chronicles - 18|<--]] 1 Chronicles - 19 [[1 Chronicles - 20|-->]]

---
# Notes
