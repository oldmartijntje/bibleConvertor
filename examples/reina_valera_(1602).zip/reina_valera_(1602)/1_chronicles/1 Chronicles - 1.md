---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 1 - Reina Valera (1602)"
---
1 Chronicles - 1 [[1 Chronicles - 2|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Chronicles]]

# 1 Chronicles - 1

ADAM, Seth, Enos, [^1] Cainán, Mahalaleel, Jared, [^2] Enoch, Mathusalem, Lamech, [^3] Noé, Sem, Châm, y Japhet. [^4] Los hijos de Japhet: Gomer, Magog, Dadai, Javán, Tubal, Mesec, y Thiras. [^5] Los hijos de Gomer: Askenaz, Riphath, y Thogorma. [^6] Los hijos de Javán: Elisa, Tharsis, Chîthim, y Dodanim. [^7] Los hijos de Châm: Chûs, Misraim, Phuth, y Canaán. [^8] Los hijos de Chûs: Seba, Havila, Sabtha, Raema, y Sabtechâ. Y los hijos de Raema: Seba y Dedán. [^9] Chûs engendró á Nimrod: éste comenzó á ser poderoso en la tierra. [^10] Misram engendró á Ludim, Ananim, Laabim, Nephtuim, [^11] Phetrusim y Casluim: de éstos salieron los Filisteos, y los Caphtoreos. [^12] Canaán engendró á Sidón, su primogénito; [^13] Y al Hetheo, y al Jebuseo, y al Amorrheo, y al Gergeseo; [^14] Y al Heveo, y al Araceo, y al Sineo; [^15] Al Aradeo, y al Samareo, y al Hamatheo. [^16] Los hijos de Sem: Elam, Assur, Arphaxad, Lud, Aram, Hus, Hul, Gether, y Mesec. [^17] Arphaxad engendró á Sela, y Sela engendró á Heber. [^18] Y á Heber nacieron dos hijos: el nombre del uno fué Peleg, por cuanto en sus días fué dividida la tierra; y el nombre de su hermano fué Joctán. [^19] Y Joctán engendró á Elmodad, Seleph, Asarmaveth, y Jera, [^20] A Adoram también, á Uzal, Dicla, [^21] Hebal, Abimael, Seba, [^22] Ophir, Havila, y Jobab: todos hijos de Joctán. [^23] Sem, Arphaxad, Sela, [^24] Heber, Peleg, Reu, [^25] Serug, Nachôr, Thare, [^26] Y Abram, el cual es Abraham. [^27] Los hijos de Abraham: Isaac é Ismael. [^28] Y estas son sus descendencias: el primogénito de Ismael, Nabajoth; después Cedar, Adbeel, Misam, [^29] Misma, Duma, Maasa, Hadad, Thema, Jetur, Naphis, y Cedma. Estos son los hijos de Ismael. [^30] Y Cethura, concubina de Abraham, parió á Zimram, Jocsán, Medán, Madián, Isbac, y á Súa. [^31] Los hijos de Jobsán: Seba y Dedán. [^32] Los hijos de Madián: Epha, Epher, Henoch, Abida, y Eldaa; todos estos fueron hijos de Cethura. [^33] Y Abraham engendró á Isaac: y los hijos de Isaac fueron Esaú é Israel. [^34] Los hijos de Esaú: Eliphas, Rehuel, Jeus, Jalam, y Cora. [^35] Los hijos de Eliphas: Themán, Omar, Sephi, Hatham, Chênas, Timna, y Amalec. [^36] Los hijos de Rehuel: Nahath, Zera, Samma, y Mizza. [^37] Los hijos de Seir: Lotán, Sobal, Sibeón, Ana, Disón, Eser, y Disán. [^38] Los hijos de Lotán: Hori, y Homam: y Timna fué hermana de Lotán. [^39] Los hijos de Sobal: Alian, Manahach, Ebal, Sephi y Oman. Los hijos de Sibehom: Aia, y Ana. [^40] Disón fué hijo de Ana: y los hijos de Disón; Hamrán, Hesbán, Ithran y Chêrán. [^41] Los hijos de Eser: Bilham, Zaaván, y Jaacán. Los hijos de Disán: Hus y Arán. [^42] Y estos son los reyes que reinaron en la tierra de Edom, antes que reinase rey sobre los hijos de Israel Belah, hijo de Beor; y el nombre de su ciudad fué Dinaba. [^43] Y muerto Belah, reinó en su lugar Jobab, hijo de Zera, de Bosra. [^44] Y muerto Jobab reinó en su lugar Husam, de la tierra de los Themanos. [^45] Muerto Husam, reinó en su lugar Adad, hijo de Bedad, el cual hirió á Madián en la campaña de Moab: y el nombre de su ciudad fué Avith. [^46] Muerto Adad, reinó en su lugar Samla, de Masreca. [^47] Muerto también Samla, reinó en su lugar Saúl de Rehoboth, que está junto al río. [^48] Y muerto Saúl, reinó en su lugar Baal-hanán, hijo de Achbor. [^49] Y muerto Baal-hanán, reinó en su lugar Adad, el nombre de cuya ciudad fué Pai; y el nombre de su mujer Meetabel, hija de Matred, y ésta de Mezaab. [^50] Muerto Adad, sucedieron los duques en Edom: el duque Timna, el duque Alia, el duque Jetheth, [^51] El duque Oholibama, el duque Ela, el duque Phinón, [^52] El duque Chênaz, el duque Themán, el duque Mibzar, [^53] El duque Magdiel, el duque Iram. Estos fueron los duques de Edom. [^54] 

1 Chronicles - 1 [[1 Chronicles - 2|-->]]

---
# Notes
