---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 23 - Reina Valera (1602)"
---
[[1 Chronicles - 22|<--]] 1 Chronicles - 23 [[1 Chronicles - 24|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Chronicles]]

# 1 Chronicles - 23

SIENDO pues David ya viejo y harto de días, hizo á Salomón su hijo rey sobre Israel. [^1] Y juntando á todos los principales de Israel, y á los sacerdotes y Levitas, [^2] Fueron contados los Levitas de treinta años arriba; y fué el número de ellos por sus cabezas, contados uno á uno, treinta y ocho mil. [^3] De éstos, veinticuatro mil para dar prisa á la obra de la casa de Jehová; y gobernadores y jueces, seis mil; [^4] Además cuatro mil porteros; y cuatro mil para alabar á Jehová, dijo David, con los instrumentos que he hecho para rendir alabanzas. [^5] Y repartiólos David en órdenes conforme á los hijos de Leví, Gersón y Coath y Merari. [^6] Los hijos de Gersón: Ladán, y Simi. [^7] Los hijos de Ladán, tres: Jehiel el primero, después Zetham y Joel. [^8] Los hijos de Simi, tres: Selomith, Haziel, y Arán. Estos fueron los príncipes de las familias de Ladán. [^9] Y los hijos de Simi: Jahath, Zinat, Jeus, y Berías. Estos cuatro fueron los hijos de Simi. [^10] Jahat era el primero, Zinat el segundo; mas Jeus y Berías no multiplicaron en hijos, por lo cual fueron contados por una familia. [^11] Los hijos de Coath: Amram, Ishar, Hebrón, y Uzziel, ellos cuatro. [^12] Los hijos de Amram: Aarón y Moisés. Y Aarón fué apartado para ser dedicado á las más santas cosas, él y sus hijos para siempre, para que quemasen perfumes delante de Jehová, y le ministrasen, y bendijesen en su nombre, para siempre. [^13] Y los hijos de Moisés, varón de Dios, fueron contados en la tribu de Leví. [^14] Los hijos de Moisés fueron Gersón y Eliezer. [^15] Hijo de Gersón fué Sebuel el primero. [^16] E hijo de Eliezer fué Rehabía el primero. Y Eliezer no tuvo otros hijos; mas los hijos de Rehabía fueron muchos. [^17] Hijo de Ishar fué Selomith el primero. [^18] Los hijos de Hebrón: Jería el primero, Amarías el segundo, Jahaziel el tercero, y Jecamán el cuarto. [^19] Los hijos de Uzziel: Michâ el primero, é Isía el segundo. [^20] Los hijos de Merari: Mahali y Musi. Los hijos de Mahali: Eleazar y Cis. [^21] Y murió Eleazar sin hijos, mas tuvo hijas; y los hijos de Cis, sus hermanos, las tomaron por mujeres. [^22] Los hijos de Musi: Mahali, Eder y Jerimoth, ellos tres. [^23] Estos son los hijos de Leví en las familias de sus padres, cabeceras de familias en sus delineaciones, contados por sus nombres, por sus cabezas, los cuales hacían obra en el ministerio de la casa de Jehová, de veinte años arriba. [^24] Porque David dijo: Jehová Dios de Israel ha dado reposo á su pueblo Israel, y el habitar en Jerusalem para siempre. [^25] Y también los Levitas no llevarán más el tabernáculo, y todos sus vasos para su ministerio. [^26] Así que, conforme á las postreras palabras de David, fué la cuenta de los hijos de Leví de veinte años arriba. [^27] Y estaban bajo la mano de los hijos de Aarón, para ministrar en la casa de Jehová, en los atrios y en las cámaras, y en la purificación de toda cosa santificada, y en la demás obra del ministerio de la casa de Dios; [^28] Asimismo para los panes de la proposición, y para la flor de la harina para el sacrificio, y para las hojuelas sin levadura, y para la fruta de sartén, y para lo tostado, y para toda medida y cuenta; [^29] Y para que asistiesen cada mañana todos los días á confesar y alabar á Jehová, y asimismo á la tarde; [^30] Y para ofrecer todos los holocaustos á Jehová los sábados, nuevas lunas, y solemnidades, por la cuenta y forma que tenían, continuamente delante de Jehová. [^31] Y para que tuviesen la guarda del tabernáculo del testimonio, y la guarda del santuario, y las órdenes de los hijos de Aarón sus hermanos, en el ministerio de la casa de Jehová. [^32] 

[[1 Chronicles - 22|<--]] 1 Chronicles - 23 [[1 Chronicles - 24|-->]]

---
# Notes
