---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 20 - Reina Valera (1602)"
---
[[1 Chronicles - 19|<--]] 1 Chronicles - 20 [[1 Chronicles - 21|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Chronicles]]

# 1 Chronicles - 20

Y ACONTECIO á la vuelta del año, en el tiempo que suelen los reyes salir á la guerra, que Joab sacó las fuerzas del ejército, y destruyó la tierra de los hijos de Ammón, y vino y cercó á Rabba. Mas David estaba en Jerusalem: y Joab batió á Rabba, y destruyóla. [^1] Y tomó David la corona de su rey de encima de su cabeza, y hallóla de peso de un talento de oro, y había en ella piedras preciosas; y fué puesta sobre la cabeza de David. Y Además de esto sacó de la ciudad un muy gran despojo. [^2] Sacó también al pueblo que estaba en ella, y cortólos con sierras, y con trillos de hierro, y segures. Lo mismo hizo David á todas las ciudades de los hijos de Ammón. Y volvióse David con todo el pueblo á Jerusalem. [^3] Después de esto aconteció que se levantó guerra en Gezer con los Filisteos; é hirió Sibbecai Husathita á Sippai, del linaje de los gigantes; y fueron humillados. [^4] Y volvióse á levantar guerra con los Filisteos; é hirió Elhanán hijo de Jair á Lahmi, hermano de Goliath Getheo, el asta de cuya lanza era como un enjullo de tejedores. [^5] Y volvió á haber guerra en Gath, donde hubo un hombre de grande estatura, el cual tenía seis dedos en pies y manos, en todos veinticuatro: y también era hijo de Rapha. [^6] Denostó él á Israel, mas hiriólo Jonathán, hijo de Sima hermano de David. [^7] Estos fueron hijos de Rapha en Gath, los cuales cayeron por mano de David y de sus siervos. [^8] 

[[1 Chronicles - 19|<--]] 1 Chronicles - 20 [[1 Chronicles - 21|-->]]

---
# Notes
