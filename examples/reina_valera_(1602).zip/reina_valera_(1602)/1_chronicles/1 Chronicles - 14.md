---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 14 - Reina Valera (1602)"
---
[[1 Chronicles - 13|<--]] 1 Chronicles - 14 [[1 Chronicles - 15|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Chronicles]]

# 1 Chronicles - 14

E Hiram rey de Tiro envió embajadores á David, y madera de cedro, y albañiles y carpinteros, que le edificasen una casa. [^1] Y entendió David que Jehová lo había confirmado por rey sobre Israel, y que había ensalzado su reino sobre su pueblo Israel. [^2] Entonces David tomó también mujeres en Jerusalem y aun engendró David hijos é hijas. [^3] Y estos son los nombres de los que le nacieron en Jerusalem: Samua, Sobab, Nathán, Salomón, [^4] Ibhar, Elisua, Eliphelet, [^5] Noga, Nepheg, Japhías, [^6] Elisama, Beel-iada y Eliphelet. [^7] Y oyendo los Filisteos que David había sido ungido por rey sobre todo Israel, subieron todos los Filisteos en busca de David. Y como David lo oyó, salió contra ellos. [^8] Y vinieron los Filisteos y extendiéronse por el valle de Raphaim. [^9] Entonces David consultó á Dios, diciendo: ¿Subiré contra los Filisteos? ¿los entregarás en mi mano? Y Jehová le dijo: Sube, que yo los entregaré en tus manos. [^10] Subieron pues á Baal-perasim, y allí los hirió David. Dijo luego David: Dios rompió mis enemigos por mi mano, como se rompen las aguas. Por esto llamaron el nombre de aquel lugar Baal-perasim. [^11] Y dejaron allí sus dioses, y David dijo que los quemasen al fuego. [^12] Y volviendo los Filisteos á extenderse por el valle, [^13] David volvió á consultar á Dios, y Dios le dijo: No subas tras ellos, sino rodéalos, para venir á ellos por delante de los morales; [^14] Y así que oyeres venir un estruendo por las copas de los morales, sal luego á la batalla: porque Dios saldrá delante de ti, y herirá el campo de los Filisteos. [^15] Hizo pues David como Dios le mandó, é hirieron el campo de los Filisteos desde Gabaón hasta Gezer. [^16] Y la fama de David fué divulgada por todas aquellas tierras: y puso Jehová temor de David sobre todas las gentes. [^17] 

[[1 Chronicles - 13|<--]] 1 Chronicles - 14 [[1 Chronicles - 15|-->]]

---
# Notes
