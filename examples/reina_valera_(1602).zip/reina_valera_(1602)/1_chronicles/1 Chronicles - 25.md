---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 25 - Reina Valera (1602)"
---
[[1 Chronicles - 24|<--]] 1 Chronicles - 25 [[1 Chronicles - 26|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Chronicles]]

# 1 Chronicles - 25

ASIMISMO David y los príncipes del ejército apartaron para el ministerio á los hijos de Asaph, y de Hemán, y de Jeduthún, los cuales profetizasen con arpas, salterios, y címbalos: y el número de ellos fué, de hombres idóneos para la obra de su ministerio respectivo: [^1] De los hijos de Asaph: Zachûr, José, Methanías, y Asareela, hijos de Asaph, bajo la dirección de Asaph, el cual profetizaba á la orden del rey. [^2] De Jeduthún: los hijos de Jeduthún, Gedalías, Sesi, Jesaías, Hasabías, y Mathithías, y Simi: seis, bajo la mano de su padre Jeduthún, el cual profetizaba con arpa, para celebrar y alabar á Jehová. [^3] De Hemán: los hijos de Hemán, Buccia, Mathanía, Uzziel, Sebuel, Jerimoth, Hananías, Hanani, Eliatha, Gidalthi, Romamti-ezer, Josbecasa, Mallothi, Othir, y Mahazioth. [^4] Todos estos fueron hijos de Hemán, vidente del rey en palabras de Dios, para ensalzar el poder suyo: y dió Dios á Hemán catorce hijos y tres hijas. [^5] Y todos estos estaban bajo la dirección de su padre en la música, en la casa de Jehová, con címbalos, salterios y arpas, para el ministerio del templo de Dios, por disposición del rey acerca de Asaph, de Jeduthún, y de Hemán. [^6] Y el número de ellos con sus hermanos instruídos en música de Jehová, todos los aptos, fué doscientos ochenta y ocho. [^7] Y echaron suertes para los turnos del servicio, entrando el pequeño con el grande, lo mismo el maestro que el discípulo. [^8] Y la primera suerte salió por Asaph, á José: la segunda á Gedalías, quien con sus hermanos é hijos fueron doce; [^9] La tercera á Zachûr, con sus hijos y sus hermanos, doce; [^10] La cuarta á Isri, con sus hijos y sus hermanos, doce; [^11] La quinta á Nethanías, con sus hijos y sus hermanos, doce; [^12] La sexta á Buccia, con sus hijos y sus hermanos, doce; [^13] La séptima á Jesarela, con sus hijos y sus hermanos, doce; [^14] La octava á Jesahías, con sus hijos y sus hermanos, doce; [^15] La nona á Mathanías, con sus hijos y sus hermanos, doce; [^16] La décima á Simi, con sus hijos y sus hermanos, doce; [^17] La undécima á Azareel, con sus hijos y sus hermanos, doce; [^18] La duodécima á Hasabías, con sus hijos y sus hermanos, doce; [^19] La décimatercia á Subael, con sus hijos y sus hermanos, doce; [^20] La décimacuarta á Mathithías, con sus hijos y sus hermanos, doce; [^21] La décimaquinta á Jerimoth, con sus hijos y sus hermanos, doce; [^22] La décimasexta á Hananías, con sus hijos y sus hermanos, doce; [^23] La décimaséptima á Josbecasa, con sus hijos y sus hermanos, doce; [^24] La décimaoctava á Hanani, con sus hijos y sus hermanos, doce; [^25] La décimanona á Mallothi, con sus hijos y sus hermanos, doce; [^26] La vigésima á Eliatha, con sus hijos y sus hermanos, doce; [^27] La vigésimaprima á Othir, con sus hijos y sus hermanos, doce; [^28] La vigésimasegunda á Giddalthi, con sus hijos y sus hermanos, doce; [^29] La vigésimatercia á Mahazioth, con sus hijos y sus hermanos, doce; [^30] La vigésimacuarta á Romamti-ezer, con sus hijos y sus hermanos, doce. [^31] 

[[1 Chronicles - 24|<--]] 1 Chronicles - 25 [[1 Chronicles - 26|-->]]

---
# Notes
