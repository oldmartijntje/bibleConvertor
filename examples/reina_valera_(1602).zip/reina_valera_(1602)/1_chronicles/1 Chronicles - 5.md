---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 5 - Reina Valera (1602)"
---
[[1 Chronicles - 4|<--]] 1 Chronicles - 5 [[1 Chronicles - 6|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Chronicles]]

# 1 Chronicles - 5

Y LOS hijos de Rubén, primogénito de Israel, (porque él era el primogénito, mas como violó el lecho de su padre, sus derechos de primogenitura fueron dados á los hijos de José, hijo de Israel; y no fué contado por primogénito. [^1] Porque Judá fué el mayorazgo sobre sus hermanos, y el príncipe de ellos: mas el derecho de primogenitura fué de José.) [^2] Fueron pues los hijos de Rubén, primogénito de Israel: Enoch, Phallu, Esrón y Charmi. [^3] Los hijos de Joel: Semaías su hijo, Gog su hijo, Simi su hijo; [^4] Michâ su hijo, Recaía su hijo, Baal su hijo; [^5] Beera su hijo, el cual fué trasportado por Thiglath-pilneser rey de los Asirios. Este era principal de los Rubenitas. [^6] Y sus hermanos por sus familias, cuando eran contados en sus descendencias, tenían por príncipes á Jeiel y á Zachârías. [^7] Y Bela hijo de Azaz, hijo de Sema, hijo de Joel, habitó en Aroer hasta Nebo y Baal-meón. [^8] Habitó también desde el oriente hasta la entrada del desierto desde el río Eufrates: porque tenía muchos ganados en la tierra de Galaad. [^9] Y en los días de Saúl trajeron guerra contra los Agarenos, los cuales cayeron en su mano; y ellos habitaron en sus tiendas sobre toda la haz oriental de Galaad. [^10] Y los hijos de Gad habitaron enfrente de ellos en la tierra de Basán hasta Salca. [^11] Y Joel fué el principal en Basán, el segundo Sephán, luego Janai, después Saphat. [^12] Y sus hermanos, según las familias de sus padres, fueron Michâel, Mesullam, Seba, Jorai, Jachân, Zia, y Heber; en todos siete. [^13] Estos fueron los hijos de Abihail hijo de Huri, hijo de Jaroa, hijo de Galaad, hijo de Michâel, hijo de Jesiaí, hijo de Jaddo, hijo de Buz. [^14] También Ahí, hijo de Abdiel, hijo de Guni, fué principal en la casa de sus padres. [^15] Los cuales habitaron en Galaad, en Basán, y en sus aldeas, y en todos los ejidos de Sarón hasta salir de ellos. [^16] Todos estos fueron contados por sus generaciones en días de Jothán rey de Judá, y en días de Jeroboam rey de Israel. [^17] Los hijos de Rubén, y de Gad, y la media tribu de Manasés, hombres valientes, hombres que traían escudo y espada, que entesaban arco, y diestros en guerra, en cuarenta y cuatro mil setecientos y sesenta que salían á batalla. [^18] Y tuvieron guerra los Agarenos, y Jethur, y Naphis, y Nodab. [^19] Y fueron ayudados contra ellos, y los Agarenos se dieron en sus manos, y todos los que con ellos estaban; porque clamaron á Dios en la guerra, y fuéles favorable, porque esperaron en él. [^20] Y tomaron sus ganados, cincuenta mil camellos, y doscientas cincuenta mil ovejas, dos mil asnos, y cien mil personas. [^21] Y cayeron muchos heridos, porque la guerra era de Dios; y habitaron en sus lugares hasta la transmigración. [^22] Y los hijos de la media tribu de Manasés habitaron en la tierra, desde Basán hasta Baal-Hermón, y Senir y el monte de Hermón, multiplicados en gran manera. [^23] Y estas fueron las cabezas de las casas de sus padres: Epher, Isi, y Eliel, Azriel, y Jeremías, y Odavia, y Jadiel, hombres valientes y de esfuerzo, varones de nombre y cabeceras de las casas de sus padres. [^24] Mas se rebelaron contra el Dios de sus padres, y fornicaron siguiendo los dioses de los pueblos de la tierra, á los cuales había Jehová quitado de delante de ellos. [^25] Por lo cual el Dios de Israel excitó el espíritu de Phul rey de los Asirios, y el espíritu de Thiglath-pilneser rey de los Asirios, el cual trasportó á los Rubenitas y Gaditas y á la media tribu de Manasés, y llevólos á Halad, y á Habor y á Ara, y al río de Gozán, hasta hoy. [^26] 

[[1 Chronicles - 4|<--]] 1 Chronicles - 5 [[1 Chronicles - 6|-->]]

---
# Notes
