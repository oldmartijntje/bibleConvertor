---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 17 - Reina Valera (1602)"
---
[[1 Chronicles - 16|<--]] 1 Chronicles - 17 [[1 Chronicles - 18|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Chronicles]]

# 1 Chronicles - 17

Y ACONTECIO que morando David en su casa, dijo David al profeta Nathán: He aquí yo habito en casa de cedro, y el arca del pacto de Jehová debajo de cortinas. [^1] Y Nathán dijo á David: Haz todo lo que está en tu corazón, porque Dios es contigo. [^2] En aquella misma noche fué palabra de Dios á Nathán, diciendo: [^3] Ve y di á David mi siervo: Así ha dicho Jehová: Tú no me edificarás casa en que habite: [^4] Porque no he habitado en casa alguna desde el día que saqué á los hijos de Israel hasta hoy; antes estuve de tienda en tienda, y de tabernáculo en tabernáculo. [^5] En todo cuanto anduve con todo Israel ¿hablé una palabra á alguno de los jueces de Israel, á los cuales mandé que apacentasen mi pueblo, para decirles: Por qué no me edificáis una casa de cedro? [^6] Por tanto, ahora dirás á mi siervo David: Así dijo Jehová de los ejércitos: Yo te tomé de la majada, de detrás del ganado, para que fueses príncipe sobre mi pueblo Israel; [^7] Y he sido contigo en todo cuanto has andado, y he talado á todos tus enemigos de delante de ti, y hete hecho grande nombre, como el nombre de los grandes que son en la tiera. [^8] Asimismo he dispuesto lugar á mi pueblo Israel, y lo he plantado para que habite por sí, y que no sea más conmovido: ni los hijos de iniquidad lo consumirán más, como antes, [^9] Y desde el tiempo que puse los jueces sobre mi pueblo Israel; mas humilllaré á todos tus enemigos. Hágote además saber que Jehová te ha de edificar casa. [^10] Y será que, cuando tus días fueren cumplidos para irte con tus padres, levantaré tu simiente después de ti, la cual será de tus hijos, y afirmaré su reino. [^11] El me edificará casa, y yo confirmaré su trono eternalmente. [^12] Yo le seré por padre, y él me será por hijo: y no quitaré de él mi misericordia, como la quité de aquel que fué antes de ti; [^13] Mas yo lo confirmaré en mi casa y en mi reino eternalmente; y su trono será firme para siempre. [^14] Conforme á todas estas palabras, y conforme á toda esta visión, así habló Nathán á David. [^15] Y entró el rey David, y estuvo delante de Jehová, y dijo: Jehová Dios, ¿quién soy yo, y cuál es mi casa, que me has traído hasta este lugar? [^16] Y aun esto, oh Dios, te ha parecido poco, pues que has hablado de la casa de tu siervo para más lejos, y me has mirado como á un hombre excelente, oh Jehová Dios. [^17] ¿Qué más puede añadir David pidiendo de ti para glorificar á tu siervo? mas tú conoces á tu siervo. [^18] Oh Jehová, por amor de tu siervo y según tu corazón, has hecho toda esta grandeza, para hacer notorias todas tus grandezas. [^19] Jehová, no hay semejante á ti, ni hay Dios sino tú, según todas las cosas que hemos oído con nuestros oídos. [^20] ¿Y qué gente hay en la tierra como tu pueblo Israel, cuyo Dios fuese y se redimiera un pueblo, para hacerte nombre con grandezas y maravillas, echando las gentes de delante de tu pueblo, que tú rescataste de Egipto? [^21] Tú has constituído á tu pueblo Israel por pueblo tuyo para siempre; y tú, Jehová, has venido á ser su Dios. [^22] Ahora pues, Jehová, la palabra que has hablado acerca de tu siervo y de su casa, sea firme para siempre, y haz como has dicho. [^23] Permanezca pues, y sea engrandecido tu nombre para siempre, á fin de que se diga: Jehová de los ejércitos, Dios de Israel, es Dios para Israel. Y sea la casa de tu siervo David firme delante de ti. [^24] Porque tú, Dios mío, revelaste al oído á tu siervo que le has de edificar casa; por eso ha hallado tu siervo motivo de orar delante de ti. [^25] Ahora pues, Jehová, tú eres el Dios que has hablado de tu siervo este bien; [^26] Y ahora has querido bendecir la casa de tu siervo, para que permanezca perpetuamente delante de ti: porque tú, Jehová, la has bendecido, y será bendita para siempre. [^27] 

[[1 Chronicles - 16|<--]] 1 Chronicles - 17 [[1 Chronicles - 18|-->]]

---
# Notes
