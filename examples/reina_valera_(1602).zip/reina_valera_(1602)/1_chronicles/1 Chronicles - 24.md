---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 24 - Reina Valera (1602)"
---
[[1 Chronicles - 23|<--]] 1 Chronicles - 24 [[1 Chronicles - 25|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Chronicles]]

# 1 Chronicles - 24

TAMBIÉN los hijos de Aarón tuvieron sus repartimientos. Los hijos de Aarón: Nadab, Abiú, Eleazar é Ithamar. [^1] Mas Nadab, y Abiú murieron antes que su padre, y no tuvieron hijos: Eleazar é Ithamar tuvieron el sacerdocio. [^2] Y David los repartió, siendo Sadoc de los hijos de Eleazar, y Ahimelech de los hijos de Ithamar, por sus turnos en su ministerio. [^3] Y los hijos de Eleazar fueron hallados, cuanto á sus principales varones, muchos más que los hijos de Ithamar; y repartiéronlos así: De los hijos de Eleazar había dieciséis cabezas de familias paternas; y de los hijos de Ithamar por las familias de sus padres, ocho. [^4] Repartiéronlos pues por suerte los unos con los otros: porque de los hijos de Eleazar y de los hijos de Ithamar hubo príncipes del santuario, y príncipes de la casa de Dios. [^5] Y Semeías escriba, hijo de Nathanael, de los Levitas, escribiólos delante del rey y de los príncipes, y delante de Sadoc el sacerdote, y de Ahimelech hijo de Abiathar, y de los príncipes de las familias de los sacerdotes y Levitas: y adscribían una familia á Eleazar, y á Ithamar otra. [^6] Y la primera suerte salió por Joiarib, la segunda por Jedaía; [^7] La tercera por Harim, la cuarta por Seorim; [^8] La quinta por Malchîas, la sexta por Miamim; [^9] La séptima por Cos, la octava por Abías; [^10] La nona por Jesua, la décima por Sechânía; [^11] La undécima por Eliasib, la duodécima por Jacim; [^12] La décimatercia por Uppa, la décimacuarta por Isebeab; [^13] La décimaquinta por Bilga, la décimasexta por Immer; [^14] La décimaséptima por Hezir, la décimaoctava por Aphses; [^15] La décimanona por Pethaía, la vigésima por Hezeciel; [^16] La vigésimaprima por Jachim, la vigésimasegunda por Hamul; [^17] La vigésimatercia por Delaía, la vigésimacuarta por Maazía. [^18] Estos fueron contados en su ministerio, para que entrasen en la casa de Jehová, conforme á su ordenanza, bajo el mando de Aarón su padre, de la manera que le había mandado Jehová el Dios de Israel. [^19] Y de los hijos de Leví que quedaron: Subael, de los hijos de Amram; y de los hijos de Subael, Jehedías. [^20] Y de los hijos de Rehabía, Isias el principal. [^21] De los Ishareos, Selemoth; é hijo de Selemoth, Jath. [^22] Y de los hijos de Hebrón; Jeria el primero, el segundo Amarías, el tercero Jahaziel, el cuarto Jecamán. [^23] Hijo de Uzziel, Michâ; é hijo de Michâ, Samir. [^24] Hermano de Michâ, Isía; é hijo de Isía, Zachârías. [^25] Los hijos de Merari: Mahali y Musi; hijo de Jaazia, Benno. [^26] Los hijos de Merari por Jaazia: Benno, y Soam, Zachûr é Ibri. [^27] Y de Mahali, Eleazar, el cual no tuvo hijos. [^28] Hijo de Cis, Jerameel. [^29] Los hijos de Musi: Maheli, Eder y Jerimoth. Estos fueron los hijos de los Levitas conforme á las casas de sus familias. [^30] Estos también echaron suertes, como sus hermanos los hijos de Aarón, delante del rey David, y de Sadoc y de Ahimelech, y de los príncipes de las familias de los sacerdotes y Levitas: el principal de los padres igualmente que el menor de sus hermanos. [^31] 

[[1 Chronicles - 23|<--]] 1 Chronicles - 24 [[1 Chronicles - 25|-->]]

---
# Notes
