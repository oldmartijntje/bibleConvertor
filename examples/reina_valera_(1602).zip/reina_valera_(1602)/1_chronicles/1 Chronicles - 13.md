---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 13 - Reina Valera (1602)"
---
[[1 Chronicles - 12|<--]] 1 Chronicles - 13 [[1 Chronicles - 14|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Chronicles]]

# 1 Chronicles - 13

ENTONCES David tomó consejo con los capitanes de millares y de cientos, y con todos los jefes. [^1] Y dijo David á todo el congreso de Israel: Si os parece bien y de Jehová nuestro Dios, enviaremos á todas partes á llamar nuestros hermanos que han quedado en todas las tierras de Israel, y á los sacerdotes y Levitas que están con ellos en sus ciudades y ejidos que se junten con nosotros; [^2] Y traigamos el arca de nuestro Dios á nosotros, porque desde el tiempo de Saúl no hemos hecho caso de ella. [^3] Y dijo todo el congreso que se hiciese así, porque la cosa parecía bien á todo el pueblo. [^4] Entonces juntó David á todo Israel, desde Sihor de Egipto hasta entrar en Hamath, para que trajesen el arca de Dios de Chîriath-jearim. [^5] Y subió David con todo Israel á Baala de Chîriath-jearim, que es en Judá, para pasar de allí el arca de Jehová Dios que habita entre los querubines, sobre la cual su nombre es invocado. [^6] Y lleváronse el arca de Dios de la casa de Abinadab en un carro nuevo; y Uzza y su hermano guiaban el carro. [^7] Y David y todo Israel hacían alegrías delante de Dios con todas sus fuerzas, con canciones, arpas, salterios, tamboriles, címbalos y trompetas. [^8] Y como llegaron á la era de Chidón, Uzza extendió su mano al arca para tenerla, porque los bueyes se desmandaban. [^9] Y el furor de Jehová se encendió contra Uzza, é hiriólo, porque había extendido su mano al arca: y murió allí delante de Dios. [^10] Y David tuvo pesar, porque Jehová había hecho rotura en Uzza; por lo que llamó aquel lugar Pérez-uzza, hasta hoy. [^11] Y David temió á Dios aquel día, y dijo: ¿Cómo he de traer á mi casa el arca de Dios? [^12] Y no trajo David el arca á su casa en la ciudad de David, sino llevóla á casa de Obed-edom Getheo. [^13] Y el arca de Dios estuvo en casa de Obed-edom, en su casa, tres meses: y bendijo Jehová la casa de Obed-edom, y todas las cosas que tenía. [^14] 

[[1 Chronicles - 12|<--]] 1 Chronicles - 13 [[1 Chronicles - 14|-->]]

---
# Notes
