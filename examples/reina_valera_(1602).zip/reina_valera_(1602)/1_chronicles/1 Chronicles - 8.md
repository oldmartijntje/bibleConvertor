---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 8 - Reina Valera (1602)"
---
[[1 Chronicles - 7|<--]] 1 Chronicles - 8 [[1 Chronicles - 9|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Chronicles]]

# 1 Chronicles - 8

BENJAMIN engendró á Bela su primogénito, Asbel el segundo, Ara el tercero, [^1] Noha el cuarto, y Rapha el quinto. [^2] Y los hijos de Bela fueron Addar, Gera, Abiud, [^3] Abisua, Naamán, Ahoa, [^4] Y Gera, Sephuphim, y Huram. [^5] Y estos son los hijos de Ehud, estos las cabezas de padres que habitaron en Gabaa, y fueron trasportados á Manahath: [^6] Es á saber: Naamán, Achîas, y Gera: éste los trasportó, y engendró á Uzza, y á Ahihud. [^7] Y Saharaim engendró hijos en la provincia de Moab, después que dejó á Husim y á Baara que eran sus mujeres. [^8] Engendró pues de Chôdes su mujer, á Jobab, Sibias, Mesa, Malchâm, [^9] Jeus, Sochîas, y Mirma. Estos son sus hijos, cabezas de familias. [^10] Mas de Husim engendró á Abitob, y á Elphaal. [^11] Y los hijos de Elphaal: Heber, Misam, y Semeb, (el cual edificó á Ono, y á Loth con sus aldeas,) [^12] Berías también, y Sema, que fueron las cabezas de las familias de los moradores de Ajalón, los cuales echaron á los moradores de Gath; [^13] Y Ahío, Sasac, Jeremoth; [^14] Zebadías, Arad, Heder; [^15] Michâel, Ispha, y Joa, hijos de Berías; [^16] Y Zebadías, Mesullam, Hizchî, Heber; [^17] Ismari, Izlia, y Jobab, hijos de Elphaal. [^18] Y Jacim, Zichri, Zabdi; [^19] Elioenai, Silithai, Eliel; [^20] Adaías, Baraías, y Simrath, hijos de Simi; [^21] E Isphán, Heber, Eliel; [^22] Adón, Zichri, Hanán; [^23] Hananía, Belam, Anathothías; [^24] Iphdaías, y Peniel, hijos de Sasac; [^25] Y Samseri, Seharías, Atalía; [^26] Jaarsías, Elías, Zichri, hijos de Jeroham. [^27] Estos fueron jefes principales de familias por sus linajes, y habitaron en Jerusalem. [^28] Y en Gabaón habitaron Abiga-baón, la mujer del cual se llamó Maachâ: [^29] Y su hijo primogénito, Abdón, luego Sur, Chîs, Baal, Nadab, [^30] Gedor, Ahíe, y Zechêr. [^31] Y Micloth engendró á Simea. Estos también habitaron con sus hermanos en Jerusalem, enfrente de ellos. [^32] Y Ner engendró á Cis, y Cis engendró á Saúl, y Saúl engendró á Jonathán, Malchî-súa, Abinadab, y Esbaal. [^33] Hijo de Jonathán fué Merib-baal, y Merib-baal engendró á Michâ. [^34] Los hijos de Michâ: Phitón, Melech, Thaarea y Ahaz. [^35] Y Ahaz engendró á Joadda; y Joadda engendró á Elemeth, y á Azmaveth, y á Zimri; y Zimri engendró á Mosa; [^36] Y Mosa engendró á Bina, hijo del cual fué Rapha, hijo del cual fué Elasa, cuyo hijo fué Asel. [^37] Y los hijos de Asel fueron seis, cuyos nombres son Azricam, Bochru, Ismael, Searías, Obadías, y Hanán: todos estos fueron hijos de Asel. [^38] Y los hijos de Esec su hermano: Ulam su primogénito, Jehus el segundo, Elipheleth el tercero. [^39] Y fueron los hijos de Ulam hombres valientes y vigorosos, flecheros diestros, los cuales tuvieron muchos hijos y nietos, ciento y cincuenta. Todos estos fueron de los hijos de Benjamín. [^40] 

[[1 Chronicles - 7|<--]] 1 Chronicles - 8 [[1 Chronicles - 9|-->]]

---
# Notes
