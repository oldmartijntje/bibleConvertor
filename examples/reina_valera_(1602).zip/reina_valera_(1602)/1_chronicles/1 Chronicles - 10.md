---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 10 - Reina Valera (1602)"
---
[[1 Chronicles - 9|<--]] 1 Chronicles - 10 [[1 Chronicles - 11|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Chronicles]]

# 1 Chronicles - 10

LOS Filisteos pelearon con Israel; y huyeron delante de ellos los Israelitas, y cayeron heridos en el monte de Gilboa. [^1] Y los Filisteos siguieron á Saúl y á sus hijos; y mataron los Filisteos á Jonathán, y á Abinadab, y á Malchîsua, hijos de Saúl. [^2] Y agravóse la batalla sobre Saúl, y le alcanzaron los flecheros, y fué de los flecheros herido. [^3] Entonces dijo Saúl á su escudero: Saca tu espada, y pásame con ella, porque no vengan estos incircuncisos, y hagan escarnio de mí; mas su escudero no quiso, porque tenía gran miedo. Entonces Saúl tomó la espada, y echóse sobre ella. [^4] Y como su escudero vió á Saúl muerto, él también se echó sobre su espada, y matóse. [^5] Así murió Saúl, y sus tres hijos; y toda su casa murió juntamente con él. [^6] Y viendo todos los de Israel que habitaban en el valle, que habían huído, y que Saúl y sus hijos eran muertos, dejaron sus ciudades, y huyeron: y vinieron los Filisteos, y habitaron en ellas. [^7] Y fué que viniendo el día siguiente los Filisteos á despojar los muertos, hallaron á Saúl y á sus hijos tendidos en el monte de Gilboa. [^8] Y luego que le hubieron desnudado, tomaron su cabeza y sus armas, y enviáronlo todo á la tierra de los Filisteos por todas partes, para que fuese denunciado á sus ídolos y al pueblo. [^9] Y pusieron sus armas en el templo de su dios, y colgaron la cabeza en el templo de Dagón. [^10] Y oyendo todos los de Jabes de Galaad lo que los Filisteos habían hecho de Saúl, [^11] Levantáronse todos los hombres valientes, y tomaron el cuerpo de Saúl, y los cuerpos de sus hijos, y trajéronlos á Jabes; y enterraron sus huesos debajo del alcornoque en Jabes, y ayunaron siete días. [^12] Así murió Saúl por su rebelión con que prevaricó contra Jehová, contra la palabra de Jehová, la cual no guardó; y porque consultó al pythón, preguntándo le, [^13] Y no consultó á Jehová: por esta causa lo mató, y traspasó el reino á David, hijo de Isaí. [^14] 

[[1 Chronicles - 9|<--]] 1 Chronicles - 10 [[1 Chronicles - 11|-->]]

---
# Notes
