---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 22 - Reina Valera (1602)"
---
[[1 Chronicles - 21|<--]] 1 Chronicles - 22 [[1 Chronicles - 23|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Chronicles]]

# 1 Chronicles - 22

Y DIJO David: Esta es la casa de Jehová Dios, y este es el altar del holocausto para Israel. [^1] Después mandó David que se juntasen los extranjeros que estaban en la tierra de Israel, y señaló de ellos canteros que labrasen piedras para edificar la casa de Dios. [^2] Asimismo aparejó David mucho hierro para la clavazón de las puertas, y para las junturas; y mucho metal sin peso, y madera de cedro sin cuenta. [^3] Porque los Sidonios y Tirios habían traído á David madera de cedro innumerable. [^4] Y dijo David: Salomón mi hijo es muchacho y tierno, y la casa que se ha de edificar á Jehová ha de ser magnífica por excelencia, para nombre y honra en todas las tierras; ahora pues yo le aparejaré lo necesario. Y preparó David antes de su muerte en grande abundancia. [^5] Llamó entonces David á Salomón su hijo, y mandóle que edificase casa á Jehová Dios de Israel. [^6] Y dijo David á Salomón: Hijo mío, en mi corazón tuve el edificar templo al nombre de Jehová mi Dios. [^7] Mas vino á mí palabra de Jehová, diciendo: Tú has derramado mucha sangre, y has traído grandes guerras: no edificarás casa á mi nombre, porque has derramado mucha sangre en la tierra delante de mí: [^8] He aquí, un hijo te nacerá, el cual será varón de reposo, porque yo le daré quietud de todos sus enemigos en derredor; por tanto su nombre será Salomón; y yo daré paz y reposo sobre Israel en sus días: [^9] El edificará casa á mi nombre, y él me será á mí por hijo, y yo le seré por padre; y afirmaré el trono de su reino sobre Israel para siempre. [^10] Ahora pues, hijo mío, sea contigo Jehová, y seas prosperado, y edifiques casa á Jehová tu Dios, como él ha dicho de ti. [^11] Y Jehová te dé entendimiento y prudencia, y él te dé mandamientos para Israel; y que tú guardes la ley de Jehová tu Dios. [^12] Entonces serás prosperado, si cuidares de poner por obra los estatutos y derechos que Jehová mandó á Moisés para Israel. Esfuérzate pues, y cobra ánimo; no temas, ni desmayes. [^13] He aquí, yo en mi estrechez he prevenido para la casa de Jehová cien mil talentos de oro, y un millar de millares de talentos de plata: no tiene peso el metal ni el hierro, porque es mucho. Asimismo he aprestado madera y piedra, á lo cual tú añadirás. [^14] Tú tienes contigo muchos oficiales, canteros, albañiles, y carpinteros, y todo hombre experto en toda obra. [^15] Del oro, de la plata, del metal, y del hierro, no hay número. Levántate pues, y á la obra; que Jehová será contigo. [^16] Asimismo mandó David á todos los principales de Israel que diesen ayuda á Salomón su hijo, diciendo: [^17] ¿No es con vosotros Jehová vuestro Dios, el cual os ha dado quietud de todas partes? porque él ha entregado en mi mano los moradores de la tierra, y la tierra ha sido sujetada delante de Jehová, y delante de su pueblo. [^18] Poned, pues, ahora vuestros corazones y vuestros ánimos en buscar á Jehová vuestro Dios; y levantaos, y edificad el santuario del Dios Jehová, para traer el arca del pacto de Jehová, y lo santos vasos de Dios, á la casa edificada al nombre de Jehová. [^19] 

[[1 Chronicles - 21|<--]] 1 Chronicles - 22 [[1 Chronicles - 23|-->]]

---
# Notes
