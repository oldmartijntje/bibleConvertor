---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 15 - Reina Valera (1602)"
---
[[1 Chronicles - 14|<--]] 1 Chronicles - 15 [[1 Chronicles - 16|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Chronicles]]

# 1 Chronicles - 15

HIZO también casas para sí en la ciudad de David, y labró un lugar para el arca de Dios, y tendióle una tienda. [^1] Entonces dijo David: El arca de Dios no debe ser traída sino por los Levitas; porque á ellos ha elegido Jehová para que lleven el arca de Jehová, y le sirvan perpetuamente. [^2] Y juntó David á todo Israel en Jerusalem, para que pasasen el arca de Jehová á su lugar, el cual le había él preparado. [^3] Juntó también David á los hijos de Aarón y á los Levitas: [^4] De los hijos de Coath, Uriel el principal, y sus hermanos, ciento y veinte; [^5] De los hijos de Merari, Asaías el principal, y sus hermanos, doscientos y viente; [^6] De los hijos de Gersón, Joel el principal, y sus hermanos, ciento y treinta; [^7] De los hijos de Elisaphán, Semeías el principal, y sus hermanos, docientos; [^8] De los hijos de Hebrón, Eliel el principal, y sus hermanos, ochenta; [^9] De los hijos de Uzziel, Amidadab el principal, y sus hermanos, ciento y doce. [^10] Y llamó David á Sadoc y á Abiathar, sacerdotes, y á los Levitas, Uriel, Asaías, Joel, Semeías, Eliel, y Aminadab; [^11] Y díjoles: Vosotros que sois los principales de padres entre los Levitas, santificaos, vosotros y vuestros hermanos, y pasad el arca de Jehová Dios de Israel al lugar que le he preparado; [^12] Pues por no haberlo hecho así vosotros la primera vez, Jehová nuestro Dios hizo en nosotros rotura, por cuanto no le buscamos según la ordenanza. [^13] Así los sacerdotes y los Levitas se santificaron para traer el arca de Jehová Dios de Israel. [^14] Y los hijos de los Levitos trajeron el arca de Dios puesta sobre sus hombros en las barras, como lo había mandado Moisés conforme á la palabra de Jehová. [^15] Asimismo dijo David á los principales de los Levitas, que constituyesen de sus hermanos cantores, con instrumentos de música, con salterios, y arpas, y címbalos, que resonasen, y alzasen la voz con alegría. [^16] Y los Levitas constituyeron á Hemán hijo de Joel; y de sus hermanos, á Asaph hijo de Berechîas; y de los hijos de Merari y de sus hermanos, á Ethán hijo de Cusaías; [^17] Y con ellos á sus hermanos del segundo orden, á Zachârías, Ben y Jaaziel, Semiramoth, Jehiel, Unni, Eliab, Benaías, Maasías, y Mathithías, Eliphelehu, Micnías, Obed-edom, y Jehiel, los porteros. [^18] Así Hemán, Asaph, y Ethán, que eran cantores, sonaban con címbalos de metal. [^19] Y Zachârías, Jaaziel, Semiramoth, Jehiel, Unni, Eliab, Maasías, y Benaías, con salterios sobre Alamoth. [^20] Y Mathithías, Eliphelehu, Micnías, Obed-edom, Jehiel, y Azazías, cantaban con arpas en la octava sobresaliendo. [^21] Y Chênanías, principal de los Levitas, estaba para la entonación; pues él presidía en el canto, porque era entendido. [^22] Y Berechîas y Elcana eran porteros del arca. [^23] Y Sebanías, Josaphat, Nathanael, Amasai, Zachârías, Benaías, y Eliezer, sacerdotes, tocaban las trompetas delante del arca de Dios: Obed-edom y Jehías eran también porteros del arca. [^24] David pues y los ancianos de Israel, y los capitanes de millares, fueron á traer el arca del pacto de Jehová, de casa de Obed-edom, con alegría. [^25] Y ayudando Dios á los Levitas que llevaban el arca del pacto de Jehová, sacrificaban siete novillos y siete carneros. [^26] Y David iba vestido de lino fino y también todos los Levitas que llevaban el arca, y asimismo los cantores; y Chênanías era maestro de canto entre los cantores. Llevaba también David sobre sí un ephod de lino. [^27] De esta manera llevaba todo Israel el arca del pacto de Jehová, con júbilo y sonido de bocinas, y trompetas, y címbalos, y al son de salterios y arpas. [^28] Y como el arca del pacto de Jehová llegó á la ciudad de David, Michâl, hija de Saúl, mirando por una ventana, vió al rey David que saltaba y bailaba; y menospreciólo en su corazón. [^29] 

[[1 Chronicles - 14|<--]] 1 Chronicles - 15 [[1 Chronicles - 16|-->]]

---
# Notes
