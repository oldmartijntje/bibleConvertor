---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 3 - Reina Valera (1602)"
---
[[1 Chronicles - 2|<--]] 1 Chronicles - 3 [[1 Chronicles - 4|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Chronicles]]

# 1 Chronicles - 3

ESTOS son los hijos de David, que le nacieron en Hebrón: Amnón el primogénito, de Achînoam Jezreelita; el segundo Daniel, de Abigail de Carmelo; [^1] El tercero, Absalom, hijo de Maachâ hija de Talmai rey de Gesur; el cuarto, Adonías hijo de Aggith; [^2] El quinto, Sephatías, de Abithal; el sexto, Itream, de Egla su mujer. [^3] Estos seis le nacieron en Hebrón, donde reinó siete años y seis meses: y en Jerusalem reinó treinta y tres años. [^4] Estos cuatro le nacieron en Jerusalem: Simma, Sobab, Nathán, y Salomón, de Beth-sua hija de Ammiel. [^5] Y otros nueve: Ibaar, Elisama, y Eliphelet, [^6] Noga, Nepheg, y Japhia. [^7] Elisama, Eliada, y Eliphelet. [^8] Todos estos fueron los hijos de David, sin los hijos de las concubinas. Y Thamar fué hermana de ellos. [^9] Hijo de Salomón fué Roboam, cuyo hijo fué Abía, del cual fué hijo Asa, cuyo hijo fué Josaphat; [^10] De quien fué hijo Joram, cuyo hijo fué Ochôzias, hijo del cual fué Joas; [^11] Del cual fué hijo Amasías, cuyo hijo fué Azarías, é hijo de éste Jotham; [^12] E hijo del cual fué Achâz, del que fué hijo Ezechîas, cuyo hijo fué Manasés; [^13] Del cual fué hijo Amón, cuyo hijo fué Josías. [^14] Y los hijos de Josías: Johanán su primogénito, el segundo Joacim, el tercero Sedecías, el cuarto Sallum. [^15] Los hijos de Joacim: Jechônías su hijo, hijo del cual fué Sedecías. [^16] Y los hijos de Jechônías: Asir, Salathiel, [^17] Mechiram, Pedaía, Seneaser, y Jecamía, Hosama, y Nedabía. [^18] Y los hijos de Pedaía: Zorobabel, y Simi. Y los hijos de Zorobabel: Mesullam, Hananías, y Selomith su hermana. [^19] Y de Mesullam: Hasuba, Ohel, y Berechîas, Hasadía, y Jusabhesed; cinco en todos. [^20] Los hijos de Hananías: Pelatías, y Jesaías, hijo de Rephaías, hijo de Arnán, hijo de Obdías, hijo de Sechânías. [^21] Hijo de Sechânías: Hattus, Igheal, Barias, Nearías, y Saphat; seis. [^22] Los hijos de Nearías fueron estos tres: Elioenai, Ezechîas, y Azricam. [^23] Los hijos de Elioenai fueron estos siete: Odavias, Eliasib, Pelaías, Accub, Johanán, Dalaías, y Anani. [^24] 

[[1 Chronicles - 2|<--]] 1 Chronicles - 3 [[1 Chronicles - 4|-->]]

---
# Notes
