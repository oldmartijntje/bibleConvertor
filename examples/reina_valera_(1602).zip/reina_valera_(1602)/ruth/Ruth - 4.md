---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/ruth"
  - "#bible/testament/old"
aliases:
  - "Ruth - 4 - Reina Valera (1602)"
---
[[Ruth - 3|<--]] Ruth - 4

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Ruth]]

# Ruth - 4

Y BOOZ subió á la puerta y sentóse allí: y he aquí pasaba aquel pariente del cual había Booz hablado, y díjole: Eh, fulano, ven acá y siéntate. Y él vino, y sentóse. [^1] Entonces él tomó diez varones de los ancianos de la ciudad, y dijo: Sentaos aquí. Y ellos se sentaron. [^2] Luego dijo al pariente: Noemi, que ha vuelto del campo de Moab, vende una parte de las tierras que tuvo nuestro hermano Elimelech; [^3] Y yo decidí hacértelo saber, y decirte que la tomes delante de los que están aquí sentados, y delante de los ancianos de mi pueblo. Si hubieres de redimir, redime; y si no quisieres redimir, decláramelo para que yo lo sepa: porque no hay otro que redima sino tú, y yo después de ti. Y él respondió: Yo redimiré. [^4] Entonces replicó Booz: El mismo día que tomares las tierras de mano de Noemi, has de tomar también á Ruth Moabita, mujer del difunto, para que suscites el nombre del muerto sobre su posesión. [^5] Y respondió el pariente: No puedo redimir por mi parte, porque echaría á perder mi heredad: redime tú usando de mi derecho, porque yo no podré redimir. [^6] Había ya de largo tiempo esta costumbre en Israel en la redención ó contrato, que para la confirmación de cualquier negocio, el uno se quitaba el zapato y lo daba á su compañero: y este era el testimonio en Israel. [^7] Entonces el pariente dijo á Booz: Tómalo tú. Y descalzó su zapato. [^8] Y Booz dijo á los ancianos y á todo el pueblo: Vosotros sois hoy testigos de que tomo todas las cosas que fueron de Elimelech, y todo lo que fué de Chelión y de Mahalón, de mano de Noemi. [^9] Y que también tomo por mi mujer á Ruth Moabita, mujer de Mahalón, para suscitar el nombre del difunto sobre su heredad, para que el nombre del muerto no se borre de entre sus hermanos y de la puerta de su lugar. Vosotros sois hoy testigos. [^10] Y dijeron todos los del pueblo que estaban á la puerta con los ancianos: Testigos somos. Jehová haga á la mujer que entra en tu casa como á Rachêl y á Lea, las cuales dos edificaron la casa de Israel; y tú seas ilustre en Ephrata, y tengas nombradía en Beth-lehem; [^11] Y de la simiente que Jehová te diere de aquesta moza, sea tu casa como la casa de Phares, al que parió Thamar á Judá. [^12] Booz pues tomó á Ruth, y ella fué su mujer; y luego que entró á ella, Jehová le dió que concibiese y pariese un hijo. [^13] Y las mujeres decían á Noemi: Loado sea Jehová, que hizo que no te faltase hoy pariente, cuyo nombre será nombrado en Israel. [^14] El cual será restaurador de tu alma, y el que sustentará tu vejez; pues que tu nuera, la cual te ama y te vale más que siete hijos, le ha parido. [^15] Y tomando Noemi el hijo, púsolo en su regazo, y fuéle su ama. [^16] Y las vecinas diciendo, á Noemi ha nacido un hijo, le pusieron nombre; y llamáronle Obed. Este es padre de Isaí, padre de David. [^17] Y estas son las generaciones de Phares: Phares engendró á Hesrón; [^18] Y Hesrón engendró á Ram, y Ram engendró á Aminadab; [^19] Y Aminadab engendró á Nahasón, y Nahasón engendró á Salmón; [^20] Y Salmón engendró á Booz, y Booz engendró á Obed; [^21] Y Obed engendró á Isaí, é Isaí engendró á David. [^22] 

[[Ruth - 3|<--]] Ruth - 4

---
# Notes
