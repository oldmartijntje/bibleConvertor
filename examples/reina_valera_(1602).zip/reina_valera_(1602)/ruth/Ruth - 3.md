---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/ruth"
  - "#bible/testament/old"
aliases:
  - "Ruth - 3 - Reina Valera (1602)"
---
[[Ruth - 2|<--]] Ruth - 3 [[Ruth - 4|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Ruth]]

# Ruth - 3

Y DIJOLE su suegra Noemi: Hija mía, ¿no te tengo de buscar descanso, que te sea bueno? [^1] ¿No es Booz nuestro pariente, con cuyas mozas tú has estado? He aquí que él avienta esta noche la parva de las cebadas. [^2] Te lavarás pues, y te ungirás, y vistiéndote tus vestidos, pasarás á la era; mas no te darás á conocer al varón hasta que él haya acabado de comer y de beber. [^3] Y cuando él se acostare, repara tú el lugar donde él se acostará, é irás, y descubrirás los pies, y te acostarás allí; y él te dirá lo que hayas de hacer. [^4] Y le respondió: Haré todo lo que tú me mandares. [^5] Descendió pues á la era, é hizo todo lo que su suegra le había mandado. [^6] Y como Booz hubo comido y bebido, y su corazón estuvo contento, retiróse á dormir á un lado del montón. Entonces ella vino calladamente, y descubrió los pies, y acostóse. [^7] Y aconteció, que á la media noche se estremeció aquel hombre, y palpó: y he aquí, la mujer que estaba acostada á sus pies. [^8] Entonces él dijo: ¿Quién eres? Y ella respondió: Yo soy Ruth tu sierva: extiende el borde de tu capa sobre tu sierva, por cuanto eres pariente cercano. [^9] Y él dijo: Bendita seas tú de Jehová, hija mía; que has hecho mejor tu postrera gracia que la primera, no yendo tras los mancebos, sean pobres ó ricos. [^10] Ahora pues, no temas, hija mía: yo haré contigo lo que tú dijeres, pues que toda la puerta de mi pueblo sabe que eres mujer virtuosa. [^11] Y ahora, aunque es cierto que yo soy pariente cercano, con todo eso hay pariente más cercano que yo. [^12] Reposa esta noche, y cuando sea de día, si él te redimiere, bien, redímate; mas si él no te quisiere redimir, yo te redimiré, vive Jehová. Descansa pues hasta la mañana. [^13] Y después que reposó á sus pies hasta la mañana, levantóse, antes que nadie pudiese conocer á otro. Y él dijo: No se sepa que haya venido mujer á la era. [^14] Después le dijo: Llega el lienzo que traes sobre ti, y ten de él. Y teniéndolo ella, él midió seis medidas de cebada, y púsoselas á cuestas: y vínose ella á la ciudad. [^15] Así que vino á su suegra, ésta le dijo: ¿Qué pues, hija mía? Y declaróle ella todo lo que con aquel varón le había acontecido. [^16] Y dijo: Estas seis medidas de cebada me dió, diciéndome: Porque no vayas vacía á tu suegra. [^17] Entonces Noemi dijo: Reposa, hija mía, hasta que sepas como cae la cosa: porque aquel hombre no parará hasta que hoy concluya el negocio. [^18] 

[[Ruth - 2|<--]] Ruth - 3 [[Ruth - 4|-->]]

---
# Notes
