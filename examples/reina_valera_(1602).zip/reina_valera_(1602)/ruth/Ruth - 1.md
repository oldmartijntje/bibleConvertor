---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/ruth"
  - "#bible/testament/old"
aliases:
  - "Ruth - 1 - Reina Valera (1602)"
---
Ruth - 1 [[Ruth - 2|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Ruth]]

# Ruth - 1

Y ACONTECIO en los días que gobernaban los jueces, que hubo hambre en la tierra. Y un varón de Beth-lehem de Judá, fué á peregrinar en los campos de Moab, él y su mujer, y dos hijos suyos. [^1] El nombre de aquel varón era Elimelech, y el de su mujer Noemi; y los nombres de sus dos hijos eran, Mahalón y Chelión, Ephrateos de Beth-lehem de Judá. Llegaron pues á los campos de Moab, y asentaron allí. [^2] Y murió Elimelech, marido de Noemi, y quedó ella con sus dos hijos; [^3] Los cuales tomaron para sí mujeres de Moab, el nombre de la una Orpha, y el nombre de la otra Ruth; y habitaron allí unos diez años. [^4] Y murieron también los dos, Mahalón y Chelión, quedando así la mujer desamparada de sus dos hijos y de su marido. [^5] Entonces se levantó con sus nueras, y volvióse de los campos de Moab: porque oyó en el campo de Moab que Jehová había visitado á su pueblo para darles pan. [^6] Salió pues del lugar donde había estado, y con ella sus dos nueras, y comenzaron á caminar para volverse á la tierra de Judá. [^7] Y Noemi dijo á sus dos nueras: Andad, volveos cada una á la casa de su madre: Jehová haga con vosotras misericordia, como la habéis hecho con los muertos y conmigo. [^8] Déos Jehová que halléis descanso, cada una en casa de su marido: besólas luego, y ellas lloraron á voz en grito. [^9] Y dijéronle: Ciertamente nosotras volveremos contigo á tu pueblo. [^10] Y Noemi respondió: Volveos, hijas mías: ¿para qué habéis de ir conmigo? ¿tengo yo más hijos en el vientre, que puedan ser vuestros maridos? [^11] Volveos, hijas mías, é idos; que yo ya soy vieja para ser para varón. Y aunque dijese: Esperanza tengo; y esta noche fuese con varón, y aun pariese hijos; [^12] ¿Habíais vosotras de esperarlos hasta que fuesen grandes? ¿habías vosotras de quedaros sin casar por amor de ellos? No, hijas mías; que mayor amargura tengo yo que vosotras, pues la mano de Jehová ha salido contra mí. [^13] Mas ellas alzando otra vez su voz, lloraron: y Orpha besó á su suegra, mas Ruth se quedó con ella. [^14] Y Noemi dijo: He aquí tu cuñada se ha vuelto á su pueblo y á sus dioses; vuélvete tú tras ella. [^15] Y Ruth respondió: No me ruegues que te deje, y que me aparte de ti: porque donde quiera que tú fueres, iré yo; y donde quiera que vivieres, viviré. Tu pueblo será mi pueblo, y tu Dios mi Dios. [^16] Donde tú murieres, moriré yo, y allí seré sepultada: así me haga Jehová, y así me dé, que sólo la muerte hará separación entre mí y ti. [^17] Y viendo Noemi que estaba tan resuelta á ir con ella, dejó de hablarle. [^18] Anduvieron pues ellas dos hasta que llegaron á Beth-lehem: y aconteció que entrando en Beth-lehem, toda la ciudad se conmovió por razón de ellas, y decían: ¿No es ésta Noemi? [^19] Y ella les respondiá: No me llaméis Noemi, sino llamadme Mara: porque en grande amargura me ha puesto el Todopoderoso. [^20] Yo me fuí llena, mas vacía me ha vuelto Jehová. ¿Por qué me llamaréis Noemi, ya que Jehová ha dado testimonio contra mí, y el Todopoderoso me ha afligido? [^21] Así volvió Noemi y Ruth Moabita su nuera con ella; volvió de los campos de Moab, y llegaron á Beth-lehem en el principio de la siega de las cebadas. [^22] 

Ruth - 1 [[Ruth - 2|-->]]

---
# Notes
