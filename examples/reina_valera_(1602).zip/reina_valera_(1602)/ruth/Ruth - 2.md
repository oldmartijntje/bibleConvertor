---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/ruth"
  - "#bible/testament/old"
aliases:
  - "Ruth - 2 - Reina Valera (1602)"
---
[[Ruth - 1|<--]] Ruth - 2 [[Ruth - 3|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Ruth]]

# Ruth - 2

Y TENIA Noemi un pariente de su marido, varón poderoso y de hecho, de la familia de Elimelech, el cual se llamaba Booz. [^1] Y Ruth la Moabita dijo á Noemi: Ruégote que me dejes ir al campo, y cogeré espigas en pos de aquel á cuyos ojos hallare gracia. Y ella le respondió: Ve, hija mía. [^2] Fué pues, y llegando, espigó en el campo en pos de los segadores: y aconteció por ventura, que la suerte del campo era de Booz, el cual era de la parentela de Elimelech. [^3] Y he aquí que Booz vino de Beth-lehem, y dijo á los segadores: Jehová sea con vosotros. Y ellos respondieron: Jehová te bendiga. [^4] Y Booz dijo á su criado el sobrestante de los segadores: ¿Cúya es esta moza? [^5] Y el criado, sobrestante de los segadores, respondió y dijo: Es la moza de Moab, que volvió con Noemi de los campos de Moab; [^6] Y ha dicho: Ruégote que me dejes coger y juntar tras los segadores entre las gavillas: entró pues, y está desde por la mañana hasta ahora, menos un poco que se detuvo en casa. [^7] Entonces Booz dijo á Ruth: Oye, hija mía, no vayas á espigar á otro campo, ni pases de aquí: y aquí estarás con mis mozas. [^8] Mira bien el campo que segaren, y síguelas: porque yo he mandado á los mozos que no te toquen. Y si tuvieres sed, ve á los vasos, y bebe del agua que sacaren los mozos. [^9] Ella entonces bajando su rostro inclinóse á tierra, y díjole: ¿Por qué he hallado gracia en tus ojos para que tú me reconozcas, siendo yo extranjera? [^10] Y respondiendo Booz, díjole: Por cierto se me ha declarado todo lo que has hecho con tu suegra después de la muerte de tu marido, y que dejando á tu padre y á tu madre y la tierra donde naciste, has venido á pueblo que no conociste antes. [^11] Jehová galardone tu obra, y tu remuneración sea llena por Jehová Dios de Israel, que has venido para cubrirte debajo de sus alas. [^12] Y ella dijo: Señor mío, halle yo gracia delante de tus ojos; porque me has consolado, y porque has hablado al corazón de tu sierva, no siendo yo como una de tus criadas. [^13] Y Booz le dijo á la hora de comer: Allégate aquí, y come del pan, y moja tu bocado en el vinagre. Y sentóse ella junto á los segadores, y él le dió del potaje, y comió hasta que se hartó y le sobró. [^14] Levantóse luego para espigar. Y Booz mandó á sus criados, diciendo: Coja también espigas entre las gavillas, y no la avergoncéis; [^15] Antes echaréis á sabiendas de los manojos, y la dejaréis que coja, y no la reprendáis. [^16] Y espigó en el campo hasta la tarde, y desgranó lo que había cogido, y fué como un epha de cebada. [^17] Y tomólo, y vínose á la ciudad; y su suegra vió lo que había cogido. Sacó también luego lo que le había sobrado después de harta, y dióselo. [^18] Y díjole su suegra: ¿Dónde has espigado hoy? ¿y dónde has trabajado? bendito sea el que te ha reconocido. Y ella declaró á su suegra lo que le había acontecido con aquél, y dijo: El nombre del varón con quien hoy he trabajado es Booz. [^19] Y dijo Noemi á su nuera: Sea él bendito de Jehová, pues que no ha rehusado á los vivos la benevolencia que tuvo para con los finados. Díjole después Noemi: Nuestro pariente es aquel varón, y de nuestros redentores es. [^20] Y Ruth Moabita dijo: á más de esto me ha dicho: Júntate con mis criados, hasta que hayan acabado toda mi siega. [^21] Y Noemi respondió á Ruth su nuera: Mejor es, hija mía, que salgas con sus criadas, que no que te encuentren en otro campo. [^22] Estuvo pues junta con las mozas de Booz espigando, hasta que la siega de las cebadas y la de los trigos fué acabada; mas con su suegra habitó. [^23] 

[[Ruth - 1|<--]] Ruth - 2 [[Ruth - 3|-->]]

---
# Notes
