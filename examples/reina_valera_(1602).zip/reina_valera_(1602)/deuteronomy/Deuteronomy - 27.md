---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 27 - Reina Valera (1602)"
---
[[Deuteronomy - 26|<--]] Deuteronomy - 27 [[Deuteronomy - 28|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Deuteronomy]]

# Deuteronomy - 27

Y MANDO Moisés, con los ancianos de Israel, al pueblo, diciendo: Guardaréis todos los mandamientos que yo prescribo hoy. [^1] Y será que, el día que pasareis el Jordán á la tierra que Jehová tu Dios te da, te has de levantar piedras grandes, las cuales revocarás con cal: [^2] Y escribirás en ellas todas las palabras de esta ley, cuando hubieres pasado para entrar en la tierra que Jehová tu Dios te da, tierra que fluye leche y miel, como Jehová el Dios de tus padres te ha dicho. [^3] Será pues, cuando hubieres pasado el Jordán, que levantaréis estas piedras que yo os mando hoy, en el monte de Ebal, y las revocarás con cal: [^4] Y edificarás allí altar á Jehová tu Dios, altar de piedras: no alzarás sobre ellas hierro. [^5] De piedras enteras edificarás el altar de Jehová tu Dios; y ofrecerás sobre él holocausto á Jehová tu Dios; [^6] Y sacrificarás pacíficos, y comerás allí; y alegrarte has delante de Jehová tu Dios. [^7] Y escribirás en las piedras todas las palabras de esta ley muy claramente. [^8] Y Moisés, con los sacerdotes Levitas, habló á todo Israel, diciendo: Atiende y escucha, Israel: hoy eres hecho pueblo de Jehová tu Dios. [^9] Oirás pues la voz de Jehová tu Dios, y cumplirás sus mandamientos y sus estatutos, que yo te ordeno hoy. [^10] Y mandó Moisés al pueblo en aquel día, diciendo: [^11] Estos estarán sobre el monte de Gerizim para bendecir al pueblo, cuando hubiereis pasado el Jordán: Simeón, y Leví, y Judá, é Issachâr, y José y Benjamín. [^12] Y estos estarán para pronunciar la maldición en el de Ebal: Rubén, Gad, y Aser, y Zabulón, Dan, y Nephtalí. [^13] Y hablarán los Levitas, y dirán á todo varón de Israel en alta voz: [^14] Maldito el hombre que hiciere escultura ó imagen de fundición, abominación á Jehová, obra de mano de artífice, y la pusiere en oculto. Y todo el pueblo responderá y dirá: Amén. [^15] Maldito el que deshonrare á su padre ó á su madre. Y dirá todo el pueblo: Amén. [^16] Maldito el que redujere el término de su prójimo. Y dirá todo el pueblo: Amén. [^17] Maldito el que hiciere errar al ciego en el camino. Y dirá todo el pueblo: Amén. [^18] Maldito el que torciere el derecho del extranjero, del huérfano, y de la viuda. Y dirá todo el pueblo: Amén. [^19] Maldito el que se echare con la mujer de su padre; por cuanto descubrió el regazo de su padre. Y dirá todo el pueblo: Amén. [^20] Maldito el que tuviere parte con cualquiera bestia. Y dirá todo el pueblo: Amén. [^21] Maldito el que se echare con su hermana, hija de su padre, ó hija de su madre. Y dirá todo el pueblo: Amén. [^22] Maldito el que se echare con su suegra. Y dirá todo el pueblo: Amén. [^23] Maldito el que hiriere á su prójimo ocultamente. Y dirá todo el pueblo: Amén. [^24] Maldito el que recibiere don para herir de muerte al inocente. Y dirá todo el pueblo: Amén. [^25] Maldito el que no confirmare las palabras de esta ley para cumplirlas. Y dirá todo el pueblo: Amén. [^26] 

[[Deuteronomy - 26|<--]] Deuteronomy - 27 [[Deuteronomy - 28|-->]]

---
# Notes
