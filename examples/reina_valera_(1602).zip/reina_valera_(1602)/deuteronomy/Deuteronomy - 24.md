---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 24 - Reina Valera (1602)"
---
[[Deuteronomy - 23|<--]] Deuteronomy - 24 [[Deuteronomy - 25|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Deuteronomy]]

# Deuteronomy - 24

CUANDO alguno tomare mujer y se casare con ella, si no le agradare por haber hallado en ella alguna cosa torpe, le escribirá carta de repudio, y se la entregará en su mano, y despedirála de su casa. [^1] Y salida de su casa, podrá ir y casarse con otro hombre. [^2] Y si la aborreciere aqueste último, y le escribiere carta de repudio, y se la entregare en su mano, y la despidiere de su casa; ó si muriere el postrer hombre que la tomó para sí por mujer, [^3] No podrá su primer marido, que la despidió, volverla á tomar para que sea su mujer, después que fué amancillada; porque es abominación delante de Jehová, y no has de pervertir la tierra que Jehová tu Dios te da por heredad. [^4] Cuando tomare alguno mujer nueva, no saldrá á la guerra, ni en ninguna cosa se le ocupará; libre estará en su casa por un año, para alegrar á su mujer que tomó. [^5] No tomarás en prenda la muela de molino, ni la de abajo ni la de arriba: porque sería prendar la vida. [^6] Cuando fuere hallado alguno que haya hurtado persona de sus hermanos los hijos de Israel, y hubiere mercadeado con ella, ó la hubiere vendido, el tal ladrón morirá, y quitarás el mal de en medio de ti. [^7] Guárdate de llaga de lepra, observando diligentemente, y haciendo según todo lo que os enseñaren los sacerdotes Levitas: cuidaréis de hacer como les he mandado. [^8] Acuérdate de lo que hizo Jehová tu Dios á María en el camino, después que salisteis de Egipto. [^9] Cuando dieres á tu prójimo alguna cosa emprestada, no entrarás en su casa para tomarle prenda: [^10] Fuera estarás, y el hombre á quien prestaste, te sacará afuera la prenda. [^11] Y si fuere hombre pobre, no duermas con su prenda: [^12] Precisamente le devolverás la prenda cuando el sol se ponga, para que duerma en su ropa, y te bendiga: y te será justicia delante de Jehová tu Dios. [^13] No hagas agravio al jornalero pobre y menesteroso, así de tus hermanos como de tus extranjeros que están en tu tierra en tus ciudades: [^14] En su día le darás su jornal, y no se pondrá el sol sin dárselo: pues es pobre, y con él sustenta su vida: porque no clame contra ti á Jehová, y sea en ti pecado. [^15] Los padres no morirán por los hijos, ni los hijos por los padres; cada uno morirá por su pecado. [^16] No torcerás el derecho del peregrino y del huérfano; ni tomarás por prenda la ropa de la viuda: [^17] Mas acuérdate que fuiste siervo en Egipto, y de allí te rescató Jehová tu Dios: por tanto, yo te mando que hagas esto. [^18] Cuando segares tu mies en tu campo, y olvidares alguna gavilla en el campo, no volverás a tomarla: para el extranjero, para el huérfano, y para la viuda será; porque te bendiga Jehová tu Dios en toda obra de tus manos. [^19] Cuando sacudieres tus olivas, no recorrerás las ramas tras ti: para el extranjero, para el huérfano, y para la viuda será. [^20] Cuando vendimiares tu viña, no rebuscarás tras ti: para el extranjero, para el huérfano, y para la viuda será. [^21] Y acuérdate que fuiste siervo en tierra de Egipto: por tanto, yo te mando que hagas esto. [^22] 

[[Deuteronomy - 23|<--]] Deuteronomy - 24 [[Deuteronomy - 25|-->]]

---
# Notes
