---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 21 - Reina Valera (1602)"
---
[[Deuteronomy - 20|<--]] Deuteronomy - 21 [[Deuteronomy - 22|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Deuteronomy]]

# Deuteronomy - 21

CUANDO fuere hallado en la tierra que Jehová tu Dios te da para que la poseas, muerto echado en el campo, y no se supiere quién lo hirió, [^1] Entonces tus ancianos y tus jueces saldrán y medirán hasta las ciudades que están alrededor del muerto: [^2] Y será, que los ancianos de aquella ciudad, de la ciudad más cercana al muerto, tomarán de la vacada una becerra que no haya servido, que no haya traído yugo; [^3] Y los ancianos de aquella ciudad traerán la becerra á un valle áspero, que nunca haya sido arado ni sembrado, y cortarán el pescuezo á la becerra allí en el valle. [^4] Entonces vendrán los sacerdotes hijos de Leví, porque á ellos escogió Jehová tu Dios para que le sirvan, y para bendecir en nombre de Jehová; y por el dicho de ellos se determinará todo pleito y toda llaga. [^5] Y todos los ancianos de aquella ciudad más cercana al muerto lavarán sus manos sobre la becerra degollada en el valle. [^6] Y protestarán, y dirán: Nuestras manos no han derramado esta sangre, ni nuestros ojos lo vieron. [^7] Expía á tu pueblo Israel, al cual redimiste, oh Jehová; y no imputes la sangre inocente derramada en medio de tu pueblo Israel. Y la sangre les será perdonada. [^8] Y tú quitarás la culpa de sangre inocente de en medio de ti, cuando hicieres lo que es recto en los ojos de Jehová. [^9] Cuando salieres á la guerra contra tus enemigos, y Jehová tu Dios los entregare en tu mano, y tomares de ellos cautivos, [^10] Y vieres entre los cautivos alguna mujer hermosa, y la codiciares, y la tomares para ti por mujer, [^11] La meterás en tu casa; y ella raerá su cabeza, y cortará sus uñas, [^12] Y se quitará el vestido de su cautiverio, y quedaráse en tu casa: y llorará á su padre y á su madre el tiempo de un mes: y después entrarás á ella, y tu serás su marido, y ella tu mujer. [^13] Y será, si no te agradare, que la has de dejar en su libertad; y no la venderás por dinero, ni mercadearás con ella, por cuanto la afligiste. [^14] Cuando un hombre tuviere dos mujeres, la una amada y la otra aborrecida, y la amada y la aborrecida le parieren hijos, y el hijo primogénito fuere de la aborrecida; [^15] Será que, el día que hiciere heredar á sus hijos lo que tuviere, no podrá dar el derecho de primogenitura á los hijos de la amada en preferencia al hijo de la aborrecida, que es el primogénito; [^16] Mas al hijo de la aborrecida reconocerá por primogénito, para darle dos tantos de todo lo que se hallare que tiene: porque aquél es el principio de su fuerza, el derecho de la primogenitura es suyo. [^17] Cuando alguno tuviere hijo contumaz y rebelde, que no obedeciere á la voz de su padre ni á la voz de su madre, y habiéndolo castigado, no les obedeciere; [^18] Entonces tomarlo han su padre y su madre, y lo sacarán á los ancianos de su ciudad, y á la puerta del lugar suyo; [^19] Y dirán á los ancianos de la ciudad: Este nuestro hijo es contumaz y rebelde, no obedece á nuestra voz; es glotón y borracho. [^20] Entonces todos los hombres de su ciudad lo apedrearán con piedras, y morirá: así quitarás el mal de en medio de ti; y todo Israel oirá, y temerá. [^21] Cuando en alguno hubiere pecado de sentencia de muerte, por el que haya de morir, y le habrás colgado de un madero, [^22] No estará su cuerpo por la noche en el madero, mas sin falta lo enterrarás el mismo día, porque maldición de Dios es el colgado: y no contaminarás tu tierra, que Jehová tu Dios te da por heredad. [^23] 

[[Deuteronomy - 20|<--]] Deuteronomy - 21 [[Deuteronomy - 22|-->]]

---
# Notes
