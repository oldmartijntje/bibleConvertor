---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 30 - Reina Valera (1602)"
---
[[Deuteronomy - 29|<--]] Deuteronomy - 30 [[Deuteronomy - 31|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Deuteronomy]]

# Deuteronomy - 30

Y SERA que, cuando te sobrevinieren todas estas cosas, la bendición y la maldición que he puesto delante de ti, y volvieres á tu corazón en medio de todas las gentes á las cuales Jehová tu Dios te hubiere echado, [^1] Y te convirtieres á Jehová tu Dios, y obedecieres á su voz conforme á todo lo que yo te mando hoy, tú y tus hijos, con todo tu corazón y con toda tu alma, [^2] Jehová también volverá tus cautivos, y tendrá misericordia de ti, y tornará á recogerte de todos los pueblos á los cuales te hubiere esparcido Jehová tu Dios. [^3] Si hubieres sido arrojado hasta el cabo de los cielos, de allí te recogerá Jehová tu Dios, y de allá te tomará: [^4] Y volverte ha Jehová tu Dios á la tierra que heredaron tus padres, y la poseerás; y te hará bien, y te multiplicará más que á tus padres. [^5] Y circuncidará Jehová tu Dios tu corazón, y el corazón de tu simiente, para que ames á Jehová tu Dios con todo tu corazón y con toda tu alma, á fin de que tú vivas. [^6] Y pondrá Jehová tu Dios todas estas maldiciones sobre tus enemigos, y sobre tus aborrecedores que te persiguieron. [^7] Y tú volverás, y oirás la voz de Jehová, y pondrás por obra todos sus mandamientos, que yo te intimo hoy. [^8] Y hacerte ha Jehová tu Dios abundar en toda obra de tus manos, en el fruto de tu vientre, en el fruto de tu bestia, y en el fruto de tu tierra, para bien: porque Jehová volverá á gozarse sobre ti para bien, de la manera que se gozó sobre tus padres; [^9] Cuando oyeres la voz de Jehová tu Dios, para guardar sus mandamientos y sus estatutos escritos en este libro de la ley; cuando te convirtieres á Jehová tu Dios con todo tu corazón y con toda tu alma. [^10] Porque este mandamiento que yo te intimo hoy, no te es encubierto, ni está lejos: [^11] No está en el cielo, para que digas: ¿Quién subirá por nosotros al cielo, y nos lo traerá y nos lo representará, para que lo cumplamos? [^12] Ni está de la otra parte de la mar, para que digas: ¿Quién pasará por nosotros la mar, para que nos lo traiga y nos lo represente, á fin de que lo cumplamos? [^13] Porque muy cerca de ti está la palabra, en tu boca y en tu corazón, para que la cumplas. [^14] Mira, yo he puesto delante de ti hoy la vida y el bien, la muerte y el mal: [^15] Porque yo te mando hoy que ames á Jehová tu Dios, que andes en sus caminos, y guardes sus mandamientos y sus estatutos y sus derechos, para que vivas y seas multiplicado, y Jehová tu Dios te bendiga en la tierra á la cual entras para poseerla. [^16] Mas si tu corazón se apartare, y no oyeres, y fueres incitado, y te inclinares á dioses ajenos, y los sirvieres; [^17] Protéstoos hoy que de cierto pereceréis: no tendréis largos días sobre la tierra, para ir á la cual pasas el Jordán para poseerla. [^18] A los cielos y la tierra llamo por testigos hoy contra vosotros, que os he puesto delante la vida y la muerte, la bendición y la maldición: escoge pues la vida, porque vivas tú y tu simiente: [^19] Que ames á Jehová tu Dios, que oigas su voz, y te allegues á él; porque él es tu vida, y la longitud de tus días; á fin de que habites sobre la tierra que juró Jehová á tus padres Abraham, Isaac, y Jacob, que les había de dar. [^20] 

[[Deuteronomy - 29|<--]] Deuteronomy - 30 [[Deuteronomy - 31|-->]]

---
# Notes
