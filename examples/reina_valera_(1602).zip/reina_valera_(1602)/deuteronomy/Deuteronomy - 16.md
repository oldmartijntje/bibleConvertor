---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 16 - Reina Valera (1602)"
---
[[Deuteronomy - 15|<--]] Deuteronomy - 16 [[Deuteronomy - 17|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Deuteronomy]]

# Deuteronomy - 16

GUARDARAS el mes de Abib, y harás pascua á Jehová tu Dios: porque en el mes de Abib te sacó Jehová tu Dios de Egipto de noche. [^1] Y sacrificarás la pascua á Jehová tu Dios, de las ovejas y de las vacas, en el lugar que Jehová escogiere para hacer habitar allí su nombre. [^2] No comerás con ella leudo; siete días comerás con ella pan por leudar, pan de aflicción, porque apriesa saliste de tierra de Egipto: para que te acuerdes del día en que saliste de la tierra de Egipto todos los días de tu vida. [^3] Y no se dejará ver levadura contigo en todo tu término por siete días; y de la carne que matares á la tarde del primer día, no quedará hasta la mañana. [^4] No podrás sacrificar la pascua en ninguna de tus ciudades, que Jehová tu Dios te da; [^5] Sino en el lugar que Jehová tu Dios escogiere para hacer habitar allí su nombre, sacrificarás la pascua por la tarde á puesta del sol, al tiempo que saliste de Egipto: [^6] Y la asarás y comerás en el lugar que Jehová tu Dios hubiere escogido; y por la mañana te volverás y restituirás á tu morada. [^7] Seis días comerás ázimos, y el séptimo día será solemnidad á Jehová tu Dios: no harás obra en él. [^8] Siete semanas te contarás: desde que comenzare la hoz en las mieses comenzarás á contarte las siete semanas. [^9] Y harás la solemnidad de las semanas á Jehová tu Dios: de la suficiencia voluntaria de tu mano será lo que dieres, según Jehová tu Dios te hubiere bendecido. [^10] Y te alegrarás delante de Jehová tu Dios, tú, y tu hijo, y tu hija, y tu siervo, y tu sierva, y el Levita que estuviere en tus ciudades, y el extranjero, y el huérfano, y la viuda, que estuvieren en medio de ti, en el lugar que Jehová tu Dios hubiere escogido para hacer habitar allí su nombre. [^11] Y acuérdate que fuiste siervo en Egipto; por tanto guardarás y cumplirás estos estatutos. [^12] La solemnidad de las cabañas harás por siete días, cuando hubieres hecho la cosecha de tu era y de tu lagar. [^13] Y te alegrarás en tus solemnidades, tú, y tu hijo, y tu hija, y tu siervo, y tu sierva, y el Levita, y el extranjero, y el huérfano, y la viuda, que están en tus poblaciones. [^14] Siete días celebrarás solemnidad á Jehová tu Dios en el lugar que Jehová escogiere; porque te habrá bendecido Jehová tu Dios en todos tus frutos, y en toda obra de tus manos, y estarás ciertamente alegre. [^15] Tres veces cada un año parecerá todo varón tuyo delante de Jehová tu Dios en el lugar que él escogiere: en la solemnidad de los ázimos, y en la solemnidad de las semanas, y en la solemnidad de las cabañas. Y no parecerá vacío delante de Jehová: [^16] Cada uno con el don de su mano, conforme á la bendición de Jehová tu Dios, que te hubiere dado. [^17] Jueces y alcaldes te pondrás en todas tus ciudades que Jehová tu Dios te dará en tus tribus, los cuales juzgarán al pueblo con justo juicio. [^18] No tuerzas el derecho; no hagas acepción de personas, ni tomes soborno; porque el soborno ciega los ojos de los sabios, y pervierte las palabras de los justos. [^19] La justicia, la justicia seguirás, porque vivas y heredes la tierra que Jehová tu Dios te da. [^20] No te plantarás bosque de ningún árbol cerca del altar de Jehová tu Dios, que tú te habrás hecho. [^21] Ni te levantarás estatua; lo cual aborrece Jehová tu Dios. [^22] 

[[Deuteronomy - 15|<--]] Deuteronomy - 16 [[Deuteronomy - 17|-->]]

---
# Notes
