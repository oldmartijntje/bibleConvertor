---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 17 - Reina Valera (1602)"
---
[[Deuteronomy - 16|<--]] Deuteronomy - 17 [[Deuteronomy - 18|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Deuteronomy]]

# Deuteronomy - 17

NO sacrificarás á Jehová tu Dios buey, ó cordero, en el cual haya falta ó alguna cosa mala: porque es abominación á Jehová tu Dios. [^1] Cuando se hallare entre ti, en alguna de tus ciudades que Jehová tu Dios te da, hombre, ó mujer, que haya hecho mal en ojos de Jehová tu Dios traspasando su pacto, [^2] Que hubiere ido y servido á dioses ajenos, y se hubiere inclinado á ellos, ora al sol, ó á la luna, ó á todo el ejército del cielo, lo cual yo no he mandado; [^3] Y te fuere dado aviso, y, después que oyeres y hubieres indagado bien, la cosa parece de verdad cierta, que tal abominación ha sido hecha en Israel; [^4] Entonces sacarás al hombre ó mujer que hubiere hecho esta mala cosa, á tus puertas, hombre ó mujer, y los apedrearás con piedras, y así morirán. [^5] Por dicho de dos testigos, ó de tres testigos, morirá el que hubiere de morir; no morirá por el dicho de un solo testigo. [^6] La mano de los testigos será primero sobre él para matarlo, y después la mano de todo el pueblo: así quitarás el mal de en medio de ti. [^7] Cuando alguna cosa te fuere oculta en juicio entre sangre y sangre, entre causa y causa, y entre llaga y llaga, en negocios de litigio en tus ciudades; entonces te levantarás y recurrirás al lugar que Jehová tu Dios escogiere; [^8] Y vendrás á los sacerdotes Levitas, y al juez que fuere en aquellos días, y preguntarás; y te enseñarán la sentencia del juicio. [^9] Y harás según la sentencia que te indicaren los del lugar que Jehová escogiere, y cuidarás de hacer según todo lo que te manifestaren. [^10] Según la ley que ellos te enseñaren, y según el juicio que te dijeren, harás: no te apartarás ni á diestra ni á siniestra de la sentencia que te mostraren. [^11] Y el hombre que procediere con soberbia, no obedeciendo al sacerdote que está para ministrar allí delante de Jehová tu Dios, ó al juez, el tal varón morirá: y quitarás el mal de Israel. [^12] Y todo el pueblo oirá, y temerá, y no se ensoberbecerán más. [^13] Cuando hubieres entrado en la tierra que Jehová tu Dios te da, y la poseyeres, y habitares en ella, y dijeres: Pondré rey sobre mí, como todas las gentes que están en mis alrededores; [^14] Sin duda pondrás por rey sobre ti al que Jehová tu Dios escogiere: de entre tus hermanos pondrás rey sobre ti: no podrás poner sobre ti hombre extranjero, que no sea tu hermano. [^15] Empero que no se aumente caballos, ni haga volver el pueblo á Egipto para acrecentar caballos: porque Jehová os ha dicho: No procuraréis volver más por este camino. [^16] Ni aumentará para sí mujeres, porque su corazón no se desvíe: ni plata ni oro acrecentará para sí en gran copia. [^17] Y será, cuando se asentare sobre el solio de su reino, que ha de escribir para sí en un libro un traslado de esta ley, del original de delante de los sacerdotes Levitas; [^18] Y lo tendrá consigo, y leerá en él todos los días de su vida, para que aprenda á temer á Jehová su Dios, para guardar todas las palabras de aquesta ley y estos estatutos, para ponerlos por obra: [^19] Para que no se eleve su corazón sobre sus hermanos, ni se aparte del mandamiento á diestra ni á siniestra: á fin que prolongue sus días en su reino, él y sus hijos, en medio de Israel. [^20] 

[[Deuteronomy - 16|<--]] Deuteronomy - 17 [[Deuteronomy - 18|-->]]

---
# Notes
