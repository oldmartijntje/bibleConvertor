---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 13 - Reina Valera (1602)"
---
[[Deuteronomy - 12|<--]] Deuteronomy - 13 [[Deuteronomy - 14|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Deuteronomy]]

# Deuteronomy - 13

CUANDO se levantare en medio de ti profeta, ó soñador de sueños, y te diere señal ó prodigio, [^1] Y acaeciere la señal ó prodigio que él te dijo, diciendo: Vamos en pos de dioses ajenos, que no conociste, y sirvámosles; [^2] No darás oído á las palabras de tal profeta, ni al tal soñador de sueños: porque Jehová vuestro Dios os prueba, para saber si amáis á Jehová vuestro Dios con todo vuestro corazón, y con toda vuestra alma. [^3] En pos de Jehová vuestro Dios andaréis, y á él temeréis, y guardaréis sus mandamientos, y escucharéis su voz, y á él serviréis, y á él os allegaréis. [^4] Y el tal profeta ó soñador de sueños, ha de ser muerto; por cuanto trató de rebelión contra Jehová vuestro Dios, que te sacó de tierra de Egipto, y te rescató de casa de siervos, y de echarte del camino por el que Jehová tu Dios te mandó que anduvieses: y así quitarás el mal de en medio de ti. [^5] Cuando te incitare tu hermano, hijo de tu madre, ó tu hijo, ó tu hija, ó la mujer de tu seno, ó tu amigo que sea como tu alma, diciendo en secreto: Vamos y sirvamos á dioses ajenos, que ni tú ni tus padres conocisteis, [^6] De los dioses de los pueblos que están en vuestros alrededores cercanos á ti, ó lejos de ti, desde el un cabo de la tierra hasta el otro cabo de ella; [^7] No consentirás con él, ni le darás oído; ni tu ojo le perdonará, ni tendrás compasión, ni lo encubrirás: [^8] Antes has de matarlo; tu mano será primero sobre él para matarle, y después la mano de todo el pueblo. [^9] Y has de apedrearlo con piedras, y morirá; por cuanto procuró apartarte de Jehová tu Dios, que te sacó de tierra de Egipto, de casa de siervos: [^10] Para que todo Israel oiga, y tema, y no tornen á hacer cosa semejante á esta mala cosa en medio de ti. [^11] Cuando oyeres de alguna de tus ciudades que Jehová tu Dios te da para que mores en ellas, que se dice: [^12] Hombres, hijos de impiedad, han salido de en medio de ti, que han instigado á los moradores de su ciudad, diciendo: Vamos y sirvamos á dioses ajenos, que vosotros no conocisteis; [^13] Tú inquirirás, y buscarás, y preguntarás con diligencia; y si pareciere verdad, cosa cierta, que tal abominación se hizo en medio de ti, [^14] Irremisiblemente herirás á filo de espada los moradores de aquella ciudad, destruyéndola con todo lo que en ella hubiere, y también sus bestias á filo de espada. [^15] Y juntarás todo el despojo de ella en medio de su plaza, y consumirás con fuego la ciudad y todo su despojo, todo ello, á Jehová tu Dios: y será un montón para siempre: nunca más se edificará. [^16] Y no se pegará algo á tu mano del anatema; porque Jehová se aparte del furor de su ira, y te dé mercedes, y tenga misericordia de ti, y te multiplique, como lo juró á tus padres, [^17] Cuando obedecieres á la voz de Jehová tu Dios, guardando todos sus mandamientos que yo te prescribo hoy, para hacer lo recto en ojos de Jehová tu Dios. [^18] 

[[Deuteronomy - 12|<--]] Deuteronomy - 13 [[Deuteronomy - 14|-->]]

---
# Notes
