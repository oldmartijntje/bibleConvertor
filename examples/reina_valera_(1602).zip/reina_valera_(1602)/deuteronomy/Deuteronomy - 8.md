---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 8 - Reina Valera (1602)"
---
[[Deuteronomy - 7|<--]] Deuteronomy - 8 [[Deuteronomy - 9|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Deuteronomy]]

# Deuteronomy - 8

CUIDARÉIS de poner por obra todo mandamiento que yo os ordeno hoy, porque viváis, y seáis multiplicados, y entréis, y poseáis la tierra, de la cual juró Jehová á vuestros padres. [^1] Y acordarte has de todo el camino por donde te ha traído Jehová tu Dios estos cuarenta años en el desierto, para afligirte, por probarte, para saber lo que estaba en tu corazón, si habías de guardar ó no sus mandamientos. [^2] Y te afligió, é hízote tener hambre, y te sustentó con maná, comida que no conocías tú, ni tus padres la habían conocido; para hacerte saber que el hombre no vivirá de solo pan, mas de todo lo que sale de la boca de Jehová vivirá el hombre. [^3] Tu vestido nunca se envejeció sobre ti, ni el pie se te ha hinchado por estos cuarenta años. [^4] Reconoce asimismo en tu corazón, que como castiga el hombre á su hijo, así Jehová tu Dios te castiga. [^5] Guardarás, pues, los mandamientos de Jehová tu Dios, andando en sus caminos, y temiéndolo. [^6] Porque Jehová tu Dios te introduce en la buena tierra, tierra de arroyos, de aguas, de fuentes, de abismos que brotan por vegas y montes; [^7] Tierra de trigo y cebada, y de vides, é higueras, y granados; tierra de olivas, de aceite, y de miel; [^8] Tierra en la cual no comerás el pan con escasez, no te faltará nada en ella; tierra que sus piedras son hierro, y de sus montes cortarás metal. [^9] Y comerás y te hartarás, y bendecirás á Jehová tu Dios por la buena tierra que te habrá dado. [^10] Guárdate, que no te olvides de Jehová tu Dios, para no observar sus mandamientos, y sus derechos, y sus estatutos, que yo te ordeno hoy: [^11] Que quizá no comas y te hartes, y edifiques buenas casas en que mores, [^12] Y tus vacas y tus ovejas se aumenten, y la plata y el oro se te multiplique, y todo lo que tuvieres se te aumente, [^13] Y se eleve luego tu corazón, y te olvides de Jehová tu Dios, que te sacó de tierra de Egipto, de casa de siervos; [^14] Que te hizo caminar por un desierto grande y espantoso, de serpientes ardientes, y de escorpiones, y de sed, donde ningún agua había, y él te sacó agua de la roca del pedernal; [^15] Que te sustentó con maná en el desierto, comida que tus padres no habían conocido, afligiéndote y probándote, para á la postre hacerte bien; [^16] Y digas en tu corazón: Mi poder y la fortaleza de mi mano me han traído esta riqueza. [^17] Antes acuérdate de Jehová tu Dios: porque él te da el poder para hacer las riquezas, á fin de confirmar su pacto que juró á tus padres, como en este día. [^18] Mas será, si llegares á olvidarte de Jehová tu Dios, y anduvieres en pos de dioses ajenos, y les sirvieres, y á ellos te encorvares, protésto lo hoy contra vosotros, que de cierto pereceréis. [^19] Como las gentes que Jehová destruirá delante de vosotros, así pereceréis; por cuanto no habréis atendido á la voz de Jehová vuestro Dios. [^20] 

[[Deuteronomy - 7|<--]] Deuteronomy - 8 [[Deuteronomy - 9|-->]]

---
# Notes
