---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 25 - Reina Valera (1602)"
---
[[Deuteronomy - 24|<--]] Deuteronomy - 25 [[Deuteronomy - 26|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Deuteronomy]]

# Deuteronomy - 25

CUANDO hubiere pleito entre algunos, y vinieren á juicio, y los juzgaren, y absolvieren al justo y condenaren al inicuo, [^1] Será que, si el delincuente mereciere ser azotado, entonces el juez lo hará echar en tierra, y harále azotar delante de sí, según su delito, por cuenta. [^2] Harále dar cuarenta azotes, no más: no sea que, si lo hiriere con muchos azotes a más de éstos, se envilezca tu hermano delante de tus ojos. [^3] No pondrás bozal al buey cuando trillare. [^4] Cuando hermanos estuvieren juntos, y muriere alguno de ellos, y no tuviere hijo, la mujer del muerto no se casará fuera con hombre extraño: su cuñado entrará á ella, y la tomará por su mujer, y hará con ella parentesco. [^5] Y será que el primogénito que pariere ella, se levantará en nombre de su hermano el muerto, porque el nombre de éste no sea raído de Israel. [^6] Y si el hombre no quisiere tomar á su cuñada, irá entonces la cuñada suya á la puerta á los ancianos, y dirá: Mi cuñado no quiere suscitar nombre en Israel á su hermano; no quiere emparentar conmigo. [^7] Entonces los ancianos de aquella ciudad lo harán venir, y hablarán con él: y si él se levantare, y dijere, No quiero tomarla, [^8] Llegaráse entonces su cuñada á él delante de los ancianos, y le descalzará el zapato de su pie, y escupirále en el rostro, y hablará y dirá: Así será hecho al varón que no edificare la casa de su hermano. [^9] Y su nombre será llamado en Israel: La casa del descalzado. [^10] Cuando algunos riñeren juntos el uno con el otro, y llegare la mujer del uno para librar á su marido de mano del que le hiere, y metiere su mano y le trabare de sus vergüenzas; [^11] La cortarás entonces la mano, no la perdonará tu ojo. [^12] No tendrás en tu bolsa pesa grande y pesa chica. [^13] No tendrás en tu casa epha grande y epha pequeño. [^14] Pesas cumplidas y justas tendrás; epha cabal y justo tendrás: para que tus días sean prolongados sobre la tierra que Jehová tu Dios te da. [^15] Porque abominación es á Jehová tu Dios cualquiera que hace esto, cualquiera que hace agravio. [^16] Acuérdate de lo que te hizo Amalec en el camino, cuando salisteis de Egipto: [^17] Que te salió al camino, y te desbarató la retaguardia de todos los flacos que iban detrás de ti, cuando tú estabas cansado y trabajado; y no temió á Dios. [^18] Será pues, cuando Jehová tu Dios te hubiere dado reposo de tus enemigos alrededor, en la tierra que Jehová tu Dios te da por heredar para que la poseas, que raerás la memoria de Amalec de debajo del cielo: no te olvides. [^19] 

[[Deuteronomy - 24|<--]] Deuteronomy - 25 [[Deuteronomy - 26|-->]]

---
# Notes
