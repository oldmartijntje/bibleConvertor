---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 18 - Reina Valera (1602)"
---
[[Deuteronomy - 17|<--]] Deuteronomy - 18 [[Deuteronomy - 19|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Deuteronomy]]

# Deuteronomy - 18

LOS sacerdotes Levitas, toda la tribu de Leví, no tendrán parte ni heredad con Israel; de las ofrendas encendidas á Jehová, y de la heredad de él comerán. [^1] No tendrán, pues, heredad entre sus hermanos: Jehová es su heredad, como él les ha dicho. [^2] Y este será el derecho de los sacerdotes de parte del pueblo, de los que ofrecieren en sacrificio buey ó cordero: darán al sacerdote la espalda, y las quijadas, y el cuajar. [^3] Las primicias de tu grano, de tu vino, y de tu aceite, y las primicias de la lana de tus ovejas le darás: [^4] Porque le ha escogido Jehová tu Dios de todas tus tribus, para que esté para ministrar al nombre de Jehová, él y sus hijos para siempre. [^5] Y cuando el Levita saliere de alguna de tus ciudades de todo Israel, donde hubiere peregrinado, y viniere con todo deseo de su alma al lugar que Jehová escogiere, [^6] Ministrará al nombre de Jehová su Dios, como todos sus hermanos los Levitas que estuvieren allí delante de Jehová. [^7] Porción como la porción de los otros comerán, además de sus patrimonios. [^8] Cuando hubieres entrado en la tierra que Jehová tu Dios te da, no aprenderás á hacer según las abominaciones de aquellas gentes. [^9] No sea hallado en ti quien haga pasar su hijo ó su hija por el fuego, ni practicante de adivinaciones, ni agorero, ni sortílego, ni hechicero, [^10] Ni fraguador de encantamentos, ni quien pregunte á pitón, ni mágico, ni quien pregunte á los muertos. [^11] Porque es abominación á Jehová cualquiera que hace estas cosas, y por estas abominaciones Jehová tu Dios las echó de delante de ti. [^12] Perfecto serás con Jehová tu Dios. [^13] Porque estas gentes que has de heredar, á agoreros y hechiceros oían: mas tú, no así te ha dado Jehová tu Dios. [^14] Profeta de en medio de ti, de tus hermanos, como yo, te levantará Jehová tu Dios: á él oiréis: [^15] Conforme á todo lo que pediste á Jehová tu Dios en Horeb el día de la asamblea, diciendo: No vuelva yo á oir la voz de Jehová mi Dios, ni vea yo más este gran fuego, porque no muera. [^16] Y Jehová me dijo: Bien han dicho. [^17] Profeta les suscitaré de en medio de sus hermanos, como tú; y pondré mis palabras en su boca, y él les hablará todo lo que yo le mandare. [^18] Mas será, que cualquiera que no oyere mis palabras que él hablare en mi nombre, yo le residenciaré. [^19] Empero el profeta que presumiere hablar palabra en mi nombre, que yo no le haya mandado hablar, ó que hablare en nombre de dioses ajenos, el tal profeta morirá. [^20] Y si dijeres en tu corazón: ¿Cómo conoceremos la palabra que Jehová no hubiere hablado? [^21] Cuando el profeta hablare en nombre de Jehová, y no fuere la tal cosa, ni viniere, es palabra que Jehová no ha hablado: con soberbia la habló aquel profeta: no tengas temor de él. [^22] 

[[Deuteronomy - 17|<--]] Deuteronomy - 18 [[Deuteronomy - 19|-->]]

---
# Notes
