---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 20 - Reina Valera (1602)"
---
[[Deuteronomy - 19|<--]] Deuteronomy - 20 [[Deuteronomy - 21|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Deuteronomy]]

# Deuteronomy - 20

CUANDO salieres á la guerra contra tus enemigos, y vieres caballos y carros, un pueblo más grande que tú, no tengas temor de ellos, que Jehová tu Dios es contigo, el cual te sacó de tierra de Egipto. [^1] Y será que, cuando os acercareis para combatir, llegaráse el sacerdote, y hablará al pueblo, [^2] Y les dirá: Oye, Israel, vosotros os juntáis hoy en batalla contra vuestros enemigos: no se ablande vuestro corazón, no temáis, no os azoréis, ni tampoco os desalentéis delante de ellos; [^3] Que Jehová vuestro Dios anda con vosotros, para pelear por vosotros contra vuestros enemigos, para salvaros. [^4] Y los oficiales hablarán al pueblo, diciendo: ¿Quién ha edificado casa nueva, y no la ha estrenado? Vaya, y vuélvase á su casa, porque quizá no muera en la batalla, y otro alguno la estrene. [^5] ¿Y quién ha plantado viña, y no ha hecho común uso de ella? Vaya, y vuélvase á su casa, porque quizá no muera en la batalla, y otro alguno la goce. [^6] ¿Y quién se ha desposado con mujer, y no la ha tomado? Vaya, y vuélvase á su casa, porque quizá no muera en la batalla, y algún otro la tome. [^7] Y tornarán los oficiales á hablar al pueblo, y dirán: ¿Quién es hombre medroso y tierno de corazón? Vaya, y vuélvase á su casa, y no apoque el corazón de sus hermanos, como su corazón. [^8] Y será que, cuando los oficiales acabaren de hablar al pueblo, entonces los capitanes de los ejércitos mandarán delante del pueblo. [^9] Cuando te acercares á una ciudad para combatirla, le intimarás la paz. [^10] Y será que, si te respondiere, Paz, y te abriere, todo el pueblo que en ella fuere hallado te serán tributarios, y te servirán. [^11] Mas si no hiciere paz contigo, y emprendiere contigo guerra, y la cercares, [^12] Luego que Jehová tu Dios la entregare en tu mano, herirás á todo varón suyo á filo de espada. [^13] Solamente las mujeres y los niños, y los animales, y todo lo que hubiere en la ciudad, todos sus despojos, tomarás para ti: y comerás del despojo de tus enemigos, los cuales Jehová tu Dios te entregó. [^14] Así harás á todas la ciudades que estuvieren muy lejos de ti, que no fueren de las ciudades de estas gentes. [^15] Empero de las ciudades de estos pueblos que Jehová tu Dios te da por heredad, ninguna persona dejarás con vida; [^16] Antes del todo los destruirás: al Hetheo, y al Amorrheo, y al Cananeo, y al Pherezeo, y al Heveo, y al Jebuseo; como Jehová tu Dios te ha mandado: [^17] Porque no os enseñen á hacer según todas sus abominaciones, que ellos hacen á sus dioses, y pequéis contra Jehová vuestro Dios. [^18] Cuando pusieres cerco á alguna ciudad, peleando contra ella muchos días para tomarla, no destruyas su arboleda metiendo en ella hacha, porque de ella comerás; y no la talarás, que no es hombre el árbol del campo para venir contra ti en el cerco. [^19] Mas el árbol que supieres que no es árbol para comer, lo destruirás y lo talarás, y construye baluarte contra la ciudad que pelea contigo, hasta sojuzgarla. [^20] 

[[Deuteronomy - 19|<--]] Deuteronomy - 20 [[Deuteronomy - 21|-->]]

---
# Notes
