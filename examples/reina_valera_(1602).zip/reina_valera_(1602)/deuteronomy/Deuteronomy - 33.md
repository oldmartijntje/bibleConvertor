---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 33 - Reina Valera (1602)"
---
[[Deuteronomy - 32|<--]] Deuteronomy - 33 [[Deuteronomy - 34|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Deuteronomy]]

# Deuteronomy - 33

Y ESTA es la bendición con la cual bendijo Moisés varón de Dios á los hijos de Israel, antes que muriese. [^1] Y dijo: Jehová vino de Sinaí, Y de Seir les esclareció; Resplandeció del monte de Parán, Y vino con diez mil santos: A su diestra la ley de fuego para ellos. [^2] Aun amó los pueblos; Todos sus santos en tu mano: Ellos también se llegaron á tus pies: Recibieron de tus dichos. [^3] Ley nos mandó Moisés, Heredad á la congregación de Jacob. [^4] Y fué rey en Jeshurun, Cuando se congregaron las cabezas del pueblo Con las tribus de Israel. [^5] Viva Rubén, y no muera; Y sean sus varones en número. [^6] Y esta bendición para Judá. Dijo así: Oye, oh Jehová, la voz de Judá, Y llévalo á su pueblo; Sus manos le basten, Y tú seas ayuda contra sus enemigos. [^7] Y a Leví dijo: Tu Thummim y tu Urim, con tu buen varón Al cual tentaste en Massa, Y le hiciste reñir en las aguas de la rencilla; [^8] El que dijo á su padre y á su madre: Nunca los vi: Ni conoció á sus hermanos, Ni conoció á sus hijos: Por lo cual ellos guardarán tus palabras, Y observarán tu pacto. [^9] Ellos enseñarán tus juicios á Jacob, Y tu ley á Israel; Pondrán el perfume delante de ti, Y el holocausto sobre tu altar. [^10] Bendice, oh Jehová, lo que hicieren, Y recibe con agrado la obra de sus manos: Hiere los lomos de sus enemigos, Y de los que le aborrecieren; para que nunca se levanten. [^11] Y á Benjamín dijo: El amado de Jehová habitará confiado cerca de él: Cubrirálo siempre, Y entre sus hombros morará. [^12] Y á José dijo: Bendita de Jehová su tierra, Por los regalos de los cielos, por el rocío, Y por el abismo que abajo yace, [^13] Y por los regalados frutos del sol, Y por los regalos de las influencias de las lunas, [^14] Y por la cumbre de los montes antiguos, Y por los regalos de los collados eternos, [^15] Y por los regalos de la tierra y su plenitud; Y la gracia del que habitó en la zarza Venga sobre la cabeza de José, Y sobre la mollera del apartado de sus hermanos. [^16] El es aventajado como el primogénito de su toro, Y sus cuernos, cuernos de unicornio: Con ellos acorneará los pueblos juntos hasta los fines de la tierra: Y estos son los diez millares de Ephraim, Y estos los millares de Manasés. [^17] Y á Zabulón dijo: Alégrate, Zabulón, cuando salieres: Y tu Issachâr, en tus tiendas. [^18] Llamarán los pueblos al monte: Allí sacrificarán sacrificios de justicia: Por lo cual chuparán la abundancia de los mares, Y los tesoros escondidos de la arena. [^19] Y a Gad dijo: Bendito el que hizo ensanchar á Gad: Como león habitará, Y arrebatará brazo y testa. [^20] Y él se ha provisto de la parte primera, Porque allí una porción del legislador fuéle reservada, Y vino en la delantera del pueblo; La justicia de Jehová ejecutará, Y sus juicios con Israel. [^21] Y á Dan dijo: Dan, cachorro de león: Saltará desde Basán. [^22] Y á Nephtalí dijo: Nephtalí, saciado de benevolencia, Y lleno de la bendición de Jehová, Posee el occidente y el mediodía, [^23] Y á Aser dijo: Bendito Aser en hijos: Agradable será á sus hermanos, Y mojará en aceite su pie. [^24] Hierro y metal tu calzado, Y como tus días tu fortaleza. [^25] No hay como el Dios de Jeshurun, Montado sobre los cielos para tu ayuda, Y sobre las nubes con su grandeza. [^26] El eterno Dios es tu refugio Y acá abajo los brazos eternos; El echará de delante de ti al enemigo, Y dirá: Destruye. [^27] E Israel, fuente de Jacob, habitará confiado solo En tierra de grano y de vino: También sus cielos destilarán rocío. [^28] Bienaventurado tú, oh Israel, ¿Quién como tú, Pueblo salvo por Jehová, Escudo de tu socorro, Y espada de tu excelencia? Así que tus enemigos serán humillados, Y tú hollarás sobre sus alturas. [^29] 

[[Deuteronomy - 32|<--]] Deuteronomy - 33 [[Deuteronomy - 34|-->]]

---
# Notes
