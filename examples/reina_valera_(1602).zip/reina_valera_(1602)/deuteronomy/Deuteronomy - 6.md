---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 6 - Reina Valera (1602)"
---
[[Deuteronomy - 5|<--]] Deuteronomy - 6 [[Deuteronomy - 7|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Deuteronomy]]

# Deuteronomy - 6

ESTOS pues son los mandamientos, estatutos, y derechos que Jehová vuestro Dios mandó que os enseñase, para que los pongáis por obra en la tierra á la cual pasáis vosotros para poseerla: [^1] Para que temas á Jehová tu Dios, guardando todos sus estatutos y sus mandamientos que yo te mando, tú, y tu hijo, y el hijo de tu hijo, todos los días de tu vida, y que tus días sean prolongados. [^2] Oye pues, oh Israel, y cuida de ponerlos por obra, para que te vaya bien, y seáis multiplicados, como te ha dicho Jehová el Dios de tus padres, en la tierra que destila leche y miel. [^3] Oye, Israel: Jehová nuestro Dios, Jehová uno es: [^4] Y Amarás á Jehová tu Dios de todo tu corazón, y de toda tu alma, y con todo tu poder. [^5] Y estas palabras que yo te mando hoy, estarán sobre tu corazón: [^6] Y las repetirás á tus hijos, y hablarás de ellas estando en tu casa, y andando por el camino, y al acostarte, y cuando te levantes: [^7] Y has de atarlas por señal en tu mano, y estarán por frontales entre tus ojos: [^8] Y las escribirás en los postes de tu casa, y en tus portadas. [^9] Y será, cuando Jehová tu Dios te hubiere introducido en la tierra que juró á tus padres Abraham, Isaac, y Jacob, que te daría; en ciudades grandes y buenas que tú no edificaste, [^10] Y casas llenas de todo bien, que tú no henchiste, y cisternas cavadas, que tú no cavaste, viñas y olivares que no plantaste: luego que comieres y te hartares, [^11] Guárdate que no te olvides de Jehová, que te sacó de tierra de Egipto, de casa de siervos. [^12] A Jehová tu Dios temerás, y á él servirás, y por su nombre jurarás. [^13] No andaréis en pos de dioses ajenos, de los dioses de los pueblos que están en vuestros contornos: [^14] Porque el Dios celoso, Jehová tu Dios, en medio de ti está; porque no se inflame el furor de Jehová tu Dios contra ti, y te destruya de sobre la haz de la tierra. [^15] No tentaréis á Jehová vuestro Dios, como lo tentasteis en Massa. [^16] Guardad cuidadosamente los mandamientos de Jehová vuestro Dios, y sus testimonios, y sus estatutos, que te ha mandado. [^17] Y harás lo recto y bueno en ojos de Jehová, para que te vaya bien, y entres y poseas la buena tierra que Jehová juró á tus padres; [^18] Para que él eche á todos sus enemigos de delante de ti, como Jehová ha dicho. [^19] Cuando mañana te preguntare tu hijo, diciendo: ¿Qué significan los testimonios, y estatutos, y derechos, que Jehová nuestro Dios os mandó? [^20] Entonces dirás á tu hijo: Nosotros éramos siervos de Faraón en Egipto, y Jehová nos sacó de Egipto con mano fuerte; [^21] Y dió Jehová señales y milagros grandes y nocivos en Egipto, sobre Faraón y sobre toda su casa, delante de nuestros ojos; [^22] Y sacónos de allá, para traernos y darnos la tierra que juró á nuestros padres; [^23] Y mandónos Jehová que ejecutásemos todos estos estatutos, y que temamos á Jehová nuestro Dios, porque nos vaya bien todos los días, y para que nos dé vida, como hoy. [^24] Y tendremos justicia cuando cuidáremos de poner por obra todos estos mandamientos delante de Jehová nuestro Dios, como él nos ha mandado. [^25] 

[[Deuteronomy - 5|<--]] Deuteronomy - 6 [[Deuteronomy - 7|-->]]

---
# Notes
