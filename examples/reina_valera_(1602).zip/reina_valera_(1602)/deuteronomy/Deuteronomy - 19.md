---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 19 - Reina Valera (1602)"
---
[[Deuteronomy - 18|<--]] Deuteronomy - 19 [[Deuteronomy - 20|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Deuteronomy]]

# Deuteronomy - 19

CUANDO Jehová tu Dios talare las gentes, cuya tierra Jehová tu Dios te da á ti, y tú las heredares, y habitares en sus ciudades, y en sus casas; [^1] Te apartarás tres ciudades en medio de tu tierra que Jehová tu Dios te da para que la poseas. [^2] Arreglarte has el camino, y dividirás en tres partes el término de tu tierra, que Jehová tu Dios te dará en heredad, y será para que todo homicida se huya allí. [^3] Y este es el caso del homicida que ha de huir allí, y vivirá: el que hiriere á su prójimo por yerro, que no le tenía enemistad desde ayer ni antes de ayer: [^4] Como el que fué con su prójimo al monte á cortar leña, y poniendo fuerza con su mano en el hacha para cortar algún leño, saltó el hierro del cabo, y encontró á su prójimo, y murió; aquél huirá á una de aquestas ciudades, y vivirá; [^5] No sea que el pariente del muerto vaya tras el homicida, cuando se enardeciere su corazón, y le alcance por ser largo el camino, y le hiera de muerte, no debiendo ser condenado á muerte; por cuanto no tenía enemistad desde ayer ni antes de ayer con el muerto. [^6] Por tanto yo te mando, diciendo: Tres ciudades te apartarás. [^7] Y si Jehová tu Dios ensanchare tu término, como lo juró á tus padres, y te diere toda la tierra que dijo á tus padres que había de dar; [^8] Cuando guardases todos estos mandamientos, que yo te prescribo hoy, para ponerlos por obra, que ames á Jehová tu Dios y andes en sus caminos todos los días, entonces añadirás tres ciudades á más de estas tres; [^9] Porque no sea derramada sangre inocente en medio de tu tierra, que Jehová tu Dios te da por heredad, y sea sobre ti sangre. [^10] Mas cuando hubiere alguno que aborreciere á su prójimo, y lo acechare, y se levantare sobre él, y lo hiriere de muerte, y muriere, y huyere á alguna de estas ciudades; [^11] Entonces los ancianos de su ciudad enviarán y lo sacarán de allí, y entregarlo han en mano del pariente del muerto, y morirá. [^12] No le perdonará tu ojo: y quitarás de Israel la sangre inocente, y te irá bien. [^13] No reducirás el término de tu prójimo, el cual señalaron los antiguos en tu heredad, la que poseyeres en la tierra que Jehová tu Dios te da para que la poseas. [^14] No valdrá un testigo contra ninguno en cualquier delito, ó en cualquier pecado, en cualquier pecado que se cometiere. En el dicho de dos testigos, ó en el dicho de tres testigos consistirá el negocio. [^15] Cuando se levantare testigo falso contra alguno, para testificar contra él rebelión, [^16] Entonces los dos hombres litigantes se presentarán delante de Jehová, delante de los sacerdotes y jueces que fueren en aquellos días: [^17] Y los jueces inquirirán bien, y si pareciere ser aquél testigo falso, que testificó falsamente contra su hermano, [^18] Haréis á él como él pensó hacer á su hermano: y quitarás el mal de en medio de ti. [^19] Y los que quedaren oirán, y temerán, y no volverán más á hacer una mala cosa como ésta, en medio de ti. [^20] Y no perdonará tu ojo: vida por vida, ojo por ojo, diente por diente, mano por mano, pie por pie. [^21] 

[[Deuteronomy - 18|<--]] Deuteronomy - 19 [[Deuteronomy - 20|-->]]

---
# Notes
