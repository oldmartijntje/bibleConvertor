---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 26 - Reina Valera (1602)"
---
[[Deuteronomy - 25|<--]] Deuteronomy - 26 [[Deuteronomy - 27|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Deuteronomy]]

# Deuteronomy - 26

Y SERA que, cuando hubieres entrado en la tierra que Jehová tu Dios te da por heredad, y la poseyeres, y habitares en ella; [^1] Entonces tomarás de las primicias de todos los frutos de la tierra, que sacares de tu tierra que Jehová tu Dios te da, y lo pondrás en un canastillo, é irás al lugar que Jehová tu Dios escogiere para hacer habitar allí su nombre. [^2] Y llegarás al sacerdote que fuere en aquellos días, y le dirás: Reconozco hoy á Jehová tu Dios que he entrado en la tierra que juró Jehová á nuestros padres que nos había de dar. [^3] Y el sacerdote tomará el canastillo de tu mano, y pondrálo delante del altar de Jehová tu Dios. [^4] Entonces hablarás y dirás delante de Jehová tu Dios: Un Siro á punto de perecer fué mi padre, el cual descendió á Egipto y peregrinó allá con pocos hombres, y allí creció en gente grande, fuerte y numerosa: [^5] Y los Egipcios nos maltrataron, y nos afligieron, y pusieron sobre nosotros dura servidumbre. [^6] Y clamamos á Jehová Dios de nuestros padres; y oyó Jehová nuestra voz, y vió nuestra aflicción, y nuestro trabajo, y nuestra opresión: [^7] Y sacónos Jehová de Egipto con mano fuerte, y con brazo extendido, y con grande espanto, y con señales y con milagros: [^8] Y trájonos á este lugar, y diónos esta tierra, tierra que fluye leche y miel. [^9] Y ahora, he aquí, he traído las primicias del fruto de la tierra que me diste, oh Jehová. Y lo dejarás delante de Jehová tu Dios, é inclinarte has delante de Jehová tu Dios. [^10] Y te alegrarás con todo el bien que Jehová tu Dios te hubiere dado á ti y á tu casa, tú y el Levita, y el extranjero que está en medio de ti. [^11] Cuando hubieres acabado de diezmar todo el diezmo de tus frutos en el año tercero, el año del diezmo, darás también al Levita, al extranjero, al huérfano y á la viuda; y comerán en tus villas, y se saciarán. [^12] Y dirás delante de Jehová tu Dios: Yo he sacado lo consagrado de mi casa, y también lo he dado al Levita, y al extranjero, y al huérfano, y á la viuda, conforme á todos tus mandamientos que me ordenaste: no he traspasado tus mandamientos, ni me he olvidado de ellos: [^13] No he comido de ello en mi luto, ni he sacado de ello en inmundicia, ni de ello he dado para mortuorio: he obedecido á la voz de Jehová mi Dios, he hecho conforme á todo lo que me has mandado. [^14] Mira desde la morada de tu santidad, desde el cielo, y bendice á tu pueblo Israel, y á la tierra que nos has dado, como juraste á nuestros padres, tierra que fluye leche y miel. [^15] Jehová tu Dios te manda hoy que cumplas estos estatutos y derechos; cuida, pues, de ponerlos por obra con todo tu corazón, y con toda tu alma. [^16] A Jehová has ensalzado hoy para que te sea por Dios, y para andar en sus caminos, y para guardar sus estatutos y sus mandamientos y sus derechos, y para oir su voz: [^17] Y Jehová te ha ensalzado hoy para que le seas su peculiar pueblo, como él te lo he dicho, y para que guardes todos sus mandamientos; [^18] Y para ponerte alto sobre todas las gentes que hizo, para loor, y fama, y gloria; y para que seas pueblo santo á Jehová tu Dios, como él ha dicho. [^19] 

[[Deuteronomy - 25|<--]] Deuteronomy - 26 [[Deuteronomy - 27|-->]]

---
# Notes
