---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 15 - Reina Valera (1602)"
---
[[Deuteronomy - 14|<--]] Deuteronomy - 15 [[Deuteronomy - 16|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Deuteronomy]]

# Deuteronomy - 15

AL cabo de siete años harás remisión. [^1] Y esta es la manera de la remisión: perdonará á su deudor todo aquél que hizo empréstito de su mano, con que obligó á su prójimo: no lo demandará más á su prójimo, ó á su hermano; porque la remisión de Jehová es pregonada. [^2] Del extranjero demandarás el reintegro: mas lo que tu hermano tuviere tuyo, lo perdonará tu mano; [^3] Para que así no haya en ti mendigo; porque Jehová te bendecirá con abundancia en la tierra que Jehová tu Dios te da por heredad para que la poseas, [^4] Si empero escuchares fielmente la voz de Jehová tu Dios, para guardar y cumplir todos estos mandamientos que yo te intimo hoy. [^5] Ya que Jehová tu Dios te habrá bendecido, como te ha dicho, prestarás entonces á muchas gentes, mas tú no tomarás prestado; y enseñorearte has de muchas gentes, pero de ti no se enseñorearán. [^6] Cuando hubiere en ti menesteroso de alguno de tus hermanos en alguna de tus ciudades, en tu tierra que Jehová tu Dios te da, no endurecerás tu corazón, ni cerrarás tu mano á tu hermano pobre: [^7] Mas abrirás á él tu mano liberalmente, y en efecto le prestarás lo que basta, lo que hubiere menester. [^8] Guárdate que no haya en tu corazón perverso pensamiento, diciendo: Cerca está el año séptimo, el de la remisión; y tu ojo sea maligno sobre tu hermano menesteroso para no darle: que él podrá clamar contra ti á Jehová, y se te imputará á pecado. [^9] Sin falta le darás, y no sea tu corazón maligno cuando le dieres: que por ello te bendecirá Jehová tu Dios en todos tus hechos, y en todo lo que pusieres mano. [^10] Porque no faltarán menesterosos de en medio de la tierra; por eso yo te mando, diciendo: Abrirás tu mano á tu hermano, á tu pobre, y á tu menesteroso en tu tierra. [^11] Cuando se vendiere á ti tu hermano Hebreo ó Hebrea, y te hubiere servido seis años, al séptimo año le despedirás libre de ti. [^12] Y cuando lo despidieres libre de ti, no lo enviarás vacío: [^13] Le abastecerás liberalmente de tus ovejas, de tu era, y de tu lagar; le darás de aquello en que Jehová te hubiere bendecido. [^14] Y te acordarás que fuiste siervo en la tierra de Egipto, y que Jehová tu Dios te rescató: por tanto yo te mando esto hoy. [^15] Y será que, si él te dijere: No saldré de contigo; porque te ama á ti y á tu casa, que le va bien contigo; [^16] Entonces tomarás una lesna, y horadarás su oreja junto á la puerta, y será tu siervo para siempre: así también harás á tu criada. [^17] No te parezca duro cuando le enviares libre de ti; que doblado del salario de mozo jornalero te sirvió seis años: y Jehová tu Dios te bendecirá en todo cuanto hicieres. [^18] Santificarás á Jehová tu Dios todo primerizo macho que nacerá de tus vacas y de tus ovejas: no te sirvas del primerizo de tus vacas, ni trasquiles el primerizo de tus ovejas. [^19] Delante de Jehová tu Dios los comerás cada un año, tú y tu familia, en el lugar que Jehová escogiere. [^20] Y si hubiere en él tacha, ciego ó cojo, ó cualquiera mala falta, no lo sacrificarás á Jehová tu Dios. [^21] En tus poblaciones lo comerás: el inmundo lo mismo que el limpio comerán de él, como de un corzo ó de un ciervo. [^22] Solamente que no comas su sangre: sobre la tierra la derramarás como agua. [^23] 

[[Deuteronomy - 14|<--]] Deuteronomy - 15 [[Deuteronomy - 16|-->]]

---
# Notes
