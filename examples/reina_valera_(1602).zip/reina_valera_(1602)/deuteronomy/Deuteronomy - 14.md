---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 14 - Reina Valera (1602)"
---
[[Deuteronomy - 13|<--]] Deuteronomy - 14 [[Deuteronomy - 15|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Deuteronomy]]

# Deuteronomy - 14

HIJOS sois de Jehová vuestro Dios: no os sajaréis, ni pondréis calva sobre vuestros ojos por muerto; [^1] Porque eres pueblo santo á Jehová tu Dios, y Jehová te ha escogido para que le seas un pueblo singular de entre todos los pueblos que están sobre la haz de la tierra. [^2] Nada abominable comerás. [^3] Estos son los animales que comeréis: el buey, la oveja, y la cabra, [^4] El ciervo, el corzo, y el búfalo, y el cabrío salvaje, y el unicornio, y buey salvaje, y cabra montés. [^5] Y todo animal de pezuñas, que tiene hendidura de dos uñas, y que rumiare entre los animales, ese comeréis. [^6] Empero estos no comeréis de los que rumian, ó tienen uña hendida: camello, y liebre, y conejo, porque rumian, mas no tienen uña hendida, os serán inmundos; [^7] Ni puerco: porque tiene uña hendida, mas no rumia, os será inmundo. De la carne de éstos no comeréis, ni tocaréis sus cuerpos muertos. [^8] Esto comeréis de todo lo que está en el agua: todo lo que tiene aleta y escama comeréis; [^9] Mas todo lo que no tuviere aleta y escama, no comeréis: inmundo os será. [^10] Toda ave limpia comeréis. [^11] Y estas son de las que no comeréis: el águila, y el azor, y el esmerejón, [^12] Y el ixio, y el buitre, y el milano según su especie, [^13] Y todo cuervo según su especie, [^14] Y el búho, y la lechuza, y el cuclillo, y el halcón según su especie, [^15] Y el herodión, y el cisne, y el ibis, [^16] Y el somormujo, y el calamón, y el corvejón, [^17] Y la cigüeña, y la garza según su especie, y la abubilla, y el murciélago. [^18] Y todo reptil alado os será inmundo: no se comerá. [^19] Toda ave limpia comeréis. [^20] Ninguna cosa mortecina comeréis: al extranjero que está en tus poblaciones la darás, y él la comerá: ó véndela al extranjero; porque tú eres pueblo santo á Jehová tu Dios. No cocerás el cabrito en la leche de su madre. [^21] Indispensablemente diezmarás todo el producto de tu simiente, que rindiere el campo cada un año. [^22] Y comerás delante de Jehová tu Dios en el lugar que él escogiere para hacer habitar allí su nombre, el diezmo de tu grano, de tu vino, y de tu aceite, y los primerizos de tus manadas, y de tus ganados, para que aprendas á temer á Jehová tu Dios todos los días. [^23] Y si el camino fuere tan largo que tú no puedas llevarlo por él, por estar lejos de ti el lugar que Jehová tu Dios hubiere escogido para poner en él su nombre, cuando Jehová tu Dios te bendijere, [^24] Entonces venderlo has, y atarás el dinero en tu mano, y vendrás al lugar que Jehová tu Dios escogiere; [^25] Y darás el dinero por todo lo que deseare tu alma, por vacas, ó por ovejas, ó por vino, ó por sidra, ó por cualquier cosa que tu alma te demandare: y comerás allí delante de Jehová tu Dios, y te alegrarás tú y tu familia. [^26] Y no desampararás al Levita que habitare en tus poblaciones; porque no tiene parte ni heredad contigo. [^27] Al cabo de cada tres años sacarás todo el diezmo de tus productos de aquel año, y lo guardarás en tus ciudades: [^28] Y vendrá el Levita, que no tiene parte ni heredad contigo, y el extranjero, y el huérfano, y la viuda, que hubiere en tus poblaciones, y comerán y serán saciados; para que Jehová tu Dios te bendiga en toda obra de tus manos que hicieres. [^29] 

[[Deuteronomy - 13|<--]] Deuteronomy - 14 [[Deuteronomy - 15|-->]]

---
# Notes
