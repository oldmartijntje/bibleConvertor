---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 23 - Reina Valera (1602)"
---
[[Deuteronomy - 22|<--]] Deuteronomy - 23 [[Deuteronomy - 24|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Deuteronomy]]

# Deuteronomy - 23

NO entrará en la congregación de Jehová el que fuere quebrado, ni el castrado. [^1] No entrará bastardo en la congregación de Jehová: ni aun en la décima generación entrará en la congregación de Jehová. [^2] No entrará Ammonita ni Moabita en la congregación de Jehová; ni aun en la décima generación entrará en la congregación de Jehová para siempre: [^3] Por cuanto no os salieron á recibir con pan y agua al camino, cuando salisteis de Egipto; y porque alquiló contra ti á Balaam hijo de Beor de Pethor de Mesopotamia de Siria, para que te maldijese. [^4] Mas no quiso Jehová tu Dios oir á Balaam; y Jehová tu Dios te volvió la maldición en bendición, porque Jehová tu Dios te amaba. [^5] No procurarás la paz de ellos ni su bien en todos los días para siempre. [^6] No abominarás al Idumeo, que tu hermano es: no abominarás al egipcio, que extranjero fuiste en su tierra. [^7] Los hijos que nacieren de ellos, á la tercera generación entrarán en la congregación de Jehová. [^8] Cuando salieres á campaña contra tus enemigos, guárdate de toda cosa mala. [^9] Cuando hubiere en ti alguno que no fuere limpio por accidente de noche, saldráse del campo, y no entrará en él. [^10] Y será que al declinar de la tarde se lavará con agua, y cuando fuere puesto el sol, entrará en el campo. [^11] Y tendrás un lugar fuera del real, y saldrás allá fuera; [^12] Tendrás también una estaca entre tus armas; y será que, cuando estuvieres allí fuera, cavarás con ella, y luego al volverte cubrirás tu excremento: [^13] Porque Jehová tu Dios anda por medio de tu campo, para librarte y entregar tus enemigos delante de ti; por tanto será tu real santo: porque él no vea en ti cosa inmunda, y se vuelva de en pos de ti. [^14] No entregarás á su señor el siervo que se huyere á ti de su amo: [^15] More contigo, en medio de ti, en el lugar que escogiere en alguna de tus ciudades, donde bien le estuviere: no le harás fuerza. [^16] No habrá ramera de las hijas de Israel, ni habrá sodomítico de los hijos de Israel. [^17] No traerás precio de ramera, ni precio de perro á la casa de Jehová tu Dios por ningún voto; porque abominación es á Jehová tu Dios así lo uno como lo otro. [^18] No tomarás de tu hermano logro de dinero, ni logro de comida, ni logro de cosa alguna que se suele tomar. [^19] Del extraño tomarás logro, mas de tu hermano no lo tomarás, porque te bendiga Jehová tu Dios en toda obra de tus manos sobre la tierra á la cual entras para poseerla. [^20] Cuando prometieres voto á Jehová tu Dios, no tardarás en pagarlo; porque ciertamente lo demandará Jehová tu Dios de ti, y habría en ti pecado. [^21] Mas cuando te abstuvieres de prometer, no habrá en ti pecado. [^22] Guardarás lo que tus labios pronunciaren; y harás, como prometiste á Jehová tu Dios, lo que de tu voluntad hablaste por tu boca. [^23] Cuando entrares en la viña de tu prójimo, comerás uvas hasta saciar tu deseo: mas no pondrás en tu vaso. [^24] Cuando entrares en la mies de tu prójimo, podrás cortar espigas con tu mano; mas no aplicarás hoz á la mies de tu prójimo. [^25] 

[[Deuteronomy - 22|<--]] Deuteronomy - 23 [[Deuteronomy - 24|-->]]

---
# Notes
