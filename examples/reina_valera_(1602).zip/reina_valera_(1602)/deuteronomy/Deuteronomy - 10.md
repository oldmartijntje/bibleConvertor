---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 10 - Reina Valera (1602)"
---
[[Deuteronomy - 9|<--]] Deuteronomy - 10 [[Deuteronomy - 11|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Deuteronomy]]

# Deuteronomy - 10

EN aquel tiempo Jehová me dijo: Lábrate dos tablas de piedra como las primeras, y sube á mí al monte, y hazte un arca de madera: [^1] Y escribiré en aquellas tablas palabras que estaban en las tablas primeras que quebraste; y las pondrás en el arca. [^2] E hice un arca de madera de Sittim, y labré dos tablas de piedra como las primeras, y subí al monte con las dos tablas en mi mano. [^3] Y escribió en las tablas conforme á la primera escritura, las diez palabras que Jehová os había hablado en el monte de en medio del fuego, el día de la asamblea; y diómelas Jehová. [^4] Y volví y descendí del monte, y puse las tablas en el arca que había hecho; y allí están, como Jehová me mandó. [^5] (Después partieron los hijos de Israel de Beerot-bene-jacaam á Moserá: allí murió Aarón, y allí fué sepultado; y en lugar suyo tuvo el sacerdocio su hijo Eleazar. [^6] De allí partieron á Gudgod, y de Gudgod á Jotbath, tierra de arroyos de aguas. [^7] En aquel tiempo apartó Jehová la tribu de Leví, para que llevase el arca del pacto de Jehová, para que estuviese delante de Jehová para servirle, y para bendecir en su nombre, hasta hoy. [^8] Por lo cual Leví no tuvo parte ni heredad con sus hermanos: Jehová es su heredad, como Jehová tu Dios le dijo.) [^9] Y yo estuve en el monte como los primeros días, cuarenta días y cuarenta noches; y Jehová me oyó también esta vez, y no quiso Jehová destruirte. [^10] Y díjome Jehová: Levántate, anda, para que partas delante del pueblo, para que entren y posean la tierra que juré á sus padres les había de dar. [^11] Ahora pues, Israel, ¿qué pide Jehová tu Dios de ti, sino que temas á Jehová tu Dios, que andes en todos sus caminos, y que lo ames, y sirvas á Jehová tu Dios con todo tu corazón, y con toda tu alma; [^12] Que guardes los mandamientos de Jehová y sus estatutos, que yo te prescribo hoy, para que hayas bien? [^13] He aquí, de Jehová tu Dios son los cielos, y los cielos de los cielos: la tierra, y todas las cosas que hay en ella. [^14] Solamente de tus padres se agradó Jehová para amarlos, y escogió su simiente después de ellos, á vosotros, de entre todos los pueblos, como en este día. [^15] Circuncidad pues el prepucio de vuestro corazón, y no endurezcáis más vuestra cerviz. [^16] Porque Jehová vuestro Dios es Dios de dioses, y Señor de señores, Dios grande, poderoso, y terrible, que no acepta persona, ni toma cohecho; [^17] Que hace justicia al huérfano y á la viuda; que ama también al extranjero dándole pan y vestido. [^18] Amaréis pues al extranjero: porque extranjeros fuisteis vosotros en tierra de Egipto. [^19] A Jehová tu Dios temerás, á él servirás, á él te allegarás, y por su nombre jurarás. [^20] El es tu alabanza, y él es tu Dios, que ha hecho contigo estas grandes y terribles cosas que tus ojos han visto. [^21] Con setenta almas descendieron tus padres á Egipto; y ahora Jehová te ha hecho como las estrellas del cielo en multitud. [^22] 

[[Deuteronomy - 9|<--]] Deuteronomy - 10 [[Deuteronomy - 11|-->]]

---
# Notes
