---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 34 - Reina Valera (1602)"
---
[[Deuteronomy - 33|<--]] Deuteronomy - 34

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Deuteronomy]]

# Deuteronomy - 34

Y SUBIO Moisés de los campos de Moab al monte de Nebo, á la cumbre de Pisga, que está enfrente de Jericó: y mostróle Jehová toda la tierra de Galaad hasta Dan, [^1] Y á todo Nephtalí, y la tierra de Ephraim y de Manasés, toda la tierra de Judá hasta la mar postrera; [^2] Y la parte meridional, y la campiña, la vega de Jericó, ciudad de las palmas, hasta Soar. [^3] Y díjole Jehová: Esta es la tierra de que juré á Abraham, á Isaac, y á Jacob, diciendo: A tu simiente la daré. Hétela hecho ver con tus ojos, mas no pasarás allá. [^4] Y murió allí Moisés siervo de Jehová, en la tierra de Moab, conforme al dicho de Jehová. [^5] Y enterrólo en el valle, en tierra de Moab, enfrente de Bethpeor; y ninguno sabe su sepulcro hasta hoy. [^6] Y era Moisés de edad de ciento y veinte años cuando murió: sus ojos nunca se oscurecieron, ni perdió su vigor. [^7] Y lloraron los hijos de Israel á Moisés en los campos de Moab treinta días: Y así se cumplieron los días del lloro del luto de Moisés. [^8] Y Josué hijo de Nun fué lleno de espíritu de sabiduría, porque Moisés había puesto sus manos sobre él: y los hijos de Israel le obedecieron, é hicieron como Jehová mandó á Moisés. [^9] Y nunca más se levantó profeta en Israel como Moisés, á quien haya conocido Jehová cara á cara; [^10] En todas las señales y prodigios que le envió Jehová á hacer en tierra de Egipto á Faraón, y á todos sus siervos, y á toda su tierra; [^11] Y en toda aquella mano esforzada, y en todo el espanto grande que causó Moisés á ojos de todo Israel. [^12] 

[[Deuteronomy - 33|<--]] Deuteronomy - 34

---
# Notes
