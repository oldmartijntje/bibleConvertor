---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 4 - Reina Valera (1602)"
---
[[Job - 3|<--]] Job - 4 [[Job - 5|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 4

Y RESPONDIO Eliphaz el Temanita, y dijo: [^1] Si probáremos á hablarte, serte ha molesto; Mas ¿quién podrá detener las palabras? [^2] He aquí, tú enseñabas á muchos, Y las manos flacas corroborabas; [^3] Al que vacilaba, enderezaban tus palabras, Y esforzabas las rodillas que decaían. [^4] Mas ahora que el mal sobre ti ha venido, te es duro; Y cuando ha llegado hasta ti, te turbas. [^5] ¿Es este tu temor, tu confianza, Tu esperanza, y la perfección de tus caminos? [^6] Recapacita ahora, ¿quién que fuera inocente se perdiera? Y ¿en dónde los rectos fueron cortados? [^7] Como yo he visto, los que aran iniquidad Y siembran injuria, la siegan. [^8] Perecen por el aliento de Dios, Y por el espíritu de su furor son consumidos. [^9] El bramido del león, y la voz del león, Y los dientes de los leoncillos son quebrantados. [^10] El león viejo perece por falta de presa, Y los hijos del león son esparcidos. [^11] El negocio también me era á mí oculto; Mas mi oído ha percibido algo de ello. [^12] En imaginaciones de visiones nocturnas, Cuando el sueño cae sobre los hombres, [^13] Sobrevínome un espanto y un temblor, Que estremeció todos mis huesos: [^14] Y un espíritu pasó por delante de mí, Que hizo se erizara el pelo de mi carne. [^15] Paróse un fantasma delante de mis ojos, Cuyo rostro yo no conocí, Y quedo, oí que decía: [^16] ¿Si será el hombre más justo que Dios? ¿Si será el varón más limpio que el que lo hizo? [^17] He aquí que en sus siervos no confía, Y notó necedad en sus ángeles [^18] Cuánto más en los que habitan en casas de lodo, Cuyo fundamento está en el polvo, Y que serán quebrantados de la polilla! [^19] De la mañana á la tarde son quebrantados, Y se pierden para siempre, sin haber quien lo considere. [^20] ¿Su hermosura, no se pierde con ellos mismos? Mueren, y sin sabiduría. [^21] 

[[Job - 3|<--]] Job - 4 [[Job - 5|-->]]

---
# Notes
