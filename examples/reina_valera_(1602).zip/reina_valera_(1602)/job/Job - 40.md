---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 40 - Reina Valera (1602)"
---
[[Job - 39|<--]] Job - 40 [[Job - 41|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 40

A más de eso respondió Jehová á Job y dijo: [^1] ¿Es sabiduría contender con el Omnipotente? El que disputa con Dios, responda á esto. [^2] Y respondió Job á Jehová, y dijo: [^3] He aquí que yo soy vil, ¿qué te responderé? Mi mano pongo sobre mi boca. [^4] Una vez hablé, y no responderé: Aun dos veces, mas no tornaré á hablar. [^5] ENTONCES respondió Jehová á Job desde la oscuridad, y dijo: [^6] Cíñete ahora como varón tus lomos; Yo te preguntaré, y explícame. [^7] ¿Invalidarás tú también mi juicio? ¿Me condenarás á mí, para justificarte á ti? [^8] ¿Tienes tú brazo como Dios? ¿Y tronarás tú con voz como él? [^9] Atavíate ahora de majestad y de alteza: Y vístete de honra y de hermosura. [^10] Esparce furores de tu ira: Y mira á todo soberbio, y abátelo. [^11] Mira á todo soberbio, y humíllalo, Y quebranta á los impíos en su asiento. [^12] Encúbrelos á todos en el polvo, Venda sus rostros en la oscuridad; [^13] Y yo también te confesaré Que podrá salvarte tu diestra. [^14] He aquí ahora behemoth, al cual yo hice contigo; Hierba come como buey. [^15] He aquí ahora que su fuerza está en sus lomos, Y su fortaleza en el ombligo de su vientre. [^16] Su cola mueve como un cedro, Y los nervios de sus genitales son entretejidos. [^17] Sus huesos son fuertes como bronce, Y sus miembros como barras de hierro. [^18] El es la cabeza de los caminos de Dios: El que lo hizo, puede hacer que su cuchillo á él se acerque. [^19] Ciertamente los montes producen hierba para él: Y toda bestia del campo retoza allá. [^20] Echaráse debajo de las sombras, En lo oculto de las cañas, y de los lugares húmedos. [^21] Los árboles sombríos lo cubren con su sombra; Los sauces del arroyo lo cercan. [^22] He aquí que él tomará el río sin inmutarse: Y confíase que el Jordán pasará por su boca. [^23] ¿Tomarálo alguno por sus ojos en armadijos, Y horadará su nariz? [^24] 

[[Job - 39|<--]] Job - 40 [[Job - 41|-->]]

---
# Notes
