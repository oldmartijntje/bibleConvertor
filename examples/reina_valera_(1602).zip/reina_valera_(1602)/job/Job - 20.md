---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 20 - Reina Valera (1602)"
---
[[Job - 19|<--]] Job - 20 [[Job - 21|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 20

Y RESPONDIO Sophar Naamathita, y dijo: [^1] Por cierto mis pensamientos me hacen responder, Y por tanto me apresuro. [^2] La reprensión de mi censura he oído, Y háceme responder el espíritu de mi inteligencia. [^3] ¿No sabes esto que fué siempre, Desde el tiempo que fué puesto el hombre sobre la tierra, [^4] Que la alegría de los impíos es breve, Y el gozo del hipócrita por un momento? [^5] Si subiere su altivez hasta el cielo, Y su cabeza tocare en las nubes, [^6] Con su estiércol perecerá para siempre: Los que le hubieren visto, dirán: ¿Qué es de él? [^7] Como sueño volará, y no será hallado: Y disiparáse como visión nocturna. [^8] El ojo que le habrá visto, nunca más le verá; Ni su lugar le echará más de ver. [^9] Sus hijos pobres andarán rogando; Y sus manos tornarán lo que él robó. [^10] Sus huesos están llenos de sus mocedades, Y con él serán sepultados en el polvo. [^11] Si el mal se endulzó en su boca, Si lo ocultaba debajo de su lengua; [^12] Si le parecía bien, y no lo dejaba, Mas antes lo detenía entre su paladar; [^13] Su comida se mudará en sus entrañas, Hiel de áspides será dentro de él. [^14] Devoró riquezas, mas vomitarálas; De su vientre las sacará Dios. [^15] Veneno de áspides chupará; Matarálo lengua de víbora. [^16] No verá los arroyos, los ríos, Los torrentes de miel y de manteca. [^17] Restituirá el trabajo conforme á la hacienda que tomó; Y no tragará, ni gozará. [^18] Por cuanto quebrantó y desamparó á los pobres, Robó casas, y no las edificó; [^19] Por tanto, no sentirá él sosiego en su vientre, Ni salvará nada de lo que codiciaba. [^20] No quedó nada que no comiese: Por tanto su bien no será durable. [^21] Cuando fuere lleno su bastimento, tendrá angustia: Las manos todas de los malvados vendrán sobre él. [^22] Cuando se pusiere á henchir su vientre, Dios enviará sobre él el furor de su ira, Y harála llover sobre él y sobre su comida. [^23] Huirá de las armas de hierro, Y el arco de acero le atravesará. [^24] Desenvainará y sacará saeta de su aljaba, Y relumbrante pasará por su hiel: Sobre él vendrán terrores. [^25] Todas tinieblas están guardadas para sus secretos: Fuego no soplado lo devorará; Su sucesor será quebrantado en su tienda. [^26] Los cielos descubrirán su iniquidad, Y la tierra se levantará contra él. [^27] Los renuevos de su casa serán trasportados; Serán derramados en el día de su furor. [^28] Esta es la parte que Dios apareja al hombre impío, Y la heredad que Dios le señala por su palabra. [^29] 

[[Job - 19|<--]] Job - 20 [[Job - 21|-->]]

---
# Notes
