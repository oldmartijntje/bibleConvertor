---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 25 - Reina Valera (1602)"
---
[[Job - 24|<--]] Job - 25 [[Job - 26|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 25

Y RESPONDIO Bildad Suhita, y dijo: [^1] El señorío y el temor están con él: El hace paz en sus alturas. [^2] ¿Tienen sus ejércitos número? ¿Y sobre quién no está su luz? [^3] ¿Cómo pues se justificará el hombre con Dios? ¿Y cómo será limpio el que nace de mujer? [^4] He aquí que ni aun la misma luna será resplandeciente, Ni las estrellas son limpias delante de sus ojos. [^5] ¿Cuánto menos el hombre que es un gusano, Y el hijo de hombre, también gusano? [^6] 

[[Job - 24|<--]] Job - 25 [[Job - 26|-->]]

---
# Notes
