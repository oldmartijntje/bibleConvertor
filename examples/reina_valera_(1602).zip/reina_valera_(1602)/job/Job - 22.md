---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 22 - Reina Valera (1602)"
---
[[Job - 21|<--]] Job - 22 [[Job - 23|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 22

Y RESPONDIO Eliphaz Temanita, y dijo: [^1] ¿Traerá el hombre provecho á Dios, Porque el sabio sea provechoso á sí mismo? [^2] ¿Tiene su contentamiento el Omnipotente en que tú seas justificado, O provecho de que tú hagas perfectos tus caminos? [^3] ¿Castigaráte acaso, O vendrá contigo á juicio porque te teme? [^4] Por cierto tu malicia es grande, Y tus maldades no tienen fin. [^5] Porque sacaste prenda á tus hermanos sin causa, E hiciste desnudar las ropas de los desnudos. [^6] No diste de beber agua al cansado, Y detuviste el pan al hambriento. [^7] Empero el hombre pudiente tuvo la tierra; Y habitó en ella el distinguido. [^8] Las viudas enviaste vacías, Y los brazos de los huérfanos fueron quebrados. [^9] Por tanto hay lazos alrededor de ti, Y te turba espanto repentino; [^10] O tinieblas, porque no veas; Y abundancia de agua te cubre. [^11] ¿No está Dios en la altura de los cielos? Mira lo encumbrado de las estrellas, cuán elevadas están. [^12] ¿Y dirás tú: Qué sabe Dios? ¿Cómo juzgará por medio de la oscuridad? [^13] Las nubes son su escondedero, y no ve; Y por el circuito del cielo se pasea. [^14] ¿Quieres tú guardar la senda antigua, Que pisaron los hombres perversos? [^15] Los cuales fueron cortados antes de tiempo, Cuyo fundamento fué como un río derramado: [^16] Que decían á Dios: Apártate de nosotros. ¿Y qué les había hecho el Omnipotente? [^17] Habíales él henchido sus casas de bienes. Sea empero el consejo de ellos lejos de mí. [^18] Verán los justos y se gozarán; Y el inocente los escarnecerá, diciendo: [^19] Fué cortada nuestra sustancia, Habiendo consumido el fuego el resto de ellos. [^20] Amístate ahora con él, y tendrás paz; Y por ello te vendrá bien. [^21] Toma ahora la ley de su boca, Y pon sus palabras en tu corazón. [^22] Si te tornares al Omnipotente, serás edificado; Alejarás de tu tienda la aflicción; [^23] Y tendrás más oro que tierra, Y como piedras de arroyos oro de Ophir; [^24] Y el Todopoderoso será tu defensa, Y tendrás plata á montones. [^25] Porque entonces te deleitarás en el Omnipotente, Y alzarás á Dios tu rostro. [^26] Orarás á él, y él te oirá; Y tú pagarás tus votos. [^27] Determinarás asimismo una cosa, y serte ha firme; Y sobre tus caminos resplandecerá luz. [^28] Cuando fueren abatidos, dirás tú: Ensalzamiento habrá: Y Dios salvará al humilde de ojos. [^29] El libertará la isla del inocente; Y por la limpieza de tus manos será librada. [^30] 

[[Job - 21|<--]] Job - 22 [[Job - 23|-->]]

---
# Notes
