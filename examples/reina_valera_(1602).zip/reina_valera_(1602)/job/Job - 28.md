---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 28 - Reina Valera (1602)"
---
[[Job - 27|<--]] Job - 28 [[Job - 29|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 28

CIERTAMENTE la plata tiene sus veneros, Y el oro lugar donde se forma. [^1] El hierro se saca del polvo, Y de la piedra es fundido el metal. [^2] A las tinieblas puso término, Y examina todo á la perfección, Las piedras que hay en la oscuridad y en la sombra de muerte. [^3] Brota el torrente de junto al morador, Aguas que el pie había olvidado: Sécanse luego, vanse del hombre. [^4] De la tierra nace el pan, Y debajo de ella estará como convertida en fuego. [^5] Lugar hay cuyas piedras son zafiro, Y sus polvos de oro. [^6] Senda que nunca la conoció ave, Ni ojo de buitre la vió: [^7] Nunca la pisaron animales fieros, Ni león pasó por ella. [^8] En el pedernal puso su mano, Y trastornó los montes de raíz. [^9] De los peñascos cortó ríos, Y sus ojos vieron todo lo preciado. [^10] Detuvo los ríos en su nacimiento, E hizo salir á luz lo escondido. [^11] Empero ¿dónde se hallará la sabiduría? ¿Y dónde está el lugar de la prudencia? [^12] No conoce su valor el hombre, Ni se halla en la tierra de los vivientes. [^13] El abismo dice: No está en mí: Y la mar dijo: Ni conmigo. [^14] No se dará por oro, Ni su precio será á peso de plata. [^15] No puede ser apreciada con oro de Ophir, Ni con onique precioso, ni con zafiro. [^16] El oro no se le igualará, ni el diamante; Ni se trocará por vaso de oro fino. [^17] De coral ni de perlas no se hará mención: La sabiduría es mejor que piedras preciosas. [^18] No se igualará con ella esmeralda de Ethiopía; No se podrá apreciar con oro fino. [^19] ¿De dónde pues vendrá la sabiduría? ¿Y dónde está el lugar de la inteligencia? [^20] Porque encubierta está á los ojos de todo viviente, y á toda ave del cielo es oculta. [^21] El infierno y la muerte dijeron: Su fama hemos oído con nuestros oídos. [^22] Dios entiende el camino de ella, Y él conoce su lugar. [^23] Porque él mira hasta los fines de la tierra, Y ve debajo de todo el cielo. [^24] Al dar peso al viento, Y poner las aguas por medida; [^25] Cuando él hizo ley á la lluvia, Y camino al relámpago de los truenos: [^26] Entonces la veía él, y la manifestaba: Preparóla y descubrióla también. [^27] Y dijo al hombre: He aquí que el temor del Señor es la sabiduría, Y el apartarse del mal la inteligencia. [^28] 

[[Job - 27|<--]] Job - 28 [[Job - 29|-->]]

---
# Notes
