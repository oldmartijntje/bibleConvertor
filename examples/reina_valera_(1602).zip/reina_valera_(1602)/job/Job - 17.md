---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 17 - Reina Valera (1602)"
---
[[Job - 16|<--]] Job - 17 [[Job - 18|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 17

MI ALIENTO está corrompido, acórtanse mis días, Y me está aparejado el sepulcro. [^1] No hay conmigo sino escarnecedores, En cuya acrimonia se detienen mis ojos. [^2] Pon ahora, dame fianza para litigar contigo: ¿Quién tocará ahora mi mano? [^3] Porque á éstos has tú escondido su corazón de inteligencia: Por tanto, no los ensalzarás. [^4] El que denuncia lisonjas á sus prójimos, Los ojos de sus hijos desfallezcan. [^5] El me ha puesto por parábola de pueblos, Y delante de ellos he sido como tamboril. [^6] Y mis ojos se oscurecieron de desabrimiento, Y mis pensamientos todos son como sombra. [^7] Los rectos se maravillarán de esto, Y el inocente se levantará contra el hipócrita. [^8] No obstante, proseguirá el justo su camino, Y el limpio de manos aumentará la fuerza. [^9] Mas volved todos vosotros, y venid ahora, Que no hallaré entre vosotros sabio. [^10] Pasáronse mis días, fueron arrancados mis pensamientos, Los designios de mi corazón. [^11] Pusieron la noche por día, Y la luz se acorta delante de las tinieblas. [^12] Si yo espero, el sepulcro es mi casa: Haré mi cama en las tinieblas. [^13] A la huesa tengo dicho: Mi padre eres tú; A los gusanos: Mi madre y mi hermana. [^14] ¿Dónde pues estará ahora mi esperanza? Y mi esperanza ¿quién la verá? [^15] A los rincones de la huesa descenderán, Y juntamente descansarán en el polvo. [^16] 

[[Job - 16|<--]] Job - 17 [[Job - 18|-->]]

---
# Notes
