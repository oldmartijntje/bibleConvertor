---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 42 - Reina Valera (1602)"
---
[[Job - 41|<--]] Job - 42

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 42

Y RESPONDIO Job á Jehová, y dijo: [^1] Yo conozco que todo lo puedes, Y que no hay pensamiento que se esconda de ti. [^2] ¿Quién es el que oscurece el consejo sin ciencia? Por tanto yo denunciaba lo que no entendía; Cosas que me eran ocultas, y que no las sabía. [^3] Oye te ruego, y hablaré; Te preguntaré, y tú me enseñarás. [^4] De oídas te había oído; Mas ahora mis ojos te ven. [^5] Por tanto me aborrezco, y me arrepiento En el polvo y en la ceniza. [^6] Y aconteció que después que habló Jehová estas palabras á Job, Jehová dijo á Eliphaz Temanita: Mi ira se encendió contra ti y tus dos compañeros: porque no habéis hablado por mí lo recto, como mi siervo Job. [^7] Ahora pues, tomaos siete becerros y siete carneros, y andad á mi siervo Job, y ofreced holocausto por vosotros, y mi siervo Job orará por vosotros; porque de cierto á él atenderé para no trataros afrentosamente, por cuanto no habéis hablado por mí con rectitud, como mi siervo Job. [^8] Fueron pues Eliphaz Temanita, y Bildad Suhita, y Sophar Naamatita, é hicieron como Jehová les dijo: y Jehová atendió á Job. [^9] Y mudó Jehová la aflicción de Job, orando él por sus amigos: y aumentó al doble todas las cosas que habían sido de Job. [^10] Y vinieron é él todos sus hermanos, y todas sus hermanas, y todos los que antes le habían conocido, y comieron con él pan en su casa, y condoliéronse de él, y consoláronle de todo aquel mal que sobre él había Jehová traído; y cada uno de ellos le dió una pieza de moneda, y un zarcillo de oro. [^11] Y bendijo Jehová la postrimería de Job más que su principio; porque tuvo catorce mil ovejas, y seis mil camellos, y mil yuntas de bueyes, y mil asnas. [^12] Y tuvo siete hijos y tres hijas. [^13] Y llamó el nombre de la una, Jemimah, y el nombre de la segunda, Cesiah, y el nombre de la tercera, Keren-happuch. [^14] Y no se hallaron mujeres tan hermosas como las hijas de Job en toda la tierra: y dióles su padre herencia entre sus hermanos. [^15] Y después de esto vivió Job ciento y cuarenta años, y vió á sus hijos, y á los hijos de sus hijos, hasta la cuarta generación. [^16] Murió pues Job viejo, y lleno de días. [^17] 

[[Job - 41|<--]] Job - 42

---
# Notes
