---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 39 - Reina Valera (1602)"
---
[[Job - 38|<--]] Job - 39 [[Job - 40|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 39

¿Sabes tú el tiempo en que paren las cabras monteses? ¿O miraste tú las ciervas cuando están pariendo? [^1] ¿Contaste tú los meses de su preñez, Y sabes el tiempo cuando han de parir? [^2] Encórvanse, hacen salir sus hijos, Pasan sus dolores. [^3] Sus hijos están sanos, crecen con el pasto: Salen y no vuelven á ellas. [^4] ¿Quién echó libre al asno montés, y quién soltó sus ataduras? [^5] Al cual yo puse casa en la soledad, Y sus moradas en lugares estériles. [^6] Búrlase de la multitud de la ciudad: No oye las voces del arriero. [^7] Lo oculto de los montes es su pasto, Y anda buscando todo lo que está verde. [^8] ¿Querrá el unicornio servirte á ti, Ni quedar á tu pesebre? [^9] ¿Atarás tú al unicornio con su coyunda para el surco? ¿Labrará los valles en pos de ti? [^10] ¿Confiarás tú en él, por ser grande su fortaleza, Y le fiarás tu labor? [^11] ¿Fiarás de él que te tornará tu simiente, Y que la allegará en tu era? [^12] ¿Diste tú hermosas alas al pavo real, O alas y plumas al avestruz? [^13] El cual desampara en la tierra sus huevos, Y sobre el polvo los calienta, [^14] Y olvídase de que los pisará el pie, Y que los quebrará bestia del campo. [^15] Endurécese para con sus hijos, como si no fuesen suyos, No temiendo que su trabajo haya sido en vano: [^16] Porque le privó Dios de sabiduría, Y no le dió inteligencia. [^17] Luego que se levanta en alto, Búrlase del caballo y de su jinete. [^18] ¿Diste tú al caballo la fortaleza? ¿Vestiste tú su cerviz de relincho? [^19] ¿Le intimidarás tú como á alguna langosta? El resoplido de su nariz es formidable: [^20] Escarba la tierra, alégrase en su fuerza, Sale al encuentro de las armas: [^21] Hace burla del espanto, y no teme, Ni vuelve el rostro delante de la espada. [^22] Contra él suena la aljaba, El hierro de la lanza y de la pica: [^23] Y él con ímpetu y furor escarba la tierra, Sin importarle el sonido de la bocina; [^24] Antes como que dice entre los clarines: ­Ea! Y desde lejos huele la batalla, el grito de los capitanes, y la vocería. [^25] ¿Vuela el gavilán por tu industria, Y extiende hacia el mediodía sus alas? [^26] ¿Se remonta el águila por tu mandamiento, Y pone en alto su nido? [^27] Ella habita y está en la piedra, En la cumbre del peñasco y de la roca. [^28] Desde allí acecha la comida: Sus ojos observan de muy lejos. [^29] Sus pollos chupan la sangre: Y donde hubiere cadáveres, allí está. [^30] 

[[Job - 38|<--]] Job - 39 [[Job - 40|-->]]

---
# Notes
