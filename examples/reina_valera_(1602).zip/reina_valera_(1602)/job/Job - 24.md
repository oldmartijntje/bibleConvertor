---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 24 - Reina Valera (1602)"
---
[[Job - 23|<--]] Job - 24 [[Job - 25|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 24

PUESTO que no son ocultos los tiempos al Todopoderoso, ¿Por qué los que le conocen no ven sus días? [^1] Traspasan los términos, Roban los ganados, y apaciéntanlos. [^2] Llévanse el asno de los huérfanos; Prenden el buey de la viuda. [^3] Hacen apartar del camino á los menesterosos: Y todos los pobres de la tierra se esconden. [^4] He aquí, como asnos monteses en el desierto, Salen á su obra madrugando para robar; El desierto es mantenimiento de sus hijos. [^5] En el campo siegan su pasto, Y los impíos vendimian la viña ajena. [^6] Al desnudo hacen dormir sin ropa, Y que en el frío no tenga cobertura. [^7] Con las avenidas de los montes se mojan, Y abrazan las peñas sin tener abrigo. [^8] Quitan el pecho á los huérfanos, Y de sobre el pobre toman la prenda. [^9] Al desnudo hacen andar sin vestido, Y á los hambrientos quitan los hacecillos. [^10] De dentro de sus paredes exprimen el aceite, Pisan los lagares, y mueren de sed. [^11] De la ciudad gimen los hombres, Y claman las almas de los heridos de muerte: Mas Dios no puso estorbo. [^12] Ellos son los que, rebeldes á la luz, Nunca conocieron sus caminos, Ni estuvieron en sus veredas. [^13] A la luz se levanta el matador, mata al pobre y al necesitado, Y de noche es como ladrón. [^14] El ojo del adúltero está aguardando la noche, Diciendo: No me verá nadie: Y esconde su rostro. [^15] En las tinieblas minan las casas, Que de día para sí señalaron; No conocen la luz. [^16] Porque la mañana es á todos ellos como sombra de muerte; Si son conocidos, terrores de sombra de muerte los toman. [^17] Son instables más que la superficie de las aguas; Su porción es maldita en la tierra; No andarán por el camino de las viñas. [^18] La sequía y el calor arrebatan las aguas de la nieve; Y el sepulcro á los pecadores. [^19] Olvidaráse de ellos el seno materno; de ellos sentirán los gusanos dulzura; Nunca más habrá de ellos memoria, Y como un árbol serán los impíos quebrantados. [^20] A la mujer estéril que no paría, afligió; Y á la viuda nunca hizo bien. [^21] Mas á los fuertes adelantó con su poder: Levantóse, y no se da por segura la vida. [^22] Le dieron á crédito, y se afirmó: Sus ojos están sobre los caminos de ellos. [^23] Fueron ensalzados por un poco, mas desaparecen, Y son abatidos como cada cual: serán encerrados, Y cortados como cabezas de espigas. [^24] Y si no, ¿quién me desmentirá ahora, O reducirá á nada mis palabras? [^25] 

[[Job - 23|<--]] Job - 24 [[Job - 25|-->]]

---
# Notes
