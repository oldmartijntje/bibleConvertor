---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 14 - Reina Valera (1602)"
---
[[Job - 13|<--]] Job - 14 [[Job - 15|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 14

EL HOMBRE nacido de mujer, Corto de días, y harto de sinsabores: [^1] Que sale como una flor y es cortado; Y huye como la sombra, y no permanece. [^2] ¿Y sobre éste abres tus ojos, Y me traes á juicio contigo? [^3] ¿Quién hará limpio de inmundo? Nadie. [^4] Ciertamente sus días están determinados, y el número de sus meses está cerca de ti: Tú le pusiste términos, de los cuales no pasará. [^5] Si tú lo dejares, él dejará de ser: Entre tanto deseará, como el jornalero, su día. [^6] Porque si el árbol fuere cortado, aún queda de él esperanza; retoñecerá aún, Y sus renuevos no faltarán. [^7] Si se envejeciere en la tierra su raíz, Y su tronco fuere muerto en el polvo, [^8] Al percibir el agua reverdecerá, Y hará copa como planta. [^9] Mas el hombre morirá, y será cortado; Y perecerá el hombre, ¿y dónde estará él? [^10] Las aguas de la mar se fueron, Y agotóse el río, secóse. [^11] Así el hombre yace, y no se tornará á levantar: Hasta que no haya cielo no despertarán, Ni se levantarán de su sueño. [^12] Oh quién me diera que me escondieses en el sepulcro, Que me encubrieras hasta apaciguarse tu ira, Que me pusieses plazo, y de mí te acordaras! [^13] Si el hombre muriere, ¿volverá á vivir? Todos los días de mi edad esperaré, Hasta que venga mi mutación. [^14] Aficionado á la obra de tus manos, Llamarás, y yo te responderé. [^15] Pues ahora me cuentas los pasos, Y no das tregua á mi pecado. [^16] Tienes sellada en saco mi prevaricación, Y coacervas mi iniquidad. [^17] Y ciertamente el monte que cae se deshace, Y las peñas son traspasadas de su lugar; [^18] Las piedras son desgastadas con el agua impetuosa, Que se lleva el polvo de la tierra: de tal manera haces tú perecer la esperanza del hombre. [^19] Para siempre serás más fuerte que él, y él se va; Demudarás su rostro, y enviaráslo. [^20] Sus hijos serán honrados, y él no lo sabrá; O serán humillados, y no entenderá de ellos. [^21] Mas su carne sobre él se dolerá, Y entristecerse ha en él su alma. [^22] 

[[Job - 13|<--]] Job - 14 [[Job - 15|-->]]

---
# Notes
