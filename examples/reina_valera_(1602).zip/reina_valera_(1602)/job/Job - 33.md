---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 33 - Reina Valera (1602)"
---
[[Job - 32|<--]] Job - 33 [[Job - 34|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 33

POR tanto, Job, oye ahora mis razones, Y escucha todas mis palabras. [^1] He aquí yo abriré ahora mi boca, Y mi lengua hablará en mi garganta. [^2] Mis razones declararán la rectitud de mi corazón, Y mis labios proferirán pura sabiduría. [^3] El espíritu de Dios me hizo, Y la inspiración del Omnipotente me dió vida. [^4] Si pudieres, respóndeme: Dispón tus palabras, está delante de mí. [^5] Heme aquí á mí en lugar de Dios, conforme á tu dicho: De lodo soy yo también formado. [^6] He aquí que mi terror no te espantará, Ni mi mano se agravará sobre ti. [^7] De cierto tú dijiste á oídos míos, Y yo oí la voz de tus palabras que decían: [^8] Yo soy limpio y sin defecto; Y soy inocente, y no hay maldad en mí. [^9] He aquí que él buscó achaques contra mí, Y me tiene por su enemigo; [^10] Puso mis pies en el cepo, Y guardó todas mis sendas. [^11] He aquí en esto no has hablado justamente: Yo te responderé que mayor es Dios que el hombre. [^12] ¿Por qué tomaste pleito contra él? Porque él no da cuenta de ninguna de sus razones. [^13] Sin embargo, en una ó en dos maneras habla Dios; Mas el hombre no entiende. [^14] Por sueño de visión nocturna, Cuando el sueño cae sobre los hombres, Cuando se adormecen sobre el lecho; [^15] Entonces revela al oído de los hombres, Y les señala su consejo; [^16] Para quitar al hombre de su obra, Y apartar del varón la soberbia. [^17] Detendrá su alma de corrupción, Y su vida de que pase á cuchillo. [^18] También sobre su cama es castigado Con dolor fuerte en todos sus huesos, [^19] Que le hace que su vida aborrezca el pan, Y su alma la comida suave. [^20] Su carne desfallece sin verse, Y sus huesos, que antes no se veían, aparecen. [^21] Y su alma se acerca al sepulcro, Y su vida á los que causan la muerte. [^22] Si tuviera cerca de él Algún elocuente anunciador muy escogido, Que anuncie al hombre su deber; [^23] Que le diga que Dios tuvo de él misericordia, Que lo libró de descender al sepulcro, Que halló redención: [^24] Enterneceráse su carne más que de niño, Volverá á los días de su mocedad. [^25] Orará á Dios, y le amará, Y verá su faz con júbilo: Y él restituirá al hombre su justicia. [^26] El mira sobre los hombres; y el que dijere: Pequé, y pervertí lo recto, Y no me ha aprovechado; [^27] Dios redimirá su alma, que no pase al sepulcro, Y su vida se verá en luz. [^28] He aquí, todas estas cosas hace Dios Dos y tres veces con el hombre; [^29] Para apartar su alma del sepulcro, Y para iluminarlo con la luz de los vivientes. [^30] Escucha, Job, y óyeme; Calla, y yo hablaré. [^31] Que si tuvieres razones, respóndeme; Habla, porque yo te quiero justificar. [^32] Y si no, óyeme tú á mí; Calla, y enseñarte he sabiduría. [^33] 

[[Job - 32|<--]] Job - 33 [[Job - 34|-->]]

---
# Notes
