---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 7 - Reina Valera (1602)"
---
[[Job - 6|<--]] Job - 7 [[Job - 8|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 7

CIERTAMENTE tiempo limitado tiene el hombre sobre la tierra, Y sus días son como los días del jornalero. [^1] Como el siervo anhela la sombra, Y como el jornalero espera el reposo de su trabajo: [^2] Así poseo yo meses de vanidad, Y noches de trabajo me dieron por cuenta. [^3] Cuando estoy acostado, digo: ¿Cuándo me levantaré? Y mide mi corazón la noche, Y estoy harto de devaneos hasta el alba. [^4] Mi carne está vestida de gusanos, y de costras de polvo; Mi piel hendida y abominable. [^5] Y mis días fueron más ligeros que la lanzadera del tejedor, Y fenecieron sin esperanza. [^6] Acuérdate que mi vida es viento, Y que mis ojos no volverán á ver el bien. [^7] Los ojos de los que me ven, no me verán más: Tus ojos sobre mí, y dejaré de ser. [^8] La nube se consume, y se va: Así el que desciende al sepulcro no subirá; [^9] No tornará más á su casa, Ni su lugar le conocerá más. [^10] Por tanto yo no reprimiré mi boca; Hablaré en la angustia de mi espíritu, Y quejaréme con la amargura de mi alma. [^11] ¿Soy yo la mar, ó ballena, Que me pongas guarda? [^12] Cuando digo: Mi cama me consolará, Mi cama atenuará mis quejas; [^13] Entonces me quebrantarás con sueños, Y me turbarás con visiones. [^14] Y así mi alma tuvo por mejor el ahogamiento, Y quiso la muerte más que mis huesos. [^15] Aburríme: no he de vivir yo para siempre; Déjáme, pues que mis días son vanidad. [^16] ¿Qué es el hombre, para que lo engrandezcas, Y que pongas sobre él tu corazón, [^17] Y lo visites todas las mañanas, Y todos los momentos lo pruebes? [^18] ¿Hasta cuándo no me dejarás, Ni me soltarás hasta que trague mi saliva? [^19] Pequé, ¿qué te haré, oh Guarda de los hombres? ¿Por qué me has puesto contrario á ti, Y que á mí mismo sea pesado? [^20] ¿Y por qué no quitas mi rebelión, y perdonas mi iniquidad? Porque ahora dormiré en el polvo, Y si me buscares de mañana, ya no seré. [^21] 

[[Job - 6|<--]] Job - 7 [[Job - 8|-->]]

---
# Notes
