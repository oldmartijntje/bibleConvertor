---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 36 - Reina Valera (1602)"
---
[[Job - 35|<--]] Job - 36 [[Job - 37|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 36

Y AÑADIO Eliú, y dijo: [^1] Espérame un poco, y enseñarte he; Porque todavía tengo razones en orden á Dios. [^2] Tomaré mi noticia de lejos, Y atribuiré justicia á mi Hacedor. [^3] Porque de cierto no son mentira mis palabras; Contigo está el que es íntegro en sus conceptos. [^4] He aquí que Dios es grande, mas no desestima á nadie; Es poderoso en fuerza de sabiduría. [^5] No otorgará vida al impío, Y á los afligidos dará su derecho. [^6] No quitará sus ojos del justo; Antes bien con los reyes los pondrá en solio para siempre, Y serán ensalzados. [^7] Y si estuvieren prendidos en grillos, Y aprisionados en las cuerdas de aflicción, [^8] El les dará á conocer la obra de ellos, Y que prevalecieron sus rebeliones. [^9] Despierta además el oído de ellos para la corrección, Y díce les que se conviertan de la iniquidad. [^10] Si oyeren, y le sirvieren, Acabarán sus días en bien, y sus años en deleites. [^11] Mas si no oyeren, serán pasados á cuchillo, Y perecerán sin sabiduría. [^12] Empero los hipócritas de corazón lo irritarán más, Y no clamarán cuando él los atare. [^13] Fallecerá el alma de ellos en su mocedad, Y su vida entre los sodomitas. [^14] Al pobre librará de su pobreza, Y en la aflicción despertará su oído. [^15] Asimismo te apartaría de la boca de la angustia A lugar espacioso, libre de todo apuro; Y te asentará mesa llena de grosura. [^16] Mas tú has llenado el juicio del impío, En vez de sustentar el juicio y la justicia. [^17] Por lo cual teme que en su ira no te quite con golpe, El cual no puedas apartar de ti con gran rescate. [^18] ¿Hará él estima de tus riquezas, ni del oro, Ni de todas las fuerzas del poder? [^19] No anheles la noche, En que desaparecen los pueblos de su lugar. [^20] Guárdate, no tornes á la iniquidad; Pues ésta escogiste más bien que la aflicción. [^21] He aquí que Dios es excelso con su potencia; ¿Qué enseñador semejante á él? [^22] ¿Quién le ha prescrito su camino? ¿Y quién le dirá: Iniquidad has hecho? [^23] Acuérdate de engrandecer su obra, La cual contemplan los hombres. [^24] Los hombres todos la ven; Mírala el hombre de lejos. [^25] He aquí, Dios es grande, y nosotros no le conocemos; Ni se puede rastrear el número de sus años. [^26] El reduce las gotas de las aguas, Al derramarse la lluvia según el vapor; [^27] Las cuales destilan las nubes, Goteando en abundancia sobre los hombres. [^28] ¿Quién podrá tampoco comprender la extensión de las nubes, Y el sonido estrepitoso de su pabellón? [^29] He aquí que sobre él extiende su luz, Y cobija con ella las raíces de la mar. [^30] Bien que por esos medios castiga á los pueblos, A la multitud da comida. [^31] Con las nubes encubre la luz, Y mándale no brillar, interponiendo aquéllas. [^32] Tocante á ella anunciará el trueno, su compañero, Que hay acumulación de ira sobre el que se eleva. [^33] 

[[Job - 35|<--]] Job - 36 [[Job - 37|-->]]

---
# Notes
