---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 34 - Reina Valera (1602)"
---
[[Job - 33|<--]] Job - 34 [[Job - 35|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 34

ADEMAS respondió Eliú, y dijo: [^1] Oid, sabios, mis palabras; Y vosotros, doctos, estadme atentos. [^2] Porque el oído prueba las palabras, Como el paladar gusta para comer. [^3] Escojamos para nosotros el juicio, Conozcamos entre nosotros cuál sea lo bueno; [^4] Porque Job ha dicho: Yo soy justo, Y Dios me ha quitado mi derecho. [^5] ¿He de mentir yo contra mi razón? Mi saeta es gravosa sin haber yo prevaricado. [^6] ¿Qué hombre hay como Job, Que bebe el escarnio como agua? [^7] Y va en compañía con los que obran iniquidad, Y anda con los hombres maliciosos. [^8] Porque ha dicho: De nada servirá al hombre El conformar su voluntad con Dios. [^9] Por tanto, varones de seso, oidme; Lejos esté de Dios la impiedad, Y del Omnipotente la iniquidad. [^10] Porque él pagará al hombre según su obra, Y él le hará hallar conforme á su camino. [^11] Sí, por cierto, Dios no hará injusticia, Y el Omnipotente no pervertirá el derecho. [^12] ¿Quién visitó por él la tierra? ¿Y quién puso en orden todo el mundo? [^13] Si él pusiese sobre el hombre su corazón, Y recogiese así su espíritu y su aliento, [^14] Toda carne perecería juntamente, Y el hombre se tornaría en polvo. [^15] Si pues hay en ti entendimiento, oye esto: Escucha la voz de mis palabras. [^16] ¿Enseñorearáse el que aborrece juicio? ¿Y condenarás tú al que es tan justo? [^17] ¿Hase de decir al rey: Perverso; Y á los príncipes: Impíos? [^18] ¿Cuánto menos á aquel que no hace acepción de personas de príncipes, Ni el rico es de él más respetado que el pobre? Porque todos son obras de sus manos. [^19] En un momento morirán, y á media noche Se alborotarán los pueblos, y pasarán, Y sin mano será quitado el poderoso. [^20] Porque sus ojos están sobre los caminos del hombre, Y ve todos sus pasos. [^21] No hay tinieblas ni sombra de muerte Donde se encubran los que obran maldad. [^22] No carga pues él al hombre más de lo justo, Para que vaya con Dios á juicio. [^23] El quebrantará á los fuertes sin pesquisa, Y hará estar otros en su lugar. [^24] Por tanto él hará notorias las obras de ellos, Cuando los trastornará en la noche, y serán quebrantados. [^25] Como á malos los herirá En lugar donde sean vistos: [^26] Por cuanto así se apartaron de él, Y no consideraron todos sus caminos; [^27] Haciendo venir delante de él el clamor del pobre, Y que oiga el clamor de los necesitados. [^28] Y si él diere reposo, ¿quién inquietará? Si escondiere el rostro, ¿quién lo mirará? Esto sobre una nación, y lo mismo sobre un hombre; [^29] Haciendo que no reine el hombre hipócrita Para vejaciones del pueblo. [^30] De seguro conviene se diga á Dios: Llevado he ya castigo, no más ofenderé: [^31] Enséñame tú lo que yo no veo: Que si hice mal, no lo haré más. [^32] ¿Ha de ser eso según tu mente? El te retribuirá, ora rehuses, Ora aceptes, y no yo: Di si no, lo que tú sabes. [^33] Los hombres de seso dirán conmigo, Y el hombre sabio me oirá: [^34] Que Job no habla con sabiduría, Y que sus palabras no son con entendimiento. [^35] Deseo yo que Job sea probado ampliamente, A causa de sus respuestas por los hombres inicuos. [^36] Porque á su pecado añadió impiedad: Bate las manos entre nosotros, Y contra Dios multiplica sus palabras. [^37] 

[[Job - 33|<--]] Job - 34 [[Job - 35|-->]]

---
# Notes
