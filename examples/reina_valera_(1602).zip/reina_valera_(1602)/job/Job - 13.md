---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 13 - Reina Valera (1602)"
---
[[Job - 12|<--]] Job - 13 [[Job - 14|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 13

HE AQUI que todas estas cosas han visto mis ojos, Y oído y entendido de por sí mis oídos. [^1] Como vosotros lo sabéis, lo sé yo; No soy menos que vosotros. [^2] Mas yo hablaría con el Todopoderoso, Y querría razonar con Dios. [^3] Que ciertamente vosotros sois fraguadores de mentira; Sois todos vosotros médicos nulos. [^4] Ojalá callarais del todo, Porque os fuera sabiduría. [^5] Oid ahora mi razonamiento, Y estad atentos á los argumentos de mis labios. [^6] ¿Habéis de hablar iniquidad por Dios? ¿Habéis de hablar por él engaño? [^7] ¿Habéis de hacer acepción de su persona? ¿Habéis de pleitear vosotros por Dios? [^8] ¿Sería bueno que él os escudriñase? ¿Os burlaréis de él como quien se burla de algún hombre? [^9] El os reprochará de seguro, Si solapadamente hacéis acepción de personas. [^10] De cierto su alteza os había de espantar, Y su pavor había de caer sobre vosotros. [^11] Vuestras memorias serán comparadas á la ceniza, Y vuestros cuerpos como cuerpos de lodo. [^12] Escuchadme, y hablaré yo, Y véngame después lo que viniere. [^13] ¿Por qué quitaré yo mi carne con mis dientes, Y pondré mi alma en mi mano? [^14] He aquí, aunque me matare, en él esperaré; Empero defenderé delante de él mis caminos. [^15] Y él mismo me será salud, Porque no entrará en su presencia el hipócrita. [^16] Oid con atención mi razonamiento, Y mi denunciación con vuestros oídos. [^17] He aquí ahora, si yo me apercibiere á juicio, Sé que seré justificado. [^18] ¿Quién es el que pleiteará conmigo? Porque si ahora yo callara, fenecería. [^19] A lo menos dos cosas no hagas conmigo; Entonces no me esconderé de tu rostro: [^20] Aparta de mí tu mano, Y no me asombre tu terror. [^21] Llama luego, y yo responderé; O yo hablaré, y respóndeme tú. [^22] ¿Cuántas iniquidades y pecados tengo yo? Hazme entender mi prevaricación y mi pecado. [^23] ¿Por qué escondes tu rostro, Y me cuentas por tu enemigo? [^24] ¿A la hoja arrebatada has de quebrantar? ¿Y á una arista seca has de perseguir? [^25] ¿Por qué escribes contra mí amarguras, Y me haces cargo de los pecados de mi mocedad? [^26] Pones además mis pies en el cepo, y guardas todos mis caminos, Imprimiéndolo á las raíces de mis pies. [^27] Y el cuerpo mío se va gastando como de carcoma, Como vestido que se come de polilla. [^28] 

[[Job - 12|<--]] Job - 13 [[Job - 14|-->]]

---
# Notes
