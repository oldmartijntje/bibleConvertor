---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 19 - Reina Valera (1602)"
---
[[Job - 18|<--]] Job - 19 [[Job - 20|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 19

Y RESPONDIO Job, y dijo: [^1] ¿Hasta cuándo angustiaréis mi alma, Y me moleréis con palabras? [^2] Ya me habéis vituperado diez veces: ¿No os avergonzáis de descomediros delante de mí? [^3] Sea así que realmente haya yo errado, Conmigo se quedará mi yerro. [^4] Mas si vosotros os engrandeciereis contra mí, Y adujereis contra mí mi oprobio, [^5] Sabed ahora que Dios me ha trastornado, Y traído en derredor su red sobre mí. [^6] He aquí yo clamaré agravio, y no seré oído: Daré voces, y no habrá juicio. [^7] Cercó de vallado mi camino, y no pasaré; Y sobre mis veredas puso tinieblas. [^8] Hame despojado de mi gloria, Y quitado la corona de mi cabeza. [^9] Arruinóme por todos lados, y perezco; Y ha hecho pasar mi esperanza como árbol arrancado. [^10] E hizo inflamar contra mí su furor, Y contóme para sí entre sus enemigos. [^11] Vinieron sus ejércitos á una, y trillaron sobre mí su camino, Y asentaron campo en derredor de mi tienda. [^12] Hizo alejar de mí mis hermanos, Y positivamente se extrañaron de mí mis conocidos. [^13] Mis parientes se detuvieron, Y mis conocidos se olvidaron de mí. [^14] Los moradores de mi casa y mis criadas me tuvieron por extraño; Forastero fuí yo en sus ojos. [^15] Llamé á mi siervo, y no respondió; De mi propia boca le suplicaba. [^16] Mi aliento vino á ser extraño á mi mujer, Aunque por los hijos de mis entrañas le rogaba. [^17] Aun los muchachos me menospreciaron: En levantándome, hablaban contra mí. [^18] Todos mis confidentes me aborrecieron; Y los que yo amaba, se tornaron contra mí. [^19] Mi cuero y mi carne se pegaron á mis huesos; Y he escapado con la piel de mis dientes. [^20] Oh vosotros mis amigos, tened compasión de mí, tened compasión de mí; Porque la mano de Dios me ha tocado. [^21] ¿Por qué me perseguís como Dios, Y no os hartáis de mis carnes? [^22] Quién diese ahora que mis palabras fuesen escritas! ­Quién diese que se escribieran en un libro! [^23] Que con cincel de hierro y con plomo Fuesen en piedra esculpidas para siempre! [^24] Yo sé que mi Redentor vive, Y al fin se levantará sobre el polvo: [^25] Y después de deshecha esta mi piel, Aun he de ver en mi carne á Dios; [^26] Al cual yo tengo de ver por mí, Y mis ojos lo verán, y no otro, Aunque mis riñones se consuman dentro de mí. [^27] Mas debierais decir: ¿Por qué lo perseguimos? Ya que la raíz del negocio en mí se halla. [^28] Temed vosotros delante de la espada; Porque sobreviene el furor de la espada á causa de las injusticias, Para que sepáis que hay un juicio. [^29] 

[[Job - 18|<--]] Job - 19 [[Job - 20|-->]]

---
# Notes
