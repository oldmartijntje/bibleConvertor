---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 27 - Reina Valera (1602)"
---
[[Job - 26|<--]] Job - 27 [[Job - 28|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 27

Y REASUMIO Job su discurso, y dijo: [^1] Vive Dios, el cual ha apartado mi causa, Y el Omnipotente, que amargó el alma mía, [^2] Que todo el tiempo que mi alma estuviere en mí, Y hubiere hálito de Dios en mis narices, [^3] Mis labios no hablarán iniquidad, Ni mi lengua pronunciará engaño. [^4] Nunca tal acontezca que yo os justifique: Hasta morir no quitaré de mí mi integridad. [^5] Mi justicia tengo asida, y no la cederé: No me reprochará mi corazón en el tiempo de mi vida. [^6] Sea como el impío mi enemigo, Y como el inicuo mi adversario. [^7] Porque ¿cuál es la esperanza del hipócrita, por mucho que hubiere robado, Cuando Dios arrebatare su alma? [^8] ¿Oirá Dios su clamor Cuando la tribulación sobre él viniere? [^9] ¿Deleitaráse en el Omnipotente? ¿Invocará á Dios en todo tiempo? [^10] Yo os enseñaré en orden á la mano de Dios: No esconderé lo que hay para con el Omnipotente. [^11] He aquí que todos vosotros lo habéis visto: ¿Por qué pues os desvanecéis con fantasía? [^12] Esta es para con Dios la suerte del hombre impío, Y la herencia que los violentos han de recibir del Omnipotente. [^13] Si sus hijos fueren multiplicados, serán para el cuchillo; Y sus pequeños no se hartarán de pan; [^14] Los que le quedaren, en muerte serán sepultados; Y no llorarán sus viudas. [^15] Si amontonare plata como polvo, Y si preparare ropa como lodo; [^16] Habrála él preparado, mas el justo se vestirá, Y el inocente repartirá la plata. [^17] Edificó su casa como la polilla, Y cual cabaña que el guarda hizo. [^18] El rico dormirá, mas no será recogido: Abrirá sus ojos, mas él no será. [^19] Asirán de él terrores como aguas: Torbellino lo arrebatará de noche. [^20] Lo antecogerá el solano, y partirá; Y tempestad lo arrebatará del lugar suyo. [^21] Dios pues descargará sobre él, y no perdonará: Hará él por huir de su mano. [^22] Batirán sus manos sobre él, Y desde su lugar le silbarán. [^23] 

[[Job - 26|<--]] Job - 27 [[Job - 28|-->]]

---
# Notes
