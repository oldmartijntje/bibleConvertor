---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 1 - Reina Valera (1602)"
---
Job - 1 [[Job - 2|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 1

HUBO un varón en tierra de Hus, llamado Job; y era este hombre perfecto y recto, y temeroso de Dios, y apartado del mal. [^1] Y naciéronle siete hijos y tres hijas. [^2] Y su hacienda era siete mil ovejas, y tres mil camellos, y quinientas yuntas de bueyes, y quinientas asnas, y muchísimos criados: y era aquel varón grande más que todos los Orientales. [^3] E iban sus hijos y hacían banquetes en sus casas, cada uno en su día; y enviaban á llamar sus tres hermanas, para que comiesen y bebiesen con ellos. [^4] Y acontecía que, habiendo pasado en turno los días del convite, Job enviaba y santificábalos, y levantábase de mañana y ofrecía holocaustos conforme al número de todos ellos. Porque decía Job: Quizá habrán pecado mis hijos, y habrán blasfemado á Dios en sus corazones. De esta manera hacía todos los días. [^5] Y un día vinieron los hijos de Dios á presentarse delante de Jehová, entre los cuales vino también Satán. [^6] Y dijo Jehová á Satán: ¿De dónde vienes? Y respondiendo Satán á Jehová, dijo: De rodear la tierra, y de andar por ella. [^7] Y Jehová dijo á Satán: ¿No has considerado á mi siervo Job, que no hay otro como él en la tierra, varón perfecto y recto, temeroso de Dios, y apartado de mal? [^8] Y respondiendo Satán á Jehová, dijo: ¿Teme Job á Dios de balde? [^9] ¿No le has tú cercado á él, y á su casa, y á todo lo que tiene en derredor? Al trabajo de sus manos has dado bendición; por tanto su hacienda ha crecido sobre la tierra. [^10] Mas extiende ahora tu mano, y toca á todo lo que tiene, y verás si no te blasfema en tu rostro. [^11] Y dijo Jehová á Satán: He aquí, todo lo que tiene está en tu mano: solamente no pongas tu mano sobre él. Y salióse Satán de delante de Jehová. [^12] Y un día aconteció que sus hijos é hijas comían y bebían vino en casa de su hermano el primogénito, [^13] Y vino un mensajero á Job, que le dijo: Estando arando los bueyes, y las asnas paciendo cerca de ellos, [^14] Acometieron los Sabeos, y tomáronlos, é hirieron á los mozos á filo de espada: solamente escapé yo para traerte las nuevas. [^15] Aun estaba éste hablando, y vino otro que dijo: Fuego de Dios cayó del cielo, que quemó las ovejas y los mozos, y los consumió: solamente escapé yo solo para traerte las nuevas. [^16] Todavía estaba éste hablando, y vino otro que dijo: Los Caldeos hicieron tres escuadrones, y dieron sobre los camellos, y tomáronlos, é hirieron á los mozos á filo de espada; y solamente escapé yo solo para traerte las nuevas. [^17] Entre tanto que éste hablaba, vino otro que dijo: Tus hijos y tus hijas estaban comiendo y bebiendo vino en casa de su hermano el primogénito; [^18] Y he aquí un gran viento que vino del lado del desierto, é hirió las cuatro esquinas de la casa, y cayó sobre los mozos, y murieron; y solamente escapé yo solo para traerte las nuevas. [^19] Entonces Job se levantó, y rasgó su manto, y trasquiló su cabeza, y cayendo en tierra adoró; [^20] Y dijo: Desnudo salí del vientre de mi madre, y desnudo tornaré allá. Jehová dió, y Jehová quitó: sea el nombre de Jehová bendito. [^21] En todo esto no pecó Job, ni atribuyó á Dios despropósito alguno. [^22] 

Job - 1 [[Job - 2|-->]]

---
# Notes
