---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 29 - Reina Valera (1602)"
---
[[Job - 28|<--]] Job - 29 [[Job - 30|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 29

Y VOLVIO Job á tomar su propósito, y dijo: [^1] Quién me tornase como en los meses pasados, Como en los días que Dios me guardaba, [^2] Cuando hacía resplandecer su candela sobre mi cabeza, A la luz de la cual yo caminaba en la oscuridad; [^3] Como fué en los días de mi mocedad, Cuando el secreto de Dios estaba en mi tienda; [^4] Cuando aún el Omnipotente estaba conmigo, Y mis hijos alrededor de mi; [^5] Cuando lavaba yo mis caminos con manteca, Y la piedra me derramaba ríos de aceite! [^6] Cuando salía á la puerta á juicio, Y en la plaza hacía preparar mi asiento, [^7] Los mozos me veían, y se escondían; Y los viejos se levantaban, y estaban en pie; [^8] Los príncipes detenían sus palabras, Ponían la mano sobre su boca; [^9] La voz de los principales se ocultaba, Y su lengua se pegaba á su paladar: [^10] Cuando los oídos que me oían, me llamaban bienaventurado, Y los ojos que me veían, me daban testimonio: [^11] Porque libraba al pobre que gritaba, Y al huérfano que carecía de ayudador. [^12] La bendición del que se iba á perder venía sobre mí; Y al corazón de la viuda daba alegría. [^13] Vestíame de justicia, y ella me vestía como un manto; Y mi toca era juicio. [^14] Yo era ojos al ciego, Y pies al cojo. [^15] A los menesterosos era padre; Y de la causa que no entendía, me informaba con diligencia: [^16] Y quebraba los colmillos del inicuo, Y de sus dientes hacía soltar la presa. [^17] Y decía yo: En mi nido moriré, Y como arena multiplicaré días. [^18] Mi raíz estaba abierta junto á las aguas, Y en mis ramas permanecía el rocío. [^19] Mi honra se renovaba en mí, Y mi arco se corroboraba en mi mano. [^20] Oíanme, y esperaban; Y callaban á mi consejo. [^21] Tras mi palabra no replicaban, Y mi razón destilaba sobre ellos. [^22] Y esperábanme como á la lluvia, Y abrían su boca como á la lluvia tardía. [^23] Si me reía con ellos, no lo creían: Y no abatían la luz de mi rostro. [^24] Calificaba yo el camino de ellos, y sentábame en cabecera; Y moraba como rey en el ejército, Como el que consuela llorosos. [^25] 

[[Job - 28|<--]] Job - 29 [[Job - 30|-->]]

---
# Notes
