---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 35 - Reina Valera (1602)"
---
[[Job - 34|<--]] Job - 35 [[Job - 36|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 35

Y PROCEDIENDO Eliú en su razonamiento, dijo: [^1] ¿Piensas ser conforme á derecho Esto que dijiste: Más justo soy yo que Dios? [^2] Porque dijiste: ¿Qué ventaja sacarás tú de ello? ¿O qué provecho tendré de mi pecado? [^3] Yo te responderé razones, Y á tus compañeros contigo. [^4] Mira á los cielos, y ve, Y considera que las nubes son más altas que tú. [^5] Si pecares, ¿qué habrás hecho contra él? Y si tus rebeliones se multiplicaren, ¿qué le harás tú? [^6] Si fueres justo, ¿qué le darás á el? ¿O qué recibirá de tu mano? [^7] Al hombre como tú dañará tu impiedad, Y al hijo del hombre aprovechará tu justicia. [^8] A causa de la multitud de las violencias clamarán, Y se lamentarán por el poderío de los grandes. [^9] Y ninguno dice: ¿Dónde está Dios mi Hacedor, Que da canciones en la noche, [^10] Que nos enseña más que á las bestias de la tierra, Y nos hace sabios más que las aves del cielo? [^11] Allí clamarán, y él no oirá, Por la soberbia de los malos. [^12] Ciertamente Dios no oirá la vanidad, Ni la mirará el Omnipotente. [^13] Aunque más digas, No lo mirará; Haz juicio delante de él, y en él espera. [^14] Mas ahora, porque en su ira no visita, Ni conoce con rigor, [^15] Por eso Job abrió su boca vanamente, Y multiplica palabras sin sabiduría. [^16] 

[[Job - 34|<--]] Job - 35 [[Job - 36|-->]]

---
# Notes
