---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 23 - Reina Valera (1602)"
---
[[Job - 22|<--]] Job - 23 [[Job - 24|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 23

Y RESPONDIO Job, y dijo: [^1] Hoy también hablaré con amargura; Que es más grave mi llaga que mi gemido. [^2] Quién me diera el saber dónde hallar á Dios! Yo iría hasta su silla. [^3] Ordenaría juicio delante de él, Y henchiría mi boca de argumentos. [^4] Yo sabría lo que él me respondería, Y entendería lo que me dijese. [^5] ¿Pleitearía conmigo con grandeza de fuerza? No: antes él la pondría en mí. [^6] Allí el justo razonaría con él: Y escaparía para siempre de mi juez. [^7] He aquí yo iré al oriente, y no lo hallaré; Y al occidente, y no lo percibiré: [^8] Si al norte él obrare, yo no lo veré; Al mediodía se esconderá, y no lo veré. [^9] Mas él conoció mi camino: Probaráme, y saldré como oro. [^10] Mis pies tomaron su rastro; Guardé su camino, y no me aparté. [^11] Del mandamiento de sus labios nunca me separé; Guardé las palabras de su boca más que mi comida. [^12] Empero si él se determina en una cosa, ¿quién lo apartará? Su alma deseó, é hizo. [^13] El pues acabará lo que ha determinado de mí: Y muchas cosas como estas hay en él. [^14] Por lo cual yo me espanto en su presencia: Consideraré, y temerélo. [^15] Dios ha enervado mi corazón, Y hame turbado el Omnipotente. [^16] ¿Por qué no fuí yo cortado delante de las tinieblas, Y cubrió con oscuridad mi rostro? [^17] 

[[Job - 22|<--]] Job - 23 [[Job - 24|-->]]

---
# Notes
