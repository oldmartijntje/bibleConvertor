---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 15 - Reina Valera (1602)"
---
[[Job - 14|<--]] Job - 15 [[Job - 16|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 15

Y RESPONDIO Eliphaz Temanita, y dijo: [^1] ¿Si proferirá el sabio vana sabiduría, Y henchirá su vientre de viento solano? [^2] ¿Disputará con palabras inútiles, Y con razones sin provecho? [^3] Tú también disipas el temor, Y menoscabas la oración delante de Dios. [^4] Porque tu boca declaró tu iniquidad, Pues has escogido el hablar de los astutos. [^5] Tu boca te condenará, y no yo; Y tus labios testificarán contra ti. [^6] ¿Naciste tú primero que Adam? ¿O fuiste formado antes que los collados? [^7] ¿Oíste tú el secreto de Dios, Que detienes en ti solo la sabiduría? [^8] ¿Qué sabes tú que no sepamos? ¿Qué entiendes que no se halle en nosotros? [^9] Entre nosotros también hay cano, también hay viejo Mucho mayor en días que tu padre. [^10] ¿En tan poco tienes las consolaciones de Dios? ¿Tienes acaso alguna cosa oculta cerca de ti? [^11] ¿Por qué te enajena tu corazón, Y por qué guiñan tus ojos, [^12] Pues haces frente á Dios con tu espíritu, Y sacas tales palabras de tu boca? [^13] ¿Qué cosa es el hombre para que sea limpio, Y que se justifique el nacido de mujer? [^14] He aquí que en sus santos no confía, Y ni los cielos son limpios delante de sus ojos: [^15] ¿Cuánto menos el hombre abominable y vil, Que bebe la iniquidad como agua? [^16] Escúchame; yo te mostraré Y te contaré lo que he visto: [^17] (Lo que los sabios nos contaron De sus padres, y no lo encubrieron; [^18] A los cuales solos fué dada la tierra, Y no pasó extraño por medio de ellos:) [^19] Todos los días del impío, él es atormentado de dolor, Y el número de años es escondido al violento. [^20] Estruendos espantosos hay en sus oídos; En la paz le vendrá quien lo asuele. [^21] El no creerá que ha de volver de las tinieblas, Y está mirando al cuchillo. [^22] Desasosegado á comer siempre, Sabe que le está aparejado día de tinieblas. [^23] Tribulación y angustia le asombrarán, Y esforzaránse contra él como un rey apercibido para la batalla. [^24] Por cuanto él extendió su mano contra Dios, Y se esforzó contra el Todopoderoso, [^25] El le acometerá en la cerviz, En lo grueso de las hombreras de sus escudos: [^26] Porque cubrió su rostro con su gordura, E hizo pliegues sobre los ijares; [^27] Y habitó las ciudades asoladas, Las casas inhabitadas, Que estaban puestas en montones. [^28] No enriquecerá, ni será firme su potencia, Ni extenderá por la tierra su hermosura. [^29] No se escapará de las tinieblas: La llama secará sus ramos, Y con el aliento de su boca perecerá. [^30] No confíe el iluso en la vanidad; Porque ella será su recompensa. [^31] El será cortado antes de su tiempo, Y sus renuevos no reverdecerán. [^32] El perderá su agraz como la vid, Y derramará su flor como la oliva. [^33] Porque la sociedad de los hipócritas será asolada, Y fuego consumirá las tiendas de soborno. [^34] Concibieron dolor, y parieron iniquidad; Y las entradas de ellos meditan engaño. [^35] 

[[Job - 14|<--]] Job - 15 [[Job - 16|-->]]

---
# Notes
