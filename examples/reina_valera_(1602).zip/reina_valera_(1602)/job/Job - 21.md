---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 21 - Reina Valera (1602)"
---
[[Job - 20|<--]] Job - 21 [[Job - 22|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 21

Y RESPONDIO Job, y dijo: [^1] Oid atentamente mi palabra, Y sea esto vuestros consuelos. [^2] Soportadme, y yo hablaré; Y después que hubiere hablado, escarneced. [^3] ¿Hablo yo á algún hombre? Y ¿por qué no se ha de angustiar mi espíritu? [^4] Miradme, y espantaos, Y poned la mano sobre la boca. [^5] Aun yo mismo, cuando me acuerdo, me asombro, Y toma temblor mi carne. [^6] ¿Por qué viven los impíos, Y se envejecen, y aun crecen en riquezas? [^7] Su simiente con ellos, compuesta delante de ellos; Y sus renuevos delante de sus ojos. [^8] Sus casas seguras de temor, Ni hay azote de Dios sobre ellos. [^9] Sus vacas conciben, no abortan; Paren sus vacas, y no malogran su cría. [^10] Salen sus chiquitos como manada, Y sus hijos andan saltando. [^11] Al son de tamboril y cítara saltan, Y se huelgan al son del órgano. [^12] Gastan sus días en bien, Y en un momento descienden á la sepultura. [^13] Dicen pues á Dios: Apártate de nosotros, Que no queremos el conocimiento de tus caminos. [^14] ¿Quién es el Todopoderoso, para que le sirvamos? ¿Y de qué nos aprovechará que oremos á él? [^15] He aquí que su bien no está en manos de ellos: El consejo de los impíos lejos esté de mí. [^16] Oh cuántas veces la lámpara de los impíos es apagada, Y viene sobre ellos su quebranto, Y Dios en su ira les reparte dolores! [^17] Serán como la paja delante del viento, Y como el tamo que arrebata el torbellino. [^18] Dios guardará para sus hijos su violencia; Y le dará su pago, para que conozca. [^19] Verán sus ojos su quebranto, Y beberá de la ira del Todopoderoso. [^20] Porque ¿qué deleite tendrá él de su casa después de sí, Siendo cortado el número de sus meses? [^21] ¿Enseñará alguien á Dios sabiduría, Juzgando él á los que están elevados? [^22] Este morirá en el vigor de su hermosura, todo quieto y pacífico. [^23] Sus colodras están llenas de leche, Y sus huesos serán regados de tuétano. [^24] Y estotro morirá en amargura de ánimo, Y no habiendo comido jamás con gusto. [^25] Igualmente yacerán ellos en el polvo, Y gusanos los cubrirán. [^26] He aquí, yo conozco vuestros pensamientos, Y las imaginaciones que contra mí forjáis. [^27] Porque decís: ¿Qué es de la casa del príncipe, Y qué de la tienda de las moradas de los impíos? [^28] ¿No habéis preguntado á los que pasan por los caminos, Por cuyas señas no negaréis, [^29] Que el malo es reservado para el día de la destrucción? Presentados serán en el día de las iras. [^30] ¿Quién le denunciará en su cara su camino? Y de lo que él hizo, ¿quién le dará el pago? [^31] Porque llevado será él á los sepulcros, Y en el montón permanecerá. [^32] Los terrones del valle le serán dulces; Y tras de él será llevado todo hombre, Y antes de él han ido innumerables. [^33] ¿Cómo pues me consoláis en vano, Viniendo á parar vuestras respuestas en falacia? [^34] 

[[Job - 20|<--]] Job - 21 [[Job - 22|-->]]

---
# Notes
