---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 32 - Reina Valera (1602)"
---
[[Job - 31|<--]] Job - 32 [[Job - 33|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 32

Y CESARON estos tres varones de responder á Job, por cuanto él era justo en sus ojos. [^1] Entonces Eliú hijo de Barachêl, Bucita, de la familia de Ram, se enojó con furor contra Job: enojóse con furor, por cuanto justificaba su vida más que á Dios. [^2] Enojóse asimismo con furor contra sus tres amigos, porque no hallaban qué responder, aunque habían condenado á Job. [^3] Y Eliú había esperado á Job en la disputa, porque eran más viejos de días que él. [^4] Empero viendo Eliú que no había respuesta en la boca de aquelllos tres varones, su furor se encendió. [^5] Y respondió Eliú hijo de Barachêl, Buzita, y dijo: Yo soy menor de días y vosotros viejos; He tenido por tanto miedo, y temido declararos mi opinión. [^6] Yo decía: Los días hablarán, Y la muchedumbre de años declarará sabiduría. [^7] Ciertamente espíritu hay en el hombre, E inspiración del Omnipotente los hace que entiendan. [^8] No los grandes son los sabios, Ni los viejos entienden el derecho. [^9] Por tanto yo dije: Escuchadme; Declararé yo también mi sabiduría. [^10] He aquí yo he esperado á vuestras razones, He escuchado vuestros argumentos, En tanto que buscabais palabras. [^11] Os he pues prestado atención, Y he aquí que no hay de vosotros quien redarguya á Job, Y responda á sus razones. [^12] Porque no digáis: Nosotros hemos hallado sabiduría: Lanzólo Dios, no el hombre. [^13] Ahora bien, Job no enderezó á mí sus palabras, Ni yo le responderé con vuestras razones. [^14] Espantáronse, no respondieron más; Fuéronseles los razonamientos. [^15] Yo pues he esperado, porque no hablaban, Antes pararon, y no respondieron más. [^16] Por eso yo también responderé mi parte, También yo declararé mi juicio. [^17] Porque lleno estoy de palabras, Y el espíritu de mi vientre me constriñe. [^18] De cierto mi vientre está como el vino que no tiene respiradero, Y se rompe como odres nuevos. [^19] Hablaré pues y respiraré; Abriré mis labios, y responderé. [^20] No haré ahora acepción de personas, Ni usaré con hombre de lisonjeros títulos. [^21] Porque no sé hablar lisonjas: De otra manera en breve mi Hacedor me consuma. [^22] 

[[Job - 31|<--]] Job - 32 [[Job - 33|-->]]

---
# Notes
