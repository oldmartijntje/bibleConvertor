---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 3 - Reina Valera (1602)"
---
[[Job - 2|<--]] Job - 3 [[Job - 4|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 3

DESPUÉS de esto abrió Job su boca, y maldijo su día. [^1] Y exclamó Job, y dijo: [^2] Perezca el día en que yo nací, Y la noche que se dijo: Varón es concebido. [^3] Sea aquel día sombrío, Y Dios no cuide de él desde arriba, Ni claridad sobre él resplandezca. [^4] Aféenlo tinieblas y sombra de muerte; Repose sobre él nublado, Que lo haga horrible como caliginoso día. [^5] Ocupe la oscuridad aquella noche; No sea contada entre los días del año, Ni venga en él número de los meses. [^6] Oh si fuere aquella noche solitaria, Que no viniera canción alguna en ella! [^7] Maldíganla los que maldicen al día, Los que se aprestan para levantar su llanto. [^8] Oscurézcanse las estrellas de su alba; Espere la luz, y no venga, Ni vea los párpados de la mañana: [^9] Por cuanto no cerró las puertas del vientre donde yo estaba, Ni escondió de mis ojos la miseria. [^10] ¿Por qué no morí yo desde la matriz, O fuí traspasado en saliendo del vientre? [^11] ¿Por qué me previnieron las rodillas? ¿Y para qué las tetas que mamase? [^12] Pues que ahora yaciera yo, y reposara; Durmiera, y entonces tuviera reposo, [^13] Con los reyes y con los consejeros de la tierra, Que edifican para sí los desiertos; [^14] O con los príncipes que poseían el oro, Que henchían sus casas de plata. [^15] O ¿por qué no fuí escondido como aborto, Como los pequeñitos que nunca vieron luz? [^16] Allí los impíos dejan el perturbar, Y allí descansan los de cansadas fuerzas. [^17] Allí asimismo reposan los cautivos; No oyen la voz del exactor. [^18] Allí están el chico y el grande; Y el siervo libre de su señor. [^19] ¿Por qué se da luz al trabajado, Y vida á los de ánimo en amargura, [^20] Que esperan la muerte, y ella no llega, Aunque la buscan más que tesoros; [^21] Que se alegran sobremanera, Y se gozan, cuando hallan el sepulcro? [^22] ¿Por qué al hombre que no sabe por donde vaya, Y al cual Dios ha encerrado? [^23] Pues antes que mi pan viene mi suspiro; Y mis gemidos corren como aguas. [^24] Porque el temor que me espantaba me ha venido, Y hame acontecido lo que temía. [^25] No he tenido paz, no me aseguré, ni me estuve reposado; Vínome no obstante turbación. [^26] 

[[Job - 2|<--]] Job - 3 [[Job - 4|-->]]

---
# Notes
