---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 12 - Reina Valera (1602)"
---
[[Job - 11|<--]] Job - 12 [[Job - 13|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 12

Y RESPONDIO Job, y dijo: [^1] Ciertamente que vosotros sois el pueblo; Y con vosotros morirá la sabiduría. [^2] También tengo yo seso como vosotros; No soy yo menos que vosotros: ¿Y quién habrá que no pueda decir otro tanto? [^3] Yo soy uno de quien su amigo se mofa, Que invoca á Dios, y él le responde: Con todo, el justo y perfecto es escarnecido. [^4] Aquel cuyos pies van á resbalar, Es como una lámpara despreciada de aquel que está á sus anchuras. [^5] Prosperan las tiendas de los ladrones, Y los que provocan á Dios viven seguros; En cuyas manos él ha puesto cuanto tienen. [^6] Y en efecto, pregunta ahora á las bestias, que ellas te enseñarán; Y á las aves de los cielos, que ellas te lo mostrarán; [^7] O habla á la tierra, que ella te enseñará; Los peces de la mar te lo declararán también. [^8] ¿Qué cosa de todas estas no entiende Que la mano de Jehová la hizo? [^9] En su mano está el alma de todo viviente, Y el espíritu de toda carne humana. [^10] Ciertamente el oído distingue las palabras, Y el paladar gusta las viandas. [^11] En los viejos está la ciencia, Y en la larga edad la inteligencia. [^12] Con Dios está la sabiduría y la fortaleza; Suyo es el consejo y la inteligencia. [^13] He aquí, él derribará, y no será edificado: Encerrará al hombre, y no habrá quien le abra. [^14] He aquí, el detendrá las aguas, y se secarán; El las enviará, y destruirán la tierra. [^15] Con él está la fortaleza y la existencia; Suyo es el que yerra, y el que hace errar. [^16] El hace andar á los consejeros desnudos de consejo, Y hace enloquecer á los jueces. [^17] El suelta la atadura de los tiranos, Y ata el cinto á sus lomos. [^18] El lleva despojados á los príncipes, Y trastorna á los poderosos. [^19] El impide el labio á los que dicen verdad, Y quita á los ancianos el consejo. [^20] El derrama menosprecio sobre los príncipes, Y enflaquece la fuerza de los esforzados. [^21] El descubre las profundidades de las tinieblas, Y saca á luz la sombra de muerte. [^22] El multiplica las gentes, y él las destruye: El esparce las gentes, y las torna á recoger. [^23] El quita el seso de las cabezas del pueblo de la tierra, Y háceles que se pierdan vagueando sin camino: [^24] Van á tientas como en tinieblas y sin luz, Y los hace errar como borrachos. [^25] 

[[Job - 11|<--]] Job - 12 [[Job - 13|-->]]

---
# Notes
