---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 8 - Reina Valera (1602)"
---
[[Job - 7|<--]] Job - 8 [[Job - 9|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 8

Y RESPONDIO Bildad Suhita, y dijo: [^1] ¿Hasta cuándo hablarás tales cosas, Y las palabras de tu boca serán como un viento fuerte? [^2] ¿Acaso pervertirá Dios el derecho, O el Todopoderoso pervertirá la justicia? [^3] Si tus hijos pecaron contra él, El los echó en el lugar de su pecado. [^4] Si tú de mañana buscares á Dios, Y rogares al Todopoderoso; [^5] Si fueres limpio y derecho, Cierto luego se despertará sobre ti, Y hará próspera la morada de tu justicia. [^6] Y tu principio habrá sido pequeño, Y tu postrimería acrecerá en gran manera. [^7] Porque pregunta ahora á la edad pasada, Y disponte para inquirir de sus padres de ellos; [^8] Pues nosotros somos de ayer, y no sabemos, Siendo nuestros días sobre la tierra como sombra. [^9] ¿No te enseñarán ellos, te dirán, Y de su corazón sacarán palabras? [^10] ¿Crece el junco sin lodo? ¿Crece el prado sin agua? [^11] Aun él en su verdor no será cortado, Y antes de toda hierba se secará. [^12] Tales son los caminos de todos los que olvidan á Dios: Y la esperanza del impío perecerá: [^13] Porque su esperanza será cortada, Y su confianza es casa de araña. [^14] Apoyaráse él sobre su casa, mas no permanecerá en pie; Atendráse á ella, mas no se afirmará. [^15] A manera de un árbol, está verde delante del sol, Y sus renuevos salen sobre su huerto; [^16] Vanse entretejiendo sus raíces junto á una fuente, Y enlazándose hasta un lugar pedregoso. [^17] Si le arrancaren de su lugar, Este negarále entonces, diciendo: Nunca te vi. [^18] Ciertamente éste será el gozo de su camino; Y de la tierra de donde se traspusiere, nacerán otros. [^19] He aquí, Dios no aborrece al perfecto, Ni toma la mano de los malignos. [^20] Aun henchirá tu boca de risa, Y tus labios de júbilo. [^21] Los que te aborrecen, serán vestidos de confusión; Y la habitación de los impíos perecerá. [^22] 

[[Job - 7|<--]] Job - 8 [[Job - 9|-->]]

---
# Notes
