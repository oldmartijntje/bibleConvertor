---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 30 - Reina Valera (1602)"
---
[[Job - 29|<--]] Job - 30 [[Job - 31|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 30

MAS ahora los más mozos de días que yo, se ríen de mí; Cuyos padres yo desdeñara ponerlos con los perros de mi ganado. [^1] Porque ¿para qué yo habría menester la fuerza de sus manos, En los cuales había perecido con el tiempo? [^2] Por causa de la pobreza y del hambre andaban solos; Huían á la soledad, á lugar tenebroso, asolado y desierto. [^3] Que cogían malvas entre los arbustos, Y raíces de enebro para calentarse. [^4] Eran echados de entre las gentes, Y todos les daban grita como al ladrón. [^5] Habitaban en las barrancas de los arroyos, En las cavernas de la tierra, y en las rocas. [^6] Bramaban entre las matas, Y se reunían debajo de las espinas. [^7] Hijos de viles, y hombres sin nombre, Más bajos que la misma tierra. [^8] Y ahora yo soy su canción, Y he sido hecho su refrán. [^9] Abomínanme, aléjanse de mí, Y aun de mi rostro no detuvieron su saliva. [^10] Porque Dios desató mi cuerda, y me afligió, Por eso se desenfrenaron delante de mi rostro. [^11] A la mano derecha se levantaron los jóvenes; Empujaron mis pies, Y sentaron contra mí las vías de su ruina. [^12] Mi senda desbarataron, Aprovecháronse de mi quebrantamiento, Contra los cuales no hubo ayudador. [^13] Vinieron como por portillo ancho, Revolviéronse á mi calamidad. [^14] Hanse revuelto turbaciones sobre mí; Combatieron como viento mi alma, Y mi salud pasó como nube [^15] Y ahora mi alma está derramada en mí; Días de aflicción me han aprehendido. [^16] De noche taladra sobre mí mis huesos, Y mis pulsos no reposan. [^17] Con la grande copia de materia mi vestidura está demudada; Cíñeme como el cuello de mi túnica. [^18] Derribóme en el lodo, Y soy semejante al polvo y á la ceniza. [^19] Clamo á ti, y no me oyes; Preséntome, y no me atiendes. [^20] Haste tornado cruel para mí: Con la fortaleza de tu mano me amenazas. [^21] Levantásteme, é hicísteme cabalgar sobre el viento, Y disolviste mi sustancia. [^22] Porque yo conozco que me reduces á la muerte; Y á la casa determinada á todo viviente. [^23] Mas él no extenderá la mano contra el sepulcro; ¿Clamarán los sepultados cuando él los quebrantare? [^24] ¿No lloré yo al afligido? Y mi alma ¿no se entristeció sobre el menesteroso? [^25] Cuando esperaba yo el bien, entonces vino el mal; Y cuando esperaba luz, la oscuridad vino. [^26] Mis entrañas hierven, y no reposan; Días de aflicción me han sobrecogido. [^27] Denegrido ando, y no por el sol: Levantádome he en la congregación, y clamado. [^28] He venido á ser hermano de los dragones, Y compañero de los buhos. [^29] Mi piel está denegrida sobre mí, Y mis huesos se secaron con ardentía. [^30] Y hase tornado mi arpa en luto, Y mi órgano en voz de lamentadores. [^31] 

[[Job - 29|<--]] Job - 30 [[Job - 31|-->]]

---
# Notes
