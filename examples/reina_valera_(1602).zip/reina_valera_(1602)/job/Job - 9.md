---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 9 - Reina Valera (1602)"
---
[[Job - 8|<--]] Job - 9 [[Job - 10|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 9

Y RESPONDIO Job, y dijo: [^1] Ciertamente yo conozco que es así: ¿Y cómo se justificará el hombre con Dios? [^2] Si quisiere contender con él, No le podrá responder á una cosa de mil. [^3] El es sabio de corazón, y poderoso en fortaleza, ¿Quién se endureció contra él, y quedó en paz? [^4] Que arranca los montes con su furor, Y no conocen quién los trastornó: [^5] Que remueve la tierra de su lugar, Y hace temblar sus columnas: [^6] Que manda al sol, y no sale; Y sella las estrellas: [^7] El que extiende solo los cielos, Y anda sobre las alturas de la mar: [^8] El que hizo el Arcturo, y el Orión, y las Pléyadas, Y los lugares secretos del mediodía: [^9] El que hace cosas grandes é incomprensibles, Y maravillosas, sin número. [^10] He aquí que él pasará delante de mí, y yo no lo veré; Y pasará, y no lo entenderé. [^11] He aquí, arrebatará; ¿quién le hará restituir? ¿Quién le dirá, Qué haces? [^12] Dios no tornará atrás su ira, Y debajo de él se encorvan los que ayudan á los soberbios. [^13] ¿Cuánto menos le responderé yo, Y hablaré con él palabras estudiadas? [^14] Que aunque fuese yo justo, no responderé; Antes habré de rogar á mi juez. [^15] Que si yo le invocase, y él me respondiese, Aun no creeré que haya escuchado mi voz. [^16] Porque me ha quebrado con tempestad, Y ha aumentado mis heridas sin causa. [^17] No me ha concedido que tome mi aliento; Mas hame hartado de amarguras. [^18] Si habláremos de su potencia, fuerte por cierto es; Si de juicio, ¿quién me emplazará? [^19] Si yo me justificare, me condenará mi boca; Si me dijere perfecto, esto me hará inicuo. [^20] Bien que yo fuese íntegro, no conozco mi alma: Reprocharé mi vida. [^21] Una cosa resta que yo diga: Al perfecto y al impío él los consume. [^22] Si azote mata de presto, Ríese de la prueba de los inocentes. [^23] La tierra es entregada en manos de los impíos, Y él cubre el rostro de sus jueces. Si no es él, ¿quién es? ¿dónde está? [^24] Mis días han sido más ligeros que un correo; Huyeron, y no vieron el bien. [^25] Pasaron cual navíos veloces: Como el águila que se arroja á la comida. [^26] Si digo: Olvidaré mi queja, Dejaré mi aburrimiento, y esforzaréme: [^27] Contúrbanme todos mis trabajos; Sé que no me darás por libre. [^28] Yo soy impío, ¿Para qué trabajaré en vano? [^29] Aunque me lave con aguas de nieve, Y limpie mis manos con la misma limpieza, [^30] Aun me hundirás en el hoyo, Y mis propios vestidos me abominarán. [^31] Porque no es hombre como yo, para que yo le responda, Y vengamos juntamente á juicio. [^32] No hay entre nosotros árbitro Que ponga su mano sobre nosotros ambos. [^33] Quite de sobre mí su vara, Y su terror no me espante. [^34] Entonces hablaré, y no le temeré: Porque así no estoy en mí mismo. [^35] 

[[Job - 8|<--]] Job - 9 [[Job - 10|-->]]

---
# Notes
