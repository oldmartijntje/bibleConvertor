---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 41 - Reina Valera (1602)"
---
[[Job - 40|<--]] Job - 41 [[Job - 42|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 41

¿SACARAS tú al leviathán con el anzuelo, O con la cuerda que le echares en su lengua? [^1] ¿Pondrás tú garfio en sus narices, Y horadarás con espinas su quijada? [^2] ¿Multiplicará él ruegos para contigo? ¿Hablaráte él lisonjas? [^3] ¿Hará concierto contigo Para que lo tomes por siervo perpetuo? [^4] ¿Jugarás tú con él como con pájaro, O lo atarás para tus niñas? [^5] ¿Harán de él banquete los compañeros? ¿Partiránlo entre los mercaderes? [^6] ¿Cortarás tú con cuchillo su cuero, O con asta de pescadores su cabeza? [^7] Pon tu mano sobre él; Te acordarás de la batalla, y nunca más tornarás. [^8] He aquí que la esperanza acerca de él será burlada; Porque aun á su sola vista se desmayarán. [^9] Nadie hay tan osado que lo despierte: ¿Quién pues podrá estar delante de mí? [^10] ¿Quién me ha anticipado, para que yo restituya? Todo lo que hay debajo del cielo es mío. [^11] Yo no callaré sus miembros, Ni lo de sus fuerzas y la gracia de su disposición. [^12] ¿Quién descubrirá la delantera de su vestidura? ¿Quién se llegará á él con freno doble? [^13] ¿Quién abrirá las puertas de su rostro? Los órdenes de sus dientes espantan. [^14] La gloria de su vestido son escudos fuertes, Cerrados entre sí estrechamente. [^15] El uno se junta con el otro, Que viento no entra entre ellos. [^16] Pegado está el uno con el otro, Están trabados entre sí, que no se pueden apartar. [^17] Con sus estornudos encienden lumbre, Y sus ojos son como los párpados del alba. [^18] De su boca salen hachas de fuego, Centellas de fuego proceden. [^19] De sus narices sale humo, Como de una olla ó caldero que hierve. [^20] Su aliento enciende los carbones, Y de su boca sale llama. [^21] En su cerviz mora la fortaleza, Y espárcese el desaliento delante de él. [^22] Las partes momias de su carne están apretadas: Están en él firmes, y no se mueven. [^23] Su corazón es firme como una piedra, Y fuerte como la muela de abajo. [^24] De su grandeza tienen temor los fuertes, Y á causa de su desfallecimiento hacen por purificarse. [^25] Cuando alguno lo alcanzare, ni espada, Ni lanza, ni dardo, ni coselete durará. [^26] El hierro estima por pajas, Y el acero por leño podrido. [^27] Saeta no le hace huir; Las piedras de honda se le tornan aristas. [^28] Tiene toda arma por hojarascas, Y del blandir de la pica se burla. [^29] Por debajo tiene agudas conchas; Imprime su agudez en el suelo. [^30] Hace hervir como una olla la profunda mar, Y tórnala como una olla de ungüento. [^31] En pos de sí hace resplandecer la senda, Que parece que la mar es cana. [^32] No hay sobre la tierra su semejante, Hecho para nada temer. [^33] Menosprecia toda cosa alta: Es rey sobre todos los soberbios. [^34] 

[[Job - 40|<--]] Job - 41 [[Job - 42|-->]]

---
# Notes
