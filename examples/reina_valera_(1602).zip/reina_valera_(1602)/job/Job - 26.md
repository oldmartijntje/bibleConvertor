---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 26 - Reina Valera (1602)"
---
[[Job - 25|<--]] Job - 26 [[Job - 27|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 26

Y RESPONDIO Job, y dijo: [^1] ¿En qué ayudaste al que no tiene fuerza? ¿Has amparado al brazo sin fortaleza? [^2] ¿En qué aconsejaste al que no tiene ciencia, Y mostraste bien sabiduría? [^3] ¿A quién has anunciado palabras, Y cuyo es el espíritu que de ti sale? [^4] Cosas inanimadas son formadas Debajo de las aguas, y los habitantes de ellas. [^5] El sepulcro es descubierto delante de él, Y el infierno no tiene cobertura. [^6] Extiende el alquilón sobre vacío, Cuelga la tierra sobre nada. [^7] Ata las aguas en sus nubes, Y las nubes no se rompen debajo de ellas. [^8] El restriñe la faz de su trono, Y sobre él extiende su nube. [^9] El cercó con término la superficie de las aguas, Hasta el fin de la luz y las tinieblas. [^10] Las columnas del cielo tiemblan, Y se espantan de su reprensión. [^11] El rompe la mar con su poder, Y con su entendimiento hiere la hinchazón suya. [^12] Su espíritu adornó los cielos; Su mano crió la serpiente tortuosa. [^13] He aquí, estas son partes de sus caminos: ­Mas cuán poco hemos oído de él! Porque el estruendo de sus fortalezas, ¿quién lo detendrá? [^14] 

[[Job - 25|<--]] Job - 26 [[Job - 27|-->]]

---
# Notes
