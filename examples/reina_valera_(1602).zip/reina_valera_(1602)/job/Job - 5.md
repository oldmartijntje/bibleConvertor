---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 5 - Reina Valera (1602)"
---
[[Job - 4|<--]] Job - 5 [[Job - 6|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 5

AHORA pues da voces, si habrá quien te responda; ¿Y á cuál de los santos te volverás? [^1] Es cierto que al necio la ira lo mata, Y al codicioso consume la envidia. [^2] Yo he visto al necio que echaba raíces, Y en la misma hora maldije su habitación. [^3] Sus hijos estarán lejos de la salud, Y en la puerta serán quebrantados, Y no habrá quien los libre. [^4] Su mies comerán los hambrientos, Y sacaránla de entre las espinas, Y los sedientos beberán su hacienda. [^5] Porque la iniquidad no sale del polvo, Ni la molestia brota de la tierra. [^6] Empero como las centellas se levantan para volar por el aire, Así el hombre nace para la aflicción. [^7] Ciertamente yo buscaría á Dios, Y depositaría en él mis negocios: [^8] El cual hace cosas grandes é inescrutables, Y maravillas que no tienen cuento: [^9] Que da la lluvia sobre la haz de la tierra, Y envía las aguas por los campos: [^10] Que pone los humildes en altura, Y los enlutados son levantados á salud: [^11] Que frustra los pensamientos de los astutos, Para que sus manos no hagan nada: [^12] Que prende á los sabios en la astucia de ellos, Y el consejo de los perversos es entontecido; [^13] De día se topan con tinieblas, Y en mitad del día andan á tientas como de noche: [^14] Y libra de la espada al pobre, de la boca de los impíos, Y de la mano violenta; [^15] Pues es esperanza al menesteroso, Y la iniquidad cerrará su boca. [^16] He aquí, bienaventurado es el hombre á quien Dios castiga: Por tanto no menosprecies la corrección del Todopoderoso. [^17] Porque él es el que hace la llaga, y él la vendará: El hiere, y sus manos curan. [^18] En seis tribulaciones te librará, Y en la séptima no te tocará el mal. [^19] En el hambre te redimirá de la muerte, Y en la guerra de las manos de la espada. [^20] Del azote de la lengua serás encubierto; Ni temerás de la destrucción cuando viniere. [^21] De la destrucción y del hambre te reirás, Y no temerás de las bestias del campo: [^22] Pues aun con las piedras del campo tendrás tu concierto, Y las bestias del campo te serán pacíficas. [^23] Y sabrás que hay paz en tu tienda; Y visitarás tu morada, y no pecarás. [^24] Asimismo echarás de ver que tu simiente es mucha, Y tu prole como la hierba de la tierra. [^25] Y vendrás en la vejez á la sepultura, Como el montón de trigo que se coge á su tiempo. [^26] He aquí lo que hemos inquirido, lo cual es así: Oyelo, y juzga tú para contigo. [^27] 

[[Job - 4|<--]] Job - 5 [[Job - 6|-->]]

---
# Notes
