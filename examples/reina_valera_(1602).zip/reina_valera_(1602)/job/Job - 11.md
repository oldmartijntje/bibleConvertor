---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 11 - Reina Valera (1602)"
---
[[Job - 10|<--]] Job - 11 [[Job - 12|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 11

Y RESPONDIO Sophar Naamathita, y dijo: [^1] ¿Las muchas palabras no han de tener respuesta? ¿Y el hombre parlero será justificado? [^2] ¿Harán tus falacias callar á los hombres? ¿Y harás escarnio, y no habrá quien te avergüence? [^3] Tú dices: Mi conversar es puro, Y yo soy limpio delante de tus ojos. [^4] Mas ­oh quién diera que Dios hablara, Y abriera sus labios contigo, [^5] Y que te declarara los arcanos de la sabiduría, Que son de doble valor que la hacienda! Conocerías entonces que Dios te ha castigado menos que tu iniquidad merece. [^6] ¿Alcanzarás tú el rastro de Dios? ¿Llegarás tú á la perfección del Todopoderoso? [^7] Es más alto que los cielos: ¿qué harás? Es más profundo que el infierno: ¿cómo lo conocerás? [^8] Su dimensión es más larga que la tierra, Y más ancha que la mar. [^9] Si cortare, ó encerrare, O juntare, ¿quién podrá contrarrestarle? [^10] Porque él conoce á los hombres vanos: Ve asimismo la iniquidad, ¿y no hará caso? [^11] El hombre vano se hará entendido, Aunque nazca como el pollino del asno montés. [^12] Si tú apercibieres tu corazón, Y extendieres á él tus manos; [^13] Si alguna iniquidad hubiere en tu mano, y la echares de ti, Y no consintieres que more maldad en tus habitaciones; [^14] Entonces levantarás tu rostro limpio de mancha, Y serás fuerte y no temerás: [^15] Y olvidarás tu trabajo, O te acordarás de él como de aguas que pasaron: [^16] Y en mitad de la siesta se levantará bonanza; Resplandecerás, y serás como la mañana: [^17] Y confiarás, que habrá esperanza; Y cavarás, y dormirás seguro: [^18] Y te acostarás, y no habrá quien te espante: Y muchos te rogarán. [^19] Mas los ojos de los malos se consumirán, Y no tendrán refugio; Y su esperanza será agonía del alma. [^20] 

[[Job - 10|<--]] Job - 11 [[Job - 12|-->]]

---
# Notes
