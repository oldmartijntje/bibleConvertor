---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 2 - Reina Valera (1602)"
---
[[Job - 1|<--]] Job - 2 [[Job - 3|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 2

Y OTRO día aconteció que vinieron los hijos de Dios para presentarse delante de Jehová, y Satán vino también entre ellos pareciendo delante de Jehová. [^1] Y dijo Jehová á Satán: ¿De dónde vienes? Respondió Satán á Jehová, y dijo: De rodear la tierra, y de andar por ella. [^2] Y Jehová dijo á Satán: ¿No has considerado á mi siervo Job, que no hay otro como él en la tierra, varón perfecto y recto, temeroso de Dios y apartado de mal, y que aun retiene su perfección, habiéndome tú incitado contra él, para que lo arruinara sin causa? [^3] Y respondiendo Satán dijo á Jehová: Piel por piel, todo lo que el hombre tiene dará por su vida. [^4] Mas extiende ahora tu mano, y toca á su hueso y á su carne, y verás si no te blasfema en tu rostro. [^5] Y Jehová dijo á Satán: He aquí, él está en tu mano; mas guarda su vida. [^6] Y salió Satán de delante de Jehová, é hirió á Job de una maligna sarna desde la planta de su pie hasta la mollera de su cabeza. [^7] Y tomaba una teja para rascarse con ella, y estaba sentado en medio de ceniza. [^8] Díjole entonces su mujer: ¿Aun retienes tú tu simplicidad? Bendice á Dios, y muérete. [^9] Y él le dijo: Como suele hablar cualquiera de las mujeres fatuas, has hablado. También recibimos el bien de Dios, ¿y el mal no recibiremos? En todo esto no pecó Job con sus labios. [^10] Y tres amigos de Job, Eliphaz Temanita, y Bildad Suhita, y Sophar Naamathita, luego que oyeron todo este mal que le había sobrevenido, vinieron cada uno de su lugar; porque habían concertado de venir juntos á condolecerse de él, y á consolarle. [^11] Los cuales alzando los ojos desde lejos, no lo conocieron, y lloraron á voz en grito; y cada uno de ellos rasgó su manto, y esparcieron polvo sobre sus cabezas hacia el cielo. [^12] Así se sentaron con él en tierra por siete días y siete noches, y ninguno le hablaba palabra, porque veían que el dolor era muy grande. [^13] 

[[Job - 1|<--]] Job - 2 [[Job - 3|-->]]

---
# Notes
