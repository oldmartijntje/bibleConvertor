---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 10 - Reina Valera (1602)"
---
[[Job - 9|<--]] Job - 10 [[Job - 11|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 10

ESTA mi alma aburrida de mi vida: Daré yo suelta á mi queja sobre mí, Hablaré con amargura de mi alma. [^1] Diré á Dios: no me condenes; Hazme entender por qué pleiteas conmigo. [^2] ¿Parécete bien que oprimas, Que deseches la obra de tus manos, Y que resplandezcas sobre el consejo de los impíos? [^3] ¿Tienes tú ojos de carne? ¿Ves tú como ve el hombre? [^4] ¿Son tus días como los días del hombre, O tus años como los tiempos humanos, [^5] Para que inquieras mi iniquidad, Y busques mi pecado, [^6] Sobre saber tú que no soy impío, Y que no hay quien de tu mano libre? [^7] Tus manos me formaron y me compusieron Todo en contorno: ¿y así me deshaces? [^8] Acuérdate ahora que como á lodo me diste forma: ¿Y en polvo me has de tornar? [^9] ¿No me fundiste como leche, Y como un queso me cuajaste? [^10] Vestísteme de piel y carne, Y cubrísteme de huesos y nervios. [^11] Vida y misericordia me concediste, Y tu visitación guardó mi espíritu. [^12] Y estas cosas tienes guardadas en tu corazón; Yo sé que esto está cerca de ti. [^13] Si pequé, tú me has observado, Y no me limpias de mi iniquidad. [^14] Si fuere malo, ­ay de mí! Y si fuere justo, no levantaré mi cabeza, Estando harto de deshonra, Y de verme afligido. [^15] Y subirá de punto, pues me cazas como á león, Y tornas á hacer en mí maravillas. [^16] Renuevas contra mí tus plagas, Y aumentas conmigo tu furor, Remudándose sobre mí ejércitos. [^17] ¿Por qué me sacaste de la matriz? Habría yo espirado, y no me vieran ojos. [^18] Fuera, como si nunca hubiera sido, Llevado desde el vientre á la sepultura. [^19] ¿No son mis días poca cosa? Cesa pues, y déjame, para que me conforte un poco. [^20] Antes que vaya para no volver, A la tierra de tinieblas y de sombra de muerte; [^21] Tierra de oscuridad, lóbrega Como sombra de muerte, sin orden, Y que aparece como la oscuridad misma. [^22] 

[[Job - 9|<--]] Job - 10 [[Job - 11|-->]]

---
# Notes
