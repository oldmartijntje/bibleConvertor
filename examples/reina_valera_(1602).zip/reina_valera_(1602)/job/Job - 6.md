---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 6 - Reina Valera (1602)"
---
[[Job - 5|<--]] Job - 6 [[Job - 7|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 6

Y RESPONDIO Job y dijo: [^1] Oh si pesasen al justo mi queja y mi tormento, Y se alzasen igualmente en balanza! [^2] Porque pesaría aquél más que la arena del mar: Y por tanto mis palabras son cortadas. [^3] Porque las saetas del Todopoderoso están en mí, Cuyo veneno bebe mi espíritu; Y terrores de Dios me combaten. [^4] ¿Acaso gime el asno montés junto á la hierba? ¿Muge el buey junto á su pasto? [^5] ¿Comeráse lo desabrido sin sal? ¿O habrá gusto en la clara del huevo? [^6] Las cosas que mi alma no quería tocar, Por los dolores son mi comida. [^7] Quién me diera que viniese mi petición, Y que Dios me otorgase lo que espero; [^8] Y que pluguiera á Dios quebrantarme; Que soltara su mano, y me deshiciera! [^9] Y sería aún mi consuelo, Si me asaltase con dolor sin dar más tregua, Que yo no he escondido las palabras del Santo. [^10] ¿Cuál es mi fortaleza para esperar aún? ¿Y cuál mi fin para dilatar mi vida? [^11] ¿Es mi fortaleza la de las piedras? ¿O mi carne, es de acero? [^12] ¿No me ayudo cuanto puedo, Y el poder me falta del todo? [^13] El atribulado es consolado de su compañero: Mas hase abandonado el temor del Omnipotente. [^14] Mis hermanos han mentido cual arroyo: Pasáronse como corrientes impetuosas, [^15] Que están escondidas por la helada, Y encubiertas con nieve; [^16] Que al tiempo del calor son deshechas, Y en calentándose, desaparecen de su lugar; [^17] Apártanse de la senda de su rumbo, Van menguando y piérdense. [^18] Miraron los caminantes de Temán, Los caminantes de Saba esperaron en ellas: [^19] Mas fueron avergonzados por su esperanza; Porque vinieron hasta ellas, y halláronse confusos. [^20] Ahora ciertamente como ellas sois vosotros: Que habéis visto el tormento, y teméis. [^21] ¿Os he dicho yo: Traedme, Y pagad por mí de vuestra hacienda; [^22] Y libradme de la mano del opresor, Y redimidme del poder de los violentos? [^23] Enseñadme, y yo callaré: Y hacedme entender en qué he errado. [^24] Cuán fuertes son las palabras de rectitud! Mas ¿qué reprende el que reprende de vosotros? [^25] ¿Pensáis censurar palabras, Y los discursos de un desesperado, que son como el viento? [^26] También os arrojáis sobre el huérfano, Y hacéis hoyo delante de vuestro amigo. [^27] Ahora pues, si queréis, mirad en mí, Y ved si miento delante de vosotros. [^28] Tornad ahora, y no haya iniquidad; Volved aún á considerar mi justicia en esto. [^29] ¿Hay iniquidad en mi lengua? ¿No puede mi paladar discernir las cosas depravadas? [^30] 

[[Job - 5|<--]] Job - 6 [[Job - 7|-->]]

---
# Notes
