---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 16 - Reina Valera (1602)"
---
[[Job - 15|<--]] Job - 16 [[Job - 17|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 16

Y RESPONDIO Job, y dijo: [^1] Muchas veces he oído cosas como estas: Consoladores molestos sois todos vosotros. [^2] ¿Tendrán fin las palabras ventosas? O ¿qué te animará á responder? [^3] También yo hablaría como vosotros. Ojalá vuestra alma estuviera en lugar de la mía, Que yo os tendría compañía en las palabras, Y sobre vosotros movería mi cabeza. [^4] Mas yo os alentaría con mis palabras, Y la consolación de mis labios apaciguaría el dolor vuestro. [^5] Si hablo, mi dolor no cesa; Y si dejo de hablar, no se aparta de mí. [^6] Empero ahora me ha fatigado: Has tú asolado toda mi compañía. [^7] Tú me has arrugado; testigo es mi flacura, Que se levanta contra mí para testificar en mi rostro. [^8] Su furor me destrizó, y me ha sido contrario: Crujió sus dientes contra mí; Contra mí aguzó sus ojos mi enemigo. [^9] Abrieron contra mí su boca; Hirieron mis mejillas con afrenta; Contra mí se juntaron todos. [^10] Hame entregado Dios al mentiroso, Y en las manos de los impíos me hizo estremecer. [^11] Próspero estaba, y desmenuzóme: Y arrebatóme por la cerviz, y despedazóme, Y púsome por blanco suyo. [^12] Cercáronme sus flecheros, Partió mis riñones, y no perdonó: Mi hiel derramó por tierra. [^13] Quebrantóme de quebranto sobre quebranto; Corrió contra mí como un gigante. [^14] Yo cosí saco sobre mi piel, Y cargué mi cabeza de polvo. [^15] Mi rostro está enlodado con lloro, Y mis párpados entenebrecidos: [^16] A pesar de no haber iniquidad en mis manos, Y de haber sido mi oración pura. [^17] Oh tierra! no cubras mi sangre, Y no haya lugar á mi clamor. [^18] Mas he aquí que en los cielos está mi testigo, Y mi testimonio en las alturas. [^19] Disputadores son mis amigos: Mas á Dios destilarán mis ojos. [^20] Ojalá pudiese disputar el hombre con Dios, Como con su prójimo! [^21] Mas los años contados vendrán, Y yo iré el camino por donde no volveré. [^22] 

[[Job - 15|<--]] Job - 16 [[Job - 17|-->]]

---
# Notes
