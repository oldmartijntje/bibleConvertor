---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 37 - Reina Valera (1602)"
---
[[Job - 36|<--]] Job - 37 [[Job - 38|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 37

A ESTO también se espanta mi corazón, Y salta de su lugar. [^1] Oid atentamente su voz terrible, y el sonido que sale de su boca. [^2] Debajo de todos los cielos lo dirige, Y su luz hasta los fines de la tierra. [^3] Después de ella bramará el sonido, Tronará él con la voz de su magnificencia; Y aunque sea oída su voz, no los detiene. [^4] Tronará Dios maravillosamente con su voz; El hace grandes cosas, que nosotros no entendemos. [^5] Porque á la nieve dice: Desciende á la tierra; También á la llovizna, Y á los aguaceros de su fortaleza. [^6] Así hace retirarse á todo hombre, Para que los hombres todos reconozcan su obra. [^7] La bestia se entrará en su escondrijo, Y estaráse en sus moradas. [^8] Del mediodía viene el torbellino, Y el frío de los vientos del norte. [^9] Por el soplo de Dios se da el hielo, Y las anchas aguas son constreñidas. [^10] Regando también llega á disipar la densa nube, Y con su luz esparce la niebla. [^11] Asimismo por sus designios se revuelven las nubes en derredor, Para hacer sobre la haz del mundo, En la tierra, lo que él les mandara. [^12] Unas veces por azote, otras pos causa de su tierra, Otras por misericordia las hará parecer. [^13] Escucha esto, Job; Repósate, y considera las maravillas de Dios. [^14] ¿Supiste tú cuándo Dios las ponía en concierto, Y hacía levantar la luz de su nube? [^15] ¿Has tú conocido las diferencias de las nubes, Las maravillas del Perfecto en sabiduría? [^16] ¿Por qué están calientes tus vestidos Cuando se fija el viento del mediodía sobre la tierra? [^17] ¿Extendiste tú con él los cielos, Firmes como un espejo sólido? [^18] Muéstranos qué le hemos de decir; Porque nosotros no podemos componer las ideas á causa de las tinieblas. [^19] ¿Será preciso contarle cuando yo hablaré? Por más que el hombre razone, quedará como abismado. [^20] He aquí aún: no se puede mirar la luz esplendente en los cielos, Luego que pasa el viento y los limpia, [^21] Viniendo de la parte del norte la dorada claridad. En Dios hay una majestad terrible. [^22] El es Todopoderoso, al cual no alcanzamos, grande en potencia; Y en juicio y en multitud de justicia no afligirá. [^23] Temerlo han por tanto los hombres: El no mira á los sabios de corazón. [^24] 

[[Job - 36|<--]] Job - 37 [[Job - 38|-->]]

---
# Notes
