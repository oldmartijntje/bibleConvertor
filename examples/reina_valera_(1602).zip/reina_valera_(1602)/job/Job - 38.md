---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 38 - Reina Valera (1602)"
---
[[Job - 37|<--]] Job - 38 [[Job - 39|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 38

Y RESPONDIO Jehová á Job desde un torbellino, y dijo: [^1] ¿Quién es ése que oscurece el consejo Con palabras sin sabiduría? [^2] Ahora ciñe como varón tus lomos; Yo te preguntaré, y hazme saber tú. [^3] ¿Dónde estabas cuando yo fundaba la tierra? Házme lo saber, si tienes inteligencia. [^4] ¿Quién ordenó sus medidas, si lo sabes? ¿O quién extendió sobre ella cordel? [^5] ¿Sobre qué están fundadas sus basas? ¿O quién puso su piedra angular, [^6] Cuando las estrellas todas del alba alababan, Y se regocijaban todos los hijos de Dios? [^7] ¿Quién encerró con puertas la mar, Cuando se derramaba por fuera como saliendo de madre; [^8] Cuando puse yo nubes por vestidura suya, Y por su faja oscuridad. [^9] Y establecí sobre ella mi decreto, Y le puse puertas y cerrojo, [^10] Y dije: Hasta aquí vendrás, y no pasarás adelante, Y ahí parará la hinchazón de tus ondas? [^11] ¿Has tu mandado á la mañana en tus días? ¿Has mostrado al alba su lugar, [^12] Para que ocupe los fines de la tierra, Y que sean sacudidos de ella los impíos? [^13] Trasmúdase como lodo bajo de sello, Y viene á estar como con vestidura: [^14] Mas la luz de los impíos es quitada de ellos, Y el brazo enaltecido es quebrantado. [^15] ¿Has entrado tú hasta los profundos de la mar, Y has andado escudriñando el abismo? [^16] ¿Hante sido descubiertas las puertas de la muerte, Y has visto las puertas de la sombra de muerte? [^17] ¿Has tú considerado hasta las anchuras de la tierra? Declara si sabes todo esto. [^18] ¿Por dónde va el camino á la habitación de la luz, Y dónde está el lugar de las tinieblas? [^19] ¿Si llevarás tú ambas cosas á sus términos, Y entenderás las sendas de su casa? [^20] ¿Sabíaslo tú porque hubieses ya nacido, O porque es grande el número de tus días? [^21] ¿Has tú entrado en los tesoros de la nieve, O has visto los tesoros del granizo, [^22] Lo cual tengo yo reservado para el tiempo de angustia, Para el día de la guerra y de la batalla? [^23] ¿Por qué camino se reparte la luz, Y se esparce el viento solano sobre la tierra? [^24] ¿Quién repartió conducto al turbión, Y camino á los relámpagos y truenos, [^25] Haciendo llover sobre la tierra deshabitada, Sobre el desierto, donde no hay hombre, [^26] Para hartar la tierra desierta é inculta, Y para hacer brotar la tierna hierba? [^27] ¿Tiene la lluvia padre? ¿O quién engendró las gotas del rocío? [^28] ¿De qué vientre salió el hielo? Y la escarcha del cielo, ¿quién la engendró? [^29] Las aguas se endurecen á manera de piedra, Y congélase la haz del abismo. [^30] ¿Podrás tú impedir las delicias de las Pléyades, O desatarás las ligaduras del Orión? [^31] ¿Sacarás tú á su tiempo los signos de los cielos, O guiarás el Arcturo con sus hijos? [^32] ¿Supiste tú las ordenanzas de los cielos? ¿Dispondrás tú de su potestad en la tierra? [^33] ¿Alzarás tú á las nubes tu voz, Para que te cubra muchedumbre de aguas? [^34] ¿Enviarás tú los relámpagos, para que ellos vayan? ¿Y diránte ellos: Henos aquí? [^35] ¿Quién puso la sabiduría en el interior? ¿O quién dió al entendimiento la inteligencia? [^36] ¿Quién puso por cuenta los cielos con sabiduría? Y los odres de los cielos, ¿quién los hace parar, [^37] Cuando el polvo se ha convertido en dureza, Y los terrones se han pegado unos con otros? [^38] ¿CAZARAS tú la presa para el león? ¿Y saciarás el hambre de los leoncillos, [^39] Cuando están echados en las cuevas, O se están en sus guaridas para acechar? [^40] ¿Quién preparó al cuervo su alimento, Cuando sus pollos claman á Dios, Bullendo de un lado á otro por carecer de comida? [^41] 

[[Job - 37|<--]] Job - 38 [[Job - 39|-->]]

---
# Notes
