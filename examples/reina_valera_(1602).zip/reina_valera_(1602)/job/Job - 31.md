---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 31 - Reina Valera (1602)"
---
[[Job - 30|<--]] Job - 31 [[Job - 32|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 31

HICE pacto con mis ojos: ¿Cómo pues había yo de pensar en virgen? [^1] Porque ¿qué galardón me daría de arriba Dios, Y qué heredad el Omnipotente de las alturas? [^2] ¿No hay quebrantamiento para el impío, Y extrañamiento para los que obran iniquidad? [^3] ¿No ve él mis caminos, Y cuenta todos mis pasos? [^4] Si anduve con mentira, Y si mi pie se apresuró á engaño, [^5] Péseme Dios en balanzas de justicia, Y conocerá mi integridad. [^6] Si mis pasos se apartaron del camino, Y si mi corazón se fué tras mis ojos, Y si algo se apegó á mis manos, [^7] Siembre yo, y otro coma, Y mis verduras sean arrancadas. [^8] Si fué mi corazón engañado acerca de mujer, Y si estuve acechando á la puerta de mi prójimo: [^9] Muela para otro mi mujer, Y sobre ella otros se encorven. [^10] Porque es maldad é iniquidad, Que han de castigar los jueces. [^11] Porque es fuego que devoraría hasta el sepulcro, Y desarraigaría toda mi hacienda. [^12] Si hubiera tenido en poco el derecho de mi siervo y de mi sierva, Cuando ellos pleitearan conmigo, [^13] ¿Qué haría yo cuando Dios se levantase? Y cuando él visitara, ¿qué le respondería yo? [^14] El que en el vientre me hizo á mí, ¿no lo hizo á él? ¿Y no nos dispuso uno mismo en la matriz? [^15] Si estorbé el contento de los pobres, E hice desfallecer los ojos de la viuda; [^16] Y si comí mi bocado solo, Y no comió de él el huerfano; [^17] (Porque desde mi mocedad creció conmigo como con padre, Y desde el vientre de mi madre fuí guía de la viuda;) [^18] Si he visto que pereciera alguno sin vestido, Y al menesteroso sin cobertura; [^19] Si no me bendijeron sus lomos, Y del vellón de mis ovejas se calentaron; [^20] Si alcé contra el huérfano mi mano, Aunque viese que me ayudarían en la puerta; [^21] Mi espalda se caiga de mi hombro, Y mi brazo sea quebrado de mi canilla. [^22] Porque temí el castigo de Dios, Contra cuya alteza yo no tendría poder. [^23] Si puse en oro mi esperanza, Y dije al oro: Mi confianza eres tú; [^24] Si me alegré de que mi hacienda se multiplicase, Y de que mi mano hallase mucho; [^25] Si he mirado al sol cuando resplandecía, Y á la luna cuando iba hermosa, [^26] Y mi corazón se engañó en secreto, Y mi boca besó mi mano: [^27] Esto también fuera maldad juzgada; Porque habría negado al Dios soberano. [^28] Si me alegré en el quebrantamiento del que me aborrecía, Y me regocijé cuando le halló el mal; [^29] (Que ni aun entregué al pecado mi paladar, Pidiendo maldición para su alma;) [^30] Cuando mis domésticos decían: ­Quién nos diese de su carne! nunca nos hartaríamos. [^31] El extranjero no tenía fuera la noche; Mis puertas abría al caminante. [^32] Si encubrí, como los hombres mis prevaricaciones, Escondiendo en mi seno mi iniquidad; [^33] Porque quebrantaba á la gran multitud, Y el menosprecio de las familias me atemorizó, Y callé, y no salí de mi puerta: [^34] Quién me diera quien me oyese! He aquí mi impresión es que el Omnipotente testificaría por mí, Aunque mi adversario me hiciera el proceso. [^35] Ciertamente yo lo llevaría sobre mi hombro, Y me lo ataría en lugar de corona. [^36] Yo le contaría el número de mis pasos, Y como príncipe me llegaría á él. [^37] Si mi tierra clama contra mí, Y lloran todos sus surcos; [^38] Si comí su sustancia sin dinero, O afligí el alma de sus dueños; [^39] En lugar de trigo me nazcan abrojos, Y espinas en lugar de cebada. [^40] 

[[Job - 30|<--]] Job - 31 [[Job - 32|-->]]

---
# Notes
