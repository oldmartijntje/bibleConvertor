---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 18 - Reina Valera (1602)"
---
[[Job - 17|<--]] Job - 18 [[Job - 19|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Job]]

# Job - 18

Y RESPONDIO Bildad Suhita, y dijo: [^1] ¿Cuándo pondréis fin á las palabras? Entended, y después hablemos. [^2] ¿Por qué somos tenidos por bestias, Y en vuestros ojos somos viles? [^3] Oh tú, que despedazas tu alma con tu furor, ¿Será dejada la tierra por tu causa, Y serán traspasadas de su lugar las peñas? [^4] Ciertamente la luz de los impíos será apagada, Y no resplandecerá la centella de su fuego. [^5] La luz se oscurecerá en su tienda, Y apagaráse sobre él su lámpara. [^6] Los pasos de su pujanza serán acortados, Y precipitarálo su mismo consejo. [^7] Porque red será echada en sus pies, Y sobre red andará. [^8] Lazo prenderá su calcañar: Afirmaráse la trampa contra él. [^9] Su cuerda está escondida en la tierra, Y su torzuelo sobre la senda. [^10] De todas partes lo asombrarán temores, Y haránle huir desconcertado. [^11] Su fuerza será hambrienta, Y á su lado estará aparejado quebrantamiento. [^12] El primogénito de la muerte comerá los ramos de su piel, Y devorará sus miembros. [^13] Su confianza será arrancada de su tienda, Y harále esto llevar al rey de los espantos. [^14] En su tienda morará como si no fuese suya: Piedra azufre será esparcida sobre su morada. [^15] Abajo se secarán sus raíces, Y arriba serán cortadas sus ramas. [^16] Su memoria perecerá de la tierra, Y no tendrá nombre por las calles. [^17] De la luz será lanzado á las tinieblas, Y echado fuera del mundo. [^18] No tendrá hijo ni nieto en su pueblo, Ni quien le suceda en sus moradas. [^19] Sobre su día se espantarán los por venir, Como ocupó el pavor á los que fueron antes. [^20] Ciertamente tales son las moradas del impío, Y este será el lugar del que no conoció á Dios. [^21] 

[[Job - 17|<--]] Job - 18 [[Job - 19|-->]]

---
# Notes
