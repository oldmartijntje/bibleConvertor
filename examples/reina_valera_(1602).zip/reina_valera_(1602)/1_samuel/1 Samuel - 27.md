---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 27 - Reina Valera (1602)"
---
[[1 Samuel - 26|<--]] 1 Samuel - 27 [[1 Samuel - 28|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Samuel]]

# 1 Samuel - 27

Y DIJO David en su corazón: Al fin seré muerto algún día por la mano de Saúl: nada por tanto me será mejor que fugarme á la tierra de los Filisteos, para que Saúl se deje de mí, y no me ande buscando más por todos los términos de Israel, y así me escaparé de sus manos. [^1] Levantóse pues David, y con los seiscientos hombres que tenía consigo pasóse á Achîs hijo de Maoch, rey de Gath. [^2] Y moró David con Achîs en Gath, él y los suyos, cada uno con su familia: David con sus dos mujeres, Ahinoam Jezreelita, y Abigail, la que fué mujer de Nabal el del Carmelo. [^3] Y vino la nueva á Saúl que David se había huído á Gath, y no lo buscó más. [^4] Y David dijo á Achîs: Si he hallado ahora gracia en tus ojos, séame dado lugar en algunas de las ciudades de la tierra, donde habite: porque ¿ha de morar tu siervo contigo en la ciudad real? [^5] Y Achîs le dió aquel día á Siclag. De aquí fué Siclag de los reyes de Judá hasta hoy. [^6] Y fué el número de los días que David habitó en la tierra de los Filisteos, cuatro meses y algunos días. [^7] Y subía David con los suyos, y hacían entradas en los Gesureos, y en los Gerzeos, y en los Amalecitas: porque estos habitaban de largo tiempo la tierra, desde como se va á Shur hasta la tierra de Egipto. [^8] Y hería David el país, y no dejaba á vida hombre ni mujer: y llevábase las ovejas y las vacas y los asnos y los camellos y las ropas; y volvía, y veníase á Achîs. [^9] Y decía Achîs: ¿Dónde habéis corrido hoy? Y David decía: Al mediodía de Judá, y al mediodía de Jerameel, ó contra el mediodía de Ceni. [^10] Ni hombre ni mujer dejaba á vida David, que viniese á Gath; diciendo: Porque no den aviso de nosotros, diciendo: Esto hizo David. Y esta era su costumbre todo el tiempo que moró en tierra de los Filisteos. [^11] Y Achîs creía á David, diciendo así: El se hace abominable en su pueblo de Israel, y será siempre mi siervo. [^12] 

[[1 Samuel - 26|<--]] 1 Samuel - 27 [[1 Samuel - 28|-->]]

---
# Notes
