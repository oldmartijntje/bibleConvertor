---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 4 - Reina Valera (1602)"
---
[[1 Samuel - 3|<--]] 1 Samuel - 4 [[1 Samuel - 5|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Samuel]]

# 1 Samuel - 4

Y SAMUEL habló á todo Israel. Por aquel tiempo salió Israel á encontrar en batalla á los Filisteos, y asentó campo junto á Eben-ezer, y los Filisteos asentaron el suyo en Aphec. [^1] Y los Filisteos presentaron la batalla á Israel; y trabándose el combate, Israel fué vencido delante de los Filisteos, los cuales hirieron en la batalla por el campo como cuatro mil hombres. [^2] Y vuelto que hubo el pueblo al campamento, los ancianos de Israel dijeron: ¿Por qué nos ha herido hoy Jehová delante de los Filisteos? Traigamos á nosotros de Silo el arca del pacto de Jehová, para que viniendo entre nosotros nos salve de la mano de nuestros enemigos. [^3] Y envió el pueblo á Silo, y trajeron de allá el arca del pacto de Jehová de los ejércitos, que estaba asentado entre los querubines; y los dos hijos de Eli, Ophni y Phinees, estaban allí con el arca del pacto de Dios. [^4] Y aconteció que, como el arca del pacto de Jehová vino al campo, todo Israel dió grita con tan grande júbilo, que la tierra tembló. [^5] Y cuando los Filisteos oyeron la voz de júbilo, dijeron: ¿Qué voz de gran júbilo es esta en el campo de los Hebreos? Y supieron que el arca de Jehová había venido al campo. [^6] Y los Filisteos tuvieron miedo, porque decían: Ha venido Dios al campo. Y dijeron: ­Ay de nosotros! pues antes de ahora no fué así. [^7] Ay de nosotros! ¿Quién nos librará de las manos de estos dioses fuertes? Estos son los dioses que hirieron á Egipto con toda plaga en el desierto. [^8] Esforzaos, oh Filisteos, y sed hombres, porque no sirváis á los Hebreos, como ellos os han servido á vosotros: sed hombres, y pelead. [^9] Pelearon pues los Filisteos, é Israel fué vencido, y huyeron cada cual á sus tiendas; y fué hecha muy grande mortandad, pues cayeron de Israel treinta mil hombres de á pie. [^10] Y el arca de Dios fué tomada, y muertos los dos hijos de Eli, Ophni y Phinees. [^11] Y corriendo de la batalla un hombre de Benjamín, vino aquel día á Silo, rotos sus vestidos y tierra sobre su cabeza: [^12] Y cuando llegó, he aquí Eli que estaba sentado en una silla atalayando junto al camino; porque su corazón estaba temblando por causa del arca de Dios. Llegado pues aquel hombre á la ciudad, y dadas las nuevas, toda la ciudad gritó. [^13] Y como Eli oyó el estruendo de la gritería, dijo: ¿Qué estruendo de alboroto es éste? Y aquel hombre vino apriesa, y dió las nuevas á Eli. [^14] Era ya Eli de edad de noventa y ocho años, y sus ojos se habían entenebrecido, de modo que no podía ver. [^15] Dijo pues aquel hombre á Eli: Yo vengo de la batalla, yo he escapado hoy del combate. Y él dijo: ¿Qué ha acontecido, hijo mío? [^16] Y el mensajero respondió, y dijo: Israel huyó delante de los Filisteos, y también fué hecha gran mortandad en el pueblo; y también tus dos hijos, Ophni y Phinees, son muertos, y el arca de Dios fué tomada. [^17] Y aconteció que como él hizo mención del arca de Dios, Eli cayó hacia atrás de la silla al lado de la puerta, y quebrósele la cerviz, y murió: porque era hombre viejo y pesado. Y había juzgado á Israel cuarenta años. [^18] Y su nuera, la mujer de Phinees, que estaba preñada, cercana al parto, oyendo el rumor que el arca de Dios era tomada, y muertos su suegro y su marido, encorvóse y parió; porque sus dolores se habían ya derramado por ella. [^19] Y al tiempo que se moría, decíanle las que estaban junto á ella: No tengas temor, porque has parido un hijo. Mas ella no respondió, ni paró mientes. [^20] Y llamó al niño Ichâbod, diciendo: ­Traspasada es la gloria de Israel! por el arca de Dios que fué tomada, y porque era muerto su suegro, y su marido. [^21] Dijo pues: Traspasada es la gloria de Israel: porque el arca de Dios fué tomada. [^22] 

[[1 Samuel - 3|<--]] 1 Samuel - 4 [[1 Samuel - 5|-->]]

---
# Notes
