---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 22 - Reina Valera (1602)"
---
[[1 Samuel - 21|<--]] 1 Samuel - 22 [[1 Samuel - 23|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Samuel]]

# 1 Samuel - 22

Y YÉNDOSE David de allí escapóse á la cueva de Adullam; lo cual como oyeron sus hermanos y toda la casa de su padre, vinieron allí á él. [^1] Y juntáronse con él todos los afligidos, y todo el que estaba adeudado, y todos los que se hallaban en amargura de espíritu, y fué hecho capitán de ellos: y tuvo consigo como cuatrocientos hombres. [^2] Y fuése David de allí á Mizpa de Moab, y dijo al rey de Moab: Yo te ruego que mi padre y mi madre estén con vosotros, hasta que sepa lo que Dios hará de mí. [^3] Trájolos pues á la presencia del rey de Moab, y habitaron con él todo el tiempo que David estuvo en la fortaleza. [^4] Y Gad profeta dijo á David: No te estés en esta fortaleza, pártete, y vete á tierra de Judá. Y David se partió, y vino al bosque de Hareth. [^5] Y oyó Saúl como había parecido David, y los que estaban con él. Estaba entonces Saúl en Gabaa debajo de un árbol en Rama, y tenía su lanza en su mano, y todos sus criados estaban en derredor de él. [^6] Y dijo Saúl á sus criados que estaban en derredor de él: Oid ahora, hijos de Benjamín: ¿Os dará también á todos vosotros el hijo de Isaí tierras y viñas, y os hará á todos tribunos y centuriones; [^7] Que todos vosotros habéis conspirado contra mí, y no hay quien me descubra al oído como mi hijo ha hecho alianza con el hijo de Isaí, ni alguno de vosotros que se duela de mí, y me descubra como mi hijo ha levantado á mi siervo contra mí, para que me aceche, según hace hoy día? [^8] Entonces Doeg Idumeo, que era superior entre los siervos de Saúl, respondió y dijo: Yo vi al hijo de Isaí que vino á Nob, á Ahimelech hijo de Ahitob; [^9] El cual consultó por él á Jehová, y dióle provisión, y también le dió la espada de Goliath el Filisteo. [^10] Y el rey envió por el sacerdote Ahimelech hijo de Ahitob, y por toda la casa de su padre, los sacerdotes que estaban en Nob: y todos vinieron al rey. [^11] Y Saúl le dijo: Oye ahora, hijo de Ahitob. Y él dijo: Heme aquí, señor mío. [^12] Y díjole Saúl: ¿Por qué habéis conspirado contra mí, tú y el hijo de Isaí, cuando tú le diste pan y espada, y consultaste por él á Dios, para que se levantase contra mí y me acechase, como lo hace hoy día? [^13] Entonces Ahimelech respondió al rey, y dijo: ¿Y quién entre todos tus siervos es tan fiel como David, yerno además del rey, y que va por tu mandado, y es ilustre en tu casa? [^14] ¿He comenzado yo desde hoy á consultar por él á Dios? lejos sea de mí: no impute el rey cosa alguna á su siervo, ni á toda la casa de mi padre; porque tu siervo ninguna cosa sabe de este negocio, grande ni chica. [^15] Y el rey dijo: Sin duda morirás, Ahimelech, tú y toda la casa de tu padre. [^16] Entonces dijo el rey á la gente de su guardia que estaba alrededor de él: Cercad y matad á los sacerdotes de Jehová; porque también la mano de ellos es con David, pues sabiendo ellos que huía, no me lo descubrieron. Mas los siervos del rey no quisieron extender sus manos para matar á los sacerdotes de Jehová. [^17] Entonces dijo el rey á Doeg: Vuelve tú, y arremete contra los sacerdotes. Y revolviéndose Doeg Idumeo, arremetió contra los sacerdotes, y mató en aquel día ochenta y cinco varones que vestían ephod de lino. [^18] Y á Nob, ciudad de los sacerdotes, puso á cuchillo: así á hombres como á mujeres, niños y mamantes, bueyes y asnos y ovejas, todo á cuchillo. [^19] Mas uno de los hijos de Ahimelech hijo de Ahitob, que se llamaba Abiathar, escapó, y huyóse á David. [^20] Y Abiathar notició á David como Saúl había muerto los sacerdotes de Jehová. [^21] Y dijo David á Abiathar: Yo sabía que estando allí aquel día Doeg el Idumeo, él lo había de hacer saber á Saúl. Yo he dado ocasión contra todas las personas de la casa de tu padre. [^22] Quédate conmigo, no temas: quien buscare mi vida, buscará también la tuya: bien que tú estarás conmigo guardado. [^23] 

[[1 Samuel - 21|<--]] 1 Samuel - 22 [[1 Samuel - 23|-->]]

---
# Notes
