---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 21 - Reina Valera (1602)"
---
[[1 Samuel - 20|<--]] 1 Samuel - 21 [[1 Samuel - 22|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Samuel]]

# 1 Samuel - 21

Y VINO David á Nob, á Ahimelech sacerdote: y sorprendióse Ahimelech de su encuentro, y díjole: ¿Cómo tú solo, y nadie contigo? [^1] Y respondió David al sacerdote Ahimelech: El rey me encomendó un negocio, y me dijo: Nadie sepa cosa alguna de este negocio á que yo te envío, y que yo te he mandado; y yo señalé á los criados un cierto lugar. [^2] Ahora pues, ¿qué tienes á mano? dame cinco panes, ó lo que se hallare. [^3] Y el sacerdote respondió á David, y dijo: No tengo pan común á la mano; solamente tengo pan sagrado: mas lo daré si los criados se han guardado mayormente de mujeres. [^4] Y David respondió al sacerdote, y díjole: Cierto las mujeres nos han sido reservadas desde anteayer cuando salí, y los vasos de los mozos fueron santos, aunque el camino es profano: cuanto más que hoy habrá otro pan santificado en los vasos. [^5] Así el sacerdote le dió el pan sagrado, porque allí no había otro pan que los panes de la proposición, los cuales habían sido quitados de delante de Jehová, para que se pusiesen panes calientes el día que los otros fueron quitados. [^6] Aquel día estaba allí uno de los siervos de Saúl detenido delante de Jehová, el nombre del cual era Doeg, Idumeo, principal de los pastores de Saúl. [^7] Y David dijo á Ahimelech: ¿No tienes aquí á mano lanza ó espada? porque no tomé en mi mano mi espada ni mis armas, por cuanto el mandamiento del rey era apremiante. [^8] Y el sacerdote respondió: La espada de Goliath el Filisteo, que tú venciste en el valle del Alcornoque, está aquí envuelta en un velo detrás del ephod: si tú quieres tomarla, tómala: porque aquí no hay otra sino esa. Y dijo David: Ninguna como ella: dámela. [^9] Y levantándose David aquel día, huyó de la presencia de Saúl, y vínose á Achîs rey de Gath. [^10] Y los siervos de Achîs le dijeron: ¿No es éste David, el rey de la tierra? ¿no es éste á quien cantaban en corros, diciendo: Hirió Saúl sus miles, Y David sus diez miles? [^11] Y David puso en su corazón estas palabras, y tuvo gran temor de Achîs rey de Gath. [^12] Y mudó su habla delante de ellos, y fingióse loco entre sus manos, y escribía en las portadas de las puertas, dejando correr su saliva por su barba. [^13] Y dijo Achîs á sus siervos: He aquí estáis viendo un hombre demente; ¿por qué lo habéis traído á mí? [^14] ¿Fáltanme á mí locos, para que hayáis traído éste que hiciese del loco delante de mí? ¿había de venir éste á mi casa? [^15] 

[[1 Samuel - 20|<--]] 1 Samuel - 21 [[1 Samuel - 22|-->]]

---
# Notes
