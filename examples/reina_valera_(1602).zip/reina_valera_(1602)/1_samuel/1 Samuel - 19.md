---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 19 - Reina Valera (1602)"
---
[[1 Samuel - 18|<--]] 1 Samuel - 19 [[1 Samuel - 20|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Samuel]]

# 1 Samuel - 19

Y HABLO Saúl á Jonathán su hijo, y á todos sus criados, para que matasen á David; mas Jonathán hijo de Saúl amaba á David en gran manera. [^1] Y dió aviso á David, diciendo: Saúl mi padre procura matarte; por tanto mira ahora por ti hasta la mañana, y estáte en paraje oculto, y escóndete: [^2] Y yo saldré y estaré junto á mi padre en el campo donde estuvieres: y hablaré de ti á mi padre, y te haré saber lo que notare. [^3] Y Jonathán habló bien de David á Saúl su padre, y díjole: No peque el rey contra su siervo David, pues que ninguna cosa ha cometido contra ti: antes sus obras te han sido muy buenas; [^4] Porque él puso su alma en su palma, é hirió al Filisteo, y Jehová hizo una gran salud á todo Israel. Tú lo viste, y te holgaste: ¿por qué pues pecarás contra la sangre inocente, matando á David sin causa? [^5] Y oyendo Saúl la voz de Jonathán, juró: Vive Jehová, que no morirá. [^6] Llamando entonces Jonathán á David, declaróle todas estas palabras; y él mismo presentó á David á Saúl, y estuvo delante de él como antes. [^7] Y tornó á hacerse guerra: y salió David y peleó contra los Filisteos, é hiriólos con grande estrago, y huyeron delante de él. [^8] Y el espíritu malo de parte de Jehová fué sobre Saúl: y estando sentado en su casa tenía una lanza á mano, mientras David estaba tañendo con su mano. [^9] Y Saúl procuró enclavar á David con la lanza en la pared; mas él se apartó de delante de Saúl, el cual hirió con la lanza en la pared; y David huyó, y escapóse aquella noche. [^10] Saúl envió luego mensajeros á casa de David para que lo guardasen, y lo matasen á la mañana. Mas Michâl su mujer lo descubrió á David, diciendo: Si no salvares tu vida esta noche, mañana serás muerto. [^11] Y descolgó Michâl á David por una ventana; y él se fué, y huyó, y escapóse. [^12] Tomó luego Michâl una estatua, y púsola sobre la cama, y acomodóle por cabecera una almohada de pelos de cabra, y cubrióla con una ropa. [^13] Y cuando Saúl envió mensajeros que tomasen á David, ella respondió: Está enfermo. [^14] Y tornó Saúl á enviar mensajeros para que viesen á David, diciendo: Traédmelo en la cama para que lo mate. [^15] Y como los mensajeros entraron, he aquí la estatua estaba en la cama, y una almohada de pelos de cabra por cabecera. [^16] Entonces Saúl dijo á Michâl: ¿Por qué me has así engañado, y has dejado escapar á mi enemigo? Y Michâl respondió á Saúl: Porque él me dijo: Déjame ir; si no, yo te mataré. [^17] Huyó pues David, y escapóse, y vino á Samuel en Rama, y díjole todo lo que Saúl había hecho con él. Y fuéronse él y Samuel, y moraron en Najoth. [^18] Y fué dado aviso á Saúl, diciendo: He aquí que David está en Najoth en Rama. [^19] Y envió Saúl mensajeros que trajesen á David, los cuales vieron una compañía de profetas que profetizaban, y á Samuel que estaba allí, y los presidía. Y fué el espíritu de Dios sobre los mensajeros de Saúl, y ellos también profetizaron. [^20] Y hecho que fué saber á Saúl, él envió otros mensajeros, los cuales también profetizaron. Y Saúl volvió á enviar por tercera vez mensajeros, y ellos también profetizaron. [^21] Entonces él mismo vino á Rama; y llegando al pozo grande que está en Sochô, preguntó diciendo: ¿Dónde están Samuel y David? Y fuéle respondido: He aquí están en Najoth en Rama. [^22] Y fué allá á Najoth en Rama; y también vino sobre él el espíritu de Dios, é iba profetizando, hasta que llegó á Najoth en Rama. [^23] Y él también se desnudó sus vestidos, y profetizó igualmente delante de Samuel, y cayó desnudo todo aquel día y toda aquella noche. De aquí se dijo: ¿También Saúl entre los profetas? [^24] 

[[1 Samuel - 18|<--]] 1 Samuel - 19 [[1 Samuel - 20|-->]]

---
# Notes
