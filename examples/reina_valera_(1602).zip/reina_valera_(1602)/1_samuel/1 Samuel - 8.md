---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 8 - Reina Valera (1602)"
---
[[1 Samuel - 7|<--]] 1 Samuel - 8 [[1 Samuel - 9|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Samuel]]

# 1 Samuel - 8

Y ACONTECIO que habiendo Samuel envejecido, puso sus hijos por jueces sobre Israel. [^1] Y el nombre de su hijo primogénito fué Joel, y el nombre del segundo, Abia: fueron jueces en Beer-sebah. [^2] Mas no anduvieron los hijos por los caminos de su padre, antes se ladearon tras la avaricia, recibiendo cohecho y pervirtiendo el derecho. [^3] Entonces todos los ancianos de Israel se juntaron, y vinieron á Samuel en Rama, [^4] Y dijéronle: He aquí tú has envejecido, y tus hijos no van por tus caminos: por tanto, constitúyenos ahora un rey que nos juzgue, como todas las gentes. [^5] Y descontentó á Samuel esta palabra que dijeron: Danos rey que nos juzgue. Y Samuel oró á Jehová. [^6] Y dijo Jehová á Samuel: Oye la voz del pueblo en todo lo que te dijeren: porque no te han desechado á ti, sino á mí me han desechado, para que no reine sobre ellos. [^7] Conforme á todas las obras que han hecho desde el día que los saqué de Egipto hasta hoy, que me han dejado y han servido á dioses ajenos, así hacen también contigo. [^8] Ahora pues, oye su voz: mas protesta contra ellos declarándoles el derecho del rey que ha de reinar sobre ellos. [^9] Y dijo Samuel todas las palabras de Jehová al pueblo que le había pedido rey. [^10] Dijo pues: Este será el derecho del rey que hubiere de reinar sobre vosotros: tomará vuestros hijos, y pondrálos en sus carros, y en su gente de á caballo, para que corran delante de su carro: [^11] Y se elegirá capitanes de mil, y capitanes de cincuenta: pondrálos asimismo á que aren sus campos, y sieguen sus mieses, y á que hagan sus armas de guerra, y los pertrechos de sus carros: [^12] Tomará también vuestras hijas para que sean perfumadoras, cocineras, y amasadoras. [^13] Asimismo tomará vuestras tierras, vuestras viñas, y vuestros buenos olivares, y los dará á sus siervos. [^14] El diezmará vuestras simientes y vuestras viñas, para dar á sus eunucos y á sus siervos. [^15] El tomará vuestros siervos, y vuestras siervas, y vuestros buenos mancebos, y vuestros asnos, y con ellos hará sus obras. [^16] Diezmará también vuestro rebaño, y seréis sus siervos. [^17] Y clamaréis aquel día á causa de vuestro rey que os habréis elegido, mas Jehová no os oirá en aquel día. [^18] Empero el pueblo no quiso oir la voz de Samuel; antes dijeron: No, sino que habrá rey sobre nosotros: [^19] Y nosotros seremos también como todas las gentes, y nuestro rey nos gobernará, y saldrá delante de nosotros, y hará nuestras guerras. [^20] Y oyó Samuel todas las palabras del pueblo, y refiriólas en oídos de Jehová. [^21] Y Jehová dijo á Samuel: Oye su voz, y pon rey sobre ellos. Entonces dijo Samuel á los varones de Israel: Idos cada uno á su ciudad. [^22] 

[[1 Samuel - 7|<--]] 1 Samuel - 8 [[1 Samuel - 9|-->]]

---
# Notes
