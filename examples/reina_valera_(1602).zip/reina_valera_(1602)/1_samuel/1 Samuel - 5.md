---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 5 - Reina Valera (1602)"
---
[[1 Samuel - 4|<--]] 1 Samuel - 5 [[1 Samuel - 6|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Samuel]]

# 1 Samuel - 5

Y LOS Filisteos, tomada el arca de Dios, trajéronla desde Eben-ezer á Asdod. [^1] Y tomaron los Filisteos el arca de Dios, y metiéronla en la casa de Dagón, y pusiéronla junto á Dagón. [^2] Y el siguiente día los de Asdod se levantaron de mañana, y he aquí Dagón postrado en tierra delante del arca de Jehová: y tomaron á Dagón, y volviéronlo á su lugar. [^3] Y tornándose á levantar de mañana el siguiente día, he aquí que Dagón había caído postrado en tierra delante del arca de Jehová; y la cabeza de Dagón, y las dos palmas de sus manos estaban cortadas sobre el umbral, habiéndole quedado á Dagón el tronco solamente. [^4] Por esta causa los sacerdotes de Dagón, y todos los que en el templo de Dagón entran, no pisan el umbral de Dagón en Asdod, hasta hoy. [^5] Empero agravóse la mano de Jehová sobre los de Asdod, y destruyólos, é hiriólos con hemorroides en Asdod y en todos sus términos. [^6] Y viendo esto los de Asdod, dijeron: No quede con nosotros el arca del Dios de Israel, porque su mano es dura sobre nosotros, y sobre nuestro dios Dagón. [^7] Enviaron pues á juntar á sí todos los príncipes de los Filisteos, y dijeron: ¿Qué haremos del arca del Dios de Israel? Y ellos respondieron: Pásese el arca del Dios de Israel á Gath. Y pasaron allá el arca del Dios de Israel. [^8] Y aconteció que como la hubieron pasado, la mano de Jehová fué contra la ciudad con grande quebrantamiento; é hirió los hombres de aquella ciudad desde el chico hasta el grande, que se llenaron de hemorroides. [^9] Entonces enviaron el arca de Dios á Ecrón. Y como el arca de Dios vino á Ecrón, los Ecronitas dieron voces diciendo: Han pasado á mí el arca del Dios de Israel por matarme á mí y á mi pueblo. [^10] Y enviaron á juntar todos los príncipes de los Filisteos, diciendo: Despachad el arca del Dios de Israel, y tórnese á su lugar, y no mate á mí ni á mi pueblo: porque había quebrantamiento de muerte en toda la ciudad, y la mano de Dios se había allí agravado. [^11] Y los que no morían, eran heridos de hemorroides; y el clamor de la ciudad subía al cielo. [^12] 

[[1 Samuel - 4|<--]] 1 Samuel - 5 [[1 Samuel - 6|-->]]

---
# Notes
