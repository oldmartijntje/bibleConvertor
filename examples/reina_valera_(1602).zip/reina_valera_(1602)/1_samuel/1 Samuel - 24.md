---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 24 - Reina Valera (1602)"
---
[[1 Samuel - 23|<--]] 1 Samuel - 24 [[1 Samuel - 25|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Samuel]]

# 1 Samuel - 24

Y como Saúl volvió de los Filisteos, diéronle aviso diciendo: He aquí que David está en el desierto de Engaddi. [^1] Y tomando Saúl tres mil hombres escogidos de todo Israel, fué en busca de David y de los suyos, por las cumbres de los peñascos de las cabras monteses. [^2] Y como llegó á una majada de ovejas en el camino, donde había una cueva, entró Saúl en ella á cubrir sus pies: y David y los suyos estaban á los lados de la cueva. [^3] Entonces los de David le dijeron: He aquí el día que te ha dicho Jehová: He aquí que entregó tu enemigo en tus manos, y harás con él como te pareciere. Y levantóse David, y calladamente cortó la orilla del manto de Saúl. [^4] Después de lo cual el corazón de David le golpeaba, porque había cortado la orilla del manto de Saúl. [^5] Y dijo á los suyos: Jehová me guarde de hacer tal cosa contra mi señor, el ungido de Jehová, que yo extienda mi mano contra él; porque es el ungido de Jehová. [^6] Así quebrantó David á los suyos con palabras, y no les permitió que se levantasen contra Saúl. Y Saúl, saliendo de la cueva, fuése su camino. [^7] También David se levantó después, y saliendo de la cueva dió voces á las espaldas de Saúl, diciendo: ­Mi señor el rey! Y como Saúl miró atrás, David inclinó su rotro á tierra, é hizo reverencia. [^8] Y dijo David á Saúl: ¿Por qué oyes las palabras de los que dicen: Mira que David procura tu mal? [^9] He aquí han visto hoy tus ojos como Jehová te ha puesto hoy en mis manos en la cueva: y dijeron que te matase, mas te perdoné, porque dije: No extenderé mi mano contra mi señor, porque ungido es de Jehová. [^10] Y mira, padre mío, mira aún la orilla de tu manto en mi mano: porque yo corté la orilla de tu manto, y no te maté. Conoce pues y ve que no hay mal ni traición en mi mano, ni he pecado contra ti; con todo, tú andas á caza de mi vida para quitármela. [^11] Juzgue Jehová entre mí y ti, y véngueme de ti Jehová: empero mi mano no será contra ti. [^12] Como dice el proverbio de los antiguos: De los impíos saldrá la impiedad: así que mi mano no será contra ti. [^13] ¿Tras quién ha salido el rey de Israel? ¿á quién persigues? ¿á un perro muerto? ¿á una pulga? [^14] Jehová pues será juez, y él juzgará entre mí y ti. El vea, y sustente mi causa, y me defienda de tu mano. [^15] Y aconteció que, como David acabó de decir estas palabras á Saúl, Saúl dijo: ¿No es esta la voz tuya, hijo mío David? Y alzando Saúl su voz lloró. [^16] Y dijo á David: Más justo eres tú que yo, que me has pagado con bien, habiéndote yo pagado con mal. [^17] Tú has mostrado hoy que has hecho conmigo bien; pues no me has muerto, habiéndome Jehová puesto en tus manos. [^18] Porque ¿quién hallará á su enemigo, y lo dejará ir sano y salvo? Jehová te pague con bien por lo que en este día has hecho conmigo. [^19] Y ahora, como yo entiendo que tú has de reinar, y que el reino de Israel ha de ser en tu mano firme y estable, [^20] Júrame pues ahora por Jehová, que no cortarás mi simiente después de mí, ni raerás mi nombre de la casa de mi padre. [^21] Entonces David juró á Saúl. Y fuése Saúl á su casa, y David y los suyos se subieron al sitio fuerte. [^22] 

[[1 Samuel - 23|<--]] 1 Samuel - 24 [[1 Samuel - 25|-->]]

---
# Notes
