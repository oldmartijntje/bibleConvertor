---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 1 - Reina Valera (1602)"
---
1 Samuel - 1 [[1 Samuel - 2|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Samuel]]

# 1 Samuel - 1

HUBO un varón de Ramathaim de Sophim, del monte de Ephraim, que se llamaba Elcana, hijo de Jeroham, hijo de Eliú, hijo de Thohu, hijo de Suph, Ephrateo. [^1] Y tenía él dos mujeres; el nombre de la una era Anna, y el nombre de la otra Peninna. Y Peninna tenía hijos, mas Anna no los tenía. [^2] Y subía aquel varón todos los años de su ciudad, á adorar y sacrificar á Jehová de los ejércitos en Silo, donde estaban dos hijos de Eli, Ophni y Phinees, sacerdotes de Jehová. [^3] Y cuando venía el día, Elcana sacrificaba, y daba á Peninna su mujer, y á todos sus hijos y á todas sus hijas, á cada uno su parte. [^4] Mas á Anna daba una parte escogida; porque amaba á Anna, aunque Jehová había cerrado su matriz. [^5] Y su competidora la irritaba, enojándola y entristeciéndola, porque Jehová había cerrado su matriz. [^6] Y así hacía cada año: cuando subía á la casa de Jehová, enojaba así á la otra; por lo cual ella lloraba, y no comía. [^7] Y Elcana su marido le dijo: Anna, ¿por qué lloras? ¿y por qué no comes? ¿y por qué está afligido tu corazón? ¿No te soy yo mejor que diez hijos? [^8] Y levantóse Anna después que hubo comido y bebido en Silo; y mientras el sacerdote Eli estaba sentado en una silla junto á un pilar del templo de Jehová, [^9] Ella con amargura de alma oró á Jehová, y lloró abundantemente. [^10] E hizo voto, diciendo: Jehová de los ejércitos, si te dignares mirar la aflicción de tu sierva, y te acordares de mí, y no te olvidares de tu sierva, mas dieres á tu sierva un hijo varón, yo lo dedicaré á Jehová todos los días de su vida, y no subirá navaja sobre su cabeza. [^11] Y fué que como ella orase largamente delante de Jehová, Eli estaba observando la boca de ella. [^12] Mas Anna hablaba en su corazón, y solamente se movían sus labios, y su voz no se oía; y túvola Eli por borracha. [^13] Entonces le dijo Eli: ¿Hasta cuándo estarás borracha?; digiere tu vino. [^14] Y Anna le respondió, diciendo: No, señor mío: mas yo soy una mujer trabajada de espíritu: no he bebido vino ni sidra, sino que he derramado mi alma delante de Jehová. [^15] No tengas á tu sierva por una mujer impía: porque por la magnitud de mis congojas y de mi aflicción he hablado hasta ahora. [^16] Y Eli respondió, y dijo: Ve en paz, y el Dios de Israel te otorgue la petición que le has hecho. [^17] Y ella dijo: Halle tu sierva gracia delante de tus ojos. Y fuése la mujer su camino, y comió, y no estuvo más triste. [^18] Y levantándose de mañana, adoraron delante de Jehová, y volviéronse, y vinieron á su casa en Ramatha. Y Elcana conoció á Anna su mujer, y Jehová se acordó de ella. [^19] Y fué que corrido el tiempo, después de haber concebido Anna, parió un hijo, y púsole por nombre Samuel, diciendo: Por cuanto lo demandé á Jehová. [^20] Después subió el varón Elcana, con toda su familia, á sacrificar á Jehová el sacrificio acostumbrado, y su voto. [^21] Mas Anna no subió, sino dijo á su marido: Yo no subiré hasta que el niño sea destetado; para que lo lleve y sea presentado delante de Jehová, y se quede allá para siempre. [^22] Y Elcana su marido le respondió: Haz lo que bien te pareciere; quédate hasta que lo destetes; solamente Jehová cumpla su palabra. Y quedóse la mujer, y crió su hijo hasta que lo destetó. [^23] Y después que lo hubo destetado, llevólo consigo, con tres becerros, y un epha de harina, y una vasija de vino, y trájolo á la casa de Jehová en Silo: y el niño era pequeño. [^24] Y matando el becerro, trajeron el niño á Eli. [^25] Y ella dijo: ­Oh, señor mío! vive tu alma, señor mío, yo soy aquella mujer que estuvo aquí junto á ti orando á Jehová. [^26] Por este niño oraba, y Jehová me dió lo que le pedí. [^27] Yo pues le vuelvo también á Jehová: todos los días que viviere, será de Jehová. Y adoró allí á Jehová. [^28] 

1 Samuel - 1 [[1 Samuel - 2|-->]]

---
# Notes
