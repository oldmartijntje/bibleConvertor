---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 6 - Reina Valera (1602)"
---
[[1 Samuel - 5|<--]] 1 Samuel - 6 [[1 Samuel - 7|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Samuel]]

# 1 Samuel - 6

Y ESTUVO el arca de Jehová en la tierra de los Filisteos siete meses. [^1] Entonces los Filisteos, llamando los sacerdotes y adivinos, preguntaron: ¿Qué haremos del arca de Jehová? Declaradnos cómo la hemos de tornar á enviar á su lugar. [^2] Y ellos dijeron: Si enviáis el arca del Dios de Israel, no la enviéis vacía; mas le pagaréis la expiación: y entonces seréis sanos, y conoceréis por qué no se apartó de vosotros su mano. [^3] Y ellos dijeron: ¿Y qué será la expiación que le pagaremos? Y ellos respondieron: Conforme al número de los príncipes de los Filisteos, cinco hermorroides de oro, y cinco ratones de oro, porque la misma plaga que todos tienen, tienen también vuestros príncipes. [^4] Haréis pues las formas de vuestras hemorroides, y las formas de vuestros ratones que destruyen la tierra, y daréis gloria al Dios de Israel: quizá aliviará su mano de sobre vosotros, y de sobre vuestros dioses, y de sobre vuestra tierra. [^5] Mas ¿por qué endurecéis vuestro corazón, como los Egipcios y Faraón endurecieron su corazón? Después que los hubo así tratado, ¿no los dejaron que se fuesen, y se fueron? [^6] Haced pues ahora un carro nuevo, y tomad luego dos vacas que críen, á las cuales no haya sido puesto yugo, y uncid las vacas al carro, y haced tornar de detrás de ellas sus becerros á casa. [^7] Tomaréis luego el arca de Jehová, y la pondréis sobre el carro; y poned en una caja al lado de ella las alhajas de oro que le pagáis en expiación: y la dejaréis que se vaya. [^8] Y mirad: si sube por el camino de su término á Beth-semes, él nos ha hecho este mal tan grande; y si no, seremos ciertos que su mano no nos hirió, nos ha sido accidente. [^9] Y aquellos hombres lo hicieron así; pues tomando dos vacas que criaban, unciéronlas al carro, y encerraron en casa sus becerros. [^10] Luego pusieron el arca de Jehová sobre el carro, y la caja con los ratones de oro y con las formas de sus hemorroides. [^11] Y las vacas se encaminaron por el camino de Beth-semes, é iban por un mismo camino andando y bramando, sin apartarse ni á diestra ni á siniestra: y los príncipes de los Filisteos fueron tras ellas hasta el término de Beth-semes. [^12] Y los de Beth-semes segaban el trigo en el valle; y alzando sus ojos vieron el arca, y holgáronse cuando la vieron. [^13] Y el carro vino al campo de Josué Beth-semita, y paró allí porque allí había una gran piedra; y ellos cortaron la madera del carro, y ofrecieron las vacas en holocausto á Jehová. [^14] Y los Levitas bajaron el arca de Jehová, y la caja que estaba junto á ella, en la cual estaban las alhajas de oro, y pusiéronlas sobre aquella gran piedra; y los hombre de Beth-semes sacrificaron holocaustos y mataron víctimas á Jehová en aquel día. [^15] Lo cual viendo los cinco príncipes de los Filisteos, volviéronse á Ecrón el mismo día. [^16] Estas pues son las hemorroides de oro que pagaron los Filisteos á Jehová en expiación: por Asdod una, por Gaza una, por Ascalón una, por Gath una, por Ecrón una; [^17] Y ratones de oro conforme al número de todas las ciudades de los Filisteos pertenecientes á los cinco príncipes, desde las ciudades fuertes hasta las aldeas sin muro; y hasta la gran piedra sobre la cual pusieron el arca de Jehová, piedra que está en el campo de Josué Beth-semita hasta hoy. [^18] Entonces hirió Dios á los de Beth-semes, porque habían mirado en el arca de Jehová; hirió en el pueblo cincuenta mil y setenta hombres. Y el pueblo puso luto, porque Jehová le había herido de tan gran plaga. [^19] Y dijeron los de Beth-semes: ¿Quién podrá estar delante de Jehová el Dios santo? ¿y á quién subirá desde nosotros? [^20] Y enviaron mensajeros á los de Chîriath-jearim, diciendo: Los Filisteos han vuelto el arca de Jehová: descended pues, y llevadla á vosotros. [^21] 

[[1 Samuel - 5|<--]] 1 Samuel - 6 [[1 Samuel - 7|-->]]

---
# Notes
