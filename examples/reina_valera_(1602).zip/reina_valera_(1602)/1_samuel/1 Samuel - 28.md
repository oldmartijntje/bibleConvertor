---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 28 - Reina Valera (1602)"
---
[[1 Samuel - 27|<--]] 1 Samuel - 28 [[1 Samuel - 29|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Samuel]]

# 1 Samuel - 28

Y ACONTECIO que en aquellos días los Filisteos juntaron sus campos para pelear contra Israel. Y dijo Achîs á David: Sabe de cierto que has de salir conmigo á campaña, tú y los tuyos. [^1] Y David respondió á Achîs: Sabrás pues lo que hará tu siervo. Y Achîs dijo á David: Por tanto te haré guarda de mi cabeza todos los días. [^2] Ya Samuel era muerto, y todo Israel lo había lamentado, y habíanle sepultado en Rama, en su ciudad. Y Saúl había echado de la tierra los encantadores y adivinos. [^3] Pues como los Filisteos se juntaron, vinieron y asentaron campo en Sunam: y Saúl juntó á todo Israel, y asentaron campo en Gilboa. [^4] Y cuando vió Saúl el campo de los Filisteos, temió, y turbóse su corazón en gran manera. [^5] Y consultó Saúl á Jehová; pero Jehová no le respondió, ni por sueños, ni por Urim, ni por profetas. [^6] Entonces Saúl dijo á sus criados: Buscadme una mujer que tenga espíritu de pythón, para que yo vaya á ella, y por medio de ella pregunte. Y sus criados le respondieron: He aquí hay una mujer en Endor que tiene espíritu de pythón. [^7] Y disfrazóse Saúl, y púsose otros vestidos, y fuése con dos hombres, y vinieron á aquella mujer de noche; y él dijo: Yo te ruego que me adivines por el espíritu de pythón, y me hagas subir á quien yo te dijere. [^8] Y la mujer le dijo: He aquí tú sabes lo que Saúl ha hecho, cómo ha separado de la tierra los pythones y los adivinos: ¿por qué pues pones tropiezo á mi vida, para hacerme matar? [^9] Entoces Saúl le juró por Jehová, diciendo: Vive Jehová, que ningún mal te vendrá por esto. [^10] La mujer entonces dijo: ¿A quién te haré venir? Y él respondió: Hazme venir á Samuel. [^11] Y viendo la mujer á Samuel, clamó en alta voz, y habló aquella mujer á Saúl, diciendo: [^12] ¿Por qué me has engañado? que tú eres Saúl. Y el rey le dijo: No temas: ¿qué has visto? Y la mujer respondió á Saúl: He visto dioses que suben de la tierra. [^13] Y él le dijo: ¿Cuál es su forma? Y ella respondió: Un hombre anciano viene, cubierto de un manto. Saúl entonces entendió que era Samuel, y humillando el rostro á tierra, hizo gran reverencia. [^14] Y Samuel dijo á Saúl: ¿Por qué me has inquietado haciéndome venir? Y Saúl respondió: Estoy muy congojado; pues los Filisteos pelean contra mí, y Dios se ha apartado de mí, y no me responde más, ni por mano de profetas, ni por sueños: por esto te he llamado, para que me declares qué tengo de hacer. [^15] Entonces Samuel dijo: ¿Y para qué me preguntas á mí, habiéndose apartado de ti Jehová, y es tu enemigo? [^16] Jehová pues ha hecho como habló por medio de mí; pues ha cortado Jehová el reino de tu mano, y lo ha dado á tu compañero David. [^17] Como tú no obedeciste á la voz de Jehová, ni cumpliste el furor de su ira sobre Amalec, por eso Jehová te ha hecho esto hoy. [^18] Y Jehová entregará á Israel también contigo en manos de los Filisteos: y mañana seréis conmigo, tú y tus hijos: y aun el campo de Israel entregará Jehová en manos de los Filisteos. [^19] En aquel punto cayó Saúl en tierra cuan grande era, y tuvo gran temor por las palabras de Samuel; que no quedó en él esfuerzo ninguno, porque en todo aquel día y aquella noche no había comido pan. [^20] Entonces la mujer vino á Saúl, y viéndole en grande manera turbado, díjole: He aquí que tu criada ha obedecido á tu voz, y he puesto mi vida en mi mano, y he oído las palabras que tú me has dicho. [^21] Ruégote pues, que tú también oigas la voz de tu sierva: pondré yo delante de ti un bocado de pan que comas, para que te corrobores, y vayas tu camino. [^22] Y él lo rehusó, diciendo: No comeré. Mas sus criados juntamente con la mujer le constriñeron, y él los obedeció. Levantóse pues del suelo, y sentóse sobre una cama. [^23] Y aquella mujer tenía en su casa un ternero grueso, el cual mató luego; y tomó harina y amasóla, y coció de ella panes sin levadura. [^24] Y lo trajo delante de Saúl y de sus criados; y luego que hubieron comido, se levantaron, y partieron aquella noche. [^25] 

[[1 Samuel - 27|<--]] 1 Samuel - 28 [[1 Samuel - 29|-->]]

---
# Notes
