---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 31 - Reina Valera (1602)"
---
[[1 Samuel - 30|<--]] 1 Samuel - 31

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Samuel]]

# 1 Samuel - 31

LOS Filisteos pues pelearon con Israel, y los de Israel huyeron delante de los Filisteos, y cayeron muertos en el monte de Gilboa. [^1] Y siguiendo los Filisteos á Saúl y á sus hijos, mataron á Jonathán, y á Abinadab, y á Melchîsua, hijos de Saúl. [^2] Y agravóse la batalla sobre Saúl, y le alcanzaron los flecheros; y tuvo gran temor de los flecheros. [^3] Entonces dijo Saúl á su escudero: Saca tu espada, y pásame con ella, porque no vengan estos incircuncisos, y me pasen, y me escarnezcan. Mas su escudero no quería, porque tenía gran temor. Entonces tomó Saúl la espada, y echóse sobre ella. [^4] Y viendo su escudero á Saúl muerto, él también se echó sobre su espada, y murió con él. [^5] Así murió Saúl en aquel día, juntamente con sus tres hijos, y su escudero, y todos sus varones. [^6] Y los de Israel que eran de la otra parte del valle, y de la otra parte del Jordán, viendo que Israel había huído, y que Saúl y sus hijos eran muertos, dejaron las ciudades y huyeron; y los Filisteos vinieron y habitaron en ellas. [^7] Y aconteció el siguiente día, que viniendo los Filisteos á despojar los muertos, hallaron á Saúl y á sus tres hijos tendidos en el monte de Gilboa; [^8] Y cortáronle la cabeza, y desnudáronle las armas; y enviaron á tierra de los Filisteos al contorno, para que lo noticiaran en el templo de sus ídolos, y por el pueblo. [^9] Y pusieron sus armas en el templo de Astaroth, y colgaron su cuerpo en el muro de Beth-san. [^10] Mas oyendo los de Jabes de Galaad esto que los Filisteos hicieron á Saúl, [^11] Todos los hombres valientes se levantaron, y anduvieron toda aquella noche, y quitaron el cuerpo de Saúl y los cuerpos de sus hijos del muro de Beth-san; y viniendo á Jabes, quemáronlos allí. [^12] Y tomando sus huesos, sepultáronlos debajo de un árbol en Jabes, y ayunaron siete días. [^13] 

[[1 Samuel - 30|<--]] 1 Samuel - 31

---
# Notes
