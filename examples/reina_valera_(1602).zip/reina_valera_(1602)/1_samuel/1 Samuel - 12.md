---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 12 - Reina Valera (1602)"
---
[[1 Samuel - 11|<--]] 1 Samuel - 12 [[1 Samuel - 13|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Samuel]]

# 1 Samuel - 12

Y DIJO Samuel á todo Israel: He aquí, yo he oído vuestra voz en todas las cosas que me habéis dicho, y os he puesto rey. [^1] Ahora pues, he aquí vuestro rey va delante de vosotros. Yo soy ya viejo y cano: mas mis hijos están con vosotros, y yo he andado delante de vosotros desde mi mocedad hasta este día. [^2] Aquí estoy; atestiguad contra mí delante de Jehová y delante de su ungido, si he tomado el buey de alguno, ó si he tomado el asno de alguno, ó si he calumniado á alguien, ó si he agraviado á alguno, ó si de alguien he tomado cohecho por el cual haya cubierto mis ojos: y os satisfaré. [^3] Entonces dijeron: Nunca nos has calumniado, ni agraviado, ni has tomado algo de mano de ningún hombre. [^4] Y él les dijo: Jehová es testigo contra vosotros, y su ungido también es testigo en este día, que no habéis hallado en mi mano cosa ninguna. Y ellos respondieron: Así es. [^5] Entonces Samuel dijo al pueblo: Jehová es quien hizo á Moisés y á Aarón, y que sacó á vuestros padres de la tierra de Egipto. [^6] Ahora pues, aguardad, y yo os haré cargo delante de Jehová de todas las justicias de Jehová, que ha hecho con vosotros y con vuestros padres. [^7] Después que Jacob hubo entrado en Egipto y vuestros padres clamaron á Jehová, Jehová envió á Moisés y á Aarón, los cuales sacaron á vuestros padres de Egipto, y los hicieron habitar en este lugar. [^8] Y olvidaron á Jehová su Dios, y él los vendió en la mano de Sísara capitán del ejército de Asor, y en la mano de los Filisteos, y en la mano del rey de Moab, los cuales les hicieron guerra. [^9] Y ellos clamaron á Jehová, y dijeron: Pecamos, que hemos dejado á Jehová, y hemos servido á los Baales y á Astaroth: líbranos pues ahora de la mano de nuestros enemigos, y te serviremos. [^10] Entonces Jehová envió á Jero-baal, y á Bedán, y á Jephté, y á Samuel, y os libró de mano de vuestros enemigos alrededor, y habitasteis seguros. [^11] Y habiendo visto que Naas rey de lo hijos de Ammón venía contra vosotros, me dijisteis: No, sino rey reinará sobre nosotros; siendo vuestro rey Jehová vuestro Dios. [^12] Ahora pues, ved aquí vuestro rey que habéis elegido, el cual pedisteis; ya veis que Jehová ha puesto sobre vosotros rey. [^13] Si temiereis á Jehová y le sirviereis, y oyereis su voz, y no fuereis rebeldes á la palabra de Jehová, así vosotros como el rey que reina sobre vosotros, seréis en pos de Jehová vuestro Dios. [^14] Mas si no oyereis la voz de Jehová, y si fuereis rebeldes á las palabras de Jehová, la mano de Jehová será contra vosotros como contra vuestros padres. [^15] Esperad aún ahora, y mirad esta gran cosa que Jehová hará delante de vuestros ojos. [^16] ¿No es ahora la siega de los trigos? Yo clamaré á Jehová, y él dará truenos y aguas; para que conozcáis y veáis que es grande vuestra maldad que habéis hecho en los ojos de Jehová, pidiéndoos rey. [^17] Y Samuel clamó á Jehová; y Jehová dió truenos y aguas en aquel día; y todo el pueblo temió en gran manera á Jehová y á Samuel. [^18] Entonces dijo todo el pueblo á Samuel: Ruega por tus siervos á Jehová tu Dios, que no muramos: porque á todos nuestros pecados hemos añadido este mal de pedir rey para nosotros. [^19] Y Samuel respondió al pueblo: No temáis: vosotros habéis cometido todo este mal; mas con todo eso no os apartéis de en pos de Jehová, sino servid á Jehová con todo vuestro corazón: [^20] No os apartéis en pos de las vanidades, que no aprovechan ni libran, porque son vanidades. [^21] Pues Jehová no desamparará á su pueblo por su grande nombre: porque Jehová ha querido haceros pueblo suyo. [^22] Así que, lejos sea de mí que peque yo contra Jehová cesando de rogar por vosotros; antes yo os enseñaré por el camino bueno y derecho. [^23] Solamente temed á Jehová, y servidle de verdad con todo vuestro corazón, porque considerad cuán grandes cosas ha hecho con vosotros. [^24] Mas si perseverareis en hacer mal, vosotros y vuestro rey pereceréis. [^25] 

[[1 Samuel - 11|<--]] 1 Samuel - 12 [[1 Samuel - 13|-->]]

---
# Notes
