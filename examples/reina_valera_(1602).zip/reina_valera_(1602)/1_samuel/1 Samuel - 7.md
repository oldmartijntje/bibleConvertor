---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 7 - Reina Valera (1602)"
---
[[1 Samuel - 6|<--]] 1 Samuel - 7 [[1 Samuel - 8|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Samuel]]

# 1 Samuel - 7

Y VINIERON los de Chîriath-jearim, y llevaron el arca de Jehová, y metiéronla en casa de Abinadab, situada en el collado; y santificaron á Eleazar su hijo, para que guardase el arca de Jehová. [^1] Y aconteció que desde el día que llegó el arca á Chîriath-jearim pasaron mucho días, veinte años; y toda la casa de Israel lamentaba en pos de Jehová. [^2] Y habló Samuel á toda la casa de Israel, diciendo: Si de todo vuestro corazón os volvéis á Jehová, quitad los dioses ajenos y á Astaroth de entre vosotros, y preparad vuestro corazón á Jehová, y á sólo él servid, y os librará de mano de los Filisteos. [^3] Entonces los hijos de Israel quitaron á los Baales y á Astaroth, y sirvieron á solo Jehová. [^4] Y Samuel dijo: Juntad á todo Israel en Mizpa, y yo oraré por vosotros á Jehová. [^5] Y juntándose en Mizpa, sacaron agua, y derramáronla delante de Jehová, y ayunaron aquel día, y dijeron allí: Contra Jehová hemos pecado. Y juzgó Samuel á los hijos de Israel en Mizpa. [^6] Y oyendo los Filisteos que los hijos de Israel estaban reunidos en Mizpa, subieron los príncipes de los Filisteos contra Israel: lo cual como hubieron oído los hijos de Israel, tuvieron temor de los Filisteos. [^7] Y dijeron los hijos de Israel á Samuel: No ceses de clamar por nosotros á Jehová nuestro Dios, que nos guarde de mano de los filisteos. [^8] Y Samuel tomó un cordero de leche, y sacrificólo entero á Jehová en holocausto: y clamó Samuel á Jehová por Israel, y Jehová le oyó. [^9] Y aconteció que estando Samuel sacrificando el holocausto, los Filisteos llegaron para pelear con los hijos de Israel. Mas Jehová tronó aquel día con grande estruendo sobre los Filisteos, y desbaratólos, y fueron vencidos delante de Israel. [^10] Y saliendo los hijos de Israel de Mizpa, siguieron á los Filisteos, hiriéndolos hasta abajo de Beth-car. [^11] Tomó luego Samuel una piedra, y púsola entre Mizpa y Sen, y púsole por nombre Eben-ezer, diciendo: Hasta aquí nos ayudó Jehová. [^12] Fueron pues los Filisteos humillados, que no vinieron más al término de Israel; y la mano de Jehová fué contra los Filisteos todo el tiempo de Samuel. [^13] Y fueron restituídas á los hijos de Israel las ciudades que los Filisteos habían tomado á los Isrelitas, desde Ecrón hasta Gath, con sus términos: é Israel las libró de mano de los Filisteos. Y hubo paz entre Israel y el Amorrheo. [^14] Y juzgó Samuel á Israel todo el tiempo que vivió. [^15] Y todos los años iba y daba vuelta á Beth-el, y á Gilgal, y á Mizpa, y juzgaba á Israel en todos estos lugares. [^16] Volvíase después á Rama, porque allí estaba su casa, y allí juzgaba á Israel; y edificó allí altar á Jehová. [^17] 

[[1 Samuel - 6|<--]] 1 Samuel - 7 [[1 Samuel - 8|-->]]

---
# Notes
