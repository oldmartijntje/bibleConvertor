---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 11 - Reina Valera (1602)"
---
[[1 Samuel - 10|<--]] 1 Samuel - 11 [[1 Samuel - 12|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Samuel]]

# 1 Samuel - 11

Y SUBIO Naas Ammonita, y asentó campo contra Jabes de Galaad. Y todos los de Jabes dijeron á Naas: Haz alianza con nosotros, y te serviremos. [^1] Y Naas Ammonita les respondió: Con esta condición haré alianza con vosotros, que á cada uno de todos vosotros saque el ojo derecho, y ponga esta afrenta sobre todo Israel. [^2] Entonces los ancianos de Jabes le dijeron: Danos siete días, para que enviemos mensajeros á todos los términos de Israel; y si nadie hubiere que nos defienda, saldremos á ti. [^3] Y llegando los mensajeros á Gabaa de Saúl, dijeron estas palabras en oídos del pueblo; y todo el pueblo lloró á voz en grito. [^4] Y he aquí Saúl que venía del campo, tras los bueyes; y dijo Saúl: ¿Qué tiene el pueblo, que lloran? Y contáronle las palabras de los hombres de Jabes. [^5] Y el espíritu de Dios arrebató á Saúl en oyendo estas palabras, y encendióse en ira en gran manera. [^6] Y tomando un par de bueyes, cortólos en piezas, y enviólas por todos los términos de Israel por mano de mensajeros, diciendo: Cualquiera que no saliere en pos de Saúl y en pos de Samuel, así será hecho á sus bueyes. Y cayó temor de Jehová sobre el pueblo, y salieron como un solo hombre. [^7] Y contóles en Bezec; y fueron los hijos de Israel trescientos mil, y treinta mil los hombres de Judá. [^8] Y respondieron á los mensajeros que habían venido: Así diréis á los de Jabes de Galaad: Mañana en calentando el sol, tendréis salvamento. Y vinieron los mensajeros, y declaráronlo á los de Jabes, los cuales se holgaron. [^9] Y los de Jabes dijeron: Mañana saldremos á vosotros, para que hagáis con nosotros todo lo que bien os pareciere. [^10] Y el día siguiente dispuso Saúl el pueblo en tres escuadrones, y entraron en medio del real á la vela de la mañana, é hirieron á los Ammonitas hasta que el día calentaba: y los que quedaron fueron dispersos, tal que no quedaron dos de ellos juntos. [^11] El pueblo entonces dijo á Samuel: ¿Quiénes son lo que decían: Reinará Saúl sobre nosotros? Dad nos esos hombres, y los mataremos. [^12] Y Saúl dijo: No morirá hoy ninguno, porque hoy ha obrado Jehová salud en Israel. [^13] Mas Samuel dijo al pueblo: Venid, vamos á Gilgal para que renovemos allí el reino. [^14] Y fué todo el pueblo á Gilgal, é invistieron allí á Saúl por rey delante de Jehová en Gilgal. Y sacrificaron allí víctimas pacíficas delante de Jehová; y alegráronse mucho allí Saúl y todos los de Israel. [^15] 

[[1 Samuel - 10|<--]] 1 Samuel - 11 [[1 Samuel - 12|-->]]

---
# Notes
