---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 13 - Reina Valera (1602)"
---
[[1 Samuel - 12|<--]] 1 Samuel - 13 [[1 Samuel - 14|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Samuel]]

# 1 Samuel - 13

HABIA ya Saúl reinado un año; y reinado que hubo dos años sobre Israel, [^1] Escogióse luego tres mil de Israel: los dos mil estuvieron con Saúl en Michmas y en el monte de Beth-el, y los mil estuvieron con Jonathán en Gabaa de Benjamín; y envió á todo el otro pueblo cada uno á sus tiendas. [^2] Y Jonathán hirió la guarnición de los Filisteos que había en el collado, y oyéronlo los Filisteos. E hizo Saúl tocar trompetas por toda la tierra, diciendo: Oigan los Hebreos. [^3] Y todo Israel oyó lo que se decía: Saúl ha herido la guarnición de los Filisteos; y también que Israel olía mal á los Filisteos. Y juntóse el pueblo en pos de Saúl en Gilgal. [^4] Entonces los Filisteos se juntaron para pelear con Israel, treinta mil carros, y seis mil caballos, y pueblo como la arena que está á la orilla de la mar en multitud; y subieron, y asentaron campo en Michmas, al oriente de Beth-aven. [^5] Mas los hombres de Israel, viéndose puestos en estrecho, (porque el pueblo estaba en aprieto), escondióse el pueblo en cuevas, en fosos, en peñascos, en rocas y en cisternas. [^6] Y algunos de los Hebreos pasaron el Jordán á la tierra de Gad y de Galaad: y Saúl se estaba aún en Gilgal, y todo el pueblo iba tras él temblando. [^7] Y él esperó siete días, conforme al plazo que Samuel había dicho; pero Samuel no venía á Gilgal, y el pueblo se le desertaba. [^8] Entonces dijo Saúl: Traedme holocausto y sacrificios pacíficos. Y ofreció el holocausto. [^9] Y como él acababa de hacer el holocausto, he aquí Samuel que venía; y Saúl le salió á recibir para saludarle. [^10] Entonces Samuel dijo: ¿Qué has hecho? Y Saúl respondió: Porque vi que el pueblo se me iba, y que tú no venías al plazo de los días, y que los Filisteos estaban juntos en Michmas, [^11] Me dije: Los Filisteos descenderán ahora contra mí á Gilgal, y yo no he implorado el favor de Jehová. Esforcéme pues, y ofrecí holocausto. [^12] Entonces Samuel dijo á Saúl: Locamente has hecho; no guardaste el mandamiento de Jehová tu Dios, que él te había intimado; porque ahora Jehová hubiera confirmado tu reino sobre Israel para siempre. [^13] Mas ahora tu reino no será durable: Jehová se ha buscado varón según su corazón, al cual Jehová ha mandado que sea capitán sobre su pueblo, por cuanto tú no has guardado lo que Jehová te mandó. [^14] Y levantándose Samuel, subió de Gilgal á Gabaa de Benjamín. Y Saúl contó la gente que se hallaba con él, como seiscientos hombres. [^15] Saúl pues y Jonathán su hijo, y el pueblo que con ellos se hallaba, quedáronse en Gabaa de Benjamín: mas los Filisteos habían puesto su campo en Michmas. [^16] Y salieron del campo de los Filisteos en correría tres escuadrones. El un escuadrón tiró por el camino de Ophra hacia la tierra de Sual. [^17] El otro escuadrón marchó hacia Beth-oron, y el tercer escuadrón marchó hacia la región que mira al valle de Seboim hacia el desierto. [^18] Y en toda la tierra de Israel no se hallaba herrero; porque los Filisteos habían dicho: Para que los Hebreos no hagan espada ó lanza. [^19] Y todos los de Israel descendían á los Filisteos cada cual á amolar su reja, su azadón, su hacha, ó su sacho, [^20] Y cuando se hacían bocas en las rejas, ó en los azadones, ó en las horquillas, ó en las hachas; hasta para una ahijada que se hubiera de componer. [^21] Así aconteció que el día de la batalla no se halló espada ni lanza en mano de alguno de todo el pueblo que estaba con Saúl y con Jonathán, excepto Saúl y Jonathán su hijo, que las tenían. [^22] Y la guarnición de los Filisteos salió al paso de Michmas. [^23] 

[[1 Samuel - 12|<--]] 1 Samuel - 13 [[1 Samuel - 14|-->]]

---
# Notes
