---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 3 - Reina Valera (1602)"
---
[[1 Samuel - 2|<--]] 1 Samuel - 3 [[1 Samuel - 4|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Samuel]]

# 1 Samuel - 3

Y EL joven Samuel ministraba á Jehová delante de Eli: y la palabra de Jehová era de estima en aquellos días; no había visión manifiesta. [^1] Y aconteció un día, que estando Eli acostado en su aposento, cuando sus ojos comenzaban á oscurecerse, que no podía ver, [^2] Samuel estaba durmiendo en el templo de Jehová, donde el arca de Dios estaba: y antes que la lámpara de Dios fuese apagada, [^3] Jehová llamó á Samuel; y él respondió: Heme aquí. [^4] Y corriendo luego á Eli, dijo: Heme aquí; ¿para qué me llamaste? Y Eli le dijo: Yo no he llamado; vuélvete á acostar. Y él se volvió, y acostóse. [^5] Y Jehová volvió á llamar otra vez á Samuel. Y levantándose Samuel vino á Eli, y dijo: Heme aquí; ¿para qué me has llamado? Y él dijo: Hijo mío, yo no he llamado; vuelve, y acuéstate. [^6] Y Samuel no había conocido aún á Jehová, ni la palabra de Jehová le había sido revelada. [^7] Jehová pues llamó la tercera vez á Samuel. Y él levantándose vino á Eli, y dijo: Heme aquí; ¿para qué me has llamado? Entonces entendió Eli que Jehová llamaba al joven. [^8] Y dijo Eli á Samuel: Ve, y acuéstate: y si te llamare, dirás: Habla, Jehová, que tu siervo oye. Así se fué Samuel, y acostóse en su lugar. [^9] Y vino Jehová, y paróse, y llamó como las otras veces: ­Samuel, Samuel! Entonces Samuel dijo: Habla, que tu siervo oye. [^10] Y Jehová dijo á Samuel: He aquí haré yo una cosa en Israel, que á quien la oyere, le retiñirán ambos oídos. [^11] Aquel día yo despertaré contra Eli todas las cosas que he dicho sobre su casa. En comenzando, acabaré también. [^12] Y mostraréle que yo juzgaré su casa para siempre, por la iniquidad que él sabe; porque sus hijos se han envilecido, y él no los ha estorbado. [^13] Y por tanto yo he jurado á la casa de Eli, que la iniquidad de la casa de Eli no será expiada jamás, ni con sacrificios ni con presentes. [^14] Y Samuel estuvo acostado hasta la mañana, y abrió las puertas de la casa de Jehová. Y Samuel temía descubrir la visión á Eli. [^15] Llamando pues Eli á Samuel, díjole: Hijo mío, Samuel. Y él respondió: Heme aquí. [^16] Y dijo: ¿Qué es la palabra que te habló Jehová?; ruégote que no me la encubras: así te haga Dios y así te añada, si me encubrieres palabra de todo lo que habló contigo. [^17] Y Samuel se lo manifestó todo, sin encubrirle nada. Entonces él dijo: Jehová es; haga lo que bien le pareciere. [^18] Y Samuel creció, y Jehová fué con él, y no dejó caer á tierra ninguna de sus palabras. [^19] Y conoció todo Israel desde Dan hasta Beer-sebah, que Samuel era fiel profeta de Jehová. [^20] Así tornó Jehová á aparecer en Silo: porque Jehová se manifestó á Samuel en Silo con palabra de Jehová. [^21] 

[[1 Samuel - 2|<--]] 1 Samuel - 3 [[1 Samuel - 4|-->]]

---
# Notes
