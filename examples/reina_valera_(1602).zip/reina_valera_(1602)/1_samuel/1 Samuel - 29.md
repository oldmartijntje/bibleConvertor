---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 29 - Reina Valera (1602)"
---
[[1 Samuel - 28|<--]] 1 Samuel - 29 [[1 Samuel - 30|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Samuel]]

# 1 Samuel - 29

Y LOS Filisteos juntaron todos sus campos en Aphec; é Israel puso su campo junto á la fuente que está en Jezreel. [^1] Y reconociendo los príncipes de los Filisteos sus compañías de á ciento y de á mil hombres, David y los suyos iban en los postreros con Achîs. [^2] Y dijeron los príncipes de los Filisteos: ¿Qué hacen aquí estos Hebreos? Y Achîs respondió á los príncipes de los Filisteos: ¿No es éste David, el siervo de Saúl rey de Israel, que ha estado conmigo algunos días ó algunos años, y no he hallado cosa en él desde el día que se pasó á mí hasta hoy? [^3] Entonces los príncipes de los Filisteos se enojaron contra él, y dijéronle: Envía á este hombre, que se vuelva al lugar que le señalaste, y no venga con nosotros á la batalla, no sea que en la batalla se nos vuelva enemigo: porque ¿con qué cosa volvería mejor á la gracia de su señor que con las cabezas de estos hombres? [^4] ¿No es este David de quien cantaba en los corros, diciendo: Saúl hirió sus miles, Y David sus diez miles? [^5] Y Achîs llamó á David, y díjole: Vive Jehová, que tú has sido recto, y que me ha parecido bien tu salida y entrada en el campo conmigo, y que ninguna cosa mala he hallado en ti desde el día que viniste á mí hasta hoy: mas en los ojos de los príncipes no agradas. [^6] Vuélvete pues, y vete en paz; y no hagas lo malo en los ojos de los príncipes de los Filisteos. [^7] Y David respondió á Achîs: ¿Qué he hecho? ¿qué has hallado en tu siervo desde el día que estoy contigo hasta hoy, para que yo no vaya y pelee contra los enemigos de mi señor el rey? [^8] Y Achîs respondió á David, y dijo: Yo sé que tú eres bueno en mis ojos, como un ángel de Dios; mas los príncipes de los Filisteos han dicho: No venga con nosotros á la batalla. [^9] Levántate pues de mañana, tú y los siervos de tu señor que han venido contigo; y levantándoos de mañana, luego al amanecer partíos. [^10] Y levantóse David de mañana, él y los suyos, para irse y volverse á la tierra de los Filisteos; y los Filisteos fueron á Jezreel. [^11] 

[[1 Samuel - 28|<--]] 1 Samuel - 29 [[1 Samuel - 30|-->]]

---
# Notes
