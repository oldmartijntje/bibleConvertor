---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 16 - Reina Valera (1602)"
---
[[1 Samuel - 15|<--]] 1 Samuel - 16 [[1 Samuel - 17|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[1 Samuel]]

# 1 Samuel - 16

Y DIJO Jehová á Samuel: ¿Hasta cuándo has tú de llorar á Saúl, habiéndolo yo desechado para que no reine sobre Israel? Hinche tu cuerno de aceite, y ven, te enviaré á Isaí de Beth-lehem: porque de sus hijos me he provisto de rey. [^1] Y dijo Samuel: ¿Cómo iré? Si Saúl lo entendiere, me matará. Jehová respondió: Toma contigo una becerra de la vacada, y di: A sacrificar á Jehová he venido. [^2] Y llama á Isaí al sacrificio, y yo te enseñaré lo que has de hacer; y ungirme has al que yo te dijere. [^3] Hizo pues Samuel como le dijo Jehová: y luego que él llegó á Beth-lehem, los ancianos de la ciudad le salieron á recibir con miedo, y dijeron: ¿Es pacífica tu venida? [^4] Y él respondió: Sí, vengo á sacrificar á Jehová; santificaos, y venid conmigo al sacrificio. Y santificando él á Isaí y á sus hijos, llamólos al sacrificio. [^5] Y aconteció que como ellos vinieron, él vió á Eliab, y dijo: De cierto delante de Jehová está su ungido. [^6] Y Jehová respondió á Samuel: No mires á su parecer, ni á lo grande de su estatura, porque yo lo desecho; porque Jehová mira no lo que el hombre mira; pues que el hombre mira lo que está delante de sus ojos, mas Jehová mira el corazón. [^7] Entonces llamó Isaí á Abinadab, é hízole pasar delante de Samuel, el cual dijo: Ni á éste ha elegido Jehová. [^8] Hizo luego pasar Isaí á Samma. Y él dijo: Tampoco á éste ha elegido Jehová. [^9] E hizo pasar Isaí sus siete hijos delante de Samuel; mas Samuel dijo á Isaí: Jehová no ha elegido á éstos. [^10] Entonces dijo Samuel á Isaí: ¿Hanse acabado los mozos? Y él respondió: Aun queda el menor, que apacienta las ovejas. Y dijo Samuel á Isaí: Envía por él, porque no nos asentaremos á la mesa hasta que él venga aquí. [^11] Envió pues por él, é introdújolo; el cual era rubio, de hermoso parecer y de bello aspecto. Entonces Jehová dijo: Levántate y úngelo, que éste es. [^12] Y Samuel tomó el cuerno del aceite, y ungiólo de entre sus hermanos: y desde aquel día en adelante el espíritu de Jehová tomó á David. Levantóse luego Samuel, y volvióse á Rama. [^13] Y el espíritu de Jehová se apartó de Saúl, y atormentábale el espíritu malo de parte de Jehová. [^14] Y los criados de Saúl le dijeron: He aquí ahora, que el espíritu malo de parte de Dios te atormenta. [^15] Diga pues nuestro señor á tus siervos que están delante de ti, que busquen alguno que sepa tocar el arpa; para que cuando fuere sobre ti el espíritu malo de parte de Dios, él taña con su mano, y tengas alivio. [^16] Y Saúl respondió á sus criados: Buscadme pues ahora alguno que taña bien, y traédmelo. [^17] Entonces uno de los criados respondió, diciendo: He aquí yo he visto á un hijo de Isaí de Beth-lehem, que sabe tocar, y es valiente y vigoroso, y hombre de guerra, prudente en sus palabras, y hermoso, y Jehová es con él. [^18] Y Saúl envió mensajeros á Isaí, diciendo: Envíame á David tu hijo, el que está con las ovejas. [^19] Y tomó Isaí un asno cargado de pan, y un vasija de vino y un cabrito, y enviólo á Saúl por mano de David su hijo. [^20] Y viniendo David á Saúl, estuvo delante de él: y amólo él mucho, y fué hecho su escudero. [^21] Y Saúl envió á decir á Isaí: Yo te ruego que esté David conmigo; porque ha hallado gracia en mis ojos. [^22] Y cuando el espíritu malo de parte de Dios era sobre Saúl, David tomaba el arpa, y tañía con su mano; y Saúl tenía refrigerio, y estaba mejor, y el espíritu malo se apartaba de él. [^23] 

[[1 Samuel - 15|<--]] 1 Samuel - 16 [[1 Samuel - 17|-->]]

---
# Notes
