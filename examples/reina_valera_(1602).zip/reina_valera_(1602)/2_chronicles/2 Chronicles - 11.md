---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 11 - Reina Valera (1602)"
---
[[2 Chronicles - 10|<--]] 2 Chronicles - 11 [[2 Chronicles - 12|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 11

Y COMO vino Roboam á Jerusalem, juntó la casa de Judá y de Benjamín, ciento y ochenta mil hombres escogidos de guerra, para pelear contra Israel y volver el reino á Roboam. [^1] Mas fué palabra de Jehová á Semeías varón de Dios, diciendo: [^2] Habla á Roboam hijo de Salomón, rey de Judá, y á todos los Israelitas en Judá y Benjamín, diciéndoles: [^3] Así ha dicho Jehová: No subáis ni peleéis contra vuestros hermanos; vuélvase casa uno á su casa, porque yo he hecho este negocio. Y ellos oyeron la palabra de Jehová, y tornáronse, y no fueron contra Jeroboam. [^4] Y habitó Roboam en Jerusalem, y edificó ciudades para fortificar á Judá. [^5] Y edificó á Beth-lehem, y á Etham, y á Tecoa, [^6] Y á Beth-sur, y á Sochô, y á Adullam, [^7] Y á Gath, y á Maresa, y á Ziph, [^8] Y á Adoraim, y á Lachîs, y á Acechâ, [^9] Y á Sora, y á Ajalón, y á Hebrón, que eran en Judá y en Benjamín, ciudades fuertes. [^10] Fortificó también las fortalezas, y puso en ellas capitanes, y vituallas, y vino, y aceite; [^11] Y en todas las ciudades, escudos y lanzas. Fortificólas pues en gran manera, y Judá y Benjamín le estaban sujetos. [^12] Y los sacerdotes y Levitas que estaban en todo Israel, se juntaron á él de todos sus términos. [^13] Porque los Levitas dejaban sus ejidos y sus posesiones, y se venían á Judá y á Jerusalem: pues Jeroboam y sus hijos los echaban del ministerio de Jehová. [^14] Y él se hizo sacerdotes para los altos, y para los demonios, y para los becerros que él había hecho. [^15] Tras aquéllos acudieron también de todas las tribus de Israel los que habían puesto su corazón en buscar á Jehová Dios de Israel; y viniéronse á Jerusalem para sacrificar á Jehová, el Dios de sus padres. [^16] Así fortificaron el reino de Judá, y confirmaron á Roboam hijo de Salomón, por tres años; porque tres años anduvieron en el camino de David y de Salomón. [^17] Y tomóse Roboam por mujer á Mahalath, hija de Jerimoth hijo de David, y á Abihail, hija de Eliab hijo de Esaí. [^18] La cual le parió hijos: á Jeus, y á Samaria, y á Zaham. [^19] Después de ella tomó á Maachâ hija de Absalom, la cual le parió á Abías, á Athai, Ziza, y Selomith. [^20] Mas Roboam amó á Maachâ hija de Absalom sobre todas sus mujeres y concubinas; porque tomó diez y ocho mujeres y sesenta concubinas, y engendró veintiocho hijos y sesenta hijas. [^21] Y puso Roboam á Abías hijo de Maachâ por cabeza y príncipe de sus hermanos, porque quería hacerle rey. [^22] E hízole instruir, y esparció todos sus hijos por todas las tierras de Judá y de Benjamín, y por todas las ciudades fuertes, y dióles vituallas en abundancia, y pidió muchas mujeres. [^23] 

[[2 Chronicles - 10|<--]] 2 Chronicles - 11 [[2 Chronicles - 12|-->]]

---
# Notes
