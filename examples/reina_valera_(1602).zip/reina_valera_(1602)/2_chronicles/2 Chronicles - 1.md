---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 1 - Reina Valera (1602)"
---
2 Chronicles - 1 [[2 Chronicles - 2|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 1

Y SALOMON hijo de David fué afirmado en su reino; y Jehová su Dios fué con él, y le engrandeció sobremanera. [^1] Y llamó Salomón á todo Israel, tribunos, centuriones, y jueces, y á todos los príncipes de todo Israel, cabezas de familias. [^2] Y fué Salomón, y con él toda esta junta, al alto que había en Gabaón; porque allí estaba el tabernáculo del testimonio de Dios, que Moisés siervo de Jehová había hecho en el desierto. [^3] Mas David había traído el arca de Dios de Chîriath-jearim al lugar que él le había preparado; porque él le había tendido una tienda en Jerusalem. [^4] Asimismo el altar de bronce que había hecho Bezaleel hijo de Uri hijo de Hur, estaba allí delante del tabernáculo de Jehová, al cual fué á consultar Salomón con aquella junta. [^5] Subió pues Salomón allá delante de Jehová, al altar de bronce que estaba en el tabernáculo del testimonio, y ofreció sobre él mil holocaustos. [^6] Y aquella noche apareció Dios á Salomón, y díjole: Demanda lo que quisieres que yo te dé. [^7] Y Salomón dijo á Dios: Tú has hecho con David mi padre grande misericordia, y á mí me has puesto por rey en lugar suyo. [^8] Confírmese pues ahora, oh Jehová Dios, tu palabra dada á David mi padre; porque tú me has puesto por rey sobre un pueblo en muchedumbre como el polvo de la tierra. [^9] Dame ahora sabiduría y ciencia, para salir y entrar delante de este pueblo: porque ¿quién podrá juzgar este tu pueblo tan grande? [^10] Y dijo Dios á Salomón: Por cuanto esto fué en tu corazón, que no pediste riquezas, hacienda, ó gloria, ni el alma de los que te quieren mal, ni pediste muchos días, sino que has pedido para ti sabiduría y ciencia para juzgar mi pueblo, sobre el cual te he puesto por rey, [^11] Sabiduría y ciencia te es dada; y también te daré riquezas, hacienda, y gloria, cual nunca hubo en los reyes que han sido antes de ti, ni después de ti habrá tal. [^12] Y volvió Salomón á Jerusalem del alto que estaba en Gabaón, de ante el tabernáculo del testimonio; y reinó sobre Israel. [^13] Y juntó Salomón carros y gente de á caballo; y tuvo mil y cuatrocientos carros, y doce mil jinetes, los cuales puso en las ciudades de los carros, y con el rey en Jerusalem. [^14] Y puso el rey plata y oro en Jerusalem como piedras, y cedro como cabrahigos que nacen en los campos en abundancia. [^15] Y sacaban caballos y lienzos finos de Egipto para Salomón; pues por contrato tomaban allí los mercaderes del rey caballos y lienzos. [^16] Y subían, y sacaban de Egipto, un carro por seiscientas piezas de plata, y un caballo por ciento y cincuenta: y así se sacaban por medio de ellos para todos los reyes de los Hetheos, y para los reyes de Siria. [^17] 

2 Chronicles - 1 [[2 Chronicles - 2|-->]]

---
# Notes
