---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 14 - Reina Valera (1602)"
---
[[2 Chronicles - 13|<--]] 2 Chronicles - 14 [[2 Chronicles - 15|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 14

Y DURMIO Abías con sus padres, y fué sepultado en la ciudad de David. Y reinó en su lugar su hijo Asa, en cuyos días tuvo sosiego el país por diez años. [^1] E hizo Asa lo bueno y lo recto en los ojos de Jehová su Dios. [^2] Porque quitó los altares del culto ajeno, y los altos; quebró las imágenes, y taló los bosques; [^3] Y mandó á Judá que buscasen á Jehová el Dios de sus padres, y pusiesen por obra la ley y sus mandamientos. [^4] Quitó asimismo de todas las ciudades de Judá los altos y las imágenes, y estuvo el reino quieto delante de él. [^5] Y edificó ciudades fuertes en Judá, por cuanto había paz en la tierra, y no había guerra contra él en aquellos tiempos; porque Jehová le había dado reposo. [^6] Dijo por tanto á Judá: Edifiquemos estas ciudades, y cerquémoslas de muros con torres, puertas, y barras, ya que la tierra es nuestra: porque hemos buscado á Jehová nuestro Dios, hémosle buscado, y él nos ha dado reposo de todas partes. Edificaron pues, y fueron prosperados. [^7] Tuvo también Asa ejército que traía escudos y lanzas: de Judá trescientos mil, y de Benjamín doscientos y ochenta mil que traían escudos y flechaban arcos; todos hombres diestros. [^8] Y salió contra ellos Zera Etiope con un ejército de mil millares, y trescientos carros; y vino hasta Maresa. [^9] Entonces salió Asa contra él, y ordenaron la batalla en el valle de Sephata junto á Maresa. [^10] Y clamó Asa á Jehová su Dios, y dijo: Jehová, no tienes tú más con el grande que con el que ninguna fuerza tiene, para dar ayuda. Ayúdanos, oh Jehová Dios nuestro, porque en ti nos apoyamos, y en tu nombre venimos contra este ejército. Oh Jehová, tú eres nuestro Dios: no prevalezca contra ti el hombre. [^11] Y Jehová deshizo los Etiopes delante de Asa y delante de Judá; y huyeron los Etiopes. [^12] Y Asa, y el pueblo que con él estaba, lo siguió hasta Gerar: y cayeron los Etiopes hasta no quedar en ellos aliento; porque fueron deshechos delante de Jehová y de su ejército. Y les tomaron muy grande despojo. [^13] Batieron también todas las ciudades alrededor de Gerar, porque el terror de Jehová fué sobre ellos: y saquearon todas las ciudades, porque había en ellas gran despojo. [^14] Asimismo dieron sobre las cabañas de los ganados, y trajeron muchas ovejas y camellos, y volviéronse á Jerusalem. [^15] 

[[2 Chronicles - 13|<--]] 2 Chronicles - 14 [[2 Chronicles - 15|-->]]

---
# Notes
