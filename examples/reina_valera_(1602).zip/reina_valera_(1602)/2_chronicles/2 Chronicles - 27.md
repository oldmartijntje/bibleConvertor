---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 27 - Reina Valera (1602)"
---
[[2 Chronicles - 26|<--]] 2 Chronicles - 27 [[2 Chronicles - 28|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 27

DE VEINTICINCO años era Joatham cuando comenzó á reinar, y dieciséis años reinó en Jerusalem. El nombre de su madre fué Jerusa, hija de Sadoc. [^1] E hizo lo recto en ojos de Jehová, conforme á todas las cosas que había hecho Uzzías su padre, salvo que no entró en el templo de Jehová. Y el pueblo falseaba aún. [^2] Edificó él la puerta mayor de la casa de Jehová, y en el muro de la fortaleza edificó mucho. [^3] Además edificó ciudades en las montañas de Judá, y labró palacios y torres en los bosques. [^4] También tuvo él guerra con el rey de los hijos de Ammón, á los cuales venció; y diéronle los hijos de Ammón en aquel año cien talentos de plata, y diez mil coros de trigo, y diez mil de cebada. Esto le dieron los hijos de Ammón, y lo mismo en el segundo año, y en el tercero. [^5] Así que Joatham fué fortificado, porque preparó sus caminos delante de Jehová su Dios. [^6] Lo demás de los hechos de Joatham, y todas sus guerras, y sus caminos, he aquí está escrito en el libro de los reyes de Israel y de Judá. [^7] Cuando comenzó á reinar era de veinticinco años, y dieciséis reinó en Jerusalem. [^8] Y durmió Joatham con sus padres, y sepultáronlo en la ciudad de David; y reinó en su lugar Achâz su hijo. [^9] 

[[2 Chronicles - 26|<--]] 2 Chronicles - 27 [[2 Chronicles - 28|-->]]

---
# Notes
