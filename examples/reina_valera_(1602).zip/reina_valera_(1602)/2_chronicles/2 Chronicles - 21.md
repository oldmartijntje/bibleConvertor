---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 21 - Reina Valera (1602)"
---
[[2 Chronicles - 20|<--]] 2 Chronicles - 21 [[2 Chronicles - 22|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 21

Y DURMIO Josaphat con sus padres, y sepultáronlo con sus padres en la ciudad de David. Y reinó en su lugar Joram su hijo. [^1] Este tuvo hermanos, hijos de Josaphat, á Azarías, Jehiel, Zachârías, Azarías, Michâel, y Sephatías. Todos estos fueron hijos de Josaphat rey de Israel. [^2] Y su padre les había dado muchos dones de oro y de plata, y cosas preciosas, y ciudades fuertes en Judá; mas había dado el reino á Joram, porque él era el primogénito. [^3] Fué pues elevado Joram al reino de su padre; y luego que se hizo fuerte, mató á cuchillo á todos sus hermanos, y asimismo algunos de los príncipes de Israel. [^4] Cuando comenzó á reinar era de treinta y dos años, y reinó ocho años en Jerusalem. [^5] Y anduvo en el camino de los reyes de Israel, como hizo la casa de Achâb; porque tenía por mujer la hija de Achâb, é hizo lo malo en ojos de Jehová. [^6] Mas Jehová no quiso destruir la casa de David, á causa de la alianza que con David había hecho, y porque le había dicho que le daría lámpara á él y á sus hijos perpetuamente. [^7] En los días de éste se rebeló la Idumea, para no estar bajo el poder de Judá, y pusieron rey sobre sí. [^8] Entonces pasó Joram con sus príncipes, y consigo todos sus carros; y levantóse de noche, é hirió á los Idumeos que le habían cercado, y á todos los comandantes de sus carros. [^9] Con todo eso Edom quedó rebelado, sin estar bajo la mano de Judá hasta hoy. También se rebeló en el mismo tiempo Libna para no estar bajo su mano; por cuanto él había dejado á Jehová el Dios de sus padres. [^10] Demás de esto hizo altos en los montes de Judá, é hizo que los moradores de Jerusalem fornicasen, y á ello impelió á Judá. [^11] Y viniéronle letras del profeta Elías, que decían: Jehová, el Dios de David tu padre, ha dicho así: Por cuanto no has andado en los caminos de Josaphat tu padre, ni en los caminos de Asa, rey de Judá, [^12] Antes has andado en el camino de los reyes de Israel, y has hecho que fornicase Judá, y los moradores de Jerusalem, como fornicó la casa de Achâb; y además has muerto á tus hermanos, á la familia de tu padre, los cuales eran mejores que tú: [^13] He aquí Jehová herirá tu pueblo de una grande plaga, y á tus hijos y á tus mujeres, y á toda tu hacienda; [^14] Y á ti con muchas enfermedades, con enfermedad de tus entrañas, hasta que las entrañas se te salgan á causa de la enfermedad de cada día. [^15] Entonces despertó Jehová contra Joram el espíritu de los Filisteos, y de los Arabes que estaban junto á los Etiopes; [^16] Y subieron contra Judá, é invadieron la tierra, y tomaron toda la hacienda que hallaron en la casa del rey, y á sus hijos, y á sus mujeres; que no le quedó hijo, sino Joachâz el menor de sus hijos. [^17] Después de todo esto Jehová lo hirió en las entrañas de una enfermedad incurable. [^18] Y aconteció que, pasando un día tras otro, al fin, al cabo de dos años, las entrañas se le salieron con la enfermedad, muriendo así de enfermedad muy penosa. Y no le hizo quema su pueblo, como las había hecho á sus padres. [^19] Cuando comenzó á reinar era de treinta y dos años, y reinó en Jerusalem ocho años; y fuése sin ser deseado. Y sepultáronlo en la ciudad de David, mas no en los sepulcros de los reyes. [^20] 

[[2 Chronicles - 20|<--]] 2 Chronicles - 21 [[2 Chronicles - 22|-->]]

---
# Notes
