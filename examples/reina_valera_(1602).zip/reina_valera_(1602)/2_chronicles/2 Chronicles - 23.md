---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 23 - Reina Valera (1602)"
---
[[2 Chronicles - 22|<--]] 2 Chronicles - 23 [[2 Chronicles - 24|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 23

MAS el séptimo año se animó Joiada, y tomó consigo en alianza á los centuriones, Azarías hijo de Jeroam, y á Ismael hijo de Johanán, y á Azarías hijo de Obed, y á Maasías hijo de Adaías, y á Elisaphat hijo de Zichri; [^1] Los cuales rodeando por Judá, juntaron los Levitas de todas las ciudades de Judá, y á los príncipes de las familias de Israel, y vinieron á Jerusalem. [^2] Y toda la multitud hizo alianza con el rey en la casa de Dios. Y él les dijo: He aquí el hijo del rey, el cual reinará, como Jehová lo tiene dicho de los hijos de David. [^3] Lo que habéis de hacer es: la tercera parte de vosotros, los que entran de semana, estarán de porteros con los sacerdotes y los Levitas; [^4] Y la tercera parte, á la casa del rey; y la tercera parte, á la puerta del fundamento: y todo el pueblo estará en los patios de la casa de Jehová. [^5] Y ninguno entre en la casa de Jehová, sino los sacerdotes y Levitas que sirven: éstos entrarán, porque están consagrados; y todo el pueblo hará la guardia de Jehová. [^6] Y los Levitas rodearán al rey por todas partes, y cada uno tendrá sus armas en la mano; y cualquiera que entrare en la casa, muera: y estaréis con el rey cuando entrare, y cuando saliere. [^7] Y los Levitas y todo Judá lo hicieron todo como lo había mandado el sacerdote Joiada: y tomó cada uno los suyos, los que entraban de semana, y los que salían el sábado: porque el sacerdote Joiada no dió licencia á las compañías. [^8] Dió también el sacerdote Joiada á los centuriones las lanzas, paveses y escudos que habían sido del rey David, que estaban en la casa de Dios; [^9] Y puso en orden á todo el pueblo, teniendo cada uno su espada en la mano, desde el rincón derecho del templo hasta el izquierdo, hacia el altar y la casa, en derredor del rey por todas partes. [^10] Entonces sacaron al hijo del rey, y pusiéronle la corona y el testimonio, é hiciéronle rey; y Joiada y sus hijos le ungieron, diciendo luego: ­Viva el rey! [^11] Y como Athalía oyó el estruendo de la gente que corría, y de los que bendecían al rey, vino al pueblo á la casa de Jehová; [^12] Y mirando, vió al rey que estaba junto á su columna á la entrada, y los príncipes y los trompetas junto al rey, y que todo el pueblo de la tierra hacía alegrías, y sonaban bocinas, y cantaban con instrumentos de música los que sabían alabar. Entonces Athalía rasgó sus vestidos, y dijo: ­Conjuración, conjuración! [^13] Y sacando el pontífice Joiada los centuriones y capitanes del ejército, díjoles: Sacadla fuera del recinto; y el que la siguiere, muera á cuchillo: porque el sacerdote había mandado que no la matasen en la casa de Jehová. [^14] Ellos pues le echaron mano, y luego que hubo ella pasado la entrada de la puerta de los caballos de la casa del rey, allí la mataron. [^15] Y Joiada hizo pacto entre sí y todo el pueblo y el rey, que serían pueblo de Jehová. [^16] Después de esto entró todo el pueblo en el templo de Baal, y derribáronlo, y también sus altares; é hicieron pedazos sus imágenes, y mataron delante de los altares á Mathán, sacerdote de Baal. [^17] Luego ordenó Joiada los oficios en la casa de Jehová bajo la mano de los sacerdotes y Levitas, según David los había distribuído en la casa de Jehová, para ofrecer á Jehová los holocaustos, como está escrito en la ley de Moisés, con gozo y cantares, conforme á la ordenación de David. [^18] Puso también porteros á las puertas de la casa de Jehová, para que por ninguna vía entrase ningún inmundo. [^19] Tomó después los centuriones, y los principales, y los que gobernaban el pueblo; y á todo el pueblo de la tierra, y llevó al rey de la casa de Jehová; y viniendo hasta el medio de la puerta mayor de la casa del rey, sentaron al rey sobre el trono del reino. [^20] Y todo el pueblo del país hizo alegrías: y la ciudad estuvo quieta, muerto que hubieron á Athalía á cuchillo. [^21] 

[[2 Chronicles - 22|<--]] 2 Chronicles - 23 [[2 Chronicles - 24|-->]]

---
# Notes
