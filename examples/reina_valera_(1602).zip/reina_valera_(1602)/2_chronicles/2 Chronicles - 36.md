---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 36 - Reina Valera (1602)"
---
[[2 Chronicles - 35|<--]] 2 Chronicles - 36

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 36

ENTONCES el pueblo de la tierra tomó á Joachâz hijo de Josías, é hiciéronle rey en lugar de su padre en Jerusalem. [^1] De veinte y tres años era Joachâz cuando comenzó á reinar, y tres meses reinó en Jerusalem. [^2] Y el rey de Egipto lo quitó de Jerusalem, y condenó la tierra en cien talentos de plata y uno de oro. [^3] Y constituyó el rey de Egipto á su hermano Eliacim por rey sobre Judá y Jerusalem, y mudóle el nombre en Joacim; y á Joachâz su hermano tomó Nechâo, y llevólo á Egipto. [^4] Cuando comenzó á reinar Joacim era de veinte y cinco años, y reinó once años en Jerusalem: é hizo lo malo en ojos de Jehová su Dios. [^5] Y subió contra él Nabucodonosor rey de Babilonia, y atado con cadenas lo llevó á Babilonia. [^6] También llevó Nabucodonosor á Babilonia de los vasos de la casa de Jehová, y púsolos en su templo en Babilonia. [^7] Lo demás de los hechos de Joacim, y las abominaciones que hizo, y lo que en él se halló, he aquí está escrito en el libro de los reyes de Israel y de Judá: y reinó en su lugar Joachîn su hijo. [^8] De ocho años era Joachîn cuando comenzó á reinar, y reinó tres meses y diez días en Jerusalem: é hizo lo malo en ojos de Jehová. [^9] A la vuelta del año el rey Nabucodonosor envió, é hízolo llevar á Babilonia juntamente con los vasos preciosos de la casa de Jehová; y constituyó á Sedecías su hermano por rey sobre Judá y Jerusalem. [^10] De veinte y un años era Sedecías cuando comenzó á reinar, y once años reinó en Jerusalem. [^11] E hizo lo malo en ojos de Jehová su Dios, y no se humilló delante de Jeremías profeta, que le hablaba de parte de Jehová. [^12] Rebelóse asimismo contra Nabucodonosor, al cual había jurado por Dios; y endureció su cerviz, y obstinó su corazón, para no volverse á Jehová el Dios de Israel. [^13] Y también todos los príncipes de los sacerdotes, y el pueblo, aumentaron la prevaricación, siguiendo todas las abominaciones de las gentes, y contaminando la casa de Jehová, la cual él había santificado en Jerusalem. [^14] Y Jehová el Dios de sus padres envió á ellos por mano de sus mensajeros, levantándose de mañana y enviando: porque él tenía misericordia de su pueblo, y de su habitación. [^15] Mas ellos hacían escarnio de los mensajeros de Dios, y menospreciaban sus palabras, burlándose de sus profetas, hasta que subió el furor de Jehová contra su pueblo, y que no hubo remedio. [^16] Por lo cual trajo contra ellos al rey de los Caldeos, que mató á cuchillo sus mancebos en la casa de su santuario, sin perdonar joven, ni doncella, ni viejo, ni decrépito; todos los entregó en sus manos. [^17] Asimismo todos los vasos de la casa de Dios, grandes y chicos, los tesoros de la casa de Jehová, y los tesoros del rey y de sus príncipes, todo lo llevó á Babilonia. [^18] Y quemaron la casa de Dios, y rompieron el muro de Jerusalem, y consumieron al fuego todos sus palacios, y destruyeron todos sus vasos deseables. [^19] Los que quedaron del cuchillo, pasáronlos á Babilonia; y fueron siervos de él y de sus hijos, hasta que vino el reino de los Persas; [^20] Para que se cumpliese la palabra de Jehová por la boca de Jeremías, hasta que la tierra hubo gozado sus sábados: porque todo el tiempo de su asolamiento reposó, hasta que los setenta años fueron cumplidos. [^21] Mas al primer año de Ciro rey de los Persas, para que se cumpliese la palabra de Jehová por boca de Jeremías, Jehová excitó el espíritu de Ciro rey de los Persas, el cual hizo pasar pregón por todo su reino, y también por escrito, diciendo: [^22] Así dice Ciro rey de los Persas: Jehová, el Dios de los cielos, me ha dado todos los reinos de la tierra; y él me ha encargado que le edifique casa en Jerusalem, que es en Judá. ¿Quién de vosotros hay de todo su pueblo? Jehová su Dios sea con él, y suba. [^23] 

[[2 Chronicles - 35|<--]] 2 Chronicles - 36

---
# Notes
