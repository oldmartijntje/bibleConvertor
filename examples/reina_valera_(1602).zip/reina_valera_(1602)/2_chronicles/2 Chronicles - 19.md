---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 19 - Reina Valera (1602)"
---
[[2 Chronicles - 18|<--]] 2 Chronicles - 19 [[2 Chronicles - 20|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 19

Y JOSAPHAT rey de Judá se volvió en paz á su casa en Jerusalem. [^1] Y salióle al encuentro Jehú el vidente, hijo de Hanani, y dijo al rey Josaphat: ¿Al impío das ayuda, y amas á los que aborrecen á Jehová? Pues la ira de la presencia de Jehová será sobre ti por ello. [^2] Empero se han hallado en ti buenas cosas, porque cortaste de la tierra los bosques, y has apercibido tu corazón á buscar á Dios. [^3] Habitó pues Josaphat en Jerusalem; mas daba vuelta y salía al pueblo, desde Beer-seba hasta el monte de Ephraim, y reducíalos á Jehová el Dios de sus padres. [^4] Y puso en la tierra jueces en todas las ciudades fuertes de Judá, por todos los lugares. [^5] Y dijo á los jueces: Mirad lo que hacéis: porque no juzguéis en lugar de hombre, sino en lugar de Jehová, el cual está con vosotros en el negocio del juicio. [^6] Sea pues con vosotros el temor de Jehová; guardad y haced: porque en Jehová nuestro Dios no hay iniquidad, ni acepción de personas, ni recibir cohecho. [^7] Y puso también Josaphat en Jerusalem algunos de los Levitas y sacerdotes, y de los padres de familias de Israel, para el juicio de Jehová y para las causas. Y volviéronse á Jerusalem. [^8] Y mandóles, diciendo: Procederéis asimismo con temor de Jehová, con verdad, y con corazón íntegro. [^9] En cualquier causa que viniere á vosotros de vuestros hermanos que habitan en las ciudades, entre sangre y sangre, entre ley y precepto, estatutos y derechos, habéis de amonestarles que no pequen contra Jehová, porque no venga ira sobre vosotros y sobre vuestros hermanos. Obrando así no pecaréis. [^10] Y he aquí Amarías sacerdote será el que os presida en todo negocio de Jehová; y Zebadías hijo de Ismael, príncipe de la casa de Judá, en todos los negocios del rey; también los Levitas serán oficiales en presencia de vosotros. Esforzaos pues, y obrad; que Jehová será con el bueno. [^11] 

[[2 Chronicles - 18|<--]] 2 Chronicles - 19 [[2 Chronicles - 20|-->]]

---
# Notes
