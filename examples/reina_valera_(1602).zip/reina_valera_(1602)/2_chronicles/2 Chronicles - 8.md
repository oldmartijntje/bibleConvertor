---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 8 - Reina Valera (1602)"
---
[[2 Chronicles - 7|<--]] 2 Chronicles - 8 [[2 Chronicles - 9|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 8

Y ACONTECIO que al cabo de veinte años que Salomón había edificado la casa de Jehová y su casa, [^1] Reedificó Salomón las ciudades que Hiram le había dado, y estableció en ellas á los hijos de Israel. [^2] Después vino Salomón á Amath de Soba, y la tomó. [^3] Y edificó á Tadmor en el desierto, y todas las ciudades de municiones que edificó en Hamath. [^4] Asimismo reedificó á Beth-oron la de arriba, y á Beth-oron la de abajo, ciudades fortificadas, de muros, puertas, y barras; [^5] Y á Baalath, y á todas las villas de munición que Salomón tenía; también todas las ciudades de los carros y las de la gente de á caballo; y todo lo que Salomón quiso edificar en Jerusalem, y en el Líbano, y en toda la tierra de su señorío. [^6] Y á todo el pueblo que había quedado de los Hetheos, Amorrheos, Pherezeos, Heveos, y Jebuseos, que no eran de Israel, [^7] Los hijos de los que habían quedado en la tierra después de ellos, á los cuales los hijos de Israel no destruyeron del todo, hizo Salomón tributarios hasta hoy. [^8] Y de los hijos de Israel no puso Salomón siervos en su obra; porque eran hombres de guerra, y sus príncipes y sus capitanes, y comandantes de sus carros, y su gente de á caballo. [^9] Y tenía Salomón doscientos y cincuenta principales de los gobernadores, los cuales mandaban en aquella gente. [^10] Y pasó Salomón á la hija de Faraón, de la ciudad de David á la casa que él le había edificado; porque dijo: Mi mujer no morará en la casa de David rey de Israel, porque aquellas habitaciones donde ha entrado el arca de Jehová, son sagradas. [^11] Entonces ofreció Salomón holocaustos á Jehová sobre el altar de Jehová, que había él edificado delante del pórtico, [^12] Para que ofreciesen cada cosa en su día, conforme al mandamiento de Moisés, en los sábados, en las nuevas lunas, y en las solemnidades, tres veces en el año, á saber, en la fiesta de los panes ázimos, en la fiesta de las semanas, y en la fiesta de las cabañas. [^13] Y constituyó los repartimientos de los sacerdotes en sus oficios, conforme á la ordenación de David su padre; y los Levitas por sus órdenes, para que alabasen y ministrasen delante de los sacerdotes, casa cosa en su día; asimismo los porteros por su orden á cada puerta: porque así lo había mandado David, varón de Dios. [^14] Y no salieron del mandamiento del rey, cuanto á los sacerdotes y Levitas, y los tesoros, y todo negocio: [^15] Porque toda la obra de Salomón estaba preparada desde el día en que la casa de Jehová fué fundada hasta que se acabó, hasta que la casa de Jehová fué acabada del todo. [^16] Entonces Salomón fué á Esion-geber, y á Eloth, á la costa de la mar en la tierra de Edom. [^17] Porque Hiram le había enviado navíos por mano de sus siervos, y marineros diestros en la mar, los cuales fueron con los siervos de Salomón á Ophir, y tomaron de allá cuatrocientos y cincuenta talentos de oro, y los trajeron al rey Salomón. [^18] 

[[2 Chronicles - 7|<--]] 2 Chronicles - 8 [[2 Chronicles - 9|-->]]

---
# Notes
