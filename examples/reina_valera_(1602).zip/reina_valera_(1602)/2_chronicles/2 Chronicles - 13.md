---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 13 - Reina Valera (1602)"
---
[[2 Chronicles - 12|<--]] 2 Chronicles - 13 [[2 Chronicles - 14|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 13

A LOS dieciocho años del rey Jeroboam, reinó Abías sobre Judá. [^1] Y reinó tres años en Jerusalem. El nombre de su madre fué Michâía hija de Uriel de Gabaa. Y hubo guerra entre Abías y Jeroboam. [^2] Entonces ordenó Abías batalla con un ejército de cuatrocientos mil hombres de guerra valerosos y escogidos: y Jeroboam ordenó batalla contra él con ochocientos mil hombres escogidos, fuertes y valerosos. [^3] Y levantóse Abías sobre el monte de Semaraim, que es en los montes de Ephraim, y dijo: Oidme, Jeroboam y todo Israel. [^4] ¿No sabéis vosotros, que Jehová Dios de Israel dió el reino á David sobre Israel para siempre, á él y á sus hijos en alianza de sal? [^5] Pero Jeroboam hijo de Nabat, siervo de Salomón hijo de David, se levantó y rebeló contra su señor. [^6] Y se allegaron á el hombres vanos, hijos de iniquidad, y pudieron más que Roboam hijo de Salomón, porque Roboam era mozo y tierno de corazón, y no se defendió de ellos. [^7] Y ahora vosotros tratáis de fortificaros contra el reino de Jehová en mano de los hijos de David, porque sois muchos, y tenéis con vosotros los becerros de oro que Jeroboam os hizo por dioses. [^8] ¿No echasteis vosotros á los sacerdotes de Jehová, á los hijos de Aarón, y á los Levitas, y os habéis hecho sacerdotes á la manera de los pueblos de otras tierras, para que cualquiera venga á consagrarse con un becerro y siete carneros, y así sea sacerdote de los que no son dioses? [^9] Mas en cuanto á nosotros, Jehová es nuestro Dios, y no le hemos dejado: y los sacerdotes que ministran á Jehová son los hijos de Aarón, y los Levitas en la obra; [^10] Los cuales queman á Jehová los holocaustos cada mañana y cada tarde, y los perfumes aromáticos; y ponen los panes sobre la mesa limpia, y el candelero de oro con sus candilejas para que ardan cada tarde: porque nosotros guardamos la ordenanza de Jehová nuestro Dios; mas vosotros le habéis dejado. [^11] Y he aquí Dios está con nosotros por cabeza, y sus sacerdotes con las trompetas del júbilo para que suenen contra vosotros. Oh hijos de Israel, no peleéis contra Jehová el Dios de vuestros padres, porque no os sucederá bien. [^12] Pero Jeroboam hizo girar una emboscada para venir á ellos por la espalda: y estando así delante de ellos, la emboscada estaba á espaldas de Judá. [^13] Y como miró Judá, he aquí que tenía batalla delante y á las espaldas; por lo que clamaron á Jehová, y los sacerdotes tocaron las trompetas. [^14] Entonces los de Judá alzaron grita; y así que ellos alzaron grita, Dios desbarató á Jeroboam y á todo Israel delante de Abías y de Judá: [^15] Y huyeron los hijos de Israel delante de Judá, y Dios los entregó en sus manos. [^16] Y Abías y su gente hacían en ellos gran mortandad; y cayeron heridos de Israel quinientos mil hombres escogidos. [^17] Así fueron humillados los hijos de Israel en aquel tiempo: mas los hijos de Judá se fortificaron, porque se apoyaban en Jehová el Dios de sus padres. [^18] Y siguió Abías á Jeroboam, y tomóle algunas ciudades, á Beth-el con sus aldeas, á Jesana con sus aldeas, y á Ephraim con sus aldeas. [^19] Y nunca más tuvo Jeroboam poderío en los días de Abías: é hirióle Jehová, y murió. [^20] Empero se fortificó Abías; y tomó catorce mujeres, y engendró veintidós hijos, y dieciséis hijas. [^21] Lo demás de los hechos de Abías, sus caminos y sus negocios, está escrito en la historia de Iddo profeta. [^22] 

[[2 Chronicles - 12|<--]] 2 Chronicles - 13 [[2 Chronicles - 14|-->]]

---
# Notes
