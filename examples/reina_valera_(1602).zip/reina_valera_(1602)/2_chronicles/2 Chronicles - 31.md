---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 31 - Reina Valera (1602)"
---
[[2 Chronicles - 30|<--]] 2 Chronicles - 31 [[2 Chronicles - 32|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 31

HECHAS todas estas cosas, todos los de Israel que se habían hallado allí, salieron por las ciudades de Judá, y quebraron las estatuas y destruyeron los bosques, y derribaron los altos y los altares por todo Judá y Benjamín, y también en Ephraim y Manasés, hasta acabarlo todo. Después volviéronse todos los hijos de Israel, cada uno á su posesión y á sus ciudades. [^1] Y arregló Ezechîas los repartimientos de los sacerdotes y de los Levitas conforme á sus órdenes, cada uno según su oficio, los sacerdotes y los Levitas para el holocausto y pacíficos, para que ministrasen, para que confesasen y alabasen á las puertas de los reales de Jehová. [^2] La contribución del rey de su hacienda, era holocaustos á mañana y tarde, y holocaustos para los sábados, nuevas lunas, y solemnidades, como está escrito en la ley de Jehová. [^3] Mandó también al pueblo que habitaba en Jerusalem, que diesen la porción á los sacerdotes y Levitas, para que se esforzasen en la ley de Jehová. [^4] Y como este edicto fué divulgado, los hijos de Israel dieron muchas primicias de grano, vino, aceite, miel, y de todos los frutos de la tierra: trajeron asimismo los diezmos de todas las cosas en abundancia. [^5] También los hijos de Israel y de Judá, que habitaban en las ciudades de Judá, dieron del mismo modo los diezmos de las vacas y de las ovejas: y trajeron los diezmos de lo santificado, de las cosas que habían prometido á Jehová su Dios, y pusiéronlos por montones. [^6] En el mes tercero comenzaron á fundar aquellos montones, y en el mes séptimo acabaron. [^7] Y Ezechîas y los príncipes vinieron á ver los montones, y bendijeron á Jehová, y á su pueblo Israel. [^8] Y preguntó Ezechîas á los sacerdotes y á los Levitas acerca de los montones. [^9] Y respondióle Azarías, sumo sacerdote, de la casa de Sadoc, y dijo: Desde que comenzaron á traer la ofrenda á la casa de Jehová, hemos comido y saciádonos, y nos ha sobrado mucho: porque Jehová ha bendecido su pueblo, y ha quedado esta muchedumbre. [^10] Entonces mandó Ezechîas que preparasen cámaras en la casa de Jehová; y preparáronlas. [^11] Y metieron las primicias y diezmos y las cosas consagradas, fielmente; y dieron cargo de ello á Chônanías Levita, el principal, y Simi su hermano fué el segundo. [^12] Y Jehiel, Azazías, Nahath, Asael, Jerimoth, Josabad, Eliel, Ismachîas, Mahaath, y Benaías, fueron sobrestantes bajo la mano de Chônanías y de Simi su hermano, por mandamiento del rey Ezechîas y de Azarías, príncipe de la casa de Dios. [^13] Y Coré hijo de Imna Levita, portero al oriente, tenía cargo de las limosnas de Dios, y de las ofrendas de Jehová que se daban, y de todo lo que se santificaba. [^14] Y á su mano estaba Edén, Benjamín, Jeshua, Semaías, Amarías, y Sechânías, en las ciudades de los sacerdotes, para dar con fidelidad á sus hermanos sus partes conforme á sus órdenes, así al mayor como al menor: [^15] A más de los varones anotados por sus linajes, de tres años arriba, á todos los que entraban en la casa de Jehová, su porción diaria por su ministerio, según sus oficios y clases; [^16] También á los que eran contados entre los sacerdotes por las familias de sus padres, y á los Levitas de edad de veinte años arriba, conforme á sus oficios y órdenes; [^17] Asimismo á los de su generación con todos sus niños, y sus mujeres, y sus hijos é hijas, á toda la familia; porque con fidelidad se consagraban á las cosas santas. [^18] Del mismo modo en orden á los hijos de Aarón, sacerdotes, que estaban en los ejidos de sus ciudades, por todas las ciudades, los varones nombrados tenían cargo de dar sus porciones á todos los varones de los sacerdotes, y á todo el linaje de los Levitas. [^19] De esta manera hizo Ezechîas en todo Judá: y ejecutó lo bueno, recto, y verdadero, delante de Jehová su Dios. [^20] En todo cuanto comenzó en el servicio de la casa de Dios, y en la ley y mandamientos, buscó á su Dios, é hízolo de todo corazón, y fué prosperado. [^21] 

[[2 Chronicles - 30|<--]] 2 Chronicles - 31 [[2 Chronicles - 32|-->]]

---
# Notes
