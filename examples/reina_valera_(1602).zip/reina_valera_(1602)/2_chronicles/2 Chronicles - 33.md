---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 33 - Reina Valera (1602)"
---
[[2 Chronicles - 32|<--]] 2 Chronicles - 33 [[2 Chronicles - 34|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 33

DE DOCE años era Manasés cuando comenzó á reinar, y cincuenta y cinco años reinó en Jerusalem. [^1] Mas hizo lo malo en ojos de Jehová, conforme á las abominaciones de las gentes que había echado Jehová delante de los hijos de Israel: [^2] Porque él reedificó los altos que Ezechîas su padre había derribado, y levantó altares á los Baales, é hizo bosques, y adoró á todo el ejército de los cielos, y á él sirvió. [^3] Edificó también altares en la casa de Jehová, de la cual había dicho Jehová: En Jerusalem será mi nombre perpetuamente. [^4] Edificó asimismo altares á todo el ejército de los cielos en los dos atrios de la casa de Jehová. [^5] Y pasó sus hijos por fuego en el valle de los hijos de Hinnom; y miraba en los tiempos, miraba en agüeros, era dado á adivinaciones, y consultaba pythones y encantadores: subió de punto en hacer lo malo en ojos de Jehová, para irritarle. [^6] A más de esto puso una imagen de fundición, que hizo, en la casa de Dios, de la cual había dicho Dios á David y á Salomón su hijo: En esta casa y en Jerusalem, la cual yo elegí sobre todas las tribus de Israel, pondré mi nombre para siempre: [^7] Y nunca más quitaré el pie de Israel de la tierra que yo entregué á vuestros padres, á condición que guarden y hagan todas las cosas que yo les he mandado, toda la ley, estatutos, y ordenanzas, por mano de Moisés. [^8] Hizo pues Manasés desviarse á Judá y á los moradores de Jerusalem, para hacer más mal que las gentes que Jehová destruyó delante de los hijos de Israel. [^9] Y habló Jehová á Manasés y á su pueblo, mas ellos no escucharon: [^10] por lo cual Jehová trajo contra ellos los generales del ejército del rey de los Asirios, los cuales aprisionaron con grillos á Manasés, y atado con cadenas lleváronlo á Babilonia. [^11] Mas luego que fué puesto en angustias, oró ante Jehová su Dios, humillado grandemente en la presencia del Dios de sus padres. [^12] Y habiendo á él orado, fué atendido; pues que oyó su oración, y volviólo á Jerusalem, á su reino. Entonces conoció Manasés que Jehová era Dios. [^13] Después de esto edificó el muro de afuera de la ciudad de David, al occidente de Gihón, en el valle, á la entrada de la puerta del pescado, y cercó á Ophel, y alzólo muy alto; y puso capitanes de ejército en todas las ciudades fuertes por Judá. [^14] Asimismo quitó los dioses ajenos, y el ídolo de la casa de Jehová, y todos los altares que había edificado en el monte de la casa de Jehová y en Jerusalem, y echólos fuera de la ciudad. [^15] Reparó luego el altar de Jehová, y sacrificó sobre él sacrificios pacíficos y de alabanza; y mandó á Judá que sirviesen á Jehová Dios de Israel. [^16] Empero el pueblo aun sacrificaba en los altos, bien que á Jehová su Dios. [^17] Lo demás de los hechos de Manasés, y su oración á su Dios, y las palabras de los videntes que le hablaron en nombre de Jehová el Dios de Israel, he aquí todo está escrito en los hechos de los reyes de Israel. [^18] Su oración también, y cómo fué oído, todos sus pecados, y su prevaricación, los lugares donde edificó altos y había puesto bosques é ídolos antes que se humillase, he aquí estas cosas están escritas en las palabras de los videntes. [^19] Y durmió Manasés con sus padres, y sepultáronlo en su casa: y reinó en su lugar Amón su hijo. [^20] De veinte y dos años era Amón cuando comenzo á reinar, y dos años reinó en Jerusalem. [^21] E hizo lo malo en ojos de Jehová, como había hecho Manasés su padre: porque á todos los ídolos que su padre Manasés había hecho, sacrificó y sirvió Amón. [^22] Mas nunca se humilló delante de Jehová, como se humilló Manasés su padre: antes aumentó el pecado. [^23] Y conspiraron contra él sus siervos, y matáronlo en su casa. [^24] Mas el pueblo de la tierra hirió á todos los que habían conspirado contra el rey Amón; y el pueblo de la tierra puso por rey en su lugar á Josías su hijo. [^25] 

[[2 Chronicles - 32|<--]] 2 Chronicles - 33 [[2 Chronicles - 34|-->]]

---
# Notes
