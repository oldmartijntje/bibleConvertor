---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 26 - Reina Valera (1602)"
---
[[2 Chronicles - 25|<--]] 2 Chronicles - 26 [[2 Chronicles - 27|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 26

ENTONCES todo el pueblo de Judá tomó á Uzzías, el cual era de diez y seis años, y pusiéronlo por rey en lugar de Amasías su padre. [^1] Edificó él á Eloth, y la restituyó á Judá después que el rey durmió con sus padres. [^2] De diez y seis años era Uzzías cuando comenzó á reinar, y cincuenta y dos años reinó en Jerusalem. El nombre de su madre fué Jechôlía, de Jerusalem. [^3] E hizo lo recto en los ojos de Jehová, conforme á todas las cosas que había hecho Amasías su padre. [^4] Y persistió en buscar á Dios en los días de Zachârías, entendido en visiones de Dios; y en estos días que él buscó á Jehová, él le prosperó. [^5] Y salió, y peleó contra los Filisteos, y rompió el muro de Gath, y el muro de Jabnia, y el muro de Asdod; y edificó ciudades en Asdod, y en la tierra de los Filisteos. [^6] Y dióle Dios ayuda contra los Filisteos, y contra los Arabes que habitaban en Gur-baal, y contra los Ammonitas. [^7] Y dieron los Ammonitas presentes á Uzzías, y divulgóse su nombre hasta la entrada de Egipto; porque se había hecho altamente poderoso. [^8] Edificó también Uzzías torres en Jerusalem, junto á la puerta del ángulo, y junto á la puerta del valle, y junto á las esquinas; y fortificólas. [^9] Asimismo edificó torres en el desierto, y abrió muchas cisternas: porque tuvo muchos ganados, así en los valles como en las vegas; y viñas, y labranzas, así en los montes como en los llanos fértiles; porque era amigo de la agricultura. [^10] Tuvo también Uzzías escuadrones de guerreros, los cuales salían á la guerra en ejército, según que estaban por lista hecha por mano de Jehiel escriba y de Maasías gobernador, y por mano de Hananías, uno de los príncipes del rey. [^11] Todo el número de los jefes de familias, valientes y esforzados, era dos mil y seiscientos. [^12] Y bajo la mano de éstos estaba el ejército de guerra, de trescientos siete mil y quinientos guerreros poderosos y fuertes para ayudar al rey contra los enemigos. [^13] Y aprestóles Uzzías para todo el ejército, escudos, lanzas, almetes, coseletes, arcos, y hondas de tirar piedras. [^14] E hizo en Jerusalem máquinas por industria de ingenieros, para que estuviesen en las torres y en los baluartes, para arrojar saetas y grandes piedras, y su fama se extendió lejos, porque se ayudó maravillosamente, hasta hacerse fuerte. [^15] Mas cuando fué fortificado, su corazón se enalteció hasta corromperse; porque se rebeló contra Jehová su Dios, entrando en el templo de Jehová para quemar sahumerios en el altar del perfume. [^16] Y entró tras él el sacerdote Azarías, y con él ochenta sacerdotes de Jehová, de los valientes. [^17] Y pusiéronse contra el rey Uzzías, y dijéronle: No á ti, oh Uzzías, el quemar perfume á Jehová, sino á los sacerdotes hijos de Aarón, que son consagrados para quemarlo: sal del santuario, por que has prevaricado, y no te será para gloria delante del Dios Jehová. [^18] Y airóse Uzzías, que tenía el perfume en la mano para quemarlo; y en esta su ira contra los sacerdotes, la lepra le salió en la frente delante de los sacerdotes en la casa de Jehová, junto al altar del perfume. [^19] Y miróle Azarías el sumo sacerdote, y todos los sacerdotes, y he aquí la lepra estaba en su frente; é hiciéronle salir apriesa de aquel lugar; y él también se dió priesa á salir, porque Jehová lo había herido. [^20] Así el rey Uzzías fué leproso hasta el día de su muerte, y habitó en una casa apartada, leproso, por lo que había sido separado de la casa de Jehová; y Joatham su hijo tuvo cargo de la casa real, gobernando al pueblo de la tierra. [^21] Lo demás de los hechos de Uzzías, primeros y postreros, escribiólo Isaías profeta, hijo de Amós. [^22] Y durmió Uzzías con sus padres, y sepultáronlo con sus padres en el campo de los sepulcros reales; porque dijeron: Leproso es. Y reinó Joatham su hijo en lugar suyo. [^23] 

[[2 Chronicles - 25|<--]] 2 Chronicles - 26 [[2 Chronicles - 27|-->]]

---
# Notes
