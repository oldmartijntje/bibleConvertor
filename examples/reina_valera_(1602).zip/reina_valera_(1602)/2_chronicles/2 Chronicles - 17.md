---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 17 - Reina Valera (1602)"
---
[[2 Chronicles - 16|<--]] 2 Chronicles - 17 [[2 Chronicles - 18|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 17

Y REINO en su lugar Josaphat su hijo, el cual prevaleció contra Israel. [^1] Y puso ejército en todas las ciudades fuertes de Judá, y colocó gente de guarnición, en tierra de Judá, y asimismo en las ciudades de Ephraim que su padre Asa había tomado. [^2] Y fué Jehová con Josaphat, porque anduvo en los primeros caminos de David su padre, y no buscó á los Baales; [^3] Sino que buscó al Dios de su padre, y anduvo en sus mandamientos, y no según las obras de Israel. [^4] Jehová por tanto confirmó el reino en su mano, y todo Judá dió á Josaphat presentes; y tuvo riquezas y gloria en abundancia. [^5] Y animóse su corazón en los caminos de Jehová, y quitó los altos y los bosques de Judá. [^6] Al tercer año de su reinado envió sus príncipes Ben-hail, Obdías, Zachârías, Nathaniel y Michêas, para que enseñasen en las ciudades de Judá; [^7] Y con ellos á los Levitas, Semeías, Nethanías, Zebadías, y Asael, y Semiramoth, y Jonathán, y Adonías, y Tobías, y Tobadonías, Levitas; y con ellos á Elisama y á Joram, sacerdotes. [^8] Y enseñaron en Judá, teniendo consigo el libro de la ley de Jehová, y rodearon por todas las ciudades de Judá enseñando al pueblo. [^9] Y cayó el pavor de Jehová sobre todos los reinos de las tierras que estaban alrededor de Judá; que no osaron hacer guerra contra Josaphat. [^10] Y traían de los Filisteos presentes á Josaphat, y tributos de plata. Los Arabes también le trajeron ganados, siete mil y setecientos carneros y siete mil y setecientos machos de cabrío. [^11] Iba pues Josaphat creciendo altamente: y edificó en Judá fortalezas y ciudades de depósitos. [^12] Tuvo además muchas obras en las ciudades de Judá, y hombres de guerra muy valientes en Jerusalem. [^13] Y este es el número de ellos según las casas de sus padres: en Judá, jefes de los millares: el general Adna, y con él trescientos mil hombres muy esforzados; [^14] Después de él, el jefe Johanán, y con él doscientos y ochenta mil; [^15] Tras éste, Amasías hijo de Zichri, el cual se había ofrecido voluntariamente á Jehová, y con él doscientos mil hombres valientes; [^16] De Benjamín, Eliada, hombre muy valeroso, y con él doscientos mil armados de arco y escudo; [^17] Tras éste, Jozabad, y con él ciento y ochenta mil apercibidos para la guerra. [^18] Estos eran siervos del rey, sin los que había el rey puesto en las ciudades de guarnición por toda Judea. [^19] 

[[2 Chronicles - 16|<--]] 2 Chronicles - 17 [[2 Chronicles - 18|-->]]

---
# Notes
