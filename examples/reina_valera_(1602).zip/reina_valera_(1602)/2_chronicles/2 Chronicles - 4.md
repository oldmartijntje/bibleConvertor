---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 4 - Reina Valera (1602)"
---
[[2 Chronicles - 3|<--]] 2 Chronicles - 4 [[2 Chronicles - 5|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 4

HIZO además un altar de bronce de veinte codos de longitud, y veinte codos de anchura, y diez codos de altura. [^1] También hizo un mar de fundición, el cual tenía diez codos del un borde al otro, enteramente redondo: su altura era de cinco codos, y una línea de treinta codos lo ceñía alrededor. [^2] Y debajo de él había figuras de bueyes que lo circundaban, diez en cada codo todo alrededor: eran dos órdenes de bueyes fundidos juntamente con el mar. [^3] Y estaba asentado sobre doce bueyes, tres de los cuales miraban al septentrión, y tres al occidente, y tres al mediodía, y tres al oriente: y el mar asentaba sobre ellos, y todas sus traseras estaban á la parte de adentro. [^4] Y tenía de grueso un palmo, y el borde era de la hechura del borde de un cáliz, ó flor de lis. Y hacía tres mil batos. [^5] Hizo también diez fuentes, y puso cinco á la derecha y cinco á la izquierda, para lavar y limpiar en ellas la obra del holocausto; mas el mar era para lavarse los sacerdotes en él. [^6] Hizo asimismo diez candeleros de oro según su forma, los cuales puso en el templo, cinco á la derecha, y cinco á la izquierda. [^7] Además hizo diez mesas y púsolas en el templo, cinco á la derecha, y cinco á la izquierda: igualmente hizo cien tazones de oro. [^8] A más de esto hizo el atrio de los sacerdotes, y el gran atrio, y las portadas del atrio, y cubrió las puertas de ellas de bronce. [^9] Y asentó el mar al lado derecho hacia el oriente, enfrente del mediodía. [^10] Hizo también Hiram calderos, y palas, y tazones; y acabó Hiram la obra que hacía al rey Salomón para la casa de Dios; [^11] Dos columnas, y los cordones, los capiteles sobre las cabezas de las dos columnas, y dos redes para cubrir las dos bolas de los capiteles que estaban encima de las columnas; [^12] Cuatrocientas granadas en las dos redecillas, dos órdenes de granadas en cada redecilla, para que cubriesen las dos bolas de los capiteles que estaban encima de las columnas. [^13] Hizo también las basas, sobre las cuales asentó las fuentes; [^14] Un mar, y doce bueyes debajo de él: [^15] Y calderos, y palas, y garfios; y todos sus enseres hizo Hiram su padre al rey Salomón para la casa de Jehová, de metal purísimo. [^16] Y fundiólos el rey en los llanos del Jordán, en tierra arcillosa, entre Suchôt y Seredat. [^17] Y Salomón hizo todos estos vasos en grande abundancia, porque no pudo ser hallado el peso del metal. [^18] Así hizo Salomón todos los vasos para la casa de Dios, y el altar de oro, y las mesas sobre las cuales se ponían los panes de la proposición; [^19] Asimismo los candeleros y sus candilejas, de oro puro, para que las encendiesen delante del oratorio conforme á la costumbre. [^20] Y las flores, y las lamparillas, y las despabiladeras se hicieron de oro, de oro perfecto; [^21] También los platillos, y las jofainas, y las cucharas, y los incensarios, de oro puro. Cuanto á la entrada de la casa, sus puertas interiores para el lugar santísimo, y las puertas de la casa del templo, de oro. [^22] 

[[2 Chronicles - 3|<--]] 2 Chronicles - 4 [[2 Chronicles - 5|-->]]

---
# Notes
