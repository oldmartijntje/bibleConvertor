---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 15 - Reina Valera (1602)"
---
[[2 Chronicles - 14|<--]] 2 Chronicles - 15 [[2 Chronicles - 16|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 15

Y FUÉ el espíritu de Dios sobre Azarías hijo de Obed; [^1] Y salió al encuentro á Asa, y díjole: Oidme, Asa, y todo Judá y Benjamín: Jehová es con vosotros, si vosotros fueres con él: y si le buscareis, será hallado de vosotros; mas si le dejareis, él también os dejará. [^2] Muchos días ha estado Israel sin verdadero Dios y sin sacerdote, y sin enseñador y sin ley: [^3] Mas cuando en su tribulación se convirtieron á Jehová Dios de Israel, y le buscaron, él fué hallado de ellos. [^4] En aquellos tiempos no hubo paz, ni para el que entraba, ni para el que salía, sino muchas aflicciones sobre todos los habitadores de las tierras. [^5] Y la una gente destruía á la otra, y una ciudad á otra ciudad: porque Dios los conturbó con todas calamidades. [^6] Esforzaos empero vosotros, y no desfallezcan vuestras manos; que salario hay para vuestra obra. [^7] Y como oyó Asa las palabras y profecía de Obed profeta, fué confortado, y quitó las abominaciones de toda la tierra de Judá y de Benjamín, y de las ciudades que él había tomado en el monte de Ephraim; y reparó el altar de Jehová que estaba delante del pórtico de Jehová. [^8] Después hizo juntar á todo Judá y Benjamín, y con ellos los extranjeros de Ephraim, y de Manasés, y de Simeón: porque muchos de Israel se habían pasado á él, viendo que Jehová su Dios era con él. [^9] Juntáronse pues en Jerusalem en el mes tercero del año décimoquinto del reinado de Asa. [^10] Y en aquel mismo día sacrificaron á Jehová, de los despojos que habían traído, setecientos bueyes y siete mil ovejas. [^11] Y entraron en concierto de que buscarían á Jehová el Dios de sus padres, de todo su corazón y de toda su alma; [^12] Y que cualquiera que no buscase á Jehová el Dios de Israel, muriese, grande ó pequeño, hombre ó mujer. [^13] Y juraron á Jehová con gran voz y júbilo, á son de trompetas y de bocinas: [^14] Del cual juramento todos los de Judá se alegraron; porque de todo su corazón lo juraban, y de toda su voluntad lo buscaban: y fué hallado de ellos; y dióles Jehová reposo de todas partes. [^15] Y aun á Maachâ madre del rey Asa, él mismo la depuso de su dignidad, porque había hecho un ídolo en el bosque: y Asa deshizo su ídolo, y lo desmenuzó, y quemó en el torrente de Cedrón. [^16] Mas con todo eso los altos no eran quitados de Israel, aunque el corazón de Asa fué perfecto mientras vivió. [^17] Y metió en la casa de Dios lo que su padre había dedicado, y lo que él había consagrado, plata y oro y vasos. [^18] Y no hubo guerra hasta los treinta y cinco años del reinado de Asa. [^19] 

[[2 Chronicles - 14|<--]] 2 Chronicles - 15 [[2 Chronicles - 16|-->]]

---
# Notes
