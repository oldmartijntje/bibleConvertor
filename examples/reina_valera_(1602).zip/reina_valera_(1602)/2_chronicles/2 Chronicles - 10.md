---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 10 - Reina Valera (1602)"
---
[[2 Chronicles - 9|<--]] 2 Chronicles - 10 [[2 Chronicles - 11|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 10

Y ROBOAM fué á Sichêm porque en Sichêm se había juntado todo Israel para hacerlo rey. [^1] Y como lo oyó Jeroboam hijo de Nabat, el cual estaba en Egipto, donde había huído á causa del rey Salomón, volvió de Egipto. [^2] Y enviaron y llamáronle. Vino pues Jeroboam, y todo Israel, y hablaron á Roboam, diciendo: [^3] Tu padre agravó nuestro yugo: afloja tú, pues, ahora algo de la dura servidumbre, y del grave yugo con que tu padre nos apremió, y te serviremos. [^4] Y él les dijo: Volved á mí de aquí á tres días. Y el pueblo se fué. [^5] Entonces el rey Roboam tomó consejo con los viejos, que habían estado delante de Salomón su padre cuando vivía, y díjoles: ¿Cómo aconsejáis vosotros que responda á este pueblo? [^6] Y ellos le hablaron, diciendo: Si te condujeres humanamente con este pueblo, y los agradares, y les hablares buenas palabras, ellos te servirán perpetuamente. [^7] Mas él, dejando el consejo que le dieron los viejos, tomó consejo con los mancebos que se habían criado con él, y que delante de él asistían; [^8] Y díjoles: ¿Qué aconsejáis vosotros que respondamos á este pueblo, que me ha hablado, diciendo: Alivia algo del yugo que tu padre puso sobre nosotros? [^9] Entonces los mancebos que se habían criado con él, le hablaron, diciendo: Así dirás al pueblo que te ha hablado diciendo, Tu padre agravó nuestro yugo, mas tú descárganos: así les dirás: Lo más menudo mío es más grueso que los lomos de mi padre. [^10] Así que, mi padre os cargó de grave yugo, y yo añadiré á vuestro yugo: mi padre os castigó con azotes, y yo con escorpiones. [^11] Vino pues Jeroboam con todo el pueblo á Roboam al tercer día: según el rey les había mandado deciendo: Volved á mí de aquí á tres días. [^12] Y respondióles el rey ásperamente; pues dejó el rey Roboam el consejo de los viejos, [^13] Y hablóles conforme al consejo de los mancebos, diciendo: Mi padre agravó vuestro yugo, y yo añadiré á vuestro yugo: mi padre os castigó con azotes, y yo con escorpiones. [^14] Y no escuchó el rey al pueblo; porque la causa era de Dios, para cumplir Jehová su palabra que había hablado, por Ahías Silonita, á Jeroboam hijo de Nabat. [^15] Y viendo todo Israel que el rey no les había oído, respondió el pueblo al rey, diciendo: ¿Qué parte tenemos nosotros con David, ni herencia en el hijo de Isaí? ­Israel, cada uno á sus estancias! ­David, mira ahora por tu casa! Así se fué todo Israel á sus estancias. [^16] Mas reinó Roboam sobre los hijos de Israel que habitaban en las ciudades de Judá. [^17] Envió luego el rey Roboam á Adoram, que tenía cargo de los tributos; pero le apedrearon los hijos de Israel, y murió. Entonces se esforzó el rey Roboam, y subiendo en un carro huyó á Jerusalem. [^18] Así se apartó Israel de la casa de David hasta hoy. [^19] 

[[2 Chronicles - 9|<--]] 2 Chronicles - 10 [[2 Chronicles - 11|-->]]

---
# Notes
