---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 7 - Reina Valera (1602)"
---
[[2 Chronicles - 6|<--]] 2 Chronicles - 7 [[2 Chronicles - 8|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 7

Y COMO Salomón acabó de orar, el fuego descendió de los cielos, y consumió el holocausto y las víctimas; y la gloria de Jehová hinchió la casa. [^1] Y no podían entrar los sacerdotes en la casa de Jehová, porque la gloria de Jehová había henchido la casa de Jehová. [^2] Y como vieron todos los hijos de Israel descender el fuego y la gloria de Jehová sobre la casa, cayeron en tierra sobre sus rostros en el pavimento, y adoraron, confesando á Jehová y diciendo: Que es bueno, que su misericordia es para siempre. [^3] Entonces el rey y todo el pueblo sacrificaron víctimas delante de Jehová. [^4] Y ofreció el rey Salomón en sacrificio veinte y dos mil bueyes, y ciento y veinte mil ovejas; y así dedicaron la casa de Dios el rey y todo el pueblo. [^5] Y los sacerdotes asistían en su ministerio; y los Levitas con los instrumentos de música de Jehová, los cuales había hecho el rey David para confesar á Jehová, que su misericordia es para siempre; cuando David alababa por mano de ellos. Asimismo los sacerdotes tañían trompetas delante de ellos, y todo Israel estaba en pie. [^6] También santificó Salomón el medio del atrio que estaba delante de la casa de Jehová, por cuanto había ofrecido allí los holocaustos, y los sebos de los pacíficos; porque en el altar de bronce que Salomón había hecho, no podían caber los holocaustos, y el presente, y los sebos. [^7] Entonces hizo Salomón fiesta siete días, y con él todo Israel, una grande congregación, desde la entrada de Hamath hasta el arroyo de Egipto. [^8] Al octavo día hicieron convocación, porque habían hecho la dedicación del altar en siete días, y habían celebrado la solemnidad por siete días. [^9] Y á los veintitrés del mes séptimo envió al pueblo á sus estancias, alegres y gozosos de corazón por los beneficios que Jehová había hecho á David, y á Salomón, y á su pueblo Israel. [^10] Acabó pues Salomón la casa de Jehová, y la casa del rey: y todo lo que Salomón tuvo en voluntad de hacer en la casa de Jehová y en su casa, fué prosperado. [^11] Y apareció Jehová á Salomón de noche, y díjole: Yo he oído tu oración, y he elegido para mí este lugar por casa de sacrificio. [^12] Si yo cerrare los cielos, que no haya lluvia, y si mandare á la langosta que consuma la tierra, ó si enviare pestilencia á mi pueblo; [^13] Si se humillare mi pueblo, sobre los cuales ni nombre es invocado, y oraren, y buscaren mi rostro, y se convirtieren de sus malos caminos; entonces yo oiré desde los cielos, y perdonaré sus pecados, y sanaré su tierra. [^14] Ahora estarán abiertos mis ojos, y atentos mis oídos, á la oración en este lugar: [^15] Pues que ahora he elegido y santificado esta casa, para que esté en ella mi nombre para siempre; y mis ojos y mi corazón estarán ahí para siempre. [^16] Y tú, si anduvieres delante de mí, como anduvo David tu padre, é hicieres todas las cosas que yo te he mandado, y guardares mis estatutos y mis derechos, [^17] Yo confirmaré el trono de tu reino, como concerté con David tu padre, diciendo: No faltará varón de ti que domine en Israel. [^18] Mas si vosotros os volviereis, y dejareis mis estatutos y mis preceptos que os he propuesto, y fuereis y sirviereis á dioses ajenos, y los adorareis, [^19] Yo los arrancaré de mi tierra que les he dado; y esta casa que he santificado á mi nombre, yo la echaré de delante de mí, y pondréla por proverbio y fábula en todos los pueblos. [^20] Y esta casa que habrá sido ilustre, será espanto á todo el que pasare, y dirá: ¿Por qué ha hecho así Jehová á esta tierra y á esta casa? [^21] Y se responderá: Por cuanto dejaron á Jehová Dios de sus padres, el cual los sacó de la tierra de Egipto, y han abrazado dioses ajenos, y los adoraron y sirvieron: por eso él ha traído todo este mal sobre ellos. [^22] 

[[2 Chronicles - 6|<--]] 2 Chronicles - 7 [[2 Chronicles - 8|-->]]

---
# Notes
