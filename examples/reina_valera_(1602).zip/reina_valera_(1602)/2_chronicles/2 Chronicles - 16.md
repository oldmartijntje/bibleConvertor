---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 16 - Reina Valera (1602)"
---
[[2 Chronicles - 15|<--]] 2 Chronicles - 16 [[2 Chronicles - 17|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 16

EN el año treinta y seis del reinado de Asa, subió Baasa rey de Israel contra Judá, y edificó á Rama, para no dejar salir ni entrar á ninguno al rey Asa, rey de Judá. [^1] Entonces sacó Asa la plata y el oro de los tesoros de la casa de Jehová y de la casa real, y envió á Ben-adad rey de Siria, que estaba en Damasco, diciendo: [^2] Haya alianza entre mí y ti, como la hubo entre mi padre y tu padre; he aquí yo te he enviado plata y oro, para que vengas y deshagas la alianza que tienes con Baasa rey de Israel, á fin de que se retire de mí. [^3] Y consintió Ben-adad con el rey Asa, y envió los capitanes de sus ejércitos á la ciudades de Israel: y batieron á Ion, Dan, y Abel-maim, y las ciudades fuertes de Nephtalí. [^4] Y oyendo esto Baasa, cesó de edificar á Rama, y dejó su obra. [^5] Entonces el rey Asa tomó á todo Judá, y lleváronse de Rama la piedra y madera con que Baasa edificaba, y con ella edificó á Gibaa y Mizpa. [^6] En aquel tiempo vino Hanani vidente á Asa rey de Judá, y díjole: Por cuanto te has apoyado en el rey de Siria, y no te apoyaste en Jehová tu Dios, por eso el ejército del rey de Siria ha escapado de tus manos. [^7] Los Etiopes y los Libios, ¿no eran un ejército numerosísimo, con carros y muy mucha gente de á caballo? con todo, porque te apoyaste en Jehová, él los entregó en tus manos. [^8] Porque los ojos de Jehová contemplan toda la tierra, para corroborar á los que tienen corazón perfecto para con él. Locamente has hecho en esto; porque de aquí adelante habrá guerra contra ti. [^9] Y enojado Asa contra el vidente, echólo en la casa de la cárcel, porque fué en extremo conmovido á causa de esto. Y oprimió Asa en aquel tiempo algunos del pueblo. [^10] Mas he aquí, los hechos de Asa, primeros y postreros, están escritos en el libro de los reyes de Judá y de Israel. [^11] Y el año treinta y nueve de su reinado enfermó Asa de los pies para arriba, y en su enfermedad no buscó á Jehová, sino á los médicos. [^12] Y durmió Asa con sus padres, y murió en el año cuarenta y uno de su reinado. [^13] Y sepultáronlo en sus sepulcros que él había hecho para sí en la ciudad de David; [^14] 

[[2 Chronicles - 15|<--]] 2 Chronicles - 16 [[2 Chronicles - 17|-->]]

---
# Notes
