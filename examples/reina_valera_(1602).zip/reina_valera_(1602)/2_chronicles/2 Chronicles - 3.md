---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 3 - Reina Valera (1602)"
---
[[2 Chronicles - 2|<--]] 2 Chronicles - 3 [[2 Chronicles - 4|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 3

Y COMENZO Salomón á edificar la casa en Jerusalem, en el monte Moria que había sido mostrado á David su padre, en el lugar que David había preparado en la era de Ornán Jebuseo. [^1] Y comenzó á edificar en el mes segundo, á dos del mes, en el cuarto año de su reinado. [^2] Estas son las medidas de que Salomón fundó el edificio de la casa de Dios. La primera medida fué, la longitud de sesenta codos; y la anchura de veinte codos. [^3] El pórtico que estaba en la delantera de la longitud, era de veinte codos al frente del ancho de la casa, y su altura de ciento y veinte: y cubriólo por dentro de oro puro. [^4] Y techó la casa mayor con madera de haya, la cual cubrió de buen oro, é hizo resaltar sobre ella palmas y cadenas. [^5] Cubrió también la casa de piedras preciosas por excelencia: y el oro era oro de Parvaim. [^6] Así cubrió la casa, sus vigas, sus umbrales, sus paredes, y sus puertas, con oro; y esculpió querubines por las paredes. [^7] Hizo asimismo la casa del lugar santísimo, cuya longitud era de veinte codos según el ancho del frente de la casa, y su anchura de veinte codos: y cubrióla de buen oro que ascendía á seiscientos talentos. [^8] Y el peso de los clavos tuvo cincuenta siclos de oro. Cubrió también de oro las salas. [^9] Y dentro del lugar santísimo hizo dos querubines de forma de niños, los cuales cubrieron de oro. [^10] El largo de las alas de los querubines era de veinte codos: porque la una ala era de cinco codos: la cual llegaba hasta la pared de la casa; y la otra ala de cinco codos, la cual llegaba al ala del otro querubín. [^11] De la misma manera la una ala del otro querubín era de cinco codos: la cual llegaba hasta la pared de la casa; y la otra ala era de cinco codos, que tocaba al ala del otro querubín. [^12] Así las alas de estos querubines estaban extendidas por veinte codos: y ellos estaban en pie con los rostros hacia la casa. [^13] Hizo también el velo de cárdeno, púrpura, carmesí y lino, é hizo resaltar en él querubines. [^14] Delante de la casa hizo dos columnas de treinta y cinco codos de longitud, con sus capiteles encima, de cinco codos. [^15] Hizo asimismo cadenas en el oratorio, y púsolas sobre los capiteles de las columnas: é hizo cien granadas, las cuales puso en las cadenas. [^16] Y asentó las columnas delante del templo, la una á la mano derecha, y la otra á la izquierda; y á la de la mano derecha llamó Jachîn, y á la de la izquierda, Boaz. [^17] 

[[2 Chronicles - 2|<--]] 2 Chronicles - 3 [[2 Chronicles - 4|-->]]

---
# Notes
