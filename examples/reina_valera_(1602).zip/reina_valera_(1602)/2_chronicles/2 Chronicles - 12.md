---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 12 - Reina Valera (1602)"
---
[[2 Chronicles - 11|<--]] 2 Chronicles - 12 [[2 Chronicles - 13|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 12

Y COMO Roboam hubo confirmado el reino, dejó la ley de Jehová, y con él todo Israel. [^1] Y en el quinto año del rey Roboam subió Sisac rey de Egipto contra Jerusalem, (por cuanto se habían rebelado contra Jehová,) [^2] Con mil y doscientos carros, y con sesenta mil hombres de á caballo: mas el pueblo que venía con él de Egipto, no tenía número; á saber, de Libios, Sukienos, y Etiopes. [^3] Y tomó las ciudades fuertes de Judá, y llegó hasta Jerusalem. [^4] Entonces vino Semeías profeta á Roboam y á los príncipes de Judá, que estaban reunidos en Jerusalem por causa de Sisac, y díjoles: Así ha dicho Jehová: Vosotros me habéis dejado, y yo también os he dejado en manos de Sisac. [^5] Y los príncipes de Israel y el rey se humillaron, y dijeron: Justo es Jehová. [^6] Y como vió Jehová que se habían humillado, fué palabra de Jehová á Semeías, diciendo: Hanse humillado; no los destruiré; antes los salvare en breve, y no se derramará mi ira contra Jerusalem por mano de Sisac. [^7] Empero serán sus siervos; para que sepan qué es servirme á mí, y servir á los reinos de las naciones. [^8] Subió pues Sisac rey de Egipto á Jerusalem, y tomó los tesoros de la casa de Jehová, y los tesoros de la casa del rey; todo lo llevó: y tomó los paveses de oro que Salomón había hecho. [^9] Y en lugar de ellos hizo el rey Roboam paveses de metal, y entrególos en manos de los jefes de la guardia, los cuales custodiaban la entrada de la casa del rey. [^10] Y cuando el rey iba á la casa de Jehová, venían los de la guardia, y traíanlos, y después los volvían á la cámara de la guardia. [^11] Y como él se humilló, la ira de Jehová se apartó de él, para no destruirlo del todo: y también en Judá las cosas fueron bien. [^12] Fortificado pues Roboam, reinó en Jerusalem: y era Roboam de cuarenta y un años cuando comenzó á reinar, y diecisiete años reinó en Jerusalem, ciudad que escogió Jehová de todas las tribus de Israel, para poner en ella su nombre. Y el nombre de su madre fué Naama Ammonita. [^13] E hizo lo malo, porque no apercibió su corazón para buscar á Jehová. [^14] Y las cosas de Roboam, primeras y postreras, ¿no están escritas en los libros de Semeías profeta y de Iddo vidente, en la cuenta de los linajes? Y entre Roboam y Jeroboam hubo perpetua guerra. [^15] Y durmió Roboam con sus padres, y fué sepultado en la ciudad de David: y reinó en su lugar Abías su hijo. [^16] 

[[2 Chronicles - 11|<--]] 2 Chronicles - 12 [[2 Chronicles - 13|-->]]

---
# Notes
