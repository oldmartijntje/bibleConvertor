---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 5 - Reina Valera (1602)"
---
[[2 Chronicles - 4|<--]] 2 Chronicles - 5 [[2 Chronicles - 6|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 5

Y ACABADA que fué toda la obra que hizo Salomón para la casa de Jehová, metió Salomón en ella las cosas que David su padre había dedicado; y puso la plata, y el oro, y todos los vasos, en los tesoros de la casa de Dios. [^1] Entonces Salomón juntó en Jerusalem los ancianos de Israel, y todos los príncipes de las tribus, los cabezas de las familias de los hijos de Israel, para que trajesen el arca del pacto de Jehová de la ciudad de David, que es Sión. [^2] Y juntáronse al rey todos los varones de Israel, á la solemnidad del mes séptimo. [^3] Y vinieron todos los ancianos de Israel, y tomaron los Levitas el arca: [^4] Y llevaron el arca, y el tabernáculo del testimonio, y todos los vasos del santuario que estaban en el tabernáculo: los sacerdotes y los Levitas los llevaron. [^5] Y el rey Salomón, y toda la congregación de Israel que se había á él reunido delante del arca, sacrificaron ovejas y bueyes, que por la multitud no se pudieron contar ni numerar. [^6] Y los sacerdotes metieron el arca del pacto de Jehová en su lugar, en el oratorio de la casa, en el lugar santísimo, bajo las alas de los querubines: [^7] Pues los querubines extendían las alas sobre el asiento del arca, y cubrían los querubines por encima así el arca como sus barras. [^8] E hicieron salir fuera las barras, de modo que se viesen las cabezas de las barras del arca delante del oratorio, mas no se veían desde fuera: y allí estuvieron hasta hoy. [^9] En el arca no había sino las dos tablas que Moisés había puesto en Horeb, con las cuales Jehová había hecho alianza con los hijos de Israel, después que salieron de Egipto. [^10] Y como los sacerdotes salieron del santuario, (porque todos los sacerdotes que se hallaron habían sido santificados, y no guardaban sus veces; [^11] Y los Levitas cantores, todos los de Asaph, los de Hemán, y los de Jeduthún, juntamente con sus hijos y sus hermanos, vestidos de lino fino, estaban con címbalos y salterios y arpas al oriente del altar; y con ellos ciento veinte sacerdotes que tocaban trompetas:) [^12] Sonaban pues las trompetas, y cantaban con la voz todos á una, para alabar y confesar á Jehová: y cuando alzaban la voz con trompetas y címbalos é instrumentos de música, cuando alababan á Jehová, diciendo: Porque es bueno, porque su misericordia es para siempre: la casa se llenó entonces de una nube, la casa de Jehová. [^13] Y no podían los sacerdotes estar para ministrar, por causa de la nube; porque la gloria de Jehová había henchido la casa de Dios. [^14] 

[[2 Chronicles - 4|<--]] 2 Chronicles - 5 [[2 Chronicles - 6|-->]]

---
# Notes
