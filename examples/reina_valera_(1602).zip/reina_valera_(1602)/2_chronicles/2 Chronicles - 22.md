---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 22 - Reina Valera (1602)"
---
[[2 Chronicles - 21|<--]] 2 Chronicles - 22 [[2 Chronicles - 23|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 22

Y LOS moradores de Jerusalem hicieron rey en lugar suyo á Ochôzías su hijo menor: porque la tropa había venido con los Arabes al campo, había muerto á todos los mayores; por lo cual reinó Ochôzías, hijo de Joram rey de Judá. [^1] Cuando Ochôzías comenzó á reinar era de cuarenta y dos años, y reinó un año en Jerusalem. El nombre de su madre fué Athalía, hija de Omri. [^2] También él anduvo en los caminos de la casa de Achâb: porque su madre le aconsejaba á obrar impíamente. [^3] Hizo pues lo malo en ojos de Jehová, como la casa de Achâb; porque después de la muerte de su padre, ellos le aconsejaron para su perdición. [^4] Y él anduvo en los consejos de ellos, y fué á la guerra con Joram hijo de Achâb, rey de Israel, contra Hazael rey de Siria, á Ramoth de Galaad, donde los Siros hirieron á Joram. [^5] Y se volvió para curarse en Jezreel de las heridas que le habían hecho en Rama, peleando con Hazael rey de Siria. Y descendió Azarías hijo de Joram, rey de Judá, á visitar á Joram hijo de Achâb, en Jezreel, porque allí estaba enfermo. [^6] Esto empero venía de Dios, para que Ochôzías fuese hollado viniendo á Joram: porque siendo venido, salió con Joram contra Jehú hijo de Nimsi, al cual Jehová había ungido para que talase la casa de Achâb. [^7] Y fué que, haciendo juicio Jehú con la casa de Achâb, halló á los príncipes de Judá, y á los hijos de los hermanos de Ochôzías, que servían á Ochôzías, y matólos. [^8] Y buscando á Ochôzías, el cual se había escondido en Samaria, tomáronlo, y trajéronlo á Jehú, y le mataron; y diéronle sepultura, porque dijeron: Es hijo de Josaphat, el cual buscó á Jehová de todo su corazón. Y la casa de Ochôzías no tenía fuerzas para poder retener el reino. [^9] Entonces Athalía madre de Ochôzías, viendo que su hijo era muerto, levantóse y destruyó toda la simiente real de la casa de Judá. [^10] Empero Josabeth, hija del rey, tomó á Joas hijo de Ochôzías, y arrebatólo de entre los hijos del rey, que mataban, y guardóle á él y á su ama en la cámara de los lechos. Así pues lo escondió Josabeth, hija del rey Joram, mujer de Joiada el sacerdote, (porque ella era hermana de Ochôzías), de delante de Athalía, y no lo mataron. [^11] Y estuvo con ellos escondido en la casa de Dios seis años. Entre tanto Athalía reinaba en el país. [^12] 

[[2 Chronicles - 21|<--]] 2 Chronicles - 22 [[2 Chronicles - 23|-->]]

---
# Notes
