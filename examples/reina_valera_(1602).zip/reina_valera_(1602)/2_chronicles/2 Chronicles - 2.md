---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 2 - Reina Valera (1602)"
---
[[2 Chronicles - 1|<--]] 2 Chronicles - 2 [[2 Chronicles - 3|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 2

DETERMINO pues Salomón edificar casa al nombre de Jehová, y otra casa para su reino. [^1] Y contó Salomón setenta mil hombres que llevasen cargas, y ochenta mil hombres que cortasen en el monte, y tres mil y seiscientos que los gobernasen. [^2] Y envió á decir Salomón á Hiram rey de Tiro: Haz conmigo como hiciste con David mi padre, enviándole cedros para que edificara para sí casa en que morase. [^3] He aquí yo tengo que edificar casa al nombre de Jehová mi Dios, para consagrársela, para quemar perfumes aromáticos delante de él, y para la colocación continua de los panes de la proposición, y para holocaustos á mañana y tarde, y los sábados, y nuevas lunas, y festividades de Jehová nuestro Dios; lo cual ha de ser perpetuo en Israel. [^4] Y la casa que tengo que edificar, ha de ser grande: porque el Dios nuestro es grande sobre todos los dioses. [^5] Mas ¿quién será tan poderoso que le edifique casa? Los cielos y los cielos de los cielos no le pueden comprender; ¿quién pues soy yo, que le edifique casa, sino para quemar perfumes delante de él? [^6] Envíame pues ahora un hombre hábil, que sepa trabajar en oro, y en plata, y en metal, y en hierro, en púrpura, y en grana, y en cárdeno, y que sepa esculpir con los maestros que están conmigo en Judá y en Jerusalem, los cuales previno mi padre. [^7] Envíame también madera de cedro, de haya, de pino, del Líbano: porque yo sé que tus siervos entienden de cortar madera en el Líbano; y he aquí, mis siervos irán con los tuyos, [^8] Para que me apresten mucha madera, porque la casa que tengo de edificar ha de ser grande y portentosa. [^9] Y he aquí para los operarios tus siervos, cortadores de la madera, he dado veinte mil coros de trigo en grano, y veinte mil coros de cebada, y veinte mil batos de vino, y veinte mil batos de aceite. [^10] Entonces Hiram rey de Tiro respondió por letras, las que envió á Salomón: Porque Jehová amó á su pueblo, te ha puesto por rey sobre ellos. [^11] Y además decía Hiram: Bendito sea Jehová el Dios de Israel, que hizo los cielos y la tierra, y que dió al rey David hijo sabio, entendido, cuerdo y prudente, que edifique casa á Jehová, y casa para su reino. [^12] Yo pues te he enviado un hombre hábil y entendido, que fué de Hiram mi padre, [^13] Hijo de una mujer de las hijas de Dan, mas su padre fué de Tiro; el cual sabe trabajar en oro, y plata, y metal, y hierro, en piedra y en madera, en púrpura, y en cárdeno, en lino y en carmesí; asimismo para esculpir todas figuras, y sacar toda suerte de diseño que se le propusiere, y estar con tus hombres peritos, y con los de mi señor David tu padre. [^14] Ahora pues, enviará mi señor á sus siervos el trigo y cebada, y aceite y vino, que ha dicho; [^15] Y nosotros cortaremos en el Líbano la madera que hubieres menester, y te la traeremos en balsas por la mar hasta Joppe, y tú la harás llevar hasta Jerusalem. [^16] Y contó Salomón todos los hombres extranjeros que estaban en la tierra de Israel, después de haberlos ya contado David su padre, y fueron hallados ciento cincuenta y tres mil seiscientos. [^17] Y señaló de ellos setenta mil para llevar cargas, y ochenta mil que cortasen en el monte, y tres mil y seiscientos por sobrestantes para hacer trabajar al pueblo. [^18] 

[[2 Chronicles - 1|<--]] 2 Chronicles - 2 [[2 Chronicles - 3|-->]]

---
# Notes
