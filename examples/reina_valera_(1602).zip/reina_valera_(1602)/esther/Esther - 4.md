---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 4 - Reina Valera (1602)"
---
[[Esther - 3|<--]] Esther - 4 [[Esther - 5|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Esther]]

# Esther - 4

LUEGO que supo Mardochêo todo lo que se había hecho, rasgó sus vestidos, y vistióse de saco y de ceniza, y fuése por medio de la ciudad clamando con grande y amargo clamor. [^1] Y vino hasta delante de la puerta del rey: porque no era lícito pasar adentro de la puerta del rey con vestido de saco. [^2] Y en cada provincia y lugar donde el mandamiento del rey y su decreto llegaba, tenían los Judíos grande luto, y ayuno, y lloro, y lamentación: saco y ceniza era la cama de muchos. [^3] Y vinieron las doncellas de Esther y sus eunucos, y dijéronselo: y la reina tuvo gran dolor, y envió vestidos para hacer vestir á Mardochêo, y hacerle quitar el saco de sobre él; mas él no los recibió. [^4] Entonces Esther llamó á Atach, uno de los eunucos del rey, que él había hecho estar delante de ella, y mandólo á Mardochêo, con orden de saber qué era aquello, y por qué. [^5] Salió pues Atach á Mardochêo, á la plaza de la ciudad que estaba delante de la puerta del rey. [^6] Y Mardochêo le declaró todo lo que le había acontecido, y dióle noticia de la plata que Amán había dicho que pesaría para los tesoros del rey por razón de los Judíos, para destruirlos. [^7] Dióle también la copia de la escritura del decreto que había sido dado en Susán para que fuesen destruídos, á fin de que la mostrara á Esther y se lo declarase, y le encargara que fuese al rey á suplicarle, y á pedir delante de él por su pueblo. [^8] Y vino Atach, y contó á Esther las palabra de Mardochêo. [^9] Entonces Esther dijo á Atach, y mandóle decir á Mardochêo: [^10] Todos los siervos del rey, y el pueblo de las provincias del rey saben, que cualquier hombre ó mujer que entra al rey al patio de adentro sin ser llamado, por una sola ley ha de morir: salvo aquel á quien el rey extendiere el cetro de oro, el cual vivirá: y yo no he sido llamada para entrar al rey estos treinta días. [^11] Y dijeron á Mardochêo las palabras de Esther. [^12] Entonces dijo Mardochêo que respondiesen á Esther: No pienses en tu alma, que escaparás en la casa del rey más que todos los Judíos: [^13] Porque si absolutamente callares en este tiempo, respiro y libertación tendrán los Judíos de otra parte; mas tú y la casa de tu padre pereceréis. ¿Y quién sabe si para esta hora te han hecho llegar al reino? [^14] Y Esther dijo que respondiesen á Mardochêo: [^15] Ve, y junta á todos los Judíos que se hallan en Susán, y ayunad por mí, y no comáis ni bebáis en tres días, noche ni día: yo también con mis doncellas ayunaré igualmente, y así entraré al rey, aunque no sea conforme á la ley; y si perezco, que perezca. [^16] Entonces se fué Mardochêo, é hizo conforme á todo lo que le mandó Esther. [^17] 

[[Esther - 3|<--]] Esther - 4 [[Esther - 5|-->]]

---
# Notes
