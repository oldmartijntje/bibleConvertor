---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 10 - Reina Valera (1602)"
---
[[Esther - 9|<--]] Esther - 10

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Esther]]

# Esther - 10

Y EL rey Assuero impuso tributo sobre la tierra y las islas de la mar. [^1] Y toda la obra de su fortaleza, y de su valor, y la declaración de la grandeza de Mardochêo, con que el rey le engrandeció, ¿no está escrito en el libro de los anales de los reyes de Media y de Persia? [^2] Porque Mardochêo Judío fué segundo después del rey Assuero, y grande entre los Judíos, y acepto á la multitud de sus hermanos, procurando el bien de su pueblo, y hablando paz para toda su simiente. [^3] 

[[Esther - 9|<--]] Esther - 10

---
# Notes
