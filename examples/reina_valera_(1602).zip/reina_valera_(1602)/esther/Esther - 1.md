---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 1 - Reina Valera (1602)"
---
Esther - 1 [[Esther - 2|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Esther]]

# Esther - 1

Y ACONTECIO en los días de Assuero, (el Assuero que reinó desde la India hasta la Etiopía sobre ciento veinte y siete provincias,) [^1] Que en aquellos días, asentado que fué el rey Assuero en la silla de su reino, la cual estaba en Susán capital del reino, [^2] En el tercer año de su reinado hizo banquete á todos sus príncipes y siervos, teniendo delante de él la fuerza de Persia y de Media, gobernadores y príncipes de provincias, [^3] Para mostrar él las riquezas de la gloria de su reino, y el lustre de la magnificencia de su poder, por muchos días, ciento y ochenta días. [^4] Y cumplidos estos días, hizo el rey banquete por siete días en el patio del huerto del palacio real á todo el pueblo, desde el mayor hasta el menor que se halló en Susán capital del reino. [^5] El pabellón era de blanco, verde, y cárdeno, tendido sobre cuerdas de lino y púrpura en sortijas de plata y columnas de mármol: los reclinatorios de oro y de plata, sobre losado de pórfido y de mármol, y de alabastro y de jacinto. [^6] Y daban á beber en vasos de oro, y vasos diferentes unos de otros, y mucho vino real, conforme á la facultad del rey. [^7] Y la bebida fué según esta ley: Que nadie constriñese; porque así lo había mandado el rey á todos los mayordomos de su casa; que se hiciese según la voluntad de cada uno. [^8] Asimismo la reina Vasthi hizo banquete de mujeres, en la casa real del rey Assuero. [^9] El séptimo día, estando el corazón del rey alegre del vino, mandó á Mehumán, y á Biztha, y á Harbona, y á Bighta, y á Abagtha, y á Zetar, y á Carcas, siete eunucos que servían delante del rey Assuero, [^10] Que trajesen á la reina Vasthi delante del rey con la corona regia, para mostrar á los pueblos y á los príncipes su hermosura; porque era linda de aspecto. [^11] Mas la reina Vasthi no quiso comparecer á la orden del rey, enviada por mano de los eunucos; y enojóse el rey muy mucho, y encendióse en él su ira. [^12] Preguntó entonces el rey á los sabios que sabían los tiempos, (porque así era la costubre del rey para con todos los que sabían la ley y el derecho; [^13] Y estaban junto á él, Carsena, y Sethar, y Admatha, y Tharsis, y Meres, y Marsena, y Memucán, siete príncipes de Persia y de Media que veían la cara del rey, y se sentaban los primeros del reino:) [^14] Qué se había de hacer según la ley con la reina Vasthi, por cuanto no había cumplido la orden del rey Assuero, enviada por mano de los eunucos. [^15] Y dijo Memucán delante del rey y de los príncipes: No solamente contra el rey ha pecado la reina Vasthi, sino contra todos los príncipes, y contra todos los pueblos que hay en todas las provincias del rey Assuero. [^16] Porque este hecho de la reina pasará á noticia de todas las mujeres, para hacerles tener en poca estima á sus maridos, diciendo: El rey Assuero mandó traer delante de sí á la reina Vasthi, y ella no vino. [^17] Y entonces dirán esto las señoras de Persia y de Media que oyeren el hecho de la reina, á todos los príncipes del rey: y habrá mucho menosprecio y enojo. [^18] Si parece bien al rey, salga mandamiento real delante de él, y escríbase entre las leyes de Persia y de Media, y no sea traspasado: Que no venga más Vasthi delante del rey Assuero: y dé el rey su reino á su compañera que sea mejor que ella. [^19] Y el mandamiento que hará el rey será oído en todo su reino, aunque es grande, y todas las mujeres darán honra á sus maridos, desde el mayor hasta el menor. [^20] Y plugo esta palabra en ojos del rey y de los príncipes, é hizo el rey conforme al dicho de Memucán; [^21] Pues envió letras á todas la provincias del rey, á cada provincia conforme á su escribir, y á cada pueblo conforme á su lenguaje, diciendo que todo hombre fuese señor en su casa; y háblese esto según la lengua de su pueblo. [^22] 

Esther - 1 [[Esther - 2|-->]]

---
# Notes
