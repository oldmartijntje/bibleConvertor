---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 7 - Reina Valera (1602)"
---
[[Esther - 6|<--]] Esther - 7 [[Esther - 8|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Esther]]

# Esther - 7

VINO pues el rey con Amán á beber con la reina Esther. [^1] Y también el segundo día dijo el rey á Esther en el convite del vino: ¿Cuál es tu petición, reina Esther, y se te concederá? ¿Cuál es pues tu demanda? Aunque sea la mitad del reino, pondráse por obra. [^2] Entonces la reina Esther respondió y dijo: Oh rey, si he hallado gracia en tus ojos, y si al rey place, séame dada mi vida por mi petición, y mi pueblo por mi demanda. [^3] Porque vendidos estamos yo y mi pueblo, para ser destruídos, para ser muertos y exterminados. Y si para siervos y siervas fuéramos vendidos, callárame, bien que el enemigo no compensara el daño del rey. [^4] Y respondió el rey Assuero, y dijo á la reina Esther: ¿Quién es, y dónde está, aquél á quien ha henchido su corazón para obrar así? [^5] Y Esther dijo: El enemigo y adversario es este malvado Amán. Entonces se turbó Amán delante del rey y de la reina. [^6] Levantóse luego el rey del banquete del vino en su furor, y se fué al huerto del palacio: y quedóse Amán para procurar de la reina Esther por su vida; porque vió que estaba resuelto para él el mal de parte del rey. [^7] Volvió después el rey del huerto del palacio al aposento del banquete del vino, y Amán había caído sobre el lecho en que estaba Esther. Entonces dijo el rey: ¿También para forzar la reina, estando conmigo en casa? Como esta palabra salió de la boca del rey, el rostro de Amán fué cubierto. [^8] Y dijo Harbona, uno de los eunucos de delante del rey: He aquí también la horca de cincuenta codos de altura que hizo Amán para Mardochêo, el cual había hablado bien por el rey, está en casa de Amán. Entonces el rey dijo: Colgadlo en ella. [^9] Así colgaron á Amán en la horca que él había hecho aparejar para Mardochêo; y apaciguóse la ira del rey. [^10] 

[[Esther - 6|<--]] Esther - 7 [[Esther - 8|-->]]

---
# Notes
