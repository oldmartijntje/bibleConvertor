---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 3 - Reina Valera (1602)"
---
[[Esther - 2|<--]] Esther - 3 [[Esther - 4|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Esther]]

# Esther - 3

DESPUÉS de estas cosas, el rey Assuero engrandeció á Amán hijo de Amadatha Agageo, y ensalzólo, y puso su silla sobre todos los príncipes que estaban con él. [^1] Y todos los siervos del rey que estaban á la puerta del rey, se arrodillaban é inclinaban á Amán, porque así se lo había mandado el rey; pero Mardochêo, ni se orrodillaba ni se humillaba. [^2] Y los siervos del rey que estaban á la puerta, dijeron á Mardochêo: ¿Por qué traspasas el mandamiento del rey? [^3] Y aconteció que, hablándole cada día de esta manera, y no escuchándolos él, denunciáronlo á Amán, por ver si las palabras de Mardochêo se mantendrían; porque ya él les había declarado que era Judío. [^4] Y vió Amán que Mardochêo ni se arrodillaba ni se humillaba delante de él; y llenóse de ira. [^5] Mas tuvo en poco meter mano en solo Mardochêo; que ya le había declarado el pueblo de Mardochêo: y procuró Amán destruir á todos los Judíos que había en el reino de Assuero, al pueblo de Mardochêo. [^6] En el mes primero, que es el mes de Nisán, en el año duodécimo del rey Assuero, fué echada Pur, esto es, la suerte, delante de Amán, de día en día y de mes en mes; y salió el mes duodécimo, que es el mes de Adar. [^7] Y dijo Amán al rey Assuero: Hay un pueblo esparcido y dividido entre los pueblos en todas las provincias de tu reino, y sus leyes son diferentes de las de todo pueblo, y no observan las leyes del rey; y al rey no viene provecho de dejarlos. [^8] Si place al rey, escríbase que sean destruídos; y yo pesaré diez mil talentos de plata en manos de los que manejan la hacienda, para que sean traídos á los tesoros del rey. [^9] Entonces el rey quitó su anillo de su mano, y diólo á Amán hijo de Amadatha Agageo, enemigo de los Judíos, [^10] Y díjole: La plata propuesta sea para ti, y asimismo el pueblo, para que hagas de él lo que bien te pareciere. [^11] Entonces fueron llamados los escribanos del rey en el mes primero, á trece del mismo, y fué escrito conforme á todo lo que mandó Amán, á los príncipes del rey, y á los capitanes que estaban sobre cada provincia, y á los príncipes de cada pueblo, á cada provincia según su escritura, y á cada pueblo según su lengua: en nombre del rey Assuero fué escrito, y signado con el anillo del rey. [^12] Y fueron enviadas letras por mano de los correos á todas las provincias del rey, para destruir, y matar, y exterminar á todos los Judíos, desde el niño hasta el viejo, niños y mujeres en un día, en el trece del mes duodécimo, que es el mes de Adar, y para apoderarse de su despojo. [^13] La copia del escrito que se diese por mandamiento en cada provincia, fué publicada á todos los pueblos, á fin de que estuviesen apercibidos para aquel día. [^14] Y salieron los correos de priesa por mandato del rey, y el edicto fué dado en Susán capital del reino. Y el rey y Amán estaban sentados á beber, y la ciudad de Susán estaba conmovida. [^15] 

[[Esther - 2|<--]] Esther - 3 [[Esther - 4|-->]]

---
# Notes
