---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 6 - Reina Valera (1602)"
---
[[Esther - 5|<--]] Esther - 6 [[Esther - 7|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Esther]]

# Esther - 6

AQUELLA noche se le fué el sueño al rey, y dijo que le trajesen el libro de las memorias de las cosas de los tiempos: y leyéronlas delante del rey. [^1] Y hallóse escrito que Mardochêo había denunciado de Bigthan y de Teres, dos eunucos del rey, de la guarda de la puerta, que habían procurado meter mano en el rey Assuero. [^2] Y dijo el rey: ¿Qué honra ó que distinción se hizo á Mardochêo por esto? Y respondieron los servidores del rey, sus oficiales: Nada se ha hecho con él. [^3] Entonces dijo el rey: ¿Quién está en el patio? Y Amán había venido al patio de afuera de la casa del rey, para decir al rey que hiciese colgar á Mardochêo en la horca que él le tenía preparada. [^4] Y los servidores del rey le respondieron: He aquí Amán está en el patio. Y el rey dijo: Entre. [^5] Entró pues Amán, y el rey le dijo: ¿Qué se hará al hombre cuya honra desea el rey? Y dijo Amán en su corazón: ¿A quién deseará el rey hacer honra más que á mí? [^6] Y respondió Amán al rey: Al varón cuya honra desea el rey, [^7] Traigan el vestido real de que el rey se viste, y el caballo en que el rey cabalga, y la corona real que está puesta en su cabeza; [^8] Y den el vestido y el caballo en mano de alguno de los príncipes más nobles del rey, y vistan á aquel varón cuya honra desea el rey, y llévenlo en el caballo por la plaza de la ciudad, y pregonen delante de él: Así se hará al varón cuya honra desea el rey. [^9] Entonces el rey dijo á Amán: Date priesa, toma el vestido y el caballo, como tú has dicho, y hazlo así con el judío Mardochêo, que se sienta á la puerta del rey; no omitas nada de todo lo que has dicho. [^10] Y Amán tomó el vestido y el caballo, y vistió á Mardochêo, y llevólo á caballo por la plaza de la ciudad, é hizo pregonar delante de él: Así se hará al varón cuya honra desea el rey. [^11] Después de esto Mardochêo se volvió á la puerta del rey, y Amán se fué corriendo á su casa, apesadumbrado y cubierta su cabeza. [^12] Contó luego Amán á Zeres su mujer, y á todos sus amigos, todo lo que le había acontecido: y dijéronle sus sabios, y Zeres su mujer: Si de la simiente de los Judíos es el Mardochêo, delante de quien has comenzado á caer, no lo vencerás; antes caerás por cierto delante de él. [^13] Aun estaban ellos hablando con él, cuando los eunucos del rey llegaron apresurados, para hacer venir á Amán al banquete que Esther había dispuesto. [^14] 

[[Esther - 5|<--]] Esther - 6 [[Esther - 7|-->]]

---
# Notes
