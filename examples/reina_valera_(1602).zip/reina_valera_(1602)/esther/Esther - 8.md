---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 8 - Reina Valera (1602)"
---
[[Esther - 7|<--]] Esther - 8 [[Esther - 9|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Esther]]

# Esther - 8

EL MISMO día dió el rey Assuero á la reina Esther la casa de Amán enemigo de los Judíos; y Mardochêo vino delante del rey, porque Esther le declaró lo que era respecto de ella. [^1] Y quitóse el rey su anillo que había vuelto á tomar de Aman, y diólo á Mardochêo. Y Esther puso á Mardochêo sobre la casa de Amán. [^2] Volvió luego Esther á hablar delante del rey, y echóse á sus pies, llorando y rogándole que hiciese nula la maldad de Amán Agageo, y su designio que había formado contra los Judíos. [^3] Entonces extendió el rey á Esther el cetro de oro, y Esther se levantó, y púsose en pie delante del rey. [^4] Y dijo: Si place al rey, y si he hallado gracia delante de el, y si la cosa es recta delante del rey, y agradable yo en sus ojos, sea escrito para revocar las letras del designio de Amán hijo de Amadatha Agageo, que escribió para destruir á los Judíos que están en todas las provincias del rey. [^5] Porque ¿cómo podré yo ver el mal que alcanzará á mi pueblo? ¿cómo podré yo ver la destrucción de mi nación? [^6] Y respondió el rey Assuero á la reina Esther, y á Mardochêo Judío: He aquí yo he dado á Esther la casa de Amán, y á él han colgado en la horca, por cuanto extendió su mano contra los Judíos. [^7] Escribid pues vosotros á los Judíos como bien os pareciere en el nombre del rey, y sellad lo con el anillo del rey; porque la escritura que se sella con el anillo del rey, no es para revocarla. [^8] Entonces fueron llamados los escribanos del rey en el mes tercero, que es Siván, á veintitrés del mismo; y escribióse conforme á todo lo que mandó Mardochêo, á los Judíos, y á los sátrapas, y á los capitanes, y á los príncipes de las provincias que había desde la India hasta la Ethiopía, ciento veintisiete provincias; á cada provincia según su escribir, y á cada pueblo conforme á su lengua, á los Judíos también conforme á su escritura y lengua. [^9] Y escribió en nombre del rey Assuero, y selló con el anillo del rey, y envió letras por correos de á caballo, montados en dromedarios, y en mulos hijos de yeguas; [^10] Con intimación de que el rey concedía á los Judíos que estaban en todas la ciudades, que se juntasen y estuviesen á la defensa de su vida, prontos á destruir, y matar, y acabar con todo ejército de pueblo o provincia que viniese contra ellos, aun niños y mujeres, y su despojo para presa, [^11] En un mismo día en todas las provincias del rey Assuero, en el trece del mes duodécimo, que es el mes de Adar. [^12] La copia de la escritura que había de darse por ordenanza en cada provincia, para que fuese manifiesta á todos los pueblos, decía que los Judíos estuviesen apercibidos para aquel día, para vengarse de sus enemigos. [^13] Los correos pues, cabalgando en dromedarios y en mulos, salieron apresurados y constreñidos por el mandamiento del rey: y la ley fué dada en Susán capital del reino. [^14] Y salió Mardochêo de delante del rey con vestido real de cárdeno y blanco, y una gran corona de oro, y un manto de lino y púrpura: y la ciudad de Susán se alegró y regocijó. [^15] Los Judíos tuvieron luz y alegría, y gozo y honra. [^16] Y en cada provincia y en cada ciudad donde llegó el mandamiento del rey, los Judíos tuvieron alegría y gozo, banquete y día de placer. Y muchos de los pueblos de la tierra se hacían Judíos, porque el temor de los Judíos había caído sobre ellos. [^17] 

[[Esther - 7|<--]] Esther - 8 [[Esther - 9|-->]]

---
# Notes
