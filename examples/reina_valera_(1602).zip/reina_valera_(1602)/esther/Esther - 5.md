---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 5 - Reina Valera (1602)"
---
[[Esther - 4|<--]] Esther - 5 [[Esther - 6|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Esther]]

# Esther - 5

Y ACONTECIO que al tercer día se vistió Esther su vestido real, y púsose en el patio de adentro de la casa del rey, enfrente del aposento del rey: y estaba el rey sentado en su solio regio en el aposento real, enfrente de la puerta del aposento. [^1] Y fué que, como vió á la reina Esther que estaba en el patio, ella obtuvo gracia en sus ojos; y el rey extendió á Esther el cetro de oro que tenía en la mano. Entonces se llegó Esther, y tocó la punta del cetro. [^2] Y dijo el rey: ¿Qué tienes, reina Esther? ¿y cuál es tu petición? Hasta la mitad del reino, se te dará. [^3] Y Esther dijo: Si al rey place, venga hoy el rey con Amán al banquete que le he hecho. [^4] Y respondió el rey: Daos priesa, llamad á Amán, para hacer lo que Esther ha dicho. Vino pues el rey con Amán al banquete que Esther dispuso. [^5] Y dijo el rey á Esther en el banquete del vino: ¿Cuál es tu petición, y te será otorgada? ¿Cuál es tu demanda? Aunque sea la mitad del reino, te será concedida. [^6] Entonces respondió Esther, y dijo: Mi petición y mi demanda es: [^7] Si he hallado gracia en los ojos del rey, y si place al rey otorgar mi petición y hacer mi demanda, que venga el rey con Amán al banquete que les dispondré; y mañana haré conforme á lo que el rey ha mandado. [^8] Y salió Amán aquel día contento y alegre de corazón; pero como vió á Mardochêo á la puerta del rey, que no se levantaba ni se movía de su lugar, llenóse contra Mardochêo de ira. [^9] Mas refrenóse Amán, y vino á su casa, y envió, é hizo venir sus amigos, y á Zeres su mujer. [^10] Y refirióles Amán la gloria de sus riquezas, y la multitud de sus hijos, y todas las cosas con que el rey le había engrandecido y con que le había ensalzado sobre los príncipes y siervos del rey. [^11] Y añadió Amán: También la reina Esther á ninguno hizo venir con el rey al banquete que ella dispuso, sino á mí: y aun para mañana soy convidado de ella con el rey. [^12] Mas todo esto nada me sirve cada vez que veo al judío Mardochêo sentado á la puerta del rey. [^13] Y díjole Zeres su mujer, y todos sus amigos: Hagan una horca alta de cincuenta codos, y mañana di al rey que cuelguen á Mardochêo en ella; y entra con el rey al banquete alegre. Y plugo la cosa en los ojos de Amán, é hizo preparar la horca. [^14] 

[[Esther - 4|<--]] Esther - 5 [[Esther - 6|-->]]

---
# Notes
