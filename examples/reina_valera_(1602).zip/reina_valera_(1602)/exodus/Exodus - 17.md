---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 17 - Reina Valera (1602)"
---
[[Exodus - 16|<--]] Exodus - 17 [[Exodus - 18|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Exodus]]

# Exodus - 17

Y TODA la congregación de los hijos de Israel partió del desierto de Sin, por sus jornadas, al mandamiento de Jehová, y asentaron el campo en Rephidim: y no había agua para que el pueblo bebiese. [^1] Y altercó el pueblo con Moisés, y dijeron: Danos agua que bebamos. Y Moisés les dijo: ¿Por qué altercáis conmigo? ¿por qué tentáis á Jehová? [^2] Así que el pueblo tuvo allí sed de agua, y murmuró contra Moisés, y dijo: ¿Por qué nos hiciste subir de Egipto para matarnos de sed á nosotros, y á nuestros hijos y á nuestros ganados? [^3] Entonces clamó Moisés á Jehová, diciendo: ¿Qué haré con este pueblo? de aquí á un poco me apedrearán. [^4] Y Jehová dijo á Moisés: Pasa delante del pueblo, y toma contigo de los ancianos de Israel; y toma también en tu mano tu vara, con que heriste el río, y ve: [^5] He aquí que yo estoy delante de ti allí sobre la peña en Horeb; y herirás la peña, y saldrán de ella aguas, y beberá el pueblo. Y Moisés lo hizo así en presencia de los ancianos de Israel. [^6] Y llamó el nombre de aquel lugar Massah y Meribah, por la rencilla de los hijos de Israel, y porque tentaron á Jehová, diciendo: ¿Está, pues, Jehová entre nosotros, ó no? [^7] Y vino Amalec y peleó con Israel en Rephidim. [^8] Y dijo Moisés á Josué: Escógenos varones, y sal, pelea con Amalec: mañana yo estaré sobre la cumbre del collado, y la vara de Dios en mi mano. [^9] E hizo Josué como le dijo Moisés, peleando con Amalec; y Moisés y Aarón y Hur subieron á la cumbre del collado. [^10] Y sucedía que cuando alzaba Moisés su mano, Israel prevalecía; mas cuando él bajaba su mano, prevalecía Amalec. [^11] Y las manos de Moisés estaban pesadas; por lo que tomaron una piedra, y pusiéronla debajo de él, y se sentó sobre ella; y Aarón y Hur sustentaban sus manos, el uno de una parte y el otro de otra; así hubo en sus manos firmeza hasta que se puso el sol. [^12] Y Josué deshizo á Amalec y á su pueblo á filo de espada. [^13] Y Jehová dijo á Moisés: Escribe esto para memoria en un libro, y di á Josué que del todo tengo de raer la memoria de Amalec de debajo del cielo. [^14] Y Moisés edificó un altar, y llamó su nombre Jehová-nissi; [^15] Y dijo: Por cuanto la mano sobre el trono de Jehová, Jehová tendrá guerra con Amalec de generación en generación. [^16] 

[[Exodus - 16|<--]] Exodus - 17 [[Exodus - 18|-->]]

---
# Notes
