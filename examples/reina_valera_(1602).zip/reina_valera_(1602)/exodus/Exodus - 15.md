---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 15 - Reina Valera (1602)"
---
[[Exodus - 14|<--]] Exodus - 15 [[Exodus - 16|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Exodus]]

# Exodus - 15

ENTONCES cantó Moisés y los hijos de Israel este cántico á Jehová, y dijeron: Cantaré yo á Jehová, porque se ha magnificado grandemente, Echando en la mar al caballo y al que en él subía. [^1] Jehová es mi fortaleza, y mi canción, Y hame sido por salud: Este es mi Dios, y á éste engrandeceré; Dios de mi padre, y á éste ensalzaré. [^2] Jehová, varón de guerra; Jehová es su nombre. [^3] Los carros de Faraón y á su ejército echó en la mar; Y sus escogidos príncipes fueron hundidos en el mar Bermejo. [^4] Los abismos los cubrieron; Como piedra descendieron á los profundos. [^5] Tu diestra, oh Jehová, ha sido magnificada en fortaleza; Tu diestra, oh Jehová, ha quebrantado al enemigo. [^6] Y con la grandeza de tu poder has trastornado á los que se levantaron contra ti: Enviaste tu furor; los tragó como á hojarasca. [^7] Con el soplo de tus narices se amontonaron las aguas; Paráronse las corrientes como en un montón; Los abismos se cuajaron en medio de la mar. [^8] El enemigo dijo: Perseguiré, prenderé, repartiré despojos; Mi alma se henchirá de ellos; Sacaré mi espada, destruirlos ha mi mano. [^9] Soplaste con tu viento, cubriólos la mar: Hundiéronse como plomo en las impetuosas aguas. [^10] ¿Quién como tú, Jehová, entre los dioses? ¿Quién como tú, magnífico en santidad, Terrible en loores, hacedor de maravillas? [^11] Extendiste tu diestra; La tierra los tragó. [^12] Condujiste en tu misericordia á este pueblo, al cual salvaste; Llevástelo con tu fortaleza á la habitación de tu santuario. [^13] Oiránlo los pueblos, y temblarán; Apoderarse ha dolor de los moradores de Palestina. [^14] Entonces los príncipes de Edom se turbarán; A los robustos de Moab los ocupará temblor; Abatirse han todos los moradores de Canaán. [^15] Caiga sobre ellos temblor y espanto; A la grandeza de tu brazo enmudezcan como una piedra; Hasta que haya pasado tu pueblo, oh Jehová, Hasta que haya pasado este pueblo que tú rescataste. [^16] Tú los introducirás y los plantarás en el monte de tu heredad, En el lugar de tu morada, que tú has aparejado, oh Jehová; En el santuario del Señor, que han afirmado tus manos. [^17] Jehová reinará por los siglos de los siglos. [^18] Porque Faraón entró cabalgando con sus carros y su gente de á caballo en la mar, y Jehová volvió á traer las aguas de la mar sobre ellos; mas los hijos de Israel fueron en seco por medio de la mar. [^19] Y María la profetisa, hermana de Aarón, tomó un pandero en su mano, y todas las mujeres salieron en pos de ella con panderos y danzas. [^20] Y María les respondía: Cantad á Jehová; porque en extremo se ha engrandecido, Echando en la mar al caballo, y al que en él subía. [^21] E hizo Moisés que partiese Israel del mar Bermejo, y salieron al desierto de Shur; y anduvieron tres días por el desierto sin hallar agua. [^22] Y llegaron á Mara, y no pudieron beber las aguas de Mara, porque eran amargas; por eso le pusieron el nombre de Mara. [^23] Entonces el pueblo murmuró contra Moisés, y dijo: ¿Qué hemos de beber? [^24] Y Moisés clamó á Jehová; y Jehová le mostró un árbol, el cual metídolo que hubo dentro de las aguas, las aguas se endulzaron. Allí les dió estatutos y ordenanzas, y allí los probó; [^25] Y dijo: Si oyeres atentamente la voz de Jehová tu Dios, é hicieres lo recto delante de sus ojos, y dieres oído á sus mandamientos, y guardares todos sus estatutos, ninguna enfermedad de las que envié á los Egipcios te enviaré á ti; porque yo soy Jehová tu Sanador. [^26] Y llegaron á Elim, donde había doce fuentes de aguas, y setenta palmas; y asentaron allí junto á las aguas. [^27] 

[[Exodus - 14|<--]] Exodus - 15 [[Exodus - 16|-->]]

---
# Notes
