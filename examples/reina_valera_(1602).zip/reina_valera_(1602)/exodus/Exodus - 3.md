---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 3 - Reina Valera (1602)"
---
[[Exodus - 2|<--]] Exodus - 3 [[Exodus - 4|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Exodus]]

# Exodus - 3

Y APACENTANDO Moisés las ovejas de Jethro su suegro, sacerdote de Madián, llevó las ovejas detrás del desierto, y vino á Horeb, monte de Dios. [^1] Y apareciósele el Angel de Jehová en una llama de fuego en medio de una zarza: y él miró, y vió que la zarza ardía en fuego, y la zarza no se consumía. [^2] Entonces Moisés dijo: Iré yo ahora, y veré esta grande visión, por qué causa la zarza no se quema. [^3] Y viendo Jehová que iba á ver, llamólo Dios de en medio de la zarza, y dijo: ­Moisés, Moisés! Y él respondió: Heme aquí. [^4] Y dijo: No te llegues acá: quita tus zapatos de tus pies, porque el lugar en que tú estás, tierra santa es. [^5] Y dijo: Yo soy el Dios de tu padre, Dios de Abraham, Dios de Isaac, Dios de Jacob. Entonces Moisés cubrió su rostro, porque tuvo miedo de mirar á Dios. [^6] Y dijo Jehová: Bien he visto la aflicción de mi pueblo que está en Egipto, y he oído su clamor á causa de sus exactores; pues tengo conocidas sus angustias: [^7] Y he descendido para librarlos de mano de los Egipcios, y sacarlos de aquella tierra á una tierra buena y ancha, á tierra que fluye leche y miel, á los lugares del Cananeo, del Hetheo, del Amorrheo, del Pherezeo, del Heveo, y del Jebuseo. [^8] El clamor, pues, de los hijos de Israel ha venido delante de mí, y también he visto la opresión con que los Egipcios los oprimen. [^9] Ven por tanto ahora, y enviarte he á Faraón, para que saques á mi pueblo, los hijos de Israel, de Egipto. [^10] Entonces Moisés respondió á Dios: ¿Quién soy yo, para que vaya á Faraón, y saque de Egipto á los hijos de Israel? [^11] Y él le respondió: Ve, porque yo seré contigo; y esto te será por señal de que yo te he enviado: luego que hubieres sacado este pueblo de Egipto, serviréis á Dios sobre este monte. [^12] Y dijo Moisés á Dios: He aquí que llego yo á los hijos de Israel, y les digo, El Dios de vuestros padres me ha enviado á vosotros; si ellos me preguntaren: ¿Cuál es su nombre? ¿qué les responderé? [^13] Y respondió Dios á Moisés: YO SOY EL QUE SOY. Y dijo: Así dirás á los hijos de Israel: YO SOY me ha enviado á vosotros. [^14] Y dijo más Dios á Moisés: Así dirás á los hijos de Israel: Jehová, el Dios de vuestros padres, el Dios de Abraham, Dios de Isaac y Dios de Jacob, me ha enviado á vosotros. Este es mi nombre para siempre, este es mi memorial por todos los siglos. [^15] Ve, y junta los ancianos de Israel, y diles: Jehová, el Dios de vuestros padres, el Dios de Abraham, de Isaac, y de Jacob, me apareció, diciendo: De cierto os he visitado, y visto lo que se os hace en Egipto; [^16] Y he dicho: Yo os sacaré de la aflicción de Egipto á la tierra del Cananeo, y del Hetheo, y del Amorrheo, y del Pherezeo, y del Heveo, y del Jebuseo, á una tierra que fluye leche y miel. [^17] Y oirán tu voz; é irás tú, y los ancianos de Israel, al rey de Egipto, y le diréis: Jehová, el Dios de los Hebreos, nos ha encontrado; por tanto nosotros iremos ahora camino de tres días por el desierto, para que sacrifiquemos á Jehová nuestro Dios. [^18] Mas yo sé que el rey de Egipto no os dejará ir sino por mano fuerte. [^19] Empero yo extenderé mi mano, y heriré á Egipto con todas mis maravillas que haré en él, y entonces os dejará ir. [^20] Y yo daré á este pueblo gracia en los ojos de los Egipcios, para que cuando os partiereis, no salgáis vacíos: [^21] Sino que demandará cada mujer á su vecina y á su huéspeda vasos de plata, vasos de oro, y vestidos: los cuales pondréis sobre vuestros hijos y vuestras hijas, y despojaréis á Egipto. [^22] 

[[Exodus - 2|<--]] Exodus - 3 [[Exodus - 4|-->]]

---
# Notes
