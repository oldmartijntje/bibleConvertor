---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 21 - Reina Valera (1602)"
---
[[Exodus - 20|<--]] Exodus - 21 [[Exodus - 22|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Exodus]]

# Exodus - 21

Y ESTOS son los derechos que les propondrás. [^1] Si comprares siervo hebreo, seis años servirá; mas al séptimo saldrá horro de balde. [^2] Si entró solo, solo saldrá: si tenía mujer, saldrá él y su mujer con él. [^3] Si su amo le hubiere dado mujer, y ella le hubiere parido hijos ó hijas, la mujer y sus hijos serán de su amo, y él saldrá solo. [^4] Y si el siervo dijere: Yo amo á mi señor, á mi mujer y á mis hijos, no saldré libre: [^5] Entonces su amo lo hará llegar á los jueces, y harále llegar á la puerta ó al poste; y su amo le horadará la oreja con lesna, y será su siervo para siempre. [^6] Y cuando alguno vendiere su hija por sierva, no saldrá como suelen salir los siervos. [^7] Si no agradare á su señor, por lo cual no la tomó por esposa, permitirle ha que se rescate, y no la podrá vender á pueblo extraño cuando la desechare. [^8] Mas si la hubiere desposado con su hijo, hará con ella según la costumbre de las hijas. [^9] Si le tomare otra, no disminuirá su alimento, ni su vestido, ni el débito conyugal. [^10] Y si ninguna de estas tres cosas hiciere, ella saldrá de gracia sin dinero. [^11] El que hiriere á alguno, haciéndole así morir, él morirá. [^12] Mas el que no armó asechanzas, sino que Dios lo puso en sus manos, entonces yo te señalaré lugar al cual ha de huir. [^13] Además, si alguno se ensoberbeciere contra su prójimo, y lo matare con alevosía, de mi altar lo quitarás para que muera. [^14] Y el que hiriere á su padre ó á su madre, morirá. [^15] Asimismo el que robare una persona, y la vendiere, ó se hallare en sus manos, morirá. [^16] Igualmente el que maldijere á su padre ó á su madre, morirá. [^17] Además, si algunos riñeren, y alguno hiriere á su prójimo con piedra ó con el puño, y no muriere, pero cayere en cama; [^18] Si se levantare y anduviere fuera sobre su báculo, entonces será el que le hirió absuelto: solamente le satisfará lo que estuvo parado, y hará que le curen. [^19] Y si alguno hiriere á su siervo ó á su sierva con palo, y muriere bajo de su mano, será castigado: [^20] Mas si durare por un día ó dos, no será castigado, porque su dinero es. [^21] Si algunos riñeren, é hiriesen á mujer preñada, y ésta abortare, pero sin haber muerte, será penado conforme á lo que le impusiere el marido de la mujer y juzgaren los árbitros. [^22] Mas si hubiere muerte, entonces pagarás vida por vida, [^23] Ojo por ojo, diente por diente, mano por mano, pie por pie, [^24] Quemadura por quemadura, herida por herida, golpe por golpe. [^25] Y cuando alguno hiriere el ojo de su siervo, ó el ojo de su sierva, y lo entortare, darále libertad por razón de su ojo. [^26] Y si sacare el diente de su siervo, ó el diente de su sierva, por su diente le dejará ir libre. [^27] Si un buey acorneare hombre ó mujer, y de resultas muriere, el buey será apedreado, y no se comerá su carne; mas el dueño del buey será absuelto. [^28] Pero si el buey era acorneador desde ayer y antes de ayer, y á su dueño le fué hecho requerimiento, y no lo hubiere guardado, y matare hombre ó mujer, el buey será apedreado, y también morirá su dueño. [^29] Si le fuere impuesto rescate, entonces dará por el rescate de su persona cuanto le fuere impuesto. [^30] Haya acorneado hijo, ó haya acorneado hija, conforme á este juicio se hará con él. [^31] Si el buey acorneare siervo ó sierva, pagará treinta siclos de plata su señor, y el buey será apedreado. [^32] Y si alguno abriere hoyo, ó cavare cisterna, y no la cubriere, y cayere allí buey ó asno, [^33] El dueño de la cisterna pagará el dinero, resarciendo á su dueño, y lo que fue muerto será suyo. [^34] Y si el buey de alguno hiriere al buey de su prójimo, y éste muriere, entonces venderán el buey vivo, y partirán el dinero de él, y también partirán el muerto. [^35] Mas si era notorio que el buey era acorneador de ayer y antes de ayer, y su dueño no lo hubiere guardado, pagará buey por buey, y el muerto será suyo. [^36] 

[[Exodus - 20|<--]] Exodus - 21 [[Exodus - 22|-->]]

---
# Notes
