---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 27 - Reina Valera (1602)"
---
[[Exodus - 26|<--]] Exodus - 27 [[Exodus - 28|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Exodus]]

# Exodus - 27

HARAS también altar de madera de Sittim de cinco codos de longitud, y de cinco codos de anchura: será cuadrado el altar, y su altura de tres codos. [^1] Y harás sus cuernos á sus cuatro esquinas; los cuernos serán de lo mismo; y lo cubrirás de metal. [^2] Harás también sus calderas para echar su ceniza; y sus paletas, y sus tazones, y sus garfios, y sus braseros: harás todos sus vasos de metal. [^3] Y le harás un enrejado de metal de obra de malla; y sobre el enrejado harás cuatro anillos de metal á sus cuatro esquinas. [^4] Y lo has de poner dentro del cerco del altar abajo; y llegará el enrejado hasta el medio del altar. [^5] Harás también varas para el altar, varas de madera de Sittim, las cuales cubrirás de metal. [^6] Y sus varas se meterán por los anillos: y estarán aquellas varas á ambos lados del altar, cuando hubiere de ser llevado. [^7] De tablas lo harás, hueco: de la manera que te fue mostrado en el monte, así lo harás. [^8] Asimismo harás el atrio del tabernáculo: al lado del mediodía, al austro, tendrá el atrio cortinas de lino torcido, de cien codos de longitud cada un lado; [^9] Sus veinte columnas, y sus veinte basas serán de metal; los capiteles de las columnas y sus molduras, de plata. [^10] Y de la misma manera al lado del aquilón habrá á lo largo cortinas de cien codos de longitud, y sus veinte columnas, con sus veinte basas de metal; los capiteles de sus columnas y sus molduras, de plata. [^11] Y el ancho del atrio del lado occidental tendrá cortinas de cincuenta codos; sus columnas diez, con sus diez basas. [^12] Y en el ancho del atrio por la parte de levante, al oriente, habrá cincuenta codos. [^13] Y las cortinas del un lado serán de quince codos; sus columnas tres, con sus tres basas. [^14] Al otro lado quince codos de cortinas; sus columnas tres, con sus tres basas. [^15] Y á la puerta del atrio habrá un pabellón de veinte codos, de cárdeno, y púrpura, y carmesí, y lino torcido, de obra de bordador: sus columnas cuatro, con sus cuatro basas. [^16] Todas las columnas del atrio en derredor serán ceñidas de plata; sus capiteles de plata, y sus basas de metal. [^17] La longitud del atrio será de cien codos, y la anchura cincuenta por un lado y cincuenta por el otro, y la altura de cinco codos: sus cortinas de lino torcido, y sus basas de metal. [^18] Todos los vasos del tabernáculo en todo su servicio, y todos sus clavos, y todos los clavos del atrio, serán de metal. [^19] Y tú mandarás á los hijos de Israel que te traigan aceite puro de olivas, molido, para la luminaria, para hacer arder continuamente las lámparas. [^20] En el tabernáculo del testimonio, afuera del velo que está delante del testimonio, las pondrá en orden Aarón y sus hijos, delante de Jehová desde la tarde hasta la mañana, como estatuto perpetuo de los hijos de Israel por sus generaciones. [^21] 

[[Exodus - 26|<--]] Exodus - 27 [[Exodus - 28|-->]]

---
# Notes
