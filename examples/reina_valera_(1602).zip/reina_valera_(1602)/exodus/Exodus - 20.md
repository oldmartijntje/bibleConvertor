---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 20 - Reina Valera (1602)"
---
[[Exodus - 19|<--]] Exodus - 20 [[Exodus - 21|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Exodus]]

# Exodus - 20

Y HABLO Dios todas estas palabras, diciendo: [^1] Yo soy JEHOVA tu Dios, que te saqué de la tierra de Egipto, de casa de siervos. [^2] No tendrás dioses ajenos delante de mí. [^3] No te harás imagen, ni ninguna semejanza de cosa que esté arriba en el cielo, ni abajo en la tierra, ni en las aguas debajo de la tierra: [^4] No te inclinarás á ellas, ni las honrarás; porque yo soy Jehová tu Dios, fuerte, celoso, que visito la maldad de los padres sobre los hijos, sobre los terceros y sobre los cuartos, á los que me aborrecen, [^5] Y que hago misericordia en millares á los que me aman, y guardan mis mandamientos. [^6] No tomarás el nombre de Jehová tu Dios en vano; porque no dará por inocente Jehová al que tomare su nombre en vano. [^7] Acordarte has del día del reposo, para santificarlo: [^8] Seis días trabajarás, y harás toda tu obra; [^9] Mas el séptimo día será reposo para Jehová tu Dios: no hagas en él obra alguna, tú, ni tu hijo, ni tu hija, ni tu siervo, ni tu criada, ni tu bestia, ni tu extranjero que está dentro de tus puertas: [^10] Porque en seis días hizo Jehová los cielos y la tierra, la mar y todas las cosas que en ellos hay, y reposó en el séptimo día: por tanto Jehová bendijo el día del reposo y lo santificó. [^11] Honra á tu padre y á tu madre, porque tus días se alarguen en la tierra que Jehová tu Dios te da. [^12] No matarás. [^13] No cometerás adulterio. [^14] No hurtarás. [^15] No hablarás contra tu prójimo falso testimonio. [^16] No codiciarás la casa de tu prójimo, no codiciarás la mujer de tu prójimo, ni su siervo, ni su criada, ni su buey, ni su asno, ni cosa alguna de tu prójimo. [^17] Todo el pueblo consideraba las voces, y las llamas, y el sonido de la bocina, y el monte que humeaba: y viéndolo el pueblo, temblaron, y pusiéronse de lejos. [^18] Y dijeron á Moisés: Habla tú con nosotros, que nosotros oiremos; mas no hable Dios con nosotros, porque no muramos. [^19] Y Moisés respondió al pueblo: No temáis; que por probaros vino Dios, y porque su temor esté en vuestra presencia para que no pequéis. [^20] Entonces el pueblo se puso de lejos, y Moisés se llegó á la osbcuridad en la cual estaba Dios. [^21] Y Jehová dijo á Moisés: Así dirás á los hijos de Israel: Vosotros habéis visto que he hablado desde el cielo con vosotros. [^22] No hagáis conmigo dioses de plata, ni dioses de oro os haréis. [^23] Altar de tierra harás para mí, y sacrificarás sobre él tus holocaustos y tus pacíficos, tus ovejas y tus vacas: en cualquier lugar donde yo hiciere que esté la memoria de mi nombre, vendré á ti, y te bendeciré. [^24] Y si me hicieres altar de piedras, no las labres de cantería; porque si alzares tu pico sobre él, tú lo profanarás. [^25] Y no subirás por gradas á mi altar, porque tu desnudez no sea junto á él descubierta. [^26] 

[[Exodus - 19|<--]] Exodus - 20 [[Exodus - 21|-->]]

---
# Notes
