---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 19 - Reina Valera (1602)"
---
[[Exodus - 18|<--]] Exodus - 19 [[Exodus - 20|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Exodus]]

# Exodus - 19

AL mes tercero de la salida de los hijos de Israel de la tierra de Egipto, en aquel día vinieron al desierto de Sinaí. [^1] Porque partieron de Rephidim, y llegaron al desierto de Sinaí, y asentaron en el desierto; y acampó allí Israel delante del monte. [^2] Y Moisés subió á Dios; y Jehová lo llamó desde el monte, diciendo: Así dirás á la casa de Jacob, y denunciarás á los hijos de Israel: [^3] Vosotros visteis lo que hice á los Egipcios, y cómo os tomé sobre alas de águilas, y os he traído á mí. [^4] Ahora pues, si diereis oído á mi voz, y guardareis mi pacto, vosotros seréis mi especial tesoro sobre todos los pueblos; porque mía es toda la tierra. [^5] Y vosotros seréis mi reino de sacerdotes, y gente santa. Estas son las palabras que dirás á los hijos de Israel. [^6] Entonces vino Moisés, y llamó á los ancianos del pueblo, y propuso en presencia de ellos todas estas palabras que Jehová le había mandado. [^7] Y todo el pueblo respondió á una, y dijeron: Todo lo que Jehová ha dicho haremos. Y Moisés refirió las palabras del pueblo á Jehová. [^8] Y Jehová dijo á Moisés: He aquí, yo vengo á ti en una nube espesa, para que el pueblo oiga mientras yo hablo contigo, y también para que te crean para siempre. Y Moisés denunció las palabras del pueblo á Jehová. [^9] Y Jehová dijo á Moisés: Ve al pueblo, y santifícalos hoy y mañana, y laven sus vestidos; [^10] Y estén apercibidos para el día tercero, porque al tercer día Jehová descenderá, á ojos de todo el pueblo, sobre el monte de Sinaí. [^11] Y señalarás término al pueblo en derredor, diciendo: Guardaos, no subáis al monte, ni toquéis á su término: cualquiera que tocare el monte, de seguro morirá: [^12] No le tocará mano, mas será apedreado ó asaeteado; sea animal ó sea hombre, no vivirá. En habiendo sonado largamente la bocina, subirán al monte. [^13] Y descendió Moisés del monte al pueblo, y santificó al pueblo; y lavaron sus vestidos. [^14] Y dijo al pueblo: Estad apercibidos para el tercer día; no lleguéis á mujer. [^15] Y aconteció al tercer día cuando vino la mañana, que vinieron truenos y relámpagos, y espesa nube sobre el monte, y sonido de bocina muy fuerte; y estremecióse todo el pueblo que estaba en el real. [^16] Y Moisés sacó del real al pueblo á recibir á Dios; y pusiéronse á lo bajo del monte. [^17] Y todo el monte de Sinaí humeaba, porque Jehová había descendido sobre él en fuego: y el humo de él subía como el humo de un horno, y todo el monte se estremeció en gran manera. [^18] Y el sonido de la bocina iba esforzándose en extremo: Moisés hablaba, y Dios le respondía en voz. [^19] Y descendió Jehová sobre el monte de Sinaí, sobre la cumbre del monte: y llamó Jehová á Moisés á la cumbre del monte, y Moisés subió. [^20] Y Jehová dijo á Moisés: Desciende, requiere al pueblo que no traspasen el término por ver á Jehová, porque caerá multitud de ellos. [^21] Y también los sacerdotes que se llegan á Jehová, se santifiquen, porque Jehová no haga en ellos estrago. [^22] Y Moisés dijo á Jehová: El pueblo no podrá subir al monte de Sinaí, porque tú nos has requerido diciendo: Señala términos al monte, y santifícalo. [^23] Y Jehová le dijo: Ve, desciende, y subirás tú, y Aarón contigo: mas los sacerdotes y el pueblo no traspasen el término por subir á Jehová, porque no haga en ellos estrago. [^24] Entonces Moisés descendió al pueblo y habló con ellos. [^25] 

[[Exodus - 18|<--]] Exodus - 19 [[Exodus - 20|-->]]

---
# Notes
