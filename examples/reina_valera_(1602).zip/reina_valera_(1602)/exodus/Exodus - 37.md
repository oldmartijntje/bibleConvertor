---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 37 - Reina Valera (1602)"
---
[[Exodus - 36|<--]] Exodus - 37 [[Exodus - 38|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Exodus]]

# Exodus - 37

HIZO también Bezaleel el arca de madera de Sittim: su longitud era de dos codos y medio, y de codo y medio su anchura, y su altura de otro codo y medio: [^1] Y cubrióla de oro puro por de dentro y por de fuera, é hízole una cornisa de oro en derredor. [^2] Hízole además de fundición cuatro anillos de oro á sus cuatro esquinas; en el un lado dos anillos y en el otro lado dos anillos. [^3] Hizo también las varas de madera de Sittim, y cubriólas de oro. [^4] Y metió las varas por los anillos á los lados del arca, para llevar el arca. [^5] Hizo asimismo la cubierta de oro puro: su longitud de dos codos y medio, y su anchura de codo y medio. [^6] Hizo también los dos querubines de oro, hízolos labrados á martillo, á los dos cabos de la cubierta: [^7] El un querubín de esta parte al un cabo, y el otro querubín de la otra parte al otro cabo de la cubierta: hizo los querubines á sus dos cabos. [^8] Y los querubines extendían sus alas por encima, cubriendo con sus alas la cubierta: y sus rostros el uno enfrente del otro, hacia la cubierta los rostros de los querubines. [^9] Hizo también la mesa de madera de Sittim; su longitud de dos codos, y su anchura de un codo, y de codo y medio su altura; [^10] Y cubrióla de oro puro, é hízole una cornisa de oro en derredor. [^11] Hízole también una moldura alrededor, del ancho de una mano, á la cual moldura hizo la cornisa de oro en circunferencia. [^12] Hízole asimismo de fundición cuatro anillos de oro, y púsolos á las cuatro esquinas que correspondían á los cuatro pies de ella. [^13] Delante de la moldura estaban los anillos, por los cuales se metiesen las varas para llevar la mesa. [^14] E hizo las varas de madera de Sittim para llevar la mesa, y cubriólas de oro. [^15] También hizo los vasos que habían de estar sobre la mesa, sus platos, y sus cucharas, y sus cubiertos y sus tazones con que se había de libar, de oro fino. [^16] Hizo asimismo el candelero de oro puro, é hízolo labrado á martillo: su pie y su caña, sus copas, sus manzanas y sus flores eran de lo mismo. [^17] De sus lados salían seis brazos; tres brazos del un lado del candelero, y otros tres brazos del otro lado del candelero: [^18] En el un brazo, tres copas figura de almendras, una manzana y una flor; y en el otro brazo tres copas figura de almendras, una manzana y una flor: y así en los seis brazos que salían del candelero. [^19] Y en el candelero había cuatro copas figura de almendras, sus manzanas y sus flores: [^20] Y una manzana debajo de los dos brazos de lo mismo, y otra manzana debajo de los otros dos brazos de lo mismo, y otra manzana debajo de los otros dos brazos de lo mismo, conforme á los seis brazos que salían de él. [^21] Sus manzanas y sus brazos eran de lo mismo; todo era una pieza labrada á martillo, de oro puro. [^22] Hizo asimismo sus siete candilejas, y sus despabiladeras, y sus platillos, de oro puro; [^23] De un talento de oro puro lo hizo, con todos sus vasos. [^24] Hizo también el altar del perfume de madera de Sittim: un codo su longitud, y otro codo su anchura, era cuadrado; y su altura de dos codos; y sus cuernos de la misma pieza. [^25] Y cubriólo de oro puro, su mesa y sus paredes alrededor, y sus cuernos: é hízole una corona de oro alrededor. [^26] Hízole también dos anillos de oro debajo de la corona en las dos esquinas á los dos lados, para pasar por ellos las varas con que había de ser conducido. [^27] E hizo las varas de madera de Sittim, y cubriólas de oro. [^28] Hizo asimismo el aceite santo de la unción, y el fino perfume aromático, de obra de perfumador. [^29] 

[[Exodus - 36|<--]] Exodus - 37 [[Exodus - 38|-->]]

---
# Notes
