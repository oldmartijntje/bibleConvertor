---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 1 - Reina Valera (1602)"
---
Exodus - 1 [[Exodus - 2|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Exodus]]

# Exodus - 1

ESTOS son los nombres de los hijos de Israel, que entraron en Egipto con Jacob; cada uno entró con su familia. [^1] Rubén, Simeón, Leví y Judá; [^2] Issachâr, Zabulón y Benjamín; [^3] Dan y Nephtalí, Gad y Aser. [^4] Y todas las almas de los que salieron del muslo de Jacob, fueron setenta. Y José estaba en Egipto. [^5] Y murió José, y todos sus hermanos, y toda aquella generación. [^6] Y los hijos de Israel crecieron, y multiplicaron, y fueron aumentados y corroborados en extremo; y llenóse la tierra de ellos. [^7] Levantóse entretanto un nuevo rey sobre Egipto, que no conocía á José; el cual dijo á su pueblo: [^8] He aquí, el pueblo de los hijos de Israel es mayor y más fuerte que nosotros: [^9] Ahora, pues, seamos sabios para con él, porque no se multiplique, y acontezca que viniendo guerra, él también se junte con nuestros enemigos, y pelee contra nosotros, y se vaya de la tierra. [^10] Entonces pusieron sobre él comisarios de tributos que los molestasen con sus cargas; y edificaron á Faraón las ciudades de los bastimentos, Phithom y Raamses. [^11] Empero cuanto más los oprimían, tanto más se multiplicaban y crecían: así que estaban ellos fastidiados de los hijos de Israel. [^12] Y los Egipcios hicieron servir á los hijos de Israel con dureza: [^13] Y amargaron su vida con dura servidumbre, en hacer barro y ladrillo, y en toda labor del campo, y en todo su servicio, al cual los obligaban con rigorismo. [^14] Y habló el rey de Egipto á las parteras de las Hebreas, una de las cuales se llamaba Siphra, y otra Phúa, y díjoles: [^15] Cuando parteareis á las Hebreas, y mirareis los asientos, si fuere hijo, matadlo; y si fuere hija, entonces viva. [^16] Mas las parteras temieron á Dios, y no hicieron como les mandó el rey de Egipto, sino que reservaban la vida á los niños. [^17] Y el rey de Egipto hizo llamar á las parteras y díjoles: ¿Por qué habéis hecho esto, que habéis reservado la vida á los niños? [^18] Y las parteras respondieron á Faraón: Porque las mujeres Hebreas no son como las Egipcias: porque son robustas, y paren antes que la partera venga á ellas. [^19] Y Dios hizo bien á las parteras: y el pueblo se multiplicó, y se corroboraron en gran manera. [^20] Y por haber las parteras temido á Dios, él les hizo casas. [^21] Entonces Faraón mandó á todo su pueblo, diciendo: Echad en el río todo hijo que naciere, y á toda hija reservad la vida. [^22] 

Exodus - 1 [[Exodus - 2|-->]]

---
# Notes
