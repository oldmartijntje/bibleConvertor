---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 5 - Reina Valera (1602)"
---
[[Exodus - 4|<--]] Exodus - 5 [[Exodus - 6|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Exodus]]

# Exodus - 5

DESPUÉS entraron Moisés y Aarón á Faraón, y le dijeron: Jehová, el Dios de Israel, dice así: Deja ir á mi pueblo á celebrarme fiesta en el desierto. [^1] Y Faraón respondió: ¿Quién es Jehová, para que yo oiga su voz y deje ir á Israel? Yo no conozco á Jehová, ni tampoco dejaré ir á Israel. [^2] Y ellos dijeron: El Dios de los Hebreos nos ha encontrado: iremos, pues, ahora camino de tres días por el desierto, y sacrificaremos á Jehová nuestro Dios; porque no venga sobre nosotros con pestilencia ó con espada. [^3] Entonces el rey de Egipto les dijo: Moisés y Aarón, ¿por qué hacéis cesar al pueblo de su obra? idos á vuestros cargos. [^4] Dijo también Faraón: He aquí el pueblo de la tierra es ahora mucho, y vosotros les hacéis cesar de sus cargos. [^5] Y mandó Faraón aquel mismo día á los cuadrilleros del pueblo que le tenían á su cargo, y á sus gobernadores, diciendo: [^6] De aquí adelante no daréis paja al pueblo para hacer ladrillo, como ayer y antes de ayer; vayan ellos y recojan por sí mismos la paja: [^7] Y habéis de ponerles la tarea del ladrillo que hacían antes, y no les disminuiréis nada; porque están ociosos, y por eso levantan la voz diciendo: Vamos y sacrificaremos á nuestro Dios. [^8] Agrávese la servidumbre sobre ellos, para que se ocupen en ella, y no atiendan á palabras de mentira. [^9] Y saliendo los cuadrilleros del pueblo y sus gobernadores, hablaron al pueblo, diciendo: Así ha dicho Faraón: Yo no os doy paja. [^10] Id vosotros, y recoged paja donde la hallareis; que nada se disminuirá de vuestra tarea. [^11] Entonces el pueblo se derramó por toda la tierra de Egipto á coger rastrojo en lugar de paja. [^12] Y los cuadrilleros los apremiaban, diciendo: Acabad vuestra obra, la tarea del día en su día, como cuando se os daba paja. [^13] Y azotaban á los capataces de los hijos de Israel, que los cuadrilleros de Faraón habían puesto sobre ellos, diciendo: ¿Por qué no habéis cumplido vuestra tarea de ladrillo ni ayer ni hoy, como antes? [^14] Y los capataces de los hijos de Israel vinieron á Faraón, y se quejaron á él, diciendo: ¿Por qué lo haces así con tus siervos? [^15] No se da paja á tus siervos, y con todo nos dicen: Haced el ladrillo. Y he aquí tus siervos son azotados, y tu pueblo cae en falta. [^16] Y él respondió: Estáis ociosos, sí, ociosos, y por eso decís: Vamos y sacrifiquemos á Jehová. [^17] Id pues ahora, y trabajad. No se os dará paja, y habéis de dar la tarea del ladrillo. [^18] Entonces los capataces de los hijos de Israel se vieron en aflicción, habiéndoseles dicho: No se disminuirá nada de vuestro ladrillo, de la tarea de cada día. [^19] Y encontrando á Moisés y á Aarón, que estaban á la vista de ellos cuando salían de Faraón, [^20] Dijéronles: Mire Jehová sobre vosotros, y juzgue; pues habéis hecho heder nuestro olor delante de Faraón y de sus siervos, dándoles el cuchillo en las manos para que nos maten. [^21] Entonces Moisés se volvió á Jehová, y dijo: Señor, ¿por qué afliges á este pueblo? ¿para qué me enviaste? [^22] Porque desde que yo vine á Faraón para hablarle en tu nombre, ha afligido á este pueblo; y tú tampoco has librado á tu pueblo. [^23] 

[[Exodus - 4|<--]] Exodus - 5 [[Exodus - 6|-->]]

---
# Notes
