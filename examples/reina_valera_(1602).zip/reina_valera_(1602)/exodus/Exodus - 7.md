---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 7 - Reina Valera (1602)"
---
[[Exodus - 6|<--]] Exodus - 7 [[Exodus - 8|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Exodus]]

# Exodus - 7

JEHOVA dijo á Moisés: Mira, yo te he constituído dios para Faraón, y tu hermano Aarón será tu profeta. [^1] Tú dirás todas las cosas que yo te mandaré, y Aarón tu hermano hablará á Faraón, para que deje ir de su tierra á los hijos de Israel. [^2] Y yo endureceré el corazón de Faraón, y multiplicaré en la tierra de Egipto mis señales y mis maravillas. [^3] Y Faraón no os oirá; mas yo pondré mi mano sobre Egipto, y sacaré á mis ejércitos, mi pueblo, los hijos de Israel, de la tierra de Egipto, con grandes juicios. [^4] Y sabrán los Egipcios que yo soy Jehová, cuando extenderé mi mano sobre Egipto, y sacaré los hijos de Israel de en medio de ellos. [^5] E hizo Moisés y Aarón como Jehová les mandó: hiciéronlo así. [^6] Y era Moisés de edad de ochenta años, y Aarón de edad de ochenta y tres, cuando hablaron á Faraón. [^7] Y habló Jehová á Moisés y á Aarón, diciendo: [^8] Si Faraón os respondiere diciendo, Mostrad milagro; dirás á Aarón: Toma tu vara, y échala delante de Faraón, para que se torne culebra. [^9] Vinieron, pues, Moisés y Aarón á Faraón, é hicieron como Jehová lo había mandado: y echó Aarón su vara delante de Faraón y de sus siervos, y tornóse culebra. [^10] Entonces llamó también Faraón sabios y encantadores; é hicieron también lo mismo los encantadores de Egipto con sus encantamientos; [^11] Pues echó cada uno su vara, las cuales se volvieron culebras: mas la vara de Aarón devoró las varas de ellos. [^12] Y el corazón de Faraón se endureció, y no los escuchó; como Jehová lo había dicho. [^13] Entonces Jehová dijo á Moisés: El corazón de Faraón está agravado, que no quiere dejar ir al pueblo. [^14] Ve por la mañana á Faraón, he aquí que él sale á las aguas; y tú ponte á la orilla del río delante de él, y toma en tu mano la vara que se volvió culebra, [^15] Y dile: Jehová el Dios de los Hebreos me ha enviado á ti, diciendo: Deja ir á mi pueblo, para que me sirvan en el desierto; y he aquí que hasta ahora no has querido oir. [^16] Así ha dicho Jehová: En esto conocerás que yo soy Jehová: he aquí, yo heriré con la vara que tengo en mi mano el agua que está en el río, y se convertirá en sangre: [^17] Y los peces que hay en el río morirán, y hederá el río, y tendrán asco los Egipcios de beber el agua del río. [^18] Y Jehová dijo á Moisés: Di á Aarón: Toma tu vara, y extiende tu mano sobre las aguas de Egipto, sobre sus ríos, sobre sus arroyos y sobre sus estanques, y sobre todos sus depósitos de aguas, para que se conviertan en sangre, y haya sangre por toda la región de Egipto, así en los vasos de madera como en los de piedra. [^19] Y Moisés y Aarón hicieron como Jehová lo mandó; y alzando la vara hirió las aguas que había en el río, en presencia de Faraón y de sus siervos; y todas las aguas que había en el río se convirtieron en sangre. [^20] Asimismo los peces que había en el río murieron; y el río se corrompió, que los Egipcios no podían beber de él: y hubo sangre por toda la tierra de Egipto. [^21] Y los encantadores de Egipto hicieron lo mismo con sus encantamientos: y el corazón de Faraón se endureció, y no los escuchó; como Jehová lo había dicho. [^22] Y tornando Faraón volvióse á su casa, y no puso su corazón aun en esto. [^23] Y en todo Egipto hicieron pozos alrededor del río para beber, porque no podían beber de las aguas del río. [^24] Y cumpliéronse siete días después que Jehová hirió el río. [^25] 

[[Exodus - 6|<--]] Exodus - 7 [[Exodus - 8|-->]]

---
# Notes
