---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 13 - Reina Valera (1602)"
---
[[Exodus - 12|<--]] Exodus - 13 [[Exodus - 14|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Exodus]]

# Exodus - 13

Y JEHOVA habló á Moisés, diciendo: [^1] Santifícame todo primogénito, cualquiera que abre matriz entre los hijos de Israel, así de los hombres como de los animales: mío es. [^2] Y Moisés dijo al pueblo: Tened memoria de aqueste día, en el cual habéis salido de Egipto, de la casa de servidumbre; pues Jehová os ha sacado de aquí con mano fuerte; por tanto, no comeréis leudado. [^3] Vosotros salís hoy en el mes de Abib. [^4] Y cuando Jehová te hubiere metido en la tierra del Cananeo, y del Hetheo, y del Amorrheo, y del Hebeo, y del Jebuseo, la cual juró á tus padres que te daría, tierra que destila leche y miel, harás esta servicio en aqueste mes. [^5] Siete días comerás por leudar, y el séptimo día será fiesta á Jehová. [^6] Por los siete días se comerán los panes sin levadura; y no se verá contigo leudado, ni levadura en todo tu término. [^7] Y contarás en aquel día á tu hijo, diciendo: Hácese esto con motivo de lo que Jehová hizo conmigo cuando me sacó de Egipto. [^8] Y serte ha como una señal sobre tu mano, y como una memoria delante de tus ojos, para que la ley de Jehová esté en tu boca; por cuanto con mano fuerte te sacó Jehová de Egipto. [^9] Por tanto, tú guardarás este rito en su tiempo de año en año. [^10] Y cuando Jehová te hubiere metido en la tierra del Cananeo, como te ha jurado á ti y á tus padres, y cuando te la hubiere dado, [^11] Harás pasar á Jehová todo lo que abriere la matriz, asimismo todo primerizo que abriere la matriz de tus animales: los machos serán de Jehová. [^12] Mas todo primogénito de asno redimirás con un cordero; y si no lo redimieres, le degollarás: asimismo redimirás todo humano primogénito de tus hijos. [^13] Y cuando mañana te preguntare tu hijo, diciendo: ¿Qué es esto? decirle has: Jehová nos sacó con mano fuerte de Egipto, de casa de servidumbre; [^14] Y endureciéndose Faraón en no dejarnos ir, Jehová mató en la tierra de Egipto á todo primogénito, desde el primogénito humano hasta el primogénito de la bestia: y por esta causa yo sacrifico á Jehová todo primogénito macho, y redimo todo primogénito de mis hijos. [^15] Serte ha, pues, como una señal sobre tu mano, y por una memoria delante de tus ojos; ya que Jehová nos sacó de Egipto con mano fuerte. [^16] Y luego que Faraón dejó ir al pueblo, Dios no los llevó por el camino de la tierra de los Filisteos, que estaba cerca; porque dijo Dios: Que quizá no se arrepienta el pueblo cuando vieren la guerra, y se vuelvan á Egipto: [^17] Mas hizo Dios al pueblo que rodease por el camino del desierto del mar Bermejo. Y subieron los hijos de Israel de Egipto armados. [^18] Tomó también consigo Moisés los huesos de José, el cual había juramentado á los hijos de Israel, diciendo: Dios ciertamente os visitará, y haréis subir mis huesos de aquí con vosotros. [^19] Y partidos de Succoth, asentaron campo en Etham, á la entrada del desierto. [^20] Y Jehová iba delante de ellos de día en una columna de nube, para guiarlos por el camino; y de noche en una columna de fuego para alumbrarles; á fin de que anduviesen de día y de noche. [^21] Nunca se partió de delante del pueblo la columna de nube de día, ni de noche la columna de fuego. [^22] 

[[Exodus - 12|<--]] Exodus - 13 [[Exodus - 14|-->]]

---
# Notes
