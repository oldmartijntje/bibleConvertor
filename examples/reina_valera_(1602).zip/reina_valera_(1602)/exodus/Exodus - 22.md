---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 22 - Reina Valera (1602)"
---
[[Exodus - 21|<--]] Exodus - 22 [[Exodus - 23|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Exodus]]

# Exodus - 22

CUANDO alguno hurtare buey ú oveja, y le degollare ó vendiere, por aquel buey pagará cinco bueyes, y por aquella oveja cuatro ovejas. [^1] Si el ladrón fuere hallado forzando una casa, y fuere herido y muriere, el que le hirió no será culpado de su muerte. [^2] Si el sol hubiere sobre él salido, el matador será reo de homicidio: el ladrón habrá de restituir cumplidamente; si no tuviere, será vendido por su hurto. [^3] Si fuere hallado con el hurto en la mano, sea buey ó asno ú oveja vivos, pagará el duplo. [^4] Si alguno hiciere pacer campo ó viña, y metiere su bestia, y comiere la tierra de otro, de lo mejor de su tierra y de lo mejor de su viña pagará. [^5] Cuando rompiere un fuego, y hallare espinas, y fuere quemado montón, ó haza, ó campo, el que encendió el fuego pagará lo quemado. [^6] Cuando alguno diere á su prójimo plata ó alhajas á guardar, y fuere hurtado de la casa de aquel hombre, si el ladrón se hallare, pagará el doble. [^7] Si el ladrón no se hallare, entonces el dueño de la casa será presentado á los jueces, para ver si ha metido su mano en la hacienda de su prójimo. [^8] Sobre todo negocio de fraude, sobre buey, sobre asno, sobre oveja, sobre vestido, sobre toda cosa perdida, cuando uno dijere: Esto es mío, la causa de ambos vendrá delante de los jueces; y el que los jueces condenaren, pagará el doble á su prójimo. [^9] Si alguno hubiere dado á su prójimo asno, ó buey, ú oveja, ó cualquier otro animal á guardar, y se muriere ó se perniquebrare, ó fuere llevado sin verlo nadie; [^10] Juramento de Jehová tendrá lugar entre ambos de que no echó su mano á la hacienda de su prójimo: y su dueño lo aceptará, y el otro no pagará. [^11] Mas si le hubiere sido hurtado, resarcirá á su dueño. [^12] Y si le hubiere sido arrebatado por fiera, traerle ha testimonio, y no pagará lo arrebatado. [^13] Pero si alguno hubiere tomado prestada bestia de su prójimo, y fuere estropeada ó muerta, ausente su dueño, deberá pagar la. [^14] Si el dueño estaba presente, no la pagará. Si era alquilada, él vendrá por su alquiler. [^15] Y si alguno engañare á alguna doncella que no fuere desposada, y durmiere con ella, deberá dotarla y tomarla por mujer. [^16] Si su padre no quisiere dársela, él le pesará plata conforme al dote de las vírgenes. [^17] A la hechicera no dejarás que viva. [^18] Cualquiera que tuviere ayuntamiento con bestia, morirá. [^19] El que sacrificare á dioses, excepto á sólo Jehová, será muerto. [^20] Y al extranjero no engañarás, ni angustiarás, porque extranjeros fuisteis vosotros en la tierra de Egipto. [^21] A ninguna viuda ni huérfano afligiréis. [^22] Que si tú llegas á afligirle, y él á mí clamare, ciertamente oiré yo su clamor; [^23] Y mi furor se encenderá, y os mataré á cuchillo, y vuestras mujeres serán viudas, y huérfanos vuestros hijos. [^24] Si dieres á mi pueblo dinero emprestado, al pobre que está contigo, no te portarás con él como logrero, ni le impondrás usura. [^25] Si tomares en prenda el vestido de tu prójimo, á puestas del sol se lo volverás: [^26] Porque sólo aquello es su cubierta, es aquel el vestido para cubrir sus carnes, en el que ha de dormir: y será que cuando él á mí clamare, yo entonces le oiré, porque soy misericordioso. [^27] No denostarás á los jueces, ni maldecirás al príncipe de tu pueblo. [^28] No dilatarás la primicia de tu cosecha, ni de tu licor, me darás el primogénito de tus hijos. [^29] Así harás con el de tu buey y de tu oveja: siete días estará con su madre, y al octavo día me lo darás. [^30] Y habéis de serme varones santos: y no comeréis carne arrebatada de las fieras en el campo; á los perros la echaréis. [^31] 

[[Exodus - 21|<--]] Exodus - 22 [[Exodus - 23|-->]]

---
# Notes
