---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 2 - Reina Valera (1602)"
---
[[Exodus - 1|<--]] Exodus - 2 [[Exodus - 3|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Exodus]]

# Exodus - 2

UN varón de la familia de Leví fué, y tomó por mujer una hija de Leví: [^1] La cual concibió, y parió un hijo: y viéndolo que era hermoso, túvole escondido tres meses. [^2] Pero no pudiendo ocultarle más tiempo, tomó una arquilla de juncos, y calafateóla con pez y betún, y colocó en ella al niño, y púsolo en un carrizal á la orilla del río: [^3] Y paróse una hermana suya á lo lejos, para ver lo que le acontecería. [^4] Y la hija de Faraón descendió á lavarse al río, y paseándose sus doncellas por la ribera del río, vió ella la arquilla en el carrizal, y envió una criada suya á que la tomase. [^5] Y como la abrió, vió al niño; y he aquí que el niño lloraba. Y teniendo compasión de él, dijo: De los niños de los Hebreos es éste. [^6] Entonces su hermana dijo á la hija de Faraón: ¿Iré á llamarte un ama de las Hebreas, para que te críe este niño? [^7] Y la hija de Faraón respondió: Ve. Entonces fué la doncella, y llamó á la madre del niño; [^8] A la cual dijo la hija de Faraón: Lleva este niño, y críamelo, y yo te lo pagaré. Y la mujer tomó al niño, y criólo. [^9] Y como creció el niño, ella lo trajo á la hija de Faraón, la cual lo prohijó, y púsole por nombre Moisés, diciendo: Porque de las aguas lo saqué. [^10] Y en aquellos días acaeció que, crecido ya Moisés, salió á sus hermanos, y vió sus cargas: y observó á un Egipcio que hería á uno de los Hebreos, sus hermanos. [^11] Y miró á todas partes, y viendo que no parecía nadie, mató al Egipcio, y escondiólo en la arena. [^12] Y salió al día siguiente, y viendo á dos Hebreos que reñían, dijo al que hacía la injuria: ¿Por qué hieres á tu prójimo? [^13] Y él respondió: ¿Quién te ha puesto á ti por príncipe y juez sobre nosotros? ¿piensas matarme como mataste al Egipcio? Entonces Moisés tuvo miedo, y dijo: Ciertamente esta cosa es descubierta. [^14] Y oyendo Faraón este negocio, procuró matar á Moisés: mas Moisés huyó de delante de Faraón, y habitó en la tierra de Madián; y sentóse junto á un pozo. [^15] Tenía el sacerdote de Madián siete hijas, las cuales vinieron á sacar agua, para llenar las pilas y dar de beber á las ovejas de su padre. [^16] Mas los pastores vinieron, y echáronlas: Entonces Moisés se levantó y defendiólas, y abrevó sus ovejas. [^17] Y volviendo ellas á Ragüel su padre, díjoles él: ¿Por qué habéis hoy venido tan presto? [^18] Y ellas respondieron: Un varón Egipcio nos defendió de mano de los pastores, y también nos sacó el agua, y abrevó las ovejas. [^19] Y dijo á sus hijas: ¿Y dónde está? ¿por qué habéis dejado ese hombre? llamadle para que coma pan. [^20] Y Moisés acordó en morar con aquel varón; y él dió á Moisés á su hija Séphora: [^21] La cual le parió un hijo, y él le puso por nombre Gersom: porque dijo: Peregrino soy en tierra ajena. [^22] Y aconteció que después de muchos días murió el rey de Egipto, y los hijos de Israel suspiraron á causa de la servidumbre, y clamaron: y subió á Dios el clamor de ellos con motivo de su servidumbre. [^23] Y oyó Dios el gemido de ellos, y acordóse de su pacto con Abraham, Isaac y Jacob. [^24] Y miró Dios á los hijos de Israel, y reconociólos Dios. [^25] 

[[Exodus - 1|<--]] Exodus - 2 [[Exodus - 3|-->]]

---
# Notes
