---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 11 - Reina Valera (1602)"
---
[[Exodus - 10|<--]] Exodus - 11 [[Exodus - 12|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Exodus]]

# Exodus - 11

Y JEHOVA dijo á Moisés: Una plaga traeré aún sobre Faraón, y sobre Egipto; después de la cual él os dejará ir de aquí; y seguramente os echará de aquí del todo. [^1] Habla ahora al pueblo, y que cada uno demande á su vecino, y cada una á su vecina, vasos de plata y de oro. [^2] Y Jehová dió gracia al pueblo en los ojos de los Egipcios. También Moisés era muy gran varón en la tierra de Egipto, á los ojos de los siervos de Faraón, y á los ojos del pueblo. [^3] Y dijo Moisés: Jehová ha dicho así: A la media noche yo saldré por medio de Egipto, [^4] Y morirá todo primogénito en tierra de Egipto, desde el primogénito de Faraón que se sienta en su trono, hasta el primogénito de la sierva que está tras la muela; y todo primogénito de las bestias. [^5] Y habrá gran clamor por toda la tierra de Egipto, cual nunca fué, ni jamás será. [^6] Mas entre todos los hijos de Israel, desde el hombre hasta la bestia, ni un perro moverá su lengua: para que sepáis que hará diferencia Jehová entre los Egipcios y los Israelitas. [^7] Y descenderán á mí todos estos tus siervos, é inclinados delante de mí dirán: Sal tú, y todo el pueblo que está bajo de ti; y después de esto yo saldré. Y salióse muy enojado de con Faraón. [^8] Y Jehová dijo á Moisés: Faraón no os oirá, para que mis maravillas se multipliquen en la tierra de Egipto. [^9] Y Moisés y Aarón hicieron todos estos prodigios delante de Faraón: mas Jehová había endurecido el corazón de Faraón, y no envió á los hijos de Israel fuera de su país. [^10] 

[[Exodus - 10|<--]] Exodus - 11 [[Exodus - 12|-->]]

---
# Notes
