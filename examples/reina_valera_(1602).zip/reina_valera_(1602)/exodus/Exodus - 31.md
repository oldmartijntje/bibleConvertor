---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 31 - Reina Valera (1602)"
---
[[Exodus - 30|<--]] Exodus - 31 [[Exodus - 32|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Exodus]]

# Exodus - 31

Y HABLO Jehová á Moisés, diciendo: [^1] Mira, yo he llamado por su nombre á Bezaleel, hijo de Uri, hijo de Hur, de la tribu de Judá; [^2] Y lo he henchido de espíritu de Dios, en sabiduría, y en inteligencia, y en ciencia, y en todo artificio, [^3] Para inventar diseños, para trabajar en oro, y en plata, y en metal, [^4] Y en artificio de piedras para engastar las, y en artificio de madera; para obrar en toda suerte de labor. [^5] Y he aquí que yo he puesto con él á Aholiab, hijo de Ahisamac, de la tribu de Dan: y he puesto sabiduría en el ánimo de todo sabio de corazón, para que hagan todo lo que te he mandado: [^6] El tabernáculo del testimonio, y el arca del testimonio, y la cubierta que está sobre ella, y todos los vasos del tabernáculo; [^7] Y la mesa y sus vasos, y el candelero limpio y todos sus vasos, y el altar del perfume; [^8] Y el altar del holocausto y todos sus vasos, y la fuente y su basa; [^9] Y los vestidos del servicio, y las santas vestiduras para Aarón el sacerdote, y las vestiduras de sus hijos, para que ejerzan el sacerdocio; [^10] Y el aceite de la unción, y el perfume aromático para el santuario: harán conforme á todo lo que te he mandado. [^11] Habló además Jehová á Moisés, diciendo: [^12] Y tú hablarás á los hijos de Israel, diciendo: Con todo eso vosotros guardaréis mis sábados: porque es señal entre mí y vosotros por vuestras edades, para que sepáis que yo soy Jehová que os santifico. [^13] Así que guardaréis el sábado, porque santo es á vosotros: el que lo profanare, de cierto morirá; porque cualquiera que hiciere obra alguna en él, aquella alma será cortada de en medio de sus pueblos. [^14] Seis días se hará obra, mas el día séptimo es sábado de reposo consagrado á Jehová; cualquiera que hiciere obra el día del sábado, morirá ciertamente. [^15] Guardarán, pues, el sábado los hijos de Israel: celebrándolo por sus edades por pacto perpetuo: [^16] Señal es para siempre entre mí y los hijos de Israel; porque en seis días hizo Jehová los cielos y la tierra, y en el séptimo día cesó, y reposó. [^17] Y dió á Moisés, como acabó de hablar con él en el monte de Sinaí, dos tablas del testimonio, tablas de piedra escritas con el dedo de Dios. [^18] 

[[Exodus - 30|<--]] Exodus - 31 [[Exodus - 32|-->]]

---
# Notes
