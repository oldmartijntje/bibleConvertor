---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 33 - Reina Valera (1602)"
---
[[Exodus - 32|<--]] Exodus - 33 [[Exodus - 34|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Exodus]]

# Exodus - 33

Y JEHOVA dijo á Moisés: Ve, sube de aquí, tú y el pueblo que sacaste de la tierra de Egipto, á la tierra de la cual juré á Abraham, Isaac, y Jacob, diciendo: A tu simiente la daré: [^1] Y yo enviaré delante de ti el ángel, y echaré fuera al Cananeo y al Amorrheo, y al Hetheo, y al Pherezeo, y al Heveo y al Jebuseo: [^2] (A la tierra que fluye leche y miel); porque yo no subiré en medio de ti, porque eres pueblo de dura cerviz, no sea que te consuma en el camino. [^3] Y oyendo el pueblo esta sensible palabra, vistieron luto, y ninguno se puso sus atavíos: [^4] Pues Jehová dijo á Moisés: Di á los hijos de Israel: Vosotros sois pueblo de dura cerviz: en un momento subiré en medio de ti, y te consumiré: quítate pues ahora tus atavíos, que yo sabré lo que te tengo de hacer. [^5] Entonces los hijos de Israel se despojaron de sus atavíos desde el monte Horeb. [^6] Y Moisés tomó el tabernáculo, y extendiólo fuera del campo, lejos del campo, y llamólo el Tabernáculo del Testimonio. Y fué, que cualquiera que requería á Jehová, salía al tabernáculo del testimonio, que estaba fuera del campo. [^7] Y sucedía que, cuando salía Moisés al tabernáculo, todo el pueblo se levantaba, y estaba cada cual en pie á la puerta de su tienda, y miraban en pos de Moisés, hasta que él entraba en el tabernáculo. [^8] Y cuando Moisés entraba en el tabernáculo, la columna de nube descendía, y poníase á la puerta del tabernáculo, y Jehová hablaba con Moisés. [^9] Y viendo todo el pueblo la columna de nube, que estaba á la puerta del tabernáculo, levantábase todo el pueblo, cada uno á la puerta de su tienda y adoraba. [^10] Y hablaba Jehová á Moisés cara á cara, como habla cualquiera á su compañero. Y volvíase al campo; mas el joven Josué, su criado, hijo de Nun, nunca se apartaba de en medio del tabernáculo. [^11] Y dijo Moisés á Jehová: Mira, tú me dices á mí: Saca este pueblo: y tú no me has declarado á quién has de enviar conmigo: sin embargo, tú dices: Yo te he conocido por tu nombre, y has hallado también gracia en mis ojos. [^12] Ahora, pues, si he hallado gracia en tus ojos, ruégote que me muestres ahora tu camino, para que te conozca, porque halle gracia en tus ojos: y mira que tu pueblo es aquesta gente. [^13] Y él dijo: Mi rostro irá contigo, y te haré descansar. [^14] Y él respondió: Si tu rostro no ha de ir conmigo, no nos saques de aquí. [^15] ¿Y en qué se conocerá aquí que he hallado gracia en tus ojos, yo y tu pueblo, sino en andar tú con nosotros, y que yo y tu pueblo seamos apartados de todos los pueblos que están sobre la faz de la tierra? [^16] Y Jehová dijo á Moisés: También haré esto que has dicho, por cuanto has hallado gracia en mis ojos, y te he conocido por tu nombre. [^17] El entonces dijo: Ruégote que me muestres tu gloria. [^18] Y respondióle: Yo haré pasar todo mi bien delante de tu rostro, y proclamaré el nombre de Jehová delante de ti; y tendré misericordia del que tendré misericordia, y seré clemente para con el que seré clemente. [^19] Dijo más: No podrás ver mi rostro: porque no me verá hombre, y vivirá. [^20] Y dijo aún Jehová: He aquí lugar junto á mí, y tú estarás sobre la peña: [^21] Y será que, cuando pasare mi gloria, yo te pondré en una hendidura de la peña, y te cubriré con mi mano hasta que haya pasado: [^22] Después apartaré mi mano, y verás mis espaldas; mas no se verá mi rostro. [^23] 

[[Exodus - 32|<--]] Exodus - 33 [[Exodus - 34|-->]]

---
# Notes
