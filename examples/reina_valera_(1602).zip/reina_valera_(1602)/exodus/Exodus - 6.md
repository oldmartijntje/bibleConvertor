---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 6 - Reina Valera (1602)"
---
[[Exodus - 5|<--]] Exodus - 6 [[Exodus - 7|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Exodus]]

# Exodus - 6

JEHOVA respondió á Moisés: Ahora verás lo que yo haré á Faraón; porque con mano fuerte los ha de dejar ir; y con mano fuerte los ha de echar de su tierra. [^1] Habló todavía Dios á Moisés, y díjole: Yo soy JEHOVA; [^2] Y aparecí á Abraham, á Isaac y á Jacob bajo el nombre de Dios Omnipotente, mas en mi nombre JEHOVA no me notifiqué á ellos. [^3] Y también establecí mi pacto con ellos, de darles la tierra de Canaán, la tierra en que fueron extranjeros, y en la cual peregrinaron. [^4] Y asimismo yo he oído el gemido de los hijos de Israel, á quienes hacen servir los Egipcios, y heme acordado de mi pacto. [^5] Por tanto dirás á los hijos de Israel: YO JEHOVA; y yo os sacaré de debajo de las cargas de Egipto, y os libraré de su servidumbre, y os redimiré con brazo extendido, y con juicios grandes: [^6] Y os tomaré por mi pueblo y seré vuestro Dios: y vosotros sabréis que yo soy Jehová vuestro Dios, que os saco de debajo de las cargas de Egipto: [^7] Y os meteré en la tierra, por la cual alcé mi mano que la daría á Abraham, á Isaac y á Jacob: y yo os la daré por heredad. YO JEHOVA. [^8] De esta manera habló Moisés á los hijos de Israel: mas ellos no escuchaban á Moisés á causa de la congoja de espíritu, y de la dura servidumbre. [^9] Y habló Jehová á Moisés, diciendo: [^10] Entra, y habla á Faraón rey de Egipto, que deje ir de su tierra á los hijos de Israel. [^11] Y respondió Moisés delante de Jehová, diciendo: He aquí, los hijos de Israel no me escuchan: ¿cómo pues me escuchará Faraón, mayormente siendo yo incircunciso de labios? [^12] Entonces Jehová habló á Moisés y á Aarón, y dióles mandamiento para los hijos de Israel, y para Faraón rey de Egipto, para que sacasen á los hijos de Israel de la tierra de Egipto. [^13] Estas son las cabezas de las familias de sus padres. Los hijos de Rubén, el primogénito de Israel: Hanoch y Phallú, Hezrón y Carmi: estas son las familias de Rubén. [^14] Los hijos de Simeón: Jemuel, y Jamín, y Ohad, y Jachîn, y Zoar, y Saúl, hijo de una Cananea: estas son las familias de Simeón. [^15] Y estos son los nombres de los hijos de Leví por sus linajes: Gersón, y Coath, y Merari: Y los años de la vida de Leví fueron ciento treinta y siete años. [^16] Y los hijos de Gersón: Libni, y Shimi, por sus familias. [^17] Y los hijos de Coath: Amram, é Izhar, y Hebrón, y Uzziel. Y los años de la vida de Coath fueron ciento treinta y tres años. [^18] Y los hijos de Merari: Mahali, y Musi: estas son las familias de Leví por sus linajes. [^19] Y Amram tomó por mujer á Jochêbed su tía, la cual le parió á Aarón y á Moisés. Y los años de la vida de Amram fueron ciento treinta y siete años. [^20] Y los hijos de Izhar: Cora, y Nepheg y Zithri. [^21] Y los hijos de Uzziel: Misael, y Elzaphán y Zithri. [^22] Y tomóse Aarón por mujer á Elisabeth, hija de Aminadab, hermana de Naasón; la cual le parió á Nadab, y á Abiú, y á Eleazar, y á Ithamar. [^23] Y los hijos de Cora: Assir, y Elcana, y Abiasaph: estas son las familias de los Coritas. [^24] Y Eleazar, hijo de Aarón, tomó para sí mujer de las hijas de Phutiel, la cual le parió á Phinees: Y estas son las cabezas de los padres de los Levitas por sus familias. [^25] Este es aquel Aarón y aquel Moisés, á los cuales Jehová dijo: Sacad á los hijos de Israel de la tierra de Egipto por sus escuadrones. [^26] Estos son los que hablaron á Faraón rey de Egipto, para sacar de Egipto á los hijos de Israel. Moisés y Aarón fueron éstos. [^27] Cuando Jehová habló á Moisés en la tierra de Egipto, [^28] Entonces Jehová habló á Moisés, diciendo: Yo soy JEHOVA; di á Faraón rey de Egipto todas las cosas que yo te digo á ti. [^29] Y Moisés respondió delante de Jehová: He aquí, yo soy incircunciso de labios, ¿cómo pues me ha de oír Faraón? [^30] 

[[Exodus - 5|<--]] Exodus - 6 [[Exodus - 7|-->]]

---
# Notes
