---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 24 - Reina Valera (1602)"
---
[[Exodus - 23|<--]] Exodus - 24 [[Exodus - 25|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Exodus]]

# Exodus - 24

Y DIJO á Moisés: Sube á Jehová, tú, y Aarón, Nadab, y Abiú, y setenta de los ancianos de Israel; y os inclinaréis desde lejos. [^1] Mas Moisés sólo se llegará á Jehová; y ellos no se lleguen cerca, ni suba con él el pueblo. [^2] Y Moisés vino y contó al pueblo todas las palabras de Jehová, y todos los derechos: y todo el pueblo respondió á una voz, y dijeron: Ejecutaremos todas las palabras que Jehová ha dicho. [^3] Y Moisés escribió todas las palabras de Jehová, y levantándose de mañana edificó un altar al pie del monte, y doce columnas, según las doce tribus de Israel. [^4] Y envió á los mancebos de los hijos de Israel, los cuales ofrecieron holocaustos y sacrificaron pacíficos á Jehová, becerros. [^5] Y Moisés tomó la mitad de la sangre, y púsola en tazones, y esparció la otra mitad de la sangre sobre el altar. [^6] Y tomó el libro de la alianza, y leyó á oídos del pueblo, el cual dijo: Haremos todas las cosas que Jehová ha dicho, y obedeceremos. [^7] Entonces Moisés tomó la sangre, y roció sobre el pueblo, y dijo: He aquí la sangre de la alianza que Jehová ha hecho con vosotros sobre todas estas cosas. [^8] Y subieron Moisés y Aarón, Nadab y Abiú, y setenta de los ancianos de Israel; [^9] Y vieron al Dios de Israel; y había debajo de sus pies como un embaldosado de zafiro, semejante al cielo cuando está sereno. [^10] Mas no extendió su mano sobre los príncipes de los hijos de Israel: y vieron á Dios, y comieron y bebieron. [^11] Entonces Jehová dijo á Moisés: Sube á mí al monte, y espera allá, y te daré tablas de piedra, y la ley, y mandamientos que he escrito para enseñarlos. [^12] Y levantóse Moisés, y Josué su ministro; y Moisés subió al monte de Dios. [^13] Y dijo á los ancianos: Esperadnos aquí hasta que volvamos á vosotros: y he aquí Aarón y Hur están con vosotros: el que tuviere negocios, lléguese á ellos. [^14] Entonces Moisés subió al monte, y una nube cubrió el monte. [^15] Y la gloria de Jehová reposó sobre el monte Sinaí, y la nube lo cubrió por seis días: y al séptimo día llamó á Moisés de en medio de la nube. [^16] Y el parecer de la gloria de Jehová era como un fuego abrasador en la cumbre del monte, á los ojos de los hijos de Israel. [^17] Y entró Moisés en medio de la nube, y subió al monte: y estuvo Moisés en el monte cuarenta días y cuarenta noches. [^18] 

[[Exodus - 23|<--]] Exodus - 24 [[Exodus - 25|-->]]

---
# Notes
