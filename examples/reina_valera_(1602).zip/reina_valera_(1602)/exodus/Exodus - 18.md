---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 18 - Reina Valera (1602)"
---
[[Exodus - 17|<--]] Exodus - 18 [[Exodus - 19|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Exodus]]

# Exodus - 18

Y OYO Jethro, sacerdote de Madián, suegro de Moisés, todas las cosas que Dios había hecho con Moisés, y con Israel su pueblo, y cómo Jehová había sacado á Israel de Egipto: [^1] Y tomó Jethro, suegro de Moisés á Séphora la mujer de Moisés, después que él la envió, [^2] Y á sus dos hijos; el uno se llamaba Gersóm, porque dijo: Peregrino he sido en tierra ajena; [^3] Y el otro se llamaba Eliezer, porque dijo, El Dios de mi padre me ayudó, y me libró del cuchillo de Faraón. [^4] Y Jethro el suegro de Moisés, con sus hijos y su mujer, llegó á Moisés en el desierto, donde tenía el campo junto al monte de Dios; [^5] Y dijo á Moisés: Yo tu suegro Jethro vengo á ti, con tu mujer, y sus dos hijos con ella. [^6] Y Moisés salió á recibir á su suegro, é inclinóse, y besólo: y preguntáronse el uno al otro cómo estaban, y vinieron á la tienda. [^7] Y Moisés contó á su suegro todas las cosas que Jehová había hecho á Faraón y á los Egipcios por amor de Israel, y todo el trabajo que habían pasado en el camino, y cómo los había librado Jehová. [^8] Y alegróse Jethro de todo el bien que Jehová había hecho á Israel, que lo había librado de mano de los Egipcios. [^9] Y Jethro dijo: Bendito sea Jehová, que os libró de mano de los Egipcios, y de la mano de Faraón, y que libró al pueblo de la mano de los Egipcios. [^10] Ahora conozco que Jehová es grande más que todos los dioses; hasta en lo que se ensoberbecieron contra ellos. [^11] Y tomó Jethro, suegro de Moisés, holocaustos y sacrificios para Dios: y vino Aarón y todos los ancianos de Israel á comer pan con el suegro de Moisés delante de Dios. [^12] Y aconteció que otro día se sentó Moisés á juzgar al pueblo; y el pueblo estuvo delante de Moisés desde la mañana hasta la tarde. [^13] Y viendo el suegro de Moisés todo lo que él hacía con el pueblo, dijo: ¿Qué es esto que haces tú con el pueblo? ¿por qué te sientas tú solo, y todo el pueblo está delante de ti desde la mañana hasta la tarde? [^14] Y Moisés respondió á su suegro: Porque el pueblo viene á mí para consultar á Dios: [^15] Cuando tienen negocios, vienen á mí; y yo juzgo entre el uno y el otro, y declaro las ordenanzas de Dios y sus leyes. [^16] Entonces el suegro de Moisés le dijo: No haces bien: [^17] Desfallecerás del todo, tú, y también este pueblo que está contigo; porque el negocio es demasiado pesado para ti; no podrás hacerlo tú solo. [^18] Oye ahora mi voz; yo te aconsejaré, y Dios será contigo. Está tú por el pueblo delante de Dios, y somete tú los negocios á Dios. [^19] Y enseña á ellos las ordenanzas y las leyes, y muéstrales el camino por donde anden, y lo que han de hacer. [^20] Además inquiere tú de entre todo el pueblo varones de virtud, temerosos de Dios, varones de verdad, que aborrezcan la avaricia; y constituirás á éstos sobre ellos caporales sobre mil, sobre ciento, sobre cincuenta y sobre diez. [^21] Los cuales juzgarán al pueblo en todo tiempo; y será que todo negocio grave lo traerán á ti, y ellos juzgarán todo negocio pequeño: alivia así la carga de sobre ti, y llevarla han ellos contigo. [^22] Si esto hicieres, y Dios te lo mandare, tú podrás persistir, y todo este pueblo se irá también en paz á su lugar. [^23] Y oyó Moisés la voz de su suegro, é hizo todo lo que dijo. [^24] Y escogió Moisés varones de virtud de todo Israel, y púsolos por cabezas sobre el pueblo, caporales sobre mil, sobre ciento, sobre cincuenta, y sobre diez. [^25] Y juzgaban al pueblo en todo tiempo: el negocio árduo traíanlo á Moisés, y ellos juzgaban todo negocio pequeño. [^26] Y despidió Moisés á su suegro, y fuése á su tierra. [^27] 

[[Exodus - 17|<--]] Exodus - 18 [[Exodus - 19|-->]]

---
# Notes
