---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/psalms"
  - "#bible/testament/old"
aliases:
  - "Psalms - 1 - Reina Valera (1602)"
---
Psalms - 1 [[Psalms - 2|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Psalms]]

# Psalms - 1

BIENAVENTURADO el varón que no anduvo en consejo de malos, Ni estuvo en camino de pecadores, Ni en silla de escarnecedores se ha sentado; [^1] Antes en la ley de Jehová está su delicia, Y en su ley medita de día y de noche. [^2] Y será como el árbol plantado junto á arroyos de aguas, Que da su fruto en su tiempo, Y su hoja no cae; Y todo lo que hace, prosperará. [^3] No así los malos: Sino como el tamo que arrebata el viento. [^4] Por tanto no se levantarán los malos en el juicio, Ni los pecadores en la congregación de los justos. [^5] Porque Jehová conoce el camino de los justos; Mas la senda de los malos perecerá. [^6] 

Psalms - 1 [[Psalms - 2|-->]]

---
# Notes
