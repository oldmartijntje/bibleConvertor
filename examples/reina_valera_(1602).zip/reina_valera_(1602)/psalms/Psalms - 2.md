---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/psalms"
  - "#bible/testament/old"
aliases:
  - "Psalms - 2 - Reina Valera (1602)"
---
[[Psalms - 1|<--]] Psalms - 2 [[Psalms - 3|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Psalms]]

# Psalms - 2

¿POR qué se amotinan las gentes, Y los pueblos piensan vanidad? [^1] Estarán los reyes de la tierra, Y príncipes consultarán unidos Contra Jehová, y contra su ungido, diciendo: [^2] Rompamos sus coyundas, Y echemos de nosotros sus cuerdas. [^3] El que mora en los cielos se reirá; El Señor se burlará de ellos. [^4] Entonces hablará á ellos en su furor, Y turbarálos con su ira. [^5] Yo empero he puesto mi rey Sobre Sión, monte de mi santidad. [^6] Yo publicaré el decreto: Jehová me ha dicho: Mi hijo eres tú; Yo te engendré hoy. [^7] Pídeme, y te daré por heredad las gentes, Y por posesión tuya los términos de la tierra. [^8] Quebrantarlos has con vara de hierro: Como vaso de alfarero los desmenuzarás. [^9] Y ahora, reyes, entended: Admitid corrección, jueces de la tierra. [^10] Servid á Jehová con temor, Y alegraos con temblor. [^11] Besad al Hijo, porque no se enoje, y perezcáis en el camino, Cuando se encendiere un poco su furor. Bienaventurados todos los que en él confían. [^12] 

[[Psalms - 1|<--]] Psalms - 2 [[Psalms - 3|-->]]

---
# Notes
