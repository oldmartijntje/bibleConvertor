---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 10 - Reina Valera (1602)"
---
[[2 Samuel - 9|<--]] 2 Samuel - 10 [[2 Samuel - 11|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Samuel]]

# 2 Samuel - 10

DESPUÉS de esto aconteció, que murió el rey de los hijos de Ammón: y reinó en lugar suyo Hanún su hijo. [^1] Y dijo David: Yo haré misericordia con Hanún hijo de Naas, como su padre la hizo conmigo. Y envió David sus siervos á consolarlo por su padre. Mas llegados los siervos de David á la tierra de los hijos de Ammón, [^2] Los príncipes de los hijos de Ammón dijeron á Hanún su señor: ¿Te parece que por honrar David á tu padre te ha enviado consoladores? ¿no ha enviado David sus siervos á ti por reconocer é inspeccionar la ciudad, para destruirla? [^3] Entonces Hanún tomó los siervos de David, y rapóles la mitad de la barba, y cortóles los vestidos por la mitad hasta las nalgas, y despachólos. [^4] Lo cual como fué hecho saber á David, envió á encontrarles, porque ellos estaban en extremo avergonzados; y el rey hizo decir les: Estaos en Jericó hasta que os vuelva á nacer la barba, y entonces regresaréis. [^5] Y viendo los hijos de Ammón que se habían hecho odiosos á David, enviaron los hijos de Ammón y tomaron á sueldo á los Siros de la casa de Rehob, y á los Siros de Soba, veinte mil hombres de á pie: y del rey de Maaca mil hombres, y de Is-tob doce mil hombres. [^6] Lo cual como oyó David, envió á Joab con todo el ejército de los valientes. [^7] Y saliendo los hijos de Ammón, ordenaron sus escuadrones á la entrada de la puerta: mas los Siros de Soba, y de Rehob, y de Is-tob, y de Maaca, estaban de por sí en le campo. [^8] Viendo pues Joab que había escuadrones delante y detrás de él, entresacó de todos los escogidos de Israel, y púsose en orden contra los Siros. [^9] Entregó luego lo que quedó del pueblo en mano de Abisai su hermano, y púsolo en orden para encontrar á los Ammonitas. [^10] Y dijo: Si los Siros me fueren superiores, tú me ayudarás; y si los hijos de Ammón pudieren más que tú, yo te daré ayuda. [^11] Esfuérzate, y esforcémonos por nuestro pueblo, y por las ciudades de nuestro Dios: y haga Jehová lo que bien le pareciere. [^12] Y acercóse Joab, y el pueblo que con él estaba, para pelear con los Siros; mas ellos huyeron delante de él. [^13] Entonces los hijos de Ammón, viendo que los Siros habían huído, huyeron también ellos delante de Abisai, y entráronse en la ciudad. Y volvió Joab de los hijos de Ammón, y vínose á Jerusalem. [^14] Mas viendo los Siros que habían caído delante de Israel, tornáronse á juntar. [^15] Y envió Hadad-ezer, y sacó los Siros que estaban de la otra parte del río, los cuales vinieron á Helam, llevando por jefe á Sobach general del ejército de Hadad-ezer. [^16] Y como fué dado aviso á David, juntó á todo Israel, y pasando el Jordán vino á Helam: y los Siros se pusieron en orden contra David, y pelearon con él. [^17] Mas los Siros huyeron delante de Israel: é hirió David de los Siros la gente de setecientos carros, y cuarenta mil hombres de á caballo: hirió también á Sobach general del ejército, y murió allí. [^18] Viendo pues todos los reyes que asistían á Hadad-ezer, como habían ellos sido derrotados delante de Israel, hicieron paz con Israel, y sirviéronle; y de allí adelante temieron los Siros de socorrer á los hijos de Ammón. [^19] 

[[2 Samuel - 9|<--]] 2 Samuel - 10 [[2 Samuel - 11|-->]]

---
# Notes
