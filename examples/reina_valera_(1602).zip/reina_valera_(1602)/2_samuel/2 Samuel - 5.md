---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 5 - Reina Valera (1602)"
---
[[2 Samuel - 4|<--]] 2 Samuel - 5 [[2 Samuel - 6|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Samuel]]

# 2 Samuel - 5

Y VINIERON todas las tribus de Israel á David en Hebrón, y hablaron, diciendo: He aquí nosotros somos tus huesos y tú carne. [^1] Y aun ayer y antes, cuando Saúl reinaba sobre nosotros, tú sacabas y volvías á Israel. Además Jehová te ha dicho: Tú apacentarás á mi pueblo Israel, y tú serás sobre Israel príncipe. [^2] Vinieron pues todos los ancianos de Israel al rey en Hebrón, y el rey David hizo con ellos alianza en Hebrón delante de Jehová; y ungieron á David por rey sobre Israel. [^3] Era David de treinta años cuando comenzó á reinar, y reinó cuarenta años. [^4] En Hebrón reinó sobre Judá siete años y seis meses: y en Jerusalem reinó treinta y tres años sobre todo Israel y Judá. [^5] Entonces el rey y los suyos fueron á Jerusalem al Jebuseo que habitaba en la tierra; el cual habló á David, diciendo: Tú no entrarás acá, si no echares los ciegos y los cojos; diciendo: No entrará acá David. [^6] Empero David tomó la fortaleza de Sión, la cual es la ciudad de David. [^7] Y dijo David aquel día: ¿Quién llegará hasta las canales, y herirá al Jebuseo, y á los cojos y ciegos, á los cuales el alma de David aborrece? Por esto se dijo: Ciego ni cojo no entrará en casa. [^8] Y David moró en la fortaleza y púsole por nombre la Ciudad de David: y edificó alrededor, desde Millo para adentro. [^9] Y David iba creciendo y aumentándose, y Jehová Dios de los ejércitos era con él. [^10] E Hiram rey de Tiro envió también embajadores á David, y madera de cedro, y carpinteros, y canteros para los muros, los cuales edificaron la casa de David. [^11] Y entendió David que Jehová le había confirmado por rey sobre Israel, y que había ensalzado su reino por amor de su pueblo Israel. [^12] Y tomó David más concubinas y mujeres de Jerusalem después que vino de Hebrón, y naciéronle más hijos é hijas. [^13] Estos son los nombres de los que le nacieron en Jerusalem: Sammua, y Sobab, y Nathán, y Salomón, [^14] E Ibhar, y Elisua, y Nepheg, [^15] Y Japhia, y Elisama, y Eliada, y Eliphelet. [^16] Y oyendo los Filisteos que habían ungido á David por rey sobre Israel, todos los Filisteos subieron á buscar á David: lo cual como David oyó, vino á la fortaleza. [^17] Y vinieron los Filisteos, y extendiéronse por el valle de Raphaim. [^18] Entonces consultó David á Jehová, diciendo: ¿Iré contra los Filisteos? ¿los entregarás en mis manos? Y Jehová respondió á David: Ve, porque ciertamente entregaré los Filisteos en tus manos. [^19] Y vino David á Baal-perasim, y allí los venció David, y dijo: Rompió Jehová mis enemigos delante de mí, como quien rompe aguas. Y por esto llamó el nombre de aquel lugar Baal-perasim. [^20] Y dejaron allí sus ídolos, los cuales quemó David y los suyos. [^21] Y los Filisteos tornaron á venir, y extendiéronse en el valle de Raphaim. [^22] Y consultando David á Jehová, él le respondió: No subas; mas rodéalos, y vendrás á ellos por delante de los morales: [^23] Y cuando oyeres un estruendo que irá por las copas de los morales, entonces te moverás; porque Jehová saldrá delante de ti á herir el campo de los Filisteos. [^24] Y David lo hizo así, como Jehová se lo había mandado; é hirió á los Filisteos desde Gabaa hasta llegar á Gaza. [^25] 

[[2 Samuel - 4|<--]] 2 Samuel - 5 [[2 Samuel - 6|-->]]

---
# Notes
