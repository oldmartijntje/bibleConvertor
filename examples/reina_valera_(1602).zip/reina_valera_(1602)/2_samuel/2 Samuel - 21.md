---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 21 - Reina Valera (1602)"
---
[[2 Samuel - 20|<--]] 2 Samuel - 21 [[2 Samuel - 22|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Samuel]]

# 2 Samuel - 21

Y EN los días de David hubo hambre por tres años consecutivos. Y David consultó á Jehová, y Jehová le dijo: Es por Saúl, y por aquella casa de sangre; porque mató á los Gabaonitas. [^1] Entonces el rey llamó á los Gabaonitas, y hablóles. (Los Gabaonitas no eran de los hijos de Israel, sino del residuo de los Amorrheos, á los cuales los hijos de Israel habían hecho juramento: mas Saúl había procurado matarlos con motivo de celo por los hijos de Israel y de Judá.) [^2] Dijo pues David á los Gabaonitas: ¿Qué os haré, y con qué expiaré para que bendigáis á la heredad de Jehová? [^3] Y los Gabaonitas le respondieron: No tenemos nosotros querella sobre plata ni sobre oro con Saúl, y con su casa: ni queremos que muera hombre de Israel. Y él les dijo: Lo que vosotros dijereis os haré. [^4] Y ellos respondieron al rey: De aquel hombre que nos destruyó, y que maquinó contra nosotros, para extirparnos sin dejar nada de nosotros en todo el término de Israel; [^5] Dénsenos siete varones de sus hijos, para que los ahorquemos á Jehová en Gabaa de Saúl, el escogido de Jehová. Y el rey dijo: Yo los daré. [^6] Y perdonó el rey á Mephi-boseth, hijo de Jonathán, hijo de Saúl, por el juramento de Jehová que hubo entre ellos, entre David y Jonathán hijo de Saúl. [^7] Mas tomó el rey dos hijos de Rispa hija de Aja, los cuales ella había parido á Saúl, á saber, á Armoni y á Mephi-boseth; y cinco hijos de Michâl hija de Saúl, los cuales ella había parido á Adriel, hijo de Barzillai Molathita; [^8] Y entrególos en manos de los Gabaonitas, y ellos los ahorcaron en el monte delante de Jehová: y murieron juntos aquellos siete, lo cuales fueron muertos en el tiempo de la siega, en los primeros días, en el principio de la siega de las cebadas. [^9] Tomando luego Rispa hija de Aja un saco, tendióselo sobre un peñasco, desde el principio de la siega hasta que llovió sobre ellos agua del cielo; y no dejó á ninguna ave del cielo asentarse sobre ellos de día, ni bestias del campo de noche. [^10] Y fué dicho á David lo que hacía Rispa hija de Aja, concubina de Saúl. [^11] Entonces David fué, y tomó los huesos de Saúl y los huesos de Jonathán su hijo, de los hombres de Jabes de Galaad, que los habían hurtado de la plaza de Beth-san, donde los habían colgado los Filisteos, cuando deshicieron los Filisteos á Saúl en Gilboa: [^12] E hizo llevar de allí los huesos de Saúl y los huesos de Jonathán su hijo; y juntaron también los huesos de los ahorcados. [^13] Y sepultaron los huesos de Saúl y los de su hijo Jonathán en tierra de Benjamín, en Sela, en el sepulcro de Cis su padre; é hicieron todo lo que el rey había mandado. Después se aplacó Dios con la tierra. [^14] Y como los Filisteos tornaron á hacer guerra á Israel, descendió David y sus siervos con él, y pelearon con los Filisteos: y David se cansó. [^15] En esto Isbi-benob, el cual era de los hijos del gigante, y el peso de cuya lanza era de trescientos siclos de metal, y tenía él ceñida una nueva espada, trató de herir á David: [^16] Mas Abisai hijo de Sarvia le socorrió, é hirió al Filisteo, y matólo. Entonces los hombres de David le juraron, diciendo: Nunca más de aquí adelante saldrás con nosotros á batalla, porque no apagues la lámpara de Israel. [^17] Otra segunda guerra hubo después en Gob contra los Filisteos: entonces Sibechâi Husathita hirió á Saph, que era de los hijos del gigante. [^18] Otra guerra hubo en Gob contra los Filisteos, en la cual Elhanan, hijo de Jaare-oregim de Beth-lehem, hirió á Goliath Getheo, el asta de cuya lanza era como un enjullo de telar. [^19] Después hubo otra guerra en Gath, donde hubo un hombre de grande altura, el cual tenía doce dedos en las manos, y otros doce en los pies, veinticuatro en todos: y también era de lo hijos del gigante. [^20] Este desafió á Israel, y matólo Jonathán, hijo de Sima hermano de David. [^21] Estos cuatro le habían nacido al gigante en Gath, los cuales cayeron por la mano de David, y por la mano de sus siervos. [^22] 

[[2 Samuel - 20|<--]] 2 Samuel - 21 [[2 Samuel - 22|-->]]

---
# Notes
