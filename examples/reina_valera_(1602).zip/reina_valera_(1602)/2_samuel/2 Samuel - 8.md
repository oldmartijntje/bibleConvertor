---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 8 - Reina Valera (1602)"
---
[[2 Samuel - 7|<--]] 2 Samuel - 8 [[2 Samuel - 9|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Samuel]]

# 2 Samuel - 8

DESPUÉS de esto aconteció, que David hirió á los Filisteos, y los humilló: y tomó David á Methegamma de mano de los Filisteos. [^1] Hirió también á los de Moab, y midiólos con cordel, haciéndolos echar por tierra; y midió con dos cordeles para muerte, y un cordel entero para vida; y fueron los Moabitas siervos debajo de tributo. [^2] Asimismo hirió David á Hadad-ezer hijo de Rehob, rey de Soba, yendo él á extender su término hasta el río de Eufrates. [^3] Y tomó David de ellos mil y setecientos de á caballo, y veinte mil hombres de á pie; y desjarretó David los caballos de todos los carros, excepto cien carros de ellos que dejó. [^4] Y vinieron los Siros de Damasco á dar ayuda á Hadad-ezer rey de Soba; y David hirió de los Siros veinte y dos mil hombres. [^5] Puso luego David guarnición en Siria la de Damasco, y fueron los Siros siervos de David sujetos á tributo. Y Jehová guardó á David donde quiere que fué. [^6] Y tomó David los escudos de oro que traían los siervos de Hadad-ezer, y llevólos á Jerusalem. [^7] Asimismo de Beta y de Beeroth, ciudades de Hadad-ezer, tomó el rey David gran copia de metal. [^8] Entonces oyendo Toi, rey de Hamath, que David había herido todo el ejército de Hadad-ezer, [^9] Envió Toi á Joram su hijo al rey David, á saludarle pacíficamente y á bendecirle, porque había peleado con Hadad-ezer y lo había vencido: porque Toi era enemigo de Hadad-ezer. Y Joram llevaba en su mano vasos de plata, y vasos de oro, y de metal; [^10] Los cuales el rey David dedicó á Jehová, con la plata y el oro que tenía dedicado de todas las naciones que había sometido: [^11] De los Siros, de los Moabitas, de los Ammonitas, de los Filisteos, de los Amalecitas, y del despojo de Hadad-ezer hijo de Rehob, rey de Soba. [^12] Y ganó David fama cuando, volviendo de la rota de los Siros, hirió diez y ocho mil hombres en el valle de la sal. [^13] Y puso guarnición en Edom, por toda Edom puso guarnición; y todos los Idumeos fueron siervos de David. Y Jehová guardó á David por donde quiera que fué. [^14] Y reinó David sobre todo Israel; y hacía David derecho y justicia á todo su pueblo. [^15] Y Joab hijo de Sarvia era general de su ejército; y Josaphat hijo de Ahilud, canciller; [^16] Y Sadoc hijo de Ahitud, y Ahimelech hijo de Abiathar, eran sacerdotes; y Seraía era escriba; [^17] Y Benahía hijo de Joiada, era sobre los Ceretheos y Peletheos; y los hijos de David eran los príncipes. [^18] 

[[2 Samuel - 7|<--]] 2 Samuel - 8 [[2 Samuel - 9|-->]]

---
# Notes
