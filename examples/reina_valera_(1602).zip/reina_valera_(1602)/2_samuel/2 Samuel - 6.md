---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 6 - Reina Valera (1602)"
---
[[2 Samuel - 5|<--]] 2 Samuel - 6 [[2 Samuel - 7|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Samuel]]

# 2 Samuel - 6

Y DAVID tornó á juntar todos los escogidos de Israel, treinta mil. [^1] Y levantóse David, y fué con todo el pueblo que tenía consigo, de Baal de Judá, para hacer pasar de allí el arca de Dios, sobre la cual era invocado el nombre de Jehová de los ejércitos, que mora en ella entre los querubines. [^2] Y pusieron el arca de Dios sobre un carro nuevo, y lleváronla de la casa de Abinadab, que estaba en Gabaa: y Uzza y Ahio, hijos de Abinadab, guiaban el carro nuevo. [^3] Y cuando lo llevaban de la casa de Abinadab que estaba en Gabaa, con el arca de Dios, Ahio iba delante del arca. [^4] Y David y toda la casa de Israel danzaban delante de Jehová con toda suerte de instrumentos de madera de haya; con arpas, salterios, adufes, flautas y címbalos. [^5] Y cuando llegaron á la era de Nachôn, Uzza extendió la mano al arca de Dios, y túvola; porque los bueyes daban sacudidas. [^6] Y el furor de Jehová se encendió contra Uzza, é hiriólo allí Dios por aquella temeridad, y cayó allí muerto junto al arca de Dios. [^7] Y entristecióse David por haber herido Jehová á Uzza: y fué llamado aquel lugar Pérez-uzza, hasta hoy. [^8] Y temiendo David á Jehová aquel día, dijo: ¿Cómo ha de venir á mí el arca de Jehová? [^9] No quiso pues David traer á sí el arca de Jehová á la ciudad de David; mas llevóla David á casa de Obed-edom Getheo. [^10] Y estuvo el arca de Jehová en casa de Obed-edom Getheo tres meses: y bendijo Jehová á Obed-edom y á toda su casa. [^11] Y fué dado aviso al rey David, diciendo: Jehová ha bendecido la casa de Obed-edom, y todo lo que tiene, á causa del arca de Dios. Entonces David fué, y trajo el arca de Dios de casa de Obed-edom á la ciudad de David con alegría. [^12] Y como los que llevaban el arca de Dios habían andado seis pasos, sacrificaban un buey y un carnero grueso. [^13] Y David saltaba con toda su fuerza delante de Jehová; y tenía vestido David un ephod de lino. [^14] Así David y toda la casa de Israel llevaban el arca de Jehová con júbilo y sonido de trompeta. [^15] Y como el arca de Jehová llegó á la ciudad de David, aconteció que Michâl hija de Saúl miró desde una ventana, y vió al rey David que saltaba con toda su fuerza delante de Jehová: y menosprecióle en su corazón. [^16] Metieron pues el arca de Jehová, y pusiéronla en su lugar en medio de una tienda que David le había tendido: y sacrificó David holocaustos y pacíficos delante de Jehová. [^17] Y como David hubo acabado de ofrecer los holocaustos y pacíficos, bendijo al pueblo en el nombre de Jehová de los ejércitos. [^18] Y repartió á todo el pueblo, y á toda la multitud de Israel, así á hombres como á mujeres, á cada uno una torta de pan, y un pedazo de carne, y un frasco de vino. Y fuése todo el pueblo, cada uno á su casa. [^19] Volvió luego David para bendecir su casa: y saliendo Michâl á recibir á David, dijo: ­Cuán honrado ha sido hoy el rey de Israel, desnudándose hoy delante de las criadas de sus siervos, como se desnudara un juglar! [^20] Entonces David respondió á Michâl: Delante de Jehová, que me eligió más bien que á tu padre y á toda su casa, mandándome que fuese príncipe sobre el pueblo de Jehová, sobre Israel, danzaré delante de Jehová. [^21] Y aun me haré más vil que esta vez, y seré bajo á mis propios ojos; y delante de las criadas que dijiste, delante de ellas seré honrado. [^22] Y Michâl hija de Saúl nunca tuvo hijos hasta el día de su muerte. [^23] 

[[2 Samuel - 5|<--]] 2 Samuel - 6 [[2 Samuel - 7|-->]]

---
# Notes
