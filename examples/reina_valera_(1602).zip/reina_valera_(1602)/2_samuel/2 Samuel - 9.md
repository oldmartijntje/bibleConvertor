---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 9 - Reina Valera (1602)"
---
[[2 Samuel - 8|<--]] 2 Samuel - 9 [[2 Samuel - 10|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Samuel]]

# 2 Samuel - 9

Y DIJO David: ¿Ha quedado alguno de la casa de Saúl, á quien haga yo misericordia por amor de Jonathán? [^1] Y había un siervo de la casa de Saúl, que se llamaba Siba, al cual como llamaron que viniese á David, el rey le dijo: ¿Eres tú Siba? Y él respondió: Tu siervo. [^2] Y el rey dijo: ¿No ha quedado nadie de la casa de Saúl, á quien haga yo misericordia de Dios? Y Siba respondió al rey: Aun ha quedado un hijo de Jonathán, lisiado de los pies. [^3] Entonces el rey le dijo: ¿Y ése dónde está? Y Siba respondió al rey: He aquí, está en casa de Machîr hijo de Amiel, en Lodebar. [^4] Y envió el rey David, y tomólo de casa de Machîr hijo de Amiel, de Lodebar. [^5] Y venido Mephi-boseth, hijo de Jonathán hijo de Saúl, á David, postróse sobre su rostro, é hizo reverencia. Y dijo David: Mephi-boseth. Y él respondió: He aquí tu siervo. [^6] Y díjole David: No tengas temor, porque yo á la verdad haré contigo misericordia por amor de Jonathán tu padre, y te haré volver todas las tierras de Saúl tu padre; y tú comerás siempre pan á mi mesa. [^7] Y él inclinándose, dijo: ¿Quién es tu siervo, para que mires á un perro muerto como yo? [^8] Entonces el rey llamó á Siba, siervo de Saúl, y díjole: Todo lo que fué de Saúl y de toda su casa, yo lo he dado al hijo de tu señor. [^9] Tú pues le labrarás las tierras, tú con tus hijos, y tus siervos, y encerrarás los frutos, para que el hijo de tu Señor tenga con qué mantenerse; y Mephi-boseth el hijo de tu señor tenga con qué mantenerse; y Mephi-boseth el hijo de tu señor comerá siempre pan á mi mesa. Y tenía Siba quince hijos y veinte siervos. [^10] Y respondió Siba al rey: Conforme á todo lo que ha mandado mi Señor el rey á su siervo, así lo hará tu siervo. Mephi-boseth, dijo el rey, comerá á mi mesa, como uno de los hijos del rey. [^11] Y tenía Mephi-boseth un hijo pequeño, que se llamaba Michâ. Y toda la familia de la casa de Siba eran siervos de Mephi-boseth. [^12] Y moraba Mephi-boseth en Jerusalem, porque comía siempre á la mesa del rey; y era cojo de ambos pies. [^13] 

[[2 Samuel - 8|<--]] 2 Samuel - 9 [[2 Samuel - 10|-->]]

---
# Notes
