---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 11 - Reina Valera (1602)"
---
[[2 Samuel - 10|<--]] 2 Samuel - 11 [[2 Samuel - 12|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Samuel]]

# 2 Samuel - 11

Y ACONTECIO á la vuelta de un año, en el tiempo que salen los reyes á la guerra, que David envió á Joab, y á sus siervos con él, y á todo Israel; y destruyeron á los Ammonitas, y pusieron cerco á Rabba: mas David se quedó en Jerusalem. [^1] Y acaeció que levantándose David de su cama á la hora de la tarde, paseábase por el terrado de la casa real, cuando vió desde el terrado una mujer que se estaba lavando, la cual era muy hermosa. [^2] Y envió David á preguntar por aquella mujer, y dijéronle: Aquella es Bath-sheba hija de Eliam, mujer de Uría Hetheo. [^3] Y envió David mensajeros, y tomóla: y así que hubo entrado á él, él durmió con ella. Purificóse luego ella de su inmundicia, y se volvió á su casa. [^4] Y concibió la mujer, y enviólo á hacer saber á David, diciendo: Yo estoy embarazada. [^5] Entonces David envió á decir á Joab: Envíame á Uría Hetheo. Y enviólo Joab á David. [^6] Y como Uría vino á él, preguntóle David por la salud de Joab, y por la salud del pueblo, y asimismo de la guerra. [^7] Después dijo David á Uría: Desciende á tu casa, y lava tus pies. Y saliendo Uría de casa del rey, vino tras de él comida real. [^8] Mas Uría durmió á la puerta de la casa del rey con todos los siervos de su señor, y no descendió á su casa. [^9] E hicieron saber esto á David, diciendo: Uría no ha descendido á su casa. Y dijo David á Uría: ¿No has venido de camino? ¿por qué pues no descendiste á tu casa? [^10] Y Uría respondió á David: El arca, é Israel y Judá, están debajo de tiendas; y mi señor Joab, y los siervos de mi señor sobre la haz del campo: ¿y había yo de entrar en mi casa para comer y beber, y á dormir con mi mujer? Por vida tuya, y por vida de tu alma, que yo no haré tal cosa. [^11] Y David dijo á Uría: Estáte aquí aún hoy, y mañana te despacharé. Y quedóse Uría en Jerusalem aquel día y el siguiente. [^12] Y David lo convidó, é hízole comer y beber delante de sí, hasta embriagarlo. Y él salió á la tarde á dormir en su cama con los siervos de su señor; mas no descendió á su casa. [^13] Venida la mañana, escribió David á Joab una carta, la cual envió por mano de Uría. [^14] Y escribió en la carta, diciendo: Poned á Uría delante de la fuerza de la batalla, y desamparadle, para que sea herido y muera. [^15] Así fué que cuando Joab cercó la ciudad, puso á Uría en el lugar donde sabía que estaban los hombres más valientes. [^16] Y saliendo luego los de la ciudad, pelearon con Joab, y cayeron algunos del pueblo de los siervos de David; y murió también Uría Hetheo. [^17] Entonces envió Joab, é hizo saber á David todos los negocios de la guerra. [^18] Y mandó al mensajero, diciendo: Cuando acabares de contar al rey todos los negocios de la guerra, [^19] Si el rey comenzare á enojarse, y te dijere: ¿Por qué os acercasteis á la ciudad peleando? ¿no sabíais lo que suelen arrojar del muro? [^20] ¿Quién hirió á Abimelech hjo de Jerobaal? ¿no echó una mujer del muro un pedazo de una rueda de molino, y murió en Thebes? ¿por qué os llegasteis al muro?: entonces tú le dirás: También tu siervo Uría Hetheo es muerto. [^21] Y fué el mensajero, y llegando, contó á David todas las cosas á que Joab le había enviado. [^22] Y dijo el mensajero á David: Prevalecieron contra nosotros los hombres, que salieron á nosotros al campo, bien que nosotros les hicimos retroceder hasta la entrada de la puerta; [^23] Pero los flecheros tiraron contra tus siervos desde el muro, y murieron algunos de los siervos del rey; y murió también tu siervo Uría Hetheo. [^24] Y David dijo al mensajero: Dirás así á Joab: No tengas pesar de esto, que de igual y semejante manera suele consumir la espada: esfuerza la batalla contra la ciudad, hasta que la rindas. Y tú aliéntale. [^25] Y oyendo la mujer de Uría que su marido Uría era muerto, hizo duelo por su marido. [^26] Y pasado el luto, envió David y recogióla á su casa: y fué ella su mujer, y parióle un hijo. Mas esto que David había hecho, fué desagradable á los ojos de Jehová. [^27] 

[[2 Samuel - 10|<--]] 2 Samuel - 11 [[2 Samuel - 12|-->]]

---
# Notes
