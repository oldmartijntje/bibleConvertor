---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 16 - Reina Valera (1602)"
---
[[2 Samuel - 15|<--]] 2 Samuel - 16 [[2 Samuel - 17|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Samuel]]

# 2 Samuel - 16

Y como David pasó un poco de la cumbre del monte, he aquí Siba, el criado de Mephi-boseth, que lo salía á recibir con un par de asnos enalbardados, y sobre ellos doscientos panes, y cien hilos de pasas, y cien panes de higos secos, y un cuero de vino. [^1] Y dijo el rey á Siba: ¿Qué es esto? Y Siba respondió: Los asnos son para la familia del rey, en que suban; los panes y la pasa para los criados, que coman; y el vino, para que beban los que se cansaren en el desierto. [^2] Y dijo el rey: ¿Dónde está el hijo de tu señor? Y Siba respondió al rey: He aquí él se ha quedado en Jerusalem, porque ha dicho: Hoy me devolverá la casa de Israel el reino de mi padre. [^3] Entonces el rey dijo á Siba: He aquí, sea tuyo todo lo que tiene Mephi-boseth. Y respondió Siba inclinándose: Rey señor mío, halle yo gracia delante de ti. [^4] Y vino el rey David hasta Bahurim: y he aquí, salía uno de la familia de la casa de Saúl, el cual se llamaba Semei, hijo de Gera; y salía maldiciendo, [^5] Y echando piedras contra David, y contra todos los siervos del rey David: y todo el pueblo, y todos los hombres valientes estaban á su diestra y á su siniestra. [^6] Y decía Semei, maldiciéndole: Sal, sal, varón de sangres, y hombre de Belial; [^7] Jehová te ha dado el pago de toda la sangre de la casa de Saúl, en lugar del cual tú has reinado: mas Jehová ha entregado el reino en mano de tu hijo Absalom; y hete aquí sorprendido en tu maldad, porque eres varón de sangres. [^8] Entonces Abisai hijo de Sarvia, dijo al rey: ¿Por qué maldice este perro muerto á mi señor el rey? Yo te ruego que me dejes pasar, y quitaréle la cabeza. [^9] Y el rey respondió: ¿Qué tengo yo con vosotros, hijos de Sarvia? El maldice así, porque Jehová le ha dicho que maldiga á David; ¿quién pues le dirá: Por qué lo haces así? [^10] Y dijo David á Abisai y á todos sus siervos: He aquí, mi hijo que ha salido de mis entrañas, acecha á mi vida: ¿cuánto más ahora un hijo de Benjamín? Dejadle que maldiga, que Jehová se lo ha dicho. [^11] Quizá mirará Jehová á mi aflicción, y me dará Jehová bien por sus maldiciones de hoy. [^12] Y como David y los suyos iban por el camino, Semei iba por el lado del monte delante de él, andando y maldiciendo, y arrojando piedras delante de él, y esparciendo polvo. [^13] Y el rey y todo el pueblo que con él estaba, llegaron fatigados, y descansaron allí. [^14] Y Absalom y todo el pueblo, los varones de Israel, entraron en Jerusalem, y con él Achitophel. [^15] Y acaeció luego, que como Husai Arachîta amigo de David hubo llegado á Absalom, díjole Husai: Viva el rey, viva el rey. [^16] Y Absalom dijo á Husai: ¿Este es tu agradecimiento para con tu amigo? ¿por qué no fuiste con tu amigo? [^17] Y Husai respondió á Absalom: No: antes al que eligiere Jehová y este pueblo y todos los varones de Israel, de aquél seré yo, y con aquél quedaré. [^18] ¿Y á quién había yo de servir? ¿no es á su hijo? Como he servido delante de tu padre, así seré delante de ti. [^19] Entonces dijo Absalom á Achitophel: Consultad qué haremos. [^20] Y Achitophel dijo á Absalom: Entra á las concubinas de tu padre, que él dejó para guardar la casa; y todo el pueblo de Israel oirá que te has hecho aborrecible á tu padre, y así se esforzarán las manos de todos los que están contigo. [^21] Entonces pusieron una tienda á Absalom sobre el terrado, y entró Absalom á las concubinas de su padre, en ojos de todo Israel. [^22] Y el consejo que daba Achitophel en aquellos días, era como si consultaran la palabra de Dios. Tal era el consejo de Achitophel, así con David como con Absalom. [^23] 

[[2 Samuel - 15|<--]] 2 Samuel - 16 [[2 Samuel - 17|-->]]

---
# Notes
