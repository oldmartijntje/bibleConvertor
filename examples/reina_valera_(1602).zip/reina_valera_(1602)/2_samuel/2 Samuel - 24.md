---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 24 - Reina Valera (1602)"
---
[[2 Samuel - 23|<--]] 2 Samuel - 24

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Samuel]]

# 2 Samuel - 24

Y VOLVIO el furor de Jehová á encenderse contra Israel, é incitó á David contra ellos á que dijese: Ve, cuenta á Israel y á Judá. [^1] Y dijo el rey á Joab, general del ejército que tenía consigo: Rodea todas las tribus de Israel, desde Dan hasta Beer-seba, y contad el pueblo, para que yo sepa el número de la gente. [^2] Y Joab respondió al rey: Añada Jehová tu Dios al pueblo cien veces tanto como son, y que lo vea mi señor al rey; mas ¿para qué quiere esto mi señor el rey? [^3] Empero la palabra del rey pudo más que Joab, y que los capitanes del ejército. Salió pues Joab, con los capitanes del ejército, de delante del rey, para contar el pueblo de Israel. [^4] Y pasando el Jordán asentaron en Aroer, á la mano derecha de la ciudad que está en medio de la arroyada de Gad y junto á Jazer. [^5] Después vinieron á Galaad, y á la tierra baja de Absi: y de allí vinieron á Dan-jaán y alrededor de Sidón. [^6] Y vinieron luego á la fortaleza de Tiro, y á todas las ciudades de los Heveos y de los Cananeos; y salieron al mediodía de Judá, á Beer-seba. [^7] Y después que hubieron andado toda la tierra, volvieron á Jerusalem al cabo de nueve meses y veinte días. [^8] Y Joab dió la cuenta del número del pueblo al rey; y fueron los de Israel ochocientos mil hombres fuertes que sacaban espada; y de los de Judá quinientos mil hombres. [^9] Y después que David hubo contado el pueblo, punzóle su corazón; y dijo David á Jehová: Yo he pecado gravemente por haber hecho esto; mas ahora, oh Jehová, ruégote que quites el pecado de tu siervo, porque yo he obrado muy neciamente. [^10] Y por la mañana, cuando David se hubo levantado, fué palabra de Jehová á Gad profeta, vidente de David, diciendo: [^11] Ve, y di á David: Así ha dicho Jehová: Tres cosas te ofrezco: tú te escogerás una de ellas, la cual yo haga. [^12] Vino pues Gad á David, é intimóle, y díjole: ¿Quieres que te vengan siete años de hambre en tu tierra? ¿ó que huyas tres meses delante de tus enemigos, y que ellos te persigan? ¿o que tres días haya pestilencia en tu tierra? Piensa ahora, y mira qué responderé al que me ha enviado. [^13] Entonces David dijo á Gad: En grande angustia estoy: ruego que caiga en la mano de Jehová, porque sus miseraciones son muchas, y que no caiga yo en manos de hombres. [^14] Y envió Jehová pestilencia á Israel desde la mañana hasta el tiempo señalado: y murieron del pueblo, desde Dan hasta Beer-seba, setenta mil hombres. [^15] Y como el ángel extendió su mano sobre Jerusalem para destruirla, Jehová se arrepintió de aquel mal, y dijo al ángel que destruía el pueblo: Basta ahora; detén tu mano. Entonces el ángel de Jehová estaba junto á la era de Arauna Jebuseo. [^16] Y David dijo á Jehová, cuando vió al ángel que hería al pueblo: Yo pequé, yo hice la maldad: ¿qué hicieron estas ovejas? Ruégote que tu mano se torne contra mí, y contra la casa de mi padre. [^17] Y Gad vino á David aquel día, y díjole: Sube, y haz un altar á Jehová en la era de Arauna Jebuseo. [^18] Y subió David, conforme al dicho de Gad, que Jehová le había mandado. [^19] Y mirando Arauna, vió al rey y á sus siervos que pasaban á él. Saliendo entonces Arauna, inclinóse delante del rey hacia tierra. [^20] Y Arauna dijo: ¿Por qué viene mi señor el rey á su siervo? Y David respondió: Para comprar de ti la era, para edificar altar á Jehová, á fin de que la mortandad cese del pueblo. [^21] Y Arauna dijo á David: Tome y sacrifique mi señor el rey lo que bien le pareciere; he aquí bueyes para el holocausto; y trillos y otros pertrechos de bueyes para leña: [^22] Todo lo da como un rey Arauna al rey. Luego dijo Arauna al rey: Jehová tu Dios te sea propicio. [^23] Y el rey dijo á Arauna: No, sino por precio te lo compraré; porque no ofreceré á Jehová mi Dios holocaustos por nada. Entonces David compró la era y los bueyes por cincuenta siclos de plata. [^24] Y edificó allí David un altar á Jehová, y sacrificó holocaustos y pacíficos; y Jehová se aplacó con la tierra, y cesó la plaga de Israel. [^25] 

[[2 Samuel - 23|<--]] 2 Samuel - 24

---
# Notes
