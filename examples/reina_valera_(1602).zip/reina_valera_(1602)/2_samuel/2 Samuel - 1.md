---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 1 - Reina Valera (1602)"
---
2 Samuel - 1 [[2 Samuel - 2|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Samuel]]

# 2 Samuel - 1

Y ACONTECIO después de la muerte de Saúl, que vuelto David de la derrota de los Amalecitas, estuvo dos días en Siclag: [^1] Y al tercer día acaeció, que vino uno del campo de Saúl, rotos sus vestidos, y tierra sobre su cabeza: y llegando á David, postróse en tierra, é hizo reverencia. [^2] Y preguntóle David: ¿De dónde vienes? Y él respondió: Heme escapado del campo de Israel. [^3] Y David le dijo: ¿Qué ha acontecido? ruégote que me lo digas. Y él respondió: El pueblo huyó de la batalla, y también muchos del pueblo cayeron y son muertos: también Saúl y Jonathán su hijo murieron. [^4] Y dijo David á aquel mancebo que le daba las nuevas: ¿Cómo sabes que Saúl es muerto, y Jonathán su hijo? [^5] Y el mancebo que le daba las nuevas respondió: Casualmente vine al monte de Gilboa, y hallé á Saúl que estaba recostado sobre su lanza, y venían tras él carros y gente de á caballo. [^6] Y como él miró atrás, vióme y llamóme; y yo dije: Heme aquí. [^7] Y él me dijo: ¿Quién eres tú? Y yo le respondí: Soy Amalecita. [^8] Y él me volvió á decir: Yo te ruego que te pongas sobre mí, y me mates, porque me toman angustias, y toda mi alma está aún en mí. [^9] Yo entonces púseme sobre él, y matélo, porque sabía que no podía vivir después de su caída: y tomé la corona que tenía en su cabeza, y la ajorca que traía en su brazo, y helas traído acá á mi señor. [^10] Entonces David trabando de sus vestidos, rompiólos; y lo mismo hicieron los hombres que estaban con él. [^11] Y lloraron y lamentaron, y ayunaron hasta la tarde, por Saúl y por Jonathán su hijo, y por el pueblo de Jehová, y por la casa de Israel: porque habían caído á cuchillo. [^12] Y David dijo á aquel mancebo que le había traído las nuevas: ¿De dónde eres tú? Y él respondió: Yo soy hijo de un extranjero, Amalecita. [^13] Y díjole David: ¿Cómo no tuviste temor de extender tu mano para matar al ungido de Jehová? [^14] Entonces llamó David uno de los mancebos, y díjole: Llega, y mátalo. Y él lo hirió, y murió. [^15] Y David le dijo: Tu sangre sea sobre tu cabeza, pues que tu boca atestiguó contra ti, diciendo: Yo maté al ungido de Jehová. [^16] Y endechó David á Saúl y á Jonathán su hijo con esta endecha. [^17] (Dijo también que enseñasen al arco á los hijos de Judá. He aquí que está escrito en el libro del derecho:) [^18] Perecido ha la gloria de Israel sobre tus montañas! ­Cómo han caído los valientes! [^19] No lo denunciéis en Gath, No deis las nuevas en las plazas de Ascalón; Porque no se alegren las hijas de los Filisteos, Porque no salten de gozo las hijas de los incircuncisos. [^20] Montes de Gilboa, Ni rocío ni lluvia caiga sobre vosotros, ni seáis tierras de ofrendas; Porque allí fué desechado el escudo de los valientes, El escudo de Saúl, como si no hubiera sido ungido con aceite. [^21] Sin sangre de muertos, sin grosura de valientes, El arco de Jonathán nunca volvió, Ni la espada de Saúl se tornó vacía. [^22] Saúl y Jonathán, amados y queridos en su vida, En su muerte tampoco fueron apartados: Más ligeros que águilas, Más fuertes que leones. [^23] Hijas de Israel, llorad sobre Saúl, Que os vestía de escarlata en regocijos, Que adornaba vuestras ropas con ornamentos de oro. [^24] Cómo han caído los valientes en medio de la batalla! ­Jonathán, muerto en tus alturas! [^25] Angustia tengo por ti, hermano mío Jonathán, Que me fuiste muy dulce: Más maravilloso me fué tu amor, Que el amor de las mujeres. [^26] Cómo han caído los valientes, Y perecieron las armas de guerra! [^27] 

2 Samuel - 1 [[2 Samuel - 2|-->]]

---
# Notes
