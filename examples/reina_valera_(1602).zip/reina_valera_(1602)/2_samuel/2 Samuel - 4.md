---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 4 - Reina Valera (1602)"
---
[[2 Samuel - 3|<--]] 2 Samuel - 4 [[2 Samuel - 5|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[2 Samuel]]

# 2 Samuel - 4

LUEGO que oyó el hijo de Saúl que Abner había sido muerto en Hebrón, las manos se le descoyuntaron, y fué atemorizado todo Israel. [^1] Y tenía el hijo de Saúl dos varones, los cuales eran capitanes de compañía, el nombre de uno era Baana, y el del otro Rechâb, hijos de Rimmón Beerothita, de los hijos de Benjamín: (porque Beeroth era contada con Benjamín; [^2] Estos Beerothitas se habían huído á Gittaim, y habían sido peregrinos allí hasta entonces.) [^3] Y Jonathán, hijo de Saúl, tenía un hijo lisiado de los pies de edad de cinco años: que cuando la noticia de la muerte de Saúl y de Jonathán vino de Jezreel, tomóle su ama y huyó; y como iba huyendo con celeridad, cayó el niño y quedó cojo. Su nombre era Mephi-boseth. [^4] Los hijos pues de Rimmón Beerothita, Rechâb y Baana, fueron y entraron en el mayor calor del día en casa de Is-boseth, el cual estaba durmiendo en su cámara la siesta. [^5] Entonces entraron ellos en medio de la casa en hábito de mercaderes de grano, y le hirieron en la quinta costilla. Escapáronse luego Rechâb y Baana su hermano; [^6] Pues como entraron en la casa, estando él en su cama en su cámara de dormir, lo hirieron y mataron, y cortáronle la cabeza, y habiéndola tomado, caminaron toda la noche por el camino de la campiña. [^7] Y trajeron la cabeza de Is-boseth á David en Hebrón, y dijeron al rey: He aquí la cabeza de Is-boseth hijo de Saúl tu enemigo, que procuraba matarte; y Jehová ha vengado hoy á mi señor el rey, de Saúl y de su simiente. [^8] Y David respondió á Rechâb y á su hermano Baana, hijos de Rimmón Beerothita, y díjoles: Vive Jehová que ha redimido mi alma de toda angustia, [^9] Que cuando uno me dió nuevas, diciendo: He aquí Saúl es muerto imaginándose que traía buenas nuevas, yo lo prendí, y le maté en Siclag en pago de la nueva. [^10] ¿Cuánto más á los malos hombres que mataron á un hombre justo en su casa, y sobre su cama? Ahora pues, ¿no tengo yo de demandar su sangre de vuestras manos, y quitaros de la tierra? [^11] Entonces David mandó á los mancebos, y ellos los mataron, y cortáronles las manos y los pies, y colgáronlos sobre el estanque, en Hebrón. Luego tomaron la cabeza de Is-boseth, y enterráronla en el sepulcro de Abner en Hebrón. [^12] 

[[2 Samuel - 3|<--]] 2 Samuel - 4 [[2 Samuel - 5|-->]]

---
# Notes
