---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 18 - Reina Valera (1602)"
---
[[Leviticus - 17|<--]] Leviticus - 18 [[Leviticus - 19|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Leviticus]]

# Leviticus - 18

Y HABLO Jehová á Moisés, diciendo: [^1] Habla á los hijos de Israel, y diles: Yo soy Jehová vuestro Dios. [^2] No haréis como hacen en la tierra de Egipto, en la cual morasteis; ni haréis como hacen en la tierra de Canaán, á la cual yo os conduzco; ni andaréis en sus estatutos. [^3] Mis derechos pondréis por obra, y mis estatutos guardaréis, andando en ellos: Yo Jehová vuestro Dios. [^4] Por tanto mis estatutos y mis derechos guardaréis, los cuales haciendo el hombre, vivirá en ellos: Yo Jehová. [^5] Ningún varón se allegue á ninguna cercana de su carne, para descubrir su desnudez: Yo Jehová. [^6] La desnudez de tu padre, ó la desnudez de tu madre, no descubrirás: tu madre es, no descubrirás su desnudez. [^7] La desnudez de la mujer de tu padre no descubrirás; es la desnudez de tu padre. [^8] La desnudez de tu hermana, hija de tu padre, ó hija de tu madre, nacida en casa ó nacida fuera, su desnudez no descubrirás. [^9] La desnudez de la hija de tu hijo, ó de la hija de tu hija, su desnudez no descubirás, porque es la desnudez tuya. [^10] La desnudez de la hija de la mujer de tu padre, engendrada de tu padre, tu hermana es, su desnudez no descubrirás. [^11] La desnudez de la hermana de tu padre no descubrirás: es parienta de tu padre. [^12] La desnudez de la hermana de tu madre no descubrirás: porque parienta de tu madre es. [^13] La desnudez del hermano de tu padre no descubrirás: no llegarás á su mujer: es mujer del hermano de tu padre. [^14] La desnudez de tu nuera no descubrirás: mujer es de tu hijo, no descubrirás su desnudez. [^15] La desnudez de la mujer de tu hermano no descubrirás: es la desnudez de tu hermano. [^16] La desnudez de la mujer y de su hija no descubrirás: no tomarás la hija de su hijo, ni la hija de su hija, para descubrir su desnudez: son parientas, es maldad. [^17] No tomarás mujer juntamente con su hermana, para hacerla su rival, descubriendo su desnudez delante de ella en su vida. [^18] Y no llegarás á la mujer en el apartamiento de su inmundicia, para descubrir su desnudez. [^19] Además, no tendrás acto carnal con la mujer de tu prójimo, contaminándote en ella. [^20] Y no des de tu simiente para hacerla pasar por el fuego á Moloch; no contamines el nombre de tu Dios: Yo Jehová. [^21] No te echarás con varón como con mujer: es abominación. [^22] Ni con ningún animal tendrás ayuntamiento amancillándote con él; ni mujer alguna se pondrá delante de animal para ayuntarse con él: es confusión. [^23] En ninguna de estas cosas os amancillaréis; porque en todas estas cosas se han ensuciado las gentes que yo echo de delante de vosotros: [^24] Y la tierra fue contaminada; y yo visité su maldad sobre ella, y la tierra vomitó sus moradores. [^25] Guardad, pues, vosotros mis estatutos y mis derechos, y no hagáis ninguna de todas estas abominaciones: ni el natural ni el extranjero que peregrina entre vosotros. [^26] (Porque todas estas abominaciones hicieron los hombres de la tierra, que fueron antes de vosotros, y la tierra fue contaminada:) [^27] Y la tierra no os vomitará, por haberla contaminado, como vomitó á la gente que fué antes de vosotros. [^28] Porque cualquiera que hiciere alguna de todas estas abominaciones, las personas que las hicieren, serán cortadas de entre su pueblo. [^29] Guardad, pues, mi ordenanza, no haciendo de las prácticas abominables que tuvieron lugar antes de vosotros, y no os ensuciéis en ellas: Yo Jehová vuestro Dios. [^30] 

[[Leviticus - 17|<--]] Leviticus - 18 [[Leviticus - 19|-->]]

---
# Notes
