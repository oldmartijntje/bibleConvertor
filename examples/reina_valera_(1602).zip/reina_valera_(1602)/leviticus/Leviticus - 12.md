---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 12 - Reina Valera (1602)"
---
[[Leviticus - 11|<--]] Leviticus - 12 [[Leviticus - 13|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Leviticus]]

# Leviticus - 12

Y HABLO Jehová á Moisés, diciendo: [^1] Habla á los hijos de Israel, diciendo: La mujer cuando concibiere y pariere varón, será inmunda siete días; conforme á los días que está separada por su menstruo, será inmunda. [^2] Y al octavo día circuncidará la carne de su prepucio. [^3] Mas ella permanecerá treinta y tres días en la sangre de su purgación: ninguna cosa santa tocará, ni vendrá al santuario, hasta que sean cumplidos los días de su purgación. [^4] Y si pariere hembra será inmunda dos semanas, conforme á su separación, y sesenta y seis días estará purificándose de su sangre. [^5] Y cuando los días de su purgación fueren cumplidos, por hijo ó por hija, traerá un cordero de un año para holocausto, y un palomino ó una tórtola para expiación, á la puerta del tabernáculo del testimonio, al sacerdote: [^6] Y él ofrecerá delante de Jehová, y hará expiación por ella, y será limpia del flujo de su sangre. Esta es la ley de la que pariere varón ó hembra. [^7] Y si no alcanzare su mano lo suficiente para un cordero, tomará entonces dos tórtolas ó dos palominos, uno para holocausto, y otro para expiación: y el sacerdote hará expiación por ella, y será limpia. [^8] 

[[Leviticus - 11|<--]] Leviticus - 12 [[Leviticus - 13|-->]]

---
# Notes
