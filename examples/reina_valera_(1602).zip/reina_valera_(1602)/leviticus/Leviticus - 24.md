---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 24 - Reina Valera (1602)"
---
[[Leviticus - 23|<--]] Leviticus - 24 [[Leviticus - 25|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Leviticus]]

# Leviticus - 24

Y HABLO Jehová á Moisés, diciendo: [^1] Manda á los hijos de Israel que te traigan aceite de olivas claro, molido, para la luminaria, para hacer arder las lámparas de continuo. [^2] Fuera del velo del testimonio, en el tabernáculo del testimonio, las aderezará Aarón desde la tarde hasta la mañana delante de Jehová, de continuo: estatuto perpetuo por vuestras edades. [^3] Sobre el candelero limpio pondrá siempre en orden las lámparas delante de Jehová. [^4] Y tomarás flor de harina, y cocerás de ella doce tortas: cada torta será de dos décimas. [^5] Y has de ponerlas en dos órdenes, seis en cada orden, sobre la mesa limpia delante de Jehová. [^6] Pondrás también sobre cada orden incienso limpio, y será para el pan por perfume, ofrenda encendida á Jehová. [^7] Cada día de sábado lo pondrá de continuo en orden delante de Jehová, de los hijos de Israel por pacto sempiterno. [^8] Y será de Aarón y de sus hijos, los cuales lo comerán en el lugar santo; porque es cosa muy santa para él, de las ofrendas encendidas á Jehová, por fuero perpetuo. [^9] En aquella sazón el hijo de una mujer Israelita, el cual era hijo de un Egipcio, salió entre los hijos de Israel; y el hijo de la Israelita y un hombre de Israel riñeron en el real: [^10] Y el hijo de la mujer Israelita pronunció el Nombre, y maldijo: entonces le llevaron á Moisés. Y su madre se llamaba Selomith, hija de Dribi, de la tribu de Dan. [^11] Y pusiéronlo en la cárcel, hasta que les fuese declarado por palabra de Jehová. [^12] Y Jehová habló á Moisés, diciendo: [^13] Saca al blasfemo fuera del real, y todos los que le oyeron pongan sus manos sobre la cabeza de él, y apedréelo toda la congregación. [^14] Y á los hijos de Israel hablarás, diciendo: Cualquiera que maldijere á su Dios, llevará su iniquidad. [^15] Y el que blasfemare el nombre de Jehová, ha de ser muerto; toda la congregación lo apedreará: así el extranjero como el natural, si blasfemare el Nombre, que muera. [^16] Asimismo el hombre que hiere de muerte á cualquiera persona, que sufra la muerte. [^17] Y el que hiere á algún animal ha de restituirlo: animal por animal. [^18] Y el que causare lesión en su prójimo, según hizo, así le sea hecho: [^19] Rotura por rotura, ojo por ojo, diente por diente: según la lesión que habrá hecho á otro, tal se hará á él. [^20] El que hiere algún animal, ha de restituirlo; mas el que hiere de muerte á un hombre, que muera. [^21] Un mismo derecho tendréis: como el extranjero, así será el natural: porque yo soy Jehová vuestro Dios. [^22] Y habló Moisés á los hijos de Israel, y ellos sacaron al blasfemo fuera del real, y apedreáronlo con piedras. Y los hijos de Israel hicieron según que Jehová había mandado á Moisés. [^23] 

[[Leviticus - 23|<--]] Leviticus - 24 [[Leviticus - 25|-->]]

---
# Notes
