---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 17 - Reina Valera (1602)"
---
[[Leviticus - 16|<--]] Leviticus - 17 [[Leviticus - 18|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Leviticus]]

# Leviticus - 17

Y HABLO Jehová á Moisés, diciendo: [^1] Habla á Aarón y á sus hijos, y á todos los hijos de Israel, y diles: Esto es lo que ha mandado Jehová, diciendo: [^2] Cualquier varón de la casa de Israel que degollare buey, ó cordero, ó cabra, en el real, ó fuera del real, [^3] Y no lo trajere á la puerta del tabernáculo del testimonio, para ofrecer ofrenda á Jehová delante del tabernáculo de Jehová, sangre será imputada al tal varón: sangre derramó; cortado será el tal varón de entre su pueblo: [^4] A fin de que traigan los hijos de Israel sus sacrificios, los que sacrifican sobre la haz del campo, para que los traigan á Jehová á la puerta del tabernáculo del testimonio al sacerdote, y sacrifiquen ellos sacrificios de paces á Jehová. [^5] Y el sacerdote esparcirá la sangre sobre el altar de Jehová, á la puerta del tabernáculo del testimonio, y quemará el sebo en olor de suavidad á Jehová. [^6] Y nunca más sacrificarán sus sacrificios á los demonios, tras de los cuales han fornicado: tendrán esto por estatuto perpetuo por sus edades. [^7] Les dirás también: Cualquier varón de la casa de Israel, ó de los extranjeros que peregrinan entre vosotros, que ofreciere holocausto ó sacrificio, [^8] Y no lo trajere á la puerta del tabernáculo del testimonio, para hacerlo á Jehová, el tal varón será igualmente cortado de sus pueblos. [^9] Y cualquier varón de la casa de Israel, ó de los extranjeros que peregrinan entre ellos, que comiere alguna sangre, yo pondré mi rostro contra la persona que comiere sangre, y le cortaré de entre su pueblo. [^10] Porque la vida de la carne en la sangre está: y yo os la he dado para expiar vuestras personas sobre el altar: por lo cual la misma sangre expiará la persona. [^11] Por tanto, he dicho á los hijos de Israel: Ninguna persona de vosotros comerá sangre, ni el extranjero que peregrina entre vosotros comerá sangre. [^12] Y cualquier varón de los hijos de Israel, ó de los extranjeros que peregrinan entre ellos, que cogiere caza de animal ó de ave que sea de comer, derramará su sangre y cubrirála con tierra: [^13] Porque el alma de toda carne, su vida, está en su sangre: por tanto he dicho á los hijos de Israel: No comeréis la sangre de ninguna carne, porque la vida de toda carne es su sangre; cualquiera que la comiere será cortado. [^14] Y cualquiera persona que comiere cosa mortecina ó despedazada por fiera, así de los naturales como de los extranjeros, lavará sus vestidos y á sí mismo se lavará con agua, y será inmundo hasta la tarde; y se limpiará. [^15] Y si no los lavare, ni lavare su carne, llevará su iniquidad. [^16] 

[[Leviticus - 16|<--]] Leviticus - 17 [[Leviticus - 18|-->]]

---
# Notes
