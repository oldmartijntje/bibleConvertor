---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 2 - Reina Valera (1602)"
---
[[Leviticus - 1|<--]] Leviticus - 2 [[Leviticus - 3|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Leviticus]]

# Leviticus - 2

Y CUANDO alguna persona ofreciere oblación de presente á Jehová, su ofrenda será flor de harina, sobre la cual echará aceite, y pondrá sobre ella incienso: [^1] Y la traerá á los sacerdotes, hijos de Aarón; y de ello tomará el sacerdote su puño lleno de su flor de harina y de su aceite, con todo su incienso, y lo hará arder sobre el altar: ofrenda encendida para recuerdo, de olor suave á Jehová. [^2] Y la sobra del presente será de Aarón y de sus hijos: es cosa santísima de las ofrendas que se queman á Jehová. [^3] Y cuando ofrecieres ofrenda de presente cocida en horno, será de tortas de flor de harina sin levadura, amasadas con aceite, y hojaldres sin levadura untadas con aceite. [^4] Mas si tu presente fuere ofrenda de sartén, será de flor de harina sin levadura, amasada con aceite, [^5] La cual partirás en piezas, y echarás sobre ella aceite: es presente. [^6] Y si tu presente fuere ofrenda cocida en cazuela, haráse de flor de harina con aceite. [^7] Y traerás á Jehová la ofrenda que se hará de estas cosas, y la presentarás al sacerdote, el cual la llegará al altar. [^8] Y tomará el sacerdote de aquel presente, en memoria del mismo, y harálo arder sobre el altar; ofrenda encendida, de suave olor á Jehová. [^9] Y lo restante del presente será de Aarón y de sus hijos; es cosa santísima de las ofrendas que se queman á Jehová. [^10] Ningun presente que ofreciereis á Jehová, será con levadura: porque de ninguna cosa leuda, ni de ninguna miel, se ha de quemar ofrenda á Jehová. [^11] En la ofrenda de las primicias las ofreceréis á Jehová: mas no subirán sobre el altar en olor de suavidad. [^12] Y sazonarás toda ofrenda de tu presente con sal; y no harás que falte jamás de tu presente la sal de la alianza de tu Dios: en toda ofrenda tuya ofrecerás sal. [^13] Y si ofrecieres á Jehová presente de primicias, tostarás al fuego las espigas verdes, y el grano desmenuzado ofrecerás por ofrenda de tus primicias. [^14] Y pondrás sobre ella aceite, y pondrás sobre ella incienso: es presente. [^15] Y el sacerdote hará arder, en memoria del don, parte de su grano desmenuzado, y de su aceite con todo su incienso; es ofrenda encendida á Jehová. [^16] 

[[Leviticus - 1|<--]] Leviticus - 2 [[Leviticus - 3|-->]]

---
# Notes
