---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 10 - Reina Valera (1602)"
---
[[Leviticus - 9|<--]] Leviticus - 10 [[Leviticus - 11|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Leviticus]]

# Leviticus - 10

Y LOS hijos de Aarón, Nadab y Abiú, tomaron cada uno su incensario, y pusieron fuego en ellos, sobre el cual pusieron perfume, y ofrecieron delante de Jehová fuego extraño, que él nunca les mandó. [^1] Y salió fuego de delante de Jehová que los quemó, y murieron delante de Jehová. [^2] Entonces dijo Moisés á Aarón: Esto es lo que habló Jehová, diciendo: En mis allegados me santificaré, y en presencia de todo el pueblo seré glorificado. Y Aarón calló. [^3] Y llamó Moisés á Misael, y á Elzaphán, hijos de Uzziel, tío de Aarón, y díjoles: Llegaos y sacad á vuestros hermanos de delante del santuario fuera del campo. [^4] Y ellos llegaron, y sacáronlos con sus túnicas fuera del campo, como dijo Moisés. [^5] Entonces Moisés dijo á Aarón, y á Eleazar y á Ithamar, sus hijos: No descubráis vuestras cabezas, ni rasguéis vuestros vestidos, porque no muráis, ni se levante la ira sobre toda la congregación: empero vuestros hermanos, toda la casa de Israel, lamentarán el incendio que Jehová ha hecho. [^6] Ni saldréis de la puerta del tabernáculo del testimonio, porque moriréis; por cuanto el aceite de la unción de Jehová está sobre vosotros. Y ellos hicieron conforme al dicho de Moisés. [^7] Y Jehová habló á Aarón, diciendo: [^8] Tú, y tus hijos contigo, no beberéis vino ni sidra, cuando hubiereis de entrar en el tabernáculo del testimonio, porque no muráis: estatuto perpetuo por vuestras generaciones; [^9] Y para poder discernir entre lo santo y lo profano, y entre lo inmundo y lo limpio; [^10] Y para enseñar á los hijos de Israel todos los estatutos que Jehová les ha dicho por medio de Moisés. [^11] Y Moisés dijo á Aarón, y á Eleazar y á Ithamar, sus hijos que habían quedado: Tomad el presente que queda de las ofrendas encendidas á Jehová, y comedlo sin levadura junto al altar, porque es cosa muy santa. [^12] Habéis, pues, de comerlo en el lugar santo: porque esto es fuero para ti, y fuero para tus hijos, de las ofrendas encendidas á Jehová, pues que así me ha sido mandado. [^13] Comeréis asimismo en lugar limpio, tú y tus hijos y tus hijas contigo, el pecho de la mecida, y la espaldilla elevada, porque por fuero para ti, y fuero para tus hijos, son dados de los sacrificios de las paces de los hijos de Israel. [^14] Con las ofrendas de los sebos que se han de encender, traerán la espaldilla que se ha de elevar, y el pecho que será mecido, para que lo mezas por ofrenda agitada delante de Jehová: y será por fuero perpetuo tuyo, y de tus hijos contigo, como Jehová lo ha mandado. [^15] Y Moisés demandó el macho cabrío de la expiación, y hallóse que era quemado: y enojóse contra Eleazar é Ithamar, los hijos de Aarón que habían quedado, diciendo: [^16] ¿Por qué no comisteis la expiación en el lugar santo? porque es muy santa, y dióla él á vosotros para llevar la iniquidad de la congregación, para que sean reconciliados delante de Jehová. [^17] Veis que su sangre no fue metida dentro del santuario: habíais de comerla en el lugar santo, como yo mandé. [^18] Y respondió Aarón á Moisés: He aquí hoy han ofrecido su expiación y su holocausto delante de Jehová: pero me han acontecido estas cosas: pues si comiera yo hoy de la expiación, ¿Hubiera sido acepto á Jehová? [^19] Y cuando Moisés oyó esto, dióse por satisfecho. [^20] 

[[Leviticus - 9|<--]] Leviticus - 10 [[Leviticus - 11|-->]]

---
# Notes
