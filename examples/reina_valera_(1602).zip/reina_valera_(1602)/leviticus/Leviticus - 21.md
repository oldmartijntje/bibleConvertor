---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 21 - Reina Valera (1602)"
---
[[Leviticus - 20|<--]] Leviticus - 21 [[Leviticus - 22|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Leviticus]]

# Leviticus - 21

Y JEHOVA dijo á Moisés: Habla á los sacerdotes hijos de Aarón, y diles que no se contaminen por un muerto en sus pueblos. [^1] Mas por su pariente cercano á sí, por su madre, ó por su padre, ó por su hijo, ó por su hermano, [^2] O por su hermana virgen, á él cercana, la cual no haya tenido marido, por ella se contaminará. [^3] No se contaminará, porque es príncipe en sus pueblos, haciéndose inmundo. [^4] No harán calva en su cabeza, ni raerán la punta de su barba, ni en su carne harán rasguños. [^5] Santos serán á su Dios, y no profanarán el nombre de su Dios; porque los fuegos de Jehová y el pan de su Dios ofrecen: por tanto serán santos. [^6] Mujer ramera ó infame no tomarán: ni tomarán mujer repudiada de su marido: porque es santo á su Dios. [^7] Lo santificarás por tanto, pues el pan de tu Dios ofrece: santo será para ti, porque santo soy yo Jehová vuestro santificador. [^8] Y la hija del varón sacerdote, si comenzare á fornicar, á su padre amancilla: quemada será al fuego. [^9] Y el sumo sacerdote entre sus hermanos, sobre cuya cabeza fué derramado el aceite de la unción, y que hinchió su mano para vestir las vestimentas, no descubrirá su cabeza, ni romperá sus vestidos: [^10] Ni entrará donde haya alguna persona muerta, ni por su padre, ó por su madre se contaminará. [^11] Ni saldrá del santuario, ni contaminará el santuario de su Dios; porque la corona del aceite de la unción de su Dios está sobre él: Yo Jehová. [^12] Y tomará él mujer con su virginidad. [^13] Viuda, ó repudiada, ó infame, ó ramera, éstas no tomará: mas tomará virgen de sus pueblos por mujer. [^14] Y no amancillará su simiente en sus pueblos; porque yo Jehová soy el que los santifico. [^15] Y Jehová habló á Moisés, diciendo: [^16] Habla á Aarón, y dile: El varón de tu simiente en sus generaciones, en el cual hubiere falta, no se allegará para ofrecer el pan de su Dios. [^17] Porque ningún varón en el cual hubiere falta, se allegará: varón ciego, ó cojo, ó falto, ó sobrado, [^18] O varón en el cual hubiere quebradura de pie ó rotura de mano, [^19] O corcobado, ó lagañoso, ó que tuviere nube en el ojo, ó que tenga sarna, ó empeine, ó compañón relajado; [^20] Ningún varón de la simiente de Aarón sacerdote, en el cual hubiere falta, se allegará para ofrecer las ofrendas encendidas de Jehová. Hay falta en él; no se allegará á ofrecer el pan de su Dios. [^21] El pan de su Dios, de lo muy santo y las cosas santificadas, comerá. [^22] Empero no entrará del velo adentro, ni se allegará al altar, por cuanto hay falta en él: y no profanará mi santuario, porque yo Jehová soy el que los santifico. [^23] Y Moisés habló esto á Aarón, y á sus hijos, y á todos los hijos de Israel. [^24] 

[[Leviticus - 20|<--]] Leviticus - 21 [[Leviticus - 22|-->]]

---
# Notes
