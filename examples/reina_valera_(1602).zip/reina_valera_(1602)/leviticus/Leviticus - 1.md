---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 1 - Reina Valera (1602)"
---
Leviticus - 1 [[Leviticus - 2|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Leviticus]]

# Leviticus - 1

Y LLAMO Jehová á Moisés, y habló con él desde el tabernáculo del testimonio, diciendo: [^1] Habla á los hijos de Israel, y diles: Cuando alguno de entre vosotros ofreciere ofrenda á Jehová, de ganado vacuno ú ovejuno haréis vuestra ofrenda. [^2] Si su ofrenda fuere holocausto de vacas, macho sin tacha lo ofrecerá: de su voluntad lo ofrecerá á la puerta del tabernáculo del testimonio delante de Jehová. [^3] Y pondrá su mano sobre la cabeza del holocausto; y él lo aceptará para expiarle. [^4] Entonces degollará el becerro en la presencia de Jehová; y los sacerdotes, hijos de Aarón, ofrecerán la sangre, y la rociarán alrededor sobre el altar, el cual está á la puerta del tabernáculo del testimonio. [^5] Y desollará el holocausto, y lo dividirá en sus piezas. [^6] Y los hijos de Aarón sacerdote pondrán fuego sobre el altar, y compondrán la leña sobre el fuego. [^7] Luego los sacerdotes, hijos de Aarón, acomodarán las piezas, la cabeza y el redaño, sobre la leña que está sobre el fuego, que habrá encima del altar: [^8] Y lavará con agua sus intestinos y sus piernas: y el sacerdote hará arder todo sobre el altar: holocausto es, ofrenda encendida de olor suave á Jehová. [^9] Y si su ofrenda para holocausto fuere de ovejas, de los corderos, ó de las cabras, macho sin defecto lo ofrecerá. [^10] Y ha de degollarlo al lado septentrional del altar delante de Jehová: y los sacerdotes, hijos de Aarón, rociarán su sangre sobre el altar alrededor. [^11] Y lo dividirá en sus piezas, con su cabeza y su redaño; y el sacerdote las acomodará sobre la leña que está sobre el fuego, que habrá encima del altar; [^12] Y lavará sus entrañas y sus piernas con agua; y el sacerdote lo ofrecerá todo, y harálo arder sobre el altar; holocausto es, ofrenda encendida de olor suave á Jehová. [^13] Y si el holocausto se hubiere de ofrecer á Jehová de aves, presentará su ofrenda de tórtolas, ó de palominos. [^14] Y el sacerdote la ofrecerá sobre el altar, y ha de quitarle la cabeza, y hará que arda en el altar; y su sangre será exprimida sobre la pared del altar. [^15] Y le ha de quitar el buche y las plumas, lo cual echará junto al altar, hacia el oriente, en el lugar de las cenizas. [^16] Y la henderá por sus alas, mas no la dividirá en dos: y el sacerdote la hará arder sobre el altar, sobre la leña que estará en el fuego; holocausto es, ofrenda encendida de olor suave á Jehová. [^17] 

Leviticus - 1 [[Leviticus - 2|-->]]

---
# Notes
