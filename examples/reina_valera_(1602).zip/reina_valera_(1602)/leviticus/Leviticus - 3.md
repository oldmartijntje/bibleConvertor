---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 3 - Reina Valera (1602)"
---
[[Leviticus - 2|<--]] Leviticus - 3 [[Leviticus - 4|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Leviticus]]

# Leviticus - 3

Y SI su ofrenda fuere sacrificio de paces, si hubiere de ofrecerlo de ganado vacuno, sea macho ó hembra, sin defecto lo ofrecerá delante de Jehová: [^1] Y pondrá su mano sobre la cabeza de su ofrenda, y la degollará á la puerta del tabernáculo del testimonio; y los sacerdotes, hijos de Aarón, rociarán su sangre sobre el altar en derredor. [^2] Luego ofrecerá del sacrificio de las paces, por ofrenda encendida á Jehová, el sebo que cubre los intestinos, y todo el sebo que está sobre las entrañas, [^3] Y los dos riñones, y el sebo que está sobre ellos, y sobre los ijares, y con los riñones quitará el redaño que está sobre el hígado. [^4] Y los hijos de Aarón harán arder esto en el altar, sobre el holocausto que estará sobre la leña que habrá encima del fuego; es ofrenda de olor suave á Jehová. [^5] Mas si de ovejas fuere su ofrenda para sacrificio de paces á Jehová, sea macho ó hembra, ofrecerála sin tacha. [^6] Si ofreciere cordero por su ofrenda, ha de ofrecerlo delante de Jehová: [^7] Y pondrá su mano sobre la cabeza de su ofrenda, y después la degollará delante del tabernáculo del testimonio; y los hijos de Aarón rociarán su sangre sobre el altar en derredor. [^8] Y del sacrificio de las paces ofrecerá por ofrenda encendida á Jehová, su sebo, y la cola entera, la cual quitará á raíz del espinazo, y el sebo que cubre los intestinos, y todo el sebo que está sobre las entrañas: [^9] Asimismo los dos riñones, y el sebo que está sobre ellos, y el que está sobre los ijares, y con los riñones quitará el redaño de sobre el hígado. [^10] Y el sacerdote hará arder esto sobre el altar; vianda de ofrenda encendida á Jehová. [^11] Y si fuere cabra su ofrenda ofrecerála delante de Jehová: [^12] Y pondrá su mano sobre la cabeza de ella, y la degollará delante del tabernáculo del testimonio; y los hijos de Aarón rociarán su sangre sobre el altar en derredor. [^13] Después ofrecerá de ella su ofrenda encendida á Jehová; el sebo que cubre los intestinos, y todo el sebo que está sobre las entrañas, [^14] Y los dos riñones, y el sebo que está sobre ellos, y el que está sobre los ijares, y con los riñones quitará el redaño de sobre el hígado. [^15] Y el sacerdote hará arder esto sobre el altar; es vianda de ofrenda que se quema en olor de suavidad á Jehová: el sebo todo es de Jehová. [^16] Estatuto perpetuo por vuestras edades; en todas vuestras moradas, ningún sebo ni ninguna sangre comeréis. [^17] 

[[Leviticus - 2|<--]] Leviticus - 3 [[Leviticus - 4|-->]]

---
# Notes
