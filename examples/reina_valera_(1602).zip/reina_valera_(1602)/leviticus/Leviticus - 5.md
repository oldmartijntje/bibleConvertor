---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 5 - Reina Valera (1602)"
---
[[Leviticus - 4|<--]] Leviticus - 5 [[Leviticus - 6|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Leviticus]]

# Leviticus - 5

Y CUANDO alguna persona pecare, que hubiere oído la voz del que juró, y él fuere testigo que vió, ó supo, si no lo denunciare, él llevará su pecado. [^1] Asimismo la persona que hubiere tocado en cualquiera cosa inmunda, sea cuerpo muerto de bestia inmunda, ó cuerpo muerto de animal inmundo, ó cuerpo muerto de reptil inmundo, bien que no lo supiere, será inmunda y habrá delinquido: [^2] O si tocare á hombre inmundo en cualquiera inmundicia suya de que es inmundo, y no lo echare de ver; si después llega á saberlo, será culpable. [^3] También la persona que jurare, pronunciando con sus labios hacer mal ó bien, en cualesquiera cosas que el hombre profiere con juramento, y él no lo conociere; si después lo entiende, será culpado en una de estas cosas. [^4] Y será que cuando pecare en alguna de estas cosas, confesará aquello en que pecó: [^5] Y para su expiación traerá á Jehová por su pecado que ha cometido, una hembra de los rebaños, una cordera ó una cabra como ofrenda de expiación; y el sacerdote hará expiación por él de su pecado. [^6] Y si no le alcanzare para un cordero, traerá en expiación por su pecado que cometió, dos tórtolas ó dos palominos á Jehová; el uno para expiación, y el otro para holocausto. [^7] Y ha de traerlos al sacerdote, el cual ofrecerá primero el que es para expiación, y desunirá su cabeza de su cuello, mas no la apartará del todo: [^8] Y rociará de la sangre de la expiación sobre la pared del altar; y lo que sobrare de la sangre lo exprimirá al pie del altar; es expiación. [^9] Y del otro hará holocausto conforme al rito; y hará por él el sacerdote expiación de su pecado que cometió, y será perdonado. [^10] Mas si su posibilidad no alcanzare para dos tórtolas, ó dos palominos, el que pecó traerá por su ofrenda la décima parte de un epha de flor de harina por expiación. No pondrá sobre ella aceite, ni sobre ella pondrá incienso, porque es expiación. [^11] Traerála, pues, al sacerdote, y el sacerdote tomará de ella su puño lleno, en memoria suya, y la hará arder en el altar sobre las ofrendas encendidas á Jehová: es expiación. [^12] Y hará el sacerdote expiación por él de su pecado que cometió en alguna de estas cosas, y será perdonado; y el sobrante será del sacerdote, como el presente de vianda. [^13] Habló más Jehová á Moisés, diciendo: [^14] Cuando alguna persona cometiere falta, y pecare por yerro en las cosas santificadas á Jehová, traerá su expiación á Jehová, un carnero sin tacha de los rebaños, conforme á tu estimación, en siclos de plata del siclo del santuario, en ofrenda por el pecado: [^15] Y pagará aquello de las cosas santas en que hubiere pecado, y añadirá á ello el quinto, y lo dará al sacerdote: y el sacerdote hará expiación por él con el carnero del sacrificio por el pecado, y será perdonado. [^16] Finalmente, si una persona pecare, ó hiciere alguna de todas aquellas cosas que por mandamiento de Jehová no se han de hacer, aun sin hacerlo á sabiendas, es culpable, y llevará su pecado. [^17] Traerá, pues, al sacerdote por expiación, según tú lo estimes, un carnero sin tacha de los rebaños: y el sacerdote hará expiación por él de su yerro que cometió por ignorancia, y será perdonado. [^18] Es infracción, y ciertamente delinquió contra Jehová. [^19] 

[[Leviticus - 4|<--]] Leviticus - 5 [[Leviticus - 6|-->]]

---
# Notes
