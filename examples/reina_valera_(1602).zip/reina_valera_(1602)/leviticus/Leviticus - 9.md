---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 9 - Reina Valera (1602)"
---
[[Leviticus - 8|<--]] Leviticus - 9 [[Leviticus - 10|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Leviticus]]

# Leviticus - 9

Y FUÉ en el día octavo, que Moisés llamó á Aarón y á sus hijos, y á los ancianos de Israel; [^1] Y dijo á Aarón: Toma de la vacada un becerro para expiación, y un carnero para holocausto, sin defecto, y ofrécelos delante de Jehová. [^2] Y á los hijos de Israel hablarás, diciendo: Tomad un macho cabrío para expiación, y un becerro y un cordero de un año, sin tacha, para holocausto; [^3] Asimismo un buey y un carnero para sacrificio de paces, que inmoléis delante de Jehová; y un presente amasado con aceite: porque Jehová se aparecerá hoy á vosotros. [^4] Y llevaron lo que mandó Moisés delante del tabernáculo del testimonio, y llegóse toda la congregación, y pusiéronse delante de Jehová. [^5] Entonces Moisés dijo: Esto es lo que mandó Jehová; hacedlo, y la gloria de Jehová se os aparecerá. [^6] Y dijo Moisés á Aarón: Llégate al altar, y haz tu expiación, y tu holocausto, y haz la reconciliación por ti y por el pueblo: haz también la ofrenda del pueblo, y haz la reconciliación por ellos; como ha mandado Jehová. [^7] Entonces llegóse Aarón al altar; y degolló su becerro de la expiación que era por él. [^8] Y los hijos de Aarón le trajeron la sangre; y él mojó su dedo en la sangre, y puso sobre los cuernos del altar, y derramó la demás sangre al pie del altar; [^9] Y el sebo y riñones y redaño del hígado, de la expiación, hízolos arder sobre el altar; como Jehová lo había mandado á Moisés. [^10] Mas la carne y el cuero los quemó al fuego fuera del real. [^11] Degolló asimismo el holocausto, y los hijos de Aarón le presentaron la sangre, la cual roció él alrededor sobre el altar. [^12] Presentáronle después el holocausto, á trozos, y la cabeza; é hízolos quemar sobre el altar. [^13] Luego lavó los intestinos y las piernas, y quemólos sobre el holocausto en el altar. [^14] Ofreció también la ofrenda del pueblo, y tomó el macho cabrío que era para la expiación del pueblo, y degollólo, y lo ofreció por el pecado como el primero. [^15] Y ofreció el holocausto, é hizo según el rito. [^16] Ofreció asimismo el presente, é hinchió de él su mano, y lo hizo quemar sobre el altar, además del holocausto de la mañana. [^17] Degolló también el buey y el carnero en sacrificio de paces, que era del pueblo: y los hijos de Aarón le presentaron la sangre (la cual roció él sobre el altar alrededor), [^18] Y los sebos del buey; y del carnero la cola con lo que cubre las entrañas, y los riñones, y el redaño del hígado: [^19] Y pusieron los sebos sobre los pechos, y él quemó los sebos sobre el altar: [^20] Empero los pechos, con la espaldilla derecha, meciólos Aarón por ofrenda agitada delante de Jehová; como Jehová lo había mandado á Moisés. [^21] Después alzó Aarón sus manos hacia el pueblo y bendíjolos: y descendió de hacer la expiación, y el holocausto, y el sacrificio de las paces. [^22] Y entraron Moisés y Aarón en el tabernáculo del testimonio; y salieron, y bendijeron al pueblo: y la gloria de Jehová se apareció á todo el pueblo. [^23] Y salió fuego de delante de Jehová, y consumió el holocausto y los sebos sobre el altar; y viéndolo todo el pueblo, alabaron, y cayeron sobre sus rostros. [^24] 

[[Leviticus - 8|<--]] Leviticus - 9 [[Leviticus - 10|-->]]

---
# Notes
