---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 20 - Reina Valera (1602)"
---
[[Numbers - 19|<--]] Numbers - 20 [[Numbers - 21|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Numbers]]

# Numbers - 20

Y LLEGARON los hijos de Israel, toda la congregación, al desierto de Zin, en el mes primero, y asentó el pueblo en Cades; y allí murió María, y fué allí sepultada. [^1] Y como no hubiese agua para la congregación, juntáronse contra Moisés y Aarón. [^2] Y regañó el pueblo con Moisés, y hablaron diciendo: ­Ojalá que nosotros hubiéramos muerto cuando perecieron nuestros hermanos delante de Jehová! [^3] Y ¿por qué hiciste venir la congregación de Jehová á este desierto, para que muramos aquí nosotros y nuestras bestias? [^4] ¿Y por qué nos has hecho subir de Egipto, para traernos á este mal lugar? No es lugar de sementera, de higueras, de viñas, ni granadas: ni aun de agua para beber. [^5] Y fuéronse Moisés y Aarón de delante de la congregación á la puerta del tabernáculo del testimonio, y echáronse sobre sus rostros; y la gloria de Jehová apareció sobre ellos. [^6] Y habló Jehová á Moisés, diciendo: [^7] Toma la vara y reune la congregación, tú y Aarón tu hermano, y hablad á la peña en ojos de ellos; y ella dará su agua, y les sacarás aguas de la peña, y darás de beber á la congregación, y á sus bestias. [^8] Entonces Moisés tomó la vara de delante de Jehová, como él le mandó. [^9] Y juntaron Moisés y Aarón la congregación delante de la peña, y díjoles: Oid ahora, rebeldes: ¿os hemos de hacer salir aguas de esta peña? [^10] Entonces alzó Moisés su mano, é hirió la peña con su vara dos veces: y salieron muchas aguas, y bebió la congregación, y sus bestias. [^11] Y Jehová dijo á Moisés y á Aarón: Por cuanto no creísteis en mí, para santificarme en ojos de los hijos de Israel, por tanto, no meteréis esta congregación en la tierra que les he dado. [^12] Estas son las aguas de la rencilla, por las cuales contendieron los hijos de Israel con Jehová, y él se santificó en ellos. [^13] Y envió Moisés embajadores al rey de Edom desde Cades: Así dice Israel tu hermano: Tú has sabido todo el trabajo que nos ha venido: [^14] Cómo nuestros padres descendieron á Egipto, y estuvimos en Egipto largo tiempo, y los Egipcios nos maltrataron, y á nuestros padres; [^15] Y clamamos á Jehová, el cual oyó nuestra voz, y envió ángel, y sacónos de Egipto; y he aquí estamos en Cades, ciudad al extremo de tus confines: [^16] Rogámoste que pasemos por tu tierra; no pasaremos por labranza, ni por viña, ni beberemos agua de pozos: por el camino real iremos, sin apartarnos á la diestra ni á la siniestra, hasta que hayamos pasado tu término. [^17] Y Edom le respondió: No pasarás por mi país, de otra manera saldré contra ti armado. [^18] Y los hijos de Israel dijeron: Por el camino seguido iremos; y si bebiéremos tus aguas yo y mis ganados, daré el precio de ellas: ciertamente sin hacer otra cosa, pasaré de seguida. [^19] Y él respondió: No pasarás. Y salió Edom contra él con mucho pueblo, y mano fuerte. [^20] No quiso, pues, Edom dejar pasar á Israel por su término, y apartóse Israel de él. [^21] Y partidos de Cades los hijos de Israel, toda aquella congregación, vinieron al monte de Hor. [^22] Y Jehová habló á Moisés y Aarón en el monte de Hor, en los confines de la tierra de Edom, diciendo: [^23] Aarón será reunido á sus pueblos; pues no entrará en la tierra que yo di á los hijos de Israel, por cuanto fuisteis rebeldes á mi mandamiento en las aguas de la rencilla. [^24] Toma á Aarón y á Eleazar su hijo, y hazlos subir al monte de Hor; [^25] Y haz desnudar á Aarón sus vestidos, y viste de ellos á Eleazar su hijo; porque Aarón será reunido á sus pueblos, y allí morirá. [^26] Y Moisés hizo como Jehová le mandó: y subieron al monte de Hor á ojos de toda la congregación. [^27] Y Moisés hizo desnudar á Aarón de sus vestidos y vistiólos á Eleazar su hijo: y Aarón murió allí en la cumbre del monte: y Moisés y Eleazar descendieron del monte. [^28] Y viendo toda la congregación que Aarón era muerto, hiciéronle duelo por treinta días todas las familias de Israel. [^29] 

[[Numbers - 19|<--]] Numbers - 20 [[Numbers - 21|-->]]

---
# Notes
