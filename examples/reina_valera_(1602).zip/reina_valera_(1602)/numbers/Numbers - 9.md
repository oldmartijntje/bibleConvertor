---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 9 - Reina Valera (1602)"
---
[[Numbers - 8|<--]] Numbers - 9 [[Numbers - 10|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Numbers]]

# Numbers - 9

Y HABLO Jehová á Moisés en el desierto de Sinaí, en el segundo año de su salida de la tierra de Egipto, en el mes primero, diciendo: [^1] Los hijos de Israel harán la pascua á su tiempo. [^2] El décimocuarto día de este mes, entre las dos tardes, la haréis á su tiempo: conforme á todos sus ritos, y conforme á todas sus leyes la haréis. [^3] Y habló Moisés á los hijos de Israel, para que hiciesen la pascua. [^4] E hicieron la pascua en el mes primero, á los catorce días del mes, entre las dos tardes, en el desierto de Sinaí: conforme á todas las cosas que mandó Jehová á Moisés, así hicieron los hijos de Israel. [^5] Y hubo algunos que estaban inmundos á causa de muerto, y no pudieron hacer la pascua aquel día; y llegaron delante de Moisés y delante de Aarón aquel día; [^6] Y dijéronle aquellos hombres: Nosotros somos inmundos por causa de muerto; ¿por qué seremos impedidos de ofrecer ofrenda á Jehová á su tiempo entre los hijos de Israel? [^7] Y Moisés les respondió: Esperad, y oiré qué mandará Jehová acerca de vosotros. [^8] Y Jehová habló á Moisés, diciendo: [^9] Habla á los hijos de Israel, diciendo: Cualquiera de vosotros ó de vuestras generaciones, que fuere inmundo por causa de muerto ó estuviere de viaje lejos, hará pascua á Jehová: [^10] En el mes segundo, á los catorce días del mes, entre las dos tardes, la harán: con cenceñas y hierbas amargas la comerán; [^11] No dejarán de él para la mañana, ni quebrarán hueso en él: conforme á todos los ritos de la pascua la harán. [^12] Mas el que estuviere limpio, y no estuviere de viaje, si dejare de hacer la pascua, la tal persona será cortada de sus pueblos: por cuanto no ofreció á su tiempo la ofrenda de Jehová, el tal hombre llevará su pecado. [^13] Y si morare con vosotros peregrino, é hiciere la pascua á Jehová, conforme al rito de la pascua y conforme á sus leyes así la hará: un mismo rito tendréis, así el peregrino como el natural de la tierra. [^14] Y el día que el tabernáculo fué levantado, la nube cubrió el tabernáculo sobre la tienda del testimonio; y á la tarde había sobre el tabernáculo como una apariencia de fuego, hasta la mañana. [^15] Así era continuamente: la nube lo cubría, y de noche la apariencia de fuego. [^16] Y según que se alzaba la nube del tabernáculo, los hijos de Israel se partían: y en el lugar donde la nube paraba, allí alojaban los hijos de Israel. [^17] Al mandato de Jehová los hijos de Israel se partían: y al mandato de Jehová asentaban el campo: todos los días que la nube estaba sobre el tabernáculo, ellos estaban quedos. [^18] Y cuando la nube se detenía sobre el tabernáculo muchos días, entonces los hijos de Israel guardaban la ordenanza de Jehová y no partían. [^19] Y cuando sucedía que la nube estaba sobre el tabernáculo pocos días, al dicho de Jehová alojaban, y al dicho de Jehová partían. [^20] Y cuando era que la nube se detenía desde la tarde hasta la mañana, cuando á la mañana la nube se levantaba, ellos partían: ó si había estado el día, y á la noche la nube se levantaba, entonces partían. [^21] O si dos días, ó un mes, ó un año, mientras la nube se detenía sobre el tabernáculo quedándose sobre él, los hijos de Israel se estaban acampados y no movían: mas cuando ella se alzaba, ellos movían. [^22] Al dicho de Jehová asentaban, y al dicho de Jehová partían, guardando la ordenanza de Jehová, como lo había Jehová dicho por medio de Moisés. [^23] 

[[Numbers - 8|<--]] Numbers - 9 [[Numbers - 10|-->]]

---
# Notes
