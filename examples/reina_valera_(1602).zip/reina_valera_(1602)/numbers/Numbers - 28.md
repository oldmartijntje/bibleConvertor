---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 28 - Reina Valera (1602)"
---
[[Numbers - 27|<--]] Numbers - 28 [[Numbers - 29|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Numbers]]

# Numbers - 28

Y HABLO Jehová á Moisés, diciendo: [^1] Manda á los hijos de Israel, y diles: Mi ofrenda, mi pan con mis ofrendas encendidas en olor á mí agradable, guardaréis, ofreciéndomelo á su tiempo. [^2] Y les dirás: Esta es la ofrenda encendida que ofreceréis á Jehová: dos corderos sin tacha de un año, cada un día, será el holocausto continuo. [^3] El un cordero ofrecerás por la mañana, y el otro cordero ofrecerás entre las dos tardes: [^4] Y la décima de un epha de flor de harina, amasada con una cuarta de un hin de aceite molido, en presente. [^5] Es holocausto continuo, que fué hecho en el monte de Sinaí en olor de suavidad, ofrenda encendida á Jehová. [^6] Y su libación, la cuarta de un hin con cada cordero: derramarás libación de superior vino á Jehová en el santuario. [^7] Y ofrecerás el segundo cordero entre las dos tardes: conforme á la ofrenda de la mañana, y conforme á su libación ofrecerás, ofrenda encendida en olor de suavidad á Jehová. [^8] Mas el día del sábado dos corderos de un año sin defecto, y dos décimas de flor de harina amasada con aceite, por presente, con su libación: [^9] Es el holocausto del sábado en cada sábado, además del holocausto continuo y su libación. [^10] Y en los principios de vuestros meses ofreceréis en holocausto á Jehová dos becerros de la vacada, y un carnero, y siete corderos de un año sin defecto; [^11] Y tres décimas de flor de harina amasada con aceite, por presente con cada becerro; y dos décimas de flor de harina amasada con aceite, por presente con cada carnero; [^12] Y una décima de flor de harina amasada con aceite, en ofrenda por presente con cada cordero: holocausto de olor suave, ofrenda encendida á Jehová. [^13] Y sus libaciones de vino, medio hin con cada becerro, y el tercio de un hin con cada carnero, y la cuarta de un hin con cada cordero. Este es el holocausto de cada mes por todos los meses del año. [^14] Y un macho cabrío en expiación se ofrecerá á Jehová, además del holocausto continuo con su libación. [^15] Mas en el mes primero, á los catorce del mes será la pascua de Jehová. [^16] Y á los quince días de aqueste mes, la solemnidad: por siete días se comerán ázimos. [^17] El primer día, santa convocación; ninguna obra servil haréis: [^18] Y ofreceréis por ofrenda encendida en holocausto á Jehová dos becerros de la vacada, y un carnero, y siete corderos de un año: sin defecto los tomaréis: [^19] Y su presente de harina amasada con aceite: tres décimas con cada becerro, y dos décimas con cada carnero ofreceréis; [^20] Con cada uno de los siete corderos ofreceréis una décima; [^21] Y un macho cabrío por expiación, para reconciliaros. [^22] Esto ofreceréis además del holocausto de la mañana, que es el holocausto continuo. [^23] Conforme á esto ofreceréis cada uno de los siete días, vianda y ofrenda encendida en olor de suavidad á Jehová; ofrecerse ha, además del holocausto continuo, con su libación. [^24] Y el séptimo día tendréis santa convocación: ninguna obra servil haréis. [^25] Además el día de las primicias, cuando ofreciereis presente nuevo á Jehová en vuestras semanas, tendréis santa convocación: ninguna obra servil haréis: [^26] Y ofreceréis en holocausto, en olor de suavidad á Jehová, dos becerros de la vacada, un carnero, siete corderos de un año: [^27] Y el presente de ellos, flor de harina amasada con aceite, tres décimas con cada becerro, dos décimas con cada carnero, [^28] Con cada uno de los siete corderos una décima; [^29] Un macho cabrío, para hacer expiación por vosotros. [^30] Los ofreceréis, además del holocausto continuo con sus presentes, y sus libaciones: sin defecto los tomaréis. [^31] 

[[Numbers - 27|<--]] Numbers - 28 [[Numbers - 29|-->]]

---
# Notes
