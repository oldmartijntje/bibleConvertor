---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 6 - Reina Valera (1602)"
---
[[Numbers - 5|<--]] Numbers - 6 [[Numbers - 7|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Numbers]]

# Numbers - 6

Y HABLO Jehová á Moisés, diciendo: [^1] Habla á los hijos de Israel, y diles: El hombre, ó la mujer, cuando se apartare haciendo voto de Nazareo, para dedicarse á Jehová, [^2] Se abstendrá de vino y de sidra; vinagre de vino, ni vinagre de sidra no beberá, ni beberá algún licor de uvas, ni tampoco comerá uvas frescas ni secas. [^3] Todo el tiempo de su nazareato, de todo lo que se hace de vid de vino, desde los granillos hasta el hollejo, no comerá. [^4] Todo el tiempo del voto de su nazareato no pasará navaja sobre su cabeza, hasta que sean cumplidos los días de su apartamiento á Jehová: santo será; dejará crecer las guedejas del cabello de su cabeza. [^5] Todo el tiempo que se apartaré á Jehová, no entrará á persona muerta. [^6] Por su padre, ni por su madre, por su hermano, ni por su hermana, no se contaminará con ellos cuando murieren; porque consagración de su Dios tiene sobre su cabeza. [^7] Todo el tiempo de su nazareato, será santo á Jehová. [^8] Y si alguno muriere muy de repente junto á el, contaminará la cabeza de su nazareato; por tanto el día de su purificacíon raerá su cabeza; al séptimo día la raerá. [^9] Y el día octavo traerá dos tórtolas ó dos palominos al sacerdote, á la puerta del tabernáculo del testimonio; [^10] Y el sacerdote hará el uno en expiación, y el otro en holocausto: y expiarálo de lo que pecó sobre el muerto, y santificará su cabeza en aquel día. [^11] Y consagrará á Jehová los días de su nazareato, y traerá un cordero de un año en expiación por la culpa; y los días primeros serán anulados, por cuanto fué contaminado su nazareato. [^12] Esta es, pues, la ley del Nazareo el día que se cumpliere el tiempo de su nazareato: Vendrá á la puerta del tabernáculo del testimonio; [^13] Y ofrecerá su ofrenda á Jehová, un cordero de un año sin tacha en holocausto, y una cordera de un año sin defecto en expiación, y un carnero sin defecto por sacrificio de paces: [^14] Además un canastillo de cenceñas, tortas de flor de harina amasadas con aceite, y hojaldres cenceñas untadas con aceite, y su presente, y sus libaciones. [^15] Y el sacerdote lo ofrecerá delante de Jehová, y hará su expiación y su holocausto: [^16] Y ofrecerá el carnero en sacrificio de paces á Jehová, con el canastillo de las cenceñas; ofrecerá asimismo el sacerdote su presente, y sus libaciones. [^17] Entonces el Nazareo raerá á la puerta del tabernáculo del testimonio la cabeza de su nazareato, y tomará los cabellos de la cabeza de su nazareato, y los pondrá sobre el fuego que está debajo del sacrificio de las paces. [^18] Después tomará el sacerdote la espaldilla cocida del carnero, y una torta sin levadura del canastillo, y una hojaldre sin levadura, y pondrálas sobre las manos del Nazareo, después que fuere raído su nazareato: [^19] Y el sacerdote mecerá aquello, ofrenda agitada delante de Jehová; lo cual será cosa santa del sacerdote, á más del pecho mecido y de la espaldilla separada: y después podrá beber vino el Nazareo. [^20] Esta es la ley del Nazareo que hiciere voto de su ofrenda á Jehová por su nazareato, á más de lo que su mano alcanzare: según el voto que hiciere, así hará, conforme á la ley de su nazareato. [^21] Y Jehová habló á Moisés, diciendo: [^22] Habla á Aarón y á sus hijos, y diles: Asi bendeciréis á los hijos de Israel, diciéndoles: [^23] Jehová te bendiga, y te guarde: [^24] Haga resplandecer Jehová su rostro sobre ti, y haya de ti misericordia: [^25] Jehová alce á ti su rostro, y ponga en ti paz. [^26] Y pondrán mi nombre sobre los hijos de Israel, y yo los bendeciré. [^27] 

[[Numbers - 5|<--]] Numbers - 6 [[Numbers - 7|-->]]

---
# Notes
