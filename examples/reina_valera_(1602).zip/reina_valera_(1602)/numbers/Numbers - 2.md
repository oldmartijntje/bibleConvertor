---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 2 - Reina Valera (1602)"
---
[[Numbers - 1|<--]] Numbers - 2 [[Numbers - 3|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Numbers]]

# Numbers - 2

Y HABLO Jehová á Moisés y á Aarón, diciendo: [^1] Los hijos de Israel acamparán cada uno junto á su bandera, según las enseñas de las casas de sus padres; alrededor del tabernáculo del testimonio acamparán. [^2] Estos acamparán al levante, al oriente: la bandera del ejército de Judá, por sus escuadrones; y el jefe de los hijos de Judá, Naasón hijo de Aminadab: [^3] Su hueste, con los contados de ellos, setenta y cuatro mil y seiscientos. [^4] Junto á él acamparán los de la tribu de Issachâr: y el jefe de los hijos de Issachâr, Nathanael hijo de Suar; [^5] Y su hueste, con sus contados, cincuenta y cuatro mil y cuatrocientos: [^6] Y la tribu de Zabulón: y el jefe de los hijos de Zabulón, Eliab hijo de Helón; [^7] Y su hueste, con sus contados, cincuenta y siete mil y cuatrocientos. [^8] Todos los contados en el ejército de Judá, ciento ochenta y seis mil y cuatrocientos, por sus escuadrones, irán delante. [^9] La bandera del ejército de Rubén al mediodía, por sus escuadrones: y el jefe de los hijos de Rubén, Elisur hijo de Sedeur; [^10] Y su hueste, sus contados, cuarenta y seis mil y quinientos. [^11] Y acamparán junto á él los de la tribu de Simeón: y el jefe de los hijos de Simeón, Selumiel hijo de Zurisaddai; [^12] Y su hueste, con los contados de ellos, cincuenta y nueve mil y trescientos: [^13] Y la tribu de Gad: y el jefe de los hijos de Gad, Eliasaph hijo de Rehuel; [^14] Y su hueste, con los contados de ellos, cuarenta y cinco mil seiscientos y cincuenta. [^15] Todos los contados en el ejército de Rubén, ciento cincuenta y un mil cuatrocientos y cincuenta, por sus escuadrones, irán los segundos. [^16] Luego irá el tabernáculo del testimonio, el campo de los Levitas en medio de los ejércitos: de la manera que asientan el campo, así caminarán, cada uno en su lugar, junto á sus banderas. [^17] La bandera del ejército de Ephraim por sus escuadrones, al occidente: y el jefe de los hijos de Ephraim, Elisama hijo de Ammiud; [^18] Y su hueste, con los contados de ellos, cuarenta mil y quinientos. [^19] Junto á él estará la tribu de Manasés; y el jefe de los hijos de Manasés, Gamaliel hijo de Pedasur; [^20] Y su hueste, con los contados de ellos, treinta y dos mil y doscientos: [^21] Y la tribu de Benjamín: y el jefe de los hijos de Benjamín, Abidán hijo de Gedeón; [^22] Y su hueste, con los contados de ellos, treinta y cinco mil y cuatrocientos. [^23] Todos los contados en el ejército de Ephraim, ciento ocho mil y ciento, por sus escuadrones, irán los terceros. [^24] La bandera del ejército de Dan estará al aquilón, por sus escuadrones: y el jefe de los hijos de Dan, Ahiezer hijo de Amisaddai; [^25] Y su hueste, con los contados de ellos, sesenta y dos mil y setecientos. [^26] Junto á él acamparán los de la tribu de Aser: y el jefe de los hijos de Aser, Phegiel hijo de Ocrán; [^27] Y su hueste, con los contados de ellos, cuarenta y un mil y quinientos: [^28] Y la tribu de Nephtalí: y el jefe de los hijos de Nephtalí, Ahira hijo de Enán; [^29] Y su hueste, con los contados de ellos, cincuenta y tres mil y cuatrocientos. [^30] Todos los contados en el ejército de Dan, ciento cincuenta y siete mil y seiscientos: irán los postreros tras sus banderas. [^31] Estos son los contados de los hijos de Israel, por las casas de sus padres: todos los contados por ejércitos, por sus escuadrones, seiscientos tres mil quinientos y cincuenta. [^32] Mas los Levitas no fueron contados entre los hijos de Israel; como Jehová lo mandó á Moisés. [^33] E hicieron los hijos de Israel conforme á todas las cosas que Jehová mandó á Moisés; así asentaron el campo por sus banderas, y así marcharon cada uno por sus familias, según las casas de sus padres. [^34] 

[[Numbers - 1|<--]] Numbers - 2 [[Numbers - 3|-->]]

---
# Notes
