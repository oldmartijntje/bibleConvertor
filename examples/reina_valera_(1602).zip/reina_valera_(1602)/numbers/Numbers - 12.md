---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 12 - Reina Valera (1602)"
---
[[Numbers - 11|<--]] Numbers - 12 [[Numbers - 13|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Numbers]]

# Numbers - 12

Y HABLARON María y Aarón contra Moisés á causa de la mujer Ethiope que había tomado: porque él había tomado mujer Ethiope. [^1] Y dijeron: ¿Solamente por Moisés ha hablado Jehová? ¿no ha hablado también por nosotros? Y oyólo Jehová. [^2] Y aquel varón Moisés era muy manso, más que todos los hombres que había sobre la tierra, [^3] Y luego dijo Jehová á Moisés, y á Aarón, y á María: Salid vosotros tres al tabernáculo del testimonio. Y salieron ellos tres. [^4] Entonces Jehová descendió en la columna de la nube, y púsose á la la puerta del tabernáculo, y llamó á Aarón y á María; y salieron ellos ambos. [^5] Y él les dijo: Oid ahora mis palabras: si tuviereis profeta de Jehová, le apareceré en visión, en sueños hablaré con él. [^6] No así á mi siervo Moisés, que es fiel en toda mi casa: [^7] Boca á boca hablaré con él, y á las claras, y no por figuras; y verá la apariencia de Jehová: ¿por qué pues no tuvisteis temor de hablar contra mi siervo Moisés? [^8] Entonces el furor de Jehová se encendió en ellos; y fuése. [^9] Y la nube se apartó del tabernáculo: y he aquí que María era leprosa como la nieve; y miró Aarón á María, y he aquí que estaba leprosa. [^10] Y dijo Aarón á Moisés: ­Ah! señor mío, no pongas ahora sobre nosotros pecado; porque locamente lo hemos hecho, y hemos pecado. [^11] No sea ella ahora como el que sale muerto del vientre de su madre, consumida la mitad de su carne. [^12] Entonces Moisés clamó á Jehová, diciendo: Ruégote, oh Dios, que la sanes ahora. [^13] Respondió Jehová á Moisés: Pues si su padre hubiera escupido en su cara, ¿no se avergonzaría por siete días?: sea echada fuera del real por siete días, y después se reunirá. [^14] Así María fué echada del real siete días; y el pueblo no pasó adelante hasta que se le reunió María. [^15] Y DESPUÉS movió el pueblo de Haseroth, y asentaron el campo en el desierto de Parán. [^16] 

[[Numbers - 11|<--]] Numbers - 12 [[Numbers - 13|-->]]

---
# Notes
