---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 27 - Reina Valera (1602)"
---
[[Numbers - 26|<--]] Numbers - 27 [[Numbers - 28|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Numbers]]

# Numbers - 27

Y LAS hijas de Salphaad, hijo de Hepher, hijo de Galaad, hijo de Machîr, hijo de Manasés, de las familias de Manasés, hijo de José, los nombres de las cuales eran Maala, y Noa, y Hogla, y Milca, y Tirsa, llegaron; [^1] Y presentáronse delante de Moisés, y delante del sacerdote Eleazar, y delante de los príncipes, y de toda la congregación, á la puerta del tabernáculo del testimonio, y dijeron: [^2] Nuestro padre murió en el desierto, el cual no estuvo en la junta que se reunió contra Jehová en la compañía de Coré: sino que en su pecado murió, y no tuvo hijos. [^3] ¿Por qué será quitado el nombre de nuestro padre de entre su familia, por no haber tenido hijo? Danos heredad entre los hermanos de nuestro padre. [^4] Y Moisés llevó su causa delante de Jehová. [^5] Y Jehová respondió á Moisés, diciendo: [^6] Bien dicen las hijas de Salphaad: has de darles posesión de heredad entre los hermanos de su padre; y traspasarás la heredad de su padre á ellas. [^7] Y á los hijos de Israel hablarás, diciendo: Cuando alguno muriere sin hijos, traspasaréis su herencia á su hija: [^8] Y si no tuviere hija, daréis su herencia á sus hermanos: [^9] Y si no tuviere hermanos, daréis su herencia á los hermanos de su padre. [^10] Y si su padre no tuviere hermanos, daréis su herencia á su pariente más cercano de su linaje, el cual la poseerá: y será á los hijos de Israel por estatuto de derecho, como Jehová mandó á Moisés. [^11] Y Jehová dijo á Moisés: Sube á este monte Abarim, y verás la tierra que he dado á los hijos de Israel. [^12] Y después que la habrás visto, tú también serás reunido á tus pueblos, como fué reunido tu hermano Aarón: [^13] Pues fuisteis rebeldes á mi dicho en el desierto de Zin, en la rencilla de la congregación, para santificarme en las aguas á ojos de ellos. Estas son las aguas de la rencilla de Cades en el desierto de Zin. [^14] Entonces respondió Moisés á Jehová, diciendo: [^15] Ponga Jehová, Dios de los espíritus de toda carne, varón sobre la congregación, [^16] Que salga delante de ellos, y que entre delante de ellos, que los saque y los introduzca; porque la congregación de Jehová no sea como ovejas sin pastor. [^17] Y Jehová dijo á Moisés: Toma á Josué hijo de Nun, varón en el cual hay espíritu, y pondrás tu mano sobre él; [^18] Y ponerlo has delante de Eleazar el sacerdote, y delante de toda la congregación; y le darás órdenes en presencia de ellos. [^19] Y pondrás de tu dignidad sobre él, para que toda la congregación de los hijos de Israel le obedezcan. [^20] Y él estará delante de Eleazar el sacerdote, y á él preguntará por el juicio del Urim delante de Jehová: por el dicho de él saldrán, y por el dicho de él entrarán, él, y todos los hijos de Israel con él, y toda la congregación. [^21] Y Moisés hizo como Jehová le había mandado; que tomó á Josué, y le puso delante de Eleazar el sacerdote, y de toda la congregación: [^22] Y puso sobre él sus manos, y dióle órdenes, como Jehová había mandado por mano de Moisés. [^23] 

[[Numbers - 26|<--]] Numbers - 27 [[Numbers - 28|-->]]

---
# Notes
