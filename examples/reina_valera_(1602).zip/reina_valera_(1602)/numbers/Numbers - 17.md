---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 17 - Reina Valera (1602)"
---
[[Numbers - 16|<--]] Numbers - 17 [[Numbers - 18|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Numbers]]

# Numbers - 17

Y HABLO Jehová á Moisés, diciendo: [^1] Habla á los hijos de Israel, y toma de ellos una vara por cada casa de los padres, de todos los príncipes de ellos, doce varas conforme á las casas de sus padres; y escribirás el nombre de cada uno sobre su vara. [^2] Y escribirás el nombre de Aarón sobre la vara de Leví; porque cada cabeza de familia de sus padres tendrá una vara. [^3] Y las pondrás en el tabernáculo del testimonio delante del testimonio, donde yo me declararé á vosotros. [^4] Y será, que el varón que yo escogiere, su vara florecerá: y haré cesar de sobre mí las quejas de los hijos de Israel, con que murmuran contra vosotros. [^5] Y Moisés habló á los hijos de Israel, y todos los príncipes de ellos le dieron varas; cada príncipe por las casas de sus padres una vara, en todas doce varas; y la vara de Aarón estaba entre las varas de ellos. [^6] Y Moisés puso las varas delante de Jehová en el tabernáculo del testimonio. [^7] Y aconteció que el día siguiente vino Moisés al tabernáculo del testimonio; y he aquí que la vara de Aarón de la casa de Leví había brotado, y echado flores, y arrojado renuevos, y producido almendras. [^8] Entonces sacó Moisés todas las varas de delante de Jehová á todos los hijos de Israel; y ellos lo vieron, y tomaron cada uno su vara. [^9] Y Jehová dijo á Moisés: Vuelve la vara de Aarón delante del testimonio, para que se guarde por señal á los hijos rebeldes; y harás cesar sus quejas de sobre mí, porque no mueran. [^10] E hízolo Moisés: como le mandó Jehová, así hizo. [^11] Entonces los hijos de Israel hablaron á Moisés, diciendo: He aquí nosotros somos muertos, perdidos somos, todos nosotros somos perdidos. [^12] Cualquiera que se llegare, el que se acercare al tabernáculo de Jehová morirá: ¿acabaremos de perecer todos? [^13] 

[[Numbers - 16|<--]] Numbers - 17 [[Numbers - 18|-->]]

---
# Notes
