---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 36 - Reina Valera (1602)"
---
[[Numbers - 35|<--]] Numbers - 36

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Numbers]]

# Numbers - 36

Y LLEGARON los príncipes de los padres de la familia de Galaad, hijo de Machîr, hijo de Manasés, de las familias de los hijos de José; y hablaron delante de Moisés, y de los príncipes, cabezas de padres de los hijos de Israel, [^1] Y dijeron: Jehová mandó á mi señor que por suerte diese la tierra á los hijos de Israel en posesión: también ha mandado Jehová á mi señor, que dé la posesión de Salphaad nuestro hermano á sus hijas; [^2] Las cuales, si se casaren con algunos de los hijos de las otras tribus de los hijos de Israel, la herencia de ellas será así desfalcada de la herencia de nuestros padres, y será añadida á la herencia de la tribu á que serán unidas: y será quitada de la suerte de nuestra heredad. [^3] Y cuando viniere el jubileo de los hijos de Israel, la heredad de ellas será añadida á la heredad de la tribu de sus maridos; y así la heredad de ellas será quitada de la heredad de la tribu de nuestros padres. [^4] Entonces Moisés mandó á los hijos de Israel por dicho de Jehová, diciendo: La tribu de los hijos de José habla rectamente. [^5] Esto es lo que ha mandado Jehová acerca de las hijas de Salphaad, diciendo: Cásense como á ellas les pluguiere, empero en la familia de la tribu de su padre se casarán; [^6] Para que la heredad de los hijos de Israel no sea traspasada de tribu en tribu; porque cada uno de los hijos de Israel se allegará á la heredad de la tribu de sus padres. [^7] Y cualquiera hija que poseyere heredad de las tribus de los hijos de Israel, con alguno de la familia de la tribu de su padre se casará, para que los hijos de Israel posean cada uno la heredad de sus padres. [^8] Y no ande la heredad rodando de una tribu á otra: mas cada una de las tribus de los hijos de Israel se llegue á su heredad. [^9] Como Jehová mandó á Moisés, así hicieron las hijas de Salphaad. [^10] Y así Maala, y Tirsa, y Hogla, y Milchâ, y Noa, hijas de Salphaad, se casaron con hijos de sus tíos: [^11] De la familia de los hijos de Manasés, hijo de José, fueron mujeres; y la heredad de ellas quedó en la tribu de la familia de su padre. [^12] Estos son los mandamientos y los estatutos que mandó Jehová por mano de Moisés á los hijos de Israel en los campos de Moab, junto al Jordán de Jericó. [^13] 

[[Numbers - 35|<--]] Numbers - 36

---
# Notes
