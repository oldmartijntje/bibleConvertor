---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 24 - Reina Valera (1602)"
---
[[Numbers - 23|<--]] Numbers - 24 [[Numbers - 25|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Numbers]]

# Numbers - 24

Y COMO vió Balaam que parecía bien á Jehová que el bendijese á Israel, no fué, como la primera y segunda vez, á encuentro de agüeros, sino que puso su rostro hacia el desierto; [^1] Y alzando sus ojos, vió á Israel alojado por sus tribus; y el espíritu de Dios vino sobre él. [^2] Entonces tomó su parábola, y dijo: Dijo Balaam hijo de Beor, Y dijo el varón de ojos abiertos: [^3] Dijo el que oyó los dichos de Dios, El que vió la visión del Omnipotente; Caído, mas abiertos los ojos: [^4] Cuán hermosas son tus tiendas, oh Jacob, Tus habitaciones, oh Israel! [^5] Como arroyos están extendidas, Como huertos junto al río, Como lináloes plantados por Jehová, Como cedros junto á las aguas. [^6] De sus manos destilarán aguas, Y su simiente será en muchas aguas: Y ensalzarse ha su rey más que Agag, Y su reino será ensalzado. [^7] Dios lo sacó de Egipto; Tiene fuerzas como de unicornio: Comerá á las gentes sus enemigas, Y desmenuzará sus huesos, Y asaeteará con sus saetas. [^8] Se encorvará para echarse como león, Y como leona; ¿quién lo despertará? Benditos los que te bendijeren, Y malditos los que te maldijeren. [^9] Entonces se encendió la ira de Balac contra Balaam, y batiendo sus palmas le dijo: Para maldecir á mis enemigos te he llamado, y he aquí los has resueltamente bendecido ya tres veces. [^10] Húyete, por tanto, ahora á tu lugar: yo dije que te honraría, mas he aquí que Jehová te ha privado de honra. [^11] Y Balaam le respondió: ¿No lo declaré yo también á tus mensajeros que me enviaste, diciendo: [^12] Si Balac me diése su casa llena de plata y oro, yo no podré traspasar el dicho de Jehová para hacer cosa buena ni mala de mi arbitrio; mas lo que Jehová hablare, eso diré yo? [^13] He aquí yo me voy ahora á mi pueblo: por tanto, ven, te indicaré lo que este pueblo ha de hacer á tu pueblo en los postrimeros días. [^14] Y tomó su parábola, y dijo: Dijo Balaam hijo de Beor, Dijo el varón de ojos abiertos: [^15] Dijo el que oyó los dichos de Jehová, Y el que sabe la ciencia del Altísimo, El que vió la visión del Omnipotente; Caído, mas abiertos los ojos: [^16] Verélo, mas no ahora: Lo miraré, mas no de cerca: Saldrá ESTRELLA de Jacob, Y levantaráse cetro de Israel, Y herirá los cantones de Moab, Y destruirá á todos los hijos de Seth. [^17] Y será tomada Edom, Será también tomada Seir por sus enemigos, E Israel se portará varonilmente. [^18] Y el de Jacob se enseñoreará, Y destruirá de la ciudad lo que quedare. [^19] Y viendo á Amalec, tomó su parábola, y dijo: Amalec, cabeza de gentes; Mas su postrimería perecerá para siempre. [^20] Y viendo al Cineo, tomó su parábola, y dijo: Fuerte es tu habitación, Pon en la peña tu nido: [^21] Que el Cineo será echado, Cuando Assur te llevará cautivo. [^22] Todavía tomó su parábola, y dijo: ­Ay! ¿quién vivirá cuando hiciere Dios estas cosas? [^23] Y vendrán navíos de la costa de Cittim, Y afligirán á Assur, afligirán también á Eber: Mas él también perecerá para siempre. [^24] Entonces se levantó Balaam, y se fué, y volvióse á su lugar: y también Balac se fué por su camino. [^25] 

[[Numbers - 23|<--]] Numbers - 24 [[Numbers - 25|-->]]

---
# Notes
