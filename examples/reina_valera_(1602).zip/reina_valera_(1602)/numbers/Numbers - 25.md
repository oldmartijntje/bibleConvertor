---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 25 - Reina Valera (1602)"
---
[[Numbers - 24|<--]] Numbers - 25 [[Numbers - 26|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Numbers]]

# Numbers - 25

Y REPOSO Israel en Sittim, y el pueblo empezó á fornicar con las hijas de Moab: [^1] Las cuales llamaron al pueblo á los sacrificios de sus dioses: y el pueblo comió, é inclinóse á sus dioses. [^2] Y allegóse el pueblo á Baal-peor; y el furor de Jehová se encendió contra Israel. [^3] Y Jehová dijo á Moisés: Toma todos los príncipes del pueblo, y ahórcalos á Jehová delante del sol; y la ira del furor de Jehová se apartará de Israel. [^4] Entonces Moisés dijo á los jueces de Israel: Matad cada uno á aquellos de los suyos que se han allegado á Baal-peor. [^5] Y he aquí un varón de los hijos de Israel vino y trajo una Madianita á sus hermanos, á ojos de Moisés y de toda la congregación de los hijos de Israel, llorando ellos á la puerta del tabernáculo del testimonio. [^6] Y viólo Phinees, hijo de Eleazar, hijo de Aarón el sacerdote, y levantóse de en medio de la congregación, y tomó una lanza en su mano: [^7] Y fué tras el varón de Israel á la tienda, y alanceólos á ambos, al varón de Israel, y á la mujer por su vientre. Y cesó la mortandad de los hijos de Israel. [^8] Y murieron de aquella mortandad veinte y cuatro mil. [^9] Entonces Jehová habló á Moisés, diciendo: [^10] Phinees, hijo de Eleazar, hijo de Aarón el sacerdote, ha hecho tornar mi furor de los hijos de Israel, llevado de celo entre ellos: por lo cual yo no he consumido en mi celo á los hijos de Israel. [^11] Por tanto di les: He aquí yo establezco mi pacto de paz con él; [^12] Y tendrá él, y su simiente después de él, el pacto del sacerdocio perpetuo; por cuanto tuvo celo por su Dios, é hizo expiación por los hijos de Israel. [^13] Y el nombre del varón muerto, que fué muerto con la Madianita, era Zimri hijo de Salu, jefe de una familia de la tribu de Simeón. [^14] Y el nombre de la mujer Madianita muerta, era Cozbi, hija de Zur, príncipe de pueblos, padre de familia en Madián. [^15] Y Jehová habló á Moisés, diciendo: [^16] Hostilizaréis á los Madianitas, y los heriréis: [^17] Por cuanto ellos os afligieron á vosotros con sus ardides, con que os han engañado en el negocio de Peor, y en el negocio de Cozbi, hija del príncipe de Madián, su hermana, la cual fué muerta el día de la mortandad por causa de Peor. [^18] 

[[Numbers - 24|<--]] Numbers - 25 [[Numbers - 26|-->]]

---
# Notes
