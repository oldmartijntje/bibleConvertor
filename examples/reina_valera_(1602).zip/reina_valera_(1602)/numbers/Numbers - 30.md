---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 30 - Reina Valera (1602)"
---
[[Numbers - 29|<--]] Numbers - 30 [[Numbers - 31|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Numbers]]

# Numbers - 30

Y habló Moisés á los príncipes de las tribus de los hijos de Israel, diciendo: Esto es lo que Jehová ha mandado. [^1] Cuando alguno hiciere voto á Jehová, ó hiciere juramento ligando su alma con obligación, no violará su palabra: hará conforme á todo lo que salió de su boca. [^2] Mas la mujer, cuando hiciere voto á Jehová, y se ligare con obligación en casa de su padre, en su mocedad; [^3] Si su padre oyere su voto, y la obligación con que ligó su alma, y su padre callare á ello, todos los votos de ella serán firmes, y toda obligación con que hubiere ligado su alma, firme será. [^4] Mas si su padre le vedare el día que oyere todos sus votos y sus obligaciones, con que ella hubiere ligado su alma, no serán firmes; y Jehová la perdonará, por cuanto su padre le vedó. [^5] Empero si fuére casada, é hiciere votos, o pronunciare de sus labios cosa con que obligue su alma; [^6] Si su marido lo oyere, y cuando lo oyere callare á ello, los votos de ella serán firmes, y la obligación con que ligó su alma, firme será. [^7] Pero si cuando su marido lo oyó, le vedó, entonces el voto que ella hizo, y lo que pronunció de sus labios con que ligó su alma, será nulo; y Jehová lo perdonará. [^8] Mas todo voto de viuda, ó repudiada, con que ligare su alma, será firme. [^9] Y si hubiere hecho voto en casa de su marido, y hubiere ligado su alma con obligación de juramento, [^10] Si su marido oyó, y calló á ello, y no le vedó; entonces todos sus votos serán firmes, y toda obligación con que hubiere ligado su alma, firme será. [^11] Mas si su marido los anuló el día que los oyó; todo lo que salió de sus labios cuanto á sus votos, y cuanto á la obligación de su alma, será nulo; su marido los anuló, y Jehová la perdonará. [^12] Todo voto, ó todo juramento obligándose á afligir el alma, su marido lo confirmará, ó su marido lo anulará. [^13] Empero si su marido callare á ello de día en día, entonces confirmó todos sus votos, y todas las obligaciones que están sobre ella: confirmólas, por cuanto calló á ello el día que lo oyó. [^14] Mas si las anulare después de haberlas oido, entonces él llevará el pecado de ella. [^15] Estas son las ordenanzas que Jehová mandó á Moisés entre el varón y su mujer, entre el padre y su hija, durante su mocedad en casa de su padre. [^16] 

[[Numbers - 29|<--]] Numbers - 30 [[Numbers - 31|-->]]

---
# Notes
