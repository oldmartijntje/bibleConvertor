---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 34 - Reina Valera (1602)"
---
[[Numbers - 33|<--]] Numbers - 34 [[Numbers - 35|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Numbers]]

# Numbers - 34

Y JEHOVA habló á Moisés, diciendo: [^1] Manda á los hijos de Israel, y diles: Cuando hubiereis entrado en la tierra de Canaán, es á saber, la tierra que os ha de caer en heredad, la tierra de Canaán según sus términos; [^2] Tendréis el lado del mediodía desde el desierto de Zin hasta los términos de Edom; y os será el término del mediodía al extremo del mar salado hacia el oriente: [^3] Y este término os irá rodeando desde el mediodía hasta la subida de Acrabbim, y pasará hasta Zin; y sus salidas serán del mediodía á Cades-barnea; y saldrá á Hasar-addar, y pasará hasta Asmón; [^4] Y rodeará este término, desde Asmón hasta el torrente de Egipto, y sus remates serán al occidente. [^5] Y el término occidental os será la gran mar: este término os será el término occidental. [^6] Y el término del norte será este: desde la gran mar os señalaréis el monte de Hor; [^7] Del monte de Hor señalaréis á la entrada de Hamath, y serán las salidas de aquel término á Sedad; [^8] Y saldrá este término á Ziphón, y serán sus remates en Hasar-enán: este os será el término del norte. [^9] Y por término al oriente os señalaréis desde Hasar-enán hasta Sepham; [^10] Y bajará este término desde Sepham á Ribla, al oriente de Ain: y descenderá el término, y llegará á la costa de la mar de Cinnereth al oriente; [^11] Después descenderá este término al Jordán, y serán sus salidas al mar Salado: esta será vuestra tierra: por sus términos alrededor. [^12] Y mandó Moisés á los hijos de Israel, diciendo: Esta es la tierra que heredaréis por suerte, la cual mandó Jehová que diese á las nueve tribus, y á la media tribu: [^13] Porque la tribu de los hijos de Rubén según las casas de sus padres, y la tribu de los hijos de Gad según las casas de sus padres, y la media tribu de Manasés, han tomado su herencia: [^14] Dos tribus y media tomaron su heredad de esta parte del Jordán de Jericó al oriente, al nacimiento del sol. [^15] Y habló Jehová á Moisés, diciendo: [^16] Estos son los nombres de los varones que os aposesionarán la tierra: Eleazar el sacerdote, y Josué hijo de Nun. [^17] Tomaréis también de cada tribu un príncipe, para dar la posesión de la tierra. [^18] Y estos son los nombres de los varones: De la tribu de Judá, Caleb hijo de Jephone. [^19] Y de la tribu de los hijos de Simeón, Samuel hijo de Ammiud. [^20] De la tribu de Benjamín; Elidad hijo de Chislón. [^21] Y de la tribu de los hijos de Dan, el príncipe Bucci hijo de Jogli. [^22] De los hijos de José: de la tribu de los hijos de Manasés, el príncipe Haniel hijo de Ephod. [^23] Y de la tribu de los hijos de Ephraim, el príncipe Chêmuel hijo de Siphtán. [^24] Y de la tribu de los hijos de Zabulón, el príncipe Elisaphán hijo de Pharnach. [^25] Y de la tribu de los hijos de Issachâr, el príncipe Paltiel hijo de Azan. [^26] Y de la tribu de los hijos de Aser, el príncipe Ahiud hijo de Selomi. [^27] Y de la tribu de los hijos de Nephtalí, el príncipe Pedael hijo de Ammiud. [^28] Estos son á los que mandó Jehová que hiciesen la partición de la herencia á los hijos de Israel en la tierra de Canaán. [^29] 

[[Numbers - 33|<--]] Numbers - 34 [[Numbers - 35|-->]]

---
# Notes
