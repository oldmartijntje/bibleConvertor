---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 19 - Reina Valera (1602)"
---
[[Numbers - 18|<--]] Numbers - 19 [[Numbers - 20|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Numbers]]

# Numbers - 19

Y Jehová habló á Moisés y á Aarón, diciendo: [^1] Esta es la ordenanza de la ley que Jehová ha prescrito, diciendo: Di á los hijos de Israel que te traigan una vaca bermeja, perfecta, en la cual no haya falta, sobre la cual no se haya puesto yugo: [^2] Y la daréis á Eleazar el sacerdote, y él la sacará fuera del campo, y harála degollar en su presencia. [^3] Y tomará Eleazar el sacerdote de su sangre con su dedo, y rociará hacia la delantera del tabernáculo del testimonio con la sangre de ella siete veces; [^4] Y hará quemar la vaca ante sus ojos: su cuero y su carne y su sangre, con su estiercol, hará quemar. [^5] Luego tomará el sacerdote palo de cedro, é hisopo, y escarlata, y lo echará en medio del fuego en que arde la vaca. [^6] El sacerdote lavará luego sus vestidos, lavará también su carne con agua, y después entrará en el real; y será inmundo el sacerdote hasta la tarde. [^7] Asimismo el que la quemó, lavará sus vestidos en agua, también lavará en agua su carne, y será inmundo hasta la tarde. [^8] Y un hombre limpio recogerá las cenizas de la vaca, y las pondrá fuera del campo en lugar limpio, y las guardará la congregación de los hijos de Israel para el agua de separación: es una expiación. [^9] Y el que recogió las cenizas de la vaca, lavará sus vestidos, y será inmundo hasta la tarde: y será á los hijos de Israel, y al extranjero que peregrina entre ellos, por estatuto perpetuo. [^10] El que tocare muerto de cualquiera persona humana, siete días será inmundo: [^11] Este se purificará al tercer día con aquesta agua, y al séptimo día será limpio; y si al tercer día no se purificare, no será limpio al séptimo día. [^12] Cualquiera que tocare en muerto, en persona de hombre que estuviere muerto, y no se purificare, el tabernáculo de Jehová contaminó; y aquella persona será cortada de Israel: por cuanto el agua de la separación no fué rociada sobre él, inmundo será; y su inmundicia será sobre él. [^13] Esta es la ley para cuando alguno muriere en la tienda: cualquiera que entrare en la tienda y todo lo que estuviere en ella, será inmundo siete días. [^14] Y todo vaso abierto, sobre el cual no hubiere tapadera bien ajustada, sera inmundo. [^15] Y cualquiera que tocare en muerto á cuchillo sobre la haz del campo, ó en muerto, ó en hueso humano, ó en sepulcro, siete días será inmundo. [^16] Y para el inmundo tomarán de la ceniza de la quemada vaca de la expiación, y echarán sobre ella agua viva en un vaso: [^17] Y un hombre limpio tomará hisopo. y mojarálo en el agua, y rociará sobre la tienda, y sobre todos los muebles, y sobre las personas que allí estuvieren, y sobre aquel que hubiere tocado el hueso, ó el matado, ó el muerto, ó el sepulcro: [^18] Y el limpio rociará sobre el inmundo al tercero y al séptimo día: y cuando lo habrá purificado al día séptimo, él lavará luego sus vestidos, y á sí mismo se lavará con agua, y será limpio á la tarde. [^19] Y el que fuere inmundo, y no se purificare, la tal persona será cortada de entre la congregación, por cuanto contaminó el tabernáculo de Jehová: no fué rociada sobre él el agua de separación, es inmundo. [^20] Y les será por estatuto perpetuo: también el que rociare el agua de la separación lavará sus vestidos; y el que tocare el agua de la separación, será inmundo hasta la tarde. [^21] Y todo lo que el inmundo tocare, será inmundo: y la persona que lo tocare, será inmunda hasta la tarde. [^22] 

[[Numbers - 18|<--]] Numbers - 19 [[Numbers - 20|-->]]

---
# Notes
