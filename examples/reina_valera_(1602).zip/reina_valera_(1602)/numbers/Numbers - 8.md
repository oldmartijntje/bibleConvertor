---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 8 - Reina Valera (1602)"
---
[[Numbers - 7|<--]] Numbers - 8 [[Numbers - 9|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Numbers]]

# Numbers - 8

Y HABLO Jehová á Moisés, diciendo: [^1] Habla á Aarón, y dile: Cuando encendieres las lámparas, las siete lámparas alumbrarán frente á frente del candelero. [^2] Y Aarón lo hizo así; que encendió enfrente del candelero sus lámparas, como Jehová lo mandó á Moisés. [^3] Y esta era la hechura del candelero: de oro labrado á martillo; desde su pie hasta sus flores era labrado á martillo: conforme al modelo que Jehová mostró á Moisés, así hizo el candelero. [^4] Y Jehová habló á Moisés, diciendo: [^5] Toma á los Levitas de entre los hijos de Israel, y expíalos. [^6] Y así les harás para expiarlos: rocía sobre ellos el agua de la expiación, y haz pasar la navaja sobre toda su carne, y lavarán sus vestidos, y serán expiados. [^7] Luego tomarán un novillo, con su presente de flor de harina amasada con aceite; y tomarás otro novillo para expiación. [^8] Y harás llegar los Levitas delante del tabernáculo del testimonio, y juntarás toda la congregación de los hijos de Israel; [^9] Y cuando habrás hecho llegar los Levitas delante de Jehová, pondrán los hijos de Israel sus manos sobre los Levitas; [^10] Y ofrecerá Aarón los Levitas delante de Jehová en ofrenda de los hijos de Israel, y servirán en el ministerio de Jehová. [^11] Y los Levitas pondrán sus manos sobre las cabezas de los novillos: y ofrecerás el uno por expiación, y el otro en holocausto á Jehová, para expiar los Levitas. [^12] Y harás presentar los Levitas delante de Aarón, y delante de sus hijos, y los ofrecerás en ofrenda á Jehová. [^13] Así apartarás los Levitas de entre los hijos de Israel; y serán míos los Levitas [^14] Y después de eso vendrán los Levitas á ministrar en el tabernáculo del testimonio: los expiarás pues, y los ofrecerás en ofrenda. [^15] Porque enteramente me son á mí dados los Levitas de entre los hijos de Israel, en lugar de todo aquel que abre matriz; helos tomado para mí en lugar de los primogénitos de todos los hijos de Israel. [^16] Porque mío es todo primogénito en los hijos de Israel, así de hombres como de animales; desde el día que yo herí todo primogénito en la tierra de Egipto, los santifiqué para mí. [^17] Y he tomado los Levitas en lugar de todos los primogénitos en los hijos de Israel. [^18] Y yo he dado en don los Levitas á Aarón y á sus hijos de entre los hijos de Israel, para que sirvan el ministerio de los hijos de Israel en el tabernáculo del testimonio, y reconcilien á los hijos de Israel; porque no haya plaga en los hijos de Israel, llegando los hijos de Israel al santuario. [^19] Y Moisés, y Aarón, y toda la congregación de los hijos de Israel, hicieron de los Levitas conforme á todas las cosas que mandó Jehová á Moisés acerca de los Levitas; así hicieron de ellos los hijos de Israel. [^20] Y los Levitas se purificaron, y lavaron sus vestidos; y Aarón los ofreció en ofrenda delante de Jehová, é hizo Aarón expiación por ellos para purificarlos. [^21] Y así vinieron después los Levitas para servir en su ministerio en el tabernáculo del testimonio, delante de Aarón y delante de sus hijos: de la manera que mandó Jehová á Moisés acerca de los Levitas, así hicieron con ellos. [^22] Y habló Jehová á Moisés, diciendo: [^23] Esto cuanto á los Levitas: de veinte y cinco años arriba entrarán á hacer su oficio en el servicio del tabernáculo del testimonio: [^24] Mas desde los cincuenta años volverán del oficio de su ministerio, y nunca más servirán: [^25] Pero servirán con sus hermanos en el tabernáculo del testimonio, para hacer la guarda, bien que no servirán en el ministerio. Así harás de los Levitas cuanto á sus oficios. [^26] 

[[Numbers - 7|<--]] Numbers - 8 [[Numbers - 9|-->]]

---
# Notes
