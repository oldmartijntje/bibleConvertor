---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 23 - Reina Valera (1602)"
---
[[Numbers - 22|<--]] Numbers - 23 [[Numbers - 24|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Numbers]]

# Numbers - 23

Y BALAAM dijo á Balac: Edifícame aquí siete altares, y prepárame aquí siete becerros y siete carneros. [^1] Y Balac hizo como le dijo Balaam: y ofrecieron Balac y Balaam un becerro y un carnero en cada altar. [^2] Y Balaam dijo á Balac: Ponte junto á tu holocausto, y yo iré: quizá Jehová me vendrá al encuentro, y cualquiera cosa que me mostrare, te la noticiaré. Y así se fué solo. [^3] Y vino Dios al encuentro de Balaam, y éste le dijo: Siete altares he ordenado, y en cada altar he ofrecido un becerro y un carnero. [^4] Y Jehová puso palabra en la boca de Balaam, y díjole: Vuelve á Balac, y has de hablar así. [^5] Y volvió á él, y he aquí estaba él junto á su holocausto, él y todos los príncipes de Moab. [^6] Y él tomó su parábola, y dijo: De Aram me trajo Balac, Rey de Moab, de los montes del oriente: Ven, maldíceme á Jacob; Y ven, execra á Israel. [^7] ¿Por qué maldeciré yo al que Dios no maldijo? ¿Y por qué he de execrar al que Jehová no ha execrado? [^8] Porque de la cumbre de las peñas lo veré, Y desde los collados lo miraré: He aquí un pueblo que habitará confiado, Y no será contado entre las gentes. [^9] ¿Quién contará el polvo de Jacob, O el número de la cuarta parte de Israel? Muera mi persona de la muerte de los rectos, Y mi postrimería sea como la suya. [^10] Entonces Balac dijo á Balaam: ¿Qué me has hecho? hete tomado para que maldigas á mis enemigos, y he aquí has proferido bendiciones. [^11] Y él respondió, y dijo: ¿No observaré yo lo que Jehová pusiere en mi boca para decirlo? [^12] Y dijo Balac: Ruégote que vengas conmigo á otro lugar desde el cual lo veas; su extremidad solamente verás, que no lo verás todo; y desde allí me lo maldecirás. [^13] Y llevólo al campo de Sophim, á la cumbre de Pisga, y edificó siete altares, y ofreció un becerro y un carnero en cada altar. [^14] Entonces él dijo á Balac: Ponte aquí junto á tu holocausto, y yo iré á encontrar á Dios allí. [^15] Y Jehová salió al encuentro de Balaam, y puso palabra en su boca, y díjole: Vuelve á Balac, y así has de decir. [^16] Y vino á él, y he aquí que él estaba junto á su holocausto, y con él los príncipes de Moab: y díjole Balac: ¿Qué ha dicho Jehová? [^17] Entonces él tomó su parábola, y dijo: Balac, levántate y oye; Escucha mis palabras, hijo de Zippor: [^18] Dios no es hombre, para que mienta; Ni hijo de hombre para que se arrepienta: El dijo, ¿y no hará?; Habló, ¿y no lo ejecutará? [^19] He aquí, yo he tomado bendición: Y él bendijo, y no podré revocarla. [^20] No ha notado iniquidad en Jacob, Ni ha visto perversidad en Israel: Jehová su Dios es con él, Y júbilo de rey en él. [^21] Dios los ha sacado de Egipto; Tiene fuerzas como de unicornio. [^22] Porque en Jacob no hay agüero, Ni adivinación en Israel: Como ahora, será dicho de Jacob y de Israel: ­Lo que ha hecho Dios! [^23] He aquí el pueblo, que como león se levantará, Y como león se erguirá: No se echará hasta que coma la presa, Y beba la sangre de los muertos. [^24] Entonces Balac dijo á Balaam: Ya que no lo maldices, ni tampoco lo bendigas. [^25] Y Balaam respondió, y dijo á Balac: ¿No te he dicho que todo lo que Jehová me dijere, aquello tengo de hacer? [^26] Y dijo Balac á Balaam: Ruégote que vengas, te llevaré á otro lugar; por ventura parecerá bien á Dios que desde allí me lo maldigas. [^27] Y Balac llevó á Balaam á la cumbre de Peor, que mira hacia Jesimón. [^28] Entonces Balaam dijo á Balac: Edifícame aquí siete altares, y prepárame aquí siete becerros y siete carneros. [^29] Y Balac hizo como Balaam le dijo; y ofreció un becerro y un carnero en cada altar. [^30] 

[[Numbers - 22|<--]] Numbers - 23 [[Numbers - 24|-->]]

---
# Notes
