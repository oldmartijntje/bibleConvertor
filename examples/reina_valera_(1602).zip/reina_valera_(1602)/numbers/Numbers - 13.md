---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 13 - Reina Valera (1602)"
---
[[Numbers - 12|<--]] Numbers - 13 [[Numbers - 14|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Numbers]]

# Numbers - 13

Y Jehová habló á Moisés, diciendo: [^1] Envía tú hombres que reconozcan la tierra de Canaán, la cual yo doy á los hijos de Israel: de cada tribu de sus padres enviaréis un varón, cada uno príncipe entre ellos. [^2] Y Moisés los envío desde el desierto de Parán, conforme á la palabra de Jehová: y todos aquellos varones eran príncipes de los hijos de Israel. [^3] Los nombres de los cuales son estos: De la tribu de Rubén, Sammua hijo de Zaccur. [^4] De la tribu de Simeón, Saphat hijo de Huri. [^5] De la tribu de Judá, Caleb hijo de Jephone. [^6] De la tribu de Issachâr, Igal hijo de Joseph. [^7] De la tribu de Ephraim, Oseas hijo de Nun. [^8] De la tribu de Benjamín, Palti hijo de Raphu. [^9] De la tribu de Zabulón, Gaddiel hijo de Sodi. [^10] De la tribu de José, de la tribu de Manasés, Gaddi hijo de Susi. [^11] De la tribu de Dan, Ammiel hijo de Gemalli. [^12] De la tribu de Aser, Sethur hijo de Michâel. [^13] De la tribu de Nephtalí, Nahabí hijo de Vapsi. [^14] De la tribu de Gad, Gehuel hijo de Machî. [^15] Estos son los nombres de los varones que Moisés envió á reconocer la tierra: y á Oseas hijo de Nun, le puso Moisés el nombre de Josué. [^16] Enviólos, pues, Moisés á reconocer la tierra de Canaán, diciéndoles: Subid por aquí, por el mediodía, y subid al monte: [^17] Y observad la tierra qué tal es; y el pueblo que la habita, si es fuerte ó débil, si poco ó numeroso; [^18] Qué tal la tierra habitada, si es buena ó mala; y qué tales son las ciudades habitadas, si de tiendas ó de fortalezas; [^19] Y cuál sea el terreno, si es pingüe ó flaco, si en él hay ó no árboles: y esforzaos, y coged del fruto del país. Y el tiempo era el tiempo de las primeras uvas. [^20] Y ellos subieron, y reconocieron la tierra desde el desierto de Zin hasta Rehob, entrando en Emath. [^21] Y subieron por el mediodía, y vinieron hasta Hebrón: y allí estaban Aimán, y Sesai, y Talmai, hijos de Anac. Hebrón fué edificada siete años antes de Zoán, la de Egipto. [^22] Y llegaron hasta el arroyo de Escol, y de allí cortaron un sarmiento con un racimo de uvas, el cual trejeron dos en un palo, y de las granadas y de los higos. [^23] Y llamóse aquel lugar Nahal-escol por el racimo que cortaron de allí los hijos de Israel. [^24] Y volvieron de reconocer la tierra al cabo de cuarenta días. [^25] Y anduvieron y vinieron á Moisés y á Aarón, y á toda la congregación de los hijos de Israel, en el desierto de Parán, en Cades, y diéronles la respuesta, y á toda la congregación, y les mostraron el fruto de la tierra. [^26] Y le contaron, y dijeron: Nosotros llegamos á la tierra á la cual nos enviaste, la que ciertamente fluye leche y miel; y este es el fruto de ella. [^27] Mas el pueblo que habita aquella tierra es fuerte, y las ciudades muy grandes y fuertes; y también vimos allí los hijos de Anac. [^28] Amalec habita la tierra del mediodía; y el Hetheo, y el Jebuseo, y el Amorrheo, habitan en el monte; y el Cananeo habita junto á la mar, y á la ribera del Jordán. [^29] Entonces Caleb hizo callar el pueblo delante de Moisés, y dijo: Subamos luego, y poseámosla; que más podremos que ella. [^30] Mas los varones que subieron con él, dijeron: No podremos subir contra aquel pueblo; porque es más fuerte que nosotros. [^31] y vituperaron entre los hijos de Israel la tierra que habían reconocido, diciendo: La tierra por donde pasamos para reconocerla, es tierra que traga á sus moradores; y todo el pueblo que vimos en medio de ella, son hombres de grande estatura. [^32] También vimos allí gigantes, hijos de Anac, raza de los gigantes: y éramos nosotros, á nuestro parecer, como langostas; y así les parecíamos á ellos. [^33] 

[[Numbers - 12|<--]] Numbers - 13 [[Numbers - 14|-->]]

---
# Notes
