---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/nehemiah"
  - "#bible/testament/old"
aliases:
  - "Nehemiah - 4 - Reina Valera (1602)"
---
[[Nehemiah - 3|<--]] Nehemiah - 4 [[Nehemiah - 5|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Nehemiah]]

# Nehemiah - 4

Y FUÉ que como oyó Sanballat que nosotros edificábamos el muro, encolerizóse y enojóse en gran manera, é hizo escarnio de los Judíos. [^1] Y habló delante de sus hermanos y del ejército de Samaria, y dijo: ¿Qué hacen estos débiles Judíos? ¿hanles de permitir? ¿han de sacrificar? ¿han de acabar en un día? ¿han de resucitar de los montones del polvo las piedras que fueron quemadas? [^2] Y estaba junto á él Tobías Ammonita, el cual dijo: Aun lo que ellos edifican, si subiere una zorra derribará su muro de piedra. [^3] Oye, oh Dios nuestro, que somos en menosprecio, y vuelve el baldón de ellos sobre su cabeza, y dalos en presa en la tierra de su cautiverio: [^4] Y no cubras su iniquidad, ni su pecado sea raído delante de tu rostro; porque se airaron contra los que edificaban. [^5] Edificamos pues el muro, y toda la muralla fué junta hasta su mitad: y el pueblo tuvo ánimo para obrar. [^6] Mas acaeció que oyendo Sanballat y Tobías, y los Arabes, y los Ammonitas, y los de Asdod, que los muros de Jerusalem eran reparados, porque ya los portillos comenzaban á cerrarse, encolerizáronse mucho; [^7] Y conspiraron todos á una para venir á combatir á Jerusalem, y á hacerle daño. [^8] Entonces oramos á nuestro Dios, y por causa de ellos pusimos guarda contra ellos de día y de noche. [^9] Y dijo Judá: Las fuerzas de los acarreadores se han enflaquecido, y el escombro es mucho, y no podemos edificar el muro. [^10] Y nuestros enemigos dijeron: No sepan, ni vean, hasta que entremos en medio de ellos, y los matemos, y hagamos cesar la obra. [^11] Sucedió empero, que como vinieron los Judíos que habitaban entre ellos, nos dieron aviso diez veces de todos los lugares de donde volvían á nosotros. [^12] Entonces puse por los bajos del lugar, detrás del muro, en las alturas de los peñascos, puse el pueblo por familias con sus espadas, con sus lanzas, y con sus arcos. [^13] Después miré, y levantéme, y dije á los principales y á los magistrados, y al resto del pueblo: No temáis delante de ellos: acordaos del Seños grande y terrible, y pelead por vuestros hermanos, por vuestros hijos y por vuestras hijas, por vuestras mujeres y por vuestras casas. [^14] Y sucedió que como oyeron nuestros enemigos que lo habíamos entendido, Dios disipó el consejo de ellos, y volvímonos todos al muro, cada uno á su obra. [^15] Mas fué que desde aquel día la mitad de los mancebos trabajaba en la obra, y la otra mitad de ellos tenía lanzas y escudos, y arcos, y corazas; y los príncipes estaban tras toda la casa de Judá. [^16] Los que edificaban en el muro, y los que llevaban cargas y los que cargaban, con la una mano trabajaban en la obra, y en la otra tenían la espada. [^17] Porque los que edificaban, cada uno tenía su espada ceñida á sus lomos, y así edificaban y el que tocaba la trompeta estaba junto á mí. [^18] Y dije á los principales, y á los magistrados y al resto del pueblo: La obra es grande y larga, y nosotros estamos apartados en el muro, lejos los unos de los otros. [^19] En el lugar donde oyereis la voz de la trompeta, reuníos allí á nosotros: nuestro Dios peleará por nosotros. [^20] Nosotros pues trabajábamos en la obra; y la mitad de ellos tenían lanzas desde la subida del alba hasta salir las estrellas. [^21] También dije entonces al pueblo: Cada uno con su criado se quede dentro de Jerusalem, y hágannos de noche centinela, y de día á la obra. [^22] Y ni yo, ni mis hermanos, ni mis mozos, ni la gente de guardia que me seguía, desnudamos nuestro vestido: cada uno se desnudaba solamente para lavarse. [^23] 

[[Nehemiah - 3|<--]] Nehemiah - 4 [[Nehemiah - 5|-->]]

---
# Notes
