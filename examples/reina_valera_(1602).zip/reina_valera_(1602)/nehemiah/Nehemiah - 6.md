---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/nehemiah"
  - "#bible/testament/old"
aliases:
  - "Nehemiah - 6 - Reina Valera (1602)"
---
[[Nehemiah - 5|<--]] Nehemiah - 6 [[Nehemiah - 7|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Nehemiah]]

# Nehemiah - 6

Y FUÉ que habiendo oído Sanballat, y Tobías, y Gesem el Arabe, y los demás nuestros enemigos, que había yo edificado el muro, y que no quedaba en él portillo, (aunque hasta aquel tiempo no había puesto en las puertas las hojas,) [^1] Sanballat y Gesem enviaron á decirme: Ven, y compongámonos juntos en alguna de las aldeas en el campo de Ono. Mas ellos habían pensado hacerme mal. [^2] Y enviéles mensajeros, diciendo: Yo hago una grande obra, y no puedo ir; porque cesaría la obra, dejándola yo para ir á vosotros. [^3] Y enviaron á mí con el mismo asunto por cuatro veces, y yo les respondí de la misma manera. [^4] Envió entonces Sanballat á mí su criado, á decir lo mismo por quinta vez, con una carta abierta en su mano, [^5] En la cual estaba escrito: Hase oído entre las gentes, y Gasmu lo dice, que tú y los Judíos pensáis rebelaros; y que por eso edificas tú el muro, con la mira, según estas palabras, de ser tú su rey; [^6] Y que has puesto profetas que prediquen de ti en Jerusalem, diciendo: ­Rey en Judá! Y ahora serán oídas del rey las tales palabras: ven por tanto, y consultemos juntos. [^7] Entonces envié yo á decirles: No hay tal cosa como dices, sino que de tu corazón tú lo inventas. [^8] Porque todos ellos nos ponían miedo, diciendo: Debilitaránse las manos de ellos en la obra, y no será hecha. Esfuerza pues mis manos, oh Dios. [^9] Vine luego en secreto á casa de Semaías hijo de Delaías, hijo de Mehetabeel, porque él estaba encerrado; el cual me dijo: Juntémonos en la casa de Dios dentro del templo, y cerremos las puertas del templo, porque vienen para matarte; sí, esta noche vendrán á matarte. [^10] Entonces dije: ¿Un hombre como yo ha de huir? ¿y quién, que como yo fuera, entraría al templo para salvar la vida? No entraré. [^11] Y entendí que Dios no lo había enviado, sino que hablaba aquella profecía contra mí, porque Tobías y Sanballat le habían alquilado por salario. [^12] Porque sobornado fué para hacerme temer así, y que pecase, y les sirviera de mal nombre con que fuera yo infamado. [^13] Acuérdate, Dios mío, de Tobías y de Sanballat, conforme á estas sus obras, y también de Noadías profetisa, y de los otros profetas que hacían por ponerme miedo. [^14] Acabóse pues el muro el veinticinco del mes de Elul, en cincuenta y dos días. [^15] Y como lo oyeron todos nuestros enemigos, temieron todas las gentes que estaban en nuestros alrededores, y abatiéronse mucho sus ojos, y conocieron que por nuestro Dios había sido hecha esta obra. [^16] Asimismo en aquellos días iban muchas cartas de los principales de Judá á Tobías, y las de Tobías venían á ellos. [^17] Porque muchos en Judá se habían conjurado con él, porque era yerno de Sechânías hijo de Ara; y Johanán su hijo había tomado la hija de Mesullam, hijo de Berechîas. [^18] También contaban delante de mí sus buenas obras, y referíanle mis palabras. Y enviaba Tobías cartas para atemorizarme. [^19] 

[[Nehemiah - 5|<--]] Nehemiah - 6 [[Nehemiah - 7|-->]]

---
# Notes
