---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/nehemiah"
  - "#bible/testament/old"
aliases:
  - "Nehemiah - 5 - Reina Valera (1602)"
---
[[Nehemiah - 4|<--]] Nehemiah - 5 [[Nehemiah - 6|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Nehemiah]]

# Nehemiah - 5

ENTONCES fué grande el clamor del pueblo y de sus mujeres contra los Judíos sus hermanos. [^1] Y había quien decía: Nosotros, nuestros hijos y nuestras hijas, somos muchos: hemos por tanto tomado grano para comer y vivir. [^2] Y había quienes decían: Hemos empeñado nuestras tierras, y nuestras viñas, y nuestras casas, para comprar grano en el hambre. [^3] Y había quienes decían: Hemos tomado prestado dinero para el tributo del rey, sobre nuestras tierras y viñas. [^4] Ahora bien, nuestra carne es como la carne de nuestros hermanos, nuestros hijos como sus hijos; y he aquí que nosotros sujetamos nuestros hijos y nuestras hijas á servidumbre, y hay algunas de nuestras hijas sujetas: mas no hay facultad en nuestras manos para rescatarlas, porque nuestras tierras y nuestras viñas son de otros. [^5] Y enojéme en gran manera cuando oí su clamor y estas palabras. [^6] Medité lo entonces para conmigo, y reprendí á los principales y á los magistrados, y díjeles: ¿Tomáiscada uno usura de vuestros hermanos? Y convoqué contra ellos una grande junta. [^7] Y díjeles: Nosotros rescatamos á nuestros hermanos Judíos que habían sido vendidos á las gentes, conforme á la facultad que había en nosotros: ¿y vosotros aun vendéis á vuestros hermanos, y serán vendidos á nosotros? Y callaron, que no tuvieron qué responder. [^8] Y dije: No es bien lo que hacéis, ¿no andaréis en temor de nuestro Dios, por no ser el oprobio de las gentes enemigas nuestras? [^9] También yo, y mis hermanos, y mis criados, les hemos prestado dinero y grano: relevémosles ahora de este gravamen. [^10] Ruégoos que les devolváis hoy sus tierras, sus viñas, sus olivares, y sus casas, y la centésima parte del dinero y grano, del vino y del aceite que demandáis de ellos. [^11] Y dijeron: Devolveremos, y nada les demandaremos; haremos así como tú dices. Entonces convoqué los sacerdotes, y juramentélos que harían conforme á esto. [^12] Además sacudí mi vestido, y dije: Así sacuda Dios de su casa y de su trabajo á todo hombre que no cumpliere esto, y así sea sacudido y vacío. Y respondió toda la congregación: ­Amén! Y alabaron á Jehová. Y el pueblo hizo conforme á esto. [^13] También desde el día que me mandó el rey que fuese gobernador de ellos en la tierra de Judá, desde el año veinte del rey Artajerjes hasta el año treinta y dos, doce años, ni yo ni mis hermanos comimos el pan del gobernador. [^14] Mas los primeros gobernadores que fueron antes de mí, cargaron al pueblo, y tomaron de ellos por el pan y por el vino sobre cuarenta siclos de plata: á más de esto, sus criados se enseñoreaban sobre el pueblo; pero yo no hice así, á causa del temor de Dios. [^15] También en la obra de este muro instauré mi parte, y no compramos heredad: y todos mis criados juntos estaban allí á la obra. [^16] Además ciento y cincuenta hombres de los Judíos y magistrados, y los que venían á nosotros de las gentes que están en nuestros contornos, estaban á mi mesa. [^17] Y lo que se aderezaba para cada día era un buey, seis ovejas escogidas, y aves también se aparejaban para mí, y cada diez días vino en toda abundancia: y con todo esto nunca requerí el pan del gobernador, porque la servidumbre de este pueblo era grave. [^18] Acuérdate de mí para bien, Dios mío, y de todo lo que hice á este pueblo. [^19] 

[[Nehemiah - 4|<--]] Nehemiah - 5 [[Nehemiah - 6|-->]]

---
# Notes
