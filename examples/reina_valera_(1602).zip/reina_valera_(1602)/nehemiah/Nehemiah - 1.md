---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/nehemiah"
  - "#bible/testament/old"
aliases:
  - "Nehemiah - 1 - Reina Valera (1602)"
---
Nehemiah - 1 [[Nehemiah - 2|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Nehemiah]]

# Nehemiah - 1

PALABRAS de Nehemías, hijo de Hachâlías. Y acaeció en el mes de Chisleu, en el año veinte, estando yo en Susán, capital del reino, [^1] Que vino Hanani, uno de mis hermanos, él y ciertos varones de Judá, y preguntéles por los Judíos que habían escapado, que habían quedado de la cautividad, y por Jerusalem. [^2] Y dijéronme: El residuo, los que quedaron de la cautividad allí en la provincia, están en gran mal y afrenta, y el muro de Jerusalem derribado, y sus puertas quemadas á fuego. [^3] Y fué que, como yo oí estas palabras, sentéme y lloré, y enlutéme por algunos días, y ayuné y oré delante del Dios de los cielos. [^4] Y dije: Ruégote, oh Jehová, Dios de los cielos, fuerte, grande, y terrible, que guarda el pacto y la misericordia á los que le aman y guardan sus mandamientos; [^5] Esté ahora atento tu oído, y tus ojos abiertos, para oír la oración de tu siervo, que yo hago ahora delante de ti día y noche, por los hijos de Israel tus siervos; y confieso los pecados de los hijos de Israel que hemos contra ti cometido; sí, yo y la casa de mi padre hemos pecado. [^6] En extremo nos hemos corrompido contra ti, y no hemos guardado los mandamientos, y estatutos y juicios, que mandaste á Moisés tu siervo. [^7] Acuérdate ahora de la palabra que ordenaste á Moisés tu siervo, diciendo: Vosotros prevaricaréis, y yo os esparciré por los pueblos: [^8] Mas os volveréis á mí, y guardaréis mis mandamientos, y los pondréis por obra. Si fuere vuestro lanzamiento hasta el cabo de los cielos, de allí os juntaré; y traerlos he al lugar que escogí para hacer habitar allí mi nombre. [^9] Ellos pues son tus siervos y tu pueblo, los cuales redimiste con tu gran fortaleza, y con tu mano fuerte. [^10] Ruégote, oh Jehová, esté ahora atento tu oído á la oración de tu siervo, y la oración de tus siervos, quienes desean temer tu nombre: y ahora concede hoy próspero suceso á tu siervo, y dale gracia delante de aquel varón. Porque yo servía de copero al rey. [^11] 

Nehemiah - 1 [[Nehemiah - 2|-->]]

---
# Notes
