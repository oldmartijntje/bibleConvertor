---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/nehemiah"
  - "#bible/testament/old"
aliases:
  - "Nehemiah - 8 - Reina Valera (1602)"
---
[[Nehemiah - 7|<--]] Nehemiah - 8 [[Nehemiah - 9|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Nehemiah]]

# Nehemiah - 8

Y JUNTOSE todo el pueblo como un solo hombre en la plaza que está delante de la puerta de las Aguas, y dijeron á Esdras el escriba, que trajese el libro de la ley de Moisés, la cual mandó Jehová á Israel. [^1] Y Esdras el sacerdote, trajo la ley delante de la congregación, así de hombres como de mujeres, y de todo entendido para escuchar, el primer día del mes séptimo. [^2] Y leyó en el libro delante de la plaza que está delante de la puerta de las Aguas, desde el alba hasta el medio día, en presencia de hombres y mujeres y entendidos; y los oídos de todo el pueblo estaban atentos al libro de la ley. [^3] Y Esdras el escriba estaba sobre un púlpito de madera, que habían hecho para ello; y junto á él estaban Mathithías, y Sema, y Anías, y Urías, é Hilcías, y Maasías, á su mano derecha; y á su mano izquierda, Pedaía, Misael, y Malchîas, y Hasum, y Hasbedana, Zachârías, y Mesullam. [^4] Abrió pues Esdras el libro á ojos de todo el pueblo, (porque estaba más alto que todo el pueblo); y como lo abrió, todo el pueblo estuvo atento. [^5] Bendijo entonces Esdras á Jehová, Dios grande. Y todo el pueblo respondió, ­Amén! ­Amén! alzando sus manos; y humilláronse, y adoraron á Jehová inclinados á tierra. [^6] Y Jesuá, y Bani, y Serebías, Jamín, Accub, Sabethai, Odías, Maasías, Celita, Azarías, Jozabed, Hanán, Pelaía, Levitas, hacían entender al pueblo la ley: y el pueblo estaba en su lugar. [^7] Y leían en el libro de la ley de Dios claramente, y ponían el sentido, de modo que entendiesen la lectura. [^8] Y Nehemías el Tirsatha, y el sacerdote Esdras, escriba, y los Levitas que hacían entender al pueblo, dijeron á todo el pueblo: Día santo es á Jehová nuestro Dios; no os entristezcáis, ni lloréis: porque todo el pueblo lloraba oyendo las palabras de la ley. [^9] Díjoles luego: Id, comed grosuras, y bebed vino dulce, y enviad porciones á los que no tienen prevenido; porque día santo es á nuestro Señor: y no os entristezcáis, porque el gozo de Jehová es vuestra fortaleza. [^10] Los Levitas pues, hacían callar á todo el pueblo, diciendo: Callad, que es día santo, y no os entristezcáis. [^11] Y todo el pueblo se fué á comer y á beber, y á enviar porciones, y á gozar de grande alegría, porque habían entendido las palabras que les habían enseñado. [^12] Y el día siguiente se juntaron los príncipes de las familias de todo el pueblo, sacerdotes, y Levitas, á Esdras escriba, para entender las palabras de la ley. [^13] Y hallaron escrito en la ley que Jehová había mandado por mano de Moisés, que habitasen los hijos de Israel en cabañas en la solemnidad del mes séptimo; [^14] Y que hiciesen saber, y pasar pregón por todas sus ciudades y por Jerusalem, diciendo: Salid al monte, y traed ramos de oliva, y ramos de pino, y ramos de arrayán, y ramos de palmas, y ramos de todo árbol espeso, para hacer cabañas como está escrito. [^15] Salió pues el pueblo, y trajeron, é hiciéronse cabañas, cada uno sobre su terrado, y en sus patios, y en los patios de la casa de Dios, y en la plaza de la puerta de las Aguas, y en la plaza de la puerta de Ephraim. [^16] Y toda la congregación que volvió de la cautividad hicieron cabañas, y en cabañas habitaron; porque desde los días de Josué hijo de Nun hasta aquel día, no habían hecho así los hijos de Israel. Y hubo alegría muy grande. [^17] Y leyó Esdras en el libro de la ley de Dios cada día, desde el primer día hasta el postrero; é hicieron la solemnidad por siete días, y al octavo día congregación, según el rito. [^18] 

[[Nehemiah - 7|<--]] Nehemiah - 8 [[Nehemiah - 9|-->]]

---
# Notes
