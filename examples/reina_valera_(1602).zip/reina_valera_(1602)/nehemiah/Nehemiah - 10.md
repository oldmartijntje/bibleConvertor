---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/nehemiah"
  - "#bible/testament/old"
aliases:
  - "Nehemiah - 10 - Reina Valera (1602)"
---
[[Nehemiah - 9|<--]] Nehemiah - 10 [[Nehemiah - 11|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Nehemiah]]

# Nehemiah - 10

y LOS que firmaron fueron, Nehemías el Tirsatha, hijo de Hachâlías, y Sedecías, [^1] Seraías, Azarías, Jeremías, [^2] Pashur, Amarías, Malchías, [^3] Hattus, Sebanías, Malluch, [^4] Harim, Meremoth, Obadías, [^5] Daniel, Ginethón, Baruch, [^6] Mesullam, Abías, Miamín, [^7] Maazías, Bilgai, Semeías: estos, sacerdotes. [^8] Y Levitas: Jesuá hijo de Azanías, Binnui de los hijos de Henadad, Cadmiel; [^9] Y sus hermanos Sebanías, Odaía, Celita, Pelaías, Hanán; [^10] Michâ, Rehob, Hasabías, [^11] Zachû, Serebías, Sebanías, [^12] Odaía, Bani, Beninu. [^13] Cabezas del pueblo: Pharos, Pahath-moab, Elam, Zattu, Bani, [^14] Bunni, Azgad, Bebai, [^15] Adonías, Bigvai, Adín, [^16] Ater, Ezekías, Azur, [^17] Odaía, Hasum, Besai, [^18] Ariph, Anathoth, Nebai, [^19] Magpías, Mesullam, Hezir, [^20] Mesezabeel, Sadoc, Jadua, [^21] Pelatías, Hanán, Anaías, [^22] Hoseas, Hananías, Asub, [^23] Lohes, Pilha, Sobec, [^24] Rehum, Hasabna, Maaseías, [^25] Y Ahijas, Hanán, Anan, [^26] Malluch, Harim, Baana. [^27] Y el resto del pueblo, los sacerdotes, Levitas, porteros, y cantores, Nethineos, y todos los que se habían apartado de los pueblos de las tierras á la ley de Dios, sus mujeres, sus hijos y sus hijas, y todo el que tenía comprensión y discernimiento, [^28] Adhiriéronse á sus hermanos, sus principales, y vinieron en la protestación y en el juramento de que andarían en la ley de Dios, que fué dada por mano de Moisés siervo de Dios, y que guardarían y cumplirían todos los mandamientos de Jehová nuestro Señor, y sus juicios y sus estatutos; [^29] Y que no daríamos nuestras hijas á los pueblos de la tierra, ni tomaríamos sus hijas para nuestros hijos. [^30] Asimismo, que si los pueblos de la tierra trajesen á vender mercaderías y comestibles en día de sábado, nada tomaríamos de ellos en sábado, ni en día santificado; y que dejaríamos el año séptimo, con remisión de toda deuda. [^31] Impusímonos además por ley el cargo de contribuir cada año con la tercera parte de un siclo, para la obra de la casa de nuestro Dios; [^32] Para el pan de la proposición, y para la ofrenda continua, y para el holocausto continuo, de los sábados, y de las nuevas lunas, y de las festividades, y para las santificaciones y sacrificios por el pecado para expiar á Israel, y para toda la obra de la casa de nuestro Dios. [^33] Echamos también las suertes, los sacerdotes, los Levitas, y el pueblo, acerca de la ofrenda de la leña, para traerla á la casa de nuestro Dios, según las casas de nuestros padres, en los tiempos determinados cada un año, para quemar sobre el altar de Jehová nuestro Dios, como está escrito en la ley. [^34] Y que cada año traeríamos las primicias de nuestra tierra, y las primicias de todo fruto de todo árbol, á la casa de Jehóva: [^35] Asimismo los primogénitos de nuestros hijos y de nuestras bestias, como está escrito en la ley; y que traeríamos los primogénitos de nuestras vacas y de nuestras ovejas á la casa de nuestro Dios, á los sacerdotes que ministran en la casa de nuestro Dios: [^36] Que traeríamos también las primicias de nuestras masas, y nuestras ofrendas, y del fruto de todo árbol, del vino y del aceite, á los sacerdotes, á las cámaras de la casa de nuestro Dios, y el diezmo de nuestra tierra á los Levitas; y que los Levitas recibirían las décimas de nuestras labores en todas las ciudades: [^37] Y que estaría el sacerdote hijo de Aarón con los Levitas, cuando los Levitas recibirían el diezmo: y que los Levitas llevarían el diezmo del diezmo á la casa de nuestro Dios, á las cámaras en la casa del tesoro. [^38] Porque á las cámaras han de llevar los hijos de Israel y los hijos de Leví la ofrenda del grano, del vino, y del aceite; y allí estarán los vasos del santuario, y los sacerdotes que ministran, y los porteros, y los cantores; y no abandonaremos la casa de nuestro Dios. [^39] 

[[Nehemiah - 9|<--]] Nehemiah - 10 [[Nehemiah - 11|-->]]

---
# Notes
