---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/nehemiah"
  - "#bible/testament/old"
aliases:
  - "Nehemiah - 2 - Reina Valera (1602)"
---
[[Nehemiah - 1|<--]] Nehemiah - 2 [[Nehemiah - 3|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Nehemiah]]

# Nehemiah - 2

Y FUÉ en el mes de Nisán, en el año veinte del rey Artajerjes, que estando ya el vino delante de él, tomé el vino, y dílo al rey. Y como yo no había estado antes triste en su presencia, [^1] Díjome el rey: ¿Por qué está triste tu rostro, pues no estás enfermo? No es esto sino quebranto de corazón. Entonces temí en gran manera. [^2] Y dije al rey: El rey viva para siempre. ¿Cómo no estará triste mi rostro, cuando la ciudad, casa de los sepulcros de mis padres, está desierta, y sus puertas consumidas del fuego? [^3] Y díjome el rey: ¿Qué cosa pides? Entonces oré al Dios de los cielos, [^4] Y dije al rey: Si al rey place, y si agrada tu siervo delante de ti, que me envíes á Judá, á la ciudad de los sepulcros de mis padres, y la reedificaré. [^5] Entonces el rey me dijo, (y la reina estaba sentada junto á él): ¿Hasta cuándo será tu viaje, y cuándo volverás? Y plugo al rey enviarme, después que yo le señalé tiempo. [^6] Además dije al rey: Si al rey place, dénseme cartas para los gobernadores de la otra parte del río, que me franqueen el paso hasta que llegue á Judá; [^7] Y carta para Asaph, guarda del bosque del rey, á fin que me dé madera para enmaderar los portales del palacio de la casa, y para el muro de la ciudad, y la casa donde entraré. Y otorgóme lo el rey, según la benéfica mano de Jehová sobre mí. [^8] Y vine luego á los gobernadores de la otra parte del río, y les dí las cartas del rey. Y el rey envió conmigo capitanes del ejército y gente de á caballo. [^9] Y oyéndolo Sanballat Horonita, y Tobías, el siervo Ammonita, disgustóles en extremo que viniese alguno para procurar el bien de los hijos de Israel. [^10] Llegué pues á Jerusalem, y estado que hube allí tres días, [^11] Levantéme de noche, yo y unos pocos varones conmigo, y no declaré á hombre alguno lo que Dios había puesto en mi corazón que hiciese en Jerusalem; ni había bestia conmigo, excepto la cabalgadura en que cabalgaba. [^12] Y salí de noche por la puerta del Valle hacia la fuente del Dragón y á la puerta del Muladar; y consideré los muros de Jerusalem que estaban derribados, y sus que puertas estaban consumidas del fuego. [^13] Pasé luego á la puerta de la Fuente, y al estanque del Rey; mas no había lugar por donde pasase la cabalgadura en que iba. [^14] Y subí por el torrente de noche, y consideré el muro, y regresando entré por la puerta del Valle, y volvíme. [^15] Y no sabían los magistrados dónde yo había ido, ni qué había hecho; ni hasta entonces lo había yo declarado á los Judíos y sacerdotes, ni á los nobles y magistrados, ni á los demás que hacían la obra. [^16] Díjeles pues: Vosotros veis el mal en que estamos, que Jerusalem está desierta, y sus puertas consumidas del fuego: venid, y edifiquemos el muro de Jerusalem, y no seamos más en oprobio. [^17] Entonces les declaré cómo la mano de mi Dios era buena sobre mí, y asimismo las palabras del rey, que me había dicho. Y dijeron: Levantémonos, y edifiquemos. Así esforzaron sus manos para bien. [^18] Mas habiéndolo oído Samballat Horonita, y Tobías el siervo Ammonita, y Gesem el Arabe, escarnecieron de nosotros, y nos despreciaron, diciendo: ¿Qué es esto que hacéis vosotros? ¿os rebeláis contra el rey? [^19] Y volvíles respuesta, y díjeles: El Dios de los cielos, él nos prosperará, y nosotros sus siervos nos levantaremos y edificaremos: que vosotros no tenéis parte, ni derecho, ni memoria en Jerusalem. [^20] 

[[Nehemiah - 1|<--]] Nehemiah - 2 [[Nehemiah - 3|-->]]

---
# Notes
