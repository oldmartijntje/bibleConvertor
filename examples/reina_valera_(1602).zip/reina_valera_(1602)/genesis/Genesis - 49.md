---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 49 - Reina Valera (1602)"
---
[[Genesis - 48|<--]] Genesis - 49 [[Genesis - 50|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 49

Y LLAMO Jacob á sus hijos, y dijo: Juntaos, y os declararé lo que os ha de acontecer en los postreros días. [^1] Juntaos y oid, hijos de Jacob; Y escuchad á vuestro padre Israel. [^2] Rubén, tú eres mi primogénito, mi fortaleza, y el principio de mi vigor; Principal en dignidad, principal en poder. [^3] Corriente como las aguas, no seas el principal; Por cuanto subiste al lecho de tu padre: Entonces te envileciste, subiendo á mi estrado. [^4] Simeón y Leví, hermanos: Armas de iniquidad sus armas. [^5] En su secreto no entre mi alma, Ni mi honra se junte en su compañía; Que en su furor mataron varón, Y en su voluntad arrancaron muro. [^6] Maldito su furor, que fué fiero; Y su ira, que fué dura: Yo los apartaré en Jacob, Y los esparciré en Israel. [^7] Judá, alabarte han tus hermanos: Tu mano en la cerviz de tus enemigos: Los hijos de tu padre se inclinarán á ti. [^8] Cachorro de león Judá: De la presa subiste, hijo mío: Encorvóse, echóse como león, Así como león viejo; ¿quién lo despertará? [^9] No será quitado el cetro de Judá, Y el legislador de entre sus piés, Hasta que venga Shiloh; Y á él se congregarán los pueblos. [^10] Atando á la vid su pollino, Y á la cepa el hijo de su asna, Lavó en el vino su vestido, Y en la sangre de uvas su manto: [^11] Sus ojos bermejos del vino, Y los dientes blancos de la leche. [^12] Zabulón en puertos de mar habitará, Y será para puerto de navíos; Y su término hasta Sidón. [^13] Issachâr, asno huesudo Echado entre dos tercios: [^14] Y vió que el descanso era bueno, Y que la tierra era deleitosa; Y bajó su hombro para llevar, Y sirvió en tributo. [^15] Dan juzgará á su pueblo, Como una de las tribus de Israel. [^16] Será Dan serpiente junto al camino, Cerasta junto á la senda, Que muerde los talones de los caballos, Y hace caer por detrás al cabalgador de ellos. [^17] Tu salud esperé, oh Jehová. [^18] Gad, ejército lo acometerá; Mas él acometerá al fin. [^19] El pan de Aser será grueso, Y él dará deleites al rey. [^20] Nephtalí, sierva dejada, Que dará dichos hermosos. [^21] Ramo fructífero José, Ramo fructífero junto á fuente, Cuyos vástagos se extienden sobre el muro. [^22] Y causáronle amargura, Y asaeteáronle, Y aborreciéronle los archeros: [^23] Mas su arco quedó en fortaleza, Y los brazos de sus manos se corroboraron Por las manos del Fuerte de Jacob, (De allí el pastor, y la piedra de Israel,) [^24] Del Dios de tu padre, el cual te ayudará, Y del Omnipotente, el cual te bendecirá Con bendiciones de los cielos de arriba, Con bendiciones del abismo que está abajo, Con bendiciones del seno y de la matriz. [^25] Las bendiciones de tu padre Fueron mayores que las bendiciones de mis progenitores: Hasta el término de los collados eternos Serán sobre la cabeza de José, Y sobre la mollera del Nazareo de sus hermanos. [^26] Benjamín, lobo arrebatador: A la mañana comerá la presa, Y á la tarde repartirá los despojos. [^27] Todos estos fueron las doce tribus de Israel: y esto fué lo que su padre les dijo, y bendíjolos; á cada uno por su bendición los bendijo. [^28] Mandóles luego, y díjoles: Yo voy á ser reunido con mi pueblo: sepultadme con mis padres en la cueva que está en el campo de Ephrón el Hetheo; [^29] En la cueva que está en el campo de Macpela, que está delante de Mamre en la tierra de Canaán, la cual compró Abraham con el mismo campo de Ephrón el Hetheo, para heredad de sepultura. [^30] Allí sepultaron á Abraham y á Sara su mujer; allí sepultaron á Isaac y á Rebeca su mujer; allí también sepulté yo á Lea. [^31] La compra del campo y de la cueva que está en él, fué de los hijos de Heth. [^32] Y como acabó Jacob de dar órdenes á sus hijos, encogió sus pies en la cama, y espiró: y fué reunido con sus padres. [^33] 

[[Genesis - 48|<--]] Genesis - 49 [[Genesis - 50|-->]]

---
# Notes
