---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 2 - Reina Valera (1602)"
---
[[Genesis - 1|<--]] Genesis - 2 [[Genesis - 3|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 2

Y FUERON acabados los cielos y la tierra, y todo su ornamento. [^1] Y acabó Dios en el día séptimo su obra que hizo, y reposó el día séptimo de toda su obra que había hecho. [^2] Y bendijo Dios al día séptimo, y santificólo, porque en él reposó de toda su obra que había Dios criado y hecho. [^3] Estos son los orígenes de los cielos y de la tierra cuando fueron criados, el día que Jehová Dios hizo la tierra y los cielos, [^4] Y toda planta del campo antes que fuese en la tierra, y toda hierba del campo antes que naciese: porque aun no había Jehová Dios hecho llover sobre la tierra, ni había hombre para que labrase la tierra; [^5] Mas subía de la tierra un vapor, que regaba toda la faz de la tierra. [^6] Formó, pues, Jehová Dios al hombre del polvo de la tierra, y alentó en su nariz soplo de vida; y fué el hombre en alma viviente. [^7] Y había Jehová Dios plantado un huerto en Edén al oriente, y puso allí al hombre que había formado. [^8] Y había Jehová Dios hecho nacer de la tierra todo árbol delicioso á la vista, y bueno para comer: también el árbol de vida en medio del huerto, y el árbol de ciencia del bien y del mal. [^9] Y salía de Edén un río para regar el huerto, y de allí se repartía en cuatro ramales. [^10] El nombre del uno era Pisón: éste es el que cerca toda la tierra de Havilah, donde hay oro: [^11] Y el oro de aquella tierra es bueno: hay allí también bdelio y piedra cornerina. [^12] El nombre del segundo río es Gihón: éste es el que rodea toda la tierra de Etiopía. [^13] Y el nombre del tercer río es Hiddekel: éste es el que va delante de Asiria. Y el cuarto río es el Eufrates. [^14] Tomó, pues, Jehová Dios al hombre, y le puso en el huerto de Edén, para que lo labrara y lo guardase. [^15] Y mandó Jehová Dios al hombre, diciendo: De todo árbol del huerto comerás; [^16] Mas del árbol de ciencia del bien y del mal no comerás de él; porque el día que de él comieres, morirás. [^17] Y dijo Jehová Dios: No es bueno que el hombre esté solo; haréle ayuda idónea para él. [^18] Formó, pues, Jehová Dios de la tierra toda bestia del campo, y toda ave de los cielos, y trájolas á Adam, para que viese cómo les había de llamar; y todo lo que Adam llamó á los animales vivientes, ese es su nombre. [^19] Y puso Adam nombres á toda bestia y ave de los cielos y á todo animal del campo: mas para Adam no halló ayuda que estuviese idónea para él. [^20] Y Jehová Dios hizo caer sueño sobre Adam, y se quedó dormido: entonces tomó una de sus costillas, y cerró la carne en su lugar; [^21] Y de la costilla que Jehová Dios tomó del hombre, hizo una mujer, y trájola al hombre. [^22] Y dijo Adam: Esto es ahora hueso de mis huesos, y carne de mi carne: ésta será llamada Varona, porque del varón fué tomada. [^23] Por tanto, dejará el hombre á su padre y á su madre, y allegarse ha á su mujer, y serán una sola carne. [^24] Y estaban ambos desnudos, Adam y su mujer, y no se avergonzaban. [^25] 

[[Genesis - 1|<--]] Genesis - 2 [[Genesis - 3|-->]]

---
# Notes
