---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 3 - Reina Valera (1602)"
---
[[Genesis - 2|<--]] Genesis - 3 [[Genesis - 4|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 3

EMPERO la serpiente era astuta, más que todos los animales del campo que Jehová Dios había hecho; la cual dijo á la mujer: ¿Conque Dios os ha dicho: No comáis de todo árbol del huerto? [^1] Y la mujer respondió á la serpiente: Del fruto de los árboles del huerto comemos; [^2] Mas del fruto del árbol que está en medio del huerto dijo Dios: No comeréis de él, ni le tocaréis, porque no muráis. [^3] Entonces la serpiente dijo á la mujer: No moriréis; [^4] Mas sabe Dios que el día que comiereis de él, serán abiertos vuestros ojos, y seréis como dioses sabiendo el bien y el mal. [^5] Y vió la mujer que el árbol era bueno para comer, y que era agradable á los ojos, y árbol codiciable para alcanzar la sabiduría; y tomó de su fruto, y comió; y dió también á su marido, el cual comió así como ella. [^6] Y fueron abiertos los ojos de entrambos, y conocieron que estaban desnudos: entonces cosieron hojas de higuera, y se hicieron delantales. [^7] Y oyeron la voz de Jehová Dios que se paseaba en el huerto al aire del día: y escondióse el hombre y su mujer de la presencia de Jehová Dios entre los árboles del huerto. [^8] Y llamó Jehová Dios al hombre, y le dijo: ¿Dónde estás tú? [^9] Y él respondió: Oí tu voz en el huerto, y tuve miedo, porque estaba desnudo; y escondíme. [^10] Y díjole: ¿Quién te enseñó que estabas desnudo? ¿Has comido del árbol de que yo te mandé no comieses? [^11] Y el hombre respondió: La mujer que me diste por compañera me dió del árbol, y yo comí. [^12] Entonces Jehová Dios dijo á la mujer: ¿Qué es lo que has hecho? Y dijo la mujer: La serpiente me engañó, y comí. [^13] Y Jehová Dios dijo á la serpiente: Por cuanto esto hiciste, maldita serás entre todas las bestias y entre todos los animales del campo; sobre tu pecho andarás, y polvo comerás todos los días de tu vida: [^14] Y enemistad pondré entre ti y la mujer, y entre tu simiente y la simiente suya; ésta te herirá en la cabeza, y tú le herirás en el calcañar. [^15] A la mujer dijo: Multiplicaré en gran manera tus dolores y tus preñeces; con dolor parirás los hijos; y á tu marido será tu deseo, y él se enseñoreará de ti. [^16] Y al hombre dijo: Por cuanto obedeciste á la voz de tu mujer, y comiste del árbol de que te mandé diciendo, No comerás de él; maldita será la tierra por amor de ti; con dolor comerás de ella todos los días de tu vida; [^17] Espinos y cardos te producirá, y comerás hierba del campo; [^18] En el sudor de tu rostro comerás el pan hasta que vuelvas á la tierra; porque de ella fuiste tomado: pues polvo eres, y al polvo serás tornado. [^19] Y llamó el hombre el nombre de su mujer, Eva; por cuanto ella era madre de todos lo vivientes. [^20] Y Jehová Dios hizo al hombre y á su mujer túnicas de pieles, y vistiólos. [^21] Y dijo Jehová Dios: He aquí el hombre es como uno de Nos sabiendo el bien y el mal: ahora, pues, porque no alargue su mano, y tome también del árbol de la vida, y coma, y viva para siempre: [^22] Y sacólo Jehová del huerto de Edén, para que labrase la tierra de que fué tomado. [^23] Echó, pues, fuera al hombre, y puso al oriente del huerto de Edén querubines, y una espada encendida que se revolvía á todos lados, para guardar el camino del árbol de la vida. [^24] 

[[Genesis - 2|<--]] Genesis - 3 [[Genesis - 4|-->]]

---
# Notes
