---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 20 - Reina Valera (1602)"
---
[[Genesis - 19|<--]] Genesis - 20 [[Genesis - 21|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 20

DE allí partió Abraham á la tierra del Mediodía, y asentó entre Cades y Shur, y habitó como forastero en Gerar. [^1] Y dijo Abraham de Sara su mujer: Mi hermana es. Y Abimelech, rey de Gerar, envió y tomó á Sara. [^2] Empero Dios vino á Abimelech en sueños de noche, y le dijo: He aquí muerto eres á causa de la mujer que has tomado, la cual es casada con marido. [^3] Mas Abimelech no había llegado á ella, y dijo: Señor, ¿matarás también la gente justa? [^4] ¿No me dijo él: Mi hermana es; y ella también dijo: Es mi hermano? Con sencillez de mi corazón, y con limpieza de mis manos he hecho esto. [^5] Y díjole Dios en sueños: Yo también sé que con integridad de tu corazón has hecho esto; y yo también te detuve de pecar contra mí, y así no te permití que la tocases. [^6] Ahora, pues, vuelve la mujer á su marido; porque es profeta, y orará por ti, y vivirás. Y si tú no la volvieres, sabe que de cierto morirás, con todo lo que fuere tuyo. [^7] Entonces Abimelech se levantó de mañana, y llamó á todos sus siervos, y dijo todas estas palabras en los oídos de ellos; y temieron los hombres en gran manera. [^8] Después llamó Abimelech á Abraham y le dijo: ¿Qué nos has hecho? ¿y en qué pequé yo contra ti, que has atraído sobre mí y sobre mi reino tan gran pecado? lo que no debiste hacer has hecho conmigo. [^9] Y dijo más Abimelech á Abraham: ¿Qué viste para que hicieses esto? [^10] Y Abraham respondió: Porque dije para mí: Cierto no hay temor de Dios en este Lugar, y me matarán por causa de mi mujer. [^11] Y á la verdad también es mi hermana, hija de mi padre, mas no hija de mi madre, y toméla por mujer. [^12] Y fue que, cuando Dios me hizo salir errante de la casa de mi padre, yo le dije: Esta es la merced que tú me harás, que en todos los lugares donde llegáremos, digas de mí: Mi hermano es. [^13] Entonces Abimelech tomó ovejas y vacas, y siervos y siervas, y diólo á Abraham, y devolvióle á Sara su mujer. [^14] Y dijo Abimelech: He aquí mi tierra está delante de ti, habita donde bien te pareciere. [^15] Y á Sara dijo: He aquí he dado mil monedas de plata á tu hermano; mira que él te es por velo de ojos para todos los que están contigo, y para con todos: así fué reprendida. [^16] Entonces Abraham oró á Dios; y Dios sanó á Abimelech y á su mujer, y á sus siervas, y parieron. [^17] Porque había del todo cerrado Jehová toda matriz de la casa de Abimelech, á causa de Sara mujer de Abraham. [^18] 

[[Genesis - 19|<--]] Genesis - 20 [[Genesis - 21|-->]]

---
# Notes
