---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 15 - Reina Valera (1602)"
---
[[Genesis - 14|<--]] Genesis - 15 [[Genesis - 16|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 15

DESPUÉS de estas cosas fué la palabra de Jehová á Abram en visión, diciendo: No temas, Abram; yo soy tu escudo, y tu galardón sobremanera grande. [^1] Y respondió Abram: Señor Jehová ¿qué me has de dar, siendo así que ando sin hijo, y el mayordomo de mi casa es ese Damasceno Eliezer? [^2] Dijo más Abram: Mira que no me has dado prole, y he aquí que es mi heredero uno nacido en mi casa. [^3] Y luego la palabra de Jehová fué á él diciendo: No te heredará éste, sino el que saldrá de tus entrañas será el que te herede. [^4] Y sacóle fuera, y dijo: Mira ahora á los cielos, y cuenta las estrellas, si las puedes contar. Y le dijo: Así será tu simiente. [^5] Y creyó á Jehová, y contóselo por justicia. [^6] Y díjole: Yo soy Jehová, que te saqué de Ur de los Caldeos, para darte á heredar esta tierra. [^7] Y él respondió: Señor Jehová ¿en qué conoceré que la tengo de heredar? [^8] Y le dijo: Apártame una becerra de tres años, y una cabra de tres años, y un carnero de tres años, una tórtola también, y un palomino. [^9] Y tomó él todas estas cosas, y partiólas por la mitad, y puso cada mitad una enfrente de otra; mas no partió las aves. [^10] Y descendían aves sobre los cuerpos muertos, y ojeábalas Abram. [^11] Mas á la caída del sol sobrecogió el sueño á Abram, y he aquí que el pavor de una grande obscuridad cayó sobre él. [^12] Entonces dijo á Abram: Ten por cierto que tu simiente será peregrina en tierra no suya, y servirá á los de allí, y serán por ellos afligidos cuatrocientos años. [^13] Mas también á la gente á quien servirán, juzgaré yo; y después de esto saldrán con grande riqueza. [^14] Y tú vendrás á tus padres en paz, y serás sepultado en buena vejez. [^15] Y en la cuarta generación volverán acá: porque aun no está cumplida la maldad del Amorrheo hasta aquí. [^16] Y sucedió que puesto el sol, y ya obscurecido, dejóse ver un horno humeando, y una antorcha de fuego que pasó por entre los animales divididos. [^17] En aquel día hizo Jehová un pacto con Abram diciendo: A tu simiente daré esta tierra desde el río de Egipto hasta el río grande, el río Eufrates; [^18] Los Cineos, y los Ceneceos, y los Cedmoneos, [^19] Y los Hetheos, y los Pherezeos, y los Raphaitas, [^20] Y los Amorrheos, y los Cananeos, y los Gergeseos, y los Jebuseos. [^21] 

[[Genesis - 14|<--]] Genesis - 15 [[Genesis - 16|-->]]

---
# Notes
