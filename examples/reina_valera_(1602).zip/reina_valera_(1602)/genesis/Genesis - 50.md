---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 50 - Reina Valera (1602)"
---
[[Genesis - 49|<--]] Genesis - 50

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 50

ENTONCES se echó José sobre el rostro de su padre, y lloró sobre él, y besólo. [^1] Y mandó José á sus médicos familiares que embalsamasen á su padre: y los médicos embalsamaron á Israel. [^2] Y cumpliéronle cuarenta días, porque así cumplían los días de los embalsamados, y lloráronlo los Egipcios setenta días. [^3] Y pasados los días de su luto, habló José á los de la casa de Faraón, diciendo: Si he hallado ahora gracia en vuestros ojos, os ruego que habléis en oídos de Faraón, diciendo: [^4] Mi padre me conjuró diciendo: He aquí yo muero; en mi sepulcro que yo cavé para mí en la tierra de Canaán, allí me sepultarás; ruego pues que vaya yo ahora, y sepultaré á mi padre, y volveré. [^5] Y Faraón dijo: Ve, y sepulta á tu padre, como él te conjuró. [^6] Entonces José subió á sepultar á su padre; y subieron con él todos los siervos de Faraón, los ancianos de su casa, y todos los ancianos de la tierra de Egipto. [^7] Y toda la casa de José, y sus hermanos, y la casa de su padre: solamente dejaron en la tierra de Gosén sus niños, y sus ovejas y sus vacas. [^8] Y subieron también con él carros y gente de á caballo, é hízose un escuadrón muy grande. [^9] Y llegaron hasta la era de Atad, que está á la otra parte del Jordán, y endecharon allí con grande y muy grave lamentación: y José hizo á su padre duelo por siete días. [^10] Y viendo los moradores de la tierra, los Cananeos, el llanto en la era de Atad, dijeron: Llanto grande es este de los Egipcios: por eso fué llamado su nombre Abelmizraim, que está á la otra parte del Jordán. [^11] Hicieron, pues, sus hijos con él, según les había mandado: [^12] Pues lleváronlo sus hijos á la tierra de Canaán, y le sepultaron en la cueva del campo de Macpela, la que había comprado Abraham con el mismo campo, para heredad de sepultura, de Ephrón el Hetheo, delante de Mamre. [^13] Y tornóse José á Egipto, él y sus hermanos, y todos los que subieron con él á sepultar á su padre, después que le hubo sepultado. [^14] Y viendo los hermanos de José que su padre era muerto, dijeron: Quizá nos aborrecerá José, y nos dará el pago de todo el mal que le hicimos. [^15] Y enviaron á decir á José: Tu padre mandó antes de su muerte, diciendo: [^16] Así diréis á José: Ruégote que perdones ahora la maldad de tus hermanos y su pecado, porque mal te trataron: por tanto ahora te rogamos que perdones la maldad de los siervos del Dios de tu padre. Y José lloró mientras hablaban. [^17] Y vinieron también sus hermanos, y postráronse delante de él, y dijeron: Henos aquí por tus siervos. [^18] Y respondióles José: No temáis: ¿estoy yo en lugar de Dios? [^19] Vosotros pensasteis mal sobre mí, mas Dios lo encaminó á bien, para hacer lo que vemos hoy, para mantener en vida á mucho pueblo. [^20] Ahora, pues, no tengáis miedo; yo os sustentaré á vosotros y á vuestros hijos. Así los consoló, y les habló al corazón. [^21] Y estuvo José en Egipto, él y la casa de su padre: y vivió José ciento diez años. [^22] Y vió José los hijos de Ephraim hasta la tercera generación: también los hijos de Machîr, hijo de Manasés, fueron criados sobre las rodillas de José. [^23] Y José dijo á sus hermanos: Yo me muero; mas Dios ciertamente os visitará, y os hará subir de aquesta tierra á la tierra que juró á Abraham, á Isaac, y á Jacob. [^24] Y conjuró José á los hijos de Israel, diciendo: Dios ciertamente os visitará, y haréis llevar de aquí mis huesos. [^25] Y murió José de edad de ciento diez años; y embalsamáronlo, y fué puesto en un ataúd en Egipto. [^26] 

[[Genesis - 49|<--]] Genesis - 50

---
# Notes
