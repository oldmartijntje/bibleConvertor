---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 38 - Reina Valera (1602)"
---
[[Genesis - 37|<--]] Genesis - 38 [[Genesis - 39|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 38

Y ACONTECIO en aquel tiempo, que Judá descendió de con sus hermanos, y fuése á un varón Adullamita, que se llamaba Hira. [^1] Y vió allí Judá la hija de un hombre Cananeo, el cual se llamaba Súa; y tomóla, y entró á ella: [^2] La cual concibió, y parió un hijo; y llamó su nombre Er. [^3] Y concibió otra vez, y parió un hijo, y llamó su nombre Onán. [^4] Y volvió á concebir, y parió un hijo, y llamó su nombre Sela. Y estaba en Chezib cuando lo parió. [^5] Y Judá tomó mujer para su primogénito Er, la cual se llamaba Thamar. [^6] Y Er, el primogénito de Judá, fué malo á los ojos de Jehová, y quitóle Jehová la vida. [^7] Entonces Judá dijo á Onán: Entra á la mujer de tu hermano, y despósate con ella, y suscita simiente á tu hermano. [^8] Y sabiendo Onán que la simiente no había de ser suya, sucedía que cuando entraba á la mujer de su hermano vertía en tierra, por no dar simiente á su hermano. [^9] Y desagradó en ojos de Jehová lo que hacía, y también quitó á él la vida. [^10] Y Judá dijo á Thamar su nuera: Estáte viuda en casa de tu padre, hasta que crezca Sela mi hijo; porque dijo: Que quizá no muera él también como sus hermanos. Y fuése Thamar, y estúvose en casa de su padre. [^11] Y pasaron muchos días, y murió la hija de Súa, mujer de Judá; y Judá se consoló, y subía á los trasquiladores de sus ovejas á Timnath, él y su amigo Hira el Adullamita. [^12] Y fué dado aviso á Thamar, diciendo: He aquí tu suegro sube á Timnath á trasquilar sus ovejas. [^13] Entonces quitó ella de sobre sí los vestidos de su viudez, y cubrióse con un velo, y arrebozóse, y se puso á la puerta de las aguas que están junto al camino de Timnath; porque veía que había crecido Sela, y ella no era dada á él por mujer. [^14] Y vióla Judá, y túvola por ramera, porque había ella cubierto su rostro. [^15] Y apartóse del camino hacia ella, y díjole: Ea, pues, ahora entraré á ti; porque no sabía que era su nuera; y ella dijo: ¿Qué me has de dar, si entrares á mí? [^16] El respondió: Yo te enviaré del ganado un cabrito de las cabras. Y ella dijo: Hasme de dar prenda hasta que lo envíes. [^17] Entonces él dijo: ¿Qué prenda te daré? Ella respondió: Tu anillo, y tu manto, y tu bordón que tienes en tu mano. Y él se los dió, y entró á ella, la cual concibió de él. [^18] Y levantóse, y fuése: y quitóse el velo de sobre sí, y vistióse las ropas de su viudez. [^19] Y Judá envió el cabrito de las cabras por mano de su amigo el Adullamita, para que tomase la prenda de mano de la mujer; mas no la halló. [^20] Y preguntó á los hombres de aquel lugar, diciendo: ¿Dónde está la ramera de las aguas junto al camino? Y ellos le dijeron: No ha estado aquí ramera. [^21] Entonces él se volvió á Judá, y dijo: No la he hallado; y también los hombres del lugar dijeron: Aquí no ha estado ramera. [^22] Y Judá dijo: Tómeselo para sí, porque no seamos menospreciados: he aquí yo he enviado este cabrito, y tú no la hallaste. [^23] Y acaeció que al cabo de unos tres meses fué dado aviso á Judá, diciendo: Thamar tu nuera ha fornicado, y aun cierto está preñada de las fornicaciones. Y Judá dijo: Sacadla, y sea quemada. [^24] Y ella cuando la sacaban, envió á decir á su suegro: Del varón cuyas son estas cosas, estoy preñada: y dijo más: Mira ahora cuyas son estas cosas, el anillo, y el manto, y el bordón. [^25] Entonces Judá los reconoció, y dijo: Más justa es que yo, por cuanto no la he dado á Sela mi hijo. Y nunca más la conoció. [^26] Y aconteció que al tiempo del parir, he aquí había dos en su vientre. [^27] Y sucedió, cuando paría, que sacó la mano el uno, y la partera tomó y ató á su mano un hilo de grana, diciendo: Este salió primero. [^28] Empero fué que tornando él á meter la mano, he aquí su hermano salió; y ella dijo: ¿Por qué has hecho sobre ti rotura? Y llamó su nombre Phares. [^29] Y después salió su hermano, el que tenía en su mano el hilo de grana, y llamó su nombre Zara. [^30] 

[[Genesis - 37|<--]] Genesis - 38 [[Genesis - 39|-->]]

---
# Notes
