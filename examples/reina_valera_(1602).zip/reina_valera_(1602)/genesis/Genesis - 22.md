---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 22 - Reina Valera (1602)"
---
[[Genesis - 21|<--]] Genesis - 22 [[Genesis - 23|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 22

Y ACONTECIO después de estas cosas, que tentó Dios á Abraham, y le dijo: Abraham. Y él respondió: Heme aquí. [^1] Y dijo: Toma ahora tu hijo, tu único, Isaac, á quien amas, y vete á tierra de Moriah, y ofrécelo allí en holocausto sobre uno de los montes que yo te diré. [^2] Y Abraham se levantó muy de mañana, y enalbardó su asno, y tomó consigo dos mozos suyos, y á Isaac su hijo: y cortó leña para el holocausto, y levantóse, y fué al lugar que Dios le dijo. [^3] Al tercer día alzó Abraham sus ojos, y vió el lugar de lejos. [^4] Entonces dijo Abraham á sus mozos: Esperaos aquí con el asno, y yo y el muchacho iremos hasta allí, y adoraremos, y volveremos á vosotros. [^5] Y tomó Abraham la leña del holocausto, y púsola sobre Isaac su hijo: y él tomó en su mano el fuego y el cuchillo; y fueron ambos juntos. [^6] Entonces habló Isaac á Abraham su padre, y dijo: Padre mío. Y él respondió: Heme aquí, mi hijo. Y él dijo: He aquí el fuego y la leña; mas ¿dónde está el cordero para el holocausto? [^7] Y respondió Abraham: Dios se proveerá de cordero para el holocausto, hijo mío. E iban juntos. [^8] Y como llegaron al lugar que Dios le había dicho, edificó allí Abraham un altar, y compuso la leña, y ató á Isaac su hijo, y púsole en el altar sobre la leña. [^9] Y extendió Abraham su mano, y tomó el cuchillo, para degollar á su hijo. [^10] Entonces el ángel de Jehová le dió voces del cielo, y dijo: Abraham, Abraham. Y él respondió: Heme aquí. [^11] Y dijo: No extiendas tu mano sobre el muchacho, ni le hagas nada; que ya conozco que temes á Dios, pues que no me rehusaste tu hijo, tu único; [^12] Entonces alzó Abraham sus ojos, y miró, y he aquí un carnero á sus espaldas trabado en un zarzal por sus cuernos: y fué Abraham, y tomó el carnero, y ofrecióle en holocausto en lugar de su hijo. [^13] Y llamó Abraham el nombre de aquel lugar, Jehová proveerá. Por tanto se dice hoy: En el monte de Jehová será provisto. [^14] Y llamó el ángel de Jehová á Abraham segunda vez desde el cielo, [^15] Y dijo: Por mí mismo he jurado, dice Jehová, que por cuanto has hecho esto, y no me has rehusado tu hijo, tu único; [^16] Bendiciendo te bendeciré, y multiplicando multiplicaré tu simiente como las estrellas del cielo, y como la arena que está á la orilla del mar; y tu simiente poseerá las puertas de sus enemigos: [^17] En tu simiente serán benditas todas las gentes de la tierra, por cuanto obedeciste á mi voz. [^18] Y tornóse Abraham á sus mozos, y levantáronse y se fueron juntos á Beer-seba; y habitó Abraham en Beer-seba. [^19] Y aconteció después de estas cosas, que fué dada nueva á Abraham, diciendo: He aquí que también Milca ha parido hijos á Nachôr tu hermano: [^20] A Huz su primogénito, y á Buz su hermano, y á Kemuel padre de Aram. [^21] Y á Chêsed, y á Hazo, y á Pildas, y á Jidlaph, y á Bethuel. [^22] Y Bethuel engendró á Rebeca. Estos ocho parió Milca á Nachôr, hermano de Abraham. [^23] Y su concubina, que se llamaba Reúma, parió también á Teba, y á Gaham, y á Taas, y á Maachâ. [^24] 

[[Genesis - 21|<--]] Genesis - 22 [[Genesis - 23|-->]]

---
# Notes
