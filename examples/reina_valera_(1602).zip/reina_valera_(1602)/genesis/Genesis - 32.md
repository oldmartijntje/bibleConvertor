---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 32 - Reina Valera (1602)"
---
[[Genesis - 31|<--]] Genesis - 32 [[Genesis - 33|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 32

Y JACOB se fué su camino, y saliéronle al encuentro ángeles de Dios. [^1] Y dijo Jacob cuando los vió: El campo de Dios es este: y llamó el nombre de aquel lugar Mahanaim. [^2] Y envió Jacob mensajeros delante de sí á Esaú su hermano, á la tierra de Seir, campo de Edom. [^3] Y mandóles diciendo: Así diréis á mí señor Esaú: Así dice tu siervo Jacob: Con Labán he morado, y detenídome hasta ahora; [^4] Y tengo vacas, y asnos, y ovejas, y siervos y siervas; y envío á decirlo á mi señor, por hallar gracia en tus ojos. [^5] Y los mensajeros volvieron á Jacob, diciendo: Vinimos á tu hermano Esaú, y él también vino á recibirte, y cuatrocientos hombres con él. [^6] Entonces Jacob tuvo gran temor, y angustióse; y partió el pueblo que tenía consigo, y las ovejas y las vacas y los camellos, en dos cuadrillas; [^7] Y dijo: Si viniere Esaú á la una cuadrilla y la hiriere, la otra cuadrilla escapará. [^8] Y dijo Jacob: Dios de mi padre Abraham, y Dios de mi padre Isaac, Jehová, que me dijiste: Vuélvete á tu tierra y á tu parentela, y yo te haré bien. [^9] Menor soy que todas las misericordias, y que toda la verdad que has usado para con tu siervo; que con mi bordón pasé este Jordán, y ahora estoy sobre dos cuadrillas. [^10] Líbrame ahora de la mano de mi hermano, de la mano de Esaú, porque le temo; no venga quizá, y me hiera la madre con los hijos. [^11] Y tú has dicho: Yo te haré bien, y pondré tu simiente como la arena del mar, que no se puede contar por la multitud. [^12] Y durmió allí aquella noche, y tomó de lo que le vino á la mano un presente para su hermano Esaú. [^13] Doscientas cabras y veinte machos de cabrío, doscientas ovejas y veinte carneros, [^14] Treinta camellas paridas, con sus hijos, cuarenta vacas y diez novillos, veinte asnas y diez borricos. [^15] Y entrególo en mano de sus siervos, cada manada de por sí; y dijo á sus siervos: Pasad delante de mí, y poned espacio entre manada y manada. [^16] Y mandó al primero, diciendo: Si Esaú mi hermano te encontrare, y te preguntare, diciendo ¿De quién eres? ¿y adónde vas? ¿y para quién es esto que llevas delante de ti? [^17] Entonces dirás: Presente es de tu siervo Jacob, que envía á mi señor Esaú; y he aquí también él viene tras nosotros. [^18] Y mandó también al segundo, y al tercero, y á todos los que iban tras aquellas manadas, diciendo: Conforme á esto hablaréis á Esaú, cuando le hallareis. [^19] Y diréis también: He aquí tu siervo Jacob viene tras nosotros. Porque dijo: Apaciguaré su ira con el presente que va delante de mí, y después veré su rostro: quizá le seré acepto. [^20] Y pasó el presente delante de él; y él durmió aquella noche en el campamento. [^21] Y levantóse aquella noche, y tomó sus dos mujeres, y sus dos siervas, y sus once hijos, y pasó el vado de Jaboc. [^22] Tomólos pues, y pasólos el arroyo, é hizo pasar lo que tenía. [^23] Y quedóse Jacob solo, y luchó con él un varón hasta que rayaba el alba. [^24] Y como vió que no podía con él, tocó en el sitio del encaje de su muslo, y descoyuntóse el muslo de Jacob mientras con él luchaba. [^25] Y dijo: Déjame, que raya el alba. Y él dijo: No te dejaré, si no me bendices. [^26] Y él le dijo: ¿Cuál es tu nombre? Y él respondió: Jacob. [^27] Y él dijo: No se dirá más tu nombre Jacob, sino Israel: porque has peleado con Dios y con los hombres, y has vencido. [^28] Entonces Jacob le preguntó, y dijo: Declárame ahora tu nombre. Y él respondió: ¿Por qué preguntas por mi nombre? Y bendíjolo allí. [^29] Y llamó Jacob el nombre de aquel lugar Peniel: porque vi á Dios cara á cara, y fué librada mi alma. [^30] Y salióle el sol pasado que hubo á Peniel; y cojeaba de su anca. [^31] Por esto no comen los hijos de Israel, hasta hoy día, del tendón que se contrajo, el cual está en el encaje del muslo: porque tocó á Jacob este sitio de su muslo en el tendón que se contrajo. [^32] 

[[Genesis - 31|<--]] Genesis - 32 [[Genesis - 33|-->]]

---
# Notes
