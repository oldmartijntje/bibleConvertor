---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 14 - Reina Valera (1602)"
---
[[Genesis - 13|<--]] Genesis - 14 [[Genesis - 15|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 14

Y ACONTECIO en los días de Amraphel, rey de Shinar, Arioch, rey de Elazar, Chêdorlaomer, rey de Elá, y Tidal, rey de naciones, [^1] Que éstos hicieron guerra contra Bera, rey de Sodoma, y contra Birsha, rey de Gomorra, y contra Shinab, rey de Adma, y contra Shemeber, rey de Zeboim, y contra el rey de Bela, la cual es Zoar. [^2] Todos estos se juntaron en el valle de Siddim, que es el mar salado. [^3] Doce años habían servido á Chêdorlaomer, y al décimotercio año se rebelaron. [^4] Y en el año décimocuarto vino Chêdorlaomer, y los reyes que estaban de su parte, y derrotaron á los Raphaitas en Ashteroth-carnaim, á los Zuzitas en Ham, y á los Emitas en Shave-Kiriataim. [^5] Y á los Horeos en el monte de Seir, hasta la llanura de Parán, que está junto al desierto. [^6] Y volvieron y vinieron á Emmisphat, que es Cades, y devastaron todas las haciendas de los Amalacitas, y también al Amorrheo, que habitaba en Hazezón-tamar. [^7] Y salió el rey de Sodoma, y el rey de Gomorra, y el rey de Adma, y el rey de Zeboim, y el rey de Bela, que es Zoar, y ordenaron contra ellos batalla en el valle de Siddim; [^8] Es á saber, contra Chêdorlaomer, rey de Elam, y Tidal, rey de naciones, y Amraphel, rey de Shinar, y Arioch, rey de Elasar; cuatro reyes contra cinco. [^9] Y el valle de Siddim estaba lleno de pozos de betún: y huyeron el rey de Sodoma y el de Gomorra, y cayeron allí; y los demás huyeron al monte. [^10] Y tomaron toda la riqueza de Sodoma y de Gomorra, y todas sus vituallas, y se fueron. [^11] Tomaron también á Lot, hijo del hermano de Abram, que moraba en Sodoma, y su hacienda, y se fueron. [^12] Y vino uno de los que escaparon, y denunciólo á Abram el Hebreo, que habitaba en el valle de Mamre Amorrheo, hermano de Eschôl y hermano de Aner, los cuales estaban confederados con Abram. [^13] Y oyó Abram que su hermano estaba prisionero, y armó sus criados, los criados de su casa, trescientos dieciocho, y siguiólos hasta Dan. [^14] Y derramóse sobre ellos de noche él y sus siervos, é hiriólos, y fuélos siguiendo hasta Hobah, que está á la izquierda de Damasco. [^15] Y recobró todos los bienes, y también á Lot su hermano y su hacienda, y también las mujeres y gente. [^16] Y salió el rey de Sodoma á recibirlo, cuando volvía de la derrota de Chêdorlaomer y de los reyes que con él estaban, al valle de Shave, que es el valle del Rey. [^17] Entonces Melchîsedec, rey de Salem, sacó pan y vino; el cual era sacerdote del Dios alto; [^18] Y bendíjole, y dijo: Bendito sea Abram del Dios alto, poseedor de los cielos y de la tierra; [^19] Y bendito sea el Dios alto, que entregó tus enemigos en tu mano. Y dióle Abram los diezmos de todo. [^20] Entonces el rey de Sodoma dijo á Abram: Dame las personas, y toma para ti la hacienda. [^21] Y respondió Abram al rey de Sodoma: He alzado mi mano á Jehová Dios alto, poseedor de los cielos y de la tierra, [^22] Que desde un hilo hasta la correa de un calzado, nada tomaré de todo lo que es tuyo, porque no digas: Yo enriquecí á Abram: [^23] Sacando solamente lo que comieron los mancebos, y la porción de los varones que fueron conmigo, Aner, Eschôl, y Mamre; los cuales tomarán su parte. [^24] 

[[Genesis - 13|<--]] Genesis - 14 [[Genesis - 15|-->]]

---
# Notes
