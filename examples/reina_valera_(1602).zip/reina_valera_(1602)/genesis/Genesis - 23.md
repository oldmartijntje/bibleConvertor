---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 23 - Reina Valera (1602)"
---
[[Genesis - 22|<--]] Genesis - 23 [[Genesis - 24|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 23

Y FUÉ la vida de Sara ciento veintisiete años: tantos fueron los años de la vida de Sara. [^1] Y murió Sara en Kiriath-arba, que es Hebrón, en la tierra de Canaán: y vino Abraham á hacer el duelo á Sara y á llorarla. [^2] Y levantóse Abraham de delante de su muerto, y habló á los hijos de Heth, diciendo: [^3] Peregrino y advenedizo soy entre vosotros; dadme heredad de sepultura con vosotros, y sepultaré mi muerto de delante de mí. [^4] Y respondieron los hijos de Heth á Abraham, y dijéronle: [^5] Oyenos, señor mío, eres un príncipe de Dios entre nosotros; en lo mejor de nuestras sepulturas sepulta á tu muerto; ninguno de nosotros te impedirá su sepultura, para que entierres tu muerto. [^6] Y Abraham se levantó, é inclinóse al pueblo de aquella tierra, á los hijos de Heth; [^7] Y habló con ellos, diciendo: Si tenéis voluntad que yo sepulte mi muerto de delante de mí, oidme, é interceded por mí con Ephrón, hijo de Zohar, [^8] Para que me dé la cueva de Macpela, que tiene al cabo de su heredad: que por su justo precio me la dé, para posesión de sepultura en medio de vosotros. [^9] Este Ephrón hallábase entre los hijos de Heth: y respondió Ephrón Hetheo á Abraham, en oídos de los hijos de Heth, de todos los que entraban por la puerta de su ciudad, diciendo: [^10] No, señor mío, óyeme: te doy la heredad, y te doy también la cueva que está en ella; delante de los hijos de mi pueblo te la doy; sepulta tu muerto. [^11] Y Abraham se inclinó delante del pueblo de la tierra. [^12] Y respondió á Ephrón en oídos del pueblo de la tierra, diciendo: Antes, si te place, ruégote que me oigas; yo daré el precio de la heredad, tómalo de mí, y sepultaré en ella mi muerto. [^13] Y respondió Ephrón á Abraham, diciéndole: [^14] Señor mío, escúchame: la tierra vale cuatrocientos siclos de plata: ¿qué es esto entre mí y ti? entierra pues tu muerto. [^15] Entonces Abraham se convino con Ephrón, y pesó Abraham á Ephrón el dinero que dijo, oyéndolo los hijos de Heth, cuatrocientos siclos de plata, de buena ley entre mercaderes. [^16] Y quedó la heredad de Ephrón que estaba en Macpela enfrente de Mamre, la heredad y la cueva que estaba en ella, y todos los árboles que había en la heredad, y en todo su término al derredor, [^17] Por de Abraham en posesión, á vista de los hijos de Heth, y de todos los que entraban por la puerta de la ciudad. [^18] Y después de esto sepultó Abraham á Sara su mujer en la cueva de la heredad de Macpela enfrente de Mamre, que es Hebrón en la tierra de Canaán. [^19] Y quedó la heredad y la cueva que en ella había, por de Abraham, en posesión de sepultura adquirida de los hijos de Heth. [^20] 

[[Genesis - 22|<--]] Genesis - 23 [[Genesis - 24|-->]]

---
# Notes
