---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 48 - Reina Valera (1602)"
---
[[Genesis - 47|<--]] Genesis - 48 [[Genesis - 49|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 48

Y SUCEDIO después de estas cosas el haberse dicho á José: He aquí tu padre está enfermo. Y él tomó consigo sus dos hijos Manasés y Ephraim. [^1] Y se hizo saber á Jacob, diciendo: He aquí tu hijo José viene á ti. Entonces se esforzó Israel, y sentóse sobre la cama; [^2] Y dijo á José: El Dios Omnipotente me apareció en Luz en la tierra de Canaán, y me bendijo, [^3] Y díjome: He aquí, yo te haré crecer, y te multiplicaré, y te pondré por estirpe de pueblos: y daré esta tierra á tu simiente después de ti por heredad perpetua. [^4] Y ahora tus dos hijos Ephraim y Manasés, que te nacieron en la tierra de Egipto, antes que viniese á ti á la tierra de Egipto, míos son; como Rubén y Simeón, serán míos: [^5] Y los que después de ellos has engendrado, serán tuyos; por el nombre de sus hermanos serán llamados en sus heredades. [^6] Porque cuando yo venía de Padan-aram, se me murió Rachêl en la tierra de Canaán, en el camino, como media legua de tierra viniendo á Ephrata; y sepultéla allí en el camino de Ephrata, que es Bethlehem. [^7] Y vió Israel los hijos de José, y dijo: ¿Quiénes son éstos? [^8] Y respondió José á su padre: Son mis hijos, que Dios me ha dado aquí. Y él dijo: Allégalos ahora á mí, y los bendeciré. [^9] Y los ojos de Israel estaban tan agravados de la vejez, que no podía ver. Hízoles, pues, llegar á él, y él los besó y abrazó. [^10] Y dijo Israel á José: No pensaba yo ver tu rostro, y he aquí Dios me ha hecho ver también tu simiente. [^11] Entonces José los sacó de entre sus rodillas, é inclinóse á tierra. [^12] Y tomólos José á ambos, Ephraim á su diestra, á la siniestra de Israel; y á Manasés á su izquierda, á la derecha de Israel; é hízoles llegar á él. [^13] Entonces Israel extendió su diestra, y púsola sobre la cabeza de Ephraim, que era el menor, y su siniestra sobre la cabeza de Manasés, colocando así sus manos adrede, aunque Manasés era el primogénito. [^14] Y bendijo á José, y dijo: El Dios en cuya presencia anduvieron mis padres Abraham é Isaac, el Dios que me mantiene desde que yo soy hasta este día, [^15] El Angel que me liberta de todo mal, bendiga á estos mozos: y mi nombre sea llamado en ellos, y el nombre de mis padres Abraham é Isaac: y multipliquen en gran manera en medio de la tierra. [^16] Entonces viendo José que su padre ponía la mano derecha sobre la cabeza de Eprhaim, causóle esto disgusto; y asió la mano de su padre, para mudarla de sobre la cabeza de Ephraim á la cabeza de Manasés. [^17] Y dijo José á su padre: No así, padre mío, porque éste es el primogénito; pon tu diestra sobre su cabeza. [^18] Mas su padre no quiso, y dijo: Lo sé, hijo mío, lo sé: también él vendrá á ser un pueblo, y será también acrecentado; pero su hermano menor será más grande que él, y su simiente será plenitud de gentes. [^19] Y bendíjolos aquel día, diciendo: En ti bendecirá Israel, diciendo: Póngate Dios como á Ephraim y como á Manasés. Y puso á Ephraim delante de Manasés. [^20] Y dijo Israel á José: He aquí, yo muero, mas Dios será con vosotros, y os hará volver á la tierra de vuestros padres. [^21] Y yo te he dado á ti una parte sobre tus hermanos, la cual tomé yo de mano del Amorrheo con mi espada y con mi arco. [^22] 

[[Genesis - 47|<--]] Genesis - 48 [[Genesis - 49|-->]]

---
# Notes
