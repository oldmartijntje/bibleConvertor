---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 35 - Reina Valera (1602)"
---
[[Genesis - 34|<--]] Genesis - 35 [[Genesis - 36|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 35

Y DIJO Dios á Jacob: Levántate, sube á Beth-el, y estáte allí; y haz allí un altar al Dios que te apareció cuando huías de tu hermano Esaú. [^1] Entonces Jacob dijo á su familia y á todos los que con él estaban: Quitad los dioses ajenos que hay entre vosotros, y limpiaos, y mudad vuestros vestidos. [^2] Y levantémonos, y subamos á Beth-el; y haré allí altar al Dios que me respondió en el día de mi angustia, y ha sido conmigo en el camino que he andado. [^3] Así dieron á Jacob todos los dioses ajenos que había en poder de ellos, y los zarzillos que estaban en sus orejas; y Jacob los escondió debajo de una encina, que estaba junto á Sichêm. [^4] Y partiéronse, y el terror de Dios fué sobre las ciudades que había en sus alrededores, y no siguieron tras los hijos de Jacob. [^5] Y llegó Jacob á Luz, que está en tierra de Canaán, (esta es Beth-el) él y todo el pueblo que con él estaba; [^6] Y edificó allí un altar, y llamó el lugar El-Beth-el, porque allí le había aparecido Dios, cuando huía de su hermano. [^7] Entonces murió Débora, ama de Rebeca, y fue sepultada á las raíces de Beth-el, debajo de una encina: y llamóse su nombre Allon-Bacuth. [^8] Y aparecióse otra vez Dios á Jacob, cuando se había vuelto de Padan-aram, y bendíjole. [^9] Y díjole Dios: Tu nombre es Jacob; no se llamará más tu nombre Jacob, sino Israel será tu nombre: y llamó su nombre Israel. [^10] Y díjole Dios: Yo soy el Dios Omnipotente: crece y multiplícate; una nación y conjunto de naciones procederá de ti, y reyes saldrán de tus lomos: [^11] Y la tierra que yo he dado á Abraham y á Isaac, la daré á ti: y á tu simiente después de ti daré la tierra. [^12] Y fuése de él Dios, del lugar donde con él había hablado. [^13] Y Jacob erigió un título en el lugar donde había hablado con él, un título de piedra, y derramó sobre él libación, y echó sobre él aceite. [^14] Y llamó Jacob el nombre de aquel lugar donde Dios había hablado con él, Beth-el. [^15] Y partieron de Beth-el, y había aún como media legua de tierra para llegar á Ephrata, cuando parió Rachêl, y hubo trabajo en su parto. [^16] Y aconteció, que como había trabajo en su parir, díjole la partera: No temas, que también tendrás este hijo. [^17] Y acaeció que al salírsele el alma, (pues murió) llamó su nombre Benoni; mas su padre lo llamó Benjamín. [^18] Así murió Rachêl, y fué sepultada en el camino del Ephrata, la cual es Beth-lehem. [^19] Y puso Jacob un título sobre su sepultura: este es el título de la sepultura de Rachêl hasta hoy. [^20] Y partió Israel, y tendió su tienda de la otra parte de Migdaleder. [^21] Y acaeció, morando Israel en aquella tierra, que fué Rubén y durmió con Bilha la concubina de su padre; lo cual llegó á entender Israel. Ahora bien, los hijos de Israel fueron doce: [^22] Los hijos de Lea: Rubén el primogénito de Jacob, y Simeón, y Leví, y Judá, é Issachâr, y Zabulón. [^23] Los hijos de Rachêl: José, y Benjamín. [^24] Y los hijos de Bilha, sierva de Rachêl: Dan, y Nephtalí. [^25] Y los hijos de Zilpa, sierva de Lea: Gad, y Aser. Estos fueron los hijos de Jacob, que le nacieron en Padan-aram. [^26] Y vino Jacob á Isaac su padre á Mamre, á la ciudad de Arba, que es Hebrón, donde habitaron Abraham é Isaac. [^27] Y fueron los días de Isaac ciento ochenta años. [^28] Y exhaló Isaac el espíritu, y murió, y fué recogido á sus pueblos, viejo y harto de días; y sepultáronlo Esaú y Jacob sus hijos. [^29] 

[[Genesis - 34|<--]] Genesis - 35 [[Genesis - 36|-->]]

---
# Notes
