---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 17 - Reina Valera (1602)"
---
[[Genesis - 16|<--]] Genesis - 17 [[Genesis - 18|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 17

Y SIENDO Abram de edad de noventa y nueve años, aparecióle Jehová, y le dijo: Yo soy el Dios Todopoderoso; anda delante de mí, y sé perfecto. [^1] Y pondré mi pacto entre mí y ti, y multiplicarte he mucho en gran manera. [^2] Entonces Abram cayó sobre su rostro, y Dios habló con él diciendo: [^3] Yo, he aquí mi pacto contigo: Serás padre de muchedumbre de gentes: [^4] Y no se llamará más tu nombre Abram, sino que será tu nombre Abraham, porque te he puesto por padre de muchedumbre de gentes. [^5] Y multiplicarte he mucho en gran manera, y te pondré en gentes, y reyes saldrán de ti. [^6] Y estableceré mi pacto entre mí y ti, y tu simiente después de ti en sus generaciones, por alianza perpetua, para serte á ti por Dios, y á tu simiente después de ti. [^7] Y te daré á ti, y á tu simiente después de ti, la tierra de tus peregrinaciones, toda la tierra de Canaán en heredad perpetua; y seré el Dios de ellos. [^8] Dijo de nuevo Dios á Abraham: Tú empero guardarás mi pacto, tú y tu simiente después de ti por sus generaciones. [^9] Este será mi pacto, que guardaréis entre mí y vosotros y tu simiente después de ti: Será circuncidado todo varón de entre vosotros. [^10] Circuncidaréis, pues, la carne de vuestro prepucio, y será por señal del pacto entre mí y vosotros. [^11] Y de edad de ocho días será circuncidado todo varón entre vosotros por vuestras generaciones: el nacido en casa, y el comprado á dinero de cualquier extranjero, que no fuere de tu simiente. [^12] Debe ser circuncidado el nacido en tu casa, y el comprado por tu dinero: y estará mi pacto en vuestra carne para alianza perpetua. [^13] Y el varón incircunciso que no hubiere circuncidado la carne de su prepucio, aquella persona será borrada de su pueblo; ha violado mi pacto. [^14] Dijo también Dios á Abraham: A Sarai tu mujer no la llamarás Sarai, mas Sara será su nombre. [^15] Y bendecirla he, y también te daré de ella hijo; sí, la bendeciré, y vendrá á ser madre de naciones; reyes de pueblos serán de ella. [^16] Entonces Abraham cayó sobre su rostro, y rióse, y dijo en su corazón: ¿A hombre de cien años ha de nacer hijo? ¿y Sara, ya de noventa años, ha de parir? [^17] Y dijo Abraham á Dios: Ojalá Ismael viva delante de ti. [^18] Y respondió Dios: Ciertamente Sara tu mujer te parirá un hijo, y llamarás su nombre Isaac; y confirmaré mi pacto con él por alianza perpetua para su simiente después de él. [^19] Y en cuanto á Ismael, también te he oído: he aquí que le bendeciré, y le haré fructificar y multiplicar mucho en gran manera: doce príncipes engendrará, y ponerlo he por gran gente. [^20] Mas yo estableceré mi pacto con Isaac, al cual te parirá Sara por este tiempo el año siguiente. [^21] Y acabó de hablar con él, y subió Dios de con Abraham. [^22] Entonces tomó Abraham á Ismael su hijo, y á todos los siervos nacidos en su casa, y á todos los comprados por su dinero, á todo varón entre los domésticos de la casa de Abraham, y circuncidó la carne del prepucio de ellos en aquel mismo día, como Dios le había dicho. [^23] Era Abraham de edad de noventa y nueve años cuando circuncidó la carne de su prepucio. [^24] E Ismael su hijo era de trece años cuando fué circuncidada la carne de su prepucio. [^25] En el mismo día fué circuncidado Abraham é Ismael su hijo. [^26] Y todos los varones de su casa, el siervo nacido en casa, y el comprado por dinero del extranjero, fueron circuncidados con él. [^27] 

[[Genesis - 16|<--]] Genesis - 17 [[Genesis - 18|-->]]

---
# Notes
