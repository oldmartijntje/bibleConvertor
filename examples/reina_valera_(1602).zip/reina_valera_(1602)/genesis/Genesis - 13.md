---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 13 - Reina Valera (1602)"
---
[[Genesis - 12|<--]] Genesis - 13 [[Genesis - 14|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 13

SUBIO, pues, Abram de Egipto hacia el Mediodía, él y su mujer, con todo lo que tenía, y con él Lot. [^1] Y Abram era riquísimo en ganado, en plata y oro. [^2] Y volvió por sus jornadas de la parte del Mediodía hacia Bethel, hasta el lugar donde había estado antes su tienda entre Bethel y Hai; [^3] Al lugar del altar que había hecho allí antes: é invocó allí Abram el nombre de Jehová. [^4] Y asimismo Lot, que andaba con Abram, tenía ovejas, y vacas, y tiendas. [^5] Y la tierra no podía darles para que habitasen juntos: porque su hacienda era mucha, y no podían morar en un mismo lugar. [^6] Y hubo contienda entre los pastores del ganado de Abram y los pastores del ganado de Lot: y el Cananeo y el Pherezeo habitaban entonces en la tierra. [^7] Entonces Abram dijo á Lot: No haya ahora altercado entre mí y ti, entre mis pastores y los tuyos, porque somos hermanos. [^8] ¿No está toda la tierra delante de ti? Yo te ruego que te apartes de mí. Si fueres á la mano izquierda, yo iré á la derecha: y si tú á la derecha, yo iré á la izquierda. [^9] Y alzó Lot sus ojos, y vió toda la llanura del Jordán, que toda ella era de riego, antes que destruyese Jehová á Sodoma y á Gomorra, como el huerto de Jehová, como la tierra de Egipto entrando en Zoar. [^10] Entonces Lot escogió para sí toda la llanura del Jordán: y partióse Lot de Oriente, y apartáronse el uno del otro. [^11] Abram asentó en la tierra de Canaán, y Lot asentó en las ciudades de la llanura, y fué poniendo sus tiendas hasta Sodoma. [^12] Mas los hombres de Sodoma eran malos y pecadores para con Jehová en gran manera. [^13] Y Jehová dijo á Abram, después que Lot se apartó de él: Alza ahora tus ojos, y mira desde el lugar donde estás hacia el Aquilón, y al Mediodía, y al Oriente y al Occidente; [^14] Porque toda la tierra que ves, la daré á ti y á tu simiente para siempre. [^15] Y haré tu simiente como el polvo de la tierra: que si alguno podrá contar el polvo de la tierra, también tu simiente será contada. [^16] Levántate, ve por la tierra á lo largo de ella y á su ancho; porque á ti la tengo de dar. [^17] Abram, pues, removiendo su tienda, vino y moró en el alcornocal de Mamre, que es en Hebrón, y edificó allí altar á Jehová. [^18] 

[[Genesis - 12|<--]] Genesis - 13 [[Genesis - 14|-->]]

---
# Notes
