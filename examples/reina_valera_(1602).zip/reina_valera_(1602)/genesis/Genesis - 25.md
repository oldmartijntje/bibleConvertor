---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 25 - Reina Valera (1602)"
---
[[Genesis - 24|<--]] Genesis - 25 [[Genesis - 26|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 25

Y ABRAHAM tomó otra mujer, cuyo nombre fué Cetura; [^1] La cual le parió á Zimram, y á Joksan, y á Medan, y á Midiam, y á Ishbak, y á Sua. [^2] Y Joksan engendró á Seba, y á Dedán: é hijos de Dedán fueron Assurim, y Letusim, y Leummim. [^3] E hijos de Midiam: Epha, y Epher, y Enech, y Abida, y Eldaa. Todos estos fueron hijos de Cetura. [^4] Y Abraham dió todo cuanto tenía á Isaac. [^5] Y á los hijos de sus concubinas dió Abraham dones, y enviólos de junto Isaac su hijo, mientras él vivía, hacia el oriente, á la tierra oriental. [^6] Y estos fueron los días de vida que vivió Abraham: ciento setenta y cinco años. [^7] Y exhaló el espíritu, y murió Abraham en buena vejez, anciano y lleno de días y fué unido á su pueblo. [^8] Y sepultáronlo Isaac é Ismael sus hijos en la cueva de Macpela, en la heredad de Ephrón, hijo de Zoar Hetheo, que está enfrente de Mamre; [^9] Heredad que compró Abraham de los hijos de Heth; allí fué Abraham sepultado, y Sara su mujer. [^10] Y sucedió, después de muerto Abraham, que Dios bendijo á Isaac su hijo: y habitó Isaac junto al pozo del Viviente que me ve. [^11] Y estas son las generaciones de Ismael, hijo de Abraham, que le parió Agar Egipcia, sierva de Sara: [^12] Estos, pues, son los nombres de los hijos de Ismael, por sus nombres, por sus linajes: El primogénito de Ismael, Nabaioth; luego Cedar, y Abdeel, y Mibsam, [^13] Y Misma, y Duma, y Massa, [^14] Hadad, y Tema, y Jetur, y Naphis, y Cedema. [^15] Estos son los hijos de Ismael, y estos sus nombres por sus villas y por sus campamentos; doce príncipes por sus familias. [^16] Y estos fueron los años de la vida de Ismael, ciento treinta y siete años: y exhaló el espíritu Ismael, y murió; y fué unido á su pueblo. [^17] Y habitaron desde Havila hasta Shur, que está enfrente de Egipto viniendo á Asiria; y murió en presencia de todos sus hermanos. [^18] Y estas son las generaciones de Isaac, hijo de Abraham. Abraham engendró á Isaac: [^19] Y era Isaac de cuarenta años cuando tomó por mujer á Rebeca, hija de Bethuel Arameo de Padan-aram, hermana de Labán Arameo. [^20] Y oró Isaac á Jehová por su mujer, que era estéril; y aceptólo Jehová, y concibió Rebeca su mujer. [^21] Y los hijos se combatían dentro de ella; y dijo: Si es así ¿para qué vivo yo? Y fue á consultar á Jehová. [^22] Y respondióle Jehová: Dos gentes hay en tu seno, Y dos pueblos serán divididos desde tus entrañas: Y el un pueblo será más fuerte que el otro pueblo, Y el mayor servirá al menor. [^23] Y como se cumplieron sus días para parir, he aquí mellizos en su vientre. [^24] Y salió el primero rubio, y todo él velludo como una pelliza; y llamaron su nombre Esaú. [^25] Y después salió su hermano, trabada su mano al calcañar de Esaú: y fué llamado su nombre Jacob. Y era Isaac de edad de sesenta años cuando ella los parió. [^26] Y crecieron los niños, y Esaú fué diestro en la caza, hombre del campo: Jacob empero era varón quieto, que habitaba en tiendas. [^27] Y amó Isaac á Esaú, porque comía de su caza; mas Rebeca amaba á Jacob. [^28] Y guisó Jacob un potaje; y volviendo Esaú del campo cansado, [^29] Dijo á Jacob: Ruégote que me des á comer de eso bermejo, pues estoy muy cansado. Por tanto fué llamado su nombre Edom. [^30] Y Jacob respondió: Véndeme en este día tu primogenitura. [^31] Entonces dijo Esaú: He aquí yo me voy á morir; ¿para qué, pues, me servirá la primogenitura? [^32] Y dijo Jacob: Júrame lo en este día. Y él le juró, y vendió á Jacob su primogenitura. [^33] Entonces Jacob dió á Esaú pan y del guisado de las lentejas; y él comió y bebió, y levantóse, y fuése. Así menospreció Esaú la primogenitura. [^34] 

[[Genesis - 24|<--]] Genesis - 25 [[Genesis - 26|-->]]

---
# Notes
