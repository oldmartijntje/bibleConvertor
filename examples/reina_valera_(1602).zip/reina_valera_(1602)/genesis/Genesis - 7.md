---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 7 - Reina Valera (1602)"
---
[[Genesis - 6|<--]] Genesis - 7 [[Genesis - 8|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 7

Y JEHOVA dijo á Noé: Entra tú y toda tu casa en el arca porque á ti he visto justo delante de mí en esta generación. [^1] De todo animal limpio te tomarás de siete en siete, macho y su hembra; mas de los animales que no son limpios, dos, macho y su hembra. [^2] También de las aves de los cielos de siete en siete, macho y hembra; para guardar en vida la casta sobre la faz de toda la tierra. [^3] Porque pasados aún siete días, yo haré llover sobre la tierra cuarenta días y cuarenta noches; y raeré toda sustancia que hice de sobre la faz de la tierra. [^4] E hizo Noé conforme á todo lo que le mandó Jehová. [^5] Y siendo Noé de seiscientos años, el diluvio de las aguas fué sobre la tierra. [^6] Y vino Noé, y sus hijos, y su mujer, y las mujeres de sus hijos con él al arca, por las aguas del diluvio. [^7] De los animales limpios, y de los animales que no eran limpios, y de las aves, y de todo lo que anda arrastrando sobre la tierra, [^8] De dos en dos entraron á Noé en el arca: macho y hembra, como mandó Dios á Noé. [^9] Y sucedió que al séptimo día las aguas del diluvio fueron sobre la tierra. [^10] El año seiscientos de la vida de Noé, en el mes segundo á diecisiete días del mes, aquel día fueron rotas todas las fuentes del grande abismo, y las cataratas de los cielos fueron abiertas; [^11] Y hubo lluvia sobre la tierra cuarenta días y cuarenta noches. [^12] En este mismo día entró Noé, y Sem, y Châm y Japhet, hijos de Noé, la mujer de Noé, y las tres mujeres de sus hijos con él en el arca; [^13] Ellos y todos los animales silvestres según sus especies, y todos los animales mansos según sus especies, y todo reptil que anda arrastrando sobre la tierra según su especie, y toda ave según su especie, todo pájaro, toda especie de volátil. [^14] Y vinieron á Noé al arca, de dos en dos de toda carne en que había espíritu de vida. [^15] Y los que vinieron, macho y hembra de toda carne vinieron, como le había mandado Dios: y Jehová le cerró la puerta [^16] Y fué el diluvio cuarenta días sobre la tierra; y las aguas crecieron, y alzaron el arca, y se elevó sobre la tierra. [^17] Y prevalecieron las aguas, y crecieron en gran manera sobre la tierra; y andaba el arca sobre la faz de las aguas. [^18] Y las aguas prevalecieron mucho en extremo sobre la tierra; y todos los montes altos que había debajo de todos los cielos, fueron cubiertos. [^19] Quince codos en alto prevalecieron las aguas; y fueron cubiertos los montes. [^20] Y murió toda carne que se mueve sobre la tierra, así de aves como de ganados, y de bestias, y de todo reptil que anda arrastrando sobre la tierra, y todo hombre: [^21] Todo lo que tenía aliento de espíritu de vida en sus narices, de todo lo que había en la tierra, murió. [^22] Así fué destruída toda sustancia que vivía sobre la faz de la tierra, desde el hombre hasta la bestia, y los reptiles, y las aves del cielo; y fueron raídos de la tierra; y quedó solamente Noé, y lo que con él estaba en el arca. [^23] Y prevalecieron las aguas sobre la tierra ciento y cincuenta días. [^24] 

[[Genesis - 6|<--]] Genesis - 7 [[Genesis - 8|-->]]

---
# Notes
