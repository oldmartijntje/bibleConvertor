---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 33 - Reina Valera (1602)"
---
[[Genesis - 32|<--]] Genesis - 33 [[Genesis - 34|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 33

Y ALZANDO Jacob sus ojos miró, y he aquí venía Esaú, y los cuatrocientos hombres con él: entonces repartió él los niños entre Lea y Rachêl y las dos siervas. [^1] Y puso las siervas y sus niños delante; luego á Lea y á sus niños; y á Rachêl y á José los postreros. [^2] Y él pasó delante de ellos, é inclinóse á tierra siete veces, hasta que llegó á su hermano. [^3] Y Esaú corrió á su encuentro, y abrazóle, y echóse sobre su cuello, y le besó; y lloraron. [^4] Y alzó sus ojos, y vió las mujeres y los niños, y dijo: ¿Qué te tocan éstos? Y él respondió: Son los niños que Dios ha dado á tu siervo. [^5] Y se llegaron las siervas, ellas y sus niños, é inclináronse. [^6] Y llegóse Lea con sus niños, é inclináronse: y después llegó José y Rachêl, y también se inclinaron. [^7] Y él dijo: ¿Qué te propones con todas estas cuadrillas que he encontrado? Y él respondió: El hallar gracia en los ojos de mi señor. [^8] Y dijo Esaú: Harto tengo yo, hermano mío: sea para ti lo que es tuyo. [^9] Y dijo Jacob: No, yo te ruego, si he hallado ahora gracia en tus ojos, toma mi presente de mi mano, pues que así he visto tu rostro, como si hubiera visto el rostro de Dios; y hazme placer. [^10] Toma, te ruego, mi dádiva que te es traída; porque Dios me ha hecho merced, y todo lo que hay aquí es mío. Y porfió con él, y tomóla. [^11] Y dijo: Anda, y vamos; y yo iré delante de ti. [^12] Y él le dijo: Mi señor sabe que los niños son tiernos, y que tengo ovejas y vacas paridas; y si las fatigan, en un día morirán todas las ovejas. [^13] Pase ahora mi señor delante de su siervo, y yo me iré poco á poco al paso de la hacienda que va delante de mí, y al paso de los niños, hasta que llegue á mi señor á Seir. [^14] Y Esaú dijo: Dejaré ahora contigo de la gente que viene conmigo. Y él dijo: ¿Para qué esto? halle yo gracia en los ojos de mi señor. [^15] Así se volvió Esaú aquel día por su camino á Seir. [^16] Y Jacob se partió á Succoth, y edificó allí casa para sí, é hizo cabañas para su ganado: por tanto llamó el nombre de aquel lugar Succoth. [^17] Y vino Jacob sano á la ciudad de Sichêm, que está en la tierra de Canaán, cuando venía de Padan-aram; y acampó delante de la ciudad. [^18] Y compró una parte del campo, donde tendió su tienda, de mano de los hijos de Hamor, padre de Sichêm, por cien piezas de moneda. [^19] Y erigió allí un altar, y llamóle: El Dios de Israel. [^20] 

[[Genesis - 32|<--]] Genesis - 33 [[Genesis - 34|-->]]

---
# Notes
