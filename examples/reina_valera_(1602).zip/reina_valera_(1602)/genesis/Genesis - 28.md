---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 28 - Reina Valera (1602)"
---
[[Genesis - 27|<--]] Genesis - 28 [[Genesis - 29|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 28

ENTONCES Isaac llamó á Jacob, y bendíjolo, y mandóle diciendo: No tomes mujer de las hijas de Canaán. [^1] Levántate, ve á Padan-aram, á casa de Bethuel, padre de tu madre, y toma allí mujer de las hijas de Labán, hermano de tu madre. [^2] Y el Dios omnipotente te bendiga y te haga fructificar, y te multiplique, hasta venir á ser congregación de pueblos; [^3] Y te dé la bendición de Abraham, y á tu simiente contigo, para que heredes la tierra de tus peregrinaciones, que Dios dió á Abraham. [^4] Así envió Isaac á Jacob, el cual fué á Padan-aram, á Labán, hijo de Bethuel Arameo, hermano de Rebeca, madre de Jacob y de Esaú. [^5] Y vió Esaú cómo Isaac había bendecido á Jacob, y le había enviado á Padan-aram, para tomar para sí mujer de allí; y que cuando le bendijo, le había mandado, diciendo: No tomarás mujer de las hijas de Canaán; [^6] Y que Jacob había obedecido á su padre y á su madre, y se había ido á Padan-aram. [^7] Vió asimismo Esaú que las hijas de Canaán parecían mal á Isaac su padre; [^8] Y fuése Esaú á Ismael, y tomó para sí por mujer á Mahaleth, hija de Ismael, hijo de Abraham, hermana de Nabaioth, además de sus otras mujeres. [^9] Y salió Jacob de Beer-seba, y fué á Harán; [^10] Y encontró con un lugar, y durmió allí porque ya el sol se había puesto: y tomó de las piedras de aquel paraje y puso á su cabecera, y acostóse en aquel lugar. [^11] Y soñó, y he aquí una escala que estaba apoyada en tierra, y su cabeza tocaba en el cielo: y he aquí ángeles de Dios que subían y descendían por ella. [^12] Y he aquí, Jehová estaba en lo alto de ella, el cual dijo: Yo soy Jehová, el Dios de Abraham tu padre, y el Dios de Isaac: la tierra en que estás acostado te la daré á ti y á tu simiente. [^13] Y será tu simiente como el polvo de la tierra, y te extenderás al occidente, y al oriente, y al aquilón, y al mediodía; y todas las familias de la tierra serán benditas en ti y en tu simiente. [^14] Y he aquí, yo soy contigo, y te guardaré por donde quiera que fueres, y te volveré á esta tierra; porque no te dejaré hasta tanto que haya hecho lo que te he dicho. [^15] Y despertó Jacob de su sueño dijo: Ciertamente Jehové está en este lugar, y yo no lo sabía. [^16] Y tuvo miedo, y dijo: ­Cuán terrible es este lugar! No es otra cosa que casa de Dios, y puerta del cielo. [^17] Y levantóse Jacob de mañana, y tomó la piedra que había puesto de cabecera, y alzóla por título, y derramó aceite encima de ella. [^18] Y llamó el nombre de aquel lugar Beth-el, bien que Luz era el nombre de la ciudad primero. [^19] E hizo Jacob voto, diciendo: Si fuere Dios conmigo, y me guardare en este viaje que voy, y me diere pan para comer y vestido para vestir, [^20] Y si tornare en paz á casa de mi padre, Jehová será mi Dios, [^21] Y esta piedra que he puesto por título, será casa de Dios: y de todo lo que me dieres, el diezmo lo he de apartar para ti. [^22] 

[[Genesis - 27|<--]] Genesis - 28 [[Genesis - 29|-->]]

---
# Notes
