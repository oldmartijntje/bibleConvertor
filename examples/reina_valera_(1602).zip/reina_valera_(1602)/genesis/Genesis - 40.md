---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 40 - Reina Valera (1602)"
---
[[Genesis - 39|<--]] Genesis - 40 [[Genesis - 41|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 40

Y ACONTECIO después de estas cosas, que el copero del rey de Egipto y el panadero delinquieron contra su señor el rey de Egipto. [^1] Y enojóse Faraón contra sus dos eunucos, contra el principal de los coperos, y contra el principal de los panaderos: [^2] Y púsolos en prisión en la casa del capitán de los de la guardia, en la casa de la cárcel donde José estaba preso. [^3] Y el capitán de los de la guardia dió cargo de ellos á José, y él les servía: y estuvieron días en la prisión. [^4] Y ambos á dos, el copero y el panadero del rey de Egipto, que estaban arrestados en la prisión, vieron un sueño, cada uno su sueño en una misma noche, cada uno conforme á la declaración de su sueño. [^5] Y vino á ellos José por la mañana, y mirólos, y he aquí que estaban tristes. [^6] Y él preguntó á aquellos eunucos de Faraón, que estaban con él en la prisión de la casa de su señor, diciendo: ¿Por qué parecen hoy mal vuestros semblantes? [^7] Y ellos le dijeron: Hemos tenido un sueño, y no hay quien lo declare. Entonces les dijo José: ¿No son de Dios las declaraciones? Contádmelo ahora. [^8] Entonces el principal de los coperos contó su sueño á José, y díjole: Yo soñaba que veía una vid delante de mí, [^9] Y en la vid tres sarmientos; y ella como que brotaba, y arrojaba su flor, viniendo á madurar sus racimos de uvas: [^10] Y que la copa de Faraón estaba en mi mano, y tomaba yo las uvas, y las exprimía en la copa de Faraón, y daba yo la copa en mano de Faraón. [^11] Y díjole José: Esta es su declaración: Los tres sarmientos son tres días: [^12] Al cabo de tres días Faraón te hará levantar cabeza, y te restituirá á tu puesto: y darás la copa á Faraón en su mano, como solías cuando eras su copero. [^13] Acuérdate, pues, de mí para contigo cuando tuvieres ese bien, y ruégote que uses conmigo de misericordia, y hagas mención de mí á Faraón, y me saques de esta casa: [^14] Porque hurtado he sido de la tierra de los Hebreos; y tampoco he hecho aquí porqué me hubiesen de poner en la cárcel. [^15] Y viendo el principal de los panaderos que había declarado para bien, dijo á José: También yo soñaba que veía tres canastillos blancos sobre mi cabeza; [^16] Y en el canastillo más alto había de todas las viandas de Faraón, obra de panadero; y que las aves las comían del canastillo de sobre mi cabeza. [^17] Entonces respondió José, y dijo: Esta es su declaración: Los tres canastillos tres días son; [^18] Al cabo de tres días quitará Faraón tu cabeza de sobre ti, y te hará colgar en la horca, y las aves comerán tu carne de sobre ti. [^19] Y fué el tercero día el día del nacimiento de Faraón, é hizo banquete á todos sus sirvientes: y alzó la cabeza del principal de los coperos, y la cabeza del principal de los panaderos, entre sus servidores. [^20] E hizo volver á su oficio al principal de los coperos; y dió él la copa en mano de Faraón. [^21] Mas hizo ahorcar al principal de los panaderos, como le había declarado José. [^22] Y el principal de los coperos no se acordó de José, sino que le olvidó. [^23] 

[[Genesis - 39|<--]] Genesis - 40 [[Genesis - 41|-->]]

---
# Notes
