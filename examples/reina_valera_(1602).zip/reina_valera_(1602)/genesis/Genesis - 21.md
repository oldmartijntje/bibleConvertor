---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 21 - Reina Valera (1602)"
---
[[Genesis - 20|<--]] Genesis - 21 [[Genesis - 22|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 21

Y VISITO Jehová á Sara, como había dicho, é hizo Jehová con Sara como había hablado. [^1] Y concibió y parió Sara á Abraham un hijo en su vejez, en el tiempo que Dios le había dicho. [^2] Y llamó Abraham el nombre de su hijo que le nació, que le parió Sara, Isaac. [^3] Y circuncidó Abraham á su hijo Isaac de ocho días, como Dios le había mandado. [^4] Y era Abraham de cien años, cuando le nació Isaac su hijo. [^5] Entonces dijo Sara: Dios me ha hecho reir, y cualquiera que lo oyere, se reirá conmigo. [^6] Y añadió: ¿Quién dijera á Abraham que Sara había de dar de mamar á hijos? pues que le he parido un hijo á su vejez. [^7] Y creció el niño, y fué destetado; é hizo Abraham gran banquete el día que fué destetado Isaac. [^8] Y vió Sara al hijo de Agar la Egipcia, el cual había ésta parido á Abraham, que se burlaba. [^9] Por tanto dijo á Abraham: Echa á esta sierva y á su hijo; que el hijo de esta sierva no ha de heredar con mi hijo, con Isaac. [^10] Este dicho pareció grave en gran manera á Abraham á causa de su hijo. [^11] Entonces dijo Dios á Abraham: No te parezca grave á causa del muchacho y de tu sierva; en todo lo que te dijere Sara, oye su voz, porque en Isaac te será llamada descendencia. [^12] Y también al hijo de la sierva pondré en gente, porque es tu simiente. [^13] Entonces Abraham se levantó muy de mañana, y tomó pan, y un odre de agua, y diólo á Agar, poniéndolo sobre su hombro, y entrególe el muchacho, y despidióla. Y ella partió, y andaba errante por el desierto de Beer-seba. [^14] Y faltó el agua del odre, y echó al muchacho debajo de un árbol; [^15] Y fuése y sentóse enfrente, alejándose como un tiro de arco; porque decía: No veré cuando el muchacho morirá: y sentóse enfrente, y alzó su voz y lloró. [^16] Y oyó Dios la voz del muchacho; y el ángel de Dios llamó á Agar desde el cielo, y le dijo: ¿Qué tienes, Agar? No temas; porque Dios ha oído la voz del muchacho en donde está. [^17] Levántate, alza al muchacho, y ásele de tu mano, porque en gran gente lo tengo de poner. [^18] Entonces abrió Dios sus ojos, y vió una fuente de agua; y fué, y llenó el odre de agua, y dió de beber al muchacho. [^19] Y fué Dios con el muchacho; y creció, y habitó en el desierto, y fué tirador de arco. [^20] Y habitó en el desierto de Parán; y su madre le tomó mujer de la tierra de Egipto. [^21] Y aconteció en aquel mismo tiempo que habló Abimelech, y Phicol, príncipe de su ejército, á Abraham diciendo: Dios es contigo en todo cuanto haces. [^22] Ahora pues, júrame aquí por Dios, que no faltarás á mí, ni á mi hijo, ni á mi nieto; sino que conforme á la bondad que yo hice contigo, harás tú conmigo y con la tierra donde has peregrinado. [^23] Y respondió Abraham: Yo juraré. [^24] Y Abraham reconvino á Abimelech á causa de un pozo de agua, que los siervos de Abimelech le habían quitado. [^25] Y respondió Abimelech: No sé quién haya hecho esto, ni tampoco tú me lo hiciste saber, ni yo lo he oído hasta hoy. [^26] Y tomó Abraham ovejas y vacas, y dió á Abimelech; é hicieron ambos alianza. [^27] Y puso Abraham siete corderas del rebaño aparte. [^28] Y dijo Abimelech á Abraham: ¿Qué significan esas siete corderas que has puesto aparte? [^29] Y él respondió: Que estas siete corderas tomarás de mi mano, para que me sean en testimonio de que yo cavé este pozo. [^30] Por esto llamó á aquel lugar Beer-seba; porque allí juraron ambos. [^31] Así hicieron alianza en Beer-seba: y levantóse Abimelech y Phicol, príncipe de su ejército, y se volvieron á tierra de los Filisteos. [^32] Y plantó Abraham un bosque en Beer-seba, é invocó allí el nombre de Jehová Dios eterno. [^33] Y moró Abraham en tierra de los Filisteos muchos días. [^34] 

[[Genesis - 20|<--]] Genesis - 21 [[Genesis - 22|-->]]

---
# Notes
