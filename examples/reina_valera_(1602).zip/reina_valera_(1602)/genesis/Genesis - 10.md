---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 10 - Reina Valera (1602)"
---
[[Genesis - 9|<--]] Genesis - 10 [[Genesis - 11|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 10

ESTAS son las generaciones de los hijos de Noé: Sem, Châm y Japhet, á los cuales nacieron hijos después del diluvio. [^1] Los hijos de Japhet: Gomer, y Magog, y Madai, y Javán, y Tubal, y Meshech, y Tiras. [^2] Y los hijos de Gomer: Ashkenaz, y Riphat, y Togorma. [^3] Y los hijos de Javán: Elisa, y Tarsis, Kittim, y Dodanim. [^4] Por éstos fueron repartidas las islas de las gentes en sus tierras, cada cual según su lengua, conforme á sus familias en sus naciones. [^5] Los hijos de Châm: Cush, y Mizraim, y Phut, y Canaán. [^6] Y los hijos de Cush: Seba, Havila, y Sabta, y Raama, y Sabtecha. Y los hijos de Raama: Sheba y Dedán. [^7] Y Cush engendró á Nimrod, éste comenzó á ser poderoso en la tierra. [^8] Este fué vigoroso cazador delante de Jehová; por lo cual se dice: Así como Nimrod, vigoroso cazador delante de Jehová. [^9] Y fué la cabecera de su reino Babel, y Erech, y Accad, y Calneh, en la tierra de Shinar. [^10] De aquesta tierra salió Assur, y edificó á Nínive, y á Rehoboth, y á Calah, [^11] Y á Ressen entre Nínive y Calah; la cual es ciudad grande. [^12] Y Mizraim engendró á Ludim, y á Anamim, y á Lehabim, y á Naphtuhim, [^13] Y á Pathrusim, y á Casluim de donde salieron los Filisteos, y á Caphtorim. [^14] Y Canaán engendró á Sidón, su primogénito y á Heth, [^15] Y al Jebuseo, y al Amorrheo, y al Gergeseo, [^16] Y al Heveo, y al Araceo, y al Sineo, [^17] Y al Aradio, y al Samareo, y al Amatheo: y después se derramaron las familias de los Cananeos. [^18] Y fué el término de los Cananeos desde Sidón, viniendo á Gerar hasta Gaza, hasta entrar en Sodoma y Gomorra, Adma, y Zeboim hasta Lasa. [^19] Estos son los hijos de Châm por sus familias, por sus lenguas, en sus tierras, en sus naciones. [^20] También le nacieron hijos á Sem, padre de todos los hijos de Heber, y hermano mayor de Japhet. [^21] Y los hijos de Sem: Elam, y Assur, y Arphaxad, y Lud, y Aram. [^22] Y los hijos de Aram: Uz, y Hul, y Gether, y Mas. [^23] Y Arphaxad engendró á Sala, y Sala engendró á Heber. [^24] Y á Heber nacieron dos hijos: el nombre de uno fué Peleg, porque en sus días fué repartida la tierra; y el nombre de su hermano, Joctán. [^25] Y Joctán engendró á Almodad, y á Sheleph, y Hazarmaveth, y á Jera, [^26] Y á Hadoram, y á Uzal, y á Dicla, [^27] Y á Obal, y á Abimael, y á Seba, [^28] Y á Ophir, y á Havila, y á Jobad: todos estos fueron hijos de Joctán. [^29] Y fué su habitación desde Mesa viniendo de Sephar, monte á la parte del oriente. [^30] Estos fueron los hijos de Sem por sus familias, por sus lenguas, en sus tierras, en sus naciones. [^31] Estas son las familias de Noé por sus descendencias, en sus naciones; y de éstos fueron divididas las gentes en la tierra después del diluvio. [^32] 

[[Genesis - 9|<--]] Genesis - 10 [[Genesis - 11|-->]]

---
# Notes
