---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 16 - Reina Valera (1602)"
---
[[Genesis - 15|<--]] Genesis - 16 [[Genesis - 17|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 16

Y SARAI, mujer de Abram no le paría: y ella tenía una sierva egipcia, que se llamaba Agar. [^1] Dijo, pues, Sarai á Abram: Ya ves que Jehová me ha hecho estéril: ruégote que entres á mi sierva; quizá tendré hijos de ella. Y atendió Abram al dicho de Sarai. [^2] Y Sarai, mujer de Abram, tomó á Agar su sierva egipcia, al cabo de diez años que había habitado Abram en la tierra de Canaán, y dióla á Abram su marido por mujer. [^3] Y él cohabitó con Agar, la cual concibió: y cuando vió que había concebido, miraba con desprecio á su señora. [^4] Entonces Sarai dijo á Abram: Mi afrenta sea sobre ti: yo puse mi sierva en tu seno, y viéndose embarazada, me mira con desprecio; juzgue Jehová entre mí y ti. [^5] Y respondió Abram á Sarai: He ahí tu sierva en tu mano, haz con ella lo que bien te pareciere. Y como Sarai la afligiese, huyóse de su presencia. [^6] Y hallóla el ángel de Jehová junto á una fuente de agua en el desierto, junto á la fuente que está en el camino del Sur. [^7] Y le dijo: Agar, sierva de Sarai, ¿de dónde vienes tú, y á dónde vas? Y ella respondió: Huyo de delante de Sarai, mi señora. [^8] Y díjole el ángel de Jehová: Vuélvete á tu señora, y ponte sumisa bajo de su mano. [^9] Díjole también el ángel de Jehová: Multiplicaré tanto tu linaje, que no será contado á causa de la muchedumbre. [^10] Díjole aún el ángel de Jehová: He aquí que has concebido, y parirás un hijo, y llamarás su nombre Ismael, porque oído ha Jehová tu aflicción. [^11] Y él será hombre fiero; su mano contra todos, y las manos de todos contra él, y delante de todos sus hermanos habitará. [^12] Entonces llamó el nombre de Jehová que con ella hablaba: Tú eres el Dios de la vista; porque dijo: ¿No he visto también aquí al que me ve? [^13] Por lo cual llamó al pozo, Pozo del Viviente que me ve. He aquí está entre Cades y Bered. [^14] Y parió Agar á Abram un hijo y llamó Abram el nombre de su hijo que le parió Agar, Ismael. [^15] Y era Abram de edad de ochenta y seis años, cuando parió Agar á Ismael. [^16] 

[[Genesis - 15|<--]] Genesis - 16 [[Genesis - 17|-->]]

---
# Notes
