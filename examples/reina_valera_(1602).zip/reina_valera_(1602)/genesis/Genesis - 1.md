---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 1 - Reina Valera (1602)"
---
Genesis - 1 [[Genesis - 2|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 1

EN el principio crió Dios los cielos y la tierra. [^1] Y la tierra estaba desordenada y vacía, y las tinieblas estaban sobre la haz del abismo, y el Espíritu de Dios se movía sobre la haz de las aguas. [^2] Y dijo Dios: Sea la luz: y fué la luz. [^3] Y vió Dios que la luz era buena: y apartó Dios la luz de las tinieblas. [^4] Y llamó Dios á la luz Día, y á las tinieblas llamó Noche: y fué la tarde y la mañana un día. [^5] Y dijo Dios: Haya expansión en medio de las aguas, y separe las aguas de las aguas. [^6] E hizo Dios la expansión, y apartó las aguas que estaban debajo de la expansión, de las aguas que estaban sobre la expansión: y fué así. [^7] Y llamó Dios á la expansión Cielos: y fué la tarde y la mañana el día segundo. [^8] Y dijo Dios: Júntense las aguas que están debajo de los cielos en un lugar, y descúbrase la seca: y fué así. [^9] Y llamó Dios á la seca Tierra, y á la reunión de las aguas llamó Mares: y vió Dios que era bueno. [^10] Y dijo Dios: Produzca la tierra hierba verde, hierba que dé simiente; árbol de fruto que dé fruto según su género, que su simiente esté en él, sobre la tierra: y fué así. [^11] Y produjo la tierra hierba verde, hierba que da simiente según su naturaleza, y árbol que da fruto, cuya simiente está en él, según su género: y vió Dios que era bueno. [^12] Y fué la tarde y la mañana el día tercero. [^13] Y dijo Dios: Sean lumbreras en la expansión de los cielos para apartar el día y la noche: y sean por señales, y para las estaciones, y para días y años; [^14] Y sean por lumbreras en la expansión de los cielos para alumbrar sobre la tierra: y fue. [^15] E hizo Dios las dos grandes lumbreras; la lumbrera mayor para que señorease en el día, y la lumbrera menor para que señorease en la noche: hizo también las estrellas. [^16] Y púsolas Dios en la expansión de los cielos, para alumbrar sobre la tierra, [^17] Y para señorear en el día y en la noche, y para apartar la luz y las tinieblas: y vió Dios que era bueno. [^18] Y fué la tarde y la mañana el día cuarto. [^19] Y dijo Dios: Produzcan las aguas reptil de ánima viviente, y aves que vuelen sobre la tierra, en la abierta expansión de los cielos. [^20] Y crió Dios las grandes ballenas, y toda cosa viva que anda arrastrando, que las aguas produjeron según su género, y toda ave alada según su especie: y vió Dios que era bueno. [^21] Y Dios los bendijo diciendo: Fructificad y multiplicad, y henchid las aguas en los mares, y las aves se multipliquen en la tierra. [^22] Y fué la tarde y la mañana el día quinto. [^23] Y dijo Dios: Produzca la tierra seres vivientes según su género, bestias y serpientes y animales de la tierra según su especie: y fué así. [^24] E hizo Dios animales de la tierra según su género, y ganado según su género, y todo animal que anda arrastrando sobre la tierra según su especie: y vió Dios que era bueno. [^25] Y dijo Dios: Hagamos al hombre á nuestra imagen, conforme á nuestra semejanza; y señoree en los peces de la mar, y en las aves de los cielos, y en las bestias, y en toda la tierra, y en todo animal que anda arrastrando sobre la tierra. [^26] Y crió Dios al hombre á su imagen, á imagen de Dios lo crió; varón y hembra los crió. [^27] Y los bendijo Dios; y díjoles Dios: Fructificad y multiplicad, y henchid la tierra, y sojuzgadla, y señoread en los peces de la mar, y en las aves de los cielos, y en todas las bestias que se mueven sobre la tierra. [^28] Y dijo Dios: He aquí que os he dado toda hierba que da simiente, que está sobre la haz de toda la tierra; y todo árbol en que hay fruto de árbol que da simiente, seros ha para comer. [^29] Y á toda bestia de la tierra, y á todas las aves de los cielos, y á todo lo que se mueve sobre la tierra, en que hay vida, toda hierba verde les será para comer: y fué así. [^30] Y vió Dios todo lo que había hecho, y he aquí que era bueno en gran manera. Y fué la tarde y la mañana el día sexto. [^31] 

Genesis - 1 [[Genesis - 2|-->]]

---
# Notes
