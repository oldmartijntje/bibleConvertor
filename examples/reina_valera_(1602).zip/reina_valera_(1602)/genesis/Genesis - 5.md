---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 5 - Reina Valera (1602)"
---
[[Genesis - 4|<--]] Genesis - 5 [[Genesis - 6|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 5

ESTE es el libro de las generaciones de Adam. El día en que crió Dios al hombre, á la semejanza de Dios lo hizo; [^1] Varón y hembra los crió; y los bendijo, y llamó el nombre de ellos Adam, el día en que fueron criados. [^2] Y vivió Adam ciento y treinta años, y engendró un hijo á su semejanza, conforme á su imagen, y llamó su nombre Seth. [^3] Y fueron los días de Adam, después que engendró á Seth, ochocientos años: y engendró hijos é hijas. [^4] Y fueron todos los días que vivió Adam novecientos y treinta años, y murió. [^5] Y vivió Seth ciento y cinco años, y engendró á Enós. [^6] Y vivió Seth, después que engendró á Enós, ochocientos y siete años: y engendró hijos é hijas. [^7] Y fueron todos los días de Seth novecientos y doce años; y murió. [^8] Y vivió Enós noventa años, y engendró á Cainán. [^9] Y vivió Enós después que engendró á Cainán, ochocientos y quince años: y engendró hijos é hijas. [^10] Y fueron todos los días de Enós novecientos y cinco años; y murió. [^11] Y vivió Cainán setenta años, y engendró á Mahalaleel. [^12] Y vivió Cainán, después que engendró á Mahalaleel, ochocientos y cuarenta años: y engendró hijos é hijas. [^13] Y fueron todos los días de Cainán novecientos y diez años; y murió. [^14] Y vivió Mahalaleel sesenta y cinco años, y engendró á Jared. [^15] Y vivió Mahalaleel, después que engendró á Jared, ochocientos y treinta años: y engendró hijos é hijas. [^16] Y fueron todos los días de Mahalaleel ochocientos noventa y cinco años; y murió. [^17] Y vivió Jared ciento sesenta y dos años, y engendró á Henoch. [^18] Y vivió Jared, después que engendró á Henoch, ochocientos años: y engendró hijos é hijas. [^19] Y fueron todos los días de Jared novecientos sesenta y dos años; y murió. [^20] Y vivió Henoch sesenta y cinco años, y engendró á Mathusalam. [^21] Y caminó Henoch con Dios, después que engendró á Mathusalam, trescientos años: y engendró hijos é hijas. [^22] Y fueron todos los días de Henoch trescientos sesenta y cinco años. [^23] Caminó, pues, Henoch con Dios, y desapareció, porque le llevó Dios. [^24] Y vivió Mathusalam ciento ochenta y siete años, y engendró á Lamech. [^25] Y vivió Mathusalam, después que engendró á Lamech, setecientos ochenta y dos años: y engendró hijos é hijas. [^26] Fueron, pues, todos los días de Mathusalam, novecientos sesenta y nueve años; y murió. [^27] Y vivió Lamech ciento ochenta y dos años, y engendró un hijo: [^28] Y llamó su nombre Noé, diciendo: Este nos aliviará de nuestras obras, y del tabajo de nuestras manos, á causa de la tierra que Jehová maldijo. [^29] Y vivió Lamech, después que engendró á Noé, quinientos noventa y cinco años: y engendró hijos é hijas. [^30] Y fueron todos los días de Lamech setecientos setenta y siete años; y murió. [^31] Y siendo Noé de quinientos años, engendró á Sem, Châm, y á Japhet. [^32] 

[[Genesis - 4|<--]] Genesis - 5 [[Genesis - 6|-->]]

---
# Notes
