---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 12 - Reina Valera (1602)"
---
[[Genesis - 11|<--]] Genesis - 12 [[Genesis - 13|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 12

EMPERO Jehová había dicho á Abram: Vete de tu tierra y de tu parentela, y de la casa de tu padre, á la tierra que te mostraré; [^1] Y haré de ti una nación grande, y bendecirte he, y engrandeceré tu nombre, y serás bendición: [^2] Y bendeciré á los que te bendijeren, y á los que te maldijeren maldeciré: y serán benditas en ti todas las familias de la tierra. [^3] Y fuése Abram, como Jehová le dijo; y fué con él Lot: y era Abram de edad de setenta y cinco años cuando salió de Harán. [^4] Y tomó Abram á Sarai su mujer, y á Lot hijo de su hermano, y toda su hacienda que habían ganado, y las almas que habían adquirido en Harán, y salieron para ir á tierra de Canaán; y á tierra de Canaán llegaron. [^5] Y pasó Abram por aquella tierra hasta el lugar de Sichêm, hasta el valle de Moreh: y el Cananeo estaba entonces en la tierra. [^6] Y apareció Jehová á Abram, y le dijo: A tu simiente daré esta tierra. Y edificó allí un altar á Jehová, que le había aparecido. [^7] Y pasóse de allí á un monte al oriente de Bethel, y tendió su tienda, teniendo á Bethel al occidente y Hai al oriente: y edificó allí altar á Jehová é invocó el nombre de Jehová. [^8] Y movió Abram de allí, caminando y yendo hacia el Mediodía. [^9] Y hubo hambre en la tierra, y descendió Abram á Egipto para peregrinar allá; porque era grande el hambre en la tierra. [^10] Y aconteció que cuando estaba para entrar en Egipto, dijo á Sarai su mujer: He aquí, ahora conozco que eres mujer hermosa de vista; [^11] Y será que cuando te habrán visto los Egipcios, dirán: Su mujer es: y me matarán á mí, y á ti te reservarán la vida. [^12] Ahora pues, di que eres mi hermana, para que yo haya bien por causa tuya, y viva mi alma por amor de ti. [^13] Y aconteció que, como entró Abram en Egipto, los Egipcios vieron la mujer que era hermosa en gran manera. [^14] Viéronla también los príncipes de Faraón, y se la alabaron; y fué llevada la mujer á casa de Faraón: [^15] E hizo bien á Abram por causa de ella; y tuvo ovejas, y vacas, y asnos, y siervos, y criadas, y asnas y camellos. [^16] Mas Jehová hirió á Faraón y á su casa con grandes plagas, por causa de Sarai mujer de Abram. [^17] Entonces Faraón llamó á Abram y le dijo: ¿Qué es esto que has hecho conmigo? ¿Por qué no me declaraste que era tu mujer? [^18] ¿Por qué dijiste: Es mi hermana? poniéndome en ocasión de tomarla para mí por mujer? Ahora pues, he aquí tu mujer, tómala y vete. [^19] Entonces Faraón dió orden á sus gentes acerca de Abram; y le acompañaron, y á su mujer con todo lo que tenía. [^20] 

[[Genesis - 11|<--]] Genesis - 12 [[Genesis - 13|-->]]

---
# Notes
