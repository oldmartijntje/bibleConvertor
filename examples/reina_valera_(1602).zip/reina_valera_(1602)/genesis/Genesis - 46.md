---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 46 - Reina Valera (1602)"
---
[[Genesis - 45|<--]] Genesis - 46 [[Genesis - 47|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 46

Y PARTIOSE Israel con todo lo que tenía, y vino á Beer-seba, y ofreció sacrificios al Dios de su padre Isaac. [^1] Y habló Dios á Israel en visiones de noche, y dijo: Jacob, Jacob. Y él respondió: Heme aquí. [^2] Y dijo: Yo soy Dios, el Dios de tu padre; no temas de descender á Egipto, porque yo te pondré allí en gran gente. [^3] Yo descenderé contigo á Egipto, y yo también te haré volver: y José pondrá su mano sobre tus ojos. [^4] Y levantóse Jacob de Beer-seba; y tomaron los hijos de Israel á su padre Jacob, y á sus niños, y á sus mujeres, en los carros que Faraón había enviado para llevarlo. [^5] Y tomaron sus ganados, y su hacienda que había adquirido en la tierra de Canaán, y viniéronse á Egipto, Jacob, y toda su simiente consigo; [^6] Sus hijos, y los hijos de sus hijos consigo; sus hijas, y las hijas de sus hijos, y á toda su simiente trajo consigo á Egipto. [^7] Y estos son los nombres de los hijos de Israel, que entraron en Egipto, Jacob y sus hijos: Rubén, el primogénito de Jacob. [^8] Y los hijos de Rubén: Hanoch, y Phallu, y Hezrón, y Carmi. [^9] Y los hijos de Simeón: Jemuel, y Jamín, y Ohad, y Jachîn, y Zohar, y Saúl, hijo de la Cananea. [^10] Y los hijos de Leví: Gersón, Coath, y Merari. [^11] Y los hijos de Judá: Er, y Onán, y Sela, y Phares, y Zara: mas Er y Onán, murieron en la tierra de Canaán. Y los hijos de Phares fueron Hezrón y Hamul. [^12] Y los hijos de Issachâr: Thola, y Phua, y Job, y Simrón. [^13] Y los hijos de Zabulón: Sered y Elón, y Jahleel. [^14] Estos fueron los hijos de Lea, los que parió á Jacob en Padan-aram, y además su hija Dina: treinta y tres las almas todas de sus hijos é hijas. [^15] Y los hijos de Gad: Ziphión, y Aggi, y Ezbón, y Suni, y Heri, y Arodi, y Areli. [^16] Y los hijos de Aser: Jimna, é Ishua, é Isui y Beria, y Sera, hermana de ellos. Los hijos de Beria: Heber, y Malchîel. [^17] Estos fueron los hijos de Zilpa, la que Labán dió á su hija Lea, y parió estos á Jacob; todas diez y seis almas. [^18] Y los hijos de Rachêl, mujer de Jacob: José y Benjamín. [^19] Y nacieron á José en la tierra de Egipto Manasés y Ephraim, los que le parió Asenath, hija de Potipherah, sacerdote de On. [^20] Y los hijos de Benjamín fueron Bela, y Bechêr y Asbel, y Gera, y Naamán, y Ehi, y Ros y Muppim, y Huppim, y Ard. [^21] Estos fueron los hijos de Rachêl, que nacieron á Jacob: en todas, catorce almas. [^22] Y los hijos de Dan: Husim. [^23] Y los hijos de Nephtalí: Jahzeel, y Guni, y Jezer, y Shillem. [^24] Estos fueron los hijos de Bilha, la que dió Labán á Rachêl su hija, y parió estos á Jacob; todas siete almas. [^25] Todas las personas que vinieron con Jacob á Egipto, procedentes de sus lomos, sin las mujeres de los hijos de Jacob, todas las personas fueron sesenta y seis. [^26] Y los hijos de José, que le nacieron en Egipto, dos personas. Todas las almas de la casa de Jacob, que entraron en Egipto, fueron setenta. [^27] Y envió á Judá delante de sí á José, para que le viniese á ver á Gosén; y llegaron á la tierra de Gosén. [^28] Y José unció su carro y vino á recibir á Israel su padre á Gosén; y se manifestó á él, y echóse sobre su cuello, y lloró sobre su cuello bastante. [^29] Entonces Israel dijo á José: Muera yo ahora, ya que he visto tu rostro, pues aun vives. [^30] Y José dijo á sus hermanos, y á la casa de su padre: Subiré y haré saber á Faraón, y diréle: Mis hermanos y la casa de mi padre, que estaban en la tierra de Canaán, han venido á mí; [^31] Y los hombres son pastores de ovejas, porque son hombres ganaderos: y han traído sus ovejas y sus vacas, y todo lo que tenían. [^32] Y cuando Faraón os llamare y dijere: ¿cuál es vuestro oficio? [^33] Entonces diréis: Hombres de ganadería han sido tus siervos desde nuestra mocedad hasta ahora, nosotros y nuestros padres; á fin que moréis en la tierra de Gosén, porque los Egipcios abominan todo pastor de ovejas. [^34] 

[[Genesis - 45|<--]] Genesis - 46 [[Genesis - 47|-->]]

---
# Notes
