---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 9 - Reina Valera (1602)"
---
[[Genesis - 8|<--]] Genesis - 9 [[Genesis - 10|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 9

Y BENDIJO Dios á Noé y á sus hijos, y díjoles: Fructificad, y multiplicad, y henchid la tierra: [^1] Y vuestro temor y vuestro pavor será sobre todo animal de la tierra, y sobre toda ave de los cielos, en todo lo que se moverá en la tierra, y en todos los peces del mar: en vuestra mano son entregados. [^2] Todo lo que se mueve y vive, os será para mantenimiento: así como las legumbres y hierbas, os lo he dado todo. [^3] Empero carne con su vida, que es su sangre, no comeréis. [^4] Porque ciertamente demandaré la sangre de vuestras vidas; de mano de todo animal la demandaré, y de mano del hombre; de mano del varón su hermano demandaré la vida del hombre. [^5] El que derramare sangre del hombre, por el hombre su sangre será derramada; porque á imagen de Dios es hecho el hombre. [^6] Mas vosotros fructificad, y multiplicaos; procread abundantemente en la tierra, y multiplicaos en ella. [^7] Y habló Dios á Noé y á sus hijos con él, diciendo: [^8] Yo, he aquí que yo establezco mi pacto con vosotros, y con vuestra simiente después de vosotros; [^9] Y con toda alma viviente que está con vosotros, de aves, de animales, y de toda bestia de la tierra que está con vosotros; desde todos los que salieron del arca hasta todo animal de la tierra. [^10] Estableceré mi pacto con vosotros, y no fenecerá ya más toda carne con aguas de diluvio; ni habrá más diluvio para destruir la tierra. [^11] Y dijo Dios: Esta será la señal del pacto que yo establezco entre mí y vosotros y toda alma viviente que está con vosotros, por siglos perpetuos: [^12] Mi arco pondré en las nubes, el cual será por señal de convenio entre mí y la tierra. [^13] Y será que cuando haré venir nubes sobre la tierra, se dejará ver entonces mi arco en las nubes. [^14] Y acordarme he del pacto mío, que hay entre mí y vosotros y toda alma viviente de toda carne; y no serán más las aguas por diluvio para destruir toda carne. [^15] Y estará el arco en las nubes, y verlo he para acordarme del pacto perpetuo entre Dios y toda alma viviente, con toda carne que hay sobre la tierra. [^16] Dijo, pues, Dios á Noé: Esta será la señal del pacto que he establecido entre mí y toda carne que está sobre la tierra. [^17] Y los hijos de Noé que salieron del arca fueron Sem, Châm y Japhet: y Châm es el padre de Canaán. [^18] Estos tres son los hijos de Noé; y de ellos fué llena toda la tierra. [^19] Y comenzó Noé á labrar la tierra, y plantó una viña: [^20] Y bebió del vino, y se embriagó, y estaba descubierto en medio de su tienda. [^21] Y Châm, padre de Canaán, vió la desnudez de su padre, y díjolo á sus dos hermanos á la parte de afuera. [^22] Entonces Sem y Japhet tomaron la ropa, y la pusieron sobre sus propios hombros, y andando hacia atrás, cubrieron la desnudez de su padre teniendo vueltos sus rostros, y así no vieron la desnudez de su padre. [^23] Y despertó Noé de su vino, y supo lo que había hecho con él su hijo el más joven; [^24] Y dijo: Maldito sea Canaán; Siervo de siervos será á sus hermanos. [^25] Dijo más: Bendito Jehová el Dios de Sem, Y séale Canaán siervo. [^26] Engrandezca Dios á Japhet, Y habite en las tiendas de Sem, Y séale Canaán siervo. [^27] Y vivió Noé después del diluvio trescientos y cincuenta años. [^28] Y fueron todos los días de Noé novecientos y cincuenta años; y murió. [^29] 

[[Genesis - 8|<--]] Genesis - 9 [[Genesis - 10|-->]]

---
# Notes
