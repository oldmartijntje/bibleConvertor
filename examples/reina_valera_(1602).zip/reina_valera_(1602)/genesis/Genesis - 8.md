---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 8 - Reina Valera (1602)"
---
[[Genesis - 7|<--]] Genesis - 8 [[Genesis - 9|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 8

Y ACORDOSE Dios de Noé, y de todos los animales, y de todas las bestias que estaban con él en el arca; é hizo pasar Dios un viento sobre la tierra, y disminuyeron las aguas. [^1] Y se cerraron las fuentes del abismo, y las cataratas de los cielos; y la lluvia de los cielos fué detenida. [^2] Y tornáronse las aguas de sobre la tierra, yendo y volviendo: y decrecieron las aguas al cabo de ciento y cincuenta días. [^3] Y reposó el arca en el mes séptimo, á dicisiete días del mes, sobre los montes de Armenia. [^4] Y las aguas fueron decreciendo hasta el mes décimo: en el décimo, al primero del mes, se descubrieron las cimas de los montes. [^5] Y sucedió que, al cabo de cuarenta días, abrió Noé la ventana del arca que había hecho, [^6] Y envió al cuervo, el cual salió, y estuvo yendo y tornando hasta que las aguas se secaron de sobre la tierra. [^7] Envió también de sí á la paloma, para ver si las aguas se habían retirado de sobre la faz de la tierra; [^8] Y no halló la paloma donde sentar la planta de su pie, y volvióse á él al arca, porque las aguas estaban aún sobre la faz de toda la tierra: entonces él extendió su mano y cogiéndola, hízola entrar consigo en el arca. [^9] Y esperó aún otros siete días, y volvió á enviar la paloma fuera del arca. [^10] Y la paloma volvió á él á la hora de la tarde: y he aquí que traía una hoja de oliva tomada en su pico: y entendió Noé que las aguas se habían retirado de sobre la tierra. [^11] Y esperó aún otros siete días, y envió la paloma, la cual no volvió ya más á él. [^12] Y sucedió que en el año seiscientos y uno de Noé, en el mes primero, al primero del mes, las aguas se enjugaron de sobre la tierra y quitó Noé la cubierta del arca, y miró, y he aquí que la faz de la tierra estaba enjuta. [^13] Y en el mes segundo, á los veintisiete días del mes, se secó la tierra. [^14] Y habló Dios á Noé diciendo: [^15] Sal del arca tú, y tu mujer, y tus hijos, y las mujeres de tus hijos contigo. [^16] Todos los animales que están contigo de toda carne, de aves y de bestias y de todo reptil que anda arrastrando sobre la tierra, sacarás contigo; y vayan por la tierra, y fructifiquen, y multiplíquense sobre la tierra. [^17] Entonces salió Noé, y sus hijos, y su mujer, y las mujeres de sus hijos con él. [^18] Todos los animales, y todo reptil y toda ave, todo lo que se mueve sobre la tierra según sus especies, salieron del arca. [^19] Y edificó Noé un altar á Jehová y tomó de todo animal limpio y de toda ave limpia, y ofreció holocausto en el altar. [^20] Y percibió Jehová olor de suavidad; y dijo Jehová en su corazón: No tornaré más á maldecir la tierra por causa del hombre; porque el intento del corazón del hombre es malo desde su juventud: ni volveré más á destruir todo viviente, como he hecho. [^21] Todavía serán todos los tiempos de la tierra; la sementera y la siega, y el frío y calor, verano é invierno, y día y noche, no cesarán. [^22] 

[[Genesis - 7|<--]] Genesis - 8 [[Genesis - 9|-->]]

---
# Notes
