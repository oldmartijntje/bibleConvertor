---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 11 - Reina Valera (1602)"
---
[[Genesis - 10|<--]] Genesis - 11 [[Genesis - 12|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 11

ERA entonces toda la tierra de una lengua y unas mismas palabras. [^1] Y aconteció que, como se partieron de oriente, hallaron una vega en la tierra de Shinar, y asentaron allí. [^2] Y dijeron los unos á los otros: Vaya, hagamos ladrillo y cozámoslo con fuego. Y fuéles el ladrillo en lugar de piedra, y el betún en lugar de mezcla. [^3] Y dijeron: Vamos, edifiquémonos una ciudad y una torre, cuya cúspide llegue al cielo; y hagámonos un nombre, por si fuéremos esparcidos sobre la faz de toda la tierra. [^4] Y descendió Jehová para ver la ciudad y la torre que edificaban los hijos de los hombres. [^5] Y dijo Jehová: He aquí el pueblo es uno, y todos éstos tienen un lenguaje: y han comenzado á obrar, y nada les retraerá ahora de lo que han pensando hacer. [^6] Ahora pues, descendamos, y confundamos allí sus lenguas, para que ninguno entienda el habla de su compañero. [^7] Así los esparció Jehová desde allí sobre la faz de toda la tierra, y dejaron de edificar la ciudad. [^8] Por esto fué llamado el nombre de ella Babel, porque allí confudió Jehová el lenguaje de toda la tierra, y desde allí los esparció sobre la faz de toda la tierra. [^9] Estas son las generaciones de Sem: Sem, de edad de cien años, engendró á Arphaxad, dos años después del diluvio. [^10] Y vivió Sem, después que engendró á Arphaxad quinientos años, y engendró hijos é hijas. [^11] Y Arphaxad vivió treinta y cinco años, y engendró á Sala. [^12] Y vivió Arphaxad, después que engendró á Sala, cuatrocientos y tres años, y engendró hijos é hijas. [^13] Y vivió Sala treinta años, y engendró á Heber. [^14] Y vivió Sala, después que engendró á Heber, cuatrocientos y tres años, y engendró hijos é hijas. [^15] Y vivió Heber treinta y cuatro años, y engendró á Peleg. [^16] Y vivió Heber, después que engendró á Peleg, cuatrocientos y treinta años, y engendró hijos é hijas. [^17] Y vivió Peleg, treinta años, y engendró á Reu. [^18] Y vivió Peleg, después que engendró á Reu, doscientos y nueve años, y engendró hijos é hijas. [^19] Y Reu vivió treinta y dos años, y engendró á Serug. [^20] Y vivió Reu, después que engendró á Serug, doscientos y siete años, y engendró hijos é hijas. [^21] Y vivió Serug treinta años, y engendró á Nachôr. [^22] Y vivió Serug, después que engendró á Nachôr, doscientos años, y engendró hijos é hijas. [^23] Y vivió Nachôr veintinueve años, y engendró á Thare. [^24] Y vivió Nachôr, después que engendró á Thare, ciento diecinueve años, y engendró hijos é hijas. [^25] Y vivió Thare setenta años, y engendró á Abram, y á Nachôr, y á Harán. [^26] Estas son las generaciones de Thare: Thare engendró á Abram, y á Nachôr, y á Harán; y Harán engendró á Lot. [^27] Y murió Harán antes que su padre Thare en la tierra de su naturaleza, en Ur de los Caldeos. [^28] Y tomaron Abram y Nachôr para sí mujeres: el nombre de la mujer de Abram fué Sarai, y el nombre de la mujer de Nachôr, Milca, hija de Harán, padre de Milca y de Isca. [^29] Mas Sarai fué esteril, y no tenía hijo. [^30] Y tomó Thare á Abram su hijo, y á Lot hijo de Harán, hijo de su hijo, y á Sarai su nuera, mujer de Abram su hijo: y salió con ellos de Ur de los Caldeos, para ir á la tierra de Canaán: y vinieron hasta Harán, y asentaron allí. [^31] Y fueron los días de Thare doscientos y cinco años; y murió Thare en Harán. [^32] 

[[Genesis - 10|<--]] Genesis - 11 [[Genesis - 12|-->]]

---
# Notes
