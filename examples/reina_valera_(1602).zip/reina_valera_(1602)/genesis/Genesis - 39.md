---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 39 - Reina Valera (1602)"
---
[[Genesis - 38|<--]] Genesis - 39 [[Genesis - 40|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 39

Y LLEVADO José á Egipto, comprólo Potiphar, eunuco de Faraón, capitán de los de la guardia, varón Egipcio, de mano de los Ismaelitas que lo habían llevado allá. [^1] Mas Jehová fué con José, y fué varón prosperado: y estaba en la casa de su señor el Egipcio. [^2] Y vió su señor que Jehová era con él, y que todo lo que él hacía, Jehová lo hacía prosperar en su mano. [^3] Así halló José gracia en sus ojos, y servíale; y él le hizo mayordomo de su casa, y entregó en su poder todo lo que tenía. [^4] Y aconteció que, desde cuando le dió el encargo de su casa, y de todo lo que tenía, Jehová bendijo la casa del Egipcio á causa de José; y la bendición de Jehová fué sobre todo lo que tenía, así en casa como en el campo. [^5] Y dejó todo lo que tenía en mano de José; ni con él sabía de nada más que del pan que comía. Y era José de hermoso semblante y bella presencia. [^6] Y aconteció después de esto, que la mujer de su señor puso sus ojos en José, y dijo: Duerme conmigo. [^7] Y él no quiso, y dijo á la mujer de su señor: He aquí que mi señor no sabe conmigo lo que hay en casa, y ha puesto en mi mano todo lo que tiene: [^8] No hay otro mayor que yo en esta casa, y ninguna cosa me ha reservado sino á ti, por cuanto tú eres su mujer; ¿cómo, pues, haría yo este grande mal y pecaría contra Dios? [^9] Y fué que hablando ella á José cada día, y no escuchándola él para acostarse al lado de ella, para estar con ella. [^10] Aconteció que entró él un día en casa para hacer su oficio, y no había nadie de los de casa allí en casa. [^11] Y asiólo ella por su ropa, diciendo: Duerme conmigo. Entonces dejóla él su ropa en las manos, y huyó, y salióse fuera. [^12] Y acaeció que cuando vió ella que le había dejado su ropa en sus manos, y había huído fuera, [^13] Llamó á los de casa, y hablóles diciendo: Mirad, nos ha traído un Hebreo, para que hiciese burla de nosotros: vino él á mí para dormir conmigo, y yo dí grandes voces; [^14] Y viendo que yo alzaba la voz y gritaba, dejó junto á mí su ropa, y huyó, y salióse fuera. [^15] Y ella puso junto á sí la ropa de él, hasta que vino su señor á su casa. [^16] Entonces le habló ella semejantes palabras, diciendo: El siervo Hebreo que nos trajiste, vino á mí para deshonrarme; [^17] Y como yo alcé mi voz y grite, él dejó su ropa junto á mí, y huyó fuera. [^18] Y sucedió que como oyó su señor las palabras que su mujer le hablara, diciendo: Así me ha tratado tu siervo; encendióse su furor. [^19] Y tomó su señor á José, y púsole en la casa de la cárcel, donde estaban los presos del rey, y estuvo allí en la casa de la cárcel. [^20] Mas Jehová fué con José, y extendió á él su misericordia, y dióle gracia en ojos del principal de la casa de la cárcel. [^21] Y el principal de la casa de la cárcel entregó en mano de José todos los presos que había en aquella prisión; todo lo que hacían allí, él lo hacía. [^22] No veía el principal de la cárcel cosa alguna que en su mano estaba; porque Jehová era con él, y lo que él hacía, Jehová lo prosperaba. [^23] 

[[Genesis - 38|<--]] Genesis - 39 [[Genesis - 40|-->]]

---
# Notes
