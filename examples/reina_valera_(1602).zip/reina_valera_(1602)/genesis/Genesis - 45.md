---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 45 - Reina Valera (1602)"
---
[[Genesis - 44|<--]] Genesis - 45 [[Genesis - 46|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 45

NO podía ya José contenerse delante de todos los que estaban al lado suyo, y clamó: Haced salir de conmigo á todos. Y no quedó nadie con él, al darse á conocer José á sus hermanos. [^1] Entonces se dió á llorar á voz en grito; y oyeron los Egipcios, y oyó también la casa de Faraón. [^2] Y dijo José á sus hermanos: Yo soy José: ¿vive aún mi padre? Y sus hermanos no pudieron responderle, porque estaban turbados delante de él. [^3] Entonces dijo José á sus hermanos: Llegaos ahora á mí. Y ellos se llegaron. Y él dijo: Yo soy José vuestro hermano el que vendisteis para Egipto. [^4] Ahora pues, no os entristezcáis, ni os pese de haberme vendido acá; que para preservación de vida me envió Dios delante de vosotros: [^5] Que ya ha habido dos años de hambre en medio de la tierra, y aun quedan cinco años en que ni habrá arada ni siega. [^6] Y Dios me envió delante de vosotros, para que vosotros quedaseis en la tierra, y para daros vida por medio de grande salvamento. [^7] Así pues, no me enviasteis vosotros acá, sino Dios, que me ha puesto por padre de Faraón, y por señor de toda su casa, y por gobernador en toda la tierra de Egipto. [^8] Daos priesa, id á mi padre y decidle: Así dice tu hijo José: Dios me ha puesto por señor de todo Egipto; ven á mí, no te detengas: [^9] Y habitarás en la tierra de Gosén, y estarás cerca de mí, tú y tus hijos, y los hijos de tus hijos, tus ganados y tus vacas, y todo lo que tienes. [^10] Y allí te alimentaré, pues aun quedan cinco años de hambre, porque no perezcas de pobreza tú y tu casa, y todo lo que tienes: [^11] Y he aquí, vuestros ojos ven, y los ojos de mi hermano Benjamín, que mi boca os habla. [^12] Haréis pues saber á mi padre toda mi gloria en Egipto, y todo lo que habéis visto: y daos priesa, y traed á mi padre acá. [^13] Y echóse sobre el cuello de Benjamín su hermano, y lloró; y también Benjamín lloró sobre su cuello. [^14] Y besó á todos sus hermanos, y lloró sobre ellos: y después sus hermanos hablaron con él. [^15] Y oyóse la noticia en la casa de Faraón, diciendo: Los hermanos de José han venido. Y plugo en los ojos de Faraón y de sus siervos. [^16] Y dijo Faraón á José: Di á tus hermanos: Haced esto: cargad vuestras bestias, é id, volved á la tierra de Canaán; [^17] Y tomad á vuestro padre y vuestras familias, y venid á mí, que yo os daré lo bueno de la tierra de Egipto y comeréis la grosura de la tierra. [^18] Y tú manda: Haced esto: tomaos de la tierra de Egipto carros para vuestros niños y vuestras mujeres; y tomad á vuestro padre, y venid. [^19] Y no se os dé nada de vuestras alhajas, porque el bien de la tierra de Egipto será vuestro. [^20] E hiciéronlo así los hijos de Israel: y dióles José carros conforme á la orden de Faraón, y suministróles víveres para el camino. [^21] A cada uno de todos ellos dió mudas de vestidos, y á Benjamín dió trescientas piezas de plata, y cinco mudas de vestidos. [^22] Y á su padre envió esto: diez asnos cargados de lo mejor de Egipto, y diez asnas cargadas de trigo, y pan y comida, para su padre en el camino. [^23] Y despidió á sus hermanos, y fuéronse. Y él les dijo: No riñáis por el camino. [^24] Y subieron de Egipto, y llegaron á la tierra de Canaán á Jacob su padre. [^25] Y diéronle las nuevas, diciendo: José vive aún; y él es señor en toda la tierra de Egipto. Y su corazón se desmayó; pues no los creía. [^26] Y ellos le contaron todas las palabras de José, que él les había hablado; y viendo él los carros que José enviaba para llevarlo, el espíritu de Jacob su padre revivió. [^27] Entonces dijo Israel: Basta; José mi hijo vive todavía: iré, y le veré antes que yo muera. [^28] 

[[Genesis - 44|<--]] Genesis - 45 [[Genesis - 46|-->]]

---
# Notes
