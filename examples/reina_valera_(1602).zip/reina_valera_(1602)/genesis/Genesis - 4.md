---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 4 - Reina Valera (1602)"
---
[[Genesis - 3|<--]] Genesis - 4 [[Genesis - 5|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 4

Y CONOCIO Adam á su mujer Eva, la cual concibió y parió á Caín, y dijo: Adquirido he varón por Jehová. [^1] Y después parió á su hermano Abel. Y fué Abel pastor de ovejas, y Caín fué labrador de la tierra. [^2] Y aconteció andando el tiempo, que Caín trajo del fruto de la tierra una ofrenda á Jehová. [^3] Y Abel trajo también de los primogénitos de sus ovejas, y de su grosura. Y miró Jehová con agrado á Abel y á su ofrenda; [^4] Mas no miró propicio á Caín y á la ofrenda suya. Y ensañóse Caín en gran manera, y decayó su semblante. [^5] Entonces Jehová dijo á Caín: ¿Por qué te has ensañado, y por qué se ha inmutado tu rostro? [^6] Si bien hicieres, ¿no serás ensalzado? y si no hicieres bien, el pecado está á la puerta: con todo esto, á ti será su deseo, y tú te enseñorearás de él. [^7] Y habló Caín á su hermano Abel: y aconteció que estando ellos en el campo, Caín se levantó contra su hermano Abel, y le mató. [^8] Y Jehová dijo á Caín: ¿Dónde está Abel tu hermano? Y él respondió: No sé; ¿soy yo guarda de mi hermano? [^9] Y él le dijo: ¿Qué has hecho? La voz de la sangre de tu hermano clama á mí desde la tierra. [^10] Ahora pues, maldito seas tú de la tierra que abrió su boca para recibir la sangre de tu hermano de tu mano: [^11] Cuando labrares la tierra, no te volverá á dar su fuerza: errante y extranjero serás en la tierra. [^12] Y dijo Caín á Jehová: Grande es mi iniquidad para ser perdonada. [^13] He aquí me echas hoy de la faz de la tierra, y de tu presencia me esconderé; y seré errante y extranjero en la tierra; y sucederá que cualquiera que me hallare, me matará. [^14] Y respondióle Jehová: Cierto que cualquiera que matare á Caín, siete veces será castigado. Entonces Jehová puso señal en Caín, para que no lo hiriese cualquiera que le hallara. [^15] Y salió Caín de delante de Jehová, y habitó en tierra de Nod, al oriente de Edén. [^16] Y conoció Caín á su mujer, la cual concibió y parió á Henoch: y edificó una ciudad, y llamó el nombre de la ciudad del nombre de su hijo, Henoch. [^17] Y á Henoch nació Irad, é Irad engendró á Mehujael, y Mehujael engendró á Methusael, y Methusael engendró á Lamech. [^18] Y tomó para sí Lamech dos mujeres; el nombre de la una fué Ada, y el nombre de la otra Zilla. [^19] Y Ada parió á Jabal, el cual fué padre de los que habitan en tiendas, y crían ganados. [^20] Y el nombre de su hermano fué Jubal, el cual fué padre de todos los que manejan arpa y órgano. [^21] Y Zilla también parió á Tubal-Caín, acicalador de toda obra de metal y de hierro: y la hermana de Tubal-Caín fué Naama. [^22] Y dijo Lamech á sus mujeres: Ada y Zilla, oid mi voz; Mujeres de Lamech, escuchad mi dicho: Que varón mataré por mi herida, Y mancebo por mi golpe: [^23] Si siete veces será vengado Caín, Lamech en verdad setenta veces siete lo será. [^24] Y conoció de nuevo Adam á su mujer, la cual parió un hijo, y llamó su nombre Seth: Porque Dios (dijo ella) me ha sustituído otra simiente en lugar de Abel, á quien mató Caín. [^25] Y á Seth también le nació un hijo, y llamó su nombre Enós. Entonces los hombres comenzaron á llamarse del nombre de Jehová. [^26] 

[[Genesis - 3|<--]] Genesis - 4 [[Genesis - 5|-->]]

---
# Notes
