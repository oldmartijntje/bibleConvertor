---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 6 - Reina Valera (1602)"
---
[[Genesis - 5|<--]] Genesis - 6 [[Genesis - 7|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Genesis]]

# Genesis - 6

Y ACAECIO que, cuando comenzaron los hombres á multiplicarse sobre la faz de la tierra, y les nacieron hijas, [^1] Viendo los hijos de Dios que las hijas de los hombres eran hermosas, tomáronse mujeres, escogiendo entre todas. [^2] Y dijo Jehová: No contenderá mi espíritu con el hombre para siempre, porque ciertamente él es carne: mas serán sus días ciento y veinte años. [^3] Había gigantes en la tierra en aquellos días, y también después que entraron los hijos de Dios á las hijas de los hombres, y les engendraron hijos: éstos fueron los valientes que desde la antigüedad fueron varones de nombre. [^4] Y vió Jehová que la malicia de los hombres era mucha en la tierra, y que todo designio de los pensamientos del corazón de ellos era de continuo solamente el mal. [^5] Y arrepintióse Jehová de haber hecho hombre en la tierra, y pesóle en su corazón. [^6] Y dijo Jehová: Raeré los hombres que he criado de sobre la faz de la tierra, desde el hombre hasta la bestia, y hasta el reptil y las aves del cielo: porque me arrepiento de haberlos hecho. [^7] Empero Noé halló gracia en los ojos de Jehová. [^8] Estas son las generaciones de Noé: Noé, varón justo, perfecto fué en sus generaciones; con Dios caminó Noé. [^9] Y engendró Noé tres hijos: á Sem, á Châm, y á Japhet. [^10] Y corrompióse la tierra delante de Dios, y estaba la tierra llena de violencia. [^11] Y miró Dios la tierra, y he aquí que estaba corrompida; porque toda carne había corrompido su camino sobre la tierra. [^12] Y dijo Dios á Noé: El fin de toda carne ha venido delante de mí; porque la tierra está llena de violencia á causa de ellos; y he aquí que yo los destruiré con la tierra. [^13] Hazte un arca de madera de Gopher: harás aposentos en el arca y la embetunarás con brea por dentro y por fuera. [^14] Y de esta manera la harás: de trescientos codos la longitud del arca, de cincuenta codos su anchura, y de treinta codos su altura. [^15] Una ventana harás al arca, y la acabarás á un codo de elevación por la parte de arriba: y pondrás la puerta del arca á su lado; y le harás piso bajo, segundo y tercero. [^16] Y yo, he aquí que yo traigo un diluvio de aguas sobre la tierra, para destruir toda carne en que haya espíritu de vida debajo del cielo; todo lo que hay en la tierra morirá. [^17] Mas estableceré mi pacto contigo, y entrarás en el arca tú, y tus hijos y tu mujer, y las mujeres de tus hijos contigo. [^18] Y de todo lo que vive, de toda carne, dos de cada especie meterás en el arca, para que tengan vida contigo; macho y hembra serán. [^19] De las aves según su especie, y de las bestias según su especie, de todo reptil de la tierra según su especie, dos de cada especie entrarán contigo para que hayan vida. [^20] Y toma contigo de toda vianda que se come, y allégala á ti; servirá de alimento para ti y para ellos. [^21] E hízolo así Noé; hizo conforme á todo lo que Dios le mandó. [^22] 

[[Genesis - 5|<--]] Genesis - 6 [[Genesis - 7|-->]]

---
# Notes
