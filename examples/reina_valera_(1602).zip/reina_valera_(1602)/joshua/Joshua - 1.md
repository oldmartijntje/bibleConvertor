---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 1 - Reina Valera (1602)"
---
Joshua - 1 [[Joshua - 2|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Joshua]]

# Joshua - 1

Y ACONTECIO después de la muerte de Moisés siervo de Jehová, que Jehová habló á Josué hijo de Nun, ministro de Moisés, diciendo: [^1] Mi siervo Moisés es muerto: levántate pues ahora, y pasa este Jordán, tú y todo este pueblo, á la tierra que yo les doy á los hijos de Israel. [^2] Yo os he entregado, como lo había dicho á Moisés, todo lugar que pisare la planta de vuestro pie. [^3] Desde el desierto y este Líbano hasta el gran río Eufrates, toda la tierra de los Hetheos hasta la gran mar del poniente del sol, será vuestro término. [^4] Nadie te podrá hacer frente en todos los días de tu vida: como yo fuí con Moisés, seré contigo; no te dejaré, ni te desampararé. [^5] Esfuérzate y sé valiente: porque tú repartirás á este pueblo por heredad la tierra, de la cual juré á sus padres que la daría á ellos. [^6] Solamente te esfuerces, y seas muy valiente, para cuidar de hacer conforme á toda la ley que mi siervo Moisés te mandó: no te apartes de ella ni á diestra ni á siniestra, para que seas prosperado en todas las cosas que emprendieres. [^7] El libro de aquesta ley nunca se apartará de tu boca: antes de día y de noche meditarás en él, para que guardes y hagas conforme á todo lo que en él está escrito: porque entonces harás prosperar tu camino, y todo te saldrá bien. [^8] Mira que te mando que te esfuerces y seas valiente: no temas ni desmayes, porque Jehová tu Dios será contigo en donde quiera que fueres. [^9] Y Josué mandó á los oficiales del pueblo, diciendo: [^10] Pasad por medio del campo, y mandad al pueblo, diciendo: Preveníos de comida; porque dentro de tres días pasaréis el Jordán, para que entréis á poseer la tierra que Jehová vuestro Dios os da para que la poseáis. [^11] También habló Josué á los Rubenitas y Gaditas, y á la media tribu de Manasés, diciendo: [^12] Acordaos de la palabra que Moisés, siervo de Jehová, os mandó diciendo: Jehová vuestro Dios os ha dado reposo, y os ha dado esta tierra. [^13] Vuestras mujeres y vuestros niños y vuestras bestias, quedarán en la tierra que Moisés os ha dado de esta parte del Jordán; mas vosotros, todos los valientes y fuertes, pasaréis armados delante de vuestros hermanos, y les ayudaréis; [^14] Hasta tanto que Jehová haya dado reposo á vuestros hermanos como á vosotros, y que ellos también posean la tierra que Jehová vuestro Dios les da: y después volveréis vosotros á la tierra de vuestra herencia, la cual Moisés siervo de Jehová os ha dado, de esta parte del Jordán hacia donde nace el sol; y la poseeréis. [^15] Entonces respondieron á Josué, diciendo: Nosotros haremos todas las cosas que nos has mandado, é iremos adonde quiera que nos mandares. [^16] De la manera que obedecimos á Moisés en todas las cosas, así te obedeceremos á ti: solamente Jehová tu Dios sea contigo, como fué con Moisés. [^17] Cualquiera que fuere rebelde á tu mandamiento, y no obedeciere á tus palabras en todas las cosas que le mandares, que muera; solamente que te esfuerces, y seas valiente. [^18] 

Joshua - 1 [[Joshua - 2|-->]]

---
# Notes
