---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 16 - Reina Valera (1602)"
---
[[Joshua - 15|<--]] Joshua - 16 [[Joshua - 17|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Joshua]]

# Joshua - 16

Y LA suerte del los hijos de José salió desde el Jordán de Jericó hasta las aguas de Jericó hacia el oriente, al desierto que sube de Jericó al monte de Beth-el: [^1] Y de Beth-el sale á Luz, y pasa al término de Archi en Ataroth; [^2] Y torna á descender hacia la mar al término de Japhlet, hasta el término de Beth-oron la de abajo, y hasta Gezer; y sale á la mar. [^3] Recibieron pues heredad los hijos de José, Manasés y Ephraim. [^4] Y fué el término de los hijos de Ephraim por sus familias, fué el término de su herencia á la parte oriental, desde Ataroth-addar hasta Beth-oron la de arriba: [^5] Y sale este término á la mar, y á Michmetat al norte, y da vuelta este término hacia el oriente á Tanath-silo, y de aquí pasa al oriente á Janoa: [^6] Y de Janoa desciende á Ataroth, y á Naaratha, y toca en Jericó, y sale al Jordán. [^7] Y de Tappua torna este término hacia la mar al arroyo de Cana, y sale á la mar. Esta es la heredad de la tribu de los hijos de Ephraim por sus familias. [^8] Hubo también ciudades que se apartaron para los hijos de Ephraim en medio de la herencia de los hijos de Manasés, todas ciudades con sus aldeas. [^9] Y no echaron al Cananeo que habitaba en Gezer; antes quedó el Cananeo en medio de Ephraim, hasta hoy, y fué tributario. [^10] 

[[Joshua - 15|<--]] Joshua - 16 [[Joshua - 17|-->]]

---
# Notes
