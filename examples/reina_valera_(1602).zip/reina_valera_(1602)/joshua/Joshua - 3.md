---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 3 - Reina Valera (1602)"
---
[[Joshua - 2|<--]] Joshua - 3 [[Joshua - 4|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Joshua]]

# Joshua - 3

Y LEVANTOSE Josué de mañana, y partieron de Sittim, y vinieron hasta el Jordán, él y todos los hijos de Israel, y reposaron allí antes que pasasen. [^1] Y pasados tres días, los oficiales atravesaron por medio del campo, [^2] Y mandaron al pueblo, diciendo: Cuando viereis el arca del pacto de Jehová vuestro Dios, y los sacerdotes y Levitas que la llevan, vosotros partiréis de vuestro lugar, y marcharéis en pos de ella. [^3] Empero entre vosotros y ella haya distancia como de la medida de dos mil codos: y no os acercaréis á ella, á fin de que sepáis el camino por donde habéis de ir: por cuanto vosotros no habéis pasado antes de ahora por este camino. [^4] Y Josué dijo al pueblo: Santificaos, porque Jehová hará mañana entre vosotros maravillas. [^5] Y habló Josué á los sacerdotes, diciendo: Tomad el arca del pacto, y pasad delante del pueblo. Y ellos tomaron el arca del pacto, y fueron delante del pueblo. [^6] Entonces Jehová dijo á Josué: Desde aqueste día comenzaré á hacerte grande delante de los ojos de todo Israel, para que entiendan que como fuí con Moisés, así seré contigo. [^7] Tú, pues, mandarás á los sacerdotes que llevan el arca del pacto, diciendo: Cuando hubiereis entrado hasta el borde del agua del Jordán, pararéis en el Jordán. [^8] Y Josué dijo á los hijos de Israel: Llegaos acá, y escuchad las palabras de Jehová vuestro Dios. [^9] Y añadió Josué: En esto conoceréis que el Dios viviente está en medio de vosotros, y que él echará de delante de vosotros al Cananeo, y al Heteo, y al Heveo, y al Pherezeo, y al Gergeseo, y al Amorrheo, y al Jebuseo. [^10] He aquí, el arca del pacto del Señoreador de toda la tierra pasa el Jordán delante de vosotros. [^11] Tomad, pues, ahora doce hombres de las tribus de Israel, de cada tribu uno. [^12] Y cuando las plantas de los pies de los sacerdotes que llevan el arca de Jehová Señoreador de toda la tierra, fueren asentadas sobre las aguas del Jordán, las aguas del Jordán se partirán: porque las aguas que vienen de arriba se detendrán en un montón. [^13] Y aconteció, que partiendo el pueblo de sus tiendas para pasar el Jordán, y los sacerdotes delante del pueblo llevando el arca del pacto, [^14] Cuando los que llevaban el arca entraron en el Jordán, así como los pies de los sacerdotes que llevaban el arca fueron mojados á la orilla del agua, (porque el Jordán suele reverter sobre todos sus bordes todo el tiempo de la siega,) [^15] Las aguas que venían de arriba, se pararon como en un montón bien lejos de la ciudad de Adam, que está al lado de Sarethán; y las que descendían á la mar de los llanos, al mar Salado, se acabaron y fueron partidas; y el pueblo pasó en derecho de Jericó. [^16] Mas los sacerdotes que llevaban el arca del pacto de Jehová, estuvieron en seco, firmes en medio del Jordán, hasta que todo el pueblo hubo acabado de pasar el Jordán; y todo Israel pasó en seco. [^17] 

[[Joshua - 2|<--]] Joshua - 3 [[Joshua - 4|-->]]

---
# Notes
