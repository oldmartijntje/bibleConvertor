---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 17 - Reina Valera (1602)"
---
[[Joshua - 16|<--]] Joshua - 17 [[Joshua - 18|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Joshua]]

# Joshua - 17

Y TUVO también suerte la tribu de Manasés, porque fué primogénito de José. Machîr, primogénito de Manasés, y padre de Galaad, el cual fué hombre de guerra, tuvo á Galaad y á Basán. [^1] Tuvieron también suerte los otros hijos de Manasés conforme á sus familias: los hijos de Abiezer, y los hijos de Helec, y los hijos de Esriel, y los hijos de Sichêm, y los hijos de Hepher, y los hijos de Semida; estos fueron los hijos varones de Manasés hijo de José, por sus familias. [^2] Pero Salphaad, hijo de Hepher, hijo de Galaad, hijo de Machîr, hijo de Manasés, no tuvo hijos, sino hijas, los nombres de las cuales son estos: Maala, Noa, Hogla, Milchâ, y Tirsa. [^3] Estas vinieron delante de Eleazar sacerdote, y de Josué hijo de Nun, y de los príncipes, y dijeron: Jehová mandó á Moisés que nos diese herencia entre nuestros hermanos. Y él les dió herencia entre los hermanos del padre de ellas, conforme al dicho de Jehová. [^4] Y cayeron á Manasés diez suertes á más de la tierra de Galaad y de Basán, que está de la otra parte del Jordán: [^5] Porque las hijas de Manasés poseyeron herencia entre sus hijos: y la tierra de Galaad fué de los otros hijos de Manasés. [^6] Y fué el término de Manasés desde Aser hasta Michmetat, la cual está delante de Sichêm; y va este término á la mano derecha, á los que habitan en Tappua. [^7] Y la tierra de Tappua fué de Manasés; pero Tappua, que está junto al término de Manasés, es de los hijos de Ephraim. [^8] Y desciende este término al arroyo de Cana, hacia el mediodía del arroyo. Estas ciudades de Ephraim están entre las ciudades de Manasés: y el término de Manasés es desde el norte del mismo arroyo, y sus salidas son á la mar. [^9] Ephraim al mediodía, y Manasés al norte, y la mar es su término: y encuéntranse con Aser á la parte del norte, y con Issachâr al oriente. [^10] Tuvo también Manasés en Issachâr y en Aser á Beth-san y sus aldeas, é Ibleam y sus aldeas, y los moradores de Dor y sus aldeas, y los moradores de Endor y sus aldeas, y los moradores de Taanach y sus aldeas, y los moradores de Megiddo y sus aldeas: tres provincias. [^11] Mas los hijos de Manasés no pudieron echar á los de aquellas ciudades; antes el Cananeo quiso habitar en la tierra. [^12] Empero cuando los hijos de Israel tomaron fuerzas, hicieron tributario al Cananeo, mas no lo echaron. [^13] Y los hijos de José hablaron á Josué, diciendo: ¿Por qué me has dado por heredad una sola suerte y una sola parte, siendo yo un pueblo tan grande y que Jehová me ha así bendecido hasta ahora? [^14] Y Josué les respondió: Si eres pueblo tan grande, sube tú al monte, y corta para ti allí en la tierra del Pherezeo y de los gigantes, pues que el monte de Ephraim es angosto para ti. [^15] Y los hijos de José dijeron: No nos bastará á nosotros este monte: y todos los Cananeos que habitan la tierra de la campiña, tienen carros herrados; los que están en Beth-san y en sus aldeas, y los que están en el valle de Jezreel. [^16] Entonces Josué respondió á la casa de José, á Ephraim y Manasés, diciendo: Tú eres gran pueblo, y tienes gran fuerza; no tendrás una sola suerte; [^17] Mas aquel monte será tuyo; que bosque es, y tú lo cortarás, y serán tuyos sus términos: porque tú echarás al Cananeo, aunque tenga carros herrados, y aunque sea fuerte. [^18] 

[[Joshua - 16|<--]] Joshua - 17 [[Joshua - 18|-->]]

---
# Notes
