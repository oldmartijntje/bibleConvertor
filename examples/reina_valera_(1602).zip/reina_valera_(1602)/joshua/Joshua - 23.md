---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 23 - Reina Valera (1602)"
---
[[Joshua - 22|<--]] Joshua - 23 [[Joshua - 24|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Joshua]]

# Joshua - 23

Y ACONTECIO, pasados muchos días después que Jehová dió reposo á Israel de todos sus enemigos al contorno, que Josué, siendo viejo, y entrado en días, [^1] Llamó á todo Israel, á sus ancianos, á sus príncipes, á sus jueces y á sus oficiales, y díjoles: Yo soy ya viejo y entrado en días: [^2] Y vosotros habéis visto todo lo que Jehová vuestro Dios ha hecho con todas estas gentes en vuestra presencia; porque Jehová vuestro Dios ha peleado por vosotros. [^3] He aquí os he repartido por suerte, en herencia para vuestras tribus, estas gentes, así las destruídas como las que quedan, desde el Jordán hasta la gran mar hacia donde el sol se pone. [^4] Y Jehová vuestro Dios las echará de delante de vosotros, y las lanzará de vuestra presencia: y vosotros poseeréis sus tierras, como Jehová vuestro Dios os ha dicho. [^5] Esforzaos pues mucho á guardar y hacer todo lo que está escrito en el libro de la ley de Moisés, sin apartaros de ello ni á la diestra ni á la siniestra; [^6] Que cuando entrareis á estas gentes que han quedado con vosotros, no hagáis mención ni juréis por el nombre de sus dioses, ni los sirváis, ni os inclinéis á ellos: [^7] Mas á Jehová vuestro Dios os allegaréis, como habéis hecho hasta hoy; [^8] Pues ha echado Jehová delante de vosotros grandes y fuertes naciones, y hasta hoy nadie ha podido parar delante de vuestro rostro. [^9] Un varón de vosotros perseguirá á mil: porque Jehová vuestro Dios pelea por vosotros, como él os dijo. [^10] Por tanto, cuidad mucho por vuestras almas, que améis á Jehová vuestro Dios. [^11] Porque si os apartareis, y os allegareis á lo que resta de aquestas gentes que han quedado con vosotros, y si concertareis con ellas matrimonios, y entrareis á ellas, y ellas á vosotros; [^12] Sabed que Jehová vuestro Dios no echará más estas gentes delante de vosotros; antes os serán por lazo, y por tropiezo, y por azote para vuestros costados, y por espinas para vuestros ojos, hasta tanto que perezcáis de aquesta buena tierra que Jehová vuestro Dios os ha dado. [^13] Y he aquí que yo estoy para entrar hoy por el camino de toda la tierra: reconoced, pues, con todo vuestro corazón y con toda vuestra alma, que no se ha perdido una palabra de todas la buenas palabras que Jehová vuestro Dios había dicho de vosotros: todas os han venido, no se ha perdido de ellas ni una. [^14] Mas será, que como ha venido sobre vosotros toda palabra buena que Jehová vuestro Dios os había dicho, así también traerá Jehová sobre vosotros toda palabra mala, hasta destruiros de sobre la buena tierra que Jehová vuestro Dios os ha dado; [^15] Cuando traspasareis el pacto de Jehová vuestro Dios que él os ha mandado, yendo y honrando dioses ajenos, é inclinándoos á ellos. Y el furor de Jehová se inflamará contra vosotros, y luego pereceréis de aquesta buena tierra que él os ha dado. [^16] 

[[Joshua - 22|<--]] Joshua - 23 [[Joshua - 24|-->]]

---
# Notes
