---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 2 - Reina Valera (1602)"
---
[[Joshua - 1|<--]] Joshua - 2 [[Joshua - 3|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Joshua]]

# Joshua - 2

Y JOSUÉ, hijo de Nun, envió desde Sittim dos espías secretamente, diciéndoles: Andad, reconoced la tierra, y á Jericó. Los cuales fueron, y entráronse en casa de una mujer ramera que se llamaba Rahab, y posaron allí. [^1] Y fué dado aviso al rey de Jericó, diciendo: He aquí que hombres de los hijos de Israel han venido aquí esta noche á espiar la tierra. [^2] Entonces el rey de Jericó, envió á decir á Rahab: Saca fuera los hombres que han venido á ti, y han entrado en tu casa; porque han venido á espiar toda la tierra. [^3] Mas la mujer había tomado los dos hombres, y los había escondido; y dijo: Verdad que hombres vinieron á mí, mas no supe de dónde eran: [^4] Y al cerrarse la puerta, siendo ya oscuro, esos hombres se salieron, y no sé á dónde se han ido: seguidlos apriesa, que los alcanzaréis. [^5] Mas ella los había hecho subir al terrado, y habíalos escondido entre tascos de lino que en aquel terrado tenía puestos. [^6] Y los hombres fueron tras ellos por el camino del Jordán, hasta los vados: y la puerta fué cerrada después que salieron los que tras ellos iban. [^7] Mas antes que ellos durmiesen, ella subió á ellos al terrado, y díjoles: [^8] Sé que Jehová os ha dado esta tierra; porque el temor de vosotros ha caído sobre nosotros, y todos los moradores del país están desmayados por causa de vosotros; [^9] Porque hemos oído que Jehová hizo secar las aguas del mar Bermejo delante de vosotros, cuando salisteis de Egipto, y lo que habéis hecho á los dos reyes de los Amorrheos que estaban de la parte allá del Jordán, á Sehón y á Og, á los cuales habéis destruído. [^10] Oyendo esto, ha desmayado nuestro corazón; ni ha quedado más espíritu en alguno por causa de vosotros: porque Jehová vuestro Dios es Dios arriba en los cielos y abajo en la tierra. [^11] Ruégoos pues ahora, me juréis por Jehová, que como he hecho misericordia con vosotros, así la haréis vosotros con la casa de mi padre, de lo cual me daréis una señal cierta; [^12] Y que salvaréis la vida á mi padre y á mi madre, y á mis hermanos y hermanas, y á todo lo que es suyo; y que libraréis nuestras vidas de la muerte. [^13] Y ellos le respondieron: Nuestra alma por vosotros hasta la muerte, si no denunciareis este nuestro negocio: y cuando Jehová nos hubiere dado la tierra, nosotros haremos contigo misericordia y verdad. [^14] Entonces ella los hizo descender con una cuerda por la ventana; porque su casa estaba á la pared del muro, y ella vivía en el muro. [^15] Y díjoles: Marchaos al monte, porque los que fueron tras vosotros no os encuentren; y estad escondidos allí tres días, hasta que los que os siguen hayan vuelto; y después os iréis vuestro camino. [^16] Y ellos le dijeron: Nosotros seremos desobligados de este juramento con que nos has conjurado. [^17] He aquí, cuando nosotros entráremos en la tierra, tú atarás este cordón de grana á la ventana por la cual nos descolgaste: y tú juntarás en tu casa tu padre y tu madre, tus hermanos y toda la familia de tu padre. [^18] Cualquiera que saliere fuera de las puertas de tu casa, su sangre será sobre su cabeza, y nosotros sin culpa. Mas cualquiera que se estuviere en casa contigo, su sangre será sobre nuestra cabeza, si mano le tocare. [^19] Y si tú denunciares este nuestro negocio, nosotros seremos desobligados de este tu juramento con que nos has juramentado. [^20] Y ella respondió: Sea así como habéis dicho. Luego los despidió, y se fueron: y ella ató el cordón de grana á la ventana. [^21] Y caminando ellos, llegaron al monte, y estuvieron allí tres días, hasta que los que los seguían se hubiesen vuelto: y los que los siguieron, buscaron por todo el camino, mas no los hallaron. [^22] Y tornándose los dos varones, descendieron del monte, y pasaron, y vinieron á Josué hijo de Nun, y contáronle todas las cosas que les habían acontecido. [^23] Y dijeron á Josué: Jehová ha entregado toda la tierra en nuestras manos; y también todos los moradores del país están desmayados delante de nosotros. [^24] 

[[Joshua - 1|<--]] Joshua - 2 [[Joshua - 3|-->]]

---
# Notes
