---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 11 - Reina Valera (1602)"
---
[[Joshua - 10|<--]] Joshua - 11 [[Joshua - 12|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Joshua]]

# Joshua - 11

OYENDO esto Jabín rey de Hasor, envió mensaje á Jobab rey de Madón, y al rey de Simrom, y al rey de Achsaph, [^1] Y á los reyes que estaban á la parte del norte en las montañas, y en el llano al mediodía de Cinneroth, y en los llanos, y en las regiones de Dor al occidente; [^2] Y al Cananeo que estaba al oriente y al occidente, y al Amorrheo, y al Hetheo, y al Pherezeo, y al Jebuseo en las montañas, y al Heveo debajo de Hermón en tierra de Mizpa. [^3] Estos salieron, y con ellos todos sus ejércitos, pueblo mucho en gran manera, como la arena que está á la orilla del mar, con gran muchedumbre de caballos y carros. [^4] Todos estos reyes se juntaron, y viniendo reunieron los campos junto á las aguas de Merom, para pelear contra Israel. [^5] Mas Jehová dijo á Josué: No tengas temor de ellos, que mañana á esta hora yo entregaré á todos éstos, muertos delante de Israel: á sus caballos desjarretarás, y sus carros quemarás al fuego. [^6] Y vino Josué, y con él todo el pueblo de guerra, contra ellos, y dió de repente sobre ellos junto á las aguas de Merom. [^7] Y entrególos Jehová en manos de Israel, los cuales los hirieron y siguieron hasta Sidón la grande, y hasta las aguas calientes, y hasta el llano de Mizpa al oriente, hiriéndolos hasta que no les dejaron ninguno. [^8] Y Josué hizo con ellos como Jehová le había mandado: desjarretó sus caballos, y sus carros quemó al fuego. [^9] Y tornándose Josué, tomó en el mismo tiempo á Hasor, é hirió á cuchillo á su rey: la cual Hasor había sido antes cabeza de todos estos reinos. [^10] E hirieron á cuchillo todo cuanto en ella había vivo, destruyendo y no dejando cosa con vida; y á Asor pusieron á fuego. [^11] Asimismo tomó Josué todas las ciudades de aquestos reyes, y á todos los reyes de ellas, y los metió á cuchillo, y los destruyó, como Moisés siervo de Jehová lo había mandado. [^12] Empero todas las ciudades que estaban en sus cabezos, no las quemó Israel, sacando á sola Asor, la cual quemó Josué. [^13] Y los hijos de Israel tomaron para sí todos los despojos y bestias de aquestas ciudades: pero á todos los hombres metieron á cuchillo hasta destruirlos, sin dejar alguno con vida. [^14] De la manera que Jehová lo había mandado á Moisés su siervo, así Moisés lo mandó á Josué: y así Josué lo hizo, sin quitar palabra de todo lo que Jehová había mandado á Moisés. [^15] Tomó pues Josué toda aquella tierra, las montañas, y toda la región del mediodía, y toda la tierra de Gosén, y los bajos y los llanos, y la montaña de Israel y sus valles. [^16] Desde el monte de Halac, que sube hasta Seir, hasta Baal-gad en la llanura del Líbano, á las raíces del monte Hermón: tomó asimismo todos sus reyes, los cuales hirió y mató. [^17] Por muchos días tuvo guerra Josué con estos reyes. [^18] No hubo ciudad que hiciese paz con los hijos de Israel, sacados los Heveos, que moraban en Gabaón: todo lo tomaron por guerra. [^19] Porque esto vino de Jehová, que endurecía el corazón de ellos para que resistiesen con guerra á Israel, para destruirlos, y que no les fuese hecha misericordia, antes fuesen desarraigados, como Jehová lo había mandado á Moisés. [^20] También en el mismo tiempo vino Josué y destruyó los Anaceos de los montes, de Hebrón, de Debir, y de Anab, y de todos los montes de Judá, y de todos los montes de Israel: Josué los destruyó á ellos y á sus ciudades. [^21] Ninguno de los Anaceos quedó en la tierra de los hijos de Israel; solamente quedaron en Gaza, en Gath, y en Asdod. [^22] Tomó, pues, Josué toda la tierra, conforme á todo lo que Jehová había dicho á Moisés; y entrególa Josué á los Israelitas por herencia, conforme á sus repartimientos de sus tribus: y la tierra reposó de guerra. [^23] 

[[Joshua - 10|<--]] Joshua - 11 [[Joshua - 12|-->]]

---
# Notes
