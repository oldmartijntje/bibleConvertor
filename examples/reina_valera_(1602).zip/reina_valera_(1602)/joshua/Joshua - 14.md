---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 14 - Reina Valera (1602)"
---
[[Joshua - 13|<--]] Joshua - 14 [[Joshua - 15|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Joshua]]

# Joshua - 14

ESTO pues es lo que los hijos de Israel tomaron por heredad en la tierra de Canaán, lo cual les repartieron Eleazar sacerdote, y Josué hijo de Nun, y los principales de los padres de las tribus de los hijos de Israel. [^1] Por suerte dióseles su heredad, como Jehová lo había mandado por Moisés, que diese á las nueve tribus y á la media tribu. [^2] Porque á las dos tribus, y á la media tribu, les había Moisés dado heredad de la otra parte del Jordán: mas á los Levitas no dió heredad entre ellos. [^3] Porque los hijos de José fueron dos tribus, Manasés y Ephraim: y no dieron parte á los Levitas en la tierra, sino ciudades en que morasen, con sus ejidos para sus ganados y rebaños. [^4] De la manera que Jehová lo había mandado á Moisés, así lo hicieron los hijos de Israel en el repartimiento de la tierra. [^5] Y los hijos de Judá vinieron á Josué en Gilgal; y Caleb, hijo de Jephone Cenezeo, le dijo: Tú sabes lo que Jehová dijo á Moisés, varón de Dios, en Cades-barnea, tocante á mí y á ti. [^6] Yo era de edad de cuarenta años, cuando Moisés siervo de Jehová me envió de Cades-barnea á reconocer la tierra; y yo le referí el negocio como lo tenía en mi corazón: [^7] Mas mis hermanos, los que habían subido conmigo, menguaron el corazón del pueblo; empero yo cumplí siguiendo á Jehová mi Dios. [^8] Entonces Moisés juró, diciendo: Si la tierra que holló tu pie no fuere para ti, y para tus hijos en herencia perpetua: por cuanto cumpliste siguiendo á Jehová mi Dios. [^9] Ahora bien, Jehová me ha hecho vivir, como él dijo, estos cuarenta y cinco años, desde el tiempo que Jehová habló estas palabras á Moisés, cuando Israel andaba por el desierto: y ahora, he aquí soy hoy día de ochenta y cinco años: [^10] Pero aun hoy estoy tan fuerte como el día que Moisés me envió: cual era entonces mi fuerza, tal es ahora, para la guerra, y para salir y para entrar. [^11] Dame, pues, ahora este monte, del cual habló Jehová aquel día; porque tú oíste en aquel día que los Anaceos están allí, y grandes y fuertes ciudades. Quizá Jehová será conmigo, y los echaré como Jehová ha dicho. [^12] Josué entonces le bendijo, y dió á Caleb hijo de Jephone á Hebrón por heredad. [^13] Por tanto Hebrón fué de Caleb, hijo de Jephone Cenezeo, en heredad hasta hoy; porque cumplió siguiendo á Jehová Dios de Israel. [^14] Mas Hebrón fué antes llamada Chîriath-arba; fué Arba un hombre grande entre los Anaceos. Y la tierra tuvo reposo de las guerras. [^15] 

[[Joshua - 13|<--]] Joshua - 14 [[Joshua - 15|-->]]

---
# Notes
