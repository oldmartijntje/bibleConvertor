---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 5 - Reina Valera (1602)"
---
[[Joshua - 4|<--]] Joshua - 5 [[Joshua - 6|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Joshua]]

# Joshua - 5

Y CUANDO todos los reyes de los Amorrheos, que estaban de la otra parte del Jordán al occidente, y todos los reyes de los Cananeos, que estaban cerca de la mar, oyeron como Jehová había secado las aguas del Jordán delante de los hijos de Israel hasta que hubieron pasado, desfalleció su corazón, y no hubo más espíritu en ellos delante de los hijos de Israel. [^1] En aquel tiempo Jehová dijo á Josué: Hazte cuchillos afilados, y vuelve á circuncidar la segunda vez á los hijos de Israel. [^2] Y Josué se hizo cuchillos afilados, y circuncidó á los hijos de Israel en el monte de los prepucios. [^3] Esta es la causa por la cual Josué los circuncidó: todo el pueblo que había salido de Egipto, los varones, todos los hombres de guerra, habían muerto en el desierto por el camino, después que salieron de Egipto. [^4] Porque todos los del pueblo que habían salido, estaban circuncidados: mas todo el pueblo que había nacido en el desierto por el camino, después que salieron de Egipto, no estaban circuncidados. [^5] Porque los hijos de Israel anduvieron por el desierto cuarenta años, hasta que toda la gente de los hombres de guerra que habían salido de Egipto, fué consumida, por cuanto no obedecieron á la voz de Jehová; por lo cual Jehová les juró que no les dejaría ver la tierra, de la cual Jehová había jurado á sus padres que nos la daría, tierra que fluye leche y miel. [^6] Y los hijos de ellos, que él había hecho suceder en su lugar, Josué los circuncidó; pues eran incircuncisos, porque no habían sido circuncidados por el camino. [^7] Y cuando hubieron acabado de circuncidar toda la gente, quedáronse en el mismo lugar en el campo, hasta que sanaron. [^8] Y Jehová dijo á Josué: Hoy he quitado de vosotros el oprobio de Egipto: por lo cual el nombre de aquel lugar fué llamado Gilgal, hasta hoy. [^9] Y los hijos de Israel asentaron el campo en Gilgal, y celebraron la pascua á los catorce días del mes, por la tarde, en los llanos de Jericó. [^10] Y al otro día de la pascua comieron del fruto de la tierra los panes sin levadura, y en el mismo día espigas nuevas tostadas. [^11] Y el maná cesó el día siguiente, desde que comenzaron á comer del fruto de la tierra: y los hijos de Israel nunca más tuvieron maná, sino que comieron de los frutos de la tierra de Canaán aquel año. [^12] Y estando Josué cerca de Jericó, alzó sus ojos, y vió un varón que estaba delante de él, el cual tenía una espada desnuda en su mano. Y Josué yéndose hacia él, le dijo: ¿Eres de los nuestros, ó de nuestros enemigos? [^13] Y él respondió: No; mas Príncipe del ejército de Jehová, ahora he venido. Entonces Josué postrándose sobre su rostro en tierra le adoró; y díjole: ¿Qué dice mi Señor á su siervo? [^14] Y el Príncipe del ejército de Jehová repondió á Josué: Quita tus zapatos de tus pies; porque el lugar donde estás es santo. Y Josué lo hizo así. [^15] 

[[Joshua - 4|<--]] Joshua - 5 [[Joshua - 6|-->]]

---
# Notes
