---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 4 - Reina Valera (1602)"
---
[[Joshua - 3|<--]] Joshua - 4 [[Joshua - 5|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Joshua]]

# Joshua - 4

Y CUANDO toda la gente hubo acabado de pasar el Jordán, Jehová habló á Josué, diciendo: [^1] Tomad del pueblo doce hombres, de cada tribu uno, [^2] Y mandadles, diciendo: Tomaos de aquí del medio del Jordán, del lugar donde están firmes los pies de los sacerdotes, doce piedras, las cuales pasaréis con vosotros, y las asentaréis en el alojamiento donde habéis de tener la noche. [^3] Entonces Josué llamó á los doce hombres, los cuales había él ordenado de entre los hijos de Israel, de cada tribu uno; [^4] Y díjoles Josué: Pasad delante del arca de Jehová vuestro Dios al medio del Jordán; y cada uno de vosotros tome una piedra sobre su hombro, conforme al número de las tribus de los hijos de Israel; [^5] Para que esto sea señal entre vosotros; y cuando vuestros hijos preguntaren á sus padres mañana, diciendo: ¿Qué os significan estas piedras? [^6] Les responderéis: Que las aguas del Jordán fueron partidas delante del arca del pacto de Jehová; cuando ella pasó el Jordán, las aguas del Jordán se partieron: y estas piedras serán por memoria á los hijos de Israel para siempre. [^7] Y los hijos de Israel lo hicieron así como Josué les mandó: que levantaron doce piedras del medio del Jordán, como Jehová lo había dicho á Josué, conforme al número de las tribus de los hijos de Israel, y pasáronlas consigo al alojamiento, y las asentaron allí. [^8] Josué también levantó doce piedras en medio del Jordán, en el lugar donde estuvieron los pies de los sacerdotes que llevaban el arca del pacto; y han estado allí hasta hoy. [^9] Y los sacerdotes que llevaban el arca se pararon en medio del Jordán, hasta tanto que se acabó todo lo que Jehová había mandado á Josué que hablase al pueblo, conforme á todas las cosas que Moisés había á Josué mandado: y el pueblo se dió priesa y pasó. [^10] Y cuando todo el pueblo acabó de pasar, pasó también el arca de Jehová, y los sacerdotes, en presencia del pueblo. [^11] También los hijos de Rubén y los hijos de Gad, y la media tribu de Manasés, pasaron armados delante de los hijos de Israel, según Moisés les había dicho: [^12] Como cuarenta mil hombres armados á punto pasaron hacia la campiña de Jericó delante de Jehová á la guerra. [^13] En aquel día Jehová engrandeció á Josué en ojos de todo Israel: y temiéronle, como habían temido á Moisés, todos los días de su vida. [^14] Y Jehová habló á Josué, diciendo: [^15] Manda á los sacerdotes que llevan el arca del testimonio, que suban del Jordán. [^16] Y Josué mandó á los sacerdotes, diciendo: Subid del Jordán. [^17] Y aconteció que como los sacerdotes que llevaban el arca del pacto de Jehová, subieron del medio del Jordán, y las plantas de los pies de los sacerdotes estuvieron en seco, las aguas del Jordán se volvieron á su lugar, á su lugar, fkbcorriendo como antes sobre todos sus bordes. [^18] Y el pueblo subió del Jordán el diez del mes primero, y asentaron el campo en Gilgal, al lado oriental de Jericó. [^19] Y Josué erigió en Gilgal las doce piedras que habían traído del Jordán. [^20] Y habló á los hijos de Israel, diciendo: Cuando mañana preguntaren vuestros hijos á sus padres, y dijeren: ¿Qué os significan estas piedras? [^21] Declararéis á vuestros hijos, diciendo: Israel pasó en seco por este Jordán. [^22] Porque Jehová vuestro Dios secó las aguas del Jordán delante de vosotros, hasta que habíais pasado, á la manera que Jehová vuestro Dios lo había hecho en el mar Bermejo, al cual secó delante de nosotros hasta que pasamos: [^23] Para que todos los pueblos de la tierra conozcan la mano de Jehová, que es fuerte; para que temáis á Jehová vuestro Dios todos los días. [^24] 

[[Joshua - 3|<--]] Joshua - 4 [[Joshua - 5|-->]]

---
# Notes
