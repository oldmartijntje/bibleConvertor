---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 12 - Reina Valera (1602)"
---
[[Joshua - 11|<--]] Joshua - 12 [[Joshua - 13|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Joshua]]

# Joshua - 12

ESTOS son los reyes de la tierra que los hijos de Israel hirieron, y cuya tierra poseyeron de la otra parte del Jordán al nacimiento del sol, desde el arroyo de Arnón hasta el monte Hermón, y toda la llanura oriental: [^1] Sehón rey de los Amorrheos, que habitaba en Hesbón, y señoreaba desde Aroer, que está á la ribera del arroyo de Arnón, y desde en medio del arroyo, y la mitad de Galaad, hasta el arroyo Jaboc, el término de los hijos de Ammón; [^2] Y desde la campiña hasta la mar de Cinneroth, al oriente; y hasta la mar de la llanura, el mar Salado, al oriente, por el camino de Beth-jesimoth; y desde el mediodía debajo de las vertientes del Pisga. [^3] Y los términos de Og rey de Basán, que había quedado de los Rapheos, el cual habitaba en Astaroth y en Edrei, [^4] Y señoreaba en el monte de Hermón, y en Salca, y en todo Basán hasta los términos de Gessuri y de Maachâti, y la mitad de Galaad, término de Sehón rey de Hesbón. [^5] A estos hirieron Moisés siervo de Jehová y los hijos de Israel; y Moisés siervo de Jehová dió aquella tierra en posesión á los Rubenitas, Gaditas, y á la media tribu de Manasés. [^6] Y estos son los reyes de la tierra que hirió Josué con los hijos de Israel, de esta parte del Jordán al occidente, desde Baal-gad en el llano del Líbano hasta el monte de Halac que sube á Seir; la cual tierra dió Josué en posesión á las tribus de Israel, conforme á sus repartimientos; [^7] En montes y en valles, en llanos y en vertientes, al desierto y al mediodía; el Hetheo, y el Amorrheo, y el Cananeo, y el Pherezeo, y el Heveo, y el Jebuseo. [^8] El rey de Jericó, uno: el rey de Hai, que está al lado de Beth-el, otro: [^9] El rey de Jerusalem, otro: el rey de Hebrón, otro: [^10] El rey de Jarmuth, otro: el rey de Lachîs, otro: [^11] El rey de Eglón, otro: el rey de Gezer, otro: [^12] El rey de Debir, otro: el rey de Geder, otro: [^13] El rey de Horma, otro: el rey de Arad, otro: [^14] El rey de Libna, otro: el rey de Adullam, otro: [^15] El rey de Maceda, otro: el rey de Beth-el, otro: [^16] El rey de Tappua, otro: el rey de Hepher, otro: [^17] El rey de Aphec, otro: el rey de Lasarón, otro: [^18] El rey de Madón, otro: el rey de Hasor, otro: [^19] El rey de Simrom-meron, otro: el rey de Achsaph, otro: [^20] El rey de Taanach, otro: el rey de Megiddo, otro: [^21] El rey de Chêdes, otro: el rey de Jocneam de Carmel, otro: [^22] El rey de Dor, de la provincia de Dor, otro; el rey de Gentes en Gilgal, otro: [^23] El rey de Tirsa, otro: treinta y un reyes en todo. [^24] 

[[Joshua - 11|<--]] Joshua - 12 [[Joshua - 13|-->]]

---
# Notes
