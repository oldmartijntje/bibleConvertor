---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 20 - Reina Valera (1602)"
---
[[Joshua - 19|<--]] Joshua - 20 [[Joshua - 21|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Joshua]]

# Joshua - 20

Y HABLO Jehová á Josué, diciendo: [^1] Habla á los hijos de Israel, diciendo: Señalaos las ciudades de refugio, de las cuales yo os hablé por Moisés; [^2] Para que se acoja allí el homicida que matare á alguno por yerro y no á sabiendas; que os sean por acogimiento del cercano del muerto. [^3] Y el que se acogiere á alguna de aquellas ciudades, presentaráse á la puerta de la ciudad, y dirá sus causas, oyéndolo los ancianos de aquella ciudad: y ellos le recibirán consigo dentro de la ciudad, y le darán lugar que habite con ellos. [^4] Y cuando el cercano del muerto le siguiere, no entregarán en su mano al homicida, por cuanto hirió á su prójimo por yerro, ni tuvo con él antes enemistad. [^5] Y quedará en aquella ciudad hasta que parezca en juicio delante del ayuntamiento, hasta la muerte del gran sacerdote que fuere en aquel tiempo: entonces el homicida tornará y vendrá á su ciudad y á su casa y á la ciudad de donde huyó. [^6] Entonces señalaron á Cedes en Galilea, en el monte de Nephtalí, y á Sichêm en el monte de Ephraim, y á Chîriath-arba, que es Hebrón, en el monte de Judá. [^7] Y de la otra parte del Jordán de Jericó, al oriente, señalaron á Beser en el desierto, en la llanura de la tribu de Rubén, y á Ramoth en Galaad de la tribu de Gad, y á Gaulón en Basán de la tribu de Manasés. [^8] Estas fueron las ciudades señaladas para todos los hijos de Israel, y para el extranjero que morase entre ellos, para que se acogiese á ellas cualquiera que hiriese hombre por yerro, y no muriese por mano del cercano del muerto, hasta que compareciese delante del ayuntamiento. [^9] 

[[Joshua - 19|<--]] Joshua - 20 [[Joshua - 21|-->]]

---
# Notes
