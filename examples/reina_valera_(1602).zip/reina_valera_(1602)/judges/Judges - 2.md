---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 2 - Reina Valera (1602)"
---
[[Judges - 1|<--]] Judges - 2 [[Judges - 3|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Judges]]

# Judges - 2

Y El ángel de Jehová subió de Gilgal á Bochîm, y dijo: Yo os saqué de Egipto, y os introduje en la tierra de la cual había jurado á vuestros padres; y dije: No invalidaré jamás mi pacto con vosotros; [^1] Con tal que vosotros no hagáis alianza con los moradores de aquesta tierra, cuyos altares habéis de derribar: mas vosotros no habéis atendido á mi voz: ¿por qué habéis hecho esto? [^2] Por tanto yo también dije: No los echaré de delante de vosotros, sino que os serán por azote para vuestros costados, y sus dioses por tropiezo. [^3] Y como el ángel de Jehová habló estas palabras á todos los hijos de Israel, el pueblo lloró en alta voz. [^4] Y llamaron por nombre aquel lugar Bochîm: y sacrificaron allí á Jehová. [^5] Porque ya Josué había despedido al pueblo, y los hijos de Israel se habían ido cada uno á su heredad para poseerla. [^6] Y el pueblo había servido á Jehová todo el tiempo de Josué, y todo el tiempo de los ancianos que vivieron largos días después de Josué, los cuales habían visto todas las grandes obras de Jehová, que el había hecho por Israel. [^7] Y murió Josué hijo de Nun, siervo de Jehová, siendo de ciento y diez años. [^8] Y enterráronlo en el término de su heredad en Timnath-sera, en el monte de Ephraim, el norte del monte de Gaas. [^9] Y toda aquella generación fué también recogida con sus padres. Y levantóse después de ellos otra generación, que no conocían á Jehová, ni la obra que él había hecho por Israel. [^10] Y los hijos de Israel hicieron lo malo en ojos de Jehová, y sirvieron á los Baales: [^11] Y dejaron á Jehová el Dios de sus padres, que los había sacado de la tierra de Egipto, y fuéronse tras otros dioses, los dioses de los pueblos que estaban en sus alrededores, á los cuales adoraron; y provocaron á ira á Jehová. [^12] Y dejaron á Jehová, y adoraron á Baal y á Astaroth. [^13] Y el furor de Jehová se encendió contra Israel, el cual los entregó en manos de robadores que los despojaron, y los vendió en manos de sus enemigos de alrededor: y no pudieron parar más delante de sus enemigos. [^14] Por donde quiera que salían, la mano de Jehová era contra ellos para mal, como Jehová había dicho, y como Jehová se lo había jurado; así los afligió en gran manera. [^15] Mas Jehová suscitó jueces que los librasen de mano de los que los despojaban. [^16] Y tampoco oyeron á sus jueces, sino que fornicaron tras dioses ajenos, á los cuales adoraron: apartáronse bien presto del camino en que anduvieron sus padres obedeciendo á los mandamientos de Jehová; mas ellos no hicieron así. [^17] Y cuando Jehová les suscitaba jueces, Jehová era con el juez, y librábalos de mano de los enemigos todo el tiempo de aquel juez: porque Jehová se arrepentía por sus gemidos á causa de los que los oprimían y afligían. [^18] Mas en muriendo el juez, ellos se tornaban, y se corrompían más que sus padres, siguiendo dioses ajenos para servirles, é inclinándose delante de ellos; y nada disminuían de sus obras, ni de su duro camino. [^19] Y la ira de Jehová se encendió contra Israel, y dijo: Pues que esta gente traspasa mi pacto que ordené á sus padres, y no obedecen mi voz, [^20] Tampoco yo echaré más de delante de ellos á ninguna de aquestas gentes que dejó Josué cuando murió; [^21] Para que por ellas probara yo á Israel, si guardarían ellos el camino de Jehová andando por él, como sus padres lo guardaron, ó no. [^22] Por esto dejó Jehová aquellas gentes, y no las desarraigó luego, ni las entregó en mano de Josué. [^23] 

[[Judges - 1|<--]] Judges - 2 [[Judges - 3|-->]]

---
# Notes
