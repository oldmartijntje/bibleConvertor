---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 15 - Reina Valera (1602)"
---
[[Judges - 14|<--]] Judges - 15 [[Judges - 16|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Judges]]

# Judges - 15

Y ACONTECIO después de días, que en el tiempo de la siega del trigo, Samsón visitó á su mujer con un cabrito, diciendo: Entraré á mi mujer á la cámara. Mas el padre de ella no lo dejó entrar. [^1] Y dijo el padre de ella: Persuadíme que la aborrecías, y díla á tu compañero. Mas su hermana menor, ¿no es más hermosa que ella? tómala, pues, en su lugar. [^2] Y Samsón les repondió: Yo seré sin culpa esta vez para con los Filisteos, si mal les hiciere. [^3] Y fué Samsón y cogió trescientas zorras, y tomando teas, y trabando aquéllas por las colas, puso entre cada dos colas una tea. [^4] Después, encendiendo las teas, echó las zorras en los sembrados de los Filisteos, y quemó hacinas y mieses, y viñas y olivares. [^5] Y dijeron los Filisteos: ¿Quién hizo esto? Y fuéles dicho: Samsón, el yerno del Timnateo, porque le quitó su mujer y la dió á su compañero. Y vinieron los Filisteos, y quemaron á fuego á ella y á su padre. [^6] Entonces Samsón les dijo: ¿Así lo habíais de hacer? mas yo me vengaré de vosotros, y después cesaré. [^7] E hiriólos pierna y muslo con gran mortandad; y descendió, y fijóse en la cueva de la peña de Etam. [^8] Y los Filisteos subieron y pusieron campo en Judá, y tendiéronse por Lehi. [^9] Y los varones de Judá les dijeron: ¿Por qué habéis subido contra nosotros? Y ellos respondieron: A prender á Samsón hemos subido, para hacerle como él nos ha hecho. [^10] Y vinieron tres mil hombres de Judá á la cueva de la peña de Etam, y dijeron á Samsón: ¿No sabes tú que los Filisteos dominan sobre nosotros? ¿por qué nos has hecho esto? Y él les respondió: Yo les he hecho como ellos me hicieron. [^11] Ellos entonces le dijeron: Nosotros hemos venido para prenderte, y entregarte en mano de los Filisteos. Y Samsón les respondió: Juradme que vosotros no me mataréis. [^12] Y ellos le respondieron, diciendo: No, solamente te prenderemos, y te entregaremos en sus manos; mas no te mataremos. Entonces le ataron con dos cuerdas nuevas, é hiciéronle venir de la peña. [^13] Y así que vino hasta Lehi, los Filisteos le salieron á recibir con algazara: y el espíritu de Jehová cayó sobre él, y las cuerdas que estaban en sus brazos se tornaron como lino quemado con fuego, y las ataduras se cayeron de sus manos. [^14] Y hallando una quijada de asno fresca, extendió la mano y tomóla, é hirió con ella á mil hombres. [^15] Entonces Samsón dijo: Con la quijada de un asno, un montón, dos montones; Con la quijada de un asno herí mil hombres. [^16] Y acabando de hablar, echó de su mano la quijada, y llamó á aquel lugar Ramath-lehi. [^17] Y teniendo gran sed, clamó luego á Jehová, y dijo: Tú has dado esta gran salud por mano de tu siervo: ¿y moriré yo ahora de sed, y caeré en mano de los incircuncisos? [^18] Entonces quebró Dios una muela que estaba en la quijada, y salieron de allí aguas, y bebió, y recobró su espíritu, y reanimóse. Por tanto llamó su nombre de aquel lugar, En-haccore, el cual es en Lehi, hasta hoy. [^19] Y juzgó á Israel en días de los Filisteos veinte años. [^20] 

[[Judges - 14|<--]] Judges - 15 [[Judges - 16|-->]]

---
# Notes
