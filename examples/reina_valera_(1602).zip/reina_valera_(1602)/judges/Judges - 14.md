---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 14 - Reina Valera (1602)"
---
[[Judges - 13|<--]] Judges - 14 [[Judges - 15|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Judges]]

# Judges - 14

Y DESCENDIENDO Samsón á Timnah, vió en Timnah una mujer de las hijas de los Filisteos. [^1] Y subió, y declarólo á su padre y á su madre, diciendo: Yo he visto en Timnah una mujer de las hijas de los Filisteos: ruégoos que me la toméis por mujer. [^2] Y su padre y su madre le dijeron: ¿No hay mujer entre las hijas de tus hermanos, ni en todo mi pueblo, para que vayas tú á tomar mujer de los Filisteos incircuncisos? Y Samsón respondió á su padre: Tómamela por mujer, porque ésta agradó á mis ojos. [^3] Mas su padre y su madre no sabían que esto venía de Jehová, y que él buscaba ocasión contra los Filisteos: porque en aquel tiempo los Filisteos dominaban sobre Israel. [^4] Y Samsón descendió con su padre y con su madre á Timnah: y como llegaron á las viñas de Timnah, he aquí un cachorro de león que venía bramando hacia él. [^5] Y el espíritu de Jehová cayó sobre él, y despedazólo como quien despedaza un cabrito, sin tener nada en su mano: y no dió á entender á su padre ni á su madre lo que había hecho. [^6] Vino pues, y habló á la mujer que había agradado á Samsón. [^7] Y volviendo después de algunos días para tomarla, apartóse para ver el cuerpo muerto del león, y he aquí en el cuerpo del león un enjambre de abejas, y un panal de miel. [^8] Y tomándolo en sus manos, fuése comiéndolo por el camino: y llegado que hubo á su padre y á su madre, dióles también á ellos que comiesen; mas no les descubrió que había tomado aquella miel del cuerpo del león. [^9] Vino pues su padre á la mujer, y Samsón hizo allí banquete; porque así solían hacer los mancebos. [^10] Y como ellos le vieron, tomaron treinta compañeros que estuviesen con él; [^11] A los cuales Samsón dijo: Yo os propondré ahora un enigma, el cual si en los siete días del banquete vosotros me declarareis y descubriereis, yo os daré treinta sábanas y treinta mudas de vestidos. [^12] Mas si no me lo supiereis declarar, vosotros me daréis las treinta sábanas y las treinta mudas de vestidos. Y ellos respondieron: Propónnos tu enigma, y lo oiremos. [^13] Entonces les dijo: Del comedor salió comida, Y del fuerte salió dulzura. Y ellos no pudieron declararle el enigma en tres días. [^14] Y al séptimo día dijeron á la mujer de Samsón: Induce á tu marido á que nos declare este enigma, porque no te quememos á ti y á la casa de tu padre. ¿Habéisnos llamado aquí para poseernos? [^15] Y lloró la mujer de Samsón delante de él, y dijo: Solamente me aborreces y no me amas, pues que no me declaras el enigma que propusiste á los hijos de mi pueblo. Y él respondió: He aquí que ni á mi padre ni á mi madre lo he declarado; y ¿habíalo de declarar á ti? [^16] Y ella lloró delante de él los siete días que ellos tuvieron banquete: mas al séptimo día él se lo declaró, porque le constriñó; y ella lo declaró á los hijos de su pueblo. [^17] Y al séptimo día, antes que el sol se pusiese, los de la ciudad le dijeron: ¿Qué cosa más dulce que la miel? ¿Y qué cosa más fuerte que el león? Si no araseis con mi novilla, Nunca hubierais descubierto mi enigma. [^18] Y el espíritu de Jehová cayó sobre él, y descendió á Ascalón, é hirió treinta hombres de ellos; y tomando sus despojos, dió las mudas de vestidos á los que habían explicado el enigma: y encendido en enojo fuése á casa de su padre. [^19] Y la mujer de Samsón fué dada á su compañero, con el cual él antes se acompañaba. [^20] 

[[Judges - 13|<--]] Judges - 14 [[Judges - 15|-->]]

---
# Notes
