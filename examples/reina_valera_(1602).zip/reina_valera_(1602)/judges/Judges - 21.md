---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 21 - Reina Valera (1602)"
---
[[Judges - 20|<--]] Judges - 21

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Judges]]

# Judges - 21

Y LOS varones de Israel habían jurado en Mizpa, diciendo: Ninguno de nosotros dará su hija á los de Benjamín por mujer. [^1] Y vino el pueblo á la casa de Dios, y estuviéronse allí hasta la tarde delante de Dios; y alzando su voz hicieron gran llanto, y dijeron: [^2] Oh Jehová Dios de Israel, ¿por qué ha sucedido esto en Israel, que falte hoy de Israel una tribu? [^3] Y al día siguiente el pueblo se levantó de mañana, y edificaron allí altar, y ofrecieron holocaustos y pacíficos. [^4] Y dijeron los hijos de Israel: ¿Quién de todas las tribus de Israel no subió á la reunión cerca de Jehová? Porque se había hecho gran juramento contra el que no subiese á Jehová en Mizpa, diciendo: Sufrirá muerte. [^5] Y los hijos de Israel se arrepintieron á causa de Benjamín su hermano, y dijeron: Una tribu es hoy cortada de Israel. [^6] ¿Qué haremos en cuanto á mujeres para los que han quedado? Nosotros hemos jurado por Jehová que no les hemos de dar nuestras hijas por mujeres. [^7] Y dijeron: ¿Hay alguno de las tribus de Israel que no haya subido á Jehová en Mizpa? Y hallaron que ninguno de Jabes-galaad había venido al campo á la reunión: [^8] Porque el pueblo fué contado, y no hubo allí varón de los moradores de Jabes-galaad. [^9] Entonces la congregación envió allá doce mil hombres de los más valientes, y mandáronles, diciendo: Id y poned á cuchillo á los moradores de Jabes-galaad, y las mujeres y niños. [^10] Mas haréis de esta manera: mataréis á todo varón, y á toda mujer que hubiere conocido ayuntamiento de varón. [^11] Y hallaron de los moradores de Jabes-galaad cuatrocientas doncellas que no habían conocido hombre en ayuntamiento de varón, y trajéronlas al campo en Silo, que es en la tierra de Canaán. [^12] Toda la congregación envió luego á hablar á los hijos de Benjamín que estaban en la peña de Rimmón, y llamáronlos en paz. [^13] Y volvieron entonces los de Benjamín; y diéronles por mujeres las que habían guardado vivas de las mujeres de Jabes-galaad: mas no les bastaron éstas. [^14] Y el pueblo tuvo dolor á causa de Benjamín, de que Jehová hubiese hecho mella en las tribus de Israel. [^15] Entonces los ancianos de la congregación dijeron: ¿Qué haremos acerca de mujeres para los que han quedado? Porque el sexo de las mujeres había sido raído de Benjamín. [^16] Y dijeron: La heredad de los que han escapado ha de ser lo que era de Benjamín, porque no sea una tribu raída de Israel. [^17] Nosotros empero, no les podemos dar mujeres de nuestras hijas, porque los hijos de Israel han jurado, diciendo: Maldito el que diere mujer á Benjamín. [^18] Ahora bien, dijeron, he aquí cada un año hay solemnidad de Jehová en Silo, que está al aquilón de Beth-el, y al lado oriental del camino que sube de Beth-el á Sichêm, y al mediodía de Lebona. [^19] Y mandaron á los hijos de Benjamín, diciendo: Id, y poned emboscada en las viñas: [^20] Y estad atentos: y cuando viereis salir las hijas de Silo á bailar en corros, vosotros saldréis de las viñas, y arrebataréis cada uno mujer para sí de las hijas de Silo, y os iréis á tierra de Benjamín: [^21] Y cuando vinieren los padres de ellas ó sus hermanos á demandárnoslo, nosotros les diremos: Tened piedad de nosotros en lugar de ellos: pues que nosotros en la guerra no tomamos mujeres para todos: que vosotros no se las habéis dado, para que ahora seáis culpables. [^22] Y los hijos de Benjamín lo hicieron así; pues tomaron mujeres conforme á su número, pillando de las que danzaban; y yéndose luego, tornáronse á su heredad, y reedificaron las ciudades, y habitaron en ellas. [^23] Entonces los hijos de Israel se fueron también de allí, cada uno á su tribu y á su familia, saliendo de allí cada uno á su heredad. [^24] En estos días no había rey en Israel: cada uno hacía lo recto delante de sus ojos. [^25] 

[[Judges - 20|<--]] Judges - 21

---
# Notes
