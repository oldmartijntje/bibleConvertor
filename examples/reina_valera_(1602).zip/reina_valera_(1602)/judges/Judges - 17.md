---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 17 - Reina Valera (1602)"
---
[[Judges - 16|<--]] Judges - 17 [[Judges - 18|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Judges]]

# Judges - 17

HUBO un hombre del monte de Ephraim, que se llamaba Michâs. [^1] El cual dijo á su madre: Los mil y cien siclos de plata que te fueron hurtados, por lo que tú maldecías oyéndolo yo, he aquí que yo tengo este dinero: yo lo había tomado. Entonces la madre dijo: Bendito seas de Jehová, hijo mío. [^2] Y luego que él hubo vuelto á su madre los mil y cien siclos de plata, su madre dijo: Yo he dedicado este dinero á Jehová de mi mano para ti, hijo mío, para que hagas una imagen de talla y de fundición: ahora pues, yo te lo devuelvo. [^3] Mas volviendo él á su madre los dineros, tomó su madre doscientos siclos de plata, y diólos al fundidor: y él le hizo de ellos una imagen de talla y de fundición, la cual fué puesta en casa de Michâs. [^4] Y tuvo este hombre Michâs casa de dioses, é hízose hacer ephod y teraphim, y consagró uno de sus hijos; y fuéle por sacerdote. [^5] En estos días no había rey en Israel: cada uno hacía como mejor le parecía. [^6] Y había un joven de Beth-lehem de Judá, de la tribu de Judá, el cual era Levita; y peregrinaba allí. [^7] Este hombre se había partido de la ciudad de Beth-lehem de Judá, para ir á vivir donde hallase; y llegando al monte de Ephraim, vino á casa de Michâs, para de allí hacer su camino. [^8] Y Michâs le dijo: ¿De dónde vienes? Y el Levita le respondió: Soy de Beth-lehem de Judá, y voy á vivir donde hallare. [^9] Entonces Michâs le dijo: Quédate en mi casa, y me serás en lugar de padre y sacerdote; y yo te daré diez siclos de plata por año, y el ordinario de vestidos, y tu comida. Y el Levita se quedó. [^10] Acordó pues el Levita en morar con aquel hombre, y él lo tenía como á uno de sus hijos. [^11] Y Michâs consagró al Levita, y aquel joven le servía de sacerdote, y estaba en casa de Michâs. [^12] Y Michâs dijo: Ahora sé que Jehová me hará bien, pues que el Levita es hecho mi sacerdote. [^13] 

[[Judges - 16|<--]] Judges - 17 [[Judges - 18|-->]]

---
# Notes
