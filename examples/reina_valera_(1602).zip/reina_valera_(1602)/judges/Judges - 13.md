---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 13 - Reina Valera (1602)"
---
[[Judges - 12|<--]] Judges - 13 [[Judges - 14|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Judges]]

# Judges - 13

Y LOS hijos de Israel tornaron á hacer lo malo en los ojos de Jehová; y Jehová los entregó en mano de los Filisteos, por cuarenta años. [^1] Y había un hombre de Sora, de la tribu de Dan, el cual se llamaba Manoa; y su mujer era estéril, que nunca había parido. [^2] A esta mujer apareció el ángel de Jehová, y díjole: He aquí que tú eres estéril, y no has parido: mas concebirás y parirás un hijo. [^3] Ahora, pues, mira que ahora no bebas vino, ni sidra, ni comas cosa inmunda. [^4] Porque tú te harás embarazada, y parirás un hijo: y no subirá navaja sobre su cabeza, porque aquel niño será Nazareo á Dios desde el vientre, y él comenzará á salvar á Israel de mano de los Filisteos. [^5] Y la mujer vino y contólo á su marido, diciendo: Un varón de Dios vino á mí, cuyo aspecto era como el aspecto de un ángel de Dios, terrible en gran manera; y no le pregunté de dónde ni quién era, ni tampoco él me dijo su nombre. [^6] Y díjome: He aquí que tú concebirás, y parirás un hijo: por tanto, ahora no bebas vino, ni sidra, ni comas cosa inmunda; porque este niño desde el vientre será Nazareo á Dios hasta el día de su muerte. [^7] Entonces oró Manoa á Jehová, y dijo: Ah, Señor mío, yo te ruego que aquel varón de Dios que enviaste, torne ahora á venir á nosotros, y nos enseñe lo que hayamos de hacer con el niño que ha de nacer. [^8] Y Dios oyó la voz de Manoa: y el ángel de Dios volvió otra vez á la mujer, estando ella en el campo; mas su marido Manoa no estaba con ella. [^9] Y la mujer corrió prontamente, y noticiólo á su marido, diciéndole: Mira que se me ha aparecido aquel varón que vino á mí el otro día. [^10] Y levantóse Manoa, y siguió á su mujer; y así que llegó al varón, díjole: ¿Eres tú aquel varón que hablaste á la mujer? Y él dijo: Yo soy. [^11] Entonces Manoa dijo: Cúmplase pues tu palabra. ¿Qué orden se tendrá con el niño, y qué ha de hacer? [^12] Y el ángel de Jehová respondió á Manoa: La mujer se guardará de todas las cosas que yo le dije: [^13] Ella no comerá cosa que proceda de vid que da vino; no beberá vino ni sidra, y no comerá cosa inmunda: ha de guardar todo lo que le mandé. [^14] Entonces Manoa dijo al ángel de Jehová: Ruégote permitas que te detengamos, y aderezaremos un cabrito que poner delante de ti. [^15] Y el ángel de Jehová respondió á Manoa: Aunque me detengas no comeré de tu pan: mas si quisieres hacer holocausto, sacrifícalo á Jehová. Y no sabía Manoa que aquél fuese ángel de Jehová. [^16] Entonces dijo Manoa al ángel de Jehová: ¿Cómo es tu nombre, para que cuando se cumpliere tu palabra te honremos? [^17] Y el ángel de Jehová respondió: ¿Por qué preguntas por mi nombre, que es oculto? [^18] Y Manoa tomó un cabrito de las cabras y un presente, y sacrificólo sobre una peña á Jehová: y el ángel hizo milagro á vista de Manoa y de su mujer. [^19] Porque aconteció que como la llama subía del altar hacia el cielo, el ángel de Jehová subió en la llama del altar á vista de Manoa y de su mujer, los cuales se postraron en tierra sobre sus rostros. [^20] Y el ángel de Jehová no tornó á aparecer á Manoa ni á su mujer. Entonces conoció Manoa que era el ángel de Jehová. [^21] Y dijo Manoa á su mujer: Ciertamente moriremos, porque á Dios hemos visto. [^22] Y su mujer le respondió: Si Jehová nos quisiera matar, no tomara de nuestras manos el holocausto y el presente, ni nos hubiera mostrado todas estas cosas, ni en tal tiempo nos habría anunciado esto. [^23] Y la mujer parió un hijo, y llamóle por nombre Samsón. Y el niño creció, y Jehová lo bendijo. [^24] Y el espíritu de Jehová comenzó á manifestarse en él en los campamentos de Dan, entre Sora y Esthaol. [^25] 

[[Judges - 12|<--]] Judges - 13 [[Judges - 14|-->]]

---
# Notes
