---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 12 - Reina Valera (1602)"
---
[[Judges - 11|<--]] Judges - 12 [[Judges - 13|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Judges]]

# Judges - 12

Y JUNTANDOSE los varones de Ephraim, pasaron hacia el aquilón, y dijeron á Jephté: ¿Por qué fuiste á hacer guerra contra los hijos de Ammón, y no nos llamaste para que fuéramos contigo? Nosotros quemaremos á fuego tu casa contigo. [^1] Y Jephté les respondió: Yo tuve, y mi pueblo, una gran contienda con los hijos de Ammón, y os llamé, y no me defendisteis de sus manos. [^2] Viendo pues que no me defendíais, puse mi alma en mi palma, y pasé contra los hijos de Ammón, y Jehová los entregó en mi mano: ¿por qué pues habéis subido hoy contra mí para pelear conmigo? [^3] Y juntando Jephté á todos los varones de Galaad, peleó contra Ephraim; y los de Galaad hirieron á Ephraim, porque habían dicho: Vosotros sois fugitivos de Ephraim, vosotros sois Galaaditas entre Ephraim y Manasés. [^4] Y los Galaaditas tomaron los vados del Jordán á Ephraim; y era que, cuando alguno de los de Ephraim que había huído, decía, ¿pasaré? los de Galaad le preguntaban: ¿Eres tú Ephrateo? Si él respondía, No; [^5] Entonces le decían: Ahora pues, di, Shiboleth. Y él decía, Siboleth; porque no podía pronunciar de aquella suerte. Entonces le echaban mano, y le degollaban junto á los vados del Jordán. Y murieron entonces de los de Ephraim cuarenta y dos mil. [^6] Y Jephté juzgó á Israel seis años: luego murió Jephté Galaadita, y fué sepultado en una de las ciudades de Galaad. [^7] Después de él juzgó á Israel Ibzan de Beth-lehem; [^8] El cual tuvo treinta hijos y treinta hijas, las cuales casó fuera, y tomó de fuera treinta hijas para sus hijos: y juzgó á Israel siete años. [^9] Y murió Ibzan, y fué sepultado en Beth-lehem. [^10] Después de él juzgó á Israel Elón, Zabulonita, el cual juzgó á Israel diez años. [^11] Y murió Elón, Zabulonita, y fué sepultado en Ajalón en la tierra de Zabulón. [^12] Después de él juzgó á Israel Abdón hijo de Hillel, Piratonita. [^13] Este tuvo cuarenta hijos y treinta nietos, que cabalgaban sobre setenta asnos: y juzgó á Israel ocho años. [^14] Y murió Abdón hijo de Hillel, Piratonita, y fué sepultado en Piratón, en la tierra de Ephraim, en el monte de Amalec. [^15] 

[[Judges - 11|<--]] Judges - 12 [[Judges - 13|-->]]

---
# Notes
