---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 10 - Reina Valera (1602)"
---
[[Judges - 9|<--]] Judges - 10 [[Judges - 11|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Judges]]

# Judges - 10

Y DESPUÉS de Abimelech levantóse para librar á Israel, Tola hijo de Púa, hijo de Dodo, varón de Issachâr, el cual habitaba en Samir, en el monte de Ephraim. [^1] Y juzgó á Israel veintitrés años, y murió, y fué sepultado en Samir. [^2] Tras él se levantó Jair, Galaadita, el cual juzgó á Israel veintidós años. [^3] Este tuvo treinta hijos que cabalgaban sobre treinta asnos, y tenían treinta villas, que se llamaron las villas de Jair hasta hoy, las cuales están en la tierra de Galaad. [^4] Y murió Jair, y fué sepultado en Camón. [^5] Mas los hijos de Israel tornaron á hacer lo malo en los ojos de Jehová, y sirvieron á los Baales y á Astaroth, y á los dioses de Siria, y á los dioses de Sidón, y á los dioses de Moab, y á los dioses de los hijos de Ammón, y á los dioses de los Filisteos: y dejaron á Jehová, y no le sirvieron. [^6] Y Jehová se airó contra Israel, y vendiólos en mano de los Filisteos, y en mano de los hijos de Ammón: [^7] Los cuales molieron y quebrantaron á los hijos de Israel en aquel tiempo dieciocho años, á todos los hijos de Israel que estaban de la otra parte del Jordán en la tierra del Amorrheo, que es en Galaad. [^8] Y los hijos de Ammón pasaron el Jordán para hacer también guerra contra Judá, y contra Benjamín, y la casa de Ephraim: y fué Israel en gran manera afligido. [^9] Y los hijos de Israel clamaron á Jehová, diciendo: Nosotros hemos pecado contra ti; porque hemos dejado á nuestro Dios, y servido á los Baales. [^10] Y Jehová respondió á los hijos de Israel: ¿No habéis sido oprimidos de Egipto, de los Amorrheos, de Losammonitas, de los Filisteos, [^11] De los de Sidón, de Amalec, y de Maón, y clamando á mí os he librado de sus manos? [^12] Mas vosotros me habéis dejado, y habéis servido á dioses ajenos: por tanto, yo no os libraré más. [^13] Andad, y clamad á los dioses que os habéis elegido, que os libren en el tiempo de vuestra aflicción. [^14] Y los hijos de Israel respondieron á Jehová: Hemos pecado; haz tú con nosotros como bien te pareciere: solamente que ahora nos libres en este día. [^15] Y quitaron de entre sí los dioses ajenos, y sirvieron á Jehová: y su alma fué angustiada á causa del trabajo de Israel. [^16] Y juntándose los hijos de Ammón, asentaron campo en Galaad: juntáronse asimismo los hijos de Israel, y asentaron su campo en Mizpa. [^17] Y los príncipes y el pueblo de Galaad dijeron el uno al otro: ¿Quién será el que comenzará la batalla contra los hijos de Ammón? él será cabeza sobre todos los que habitan en Galaad. [^18] 

[[Judges - 9|<--]] Judges - 10 [[Judges - 11|-->]]

---
# Notes
