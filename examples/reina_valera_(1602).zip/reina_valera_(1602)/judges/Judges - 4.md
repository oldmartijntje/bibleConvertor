---
translation: Reina Valera (1602)
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 4 - Reina Valera (1602)"
---
[[Judges - 3|<--]] Judges - 4 [[Judges - 5|-->]]

Translation: [[bible - Reina Valera (1602)|Reina Valera (1602)]]
Book: [[Judges]]

# Judges - 4

MAS los hijos de Israel tornaron á hacer lo malo en ojos de Jehová, después de la muerte de Aod. [^1] Y Jehová los vendió en mano de Jabín rey de Canaán, el cual reinó en Asor: y el capitán de su ejército se llamaba Sísara, y él habitaba en Haroseth de las Gentes. [^2] Y los hijos de Israel clamaron á Jehová, porque aquél tenía nuevecientos carros herrados: y había afligido en gran manera á los hijos de Israel por veinte años. [^3] Y gobernaba en aquel tiempo á Israel una mujer, Débora, profetisa, mujer de Lapidoth: [^4] La cual Débora habitaba debajo de una palma entre Rama y Beth-el, en el monte de Ephraim: y los hijos de Israel subían á ella á juicio. [^5] Y ella envió á llamar á Barac hijo de Abinoam, de Cedes de Nephtalí, y díjole: ¿No te ha mandado Jehová Dios de Israel, diciendo: Ve, y haz gente en el monte de Tabor, y toma contigo diez mil hombres de los hijos de Nephtalí, y de los hijos de Zabulón: [^6] Y yo atraeré á ti al arroyo de Cisón á Sísara, capitán del ejército de Jabín, con sus carros y su ejército, y entregarélo en tus manos? [^7] Y Barac le respondió: Si tú fueres conmigo, yo iré: pero si no fueres conmigo, no iré. [^8] Y ella dijo: Iré contigo; mas no será tu honra en el camino que vas; porque en mano de mujer venderá Jehová á Sísara. Y levantándose Débora fué con Barac á Cedes. [^9] Y juntó Barac á Zabulón y á Nephtalí en Cedes, y subió con diez mil hombres á su mando, y Débora subió con él. [^10] Y Heber Cineo, de los hijos de Hobab suegro de Moisés, se había apartado de los Cineos, y puesto su tienda hasta el valle de Zaananim, que está junto á Cedes. [^11] Vinieron pues las nuevas á Sísara como Barac hijo de Abinoam había subido al monte de Tabor. [^12] Y reunió Sísara todos sus carros, nuevecientos carros herrados, con todo el pueblo que con él estaba, desde Haroseth de las Gentes hasta el arroyo de Cisón. [^13] Entonces Débora dijo á Barac: Levántate; porque este es el día en que Jehová ha entregado á Sísara en tus manos: ¿No ha salido Jehová delante de ti? Y Barac descendió del monte de Tabor, y diez mil hombres en pos de él. [^14] Y Jehová desbarató á Sísara, y á todos sus carros y á todo su ejército, á filo de espada delante de Barac: y Sísara descendió del carro, y huyó á pie. [^15] Mas Barac siguió los carros y el ejército hasta Haroseth de las Gentes, y todo el ejército de Sísara cayó á filo de espada hasta no quedar ni uno. [^16] Y Sísara se acogió á pie á la tienda de Jael mujer de Heber Cineo; porque había paz entre Jabín rey de Asor y la casa de Heber Cineo. [^17] Y saliendo Jael á recibir á Sísara, díjole: Ven, señor mío, ven á mi, no tengas temor. Y él vino á ella á la tienda, y ella le cubrió con una manta. [^18] Y él le dijo: Ruégote me des á beber una poca de agua, que tengo sed. Y ella abrió un odre de leche y dióle de beber, y tornóle á cubrir. [^19] Y él le dijo: Estáte á la puerta de la tienda, y si alguien viniere, y te preguntare, diciendo: ¿Hay aquí alguno? Tú responderás que no. [^20] Y Jael, mujer de Heber, tomó una estaca de la tienda, y poniendo un mazo en su mano, vino á él calladamente, y metióle la estaca por las sienes, y enclavólo en la tierra, pues él estaba cargado de sueño y cansado; y así murió. [^21] Y siguiendo Barac á Sísara, Jael salió á recibirlo, y díjole: Ven, y te mostraré al varón que tú buscas. Y él entró donde ella estaba, y he aquí Sísara yacía muerto con la estaca por la sien. [^22] Así abatió Dios aquel día á Jabín, rey de Canaán, delante de los hijos de Israel. [^23] Y la mano de los hijos de Israel comenzó á crecer y á fortificarse contra Jabín rey de Canaán, hasta que lo destruyeron. [^24] 

[[Judges - 3|<--]] Judges - 4 [[Judges - 5|-->]]

---
# Notes
