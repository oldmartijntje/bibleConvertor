---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_kings"
  - "#bible/testament/old"
aliases:
  - "1 Kings - 5 - American Standard Version"
---
[[1 Kings - 4|<--]] 1 Kings - 5 [[1 Kings - 6|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[1 Kings]]

# 1 Kings - 5

And Hiram king of Tyre sent his servants unto Solomon; for he had heard that they had anointed him king in the room of his father: for Hiram was ever a lover of David. [^1] And Solomon sent to Hiram, saying, [^2] Thou knowest how that David my father could not build a house for the name of Jehovah his God for the wars which were about him on every side, until Jehovah put them under the soles of his feet. [^3] But now Jehovah my God hath given me rest on every side; there is neither adversary, nor evil occurrence. [^4] And, behold, I purpose to build a house for the name of Jehovah my God, as Jehovah spake unto David my father, saying, Thy son, whom I will set upon thy throne in thy room, he shall build the house for my name. [^5] Now therefore command thou that they cut me cedar-trees out of Lebanon; and my servants shall be with thy servants; and I will give thee hire for thy servants according to all that thou shalt say: for thou knowest that there is not among us any that knoweth how to cut timber like unto the Sidonians. [^6] And it came to pass, when Hiram heard the words of Solomon, that he rejoiced greatly, and said, Blessed be Jehovah this day, who hath given unto David a wise son over this great people. [^7] And Hiram sent to Solomon, saying, I have heard the message which thou hast sent unto me: I will do all thy desire concerning timber of cedar, and concerning timber of fir. [^8] My servants shall bring them down from Lebanon unto the sea; and I will make them into rafts to go by sea unto the place that thou shalt appoint me, and will cause them to be broken up there, and thou shalt receive them; and thou shalt accomplish my desire, in giving food for my household. [^9] So Hiram gave Solomon timber of cedar and timber of fir according to all his desire. [^10] And Solomon gave Hiram twenty thousand measures of wheat for food to his household, and twenty measures of pure oil: thus gave Solomon to Hiram year by year. [^11] And Jehovah gave Solomon wisdom, as he promised him; and there was peace between Hiram and Solomon; and they two made a league together. [^12] And king Solomon raised a levy out of all Israel; and the levy was thirty thousand men. [^13] And he sent them to Lebanon, ten thousand a month by courses; a month they were in Lebanon, and two months at home: and Adoniram was over the men subject to taskwork. [^14] And Solomon had threescore and ten thousand that bare burdens, and fourscore thousand that were hewers in the mountains; [^15] besides Solomon’s chief officers that were over the work, three thousand and three hundred, who bare rule over the people that wrought in the work. [^16] And the king commanded, and they hewed out great stones, costly stones, to lay the foundation of the house with wrought stone. [^17] And Solomon’s builders and Hiram’s builders and the Gebalites did fashion them, and prepared the timber and the stones to build the house. [^18] 

[[1 Kings - 4|<--]] 1 Kings - 5 [[1 Kings - 6|-->]]

---
# Notes
