---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_kings"
  - "#bible/testament/old"
aliases:
  - "1 Kings - 17 - American Standard Version"
---
[[1 Kings - 16|<--]] 1 Kings - 17 [[1 Kings - 18|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[1 Kings]]

# 1 Kings - 17

And Elijah the Tishbite, who was of the sojourners of Gilead, said unto Ahab, As Jehovah, the God of Israel, liveth, before whom I stand, there shall not be dew nor rain these years, but according to my word. [^1] And the word of Jehovah came unto him, saying, [^2] Get thee hence, and turn thee eastward, and hide thyself by the brook Cherith, that is before the Jordan. [^3] And it shall be, that thou shalt drink of the brook; and I have commanded the ravens to feed thee there. [^4] So he went and did according unto the word of Jehovah; for he went and dwelt by the brook Cherith, that is before the Jordan. [^5] And the ravens brought him bread and flesh in the morning, and bread and flesh in the evening; and he drank of the brook. [^6] And it came to pass after a while, that the brook dried up, because there was no rain in the land. [^7] And the word of Jehovah came unto him, saying, [^8] Arise, get thee to Zarephath, which belongeth to Sidon, and dwell there: behold, I have commanded a widow there to sustain thee. [^9] So he arose and went to Zarephath; and when he came to the gate of the city, behold, a widow was there gathering sticks: and he called to her, and said, Fetch me, I pray thee, a little water in a vessel, that I may drink. [^10] And as she was going to fetch it, he called to her, and said, Bring me, I pray thee, a morsel of bread in thy hand. [^11] And she said, As Jehovah thy God liveth, I have not a cake, but a handful of meal in the jar, and a little oil in the cruse: and, behold, I am gathering two sticks, that I may go in and dress it for me and my son, that we may eat it, and die. [^12] And Elijah said unto her, Fear not; go and do as thou hast said; but make me thereof a little cake first, and bring it forth unto me, and afterward make for thee and for thy son. [^13] For thus saith Jehovah, the God of Israel, The jar of meal shall not waste, neither shall the cruse of oil fail, until the day that Jehovah sendeth rain upon the earth. [^14] And she went and did according to the saying of Elijah: and she, and he, and her house, did eat many days. [^15] The jar of meal wasted not, neither did the cruse of oil fail, according to the word of Jehovah, which he spake by Elijah. [^16] And it came to pass after these things, that the son of the woman, the mistress of the house, fell sick; and his sickness was so sore, that there was no breath left in him. [^17] And she said unto Elijah, What have I to do with thee, O thou man of God? thou art come unto me to bring my sin to remembrance, and to slay my son! [^18] And he said unto her, Give me thy son. And he took him out of her bosom, and carried him up into the chamber, where he abode, and laid him upon his own bed. [^19] And he cried unto Jehovah, and said, O Jehovah my God, hast thou also brought evil upon the widow with whom I sojourn, by slaying her son? [^20] And he stretched himself upon the child three times, and cried unto Jehovah, and said, O Jehovah my God, I pray thee, let this child’s soul come into him again. [^21] And Jehovah hearkened unto the voice of Elijah; and the soul of the child came into him again, and he revived. [^22] And Elijah took the child, and brought him down out of the chamber into the house, and delivered him unto his mother; and Elijah said, See, thy son liveth. [^23] And the woman said to Elijah, Now I know that thou art a man of God, and that the word of Jehovah in thy mouth is truth. [^24] 

[[1 Kings - 16|<--]] 1 Kings - 17 [[1 Kings - 18|-->]]

---
# Notes
