---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 10 - American Standard Version"
---
[[Judges - 9|<--]] Judges - 10 [[Judges - 11|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Judges]]

# Judges - 10

And after Abimelech there arose to save Israel Tola the son of Puah, the son of Dodo, a man of Issachar; and he dwelt in Shamir in the hill-country of Ephraim. [^1] And he judged Israel twenty and three years, and died, and was buried in Shamir. [^2] And after him arose Jair, the Gileadite; and he judged Israel twenty and two years. [^3] And he had thirty sons that rode on thirty ass colts, and they had thirty cities, which are called Havvoth-jair unto this day, which are in the land of Gilead. [^4] And Jair died, and was buried in Kamon. [^5] And the children of Israel again did that which was evil in the sight of Jehovah, and served the Baalim, and the Ashtaroth, and the gods of Syria, and the gods of Sidon, and the gods of Moab, and the gods of the children of Ammon, and the gods of the Philistines; and they forsook Jehovah, and served him not. [^6] And the anger of Jehovah was kindled against Israel, and he sold them into the hand of the Philistines, and into the hand of the children of Ammon. [^7] And they vexed and oppressed the children of Israel that year: eighteen years oppressed they all the children of Israel that were beyond the Jordan in the land of the Amorites, which is in Gilead. [^8] And the children of Ammon passed over the Jordan to fight also against Judah, and against Benjamin, and against the house of Ephraim; so that Israel was sore distressed. [^9] And the children of Israel cried unto Jehovah, saying, We have sinned against thee, even because we have forsaken our God, and have served the Baalim. [^10] And Jehovah said unto the children of Israel, Did not I save you from the Egyptians, and from the Amorites, from the children of Ammon, and from the Philistines? [^11] The Sidonians also, and the Amalekites, and the Maonites, did oppress you; and ye cried unto me, and I saved you out of their hand. [^12] Yet ye have forsaken me, and served other gods: wherefore I will save you no more. [^13] Go and cry unto the gods which ye have chosen; let them save you in the time of your distress. [^14] And the children of Israel said unto Jehovah, We have sinned: do thou unto us whatsoever seemeth good unto thee; only deliver us, we pray thee, this day. [^15] And they put away the foreign gods from among them, and served Jehovah; and his soul was grieved for the misery of Israel. [^16] Then the children of Ammon were gathered together, and encamped in Gilead. And the children of Israel assembled themselves together, and encamped in Mizpah. [^17] And the people, the princes of Gilead, said one to another, What man is he that will begin to fight against the children of Ammon? he shall be head over all the inhabitants of Gilead. [^18] 

[[Judges - 9|<--]] Judges - 10 [[Judges - 11|-->]]

---
# Notes
