---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 14 - American Standard Version"
---
[[Judges - 13|<--]] Judges - 14 [[Judges - 15|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Judges]]

# Judges - 14

And Samson went down to Timnah, and saw a woman in Timnah of the daughters of the Philistines. [^1] And he came up, and told his father and his mother, and said, I have seen a woman in Timnah of the daughters of the Philistines: now therefore get her for me to wife. [^2] Then his father and his mother said unto him, Is there never a woman among the daughters of thy brethren, or among all my people, that thou goest to take a wife of the uncircumcised Philistines? And Samson said unto his father, Get her for me; for she pleaseth me well. [^3] But his father and his mother knew not that it was of Jehovah; for he sought an occasion against the Philistines. Now at that time the Philistines had rule over Israel. [^4] Then went Samson down, and his father and his mother, to Timnah, and came to the vineyards of Timnah: and, behold, a young lion roared against him. [^5] And the Spirit of Jehovah came mightily upon him, and he rent him as he would have rent a kid; and he had nothing in his hand: but he told not his father or his mother what he had done. [^6] And he went down, and talked with the woman, and she pleased Samson well. [^7] And after a while he returned to take her; and he turned aside to see the carcass of the lion: and, behold, there was a swarm of bees in the body of the lion, and honey. [^8] And he took it into his hands, and went on, eating as he went; and he came to his father and mother, and gave unto them, and they did eat: but he told them not that he had taken the honey out of the body of the lion. [^9] And his father went down unto the woman: and Samson made there a feast; for so used the young men to do. [^10] And it came to pass, when they saw him, that they brought thirty companions to be with him. [^11] And Samson said unto them, Let me now put forth a riddle unto you: if ye can declare it unto me within the seven days of the feast, and find it out, then I will give you thirty linen garments and thirty changes of raiment; [^12] but if ye cannot declare it unto me, then shall ye give me thirty linen garments and thirty changes of raiment. And they said unto him, Put forth thy riddle, that we may hear it. [^13] And he said unto them,Out of the eater came forth food,And out of the strong came forth sweetness.And they could not in three days declare the riddle. [^14] And it came to pass on the seventh day, that they said unto Samson’s wife, Entice thy husband, that he may declare unto us the riddle, lest we burn thee and thy father’s house with fire: have ye called us to impoverish us? is it not so? [^15] And Samson’s wife wept before him, and said, Thou dost but hate me, and lovest me not: thou hast put forth a riddle unto the children of my people, and hast not told it me. And he said unto her, Behold, I have not told it my father nor my mother, and shall I tell thee? [^16] And she wept before him the seven days, while their feast lasted: and it came to pass on the seventh day, that he told her, because she pressed him sore; and she told the riddle to the children of her people. [^17] And the men of the city said unto him on the seventh day before the sun went down, What is sweeter than honey? and what is stronger than a lion? And he said unto them,If ye had not plowed with my heifer,Ye had not found out my riddle. [^18] And the Spirit of Jehovah came mightily upon him, and he went down to Ashkelon, and smote thirty men of them, and took their spoil, and gave the changes of raiment unto them that declared the riddle. And his anger was kindled, and he went up to his father’s house. [^19] But Samson’s wife was given to his companion, whom he had used as his friend. [^20] 

[[Judges - 13|<--]] Judges - 14 [[Judges - 15|-->]]

---
# Notes
