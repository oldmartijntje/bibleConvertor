---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 17 - American Standard Version"
---
[[Judges - 16|<--]] Judges - 17 [[Judges - 18|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Judges]]

# Judges - 17

And there was a man of the hill-country of Ephraim, whose name was Micah. [^1] And he said unto his mother, The eleven hundred pieces of silver that were taken from thee, about which thou didst utter a curse, and didst also speak it in mine ears, behold, the silver is with me; I took it. And his mother said, Blessed be my son of Jehovah. [^2] And he restored the eleven hundred pieces of silver to his mother; and his mother said, I verily dedicate the silver unto Jehovah from my hand for my son, to make a graven image and a molten image: now therefore I will restore it unto thee. [^3] And when he restored the money unto his mother, his mother took two hundred pieces of silver, and gave them to the founder, who made thereof a graven image and a molten image: and it was in the house of Micah. [^4] And the man Micah had a house of gods, and he made an ephod, and teraphim, and consecrated one of his sons, who became his priest. [^5] In those days there was no king in Israel: every man did that which was right in his own eyes. [^6] And there was a young man out of Beth-lehem-judah, of the family of Judah, who was a Levite; and he sojourned there. [^7] And the man departed out of the city, out of Beth-lehem-judah, to sojourn where he could find a place, and he came to the hill-country of Ephraim to the house of Micah, as he journeyed. [^8] And Micah said unto him, Whence comest thou? And he said unto him, I am a Levite of Beth-lehem-judah, and I go to sojourn where I may find a place. [^9] And Micah said unto him, Dwell with me, and be unto me a father and a priest, and I will give thee ten pieces of silver by the year, and a suit of apparel, and thy victuals. So the Levite went in. [^10] And the Levite was content to dwell with the man; and the young man was unto him as one of his sons. [^11] And Micah consecrated the Levite, and the young man became his priest, and was in the house of Micah. [^12] Then said Micah, Now know I that Jehovah will do me good, seeing I have a Levite to my priest. [^13] 

[[Judges - 16|<--]] Judges - 17 [[Judges - 18|-->]]

---
# Notes
