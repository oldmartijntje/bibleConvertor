---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 2 - American Standard Version"
---
[[Judges - 1|<--]] Judges - 2 [[Judges - 3|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Judges]]

# Judges - 2

And the angel of Jehovah came up from Gilgal to Bochim. And he said, I made you to go up out of Egypt, and have brought you unto the land which I sware unto your fathers; and I said, I will never break my covenant with you: [^1] and ye shall make no covenant with the inhabitants of this land; ye shall break down their altars. But ye have not hearkened unto my voice: why have ye done this? [^2] Wherefore I also said, I will not drive them out from before you; but they shall be as thorns in your sides, and their gods shall be a snare unto you. [^3] And it came to pass, when the angel of Jehovah spake these words unto all the children of Israel, that the people lifted up their voice, and wept. [^4] And they called the name of that place Bochim: and they sacrificed there unto Jehovah. [^5] Now when Joshua had sent the people away, the children of Israel went every man unto his inheritance to possess the land. [^6] And the people served Jehovah all the days of Joshua, and all the days of the elders that outlived Joshua, who had seen all the great work of Jehovah that he had wrought for Israel. [^7] And Joshua the son of Nun, the servant of Jehovah, died, being a hundred and ten years old. [^8] And they buried him in the border of his inheritance in Timnath-heres, in the hill-country of Ephraim, on the north of the mountain of Gaash. [^9] And also all that generation were gathered unto their fathers: and there arose another generation after them, that knew not Jehovah, nor yet the work which he had wrought for Israel. [^10] And the children of Israel did that which was evil in the sight of Jehovah, and served the Baalim; [^11] and they forsook Jehovah, the God of their fathers, who brought them out of the land of Egypt, and followed other gods, of the gods of the peoples that were round about them, and bowed themselves down unto them: and they provoked Jehovah to anger. [^12] And they forsook Jehovah, and served Baal and the Ashtaroth. [^13] And the anger of Jehovah was kindled against Israel, and he delivered them into the hands of spoilers that despoiled them; and he sold them into the hands of their enemies round about, so that they could not any longer stand before their enemies. [^14] Whithersoever they went out, the hand of Jehovah was against them for evil, as Jehovah had spoken, and as Jehovah had sworn unto them: and they were sore distressed. [^15] And Jehovah raised up judges, who saved them out of the hand of those that despoiled them. [^16] And yet they hearkened not unto their judges; for they played the harlot after other gods, and bowed themselves down unto them: they turned aside quickly out of the way wherein their fathers walked, obeying the commandments of Jehovah; but they did not so. [^17] And when Jehovah raised them up judges, then Jehovah was with the judge, and saved them out of the hand of their enemies all the days of the judge: for it repented Jehovah because of their groaning by reason of them that oppressed them and vexed them. [^18] But it came to pass, when the judge was dead, that they turned back, and dealt more corruptly than their fathers, in following other gods to serve them, and to bow down unto them; they ceased not from their doings, nor from their stubborn way. [^19] And the anger of Jehovah was kindled against Israel; and he said, Because this nation have transgressed my covenant which I commanded their fathers, and have not hearkened unto my voice; [^20] I also will not henceforth drive out any from before them of the nations that Joshua left when he died; [^21] that by them I may prove Israel, whether they will keep the way of Jehovah to walk therein, as their fathers did keep it, or not. [^22] So Jehovah left those nations, without driving them out hastily; neither delivered he them into the hand of Joshua. [^23] 

[[Judges - 1|<--]] Judges - 2 [[Judges - 3|-->]]

---
# Notes
