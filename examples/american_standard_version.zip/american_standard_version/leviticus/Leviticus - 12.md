---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 12 - American Standard Version"
---
[[Leviticus - 11|<--]] Leviticus - 12 [[Leviticus - 13|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Leviticus]]

# Leviticus - 12

And Jehovah spake unto Moses, saying, [^1] Speak unto the children of Israel, saying, If a woman conceive seed, and bear a man-child, then she shall be unclean seven days; as in the days of the impurity of her sickness shall she be unclean. [^2] And in the eighth day the flesh of his foreskin shall be circumcised. [^3] And she shall continue in the blood of her purifying three and thirty days; she shall touch no hallowed thing, nor come into the sanctuary, until the days of her purifying be fulfilled. [^4] But if she bear a maid-child, then she shall be unclean two weeks, as in her impurity; and she shall continue in the blood of her purifying threescore and six days. [^5] And when the days of her purifying are fulfilled, for a son, or for a daughter, she shall bring a lamb a year old for a burnt-offering, and a young pigeon, or a turtle-dove, for a sin-offering, unto the door of the tent of meeting, unto the priest: [^6] and he shall offer it before Jehovah, and make atonement for her; and she shall be cleansed from the fountain of her blood. This is the law for her that beareth, whether a male or a female. [^7] And if her means suffice not for a lamb, then she shall take two turtle-doves, or two young pigeons; the one for a burnt-offering, and the other for a sin-offering: and the priest shall make atonement for her, and she shall be clean. [^8] 

[[Leviticus - 11|<--]] Leviticus - 12 [[Leviticus - 13|-->]]

---
# Notes
