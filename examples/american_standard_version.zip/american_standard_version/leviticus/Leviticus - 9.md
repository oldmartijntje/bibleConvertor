---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 9 - American Standard Version"
---
[[Leviticus - 8|<--]] Leviticus - 9 [[Leviticus - 10|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Leviticus]]

# Leviticus - 9

And it came to pass on the eighth day, that Moses called Aaron and his sons, and the elders of Israel; [^1] and he said unto Aaron, Take thee a calf of the herd for a sin-offering, and a ram for a burnt-offering, without blemish, and offer them before Jehovah. [^2] And unto the children of Israel thou shalt speak, saying, Take ye a he-goat for a sin-offering; and a calf and a lamb, both a year old, without blemish, for a burnt-offering; [^3] and an ox and a ram for peace-offerings, to sacrifice before Jehovah; and a meal-offering mingled with oil: for to-day Jehovah appeareth unto you. [^4] And they brought that which Moses commanded before the tent of meeting: and all the congregation drew near and stood before Jehovah. [^5] And Moses said, This is the thing which Jehovah commanded that ye should do: and the glory of Jehovah shall appear unto you. [^6] And Moses said unto Aaron, Draw near unto the altar, and offer thy sin-offering, and thy burnt-offering, and make atonement for thyself, and for the people; and offer the oblation of the people, and make atonement for them; as Jehovah commanded. [^7] So Aaron drew near unto the altar, and slew the calf of the sin-offering, which was for himself. [^8] And the sons of Aaron presented the blood unto him; and he dipped his finger in the blood, and put it upon the horns of the altar, and poured out the blood at the base of the altar: [^9] but the fat, and the kidneys, and the caul from the liver of the sin-offering, he burnt upon the altar; as Jehovah commanded Moses. [^10] And the flesh and the skin he burnt with fire without the camp. [^11] And he slew the burnt-offering; and Aaron’s sons delivered unto him the blood, and he sprinkled it upon the altar round about. [^12] And they delivered the burnt-offering unto him, piece by piece, and the head: and he burnt them upon the altar. [^13] And he washed the inwards and the legs, and burnt them upon the burnt-offering on the altar. [^14] And he presented the people’s oblation, and took the goat of the sin-offering which was for the people, and slew it, and offered it for sin, as the first. [^15] And he presented the burnt-offering, and offered it according to the ordinance. [^16] And he presented the meal-offering, and filled his hand therefrom, and burnt it upon the altar, besides the burnt-offering of the morning. [^17] He slew also the ox and the ram, the sacrifice of peace-offerings, which was for the people: and Aaron’s sons delivered unto him the blood, which he sprinkled upon the altar round about, [^18] and the fat of the ox and of the ram, the fat tail, and that which covereth the inwards, and the kidneys, and the caul of the liver: [^19] and they put the fat upon the breasts, and he burnt the fat upon the altar: [^20] and the breasts and the right thigh Aaron waved for a wave-offering before Jehovah; as Moses commanded. [^21] And Aaron lifted up his hands toward the people, and blessed them; and he came down from offering the sin-offering, and the burnt-offering, and the peace-offerings. [^22] And Moses and Aaron went into the tent of meeting, and came out, and blessed the people: and the glory of Jehovah appeared unto all the people. [^23] And there came forth fire from before Jehovah, and consumed upon the altar the burnt-offering and the fat: and when all the people saw it, they shouted, and fell on their faces. [^24] 

[[Leviticus - 8|<--]] Leviticus - 9 [[Leviticus - 10|-->]]

---
# Notes
