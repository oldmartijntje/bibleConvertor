---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 1 - American Standard Version"
---
Leviticus - 1 [[Leviticus - 2|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Leviticus]]

# Leviticus - 1

And Jehovah called unto Moses, and spake unto him out of the tent of meeting, saying, [^1] Speak unto the children of Israel, and say unto them, When any man of you offereth an oblation unto Jehovah, ye shall offer your oblation of the cattle, even of the herd and of the flock. [^2] If his oblation be a burnt-offering of the herd, he shall offer it a male without blemish: he shall offer it at the door of the tent of meeting, that he may be accepted before Jehovah. [^3] And he shall lay his hand upon the head of the burnt-offering; and it shall be accepted for him to make atonement for him. [^4] And he shall kill the bullock before Jehovah: and Aaron’s sons, the priests, shall present the blood, and sprinkle the blood round about upon the altar that is at the door of the tent of meeting. [^5] And he shall flay the burnt-offering, and cut it into its pieces. [^6] And the sons of Aaron the priest shall put fire upon the altar, and lay wood in order upon the fire; [^7] and Aaron’s sons, the priests, shall lay the pieces, the head, and the fat, in order upon the wood that is on the fire which is upon the altar: [^8] but its inwards and its legs shall he wash with water. And the priest shall burn the whole on the altar, for a burnt-offering, an offering made by fire, of a sweet savor unto Jehovah. [^9] And if his oblation be of the flock, of the sheep, or of the goats, for a burnt-offering; he shall offer it a male without blemish. [^10] And he shall kill it on the side of the altar northward before Jehovah: and Aaron’s sons, the priests, shall sprinkle its blood upon the altar round about. [^11] And he shall cut it into its pieces, with its head and its fat; and the priest shall lay them in order on the wood that is on the fire which is upon the altar: [^12] but the inwards and the legs shall he wash with water. And the priest shall offer the whole, and burn it upon the altar: it is a burnt-offering, an offering made by fire, of a sweet savor unto Jehovah. [^13] And if his oblation to Jehovah be a burnt-offering of birds, then he shall offer his oblation of turtle-doves, or of young pigeons. [^14] And the priest shall bring it unto the altar, and wring off its head, and burn it on the altar; and the blood thereof shall be drained out on the side of the altar; [^15] and he shall take away its crop with the filth thereof, and cast it beside the altar on the east part, in the place of the ashes: [^16] and he shall rend it by the wings thereof, but shall not divide it asunder. And the priest shall burn it upon the altar, upon the wood that is upon the fire: it is a burnt-offering, an offering made by fire, of a sweet savor unto Jehovah. [^17] 

Leviticus - 1 [[Leviticus - 2|-->]]

---
# Notes
