---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 24 - American Standard Version"
---
[[Leviticus - 23|<--]] Leviticus - 24 [[Leviticus - 25|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Leviticus]]

# Leviticus - 24

And Jehovah spake unto Moses, saying, [^1] Command the children of Israel, that they bring unto thee pure olive oil beaten for the light, to cause a lamp to burn continually. [^2] Without the veil of the testimony, in the tent of meeting, shall Aaron keep it in order from evening to morning before Jehovah continually: it shall be a statute for ever throughout your generations. [^3] He shall keep in order the lamps upon the pure candlestick before Jehovah continually. [^4] And thou shalt take fine flour, and bake twelve cakes thereof: two tenth parts of an ephah shall be in one cake. [^5] And thou shalt set them in two rows, six on a row, upon the pure table before Jehovah. [^6] And thou shalt put pure frankincense upon each row, that it may be to the bread for a memorial, even an offering made by fire unto Jehovah. [^7] Every sabbath day he shall set it in order before Jehovah continually; it is on the behalf of the children of Israel, an everlasting covenant. [^8] And it shall be for Aaron and his sons; and they shall eat it in a holy place: for it is most holy unto him of the offerings of Jehovah made by fire by a perpetual statute. [^9] And the son of an Israelitish woman, whose father was an Egyptian, went out among the children of Israel; and the son of the Israelitish woman and a man of Israel strove together in the camp: [^10] and the son of the Israelitish woman blasphemed the Name, and cursed; and they brought him unto Moses. And his mother’s name was Shelomith, the daughter of Dibri, of the tribe of Dan. [^11] And they put him in ward, that it might be declared unto them at the mouth of Jehovah. [^12] And Jehovah spake unto Moses, saying, [^13] Bring forth him that hath cursed without the camp; and let all that heard him lay their hands upon his head, and let all the congregation stone him. [^14] And thou shalt speak unto the children of Israel, saying, Whosoever curseth his God shall bear his sin. [^15] And he that blasphemeth the name of Jehovah, he shall surely be put to death; all the congregation shall certainly stone him: as well the sojourner, as the home-born, when he blasphemeth the name of Jehovah, shall be put to death. [^16] And he that smiteth any man mortally shall surely be put to death. [^17] And he that smiteth a beast mortally shall make it good, life for life. [^18] And if a man cause a blemish in his neighbor; as he hath done, so shall it be done to him: [^19] breach for breach, eye for eye, tooth for tooth; as he hath caused a blemish in a man, so shall it be rendered unto him. [^20] And he that killeth a beast shall make it good: and he that killeth a man shall be put to death. [^21] Ye shall have one manner of law, as well for the sojourner, as for the home-born: for I am Jehovah your God. [^22] And Moses spake to the children of Israel; and they brought forth him that had cursed out of the camp, and stoned him with stones. And the children of Israel did as Jehovah commanded Moses. [^23] 

[[Leviticus - 23|<--]] Leviticus - 24 [[Leviticus - 25|-->]]

---
# Notes
