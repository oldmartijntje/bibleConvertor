---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 18 - American Standard Version"
---
[[Leviticus - 17|<--]] Leviticus - 18 [[Leviticus - 19|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Leviticus]]

# Leviticus - 18

And Jehovah spake unto Moses, saying, [^1] Speak unto the children of Israel, and say unto them, I am Jehovah your God. [^2] After the doings of the land of Egypt, wherein ye dwelt, shall ye not do: and after the doings of the land of Canaan, whither I bring you, shall ye not do; neither shall ye walk in their statutes. [^3] Mine ordinances shall ye do, and my statutes shall ye keep, to walk therein: I am Jehovah your God. [^4] Ye shall therefore keep my statutes, and mine ordinances; which if a man do, he shall live in them: I am Jehovah. [^5] None of you shall approach to any that are near of kin to him, to uncover their nakedness: I am Jehovah. [^6] The nakedness of thy father, even the nakedness of thy mother, shalt thou not uncover: she is thy mother; thou shalt not uncover her nakedness. [^7] The nakedness of thy father’s wife shalt thou not uncover; it is thy father’s nakedness. [^8] The nakedness of thy sister, the daughter of thy father, or the daughter of thy mother, whether born at home, or born abroad, even their nakedness thou shalt not uncover. [^9] The nakedness of thy son’s daughter, or of thy daughter’s daughter, even their nakedness thou shalt not uncover: for theirs is thine own nakedness. [^10] The nakedness of thy father’s wife’s daughter, begotten of thy father, she is thy sister, thou shalt not uncover her nakedness. [^11] Thou shalt not uncover the nakedness of thy father’s sister: she is thy father’s near kinswoman. [^12] Thou shalt not uncover the nakedness of thy mother’s sister: for she is thy mother’s near kinswoman. [^13] Thou shalt not uncover the nakedness of thy father’s brother, thou shalt not approach to his wife: she is thine aunt. [^14] Thou shalt not uncover the nakedness of thy daughter-in-law: she is thy son’s wife; thou shalt not uncover her nakedness. [^15] Thou shalt not uncover the nakedness of thy brother’s wife: it is thy brother’s nakedness. [^16] Thou shalt not uncover the nakedness of a woman and her daughter; thou shalt not take her son’s daughter, or her daughter’s daughter, to uncover her nakedness; they are near kinswomen: it is wickedness. [^17] And thou shalt not take a wife to her sister, to be a rival to her, to uncover her nakedness, besides the other in her life-time. [^18] And thou shalt not approach unto a woman to uncover her nakedness, as long as she is impure by her uncleanness. [^19] And thou shalt not lie carnally with thy neighbor’s wife, to defile thyself with her. [^20] And thou shalt not give any of thy seed to make them pass through the fire to Molech; neither shalt thou profane the name of thy God: I am Jehovah. [^21] Thou shalt not lie with mankind, as with womankind: it is abomination. [^22] And thou shalt not lie with any beast to defile thyself therewith; neither shall any woman stand before a beast, to lie down thereto: it is confusion. [^23] Defile not ye yourselves in any of these things: for in all these the nations are defiled which I cast out from before you; [^24] and the land is defiled: therefore I do visit the iniquity thereof upon it, and the land vomiteth out her inhabitants. [^25] Ye therefore shall keep my statutes and mine ordinances, and shall not do any of these abominations; neither the home-born, nor the stranger that sojourneth among you [^26] (for all these abominations have the men of the land done, that were before you, and the land is defiled); [^27] that the land vomit not you out also, when ye defile it, as it vomited out the nation that was before you. [^28] For whosoever shall do any of these abominations, even the souls that do them shall be cut off from among their people. [^29] Therefore shall ye keep my charge, that ye practise not any of these abominable customs, which were practised before you, and that ye defile not yourselves therein: I am Jehovah your God. [^30] 

[[Leviticus - 17|<--]] Leviticus - 18 [[Leviticus - 19|-->]]

---
# Notes
