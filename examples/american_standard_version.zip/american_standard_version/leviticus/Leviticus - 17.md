---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 17 - American Standard Version"
---
[[Leviticus - 16|<--]] Leviticus - 17 [[Leviticus - 18|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Leviticus]]

# Leviticus - 17

And Jehovah spake unto Moses, saying, [^1] Speak unto Aaron, and unto his sons, and unto all the children of Israel, and say unto them: This is the thing which Jehovah hath commanded, saying, [^2] What man soever there be of the house of Israel, that killeth an ox, or lamb, or goat, in the camp, or that killeth it without the camp, [^3] and hath not brought it unto the door of the tent of meeting, to offer it as an oblation unto Jehovah before the tabernacle of Jehovah: blood shall be imputed unto that man; he hath shed blood; and that man shall be cut off from among his people: [^4] to the end that the children of Israel may bring their sacrifices, which they sacrifice in the open field, even that they may bring them unto Jehovah, unto the door of the tent of meeting, unto the priest, and sacrifice them for sacrifices of peace-offerings unto Jehovah. [^5] And the priest shall sprinkle the blood upon the altar of Jehovah at the door of the tent of meeting, and burn the fat for a sweet savor unto Jehovah. [^6] And they shall no more sacrifice their sacrifices unto the he-goats, after which they play the harlot. This shall be a statute forever unto them throughout their generations. [^7] And thou shalt say unto them, Whatsoever man there be of the house of Israel, or of the strangers that sojourn among them, that offereth a burnt-offering or sacrifice, [^8] and bringeth it not unto the door of the tent of meeting, to sacrifice it unto Jehovah; that man shall be cut off from his people. [^9] And whatsoever man there be of the house of Israel, or of the strangers that sojourn among them, that eateth any manner of blood, I will set my face against that soul that eateth blood, and will cut him off from among his people. [^10] For the life of the flesh is in the blood; and I have given it to you upon the altar to make atonement for your souls: for it is the blood that maketh atonement by reason of the life. [^11] Therefore I said unto the children of Israel, No soul of you shall eat blood, neither shall any stranger that sojourneth among you eat blood. [^12] And whatsoever man there be of the children of Israel, or of the strangers that sojourn among them, who taketh in hunting any beast or bird that may be eaten; he shall pour out the blood thereof, and cover it with dust. [^13] For as to the life of all flesh, the blood thereof is all one with the life thereof: therefore I said unto the children of Israel, Ye shall eat the blood of no manner of flesh; for the life of all flesh is the blood thereof: whosoever eateth it shall be cut off. [^14] And every soul that eateth that which dieth of itself, or that which is torn of beasts, whether he be home-born or a sojourner, he shall wash his clothes, and bathe himself in water, and be unclean until the even: then shall he be clean. [^15] But if he wash them not, nor bathe his flesh, then he shall bear his iniquity. [^16] 

[[Leviticus - 16|<--]] Leviticus - 17 [[Leviticus - 18|-->]]

---
# Notes
