---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 21 - American Standard Version"
---
[[Leviticus - 20|<--]] Leviticus - 21 [[Leviticus - 22|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Leviticus]]

# Leviticus - 21

And Jehovah said unto Moses, Speak unto the priests, the sons of Aaron, and say unto them, There shall none defile himself for the dead among his people; [^1] except for his kin, that is near unto him, for his mother, and for his father, and for his son, and for his daughter, and for his brother, [^2] and for his sister a virgin, that is near unto him, that hath had no husband; for her may he defile himself. [^3] He shall not defile himself, being a chief man among his people, to profane himself. [^4] They shall not make baldness upon their head, neither shall they shave off the corner of their beard, nor make any cuttings in their flesh. [^5] They shall be holy unto their God, and not profane the name of their God; for the offerings of Jehovah made by fire, the bread of their God, they do offer: therefore they shall be holy. [^6] They shall not take a woman that is a harlot, or profane; neither shall they take a woman put away from her husband: for he is holy unto his God. [^7] Thou shalt sanctify him therefore; for he offereth the bread of thy God: he shall be holy unto thee; for I Jehovah, who sanctify you, am holy. [^8] And the daughter of any priest, if she profane herself by playing the harlot, she profaneth her father: she shall be burnt with fire. [^9] And he that is the high priest among his brethren, upon whose head the anointing oil is poured, and that is consecrated to put on the garments, shall not let the hair of his head go loose, nor rend his clothes; [^10] neither shall he go in to any dead body, nor defile himself for his father, or for his mother; [^11] neither shall he go out of the sanctuary, nor profane the sanctuary of his God; for the crown of the anointing oil of his God is upon him: I am Jehovah. [^12] And he shall take a wife in her virginity. [^13] A widow, or one divorced, or a profane woman, a harlot, these shall he not take: but a virgin of his own people shall he take to wife. [^14] And he shall not profane his seed among his people: for I am Jehovah who sanctifieth him. [^15] And Jehovah spake unto Moses, saying, [^16] Speak unto Aaron, saying, Whosoever he be of thy seed throughout their generations that hath a blemish, let him not approach to offer the bread of his God. [^17] For whatsoever man he be that hath a blemish, he shall not approach: a blind man, or a lame, or he that hath a flat nose, or anything superfluous, [^18] or a man that is broken-footed, or broken-handed, [^19] or crook-backed, or a dwarf, or that hath a blemish in his eye, or is scurvy, or scabbed, or hath his stones broken; [^20] no man of the seed of Aaron the priest, that hath a blemish, shall come nigh to offer the offerings of Jehovah made by fire: he hath a blemish; he shall not come nigh to offer the bread of his God. [^21] He shall eat the bread of his God, both of the most holy, and of the holy: [^22] only he shall not go in unto the veil, nor come nigh unto the altar, because he hath a blemish; that he profane not my sanctuaries: for I am Jehovah who sanctifieth them. [^23] So Moses spake unto Aaron, and to his sons, and unto all the children of Israel. [^24] 

[[Leviticus - 20|<--]] Leviticus - 21 [[Leviticus - 22|-->]]

---
# Notes
