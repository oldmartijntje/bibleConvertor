---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 5 - American Standard Version"
---
[[Leviticus - 4|<--]] Leviticus - 5 [[Leviticus - 6|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Leviticus]]

# Leviticus - 5

And if any one sin, in that he heareth the voice of adjuration, he being a witness, whether he hath seen or known, if he do not utter it, then he shall bear his iniquity. [^1] Or if any one touch any unclean thing, whether it be the carcass of an unclean beast, or the carcass of unclean cattle, or the carcass of unclean creeping things, and it be hidden from him, and he be unclean, then he shall be guilty. [^2] Or if he touch the uncleanness of man, whatsoever his uncleanness be wherewith he is unclean, and it be hid from him; when he knoweth of it, then he shall be guilty. [^3] Or if any one swear rashly with his lips to do evil, or to do good, whatsoever it be that a man shall utter rashly with an oath, and it be hid from him; when he knoweth of it, then he shall be guilty in one of these things. [^4] And it shall be, when he shall be guilty in one of these things, that he shall confess that wherein he hath sinned: [^5] and he shall bring his trespass-offering unto Jehovah for his sin which he hath sinned, a female from the flock, a lamb or a goat, for a sin-offering; and the priest shall make atonement for him as concerning his sin. [^6] And if his means suffice not for a lamb, then he shall bring his trespass-offering for that wherein he hath sinned, two turtle-doves, or two young pigeons, unto Jehovah; one for a sin-offering, and the other for a burnt-offering. [^7] And he shall bring them unto the priest, who shall offer that which is for the sin-offering first, and wring off its head from its neck, but shall not divide it asunder: [^8] and he shall sprinkle of the blood of the sin-offering upon the side of the altar; and the rest of the blood shall be drained out at the base of the altar: it is a sin-offering. [^9] And he shall offer the second for a burnt-offering, according to the ordinance; and the priest shall make atonement for him as concerning his sin which he hath sinned, and he shall be forgiven. [^10] But if his means suffice not for two turtle-doves, or two young pigeons, then he shall bring his oblation for that wherein he hath sinned, the tenth part of an ephah of fine flour for a sin-offering: he shall put no oil upon it, neither shall he put any frankincense thereon; for it is a sin-offering. [^11] And he shall bring it to the priest, and the priest shall take his handful of it as the memorial thereof, and burn it on the altar, upon the offerings of Jehovah made by fire: it is a sin-offering. [^12] And the priest shall make atonement for him as touching his sin that he hath sinned in any of these things, and he shall be forgiven: and the remnant shall be the priest’s, as the meal-offering. [^13] And Jehovah spake unto Moses, saying, [^14] If any one commit a trespass, and sin unwittingly, in the holy things of Jehovah; then he shall bring his trespass-offering unto Jehovah, a ram without blemish out of the flock, according to thy estimation in silver by shekels, after the shekel of the sanctuary, for a trespass-offering: [^15] and he shall make restitution for that which he hath done amiss in the holy thing, and shall add the fifth part thereto, and give it unto the priest; and the priest shall make atonement for him with the ram of the trespass-offering, and he shall be forgiven. [^16] And if any one sin, and do any of the things which Jehovah hath commanded not to be done; though he knew it not, yet is he guilty, and shall bear his iniquity. [^17] And he shall bring a ram without blemish out of the flock, according to thy estimation, for a trespass-offering, unto the priest; and the priest shall make atonement for him concerning the thing wherein he erred unwittingly and knew it not, and he shall be forgiven. [^18] It is a trespass-offering: he is certainly guilty before Jehovah. [^19] 

[[Leviticus - 4|<--]] Leviticus - 5 [[Leviticus - 6|-->]]

---
# Notes
