---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 2 - American Standard Version"
---
[[Leviticus - 1|<--]] Leviticus - 2 [[Leviticus - 3|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Leviticus]]

# Leviticus - 2

And when any one offereth an oblation of a meal-offering unto Jehovah, his oblation shall be of fine flour; and he shall pour oil upon it, and put frankincense thereon: [^1] and he shall bring it to Aaron’s sons the priests; and he shall take thereout his handful of the fine flour thereof, and of the oil thereof, with all the frankincense thereof. And the priest shall burn it as the memorial thereof upon the altar, an offering made by fire, of a sweet savor unto Jehovah: [^2] and that which is left of the meal-offering shall be Aaron’s and his sons’: it is a thing most holy of the offerings of Jehovah made by fire. [^3] And when thou offerest an oblation of a meal-offering baken in the oven, it shall be unleavened cakes of fine flour mingled with oil, or unleavened wafers anointed with oil. [^4] And if thy oblation be a meal-offering of the baking-pan, it shall be of fine flour unleavened, mingled with oil. [^5] Thou shalt part it in pieces, and pour oil thereon: it is a meal-offering. [^6] And if thy oblation be a meal-offering of the frying-pan, it shall be made of fine flour with oil. [^7] And thou shalt bring the meal-offering that is made of these things unto Jehovah: and it shall be presented unto the priest, and he shall bring it unto the altar. [^8] And the priest shall take up from the meal-offering the memorial thereof, and shall burn it upon the altar, an offering made by fire, of a sweet savor unto Jehovah. [^9] And that which is left of the meal-offering shall be Aaron’s and his sons’: it is a thing most holy of the offerings of Jehovah made by fire. [^10] No meal-offering, which ye shall offer unto Jehovah, shall be made with leaven; for ye shall burn no leaven, nor any honey, as an offering made by fire unto Jehovah. [^11] As an oblation of first-fruits ye shall offer them unto Jehovah: but they shall not come up for a sweet savor on the altar. [^12] And every oblation of thy meal-offering shalt thou season with salt; neither shalt thou suffer the salt of the covenant of thy God to be lacking from thy meal-offering: with all thine oblations thou shalt offer salt. [^13] And if thou offer a meal-offering of first-fruits unto Jehovah, thou shalt offer for the meal-offering of thy first-fruits grain in the ear parched with fire, bruised grain of the fresh ear. [^14] And thou shalt put oil upon it, and lay frankincense thereon: it is a meal-offering. [^15] And the priest shall burn the memorial of it, part of the bruised grain thereof, and part of the oil thereof, with all the frankincense thereof: it is an offering made by fire unto Jehovah. [^16] 

[[Leviticus - 1|<--]] Leviticus - 2 [[Leviticus - 3|-->]]

---
# Notes
