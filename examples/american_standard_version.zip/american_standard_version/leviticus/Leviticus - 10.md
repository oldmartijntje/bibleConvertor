---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 10 - American Standard Version"
---
[[Leviticus - 9|<--]] Leviticus - 10 [[Leviticus - 11|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Leviticus]]

# Leviticus - 10

And Nadab and Abihu, the sons of Aaron, took each of them his censer, and put fire therein, and laid incense thereon, and offered strange fire before Jehovah, which he had not commanded them. [^1] And there came forth fire from before Jehovah, and devoured them, and they died before Jehovah. [^2] Then Moses said unto Aaron, This is it that Jehovah spake, saying, I will be sanctified in them that come nigh me, and before all the people I will be glorified. And Aaron held his peace. [^3] And Moses called Mishael and Elzaphan, the sons of Uzziel the uncle of Aaron, and said unto them, Draw near, carry your brethren from before the sanctuary out of the camp. [^4] So they drew near, and carried them in their coats out of the camp, as Moses had said. [^5] And Moses said unto Aaron, and unto Eleazar and unto Ithamar, his sons, Let not the hair of your heads go loose, neither rend your clothes; that ye die not, and that he be not wroth with all the congregation: but let your brethren, the whole house of Israel, bewail the burning which Jehovah hath kindled. [^6] And ye shall not go out from the door of the tent of meeting, lest ye die; for the anointing oil of Jehovah is upon you. And they did according to the word of Moses. [^7] And Jehovah spake unto Aaron, saying, [^8] Drink no wine nor strong drink, thou, nor thy sons with thee, when ye go into the tent of meeting, that ye die not: it shall be a statute for ever throughout your generations: [^9] and that ye may make a distinction between the holy and the common, and between the unclean and the clean; [^10] and that ye may teach the children of Israel all the statutes which Jehovah hath spoken unto them by Moses. [^11] And Moses spake unto Aaron, and unto Eleazar and unto Ithamar, his sons that were left, Take the meal-offering that remaineth of the offerings of Jehovah made by fire, and eat it without leaven beside the altar; for it is most holy; [^12] and ye shall eat it in a holy place, because it is thy portion, and thy sons’ portion, of the offerings of Jehovah made by fire: for so I am commanded. [^13] And the wave-breast and the heave-thigh shall ye eat in a clean place, thou, and thy sons, and thy daughters with thee: for they are given as thy portion, and thy sons’ portion, out of the sacrifices of the peace-offerings of the children of Israel. [^14] The heave-thigh and the wave-breast shall they bring with the offerings made by fire of the fat, to wave it for a wave-offering before Jehovah: and it shall be thine, and thy sons’ with thee, as a portion for ever; as Jehovah hath commanded. [^15] And Moses diligently sought the goat of the sin-offering, and, behold, it was burnt: and he was angry with Eleazar and with Ithamar, the sons of Aaron that were left, saying, [^16] Wherefore have ye not eaten the sin-offering in the place of the sanctuary, seeing it is most holy, and he hath given it you to bear the iniquity of the congregation, to make atonement for them before Jehovah? [^17] Behold, the blood of it was not brought into the sanctuary within: ye should certainly have eaten it in the sanctuary, as I commanded. [^18] And Aaron spake unto Moses, Behold, this day have they offered their sin-offering and their burnt-offering before Jehovah; and there have befallen me such things as these: and if I had eaten the sin-offering to-day, would it have been well-pleasing in the sight of Jehovah? [^19] And when Moses heard that, it was well-pleasing in his sight. [^20] 

[[Leviticus - 9|<--]] Leviticus - 10 [[Leviticus - 11|-->]]

---
# Notes
