---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 3 - American Standard Version"
---
[[Leviticus - 2|<--]] Leviticus - 3 [[Leviticus - 4|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Leviticus]]

# Leviticus - 3

And if his oblation be a sacrifice of peace-offerings; if he offer of the herd, whether male or female, he shall offer it without blemish before Jehovah. [^1] And he shall lay his hand upon the head of his oblation, and kill it at the door of the tent of meeting: and Aaron’s sons the priests shall sprinkle the blood upon the altar round about. [^2] And he shall offer of the sacrifice of peace-offerings an offering made by fire unto Jehovah; the fat that covereth the inwards, and all the fat that is upon the inwards, [^3] and the two kidneys, and the fat that is on them, which is by the loins, and the caul upon the liver, with the kidneys, shall he take away. [^4] And Aaron’s sons shall burn it on the altar upon the burnt-offering, which is upon the wood that is on the fire: it is an offering made by fire, of a sweet savor unto Jehovah. [^5] And if his oblation for a sacrifice of peace-offerings unto Jehovah be of the flock; male or female, he shall offer it without blemish. [^6] If he offer a lamb for his oblation, then shall he offer it before Jehovah; [^7] and he shall lay his hand upon the head of his oblation, and kill it before the tent of meeting: and Aaron’s sons shall sprinkle the blood thereof upon the altar round about. [^8] And he shall offer of the sacrifice of peace-offerings an offering made by fire unto Jehovah; the fat thereof, the fat tail entire, he shall take away hard by the backbone; and the fat that covereth the inwards, and all the fat that is upon the inwards, [^9] and the two kidneys, and the fat that is upon them, which is by the loins, and the caul upon the liver, with the kidneys, shall he take away. [^10] And the priest shall burn it upon the altar: it is the food of the offering made by fire unto Jehovah. [^11] And if his oblation be a goat, then he shall offer it before Jehovah: [^12] and he shall lay his hand upon the head of it, and kill it before the tent of meeting; and the sons of Aaron shall sprinkle the blood thereof upon the altar round about. [^13] And he shall offer thereof his oblation, even an offering made by fire unto Jehovah; the fat that covereth the inwards, and all the fat that is upon the inwards, [^14] and the two kidneys, and the fat that is upon them, which is by the loins, and the caul upon the liver, with the kidneys, shall he take away. [^15] And the priest shall burn them upon the altar: it is the food of the offering made by fire, for a sweet savor; all the fat is Jehovah’s. [^16] It shall be a perpetual statute throughout your generations in all your dwellings, that ye shall eat neither fat nor blood. [^17] 

[[Leviticus - 2|<--]] Leviticus - 3 [[Leviticus - 4|-->]]

---
# Notes
