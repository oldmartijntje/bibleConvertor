---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 12 - American Standard Version"
---
[[2 Kings - 11|<--]] 2 Kings - 12 [[2 Kings - 13|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[2 Kings]]

# 2 Kings - 12

In the seventh year of Jehu began Jehoash to reign; and he reigned forty years in Jerusalem: and his mother’s name was Zibiah of Beer-sheba. [^1] And Jehoash did that which was right in the eyes of Jehovah all his days wherein Jehoiada the priest instructed him. [^2] Howbeit the high places were not taken away; the people still sacrificed and burnt incense in the high places. [^3] And Jehoash said to the priests, All the money of the hallowed things that is brought into the house of Jehovah, in current money, the money of the persons for whom each man is rated, and all the money that it cometh into any man’s heart to bring into the house of Jehovah, [^4] let the priests take it to them, every man from his acquaintance; and they shall repair the breaches of the house, wheresoever any breach shall be found. [^5] But it was so, that in the three and twentieth year of king Jehoash the priests had not repaired the breaches of the house. [^6] Then king Jehoash called for Jehoiada the priest, and for the other priests, and said unto them, Why repair ye not the breaches of the house? now therefore take no more money from your acquaintance, but deliver it for the breaches of the house. [^7] And the priests consented that they should take no more money from the people, neither repair the breaches of the house. [^8] But Jehoiada the priest took a chest, and bored a hole in the lid of it, and set it beside the altar, on the right side as one cometh into the house of Jehovah: and the priests that kept the threshold put therein all the money that was brought into the house of Jehovah. [^9] And it was so, when they saw that there was much money in the chest, that the king’s scribe and the high priest came up, and they put up in bags and counted the money that was found in the house of Jehovah. [^10] And they gave the money that was weighed out into the hands of them that did the work, that had the oversight of the house of Jehovah: and they paid it out to the carpenters and the builders, that wrought upon the house of Jehovah, [^11] and to the masons and the hewers of stone, and for buying timber and hewn stone to repair the breaches of the house of Jehovah, and for all that was laid out for the house to repair it. [^12] But there were not made for the house of Jehovah cups of silver, snuffers, basins, trumpets, any vessels of gold, or vessels of silver, of the money that was brought into the house of Jehovah; [^13] for they gave that to them that did the work, and repaired therewith the house of Jehovah. [^14] Moreover they reckoned not with the men, into whose hand they delivered the money to give to them that did the work; for they dealt faithfully. [^15] The money for the trespass-offerings, and the money for the sin-offerings, was not brought into the house of Jehovah: it was the priests’. [^16] Then Hazael king of Syria went up, and fought against Gath, and took it; and Hazael set his face to go up to Jerusalem. [^17] And Jehoash king of Judah took all the hallowed things that Jehoshaphat and Jehoram and Ahaziah, his fathers, kings of Judah, had dedicated, and his own hallowed things, and all the gold that was found in the treasures of the house of Jehovah, and of the king’s house, and sent it to Hazael king of Syria: and he went away from Jerusalem. [^18] Now the rest of the acts of Joash, and all that he did, are they not written in the book of the chronicles of the kings of Judah? [^19] And his servants arose, and made a conspiracy, and smote Joash at the house of Millo, on the way that goeth down to Silla. [^20] For Jozacar the son of Shimeath, and Jehozabad the son of Shomer, his servants, smote him, and he died; and they buried him with his fathers in the city of David: and Amaziah his son reigned in his stead. [^21] 

[[2 Kings - 11|<--]] 2 Kings - 12 [[2 Kings - 13|-->]]

---
# Notes
