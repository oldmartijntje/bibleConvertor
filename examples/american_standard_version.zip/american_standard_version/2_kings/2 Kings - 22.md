---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 22 - American Standard Version"
---
[[2 Kings - 21|<--]] 2 Kings - 22 [[2 Kings - 23|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[2 Kings]]

# 2 Kings - 22

Josiah was eight years old when he began to reign; and he reigned thirty and one years in Jerusalem: and his mother’s name was Jedidah the daughter of Adaiah of Bozkath. [^1] And he did that which was right in the eyes of Jehovah, and walked in all the way of David his father, and turned not aside to the right hand or to the left. [^2] And it came to pass in the eighteenth year of king Josiah, that the king sent Shaphan, the son of Azaliah the son of Meshullam, the scribe, to the house of Jehovah, saying, [^3] Go up to Hilkiah the high priest, that he may sum the money which is brought into the house of Jehovah, which the keepers of the threshold have gathered of the people: [^4] and let them deliver it into the hand of the workmen that have the oversight of the house of Jehovah; and let them give it to the workmen that are in the house of Jehovah, to repair the breaches of the house, [^5] unto the carpenters, and to the builders, and to the masons, and for buying timber and hewn stone to repair the house. [^6] Howbeit there was no reckoning made with them of the money that was delivered into their hand; for they dealt faithfully. [^7] And Hilkiah the high priest said unto Shaphan the scribe, I have found the book of the law in the house of Jehovah. And Hilkiah delivered the book to Shaphan, and he read it. [^8] And Shaphan the scribe came to the king, and brought the king word again, and said, Thy servants have emptied out the money that was found in the house, and have delivered it into the hand of the workmen that have the oversight of the house of Jehovah. [^9] And Shaphan the scribe told the king, saying, Hilkiah the priest hath delivered me a book. And Shaphan read it before the king. [^10] And it came to pass, when the king had heard the words of the book of the law, that he rent his clothes. [^11] And the king commanded Hilkiah the priest, and Ahikam the son of Shaphan, and Achbor the son of Micaiah, and Shaphan the scribe, and Asaiah the king’s servant, saying, [^12] Go ye, inquire of Jehovah for me, and for the people, and for all Judah, concerning the words of this book that is found; for great is the wrath of Jehovah that is kindled against us, because our fathers have not hearkened unto the words of this book, to do according unto all that which is written concerning us. [^13] So Hilkiah the priest, and Ahikam, and Achbor, and Shaphan, and Asaiah, went unto Huldah the prophetess, the wife of Shallum the son of Tikvah, the son of Harhas, keeper of the wardrobe (now she dwelt in Jerusalem in the second quarter); and they communed with her. [^14] And she said unto them, Thus saith Jehovah, the God of Israel: Tell ye the man that sent you unto me, [^15] Thus saith Jehovah, Behold, I will bring evil upon this place, and upon the inhabitants thereof, even all the words of the book which the king of Judah hath read. [^16] Because they have forsaken me, and have burned incense unto other gods, that they might provoke me to anger with all the work of their hands, therefore my wrath shall be kindled against this place, and it shall not be quenched. [^17] But unto the king of Judah, who sent you to inquire of Jehovah, thus shall ye say to him, Thus saith Jehovah, the God of Israel: As touching the words which thou hast heard, [^18] because thy heart was tender, and thou didst humble thyself before Jehovah, when thou heardest what I spake against this place, and against the inhabitants thereof, that they should become a desolation and a curse, and hast rent thy clothes, and wept before me; I also have heard thee, saith Jehovah. [^19] Therefore, behold, I will gather thee to thy fathers, and thou shalt be gathered to thy grave in peace, neither shall thine eyes see all the evil which I will bring upon this place. And they brought the king word again. [^20] 

[[2 Kings - 21|<--]] 2 Kings - 22 [[2 Kings - 23|-->]]

---
# Notes
