---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 20 - American Standard Version"
---
[[2 Kings - 19|<--]] 2 Kings - 20 [[2 Kings - 21|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[2 Kings]]

# 2 Kings - 20

In those days was Hezekiah sick unto death. And Isaiah the prophet the son of Amoz came to him, and said unto him, Thus saith Jehovah, Set thy house in order; for thou shalt die, and not live. [^1] Then he turned his face to the wall, and prayed unto Jehovah, saying, [^2] Remember now, O Jehovah, I beseech thee, how I have walked before thee in truth and with a perfect heart, and have done that which is good in thy sight. And Hezekiah wept sore. [^3] And it came to pass, before Isaiah was gone out into the middle part of the city, that the word of Jehovah came to him, saying, [^4] Turn back, and say to Hezekiah the prince of my people, Thus saith Jehovah, the God of David thy father, I have heard thy prayer, I have seen thy tears: behold, I will heal thee; on the third day thou shalt go up unto the house of Jehovah. [^5] And I will add unto thy days fifteen years; and I will deliver thee and this city out of the hand of the king of Assyria; and I will defend this city for mine own sake, and for my servant David’s sake. [^6] And Isaiah said, Take a cake of figs. And they took and laid it on the boil, and he recovered. [^7] And Hezekiah said unto Isaiah, What shall be the sign that Jehovah will heal me, and that I shall go up unto the house of Jehovah the third day? [^8] And Isaiah said, This shall be the sign unto thee from Jehovah, that Jehovah will do the thing that he hath spoken: shall the shadow go forward ten steps, or go back ten steps? [^9] And Hezekiah answered, It is a light thing for the shadow to decline ten steps: nay, but let the shadow return backward ten steps. [^10] And Isaiah the prophet cried unto Jehovah; and he brought the shadow ten steps backward, by which it had gone down on the dial of Ahaz. [^11] At that time Berodach-baladan the son of Baladan, king of Babylon, sent letters and a present unto Hezekiah; for he had heard that Hezekiah had been sick. [^12] And Hezekiah hearkened unto them, and showed them all the house of his precious things, the silver, and the gold, and the spices, and the precious oil, and the house of his armor, and all that was found in his treasures: there was nothing in his house, nor in all his dominion, that Hezekiah showed them not. [^13] Then came Isaiah the prophet unto king Hezekiah, and said unto him, What said these men? and from whence came they unto thee? And Hezekiah said, They are come from a far country, even from Babylon. [^14] And he said, What have they seen in thy house? And Hezekiah answered, All that is in my house have they seen: there is nothing among my treasures that I have not showed them. [^15] And Isaiah said unto Hezekiah, Hear the word of Jehovah. [^16] Behold, the days come, that all that is in thy house, and that which thy fathers have laid up in store unto this day, shall be carried to Babylon: nothing shall be left, saith Jehovah. [^17] And of thy sons that shall issue from thee, whom thou shalt beget, shall they take away; and they shall be eunuchs in the palace of the king of Babylon. [^18] Then said Hezekiah unto Isaiah, Good is the word of Jehovah which thou hast spoken. He said moreover, Is it not so, if peace and truth shall be in my days? [^19] Now the rest of the acts of Hezekiah, and all his might, and how he made the pool, and the conduit, and brought water into the city, are they not written in the book of the chronicles of the kings of Judah? [^20] And Hezekiah slept with his fathers; and Manasseh his son reigned in his stead. [^21] 

[[2 Kings - 19|<--]] 2 Kings - 20 [[2 Kings - 21|-->]]

---
# Notes
