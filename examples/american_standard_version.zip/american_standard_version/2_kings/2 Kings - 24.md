---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 24 - American Standard Version"
---
[[2 Kings - 23|<--]] 2 Kings - 24 [[2 Kings - 25|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[2 Kings]]

# 2 Kings - 24

In his days Nebuchadnezzar king of Babylon came up, and Jehoiakim became his servant three years: then he turned and rebelled against him. [^1] And Jehovah sent against him bands of the Chaldeans, and bands of the Syrians, and bands of the Moabites, and bands of the children of Ammon, and sent them against Judah to destroy it, according to the word of Jehovah, which he spake by his servants the prophets. [^2] Surely at the commandment of Jehovah came this upon Judah, to remove them out of his sight, for the sins of Manasseh, according to all that he did, [^3] and also for the innocent blood that he shed; for he filled Jerusalem with innocent blood: and Jehovah would not pardon. [^4] Now the rest of the acts of Jehoiakim, and all that he did, are they not written in the book of the chronicles of the kings of Judah? [^5] So Jehoiakim slept with his fathers; and Jehoiachin his son reigned in his stead. [^6] And the king of Egypt came not again any more out of his land; for the king of Babylon had taken, from the brook of Egypt unto the river Euphrates, all that pertained to the king of Egypt. [^7] Jehoiachin was eighteen years old when he began to reign; and he reigned in Jerusalem three months: and his mother’s name was Nehushta the daughter of Elnathan of Jerusalem. [^8] And he did that which was evil in the sight of Jehovah, according to all that his father had done. [^9] At that time the servants of Nebuchadnezzar king of Babylon came up to Jerusalem, and the city was besieged. [^10] And Nebuchadnezzar king of Babylon came unto the city, while his servants were besieging it; [^11] and Jehoiachin the king of Judah went out to the king of Babylon, he, and his mother, and his servants, and his princes, and his officers: and the king of Babylon took him in the eighth year of his reign. [^12] And he carried out thence all the treasures of the house of Jehovah, and the treasures of the king’s house, and cut in pieces all the vessels of gold, which Solomon king of Israel had made in the temple of Jehovah, as Jehovah had said. [^13] And he carried away all Jerusalem, and all the princes, and all the mighty men of valor, even ten thousand captives, and all the craftsmen and the smiths; none remained, save the poorest sort of the people of the land. [^14] And he carried away Jehoiachin to Babylon; and the king’s mother, and the king’s wives, and his officers, and the chief men of the land, carried he into captivity from Jerusalem to Babylon. [^15] And all the men of might, even seven thousand, and the craftsmen and the smiths a thousand, all of them strong and apt for war, even them the king of Babylon brought captive to Babylon. [^16] And the king of Babylon made Mattaniah, Jehoiachin’s father’s brother, king in his stead, and changed his name to Zedekiah. [^17] Zedekiah was twenty and one years old when he began to reign; and he reigned eleven years in Jerusalem: and his mother’s name was Hamutal the daughter of Jeremiah of Libnah. [^18] And he did that which was evil in the sight of Jehovah, according to all that Jehoiakim had done. [^19] For through the anger of Jehovah did it come to pass in Jerusalem and Judah, until he had cast them out from his presence.And Zedekiah rebelled against the king of Babylon. [^20] 

[[2 Kings - 23|<--]] 2 Kings - 24 [[2 Kings - 25|-->]]

---
# Notes
