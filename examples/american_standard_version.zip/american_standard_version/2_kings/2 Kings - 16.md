---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 16 - American Standard Version"
---
[[2 Kings - 15|<--]] 2 Kings - 16 [[2 Kings - 17|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[2 Kings]]

# 2 Kings - 16

In the seventeenth year of Pekah the son of Remaliah Ahaz the son of Jotham king of Judah began to reign. [^1] Twenty years old was Ahaz when he began to reign; and he reigned sixteen years in Jerusalem: and he did not that which was right in the eyes of Jehovah his God, like David his father. [^2] But he walked in the way of the kings of Israel, yea, and made his son to pass through the fire, according to the abominations of the nations, whom Jehovah cast out from before the children of Israel. [^3] And he sacrificed and burnt incense in the high places, and on the hills, and under every green tree. [^4] Then Rezin king of Syria and Pekah son of Remaliah king of Israel came up to Jerusalem to war: and they besieged Ahaz, but could not overcome him. [^5] At that time Rezin king of Syria recovered Elath to Syria, and drove the Jews from Elath; and the Syrians came to Elath, and dwelt there, unto this day. [^6] So Ahaz sent messengers to Tiglath-pileser king of Assyria, saying, I am thy servant and thy son: come up, and save me out of the hand of the king of Syria, and out of the hand of the king of Israel, who rise up against me. [^7] And Ahaz took the silver and gold that was found in the house of Jehovah, and in the treasures of the king’s house, and sent it for a present to the king of Assyria. [^8] And the king of Assyria hearkened unto him; and the king of Assyria went up against Damascus, and took it, and carried the people of it captive to Kir, and slew Rezin. [^9] And king Ahaz went to Damascus to meet Tiglath-pileser king of Assyria, and saw the altar that was at Damascus; and king Ahaz sent to Urijah the priest the fashion of the altar, and the pattern of it, according to all the workmanship thereof. [^10] And Urijah the priest built an altar: according to all that king Ahaz had sent from Damascus, so did Urijah the priest make it against the coming of king Ahaz from Damascus. [^11] And when the king was come from Damascus, the king saw the altar: and the king drew near unto the altar, and offered thereon. [^12] And he burnt his burnt-offering and his meal-offering, and poured his drink-offering, and sprinkled the blood of his peace-offerings, upon the altar. [^13] And the brazen altar, which was before Jehovah, he brought from the forefront of the house, from between his altar and the house of Jehovah, and put it on the north side of his altar. [^14] And king Ahaz commanded Urijah the priest, saying, Upon the great altar burn the morning burnt-offering, and the evening meal-offering, and the king’s burnt-offering, and his meal-offering, with the burnt-offering of all the people of the land, and their meal-offering, and their drink-offerings; and sprinkle upon it all the blood of the burnt-offering, and all the blood of the sacrifice: but the brazen altar shall be for me to inquire by. [^15] Thus did Urijah the priest, according to all that king Ahaz commanded. [^16] And king Ahaz cut off the panels of the bases, and removed the laver from off them, and took down the sea from off the brazen oxen that were under it, and put it upon a pavement of stone. [^17] And the covered way for the sabbath that they had built in the house, and the king’s entry without, turned he unto the house of Jehovah, because of the king of Assyria. [^18] Now the rest of the acts of Ahaz which he did, are they not written in the book of the chronicles of the kings of Judah? [^19] And Ahaz slept with his fathers, and was buried with his fathers in the city of David: and Hezekiah his son reigned in his stead. [^20] 

[[2 Kings - 15|<--]] 2 Kings - 16 [[2 Kings - 17|-->]]

---
# Notes
