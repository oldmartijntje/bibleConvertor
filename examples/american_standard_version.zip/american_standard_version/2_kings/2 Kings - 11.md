---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 11 - American Standard Version"
---
[[2 Kings - 10|<--]] 2 Kings - 11 [[2 Kings - 12|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[2 Kings]]

# 2 Kings - 11

Now when Athaliah the mother of Ahaziah saw that her son was dead, she arose and destroyed all the seed royal. [^1] But Jehosheba, the daughter of king Joram, sister of Ahaziah, took Joash the son of Ahaziah, and stole him away from among the king’s sons that were slain, even him and his nurse, and put them in the bedchamber; and they hid him from Athaliah, so that he was not slain; [^2] And he was with her hid in the house of Jehovah six years. And Athaliah reigned over the land. [^3] And in the seventh year Jehoiada sent and fetched the captains over hundreds of the Carites and of the guard, and brought them to him into the house of Jehovah; and he made a covenant with them, and took an oath of them in the house of Jehovah, and showed them the king’s son. [^4] And he commanded them, saying, This is the thing that ye shall do: a third part of you, that come in on the sabbath, shall be keepers of the watch of the king’s house; [^5] and a third part shall be at the gate Sur; and a third part at the gate behind the guard: so shall ye keep the watch of the house, and be a barrier. [^6] And the two companies of you, even all that go forth on the sabbath, shall keep the watch of the house of Jehovah about the king. [^7] And ye shall compass the king round about, every man with his weapons in his hand; and he that cometh within the ranks, let him be slain: and be ye with the king when he goeth out, and when he cometh in. [^8] And the captains over hundreds did according to all that Jehoiada the priest commanded; and they took every man his men, those that were to come in on the sabbath, with those that were to go out on the sabbath, and came to Jehoiada the priest. [^9] And the priest delivered to the captains over hundreds the spears and shields that had been king David’s, which were in the house of Jehovah. [^10] And the guard stood, every man with his weapons in his hand, from the right side of the house to the left side of the house, along by the altar and the house, by the king round about. [^11] Then he brought out the king’s son, and put the crown upon him, and gave him the testimony; and they made him king, and anointed him; and they clapped their hands, and said, Long live the king. [^12] And when Athaliah heard the noise of the guard and of the people, she came to the people into the house of Jehovah: [^13] and she looked, and, behold, the king stood by the pillar, as the manner was, and the captains and the trumpets by the king; and all the people of the land rejoiced, and blew trumpets. Then Athaliah rent her clothes, and cried, Treason! treason! [^14] And Jehoiada the priest commanded the captains of hundreds that were set over the host, and said unto them, Have her forth between the ranks; and him that followeth her slay with the sword. For the priest said, Let her not be slain in the house of Jehovah. [^15] So they made way for her; and she went by the way of the horses’ entry to the king’s house: and there was she slain. [^16] And Jehoiada made a covenant between Jehovah and the king and the people, that they should be Jehovah’s people; between the king also and the people. [^17] And all the people of the land went to the house of Baal, and brake it down; his altars and his images brake they in pieces thoroughly, and slew Mattan the priest of Baal before the altars. And the priest appointed officers over the house of Jehovah. [^18] And he took the captains over hundreds, and the Carites, and the guard, and all the people of the land; and they brought down the king from the house of Jehovah, and came by the way of the gate of the guard unto the king’s house. And he sat on the throne of the kings. [^19] So all the people of the land rejoiced, and the city was quiet. And Athaliah they had slain with the sword at the king’s house. [^20] Jehoash was seven years old when he began to reign. [^21] 

[[2 Kings - 10|<--]] 2 Kings - 11 [[2 Kings - 12|-->]]

---
# Notes
