---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/ruth"
  - "#bible/testament/old"
aliases:
  - "Ruth - 3 - American Standard Version"
---
[[Ruth - 2|<--]] Ruth - 3 [[Ruth - 4|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Ruth]]

# Ruth - 3

And Naomi her mother-in-law said unto her, My daughter, shall I not seek rest for thee, that it may be well with thee? [^1] And now is not Boaz our kinsman, with whose maidens thou wast? Behold, he winnoweth barley to-night in the threshing-floor. [^2] Wash thyself therefore, and anoint thee, and put thy raiment upon thee, and get thee down to the threshing-floor, but make not thyself known unto the man, until he shall have done eating and drinking. [^3] And it shall be, when he lieth down, that thou shalt mark the place where he shall lie, and thou shalt go in, and uncover his feet, and lay thee down; and he will tell thee what thou shalt do. [^4] And she said unto her, All that thou sayest I will do. [^5] And she went down unto the threshing-floor, and did according to all that her mother-in-law bade her. [^6] And when Boaz had eaten and drunk, and his heart was merry, he went to lie down at the end of the heap of grain: and she came softly, and uncovered his feet, and laid her down. [^7] And it came to pass at midnight, that the man was afraid, and turned himself; and, behold, a woman lay at his feet. [^8] And he said, Who art thou? And she answered, I am Ruth thy handmaid: spread therefore thy skirt over thy handmaid; for thou art a near kinsman. [^9] And he said, Blessed be thou of Jehovah, my daughter: thou hast showed more kindness in the latter end than at the beginning, inasmuch as thou followedst not young men, whether poor or rich. [^10] And now, my daughter, fear not; I will do to thee all that thou sayest; for all the city of my people doth know that thou art a worthy woman. [^11] And now it is true that I am a near kinsman; howbeit there is a kinsman nearer than I. [^12] Tarry this night, and it shall be in the morning, that if he will perform unto thee the part of a kinsman, well; let him do the kinsman’s part: but if he will not do the part of a kinsman to thee, then will I do the part of a kinsman to thee, as Jehovah liveth: lie down until the morning. [^13] And she lay at his feet until the morning: and she rose up before one could discern another. For he said, Let it not be known that the woman came to the threshing-floor. [^14] And he said, Bring the mantle that is upon thee, and hold it; and she held it; and he measured six measures of barley, and laid it on her: and he went into the city. [^15] And when she came to her mother-in-law, she said, Who art thou, my daughter? And she told her all that the man had done to her. [^16] And she said, These six measures of barley gave he me; for he said, Go not empty unto thy mother-in-law. [^17] Then said she, Sit still, my daughter, until thou know how the matter will fall; for the man will not rest, until he have finished the thing this day. [^18] 

[[Ruth - 2|<--]] Ruth - 3 [[Ruth - 4|-->]]

---
# Notes
