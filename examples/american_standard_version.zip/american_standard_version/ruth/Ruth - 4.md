---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/ruth"
  - "#bible/testament/old"
aliases:
  - "Ruth - 4 - American Standard Version"
---
[[Ruth - 3|<--]] Ruth - 4

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Ruth]]

# Ruth - 4

Now Boaz went up to the gate, and sat him down there: and, behold, the near kinsman of whom Boaz spake came by; unto whom he said, Ho, such a one! turn aside, sit down here. And he turned aside, and sat down. [^1] And he took ten men of the elders of the city, and said, Sit ye down here. And they sat down. [^2] And he said unto the near kinsman, Naomi, that is come again out of the country of Moab, selleth the parcel of land, which was our brother Elimelech’s: [^3] and I thought to disclose it unto thee, saying, Buy it before them that sit here, and before the elders of my people. If thou wilt redeem it, redeem it: but if thou wilt not redeem it, then tell me, that I may know; for there is none to redeem it besides thee; and I am after thee. And he said, I will redeem it. [^4] Then said Boaz, What day thou buyest the field of the hand of Naomi, thou must buy it also of Ruth the Moabitess, the wife of the dead, to raise up the name of the dead upon his inheritance. [^5] And the near kinsman said, I cannot redeem it for myself, lest I mar mine own inheritance: take thou my right of redemption on thee; for I cannot redeem it. [^6] Now this was the custom in former time in Israel concerning redeeming and concerning exchanging, to confirm all things: a man drew off his shoe, and gave it to his neighbor; and this was the manner of attestation in Israel. [^7] So the near kinsman said unto Boaz, Buy it for thyself. And he drew off his shoe. [^8] And Boaz said unto the elders, and unto all the people, Ye are witnesses this day, that I have bought all that was Elimelech’s, and all that was Chilion’s and Mahlon’s, of the hand of Naomi. [^9] Moreover Ruth the Moabitess, the wife of Mahlon, have I purchased to be my wife, to raise up the name of the dead upon his inheritance, that the name of the dead be not cut off from among his brethren, and from the gate of his place: ye are witnesses this day. [^10] And all the people that were in the gate, and the elders, said, We are witnesses. Jehovah make the woman that is come into thy house like Rachel and like Leah, which two did build the house of Israel: and do thou worthily in Ephrathah, and be famous in Beth-lehem: [^11] and let thy house be like the house of Perez, whom Tamar bare unto Judah, of the seed which Jehovah shall give thee of this young woman. [^12] So Boaz took Ruth, and she became his wife; and he went in unto her, and Jehovah gave her conception, and she bare a son. [^13] And the women said unto Naomi, Blessed be Jehovah, who hath not left thee this day without a near kinsman; and let his name be famous in Israel. [^14] And he shall be unto thee a restorer of life, and a nourisher of thine old age, for thy daughter-in-law, who loveth thee, who is better to thee than seven sons, hath borne him. [^15] And Naomi took the child, and laid it in her bosom, and became nurse unto it. [^16] And the women her neighbors gave it a name, saying, There is a son born to Naomi; and they called his name Obed: he is the father of Jesse, the father of David. [^17] Now these are the generations of Perez: Perez begat Hezron, [^18] and Hezron begat Ram, and Ram begat Amminadab, [^19] and Amminadab begat Nahshon, and Nahshon begat Salmon, [^20] and Salmon begat Boaz, and Boaz begat Obed, [^21] and Obed begat Jesse, and Jesse begat David. [^22] 

[[Ruth - 3|<--]] Ruth - 4

---
# Notes
