---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 8 - American Standard Version"
---
[[Esther - 7|<--]] Esther - 8 [[Esther - 9|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Esther]]

# Esther - 8

On that day did the king Ahasuerus give the house of Haman the Jews’ enemy unto Esther the queen. And Mordecai came before the king; for Esther had told what he was unto her. [^1] And the king took off his ring, which he had taken from Haman, and gave it unto Mordecai. And Esther set Mordecai over the house of Haman. [^2] And Esther spake yet again before the king, and fell down at his feet, and besought him with tears to put away the mischief of Haman the Agagite, and his device that he had devised against the Jews. [^3] Then the king held out to Esther the golden sceptre. So Esther arose, and stood before the king. [^4] And she said, If it please the king, and if I have found favor in his sight, and the thing seem right before the king, and I be pleasing in his eyes, let it be written to reverse the letters devised by Haman, the son of Hammedatha the Agagite, which he wrote to destroy the Jews that are in all the king’s provinces: [^5] for how can I endure to see the evil that shall come unto my people? or how can I endure to see the destruction of my kindred? [^6] Then the king Ahasuerus said unto Esther the queen and to Mordecai the Jew, Behold, I have given Esther the house of Haman, and him they have hanged upon the gallows, because he laid his hand upon the Jews. [^7] Write ye also to the Jews, as it pleaseth you, in the king’s name, and seal it with the king’s ring; for the writing which is written in the king’s name, and sealed with the king’s ring, may no man reverse. [^8] Then were the king’s scribes called at that time, in the third month, which is the month Sivan, on the three and twentieth day thereof; and it was written according to all that Mordecai commanded unto the Jews, and to the satraps, and the governors and princes of the provinces which are from India unto Ethiopia, a hundred twenty and seven provinces, unto every province according to the writing thereof, and unto every people after their language, and to the Jews according to their writing, and according to their language. [^9] And he wrote in the name of king Ahasuerus, and sealed it with the king’s ring, and sent letters by posts on horseback, riding on swift steeds that were used in the king’s service, bred of the stud: [^10] wherein the king granted the Jews that were in every city to gather themselves together, and to stand for their life, to destroy, to slay, and to cause to perish, all the power of the people and province that would assault them, their little ones and women, and to take the spoil of them for a prey, [^11] upon one day in all the provinces of king Ahasuerus, namely, upon the thirteenth day of the twelfth month, which is the month Adar. [^12] A copy of the writing, that the decree should be given out in every province, was published unto all the peoples, and that the Jews should be ready against that day to avenge themselves on their enemies. [^13] So the posts that rode upon swift steeds that were used in the king’s service went out, being hastened and pressed on by the king’s commandment; and the decree was given out in Shushan the palace. [^14] And Mordecai went forth from the presence of the king in royal apparel of blue and white, and with a great crown of gold, and with a robe of fine linen and purple: and the city of Shushan shouted and was glad. [^15] The Jews had light and gladness, and joy and honor. [^16] And in every province, and in every city, whithersoever the king’s commandment and his decree came, the Jews had gladness and joy, a feast and a good day. And many from among the peoples of the land became Jews; for the fear of the Jews was fallen upon them. [^17] 

[[Esther - 7|<--]] Esther - 8 [[Esther - 9|-->]]

---
# Notes
