---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 1 - American Standard Version"
---
Esther - 1 [[Esther - 2|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Esther]]

# Esther - 1

Now it came to pass in the days of Ahasuerus (this is Ahasuerus who reigned from India even unto Ethiopia, over a hundred and seven and twenty provinces), [^1] that in those days, when the king Ahasuerus sat on the throne of his kingdom, which was in Shushan the palace, [^2] in the third year of his reign, he made a feast unto all his princes and his servants; the power of Persia and Media, the nobles and princes of the provinces, being before him; [^3] when he showed the riches of his glorious kingdom and the honor of his excellent majesty many days, even a hundred and fourscore days. [^4] And when these days were fulfilled, the king made a feast unto all the people that were present in Shushan the palace, both great and small, seven days, in the court of the garden of the king’s palace. [^5] There were hangings of white cloth, of green, and of blue, fastened with cords of fine linen and purple to silver rings and pillars of marble: the couches were of gold and silver, upon a pavement of red, and white, and yellow, and black marble. [^6] And they gave them drink in vessels of gold (the vessels being diverse one from another), and royal wine in abundance, according to the bounty of the king. [^7] And the drinking was according to the law; none could compel: for so the king had appointed to all the officers of his house, that they should do according to every man’s pleasure. [^8] Also Vashti the queen made a feast for the women in the royal house which belonged to king Ahasuerus. [^9] On the seventh day, when the heart of the king was merry with wine, he commanded Mehuman, Biztha, Harbona, Bigtha, and Abagtha, Zethar, and Carcas, the seven chamberlains that ministered in the presence of Ahasuerus the king, [^10] to bring Vashti the queen before the king with the crown royal, to show the peoples and the princes her beauty; for she was fair to look on. [^11] But the queen Vashti refused to come at the king’s commandment by the chamberlains: therefore was the king very wroth, and his anger burned in him. [^12] Then the king said to the wise men, who knew the times (for so was the king’s manner toward all that knew law and judgment; [^13] and the next unto him were Carshena, Shethar, Admatha, Tarshish, Meres, Marsena, and Memucan, the seven princes of Persia and Media, who saw the king’s face, and sat first in the kingdom), [^14] What shall we do unto the queen Vashti according to law, because she hath not done the bidding of the king Ahasuerus by the chamberlains? [^15] And Memucan answered before the king and the princes, Vashti the queen hath not done wrong to the king only, but also to all the princes, and to all the peoples that are in all the provinces of the king Ahasuerus. [^16] For this deed of the queen will come abroad unto all women, to make their husbands contemptible in their eyes, when it shall be reported, The king Ahasuerus commanded Vashti the queen to be brought in before him, but she came not. [^17] And this day will the princesses of Persia and Media who have heard of the deed of the queen say the like unto all the king’s princes. So will there arise much contempt and wrath. [^18] If it please the king, let there go forth a royal commandment from him, and let it be written among the laws of the Persians and the Medes, that it be not altered, that Vashti come no more before king Ahasuerus; and let the king give her royal estate unto another that is better than she. [^19] And when the king’s decree which he shall make shall be published throughout all his kingdom (for it is great), all the wives will give to their husbands honor, both to great and small. [^20] And the saying pleased the king and the princes; and the king did according to the word of Memucan: [^21] for he sent letters into all the king’s provinces, into every province according to the writing thereof, and to every people after their language, that every man should bear rule in his own house, and should speak according to the language of his people. [^22] 

Esther - 1 [[Esther - 2|-->]]

---
# Notes
