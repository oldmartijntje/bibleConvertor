---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 4 - American Standard Version"
---
[[Esther - 3|<--]] Esther - 4 [[Esther - 5|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Esther]]

# Esther - 4

Now when Mordecai knew all that was done, Mordecai rent his clothes, and put on sackcloth with ashes, and went out into the midst of the city, and cried with a loud and a bitter cry; [^1] and he came even before the king’s gate: for none might enter within the king’s gate clothed with sackcloth. [^2] And in every province, whithersoever the king’s commandment and his decree came, there was great mourning among the Jews, and fasting, and weeping, and wailing; and many lay in sackcloth and ashes. [^3] And Esther’s maidens and her chamberlains came and told it her; and the queen was exceedingly grieved: and she sent raiment to clothe Mordecai, and to take his sackcloth from off him; but he received it not. [^4] Then called Esther for Hathach, one of the king’s chamberlains, whom he had appointed to attend upon her, and charged him to go to Mordecai, to know what this was, and why it was. [^5] So Hathach went forth to Mordecai unto the broad place of the city, which was before the king’s gate. [^6] And Mordecai told him of all that had happened unto him, and the exact sum of the money that Haman had promised to pay to the king’s treasuries for the Jews, to destroy them. [^7] Also he gave him the copy of the writing of the decree that was given out in Shushan to destroy them, to show it unto Esther, and to declare it unto her, and to charge her that she should go in unto the king, to make supplication unto him, and to make request before him, for her people. [^8] And Hathach came and told Esther the words of Mordecai. [^9] Then Esther spake unto Hathach, and gave him a message unto Mordecai, saying: [^10] All the king’s servants, and the people of the king’s provinces, do know, that whosoever, whether man or woman, shall come unto the king into the inner court, who is not called, there is one law for him, that he be put to death, except those to whom the king shall hold out the golden sceptre, that he may live: but I have not been called to come in unto the king these thirty days. [^11] And they told to Mordecai Esther’s words. [^12] Then Mordecai bade them return answer unto Esther, Think not with thyself that thou shalt escape in the king’s house, more than all the Jews. [^13] For if thou altogether holdest thy peace at this time, then will relief and deliverance arise to the Jews from another place, but thou and thy father’s house will perish: and who knoweth whether thou art not come to the kingdom for such a time as this? [^14] Then Esther bade them return answer unto Mordecai, [^15] Go, gather together all the Jews that are present in Shushan, and fast ye for me, and neither eat nor drink three days, night or day: I also and my maidens will fast in like manner; and so will I go in unto the king, which is not according to the law: and if I perish, I perish. [^16] So Mordecai went his way, and did according to all that Esther had commanded him. [^17] 

[[Esther - 3|<--]] Esther - 4 [[Esther - 5|-->]]

---
# Notes
