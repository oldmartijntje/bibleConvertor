---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/ezra"
  - "#bible/testament/old"
aliases:
  - "Ezra - 1 - American Standard Version"
---
Ezra - 1 [[Ezra - 2|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Ezra]]

# Ezra - 1

Now in the first year of Cyrus king of Persia, that the word of Jehovah by the mouth of Jeremiah might be accomplished, Jehovah stirred up the spirit of Cyrus king of Persia, so that he made a proclamation throughout all his kingdom, and put it also in writing, saying, [^1] Thus saith Cyrus king of Persia, All the kingdoms of the earth hath Jehovah, the God of heaven, given me; and he hath charged me to build him a house in Jerusalem, which is in Judah. [^2] Whosoever there is among you of all his people, his God be with him, and let him go up to Jerusalem, which is in Judah, and build the house of Jehovah, the God of Israel (he is God), which is in Jerusalem. [^3] And whosoever is left, in any place where he sojourneth, let the men of his place help him with silver, and with gold, and with goods, and with beasts, besides the freewill-offering for the house of God which is in Jerusalem. [^4] Then rose up the heads of fathers’ houses of Judah and Benjamin, and the priests, and the Levites, even all whose spirit God had stirred to go up to build the house of Jehovah which is in Jerusalem. [^5] And all they that were round about them strengthened their hands with vessels of silver, with gold, with goods, and with beasts, and with precious things, besides all that was willingly offered. [^6] Also Cyrus the king brought forth the vessels of the house of Jehovah, which Nebuchadnezzar had brought forth out of Jerusalem, and had put in the house of his gods; [^7] even those did Cyrus king of Persia bring forth by the hand of Mithredath the treasurer, and numbered them unto Sheshbazzar, the prince of Judah. [^8] And this is the number of them: thirty platters of gold, a thousand platters of silver, nine and twenty knives, [^9] thirty bowls of gold, silver bowls of a second sort four hundred and ten, and other vessels a thousand. [^10] All the vessels of gold and of silver were five thousand and four hundred. All these did Sheshbazzar bring up, when they of the captivity were brought up from Babylon unto Jerusalem. [^11] 

Ezra - 1 [[Ezra - 2|-->]]

---
# Notes
