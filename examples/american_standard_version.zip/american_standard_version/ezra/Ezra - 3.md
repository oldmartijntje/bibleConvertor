---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/ezra"
  - "#bible/testament/old"
aliases:
  - "Ezra - 3 - American Standard Version"
---
[[Ezra - 2|<--]] Ezra - 3 [[Ezra - 4|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Ezra]]

# Ezra - 3

And when the seventh month was come, and the children of Israel were in the cities, the people gathered themselves together as one man to Jerusalem. [^1] Then stood up Jeshua the son of Jozadak, and his brethren the priests, and Zerubbabel the son of Shealtiel, and his brethren, and builded the altar of the God of Israel, to offer burnt-offerings thereon, as it is written in the law of Moses the man of God. [^2] And they set the altar upon its base; for fear was upon them because of the peoples of the countries: and they offered burnt-offerings thereon unto Jehovah, even burnt-offerings morning and evening. [^3] And they kept the feast of tabernacles, as it is written, and offered the daily burnt-offerings by number, according to the ordinance, as the duty of every day required; [^4] and afterward the continual burnt-offering, and the offerings of the new moons, and of all the set feasts of Jehovah that were consecrated, and of every one that willingly offered a freewill-offering unto Jehovah. [^5] From the first day of the seventh month began they to offer burnt-offerings unto Jehovah: but the foundation of the temple of Jehovah was not yet laid. [^6] They gave money also unto the masons, and to the carpenters; and food, and drink, and oil, unto them of Sidon, and to them of Tyre, to bring cedar-trees from Lebanon to the sea, unto Joppa, according to the grant that they had of Cyrus king of Persia. [^7] Now in the second year of their coming unto the house of God at Jerusalem, in the second month, began Zerubbabel the son of Shealtiel, and Jeshua the son of Jozadak, and the rest of their brethren the priests and the Levites, and all they that were come out of the captivity unto Jerusalem, and appointed the Levites, from twenty years old and upward, to have the oversight of the work of the house of Jehovah. [^8] Then stood Jeshua with his sons and his brethren, Kadmiel and his sons, the sons of Judah, together, to have the oversight of the workmen in the house of God: the sons of Henadad, with their sons and their brethren the Levites. [^9] And when the builders laid the foundation of the temple of Jehovah, they set the priests in their apparel with trumpets, and the Levites the sons of Asaph with cymbals, to praise Jehovah, after the order of David king of Israel. [^10] And they sang one to another in praising and giving thanks unto Jehovah, saying, For he is good, for his lovingkindness endureth for ever toward Israel. And all the people shouted with a great shout, when they praised Jehovah, because the foundation of the house of Jehovah was laid. [^11] But many of the priests and Levites and heads of fathers’ houses, the old men that had seen the first house, when the foundation of this house was laid before their eyes, wept with a loud voice; and many shouted aloud for joy: [^12] so that the people could not discern the noise of the shout of joy from the noise of the weeping of the people; for the people shouted with a loud shout, and the noise was heard afar off. [^13] 

[[Ezra - 2|<--]] Ezra - 3 [[Ezra - 4|-->]]

---
# Notes
