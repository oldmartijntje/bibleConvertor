---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/ezra"
  - "#bible/testament/old"
aliases:
  - "Ezra - 5 - American Standard Version"
---
[[Ezra - 4|<--]] Ezra - 5 [[Ezra - 6|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Ezra]]

# Ezra - 5

Now the prophets, Haggai the prophet, and Zechariah the son of Iddo, prophesied unto the Jews that were in Judah and Jerusalem; in the name of the God of Israel prophesied they unto them. [^1] Then rose up Zerubbabel the son of Shealtiel, and Jeshua the son of Jozadak, and began to build the house of God which is at Jerusalem; and with them were the prophets of God, helping them. [^2] At the same time came to them Tattenai, the governor beyond the River, and Shethar-bozenai, and their companions, and said thus unto them, Who gave you a decree to build this house, and to finish this wall? [^3] Then we told them after this manner, what the names of the men were that were making this building. [^4] But the eye of their God was upon the elders of the Jews, and they did not make them cease, till the matter should come to Darius, and then answer should be returned by letter concerning it. [^5] The copy of the letter that Tattenai, the governor beyond the River, and Shethar-bozenai, and his companions the Apharsachites, who were beyond the River, sent unto Darius the king; [^6] they sent a letter unto him, wherein was written thus: Unto Darius the king, all peace. [^7] Be it known unto the king, that we went into the province of Judah, to the house of the great God, which is builded with great stones, and timber is laid in the walls; and this work goeth on with diligence and prospereth in their hands. [^8] Then asked we those elders, and said unto them thus, Who gave you a decree to build this house, and to finish this wall? [^9] We asked them their names also, to certify thee, that we might write the names of the men that were at the head of them. [^10] And thus they returned us answer, saying, We are the servants of the God of heaven and earth, and are building the house that was builded these many years ago, which a great king of Israel builded and finished. [^11] But after that our fathers had provoked the God of heaven unto wrath, he gave them into the hand of Nebuchadnezzar king of Babylon, the Chaldean, who destroyed this house, and carried the people away into Babylon. [^12] But in the first year of Cyrus king of Babylon, Cyrus the king made a decree to build this house of God. [^13] And the gold and silver vessels also of the house of God, which Nebuchadnezzar took out of the temple that was in Jerusalem, and brought into the temple of Babylon, those did Cyrus the king take out of the temple of Babylon, and they were delivered unto one whose name was Sheshbazzar, whom he had made governor; [^14] and he said unto him, Take these vessels, go, put them in the temple that is in Jerusalem, and let the house of God be builded in its place. [^15] Then came the same Sheshbazzar, and laid the foundations of the house of God which is in Jerusalem: and since that time even until now hath it been in building, and yet it is not completed. [^16] Now therefore, if it seem good to the king, let there be search made in the king’s treasure-house, which is there at Babylon, whether it be so, that a decree was made of Cyrus the king to build this house of God at Jerusalem; and let the king send his pleasure to us concerning this matter. [^17] 

[[Ezra - 4|<--]] Ezra - 5 [[Ezra - 6|-->]]

---
# Notes
