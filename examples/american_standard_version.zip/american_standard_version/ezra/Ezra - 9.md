---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/ezra"
  - "#bible/testament/old"
aliases:
  - "Ezra - 9 - American Standard Version"
---
[[Ezra - 8|<--]] Ezra - 9 [[Ezra - 10|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Ezra]]

# Ezra - 9

Now when these things were done, the princes drew near unto me, saying, The people of Israel, and the priests and the Levites, have not separated themselves from the peoples of the lands, doing according to their abominations, even of the Canaanites, the Hittites, the Perizzites, the Jebusites, the Ammonites, the Moabites, the Egyptians, and the Amorites. [^1] For they have taken of their daughters for themselves and for their sons, so that the holy seed have mingled themselves with the peoples of the lands: yea, the hand of the princes and rulers hath been chief in this trespass. [^2] And when I heard this thing, I rent my garment and my robe, and plucked off the hair of my head and of my beard, and sat down confounded. [^3] Then were assembled unto me every one that trembled at the words of the God of Israel, because of the trespass of them of the captivity; and I sat confounded until the evening oblation. [^4] And at the evening oblation I arose up from my humiliation, even with my garment and my robe rent; and I fell upon my knees, and spread out my hands unto Jehovah my God; [^5] and I said, O my God, I am ashamed and blush to lift up my face to thee, my God; for our iniquities are increased over our head, and our guiltiness is grown up unto the heavens. [^6] Since the days of our fathers we have been exceeding guilty unto this day; and for our iniquities have we, our kings, and our priests, been delivered into the hand of the kings of the lands, to the sword, to captivity, and to plunder, and to confusion of face, as it is this day. [^7] And now for a little moment grace hath been showed from Jehovah our God, to leave us a remnant to escape, and to give us a nail in his holy place, that our God may lighten our eyes, and give us a little reviving in our bondage. [^8] For we are bondmen; yet our God hath not forsaken us in our bondage, but hath extended lovingkindness unto us in the sight of the kings of Persia, to give us a reviving, to set up the house of our God, and to repair the ruins thereof, and to give us a wall in Judah and in Jerusalem. [^9] And now, O our God, what shall we say after this? for we have forsaken thy commandments, [^10] which thou hast commanded by thy servants the prophets, saying, The land, unto which ye go to possess it, is an unclean land through the uncleanness of the peoples of the lands, through their abominations, which have filled it from one end to another with their filthiness: [^11] now therefore give not your daughters unto their sons, neither take their daughters unto your sons, nor seek their peace or their prosperity for ever; that ye may be strong, and eat the good of the land, and leave it for an inheritance to your children for ever. [^12] And after all that is come upon us for our evil deeds, and for our great guilt, seeing that thou our God hast punished us less than our iniquities deserve, and hast given us such a remnant, [^13] shall we again break thy commandments, and join in affinity with the peoples that do these abominations? wouldest not thou be angry with us till thou hadst consumed us, so that there should be no remnant, nor any to escape? [^14] O Jehovah, the God of Israel, thou art righteous; for we are left a remnant that is escaped, as it is this day: behold, we are before thee in our guiltiness; for none can stand before thee because of this. [^15] 

[[Ezra - 8|<--]] Ezra - 9 [[Ezra - 10|-->]]

---
# Notes
