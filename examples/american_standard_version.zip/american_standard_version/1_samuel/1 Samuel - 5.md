---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 5 - American Standard Version"
---
[[1 Samuel - 4|<--]] 1 Samuel - 5 [[1 Samuel - 6|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[1 Samuel]]

# 1 Samuel - 5

Now the Philistines had taken the ark of God, and they brought it from Eben-ezer unto Ashdod. [^1] And the Philistines took the ark of God, and brought it into the house of Dagon, and set it by Dagon. [^2] And when they of Ashdod arose early on the morrow, behold, Dagon was fallen upon his face to the ground before the ark of Jehovah. And they took Dagon, and set him in his place again. [^3] And when they arose early on the morrow morning, behold, Dagon was fallen upon his face to the ground before the ark of Jehovah; and the head of Dagon and both the palms of his hands lay cut off upon the threshold; only the stump of Dagon was left to him. [^4] Therefore neither the priests of Dagon, nor any that come into Dagon’s house, tread on the threshold of Dagon in Ashdod, unto this day. [^5] But the hand of Jehovah was heavy upon them of Ashdod, and he destroyed them, and smote them with tumors, even Ashdod and the borders thereof. [^6] And when the men of Ashdod saw that it was so, they said, The ark of the God of Israel shall not abide with us; for his hand is sore upon us, and upon Dagon our god. [^7] They sent therefore and gathered all the lords of the Philistines unto them, and said, What shall we do with the ark of the God of Israel? And they answered, Let the ark of the God of Israel be carried about unto Gath. And they carried the ark of the God of Israel thither. [^8] And it was so, that, after they had carried it about, the hand of Jehovah was against the city with a very great discomfiture: and he smote the men of the city, both small and great; and tumors brake out upon them. [^9] So they sent the ark of God to Ekron. And it came to pass, as the ark of God came to Ekron, that the Ekronites cried out, saying, They have brought about the ark of the God of Israel to us, to slay us and our people. [^10] They sent therefore and gathered together all the lords of the Philistines, and they said, Send away the ark of the God of Israel, and let it go again to its own place, that it slay us not, and our people. For there was a deadly discomfiture throughout all the city; the hand of God was very heavy there. [^11] And the men that died not were smitten with the tumors; and the cry of the city went up to heaven. [^12] 

[[1 Samuel - 4|<--]] 1 Samuel - 5 [[1 Samuel - 6|-->]]

---
# Notes
