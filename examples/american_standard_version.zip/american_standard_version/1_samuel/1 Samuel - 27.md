---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 27 - American Standard Version"
---
[[1 Samuel - 26|<--]] 1 Samuel - 27 [[1 Samuel - 28|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[1 Samuel]]

# 1 Samuel - 27

And David said in his heart, I shall now perish one day by the hand of Saul: there is nothing better for me than that I should escape into the land of the Philistines; and Saul will despair of me, to seek me any more in all the borders of Israel: so shall I escape out of his hand. [^1] And David arose, and passed over, he and the six hundred men that were with him, unto Achish the son of Maoch, king of Gath. [^2] And David dwelt with Achish at Gath, he and his men, every man with his household, even David with his two wives, Ahinoam the Jezreelitess, and Abigail the Carmelitess, Nabal’s wife. [^3] And it was told Saul that David was fled to Gath: and he sought no more again for him. [^4] And David said unto Achish, If now I have found favor in thine eyes, let them give me a place in one of the cities in the country, that I may dwell there: for why should thy servant dwell in the royal city with thee? [^5] Then Achish gave him Ziklag that day: wherefore Ziklag pertaineth unto the kings of Judah unto this day. [^6] And the number of the days that David dwelt in the country of the Philistines was a full year and four months. [^7] And David and his men went up, and made a raid upon the Geshurites, and the Girzites, and the Amalekites; for those nations were the inhabitants of the land, who were of old, as thou goest to Shur, even unto the land of Egypt. [^8] And David smote the land, and saved neither man nor woman alive, and took away the sheep, and the oxen, and the asses, and the camels, and the apparel; and he returned, and came to Achish. [^9] And Achish said, Against whom have ye made a raid to-day? And David said, Against the South of Judah, and against the South of the Jerahmeelites, and against the South of the Kenites. [^10] And David saved neither man nor woman alive, to bring them to Gath, saying, Lest they should tell of us, saying, So did David, and so hath been his manner all the while he hath dwelt in the country of the Philistines. [^11] And Achish believed David, saying, He hath made his people Israel utterly to abhor him; therefore he shall be my servant for ever. [^12] 

[[1 Samuel - 26|<--]] 1 Samuel - 27 [[1 Samuel - 28|-->]]

---
# Notes
