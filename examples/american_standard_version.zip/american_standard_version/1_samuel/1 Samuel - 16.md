---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 16 - American Standard Version"
---
[[1 Samuel - 15|<--]] 1 Samuel - 16 [[1 Samuel - 17|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[1 Samuel]]

# 1 Samuel - 16

And Jehovah said unto Samuel, How long wilt thou mourn for Saul, seeing I have rejected him from being king over Israel? fill thy horn with oil, and go: I will send thee to Jesse the Beth-lehemite; for I have provided me a king among his sons. [^1] And Samuel said, How can I go? if Saul hear it, he will kill me. And Jehovah said, Take a heifer with thee, and say, I am come to sacrifice to Jehovah. [^2] And call Jesse to the sacrifice, and I will show thee what thou shalt do: and thou shalt anoint unto me him whom I name unto thee. [^3] And Samuel did that which Jehovah spake, and came to Beth-lehem. And the elders of the city came to meet him trembling, and said, Comest thou peaceably? [^4] And he said, Peaceably; I am come to sacrifice unto Jehovah: sanctify yourselves, and come with me to the sacrifice. And he sanctified Jesse and his sons, and called them to the sacrifice. [^5] And it came to pass, when they were come, that he looked on Eliab, and said, Surely Jehovah’s anointed is before him. [^6] But Jehovah said unto Samuel, Look not on his countenance, or on the height of his stature; because I have rejected him: for Jehovah seeth not as man seeth; for man looketh on the outward appearance, but Jehovah looketh on the heart. [^7] Then Jesse called Abinadab, and made him pass before Samuel. And he said, Neither hath Jehovah chosen this. [^8] Then Jesse made Shammah to pass by. And he said, Neither hath Jehovah chosen this. [^9] And Jesse made seven of his sons to pass before Samuel. And Samuel said unto Jesse, Jehovah hath not chosen these. [^10] And Samuel said unto Jesse, Are here all thy children? And he said, There remaineth yet the youngest, and, behold, he is keeping the sheep. And Samuel said unto Jesse, Send and fetch him; for we will not sit down till he come hither. [^11] And he sent, and brought him in. Now he was ruddy, and withal of a beautiful countenance, and goodly to look upon. And Jehovah said, Arise, anoint him; for this is he. [^12] Then Samuel took the horn of oil, and anointed him in the midst of his brethren: and the Spirit of Jehovah came mightily upon David from that day forward. So Samuel rose up, and went to Ramah. [^13] Now the Spirit of Jehovah departed from Saul, and an evil spirit from Jehovah troubled him. [^14] And Saul’s servants said unto him, Behold now, an evil spirit from God troubleth thee. [^15] Let our lord now command thy servants, that are before thee, to seek out a man who is a skilful player on the harp: and it shall come to pass, when the evil spirit from God is upon thee, that he shall play with his hand, and thou shalt be well. [^16] And Saul said unto his servants, Provide me now a man that can play well, and bring him to me. [^17] Then answered one of the young men, and said, Behold, I have seen a son of Jesse the Beth-lehemite, that is skilful in playing, and a mighty man of valor, and a man of war, and prudent in speech, and a comely person; and Jehovah is with him. [^18] Wherefore Saul sent messengers unto Jesse, and said, Send me David thy son, who is with the sheep. [^19] And Jesse took an ass laden with bread, and a bottle of wine, and a kid, and sent them by David his son unto Saul. [^20] And David came to Saul, and stood before him: and he loved him greatly; and he became his armorbearer. [^21] And Saul sent to Jesse, saying, Let David, I pray thee, stand before me; for he hath found favor in my sight. [^22] And it came to pass, when the evil spirit from God was upon Saul, that David took the harp, and played with his hand: so Saul was refreshed, and was well, and the evil spirit departed from him. [^23] 

[[1 Samuel - 15|<--]] 1 Samuel - 16 [[1 Samuel - 17|-->]]

---
# Notes
