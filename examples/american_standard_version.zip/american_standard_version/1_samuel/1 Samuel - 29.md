---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 29 - American Standard Version"
---
[[1 Samuel - 28|<--]] 1 Samuel - 29 [[1 Samuel - 30|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[1 Samuel]]

# 1 Samuel - 29

Now the Philistines gathered together all their hosts to Aphek: and the Israelites encamped by the fountain which is in Jezreel. [^1] And the lords of the Philistines passed on by hundreds, and by thousands; and David and his men passed on in the rearward with Achish. [^2] Then said the princes of the Philistines, What do these Hebrews here? And Achish said unto the princes of the Philistines, Is not this David, the servant of Saul the king of Israel, who hath been with me these days, or rather these years, and I have found no fault in him since he fell away unto me unto this day? [^3] But the princes of the Philistines were wroth with him; and the princes of the Philistines said unto him, Make the man return, that he may go back to his place where thou hast appointed him, and let him not go down with us to battle, lest in the battle he become an adversary to us: for wherewith should this fellow reconcile himself unto his lord? should it not be with the heads of these men? [^4] Is not this David, of whom they sang one to another in dances, saying,Saul hath slain his thousands,And David his ten thousands? [^5] Then Achish called David, and said unto him, As Jehovah liveth, thou hast been upright, and thy going out and thy coming in with me in the host is good in my sight; for I have not found evil in thee since the day of thy coming unto me unto this day: nevertheless the lords favor thee not. [^6] Wherefore now return, and go in peace, that thou displease not the lords of the Philistines. [^7] And David said unto Achish, But what have I done? and what hast thou found in thy servant so long as I have been before thee unto this day, that I may not go and fight against the enemies of my lord the king? [^8] And Achish answered and said to David, I know that thou art good in my sight, as an angel of God: notwithstanding the princes of the Philistines have said, He shall not go up with us to the battle. [^9] Wherefore now rise up early in the morning with the servants of thy lord that are come with thee; and as soon as ye are up early in the morning, and have light, depart. [^10] So David rose up early, he and his men, to depart in the morning, to return into the land of the Philistines. And the Philistines went up to Jezreel. [^11] 

[[1 Samuel - 28|<--]] 1 Samuel - 29 [[1 Samuel - 30|-->]]

---
# Notes
