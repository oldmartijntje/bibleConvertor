---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 7 - American Standard Version"
---
[[1 Samuel - 6|<--]] 1 Samuel - 7 [[1 Samuel - 8|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[1 Samuel]]

# 1 Samuel - 7

And the men of Kiriath-jearim came, and fetched up the ark of Jehovah, and brought it into the house of Abinadab in the hill, and sanctified Eleazar his son to keep the ark of Jehovah. [^1] And it came to pass, from the day that the ark abode in Kiriath-jearim, that the time was long; for it was twenty years: and all the house of Israel lamented after Jehovah. [^2] And Samuel spake unto all the house of Israel, saying, If ye do return unto Jehovah with all your heart, then put away the foreign gods and the Ashtaroth from among you, and direct your hearts unto Jehovah, and serve him only; and he will deliver you out of the hand of the Philistines. [^3] Then the children of Israel did put away the Baalim and the Ashtaroth, and served Jehovah only. [^4] And Samuel said, Gather all Israel to Mizpah, and I will pray for you unto Jehovah. [^5] And they gathered together to Mizpah, and drew water, and poured it out before Jehovah, and fasted on that day, and said there, We have sinned against Jehovah. And Samuel judged the children of Israel in Mizpah. [^6] And when the Philistines heard that the children of Israel were gathered together to Mizpah, the lords of the Philistines went up against Israel. And when the children of Israel heard it, they were afraid of the Philistines. [^7] And the children of Israel said to Samuel, Cease not to cry unto Jehovah our God for us, that he will save us out of the hand of the Philistines. [^8] And Samuel took a sucking lamb, and offered it for a whole burnt-offering unto Jehovah: and Samuel cried unto Jehovah for Israel; and Jehovah answered him. [^9] And as Samuel was offering up the burnt-offering, the Philistines drew near to battle against Israel; but Jehovah thundered with a great thunder on that day upon the Philistines, and discomfited them; and they were smitten down before Israel. [^10] And the men of Israel went out of Mizpah, and pursued the Philistines, and smote them, until they came under Beth-car. [^11] Then Samuel took a stone, and set it between Mizpah and Shen, and called the name of it Eben-ezer, saying, Hitherto hath Jehovah helped us. [^12] So the Philistines were subdued, and they came no more within the border of Israel: and the hand of Jehovah was against the Philistines all the days of Samuel. [^13] And the cities which the Philistines had taken from Israel were restored to Israel, from Ekron even unto Gath; and the border thereof did Israel deliver out of the hand of the Philistines. And there was peace between Israel and the Amorites. [^14] And Samuel judged Israel all the days of his life. [^15] And he went from year to year in circuit to Beth-el, and Gilgal, and Mizpah; and he judged Israel in all those places. [^16] And his return was to Ramah, for there was his house; and there he judged Israel: and he built there an altar unto Jehovah. [^17] 

[[1 Samuel - 6|<--]] 1 Samuel - 7 [[1 Samuel - 8|-->]]

---
# Notes
