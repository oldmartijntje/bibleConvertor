---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 24 - American Standard Version"
---
[[1 Samuel - 23|<--]] 1 Samuel - 24 [[1 Samuel - 25|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[1 Samuel]]

# 1 Samuel - 24

And it came to pass, when Saul was returned from following the Philistines, that it was told him, saying, Behold, David is in the wilderness of En-gedi. [^1] Then Saul took three thousand chosen men out of all Israel, and went to seek David and his men upon the rocks of the wild goats. [^2] And he came to the sheepcotes by the way, where was a cave; and Saul went in to cover his feet. Now David and his men were abiding in the innermost parts of the cave. [^3] And the men of David said unto him, Behold, the day of which Jehovah said unto thee, Behold, I will deliver thine enemy into thy hand, and thou shalt do to him as it shall seem good unto thee. Then David arose, and cut off the skirt of Saul’s robe privily. [^4] And it came to pass afterward, that David’s heart smote him, because he had cut off Saul’s skirt. [^5] And he said unto his men, Jehovah forbid that I should do this thing unto my lord, Jehovah’s anointed, to put forth my hand against him, seeing he is Jehovah’s anointed. [^6] So David checked his men with these words, and suffered them not to rise against Saul. And Saul rose up out of the cave, and went on his way. [^7] David also arose afterward, and went out of the cave, and cried after Saul, saying, My lord the king. And when Saul looked behind him, David bowed with his face to the earth, and did obeisance. [^8] And David said to Saul, Wherefore hearkenest thou to men’s words, saying, Behold, David seeketh thy hurt? [^9] Behold, this day thine eyes have seen how that Jehovah had delivered thee to-day into my hand in the cave: and some bade me kill thee; but mine eye spared thee; and I said, I will not put forth my hand against my lord; for he is Jehovah’s anointed. [^10] Moreover, my father, see, yea, see the skirt of thy robe in my hand; for in that I cut off the skirt of thy robe, and killed thee not, know thou and see that there is neither evil nor transgression in my hand, and I have not sinned against thee, though thou huntest after my life to take it. [^11] Jehovah judge between me and thee, and Jehovah avenge me of thee; but my hand shall not be upon thee. [^12] As saith the proverb of the ancients, Out of the wicked cometh forth wickedness; but my hand shall not be upon thee. [^13] After whom is the king of Israel come out? after whom dost thou pursue? after a dead dog, after a flea. [^14] Jehovah therefore be judge, and give sentence between me and thee, and see, and plead my cause, and deliver me out of thy hand. [^15] And it came to pass, when David had made an end of speaking these words unto Saul, that Saul said, Is this thy voice, my son David? And Saul lifted up his voice, and wept. [^16] And he said to David, Thou art more righteous than I; for thou hast rendered unto me good, whereas I have rendered unto thee evil. [^17] And thou hast declared this day how that thou hast dealt well with me, forasmuch as when Jehovah had delivered me up into thy hand, thou killedst me not. [^18] For if a man find his enemy, will he let him go well away? wherefore Jehovah reward thee good for that which thou hast done unto me this day. [^19] And now, behold, I know that thou shalt surely be king, and that the kingdom of Israel shall be established in thy hand. [^20] Swear now therefore unto me by Jehovah, that thou wilt not cut off my seed after me, and that thou wilt not destroy my name out of my father’s house. [^21] And David sware unto Saul. And Saul went home; but David and his men gat them up unto the stronghold. [^22] 

[[1 Samuel - 23|<--]] 1 Samuel - 24 [[1 Samuel - 25|-->]]

---
# Notes
