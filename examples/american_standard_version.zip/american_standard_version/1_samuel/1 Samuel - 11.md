---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 11 - American Standard Version"
---
[[1 Samuel - 10|<--]] 1 Samuel - 11 [[1 Samuel - 12|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[1 Samuel]]

# 1 Samuel - 11

Then Nahash the Ammonite came up, and encamped against Jabesh-gilead: and all the men of Jabesh said unto Nahash, Make a covenant with us, and we will serve thee. [^1] And Nahash the Ammonite said unto them, On this condition will I make it with you, that all your right eyes be put out; and I will lay it for a reproach upon all Israel. [^2] And the elders of Jabesh said unto him, Give us seven days’ respite, that we may send messengers unto all the borders of Israel; and then, if there be none to save us, we will come out to thee. [^3] Then came the messengers to Gibeah of Saul, and spake these words in the ears of the people: and all the people lifted up their voice, and wept. [^4] And, behold, Saul came following the oxen out of the field; and Saul said, What aileth the people that they weep? And they told him the words of the men of Jabesh. [^5] And the Spirit of God came mightily upon Saul when he heard those words, and his anger was kindled greatly. [^6] And he took a yoke of oxen, and cut them in pieces, and sent them throughout all the borders of Israel by the hand of messengers, saying, Whosoever cometh not forth after Saul and after Samuel, so shall it be done unto his oxen. And the dread of Jehovah fell on the people, and they came out as one man. [^7] And he numbered them in Bezek; and the children of Israel were three hundred thousand, and the men of Judah thirty thousand. [^8] And they said unto the messengers that came, Thus shall ye say unto the men of Jabesh-gilead, To-morrow, by the time the sun is hot, ye shall have deliverance. And the messengers came and told the men of Jabesh; and they were glad. [^9] Therefore the men of Jabesh said, To-morrow we will come out unto you, and ye shall do with us all that seemeth good unto you. [^10] And it was so on the morrow, that Saul put the people in three companies; and they came into the midst of the camp in the morning watch, and smote the Ammonites until the heat of the day: and it came to pass, that they that remained were scattered, so that not two of them were left together. [^11] And the people said unto Samuel, Who is he that said, Shall Saul reign over us? bring the men, that we may put them to death. [^12] And Saul said, There shall not a man be put to death this day; for to-day Jehovah hath wrought deliverance in Israel. [^13] Then said Samuel to the people, Come, and let us go to Gilgal, and renew the kingdom there. [^14] And all the people went to Gilgal; and there they made Saul king before Jehovah in Gilgal; and there they offered sacrifices of peace-offerings before Jehovah; and there Saul and all the men of Israel rejoiced greatly. [^15] 

[[1 Samuel - 10|<--]] 1 Samuel - 11 [[1 Samuel - 12|-->]]

---
# Notes
