---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 31 - American Standard Version"
---
[[1 Samuel - 30|<--]] 1 Samuel - 31

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[1 Samuel]]

# 1 Samuel - 31

Now the Philistines fought against Israel: and the men of Israel fled from before the Philistines, and fell down slain in mount Gilboa. [^1] And the Philistines followed hard upon Saul and upon his sons; and the Philistines slew Jonathan, and Abinadab, and Malchi-shua, the sons of Saul. [^2] And the battle went sore against Saul, and the archers overtook him; and he was greatly distressed by reason of the archers. [^3] Then said Saul to his armorbearer, Draw thy sword, and thrust me through therewith, lest these uncircumcised come and thrust me through, and abuse me. But his armorbearer would not; for he was sore afraid. Therefore Saul took his sword, and fell upon it. [^4] And when his armorbearer saw that Saul was dead, he likewise fell upon his sword, and died with him. [^5] So Saul died, and his three sons, and his armorbearer, and all his men, that same day together. [^6] And when the men of Israel that were on the other side of the valley, and they that were beyond the Jordan, saw that the men of Israel fled, and that Saul and his sons were dead, they forsook the cities, and fled; and the Philistines came and dwelt in them. [^7] And it came to pass on the morrow, when the Philistines came to strip the slain, that they found Saul and his three sons fallen in mount Gilboa. [^8] And they cut off his head, and stripped off his armor, and sent into the land of the Philistines round about, to carry the tidings unto the house of their idols, and to the people. [^9] And they put his armor in the house of the Ashtaroth; and they fastened his body to the wall of Beth-shan. [^10] And when the inhabitants of Jabesh-gilead heard concerning him that which the Philistines had done to Saul, [^11] all the valiant men arose, and went all night, and took the body of Saul and the bodies of his sons from the wall of Beth-shan; and they came to Jabesh, and burnt them there. [^12] And they took their bones, and buried them under the tamarisk-tree in Jabesh, and fasted seven days. [^13] 

[[1 Samuel - 30|<--]] 1 Samuel - 31

---
# Notes
