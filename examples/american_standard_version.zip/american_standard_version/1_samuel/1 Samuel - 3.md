---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 3 - American Standard Version"
---
[[1 Samuel - 2|<--]] 1 Samuel - 3 [[1 Samuel - 4|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[1 Samuel]]

# 1 Samuel - 3

And the child Samuel ministered unto Jehovah before Eli. And the word of Jehovah was precious in those days; there was no frequent vision. [^1] And it came to pass at that time, when Eli was laid down in his place (now his eyes had begun to wax dim, so that he could not see), [^2] and the lamp of God was not yet gone out, and Samuel was laid down to sleep, in the temple of Jehovah, where the ark of God was; [^3] that Jehovah called Samuel: and he said, Here am I. [^4] And he ran unto Eli, and said, Here am I; for thou calledst me. And he said, I called not; lie down again. And he went and lay down. [^5] And Jehovah called yet again, Samuel. And Samuel arose and went to Eli, and said, Here am I; for thou calledst me. And he answered, I called not, my son; lie down again. [^6] Now Samuel did not yet know Jehovah, neither was the word of Jehovah yet revealed unto him. [^7] And Jehovah called Samuel again the third time. And he arose and went to Eli, and said, Here am I; for thou calledst me. And Eli perceived that Jehovah had called the child. [^8] Therefore Eli said unto Samuel, Go, lie down: and it shall be, if he call thee, that thou shalt say, Speak, Jehovah; for thy servant heareth. So Samuel went and lay down in his place. [^9] And Jehovah came, and stood, and called as at other times, Samuel, Samuel. Then Samuel said, Speak; for thy servant heareth. [^10] And Jehovah said to Samuel, Behold, I will do a thing in Israel, at which both the ears of every one that heareth it shall tingle. [^11] In that day I will perform against Eli all that I have spoken concerning his house, from the beginning even unto the end. [^12] For I have told him that I will judge his house for ever, for the iniquity which he knew, because his sons did bring a curse upon themselves, and he restrained them not. [^13] And therefore I have sworn unto the house of Eli, that the iniquity of Eli’s house shall not be expiated with sacrifice nor offering for ever. [^14] And Samuel lay until the morning, and opened the doors of the house of Jehovah. And Samuel feared to show Eli the vision. [^15] Then Eli called Samuel, and said, Samuel, my son. And he said, Here am I. [^16] And he said, What is the thing that Jehovah hath spoken unto thee? I pray thee, hide it not from me: God do so to thee, and more also, if thou hide anything from me of all the things that he spake unto thee. [^17] And Samuel told him every whit, and hid nothing from him. And he said, It is Jehovah: let him do what seemeth him good. [^18] And Samuel grew, and Jehovah was with him, and did let none of his words fall to the ground. [^19] And all Israel from Dan even to Beer-sheba knew that Samuel was established to be a prophet of Jehovah. [^20] And Jehovah appeared again in Shiloh; for Jehovah revealed himself to Samuel in Shiloh by the word of Jehovah. [^21] 

[[1 Samuel - 2|<--]] 1 Samuel - 3 [[1 Samuel - 4|-->]]

---
# Notes
