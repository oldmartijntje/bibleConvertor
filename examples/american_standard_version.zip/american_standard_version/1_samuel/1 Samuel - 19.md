---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 19 - American Standard Version"
---
[[1 Samuel - 18|<--]] 1 Samuel - 19 [[1 Samuel - 20|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[1 Samuel]]

# 1 Samuel - 19

And Saul spake to Jonathan his son, and to all his servants, that they should slay David. But Jonathan, Saul’s son, delighted much in David. [^1] And Jonathan told David, saying, Saul my father seeketh to slay thee: now therefore, I pray thee, take heed to thyself in the morning, and abide in a secret place, and hide thyself: [^2] and I will go out and stand beside my father in the field where thou art, and I will commune with my father of thee; and if I see aught, I will tell thee. [^3] And Jonathan spake good of David unto Saul his father, and said unto him, Let not the king sin against his servant, against David; because he hath not sinned against thee, and because his works have been to thee-ward very good: [^4] for he put his life in his hand, and smote the Philistine, and Jehovah wrought a great victory for all Israel: thou sawest it, and didst rejoice; wherefore then wilt thou sin against innocent blood, to slay David without a cause? [^5] And Saul hearkened unto the voice of Jonathan: and Saul sware, As Jehovah liveth, he shall not be put to death. [^6] And Jonathan called David, and Jonathan showed him all those things. And Jonathan brought David to Saul, and he was in his presence, as beforetime. [^7] And there was war again: and David went out, and fought with the Philistines, and slew them with a great slaughter; and they fled before him. [^8] And an evil spirit from Jehovah was upon Saul, as he sat in his house with his spear in his hand; and David was playing with his hand. [^9] And Saul sought to smite David even to the wall with the spear; but he slipped away out of Saul’s presence, and he smote the spear into the wall: and David fled, and escaped that night. [^10] And Saul sent messengers unto David’s house, to watch him, and to slay him in the morning: and Michal, David’s wife, told him, saying, If thou save not thy life to-night, to-morrow thou wilt be slain. [^11] So Michal let David down through the window: and he went, and fled, and escaped. [^12] And Michal took the teraphim, and laid it in the bed, and put a pillow of goats’ hair at the head thereof, and covered it with the clothes. [^13] And when Saul sent messengers to take David, she said, He is sick. [^14] And Saul sent the messengers to see David, saying, Bring him up to me in the bed, that I may slay him. [^15] And when the messengers came in, behold, the teraphim was in the bed, with the pillow of goats’ hair at the head thereof. [^16] And Saul said unto Michal, Why hast thou deceived me thus, and let mine enemy go, so that he is escaped? And Michal answered Saul, He said unto me, Let me go; why should I kill thee? [^17] Now David fled, and escaped, and came to Samuel to Ramah, and told him all that Saul had done to him. And he and Samuel went and dwelt in Naioth. [^18] And it was told Saul, saying, Behold, David is at Naioth in Ramah. [^19] And Saul sent messengers to take David: and when they saw the company of the prophets prophesying, and Samuel standing as head over them, the Spirit of God came upon the messengers of Saul, and they also prophesied. [^20] And when it was told Saul, he sent other messengers, and they also prophesied. And Saul sent messengers again the third time, and they also prophesied. [^21] Then went he also to Ramah, and came to the great well that is in Secu: and he asked and said, Where are Samuel and David? And one said, Behold, they are at Naioth in Ramah. [^22] And he went thither to Naioth in Ramah: and the Spirit of God came upon him also, and he went on, and prophesied, until he came to Naioth in Ramah. [^23] And he also stripped off his clothes, and he also prophesied before Samuel, and lay down naked all that day and all that night. Wherefore they say, Is Saul also among the prophets? [^24] 

[[1 Samuel - 18|<--]] 1 Samuel - 19 [[1 Samuel - 20|-->]]

---
# Notes
