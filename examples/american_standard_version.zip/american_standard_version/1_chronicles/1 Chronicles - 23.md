---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 23 - American Standard Version"
---
[[1 Chronicles - 22|<--]] 1 Chronicles - 23 [[1 Chronicles - 24|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[1 Chronicles]]

# 1 Chronicles - 23

Now David was old and full of days; and he made Solomon his son king over Israel. [^1] And he gathered together all the princes of Israel, with the priests and the Levites. [^2] And the Levites were numbered from thirty years old and upward: and their number by their polls, man by man, was thirty and eight thousand. [^3] Of these, twenty and four thousand were to oversee the work of the house of Jehovah; and six thousand were officers and judges; [^4] and four thousand were doorkeepers; and four thousand praised Jehovah with the instruments which I made, said David, to praise therewith. [^5] And David divided them into courses according to the sons of Levi: Gershon, Kohath, and Merari. [^6] Of the Gershonites: Ladan and Shimei. [^7] The sons of Ladan: Jehiel the chief, and Zetham, and Joel, three. [^8] The sons of Shimei: Shelomoth, and Haziel, and Haran, three. These were the heads of the fathers’ houses of Ladan. [^9] And the sons of Shimei: Jahath, Zina, and Jeush, and Beriah. These four were the sons of Shimei. [^10] And Jahath was the chief, and Zizah the second: but Jeush and Beriah had not many sons; therefore they became a fathers’ house in one reckoning. [^11] The sons of Kohath: Amram, Izhar, Hebron, and Uzziel, four. [^12] The sons of Amram: Aaron and Moses; and Aaron was separated, that he should sanctify the most holy things, he and his sons, for ever, to burn incense before Jehovah, to minister unto him, and to bless in his name, for ever. [^13] But as for Moses the man of God, his sons were named among the tribe of Levi. [^14] The sons of Moses: Gershom and Eliezer. [^15] The sons of Gershom: Shebuel the chief. [^16] And the sons of Eliezer were: Rehabiah the chief; and Eliezer had no other sons; but the sons of Rehabiah were very many. [^17] The sons of Izhar: Shelomith the chief. [^18] The sons of Hebron: Jeriah the chief, Amariah the second, Jahaziel the third, and Jekameam the fourth. [^19] The sons of Uzziel: Micah the chief, and Isshiah the second. [^20] The sons of Merari: Mahli and Mushi. The sons of Mahli: Eleazar and Kish. [^21] And Eleazar died, and had no sons, but daughters only: and their brethren the sons of Kish took them to wife. [^22] The sons of Mushi: Mahli, and Eder, and Jeremoth, three. [^23] These were the sons of Levi after their fathers’ houses, even the heads of the fathers’ houses of those of them that were counted, in the number of names by their polls, who did the work for the service of the house of Jehovah, from twenty years old and upward. [^24] For David said, Jehovah, the God of Israel, hath given rest unto his people; and he dwelleth in Jerusalem for ever: [^25] and also the Levites shall no more have need to carry the tabernacle and all the vessels of it for the service thereof. [^26] For by the last words of David the sons of Levi were numbered, from twenty years old and upward. [^27] For their office was to wait on the sons of Aaron for the service of the house of Jehovah, in the courts, and in the chambers, and in the purifying of all holy things, even the work of the service of the house of God; [^28] for the showbread also, and for the fine flour for a meal-offering, whether of unleavened wafers, or of that which is baked in the pan, or of that which is soaked, and for all manner of measure and size; [^29] and to stand every morning to thank and praise Jehovah, and likewise at even; [^30] and to offer all burnt-offerings unto Jehovah, on the sabbaths, on the new moons, and on the set feasts, in number according to the ordinance concerning them, continually before Jehovah; [^31] and that they should keep the charge of the tent of meeting, and the charge of the holy place, and the charge of the sons of Aaron their brethren, for the service of the house of Jehovah. [^32] 

[[1 Chronicles - 22|<--]] 1 Chronicles - 23 [[1 Chronicles - 24|-->]]

---
# Notes
