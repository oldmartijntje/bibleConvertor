---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 20 - American Standard Version"
---
[[1 Chronicles - 19|<--]] 1 Chronicles - 20 [[1 Chronicles - 21|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[1 Chronicles]]

# 1 Chronicles - 20

And it came to pass, at the time of the return of the year, at the time when kings go out to battle, that Joab led forth the army, and wasted the country of the children of Ammon, and came and besieged Rabbah. But David tarried at Jerusalem. And Joab smote Rabbah, and overthrew it. [^1] And David took the crown of their king from off his head, and found it to weigh a talent of gold, and there were precious stones in it; and it was set upon David’s head: and he brought forth the spoil of the city, exceeding much. [^2] And he brought forth the people that were therein, and cut them with saws, and with harrows of iron, and with axes. And thus did David unto all the cities of the children of Ammon. And David and all the people returned to Jerusalem. [^3] And it came to pass after this, that there arose war at Gezer with the Philistines: then Sibbecai the Hushathite slew Sippai, of the sons of the giant; and they were subdued. [^4] And there was again war with the Philistines; and Elhanan the son of Jair slew Lahmi the brother of Goliath the Gittite, the staff of whose spear was like a weaver’s beam. [^5] And there was again war at Gath, where was a man of great stature, whose fingers and toes were four and twenty, six on each hand, and six on each foot; and he also was born unto the giant. [^6] And when he defied Israel, Jonathan the son of Shimea David’s brother slew him. [^7] These were born unto the giant in Gath; and they fell by the hand of David, and by the hand of his servants. [^8] 

[[1 Chronicles - 19|<--]] 1 Chronicles - 20 [[1 Chronicles - 21|-->]]

---
# Notes
