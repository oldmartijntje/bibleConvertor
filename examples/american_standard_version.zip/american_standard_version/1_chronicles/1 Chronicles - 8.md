---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 8 - American Standard Version"
---
[[1 Chronicles - 7|<--]] 1 Chronicles - 8 [[1 Chronicles - 9|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[1 Chronicles]]

# 1 Chronicles - 8

And Benjamin begat Bela his first-born, Ashbel the second, and Aharah the third, [^1] Nohah the fourth, and Rapha the fifth. [^2] And Bela had sons: Addar, and Gera, and Abihud, [^3] and Abishua, and Naaman, and Ahoah, [^4] and Gera, and Shephuphan, and Huram. [^5] And these are the sons of Ehud: these are the heads of fathers’ houses of the inhabitants of Geba, and they carried them captive to Manahath: [^6] and Naaman, and Ahijah, and Gera, he carried them captive; and he begat Uzza and Ahihud. [^7] And Shaharaim begat children in the field of Moab, after he had sent them away; Hushim and Baara were his wives. [^8] And he begat of Hodesh his wife, Jobab, and Zibia, and Mesha, and Malcam, [^9] and Jeuz, and Shachia, and Mirmah. These were his sons, heads of fathers’ houses. [^10] And of Hushim he begat Abitub and Elpaal. [^11] And the sons of Elpaal: Eber, and Misham, and Shemed, who built Ono and Lod, with the towns thereof; [^12] and Beriah, and Shema, who were heads of fathers’ houses of the inhabitants of Aijalon, who put to flight the inhabitants of Gath; [^13] and Ahio, Shashak, and Jeremoth, [^14] and Zebadiah, and Arad, and Eder, [^15] and Michael, and Ishpah, and Joha, the sons of Beriah, [^16] and Zebadiah, and Meshullam, and Hizki, and Heber, [^17] and Ishmerai, and Izliah, and Jobab, the sons of Elpaal, [^18] and Jakim, and Zichri, and Zabdi, [^19] and Elienai, and Zillethai, and Eliel, [^20] and Adaiah, and Beraiah, and Shimrath, the sons of Shimei, [^21] and Ishpan, and Eber, and Eliel, [^22] and Abdon, and Zichri, and Hanan, [^23] and Hananiah, and Elam, and Anthothijah, [^24] and Iphdeiah, and Penuel, the sons of Shashak, [^25] and Shamsherai, and Shehariah, and Athaliah, [^26] and Jaareshiah, and Elijah, and Zichri, the sons of Jeroham. [^27] These were heads of fathers’ houses throughout their generations, chief men: these dwelt in Jerusalem. [^28] And in Gibeon there dwelt the father of Gibeon, Jeiel, whose wife’s name was Maacah; [^29] and his first-born son Abdon, and Zur, and Kish, and Baal, and Nadab, [^30] and Gedor, and Ahio, and Zecher. [^31] And Mikloth begat Shimeah. And they also dwelt with their brethren in Jerusalem, over against their brethren. [^32] And Ner begat Kish; and Kish begat Saul; and Saul begat Jonathan, and Malchi-shua, and Abinadab, and Eshbaal. [^33] And the son of Jonathan was Merib-baal; and Merib-baal begat Micah. [^34] And the sons of Micah: Pithon, and Melech, and Tarea, and Ahaz. [^35] And Ahaz begat Jehoaddah; and Jehoaddah begat Alemeth, and Azmaveth, and Zimri; and Zimri begat Moza. [^36] And Moza begat Binea; Raphah was his son, Eleasah his son, Azel his son. [^37] And Azel had six sons, whose names are these: Azrikam, Bocheru, and Ishmael, and Sheariah, and Obadiah, and Hanan. All these were the sons of Azel. [^38] And the sons of Eshek his brother: Ulam his first-born, Jeush the second, and Eliphelet the third. [^39] And the sons of Ulam were mighty men of valor, archers, and had many sons, and sons’ sons, a hundred and fifty. All these were of the sons of Benjamin. [^40] 

[[1 Chronicles - 7|<--]] 1 Chronicles - 8 [[1 Chronicles - 9|-->]]

---
# Notes
