---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 22 - American Standard Version"
---
[[1 Chronicles - 21|<--]] 1 Chronicles - 22 [[1 Chronicles - 23|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[1 Chronicles]]

# 1 Chronicles - 22

Then David said, This is the house of Jehovah God, and this is the altar of burnt-offering for Israel. [^1] And David commanded to gather together the sojourners that were in the land of Israel; and he set masons to hew wrought stones to build the house of God. [^2] And David prepared iron in abundance for the nails for the doors of the gates, and for the couplings; and brass in abundance without weight; [^3] and cedar-trees without number: for the Sidonians and they of Tyre brought cedar-trees in abundance to David. [^4] And David said, Solomon my son is young and tender, and the house that is to be builded for Jehovah must be exceeding magnificent, of fame and of glory throughout all countries: I will therefore make preparation for it. So David prepared abundantly before his death. [^5] Then he called for Solomon his son, and charged him to build a house for Jehovah, the God of Israel. [^6] And David said to Solomon his son, As for me, it was in my heart to build a house unto the name of Jehovah my God. [^7] But the word of Jehovah came to me, saying, Thou hast shed blood abundantly, and hast made great wars: thou shalt not build a house unto my name, because thou hast shed much blood upon the earth in my sight. [^8] Behold, a son shall be born to thee, who shall be a man of rest; and I will give him rest from all his enemies round about; for his name shall be Solomon, and I will give peace and quietness unto Israel in his days. [^9] He shall build a house for my name; and he shall be my son, and I will be his father; and I will establish the throne of his kingdom over Israel for ever. [^10] Now, my son, Jehovah be with thee; and prosper thou, and build the house of Jehovah thy God, as he hath spoken concerning thee. [^11] Only Jehovah give thee discretion and understanding, and give thee charge concerning Israel; that so thou mayest keep the law of Jehovah thy God. [^12] Then shalt thou prosper, if thou observe to do the statutes and the ordinances which Jehovah charged Moses with concerning Israel: be strong, and of good courage; fear not, neither be dismayed. [^13] Now, behold, in my affliction I have prepared for the house of Jehovah a hundred thousand talents of gold, and a thousand thousand talents of silver, and of brass and iron without weight; for it is in abundance: timber also and stone have I prepared; and thou mayest add thereto. [^14] Moreover there are workmen with thee in abundance, hewers and workers of stone and timber, and all men that are skilful in every manner of work: [^15] of the gold, the silver, and the brass, and the iron, there is no number. Arise and be doing, and Jehovah be with thee. [^16] David also commanded all the princes of Israel to help Solomon his son, saying, [^17] Is not Jehovah your God with you? and hath he not given you rest on every side? for he hath delivered the inhabitants of the land into my hand; and the land is subdued before Jehovah, and before his people. [^18] Now set your heart and your soul to seek after Jehovah your God; arise therefore, and build ye the sanctuary of Jehovah God, to bring the ark of the covenant of Jehovah, and the holy vessels of God, into the house that is to be built to the name of Jehovah. [^19] 

[[1 Chronicles - 21|<--]] 1 Chronicles - 22 [[1 Chronicles - 23|-->]]

---
# Notes
