---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 24 - American Standard Version"
---
[[1 Chronicles - 23|<--]] 1 Chronicles - 24 [[1 Chronicles - 25|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[1 Chronicles]]

# 1 Chronicles - 24

And the courses of the sons of Aaron were these. The sons of Aaron: Nadab and Abihu, Eleazar and Ithamar. [^1] But Nadab and Abihu died before their father, and had no children: therefore Eleazar and Ithamar executed the priest’s office. [^2] And David with Zadok of the sons of Eleazar, and Ahimelech of the sons of Ithamar, divided them according to their ordering in their service. [^3] And there were more chief men found of the sons of Eleazar than of the sons of Ithamar; and thus were they divided: of the sons of Eleazar there were sixteen, heads of fathers’ houses; and of the sons of Ithamar, according to their fathers’ houses, eight. [^4] Thus were they divided by lot, one sort with another; for there were princes of the sanctuary, and princes of God, both of the sons of Eleazar, and of the sons of Ithamar. [^5] And Shemaiah the son of Nethanel the scribe, who was of the Levites, wrote them in the presence of the king, and the princes, and Zadok the priest, and Ahimelech the son of Abiathar, and the heads of the fathers’ houses of the priests and of the Levites; one fathers’ house being taken for Eleazar, and one taken for Ithamar. [^6] Now the first lot came forth to Jehoiarib, the second to Jedaiah, [^7] the third to Harim, the fourth to Seorim, [^8] the fifth to Malchijah, the sixth to Mijamin, [^9] the seventh to Hakkoz, the eighth to Abijah, [^10] the ninth to Jeshua, the tenth to Shecaniah, [^11] the eleventh to Eliashib, the twelfth to Jakim, [^12] the thirteenth to Huppah, the fourteenth to Jeshebeab, [^13] the fifteenth to Bilgah, the sixteenth to Immer, [^14] the seventeenth to Hezir, the eighteenth to Happizzez, [^15] the nineteenth to Pethahiah, the twentieth to Jehezkel, [^16] the one and twentieth to Jachin, the two and twentieth to Gamul, [^17] the three and twentieth to Delaiah, the four and twentieth to Maaziah. [^18] This was the ordering of them in their service, to come into the house of Jehovah according to the ordinance given unto them by Aaron their father, as Jehovah, the God of Israel, had commanded him. [^19] And of the rest of the sons of Levi: of the sons of Amram, Shubael; of the sons of Shubael, Jehdeiah. [^20] Of Rehabiah: of the sons of Rehabiah, Isshiah the chief. [^21] Of the Izharites, Shelomoth; of the sons of Shelomoth, Jahath. [^22] And the sons of Hebron: Jeriah the chief, Amariah the second, Jahaziel the third, Jekameam the fourth. [^23] The sons of Uzziel, Micah; of the sons of Micah, Shamir. [^24] The brother of Micah, Isshiah; of the sons of Isshiah, Zechariah. [^25] The sons of Merari: Mahli and Mushi; the sons of Jaaziah: Beno. [^26] The sons of Merari: of Jaaziah, Beno, and Shoham, and Zaccur, and Ibri. [^27] Of Mahli: Eleazar, who had no sons. [^28] Of Kish; the sons of Kish: Jerahmeel. [^29] And the sons of Mushi: Mahli, and Eder, and Jerimoth. These were the sons of the Levites after their fathers’ houses. [^30] These likewise cast lots even as their brethren the sons of Aaron in the presence of David the king, and Zadok, and Ahimelech, and the heads of the fathers’ houses of the priests and of the Levites; the fathers’ houses of the chief even as those of his younger brother. [^31] 

[[1 Chronicles - 23|<--]] 1 Chronicles - 24 [[1 Chronicles - 25|-->]]

---
# Notes
