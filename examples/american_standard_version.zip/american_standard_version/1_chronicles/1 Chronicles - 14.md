---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 14 - American Standard Version"
---
[[1 Chronicles - 13|<--]] 1 Chronicles - 14 [[1 Chronicles - 15|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[1 Chronicles]]

# 1 Chronicles - 14

And Hiram king of Tyre sent messengers to David, and cedar-trees, and masons, and carpenters, to build him a house. [^1] And David perceived that Jehovah had established him king over Israel; for his kingdom was exalted on high, for his people Israel’s sake. [^2] And David took more wives at Jerusalem; and David begat more sons and daughters. [^3] And these are the names of the children whom he had in Jerusalem: Shammua, and Shobab, Nathan, and Solomon, [^4] and Ibhar, and Elishua, and Elpelet, [^5] and Nogah, and Nepheg, and Japhia, [^6] and Elishama, and Beeliada, and Eliphelet. [^7] And when the Philistines heard that David was anointed king over all Israel, all the Philistines went up to seek David: and David heard of it, and went out against them. [^8] Now the Philistines had come and made a raid in the valley of Rephaim. [^9] And David inquired of God, saying, Shall I go up against the Philistines? and wilt thou deliver them into my hand? And Jehovah said unto him, Go up; for I will deliver them into thy hand. [^10] So they came up to Baal-perazim, and David smote them there; and David said, God hath broken mine enemies by my hand, like the breach of waters. Therefore they called the name of that place Baal-perazim. [^11] And they left their gods there; and David gave commandment, and they were burned with fire. [^12] And the Philistines yet again made a raid in the valley. [^13] And David inquired again of God; and God said unto him, Thou shalt not go up after them: turn away from them, and come upon them over against the mulberry-trees. [^14] And it shall be, when thou hearest the sound of marching in the tops of the mulberry-trees, that then thou shalt go out to battle; for God is gone out before thee to smite the host of the Philistines. [^15] And David did as God commanded him: and they smote the host of the Philistines from Gibeon even to Gezer. [^16] And the fame of David went out into all lands; and Jehovah brought the fear of him upon all nations. [^17] 

[[1 Chronicles - 13|<--]] 1 Chronicles - 14 [[1 Chronicles - 15|-->]]

---
# Notes
