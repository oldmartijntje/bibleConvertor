---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 25 - American Standard Version"
---
[[1 Chronicles - 24|<--]] 1 Chronicles - 25 [[1 Chronicles - 26|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[1 Chronicles]]

# 1 Chronicles - 25

Moreover David and the captains of the host set apart for the service certain of the sons of Asaph, and of Heman, and of Jeduthun, who should prophesy with harps, with psalteries, and with cymbals: and the number of them that did the work according to their service was: [^1] of the sons of Asaph: Zaccur, and Joseph, and Nethaniah, and Asharelah, the sons of Asaph, under the hand of Asaph, who prophesied after the order of the king. [^2] Of Jeduthun; the sons of Jeduthun: Gedaliah, and Zeri, and Jeshaiah, Hashabiah, and Mattithiah, six, under the hands of their father Jeduthun with the harp, who prophesied in giving thanks and praising Jehovah. [^3] Of Heman; the sons of Heman: Bukkiah, Mattaniah, Uzziel, Shebuel, and Jerimoth, Hananiah, Hanani, Eliathah, Giddalti, and Romamti-ezer, Joshbekashah, Mallothi, Hothir, Mahazioth. [^4] All these were the sons of Heman the king’s seer in the words of God, to lift up the horn. And God gave to Heman fourteen sons and three daughters. [^5] All these were under the hands of their father for song in the house of Jehovah, with cymbals, psalteries, and harps, for the service of the house of God; Asaph, Jeduthun, and Heman being under the order of the king. [^6] And the number of them, with their brethren that were instructed in singing unto Jehovah, even all that were skilful, was two hundred fourscore and eight. [^7] And they cast lots for their offices, all alike, as well the small as the great, the teacher as the scholar. [^8] Now the first lot came forth for Asaph to Joseph: the second to Gedaliah; he and his brethren and sons were twelve: [^9] the third to Zaccur, his sons and his brethren, twelve: [^10] the fourth to Izri, his sons and his brethren, twelve: [^11] the fifth to Nethaniah, his sons and his brethren, twelve: [^12] the sixth to Bukkiah, his sons and his brethren, twelve: [^13] the seventh to Jesharelah, his sons and his brethren, twelve: [^14] the eighth to Jeshaiah, his sons and his brethren, twelve: [^15] the ninth to Mattaniah, his sons and his brethren, twelve: [^16] the tenth to Shimei, his sons and his brethren, twelve: [^17] the eleventh to Azarel, his sons and his brethren, twelve: [^18] the twelfth to Hashabiah, his sons and his brethren, twelve: [^19] for the thirteenth, Shubael, his sons and his brethren, twelve: [^20] for the fourteenth, Mattithiah, his sons and his brethren, twelve: [^21] for the fifteenth to Jeremoth, his sons and his brethren, twelve: [^22] for the sixteenth to Hananiah, his sons and his brethren, twelve: [^23] for the seventeenth to Joshbekashah, his sons and his brethren, twelve: [^24] for the eighteenth to Hanani, his sons and his brethren, twelve: [^25] for the nineteenth to Mallothi, his sons and his brethren, twelve: [^26] for the twentieth to Eliathah, his sons and his brethren, twelve: [^27] for the one and twentieth to Hothir, his sons and his brethren, twelve: [^28] for the two and twentieth to Giddalti, his sons and his brethren, twelve: [^29] for the three and twentieth to Mahazioth, his sons and his brethren, twelve: [^30] for the four and twentieth to Romamtiezer, his sons and his brethren, twelve. [^31] 

[[1 Chronicles - 24|<--]] 1 Chronicles - 25 [[1 Chronicles - 26|-->]]

---
# Notes
