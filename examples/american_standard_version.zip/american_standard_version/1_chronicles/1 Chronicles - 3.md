---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 3 - American Standard Version"
---
[[1 Chronicles - 2|<--]] 1 Chronicles - 3 [[1 Chronicles - 4|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[1 Chronicles]]

# 1 Chronicles - 3

Now these were the sons of David, that were born unto him in Hebron: the first-born, Amnon, of Ahinoam the Jezreelitess; the second, Daniel, of Abigail the Carmelitess; [^1] the third, Absalom the son of Maacah the daughter of Talmai king of Geshur; the fourth, Adonijah the son of Haggith; [^2] the fifth, Shephatiah of Abital; the sixth, Ithream by Eglah his wife: [^3] six were born unto him in Hebron; and there he reigned seven years and six months. And in Jerusalem he reigned thirty and three years; [^4] and these were born unto him in Jerusalem: Shimea, and Shobab, and Nathan, and Solomon, four, of Bath-shua the daughter of Ammiel; [^5] and Ibhar, and Elishama, and Eliphelet, [^6] and Nogah, and Nepheg, and Japhia, [^7] and Elishama, and Eliada, and Eliphelet, nine. [^8] All these were the sons of David, besides the sons of the concubines; and Tamar was their sister. [^9] And Solomon’s son was Rehoboam, Abijah his son, Asa his son, Jehoshaphat his son, [^10] Joram his son, Ahaziah his son, Joash his son, [^11] Amaziah his son, Azariah his son, Jotham his son, [^12] Ahaz his son, Hezekiah his son, Manasseh his son, [^13] Amon his son, Josiah his son. [^14] And the sons of Josiah: the first-born Johanan, the second Jehoiakim, the third Zedekiah, the fourth Shallum. [^15] And the sons of Jehoiakim: Jeconiah his son, Zedekiah his son. [^16] And the sons of Jeconiah, the captive: Shealtiel his son, [^17] and Malchiram, and Pedaiah, and Shenazzar, Jekamiah, Hoshama, and Nedabiah. [^18] And the sons of Pedaiah: Zerubbabel, and Shimei. And the sons of Zerubbabel: Meshullam, and Hananiah; and Shelomith was their sister; [^19] and Hashubah, and Ohel, and Berechiah, and Hasadiah, Jushab-hesed, five. [^20] And the sons of Hananiah: Pelatiah, and Jeshaiah; the sons of Rephaiah, the sons of Arnan, the sons of Obadiah, the sons of Shecaniah. [^21] And the sons of Shecaniah: Shemaiah. And the sons of Shemaiah: Hattush, and Igal, and Bariah, and Neariah, and Shaphat, six. [^22] And the sons of Neariah: Elioenai, and Hizkiah, and Azrikam, three. [^23] And the sons of Elioenai: Hodaviah, and Eliashib, and Pelaiah, and Akkub, and Johanan, and Delaiah, and Anani, seven. [^24] 

[[1 Chronicles - 2|<--]] 1 Chronicles - 3 [[1 Chronicles - 4|-->]]

---
# Notes
