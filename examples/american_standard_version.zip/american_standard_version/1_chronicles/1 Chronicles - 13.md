---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 13 - American Standard Version"
---
[[1 Chronicles - 12|<--]] 1 Chronicles - 13 [[1 Chronicles - 14|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[1 Chronicles]]

# 1 Chronicles - 13

And David consulted with the captains of thousands and of hundreds, even with every leader. [^1] And David said unto all the assembly of Israel, If it seem good unto you, and if it be of Jehovah our God, let us send abroad every where unto our brethren that are left in all the land of Israel, with whom the priests and Levites are in their cities that have suburbs, that they may gather themselves unto us; [^2] and let us bring again the ark of our God to us: for we sought not unto it in the days of Saul. [^3] And all the assembly said that they would do so; for the thing was right in the eyes of all the people. [^4] So David assembled all Israel together, from the Shihor the brook of Egypt even unto the entrance of Hamath, to bring the ark of God from Kiriath-jearim. [^5] And David went up, and all Israel, to Baalah, that is, to Kiriath-jearim, which belonged to Judah, to bring up from thence the ark of God Jehovah that sitteth above the cherubim, that is called by the Name. [^6] And they carried the ark of God upon a new cart, and brought it out of the house of Abinadab: and Uzza and Ahio drove the cart. [^7] And David and all Israel played before God with all their might, even with songs, and with harps, and with psalteries, and with timbrels, and with cymbals, and with trumpets. [^8] And when they came unto the threshing-floor of Chidon, Uzza put forth his hand to hold the ark; for the oxen stumbled. [^9] And the anger of Jehovah was kindled against Uzza, and he smote him, because he put forth his hand to the ark; and there he died before God. [^10] And David was displeased, because Jehovah had broken forth upon Uzza: and he called that place Perez-uzza, unto this day. [^11] And David was afraid of God that day, saying, How shall I bring the ark of God home to me? [^12] So David removed not the ark unto him into the city of David, but carried it aside into the house of Obed-edom the Gittite. [^13] And the ark of God remained with the family of Obed-edom in his house three months: and Jehovah blessed the house of Obed-edom, and all that he had. [^14] 

[[1 Chronicles - 12|<--]] 1 Chronicles - 13 [[1 Chronicles - 14|-->]]

---
# Notes
