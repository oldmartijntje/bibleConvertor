---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 19 - American Standard Version"
---
[[1 Chronicles - 18|<--]] 1 Chronicles - 19 [[1 Chronicles - 20|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[1 Chronicles]]

# 1 Chronicles - 19

And it came to pass after this, that Nahash the king of the children of Ammon died, and his son reigned in his stead. [^1] And David said, I will show kindness unto Hanun the son of Nahash, because his father showed kindness to me. So David sent messengers to comfort him concerning his father. And David’s servants came into the land of the children of Ammon to Hanun, to comfort him. [^2] But the princes of the children of Ammon said to Hanun, Thinkest thou that David doth honor thy father, in that he hath sent comforters unto thee? are not his servants come unto thee to search, and to overthrow, and to spy out the land? [^3] So Hanun took David’s servants, and shaved them, and cut off their garments in the middle, even to their buttocks, and sent them away. [^4] Then there went certain persons, and told David how the men were served. And he sent to meet them; for the men were greatly ashamed. And the king said, Tarry at Jericho until your beards be grown, and then return. [^5] And when the children of Ammon saw that they had made themselves odious to David, Hanun and the children of Ammon sent a thousand talents of silver to hire them chariots and horsemen out of Mesopotamia, and out of Aram-maacah, and out of Zobah. [^6] So they hired them thirty and two thousand chariots, and the king of Maacah and his people, who came and encamped before Medeba. And the children of Ammon gathered themselves together from their cities, and came to battle. [^7] And when David heard of it, he sent Joab, and all the host of the mighty men. [^8] And the children of Ammon came out, and put the battle in array at the gate of the city: and the kings that were come were by themselves in the field. [^9] Now when Joab saw that the battle was set against him before and behind, he chose of all the choice men of Israel, and put them in array against the Syrians. [^10] And the rest of the people he committed into the hand of Abishai his brother; and they put themselves in array against the children of Ammon. [^11] And he said, If the Syrians be too strong for me, then thou shalt help me; but if the children of Ammon be too strong for thee, then I will help thee. [^12] Be of good courage, and let us play the man for our people, and for the cities of our God: and Jehovah do that which seemeth him good. [^13] So Joab and the people that were with him drew nigh before the Syrians unto the battle; and they fled before him. [^14] And when the children of Ammon saw that the Syrians were fled, they likewise fled before Abishai his brother, and entered into the city. Then Joab came to Jerusalem. [^15] And when the Syrians saw that they were put to the worse before Israel, they sent messengers, and drew forth the Syrians that were beyond the River, with Shophach the captain of the host of Hadarezer at their head. [^16] And it was told David; and he gathered all Israel together, and passed over the Jordan, and came upon them, and set the battle in array against them. So when David had put the battle in array against the Syrians, they fought with him. [^17] And the Syrians fled before Israel; and David slew of the Syrians the men of seven thousand chariots, and forty thousand footmen, and killed Shophach the captain of the host. [^18] And when the servants of Hadarezer saw that they were put to the worse before Israel, they made peace with David, and served him: neither would the Syrians help the children of Ammon any more. [^19] 

[[1 Chronicles - 18|<--]] 1 Chronicles - 19 [[1 Chronicles - 20|-->]]

---
# Notes
