---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 18 - American Standard Version"
---
[[1 Chronicles - 17|<--]] 1 Chronicles - 18 [[1 Chronicles - 19|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[1 Chronicles]]

# 1 Chronicles - 18

And after this it came to pass, that David smote the Philistines, and subdued them, and took Gath and its towns out of the hand of the Philistines. [^1] And he smote Moab; and the Moabites became servants to David, and brought tribute. [^2] And David smote Hadarezer king of Zobah unto Hamath, as he went to establish his dominion by the river Euphrates. [^3] And David took from him a thousand chariots, and seven thousand horsemen, and twenty thousand footmen; and David hocked all the chariot horses, but reserved of them for a hundred chariots. [^4] And when the Syrians of Damascus came to succor Hadarezer king of Zobah, David smote of the Syrians two and twenty thousand men. [^5] Then David put garrisons in Syria of Damascus; and the Syrians became servants to David, and brought tribute. And Jehovah gave victory to David whithersoever he went. [^6] And David took the shields of gold that were on the servants of Hadarezer, and brought them to Jerusalem. [^7] And from Tibhath and from Cun, cities of Hadarezer, David took very much brass, wherewith Solomon made the brazen sea, and the pillars, and the vessels of brass. [^8] And when Tou king of Hamath heard that David had smitten all the host of Hadarezer king of Zobah, [^9] he sent Hadoram his son to king David, to salute him, and to bless him, because he had fought against Hadarezer and smitten him (for Hadarezer had wars with Tou); and he had with him all manner of vessels of gold and silver and brass. [^10] These also did king David dedicate unto Jehovah, with the silver and the gold that he carried away from all the nations; from Edom, and from Moab, and from the children of Ammon, and from the Philistines, and from Amalek. [^11] Moreover Abishai the son of Zeruiah smote of the Edomites in the Valley of Salt eighteen thousand. [^12] And he put garrisons in Edom; and all the Edomites became servants to David. And Jehovah gave victory to David whithersoever he went. [^13] And David reigned over all Israel; and he executed justice and righteousness unto all his people. [^14] And Joab the son of Zeruiah was over the host; and Jehoshaphat the son of Ahilud was recorder; [^15] and Zadok the son of Ahitub, and Abimelech the son of Abiathar, were priests; and Shavsha was scribe; [^16] and Benaiah the son of Jehoiada was over the Cherethites and the Pelethites; and the sons of David were chief about the king. [^17] 

[[1 Chronicles - 17|<--]] 1 Chronicles - 18 [[1 Chronicles - 19|-->]]

---
# Notes
