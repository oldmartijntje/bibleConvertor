---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 11 - American Standard Version"
---
[[Joshua - 10|<--]] Joshua - 11 [[Joshua - 12|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Joshua]]

# Joshua - 11

And it came to pass, when Jabin king of Hazor heard thereof, that he sent to Jobab king of Madon, and to the king of Shimron, and to the king of Achshaph, [^1] and to the kings that were on the north, in the hill-country, and in the Arabah south of Chinneroth, and in the lowland, and in the heights of Dor on the west, [^2] to the Canaanite on the east and on the west, and the Amorite, and the Hittite, and the Perizzite, and the Jebusite in the hill-country, and the Hivite under Hermon in the land of Mizpah. [^3] And they went out, they and all their hosts with them, much people, even as the sand that is upon the sea-shore in multitude, with horses and chariots very many. [^4] And all these kings met together; and they came and encamped together at the waters of Merom, to fight with Israel. [^5] And Jehovah said unto Joshua, Be not afraid because of them; for to-morrow at this time will I deliver them up all slain before Israel: thou shalt hock their horses, and burn their chariots with fire. [^6] So Joshua came, and all the people of war with him, against them by the waters of Merom suddenly, and fell upon them. [^7] And Jehovah delivered them into the hand of Israel, and they smote them, and chased them unto great Sidon, and unto Misrephoth-maim, and unto the valley of Mizpeh eastward; and they smote them, until they left them none remaining. [^8] And Joshua did unto them as Jehovah bade him: he hocked their horses, and burnt their chariots with fire. [^9] And Joshua turned back at that time, and took Hazor, and smote the king thereof with the sword: for Hazor beforetime was the head of all those kingdoms. [^10] And they smote all the souls that were therein with the edge of the sword, utterly destroying them; there was none left that breathed: and he burnt Hazor with fire. [^11] And all the cities of those kings, and all the kings of them, did Joshua take, and he smote them with the edge of the sword, and utterly destroyed them; as Moses the servant of Jehovah commanded. [^12] But as for the cities that stood on their mounds, Israel burned none of them, save Hazor only; that did Joshua burn. [^13] And all the spoil of these cities, and the cattle, the children of Israel took for a prey unto themselves; but every man they smote with the edge of the sword, until they had destroyed them, neither left they any that breathed. [^14] As Jehovah commanded Moses his servant, so did Moses command Joshua: and so did Joshua; he left nothing undone of all that Jehovah commanded Moses. [^15] So Joshua took all that land, the hill-country, and all the South, and all the land of Goshen, and the lowland, and the Arabah, and the hill-country of Israel, and the lowland of the same; [^16] from mount Halak, that goeth up to Seir, even unto Baal-gad in the valley of Lebanon under mount Hermon: and all their kings he took, and smote them, and put them to death. [^17] Joshua made war a long time with all those kings. [^18] There was not a city that made peace with the children of Israel, save the Hivites the inhabitants of Gibeon: they took all in battle. [^19] For it was of Jehovah to harden their hearts, to come against Israel in battle, that he might utterly destroy them, that they might have no favor, but that he might destroy them, as Jehovah commanded Moses. [^20] And Joshua came at that time, and cut off the Anakim from the hill-country, from Hebron, from Debir, from Anab, and from all the hill-country of Judah, and from all the hill-country of Israel: Joshua utterly destroyed them with their cities. [^21] There was none of the Anakim left in the land of the children of Israel: only in Gaza, in Gath, and in Ashdod, did some remain. [^22] So Joshua took the whole land, according to all that Jehovah spake unto Moses; and Joshua gave it for an inheritance unto Israel according to their divisions by their tribes. And the land had rest from war. [^23] 

[[Joshua - 10|<--]] Joshua - 11 [[Joshua - 12|-->]]

---
# Notes
