---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 4 - American Standard Version"
---
[[Joshua - 3|<--]] Joshua - 4 [[Joshua - 5|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Joshua]]

# Joshua - 4

And it came to pass, when all the nation were clean passed over the Jordan, that Jehovah spake unto Joshua, saying, [^1] Take you twelve men out of the people, out of every tribe a man, [^2] and command ye them, saying, Take you hence out of the midst of the Jordan, out of the place where the priests’ feet stood firm, twelve stones, and carry them over with you, and lay them down in the lodging-place, where ye shall lodge this night. [^3] Then Joshua called the twelve men, whom he had prepared of the children of Israel, out of every tribe a man: [^4] and Joshua said unto them, Pass over before the ark of Jehovah your God into the midst of the Jordan, and take you up every man of you a stone upon his shoulder, according unto the number of the tribes of the children of Israel; [^5] that this may be a sign among you, that, when your children ask in time to come, saying, What mean ye by these stones? [^6] then ye shall say unto them, Because the waters of the Jordan were cut off before the ark of the covenant of Jehovah; when it passed over the Jordan, the waters of the Jordan were cut off: and these stones shall be for a memorial unto the children of Israel for ever. [^7] And the children of Israel did so as Joshua commanded, and took up twelve stones out of the midst of the Jordan, as Jehovah spake unto Joshua, according to the number of the tribes of the children of Israel; and they carried them over with them unto the place where they lodged, and laid them down there. [^8] And Joshua set up twelve stones in the midst of the Jordan, in the place where the feet of the priests that bare the ark of the covenant stood: and they are there unto this day. [^9] For the priests that bare the ark stood in the midst of the Jordan, until everything was finished that Jehovah commanded Joshua to speak unto the people, according to all that Moses commanded Joshua: and the people hasted and passed over. [^10] And it came to pass, when all the people were clean passed over, that the ark of Jehovah passed over, and the priests, in the presence of the people. [^11] And the children of Reuben, and the children of Gad, and the half-tribe of Manasseh, passed over armed before the children of Israel, as Moses spake unto them: [^12] about forty thousand ready armed for war passed over before Jehovah unto battle, to the plains of Jericho. [^13] On that day Jehovah magnified Joshua in the sight of all Israel; and they feared him, as they feared Moses, all the days of his life. [^14] And Jehovah spake unto Joshua, saying, [^15] Command the priests that bear the ark of the testimony, that they come up out of the Jordan. [^16] Joshua therefore commanded the priests, saying, Come ye up out of the Jordan. [^17] And it came to pass, when the priests that bare the ark of the covenant of Jehovah were come up out of the midst of the Jordan, and the soles of the priests’ feet were lifted up unto the dry ground, that the waters of the Jordan returned unto their place, and went over all its banks, as aforetime. [^18] And the people came up out of the Jordan on the tenth day of the first month, and encamped in Gilgal, on the east border of Jericho. [^19] And those twelve stones, which they took out of the Jordan, did Joshua set up in Gilgal. [^20] And he spake unto the children of Israel, saying, When your children shall ask their fathers in time to come, saying, What mean these stones? [^21] then ye shall let your children know, saying, Israel came over this Jordan on dry land. [^22] For Jehovah your God dried up the waters of the Jordan from before you, until ye were passed over, as Jehovah your God did to the Red Sea, which he dried up from before us, until we were passed over; [^23] that all the peoples of the earth may know the hand of Jehovah, that it is mighty; that ye may fear Jehovah your God for ever. [^24] 

[[Joshua - 3|<--]] Joshua - 4 [[Joshua - 5|-->]]

---
# Notes
