---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 5 - American Standard Version"
---
[[Joshua - 4|<--]] Joshua - 5 [[Joshua - 6|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Joshua]]

# Joshua - 5

And it came to pass, when all the kings of the Amorites, that were beyond the Jordan westward, and all the kings of the Canaanites, that were by the sea, heard how that Jehovah had dried up the waters of the Jordan from before the children of Israel, until we were passed over, that their heart melted, neither was there spirit in them any more, because of the children of Israel. [^1] At that time Jehovah said unto Joshua, Make thee knives of flint, and circumcise again the children of Israel the second time. [^2] And Joshua made him knives of flint, and circumcised the children of Israel at the hill of the foreskins. [^3] And this is the cause why Joshua did circumcise: all the people that came forth out of Egypt, that were males, even all the men of war, died in the wilderness by the way, after they came forth out of Egypt. [^4] For all the people that came out were circumcised; but all the people that were born in the wilderness by the way as they came forth out of Egypt, they had not circumcised. [^5] For the children of Israel walked forty years in the wilderness, till all the nation, even the men of war that came forth out of Egypt, were consumed, because they hearkened not unto the voice of Jehovah: unto whom Jehovah sware that he would not let them see the land which Jehovah sware unto their fathers that he would give us, a land flowing with milk and honey. [^6] And their children, whom he raised up in their stead, them did Joshua circumcise: for they were uncircumcised, because they had not circumcised them by the way. [^7] And it came to pass, when they had done circumcising all the nation, that they abode in their places in the camp, till they were whole. [^8] And Jehovah said unto Joshua, This day have I rolled away the reproach of Egypt from off you. Wherefore the name of that place was called Gilgal, unto this day. [^9] And the children of Israel encamped in Gilgal; and they kept the passover on the fourteenth day of the month at even in the plains of Jericho. [^10] And they did eat of the produce of the land on the morrow after the passover, unleavened cakes and parched grain, in the selfsame day. [^11] And the manna ceased on the morrow, after they had eaten of the produce of the land; neither had the children of Israel manna any more; but they did eat of the fruit of the land of Canaan that year. [^12] And it came to pass, when Joshua was by Jericho, that he lifted up his eyes and looked, and, behold, there stood a man over against him with his sword drawn in his hand: and Joshua went unto him, and said unto him, Art thou for us, or for our adversaries? [^13] And he said, Nay; but as prince of the host of Jehovah am I now come. And Joshua fell on his face to the earth, and did worship, and said unto him, What saith my lord unto his servant? [^14] And the prince of Jehovah’s host said unto Joshua, Put off thy shoe from off thy foot; for the place whereon thou standest is holy. And Joshua did so. [^15] 

[[Joshua - 4|<--]] Joshua - 5 [[Joshua - 6|-->]]

---
# Notes
