---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 12 - American Standard Version"
---
[[Joshua - 11|<--]] Joshua - 12 [[Joshua - 13|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Joshua]]

# Joshua - 12

Now these are the kings of the land, whom the children of Israel smote, and possessed their land beyond the Jordan toward the sunrising, from the valley of the Arnon unto mount Hermon, and all the Arabah eastward: [^1] Sihon king of the Amorites, who dwelt in Heshbon, and ruled from Aroer, which is on the edge of the valley of the Arnon, and the city that is in the middle of the valley, and half Gilead, even unto the river Jabbok, the border of the children of Ammon; [^2] and the Arabah unto the sea of Chinneroth, eastward, and unto the sea of the Arabah, even the Salt Sea, eastward, the way to Beth-jeshimoth; and on the south, under the slopes of Pisgah: [^3] and the border of Og king of Bashan, of the remnant of the Rephaim, who dwelt at Ashtaroth and at Edrei, [^4] and ruled in mount Hermon, and in Salecah, and in all Bashan, unto the border of the Geshurites and the Maacathites, and half Gilead, the border of Sihon king of Heshbon. [^5] Moses the servant of Jehovah and the children of Israel smote them: and Moses the servant of Jehovah gave it for a possession unto the Reubenites, and the Gadites, and the half-tribe of Manasseh. [^6] And these are the kings of the land whom Joshua and the children of Israel smote beyond the Jordan westward, from Baal-gad in the valley of Lebanon even unto mount Halak, that goeth up to Seir (and Joshua gave it unto the tribes of Israel for a possession according to their divisions; [^7] in the hill-country, and in the lowland, and in the Arabah, and in the slopes, and in the wilderness, and in the South; the Hittite, the Amorite, and the Canaanite, the Perizzite, the Hivite, and the Jebusite): [^8] the king of Jericho, one; the king of Ai, which is beside Beth-el, one; [^9] the king of Jerusalem, one; the king of Hebron, one; [^10] the king of Jarmuth, one; the king of Lachish, one; [^11] the king of Eglon, one; the king of Gezer, one; [^12] the king of Debir, one; the king of Geder, one; [^13] the king of Hormah, one; the king of Arad, one; [^14] the king of Libnah, one; the king of Adullam, one; [^15] the king of Makkedah, one; the king of Beth-el, one; [^16] the king of Tappuah, one; the king of Hepher, one; [^17] the king of Aphek, one; the king of Lassharon, one; [^18] the king of Madon, one; the king of Hazor, one; [^19] the king of Shimron-meron, one; the king of Achshaph, one; [^20] the king of Taanach, one; the king of Megiddo, one; [^21] the king of Kedesh, one; the king of Jokneam in Carmel, one; [^22] the king of Dor in the height of Dor, one; the king of Goiim in Gilgal, one; [^23] the king of Tirzah, one: all the kings thirty and one. [^24] 

[[Joshua - 11|<--]] Joshua - 12 [[Joshua - 13|-->]]

---
# Notes
