---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 14 - American Standard Version"
---
[[Joshua - 13|<--]] Joshua - 14 [[Joshua - 15|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Joshua]]

# Joshua - 14

And these are the inheritances which the children of Israel took in the land of Canaan, which Eleazar the priest, and Joshua the son of Nun, and the heads of the fathers’ houses of the tribes of the children of Israel, distributed unto them, [^1] by the lot of their inheritance, as Jehovah commanded by Moses, for the nine tribes, and for the half-tribe. [^2] For Moses had given the inheritance of the two tribes and the half-tribe beyond the Jordan: but unto the Levites he gave no inheritance among them. [^3] For the children of Joseph were two tribes, Manasseh and Ephraim: and they gave no portion unto the Levites in the land, save cities to dwell in, with the suburbs thereof for their cattle and for their substance. [^4] As Jehovah commanded Moses, so the children of Israel did; and they divided the land. [^5] Then the children of Judah drew nigh unto Joshua in Gilgal: and Caleb the son of Jephunneh the Kenizzite said unto him, Thou knowest the thing that Jehovah spake unto Moses the man of God concerning me and concerning thee in Kadesh-barnea. [^6] Forty years old was I when Moses the servant of Jehovah sent me from Kadesh-barnea to spy out the land; and I brought him word again as it was in my heart. [^7] Nevertheless my brethren that went up with me made the heart of the people melt; but I wholly followed Jehovah my God. [^8] And Moses sware on that day, saying, Surely the land whereon thy foot hath trodden shall be an inheritance to thee and to thy children for ever, because thou hast wholly followed Jehovah my God. [^9] And now, behold, Jehovah hath kept me alive, as he spake, these forty and five years, from the time that Jehovah spake this word unto Moses, while Israel walked in the wilderness: and now, lo, I am this day fourscore and five years old. [^10] As yet I am as strong this day as I was in the day that Moses sent me: as my strength was then, even so is my strength now, for war, and to go out and to come in. [^11] Now therefore give me this hill-country, whereof Jehovah spake in that day; for thou heardest in that day how the Anakim were there, and cities great and fortified: it may be that Jehovah will be with me, and I shall drive them out, as Jehovah spake. [^12] And Joshua blessed him; and he gave Hebron unto Caleb the son of Jephunneh for an inheritance. [^13] Therefore Hebron became the inheritance of Caleb the son of Jephunneh the Kenizzite unto this day; because that he wholly followed Jehovah, the God of Israel. [^14] Now the name of Hebron beforetime was Kiriath-arba; which Arba was the greatest man among the Anakim. And the land had rest from war. [^15] 

[[Joshua - 13|<--]] Joshua - 14 [[Joshua - 15|-->]]

---
# Notes
