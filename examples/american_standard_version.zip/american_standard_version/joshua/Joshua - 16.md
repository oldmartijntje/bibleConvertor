---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 16 - American Standard Version"
---
[[Joshua - 15|<--]] Joshua - 16 [[Joshua - 17|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Joshua]]

# Joshua - 16

And the lot came out for the children of Joseph from the Jordan at Jericho, at the waters of Jericho on the east, even the wilderness, going up from Jericho through the hill-country to Beth-el; [^1] and it went out from Beth-el to Luz, and passed along unto the border of the Archites to Ataroth; [^2] and it went down westward to the border of the Japhletites, unto the border of Beth-horon the nether, even unto Gezer; and the goings out thereof were at the sea. [^3] And the children of Joseph, Manasseh and Ephraim, took their inheritance. [^4] And the border of the children of Ephraim according to their families was thus: the border of their inheritance eastward was Ataroth-addar, unto Beth-horon the upper; [^5] and the border went out westward at Michmethath on the north; and the border turned about eastward unto Taanath-shiloh, and passed along it on the east of Janoah; [^6] and it went down from Janoah to Ataroth, and to Naarah, and reached unto Jericho, and went out at the Jordan. [^7] From Tappuah the border went along westward to the brook of Kanah; and the goings out thereof were at the sea. This is the inheritance of the tribe of the children of Ephraim according to their families; [^8] together with the cities which were set apart for the children of Ephraim in the midst of the inheritance of the children of Manasseh, all the cities with their villages. [^9] And they drove not out the Canaanites that dwelt in Gezer: but the Canaanites dwell in the midst of Ephraim unto this day, and are become servants to do taskwork. [^10] 

[[Joshua - 15|<--]] Joshua - 16 [[Joshua - 17|-->]]

---
# Notes
