---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 23 - American Standard Version"
---
[[Joshua - 22|<--]] Joshua - 23 [[Joshua - 24|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Joshua]]

# Joshua - 23

And it came to pass after many days, when Jehovah had given rest unto Israel from all their enemies round about, and Joshua was old and well stricken in years; [^1] that Joshua called for all Israel, for their elders and for their heads, and for their judges and for their officers, and said unto them, I am old and well stricken in years: [^2] and ye have seen all that Jehovah your God hath done unto all these nations because of you; for Jehovah your God, he it is that hath fought for you. [^3] Behold, I have allotted unto you these nations that remain, to be an inheritance for your tribes, from the Jordan, with all the nations that I have cut off, even unto the great sea toward the going down of the sun. [^4] And Jehovah your God, he will thrust them out from before you, and drive them from out of your sight; and ye shall possess their land, as Jehovah your God spake unto you. [^5] Therefore be ye very courageous to keep and to do all that is written in the book of the law of Moses, that ye turn not aside therefrom to the right hand or to the left; [^6] that ye come not among these nations, these that remain among you; neither make mention of the name of their gods, nor cause to swear by them, neither serve them, nor bow down yourselves unto them; [^7] but cleave unto Jehovah your God, as ye have done unto this day. [^8] For Jehovah hath driven out from before you great nations and strong: but as for you, no man hath stood before you unto this day. [^9] One man of you shall chase a thousand; for Jehovah your God, he it is that fighteth for you, as he spake unto you. [^10] Take good heed therefore unto yourselves, that ye love Jehovah your God. [^11] Else if ye do at all go back, and cleave unto the remnant of these nations, even these that remain among you, and make marriages with them, and go in unto them, and they to you; [^12] know for a certainty that Jehovah your God will no more drive these nations from out of your sight; but they shall be a snare and a trap unto you, and a scourge in your sides, and thorns in your eyes, until ye perish from off this good land which Jehovah your God hath given you. [^13] And, behold, this day I am going the way of all the earth: and ye know in all your hearts and in all your souls, that not one thing hath failed of all the good things which Jehovah your God spake concerning you; all are come to pass unto you, not one thing hath failed thereof. [^14] And it shall come to pass, that as all the good things are come upon you of which Jehovah your God spake unto you, so will Jehovah bring upon you all the evil things, until he have destroyed you from off this good land which Jehovah your God hath given you. [^15] When ye transgress the covenant of Jehovah your God, which he commanded you, and go and serve other gods, and bow down yourselves to them; then will the anger of Jehovah be kindled against you, and ye shall perish quickly from off the good land which he hath given unto you. [^16] 

[[Joshua - 22|<--]] Joshua - 23 [[Joshua - 24|-->]]

---
# Notes
