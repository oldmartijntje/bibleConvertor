---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 3 - American Standard Version"
---
[[Joshua - 2|<--]] Joshua - 3 [[Joshua - 4|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Joshua]]

# Joshua - 3

And Joshua rose up early in the morning; and they removed from Shittim, and came to the Jordan, he and all the children of Israel; and they lodged there before they passed over. [^1] And it came to pass after three days, that the officers went through the midst of the camp; [^2] and they commanded the people, saying, When ye see the ark of the covenant of Jehovah your God, and the priests the Levites bearing it, then ye shall remove from your place, and go after it. [^3] Yet there shall be a space between you and it, about two thousand cubits by measure: come not near unto it, that ye may know the way by which ye must go; for ye have not passed this way heretofore. [^4] And Joshua said unto the people, Sanctify yourselves; for to-morrow Jehovah will do wonders among you. [^5] And Joshua spake unto the priests, saying, Take up the ark of the covenant, and pass over before the people. And they took up the ark of the covenant, and went before the people. [^6] And Jehovah said unto Joshua, This day will I begin to magnify thee in the sight of all Israel, that they may know that, as I was with Moses, so I will be with thee. [^7] And thou shalt command the priests that bear the ark of the covenant, saying, When ye are come to the brink of the waters of the Jordan, ye shall stand still in the Jordan. [^8] And Joshua said unto the children of Israel, Come hither, and hear the words of Jehovah your God. [^9] And Joshua said, Hereby ye shall know that the living God is among you, and that he will without fail drive out from before you the Canaanite, and the Hittite, and the Hivite, and the Perizzite, and the Girgashite, and the Amorite, and the Jebusite. [^10] Behold, the ark of the covenant of the Lord of all the earth passeth over before you into the Jordan. [^11] Now therefore take you twelve men out of the tribes of Israel, for every tribe a man. [^12] And it shall come to pass, when the soles of the feet of the priests that bear the ark of Jehovah, the Lord of all the earth, shall rest in the waters of the Jordan, that the waters of the Jordan shall be cut off, even the waters that come down from above; and they shall stand in one heap. [^13] And it came to pass, when the people removed from their tents, to pass over the Jordan, the priests that bare the ark of the covenant being before the people; [^14] and when they that bare the ark were come unto the Jordan, and the feet of the priests that bare the ark were dipped in the brink of the water (for the Jordan overfloweth all its banks all the time of harvest), [^15] that the waters which came down from above stood, and rose up in one heap, a great way off, at Adam, the city that is beside Zarethan; and those that went down toward the sea of the Arabah, even the Salt Sea, were wholly cut off: and the people passed over right against Jericho. [^16] And the priests that bare the ark of the covenant of Jehovah stood firm on dry ground in the midst of the Jordan; and all Israel passed over on dry ground, until all the nation were passed clean over the Jordan. [^17] 

[[Joshua - 2|<--]] Joshua - 3 [[Joshua - 4|-->]]

---
# Notes
