---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 20 - American Standard Version"
---
[[Joshua - 19|<--]] Joshua - 20 [[Joshua - 21|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Joshua]]

# Joshua - 20

And Jehovah spake unto Joshua, saying, [^1] Speak to the children of Israel, saying, Assign you the cities of refuge, whereof I spake unto you by Moses, [^2] that the manslayer that killeth any person unwittingly and unawares may flee thither: and they shall be unto you for a refuge from the avenger of blood. [^3] And he shall flee unto one of those cities, and shall stand at the entrance of the gate of the city, and declare his cause in the ears of the elders of that city; and they shall take him into the city unto them, and give him a place, that he may dwell among them. [^4] And if the avenger of blood pursue after him, then they shall not deliver up the manslayer into his hand; because he smote his neighbor unawares, and hated him not beforetime. [^5] And he shall dwell in that city, until he stand before the congregation for judgment, until the death of the high priest that shall be in those days: then shall the manslayer return, and come unto his own city, and unto his own house, unto the city from whence he fled. [^6] And they set apart Kedesh in Galilee in the hill-country of Naphtali, and Shechem in the hill-country of Ephraim, and Kiriath-arba (the same is Hebron) in the hill-country of Judah. [^7] And beyond the Jordan at Jericho eastward, they assigned Bezer in the wilderness in the plain out of the tribe of Reuben, and Ramoth in Gilead out of the tribe of Gad, and Golan in Bashan out of the tribe of Manasseh. [^8] These were the appointed cities for all the children of Israel, and for the stranger that sojourneth among them, that whosoever killeth any person unwittingly might flee thither, and not die by the hand of the avenger of blood, until he stood before the congregation. [^9] 

[[Joshua - 19|<--]] Joshua - 20 [[Joshua - 21|-->]]

---
# Notes
