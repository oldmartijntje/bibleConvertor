---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 14 - American Standard Version"
---
[[2 Chronicles - 13|<--]] 2 Chronicles - 14 [[2 Chronicles - 15|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[2 Chronicles]]

# 2 Chronicles - 14

So Abijah slept with his fathers, and they buried him in the city of David; and Asa his son reigned in his stead. In his days the land was quiet ten years. [^1] And Asa did that which was good and right in the eyes of Jehovah his God: [^2] for he took away the foreign altars, and the high places, and brake down the pillars, and hewed down the Asherim, [^3] and commanded Judah to seek Jehovah, the God of their fathers, and to do the law and the commandment. [^4] Also he took away out of all the cities of Judah the high places and the sun-images: and the kingdom was quiet before him. [^5] And he built fortified cities in Judah; for the land was quiet, and he had no war in those years, because Jehovah had given him rest. [^6] For he said unto Judah, Let us build these cities, and make about them walls, and towers, gates, and bars; the land is yet before us, because we have sought Jehovah our God; we have sought him, and he hath given us rest on every side. So they built and prospered. [^7] And Asa had an army that bare bucklers and spears, out of Judah three hundred thousand; and out of Benjamin, that bare shields and drew bows, two hundred and fourscore thousand: all these were mighty men of valor. [^8] And there came out against them Zerah the Ethiopian with an army of a thousand thousand, and three hundred chariots; and he came unto Mareshah. [^9] Then Asa went out to meet him, and they set the battle in array in the valley of Zephathah at Mareshah. [^10] And Asa cried unto Jehovah his God, and said, Jehovah, there is none besides thee to help, between the mighty and him that hath no strength: help us, O Jehovah our God; for we rely on thee, and in thy name are we come against this multitude. O Jehovah, thou art our God; let not man prevail against thee. [^11] So Jehovah smote the Ethiopians before Asa, and before Judah; and the Ethiopians fled. [^12] And Asa and the people that were with him pursued them unto Gerar: and there fell of the Ethiopians so many that they could not recover themselves; for they were destroyed before Jehovah, and before his host; and they carried away very much booty. [^13] And they smote all the cities round about Gerar; for the fear of Jehovah came upon them: and they despoiled all the cities; for there was much spoil in them. [^14] They smote also the tents of cattle, and carried away sheep in abundance, and camels, and returned to Jerusalem. [^15] 

[[2 Chronicles - 13|<--]] 2 Chronicles - 14 [[2 Chronicles - 15|-->]]

---
# Notes
