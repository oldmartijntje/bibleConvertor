---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 16 - American Standard Version"
---
[[2 Chronicles - 15|<--]] 2 Chronicles - 16 [[2 Chronicles - 17|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[2 Chronicles]]

# 2 Chronicles - 16

In the six and thirtieth year of the reign of Asa, Baasha king of Israel went up against Judah, and built Ramah, that he might not suffer any one to go out or come in to Asa king of Judah. [^1] Then Asa brought out silver and gold out of the treasures of the house of Jehovah and of the king’s house, and sent to Ben-hadad king of Syria, that dwelt at Damascus, saying, [^2] There is a league between me and thee, as there was between my father and thy father: behold, I have sent thee silver and gold; go, break thy league with Baasha king of Israel, that he may depart from me. [^3] And Ben-hadad hearkened unto king Asa, and sent the captains of his armies against the cities of Israel; and they smote Ijon, and Dan, and Abel-maim, and all the store-cities of Naphtali. [^4] And it came to pass, when Baasha heard thereof, that he left off building Ramah, and let his work cease. [^5] Then Asa the king took all Judah; and they carried away the stones of Ramah, and the timber thereof, wherewith Baasha had builded; and he built therewith Geba and Mizpah. [^6] And at that time Hanani the seer came to Asa king of Judah, and said unto him, Because thou hast relied on the king of Syria, and hast not relied on Jehovah thy God, therefore is the host of the king of Syria escaped out of thy hand. [^7] Were not the Ethiopians and the Lubim a huge host, with chariots and horsemen exceeding many? yet, because thou didst rely on Jehovah, he delivered them into thy hand. [^8] For the eyes of Jehovah run to and fro throughout the whole earth, to show himself strong in the behalf of them whose heart is perfect toward him. Herein thou hast done foolishly; for from henceforth thou shalt have wars. [^9] Then Asa was wroth with the seer, and put him in the prison-house; for he was in a rage with him because of this thing. And Asa oppressed some of the people at the same time. [^10] And, behold, the acts of Asa, first and last, lo, they are written in the book of the kings of Judah and Israel. [^11] And in the thirty and ninth year of his reign Asa was diseased in his feet; his disease was exceeding great: yet in his disease he sought not to Jehovah, but to the physicians. [^12] And Asa slept with his fathers, and died in the one and fortieth year of his reign. [^13] And they buried him in his own sepulchres, which he had hewn out for himself in the city of David, and laid him in the bed which was filled with sweet odors and divers kinds of spices prepared by the perfumers’ art: and they made a very great burning for him. [^14] 

[[2 Chronicles - 15|<--]] 2 Chronicles - 16 [[2 Chronicles - 17|-->]]

---
# Notes
