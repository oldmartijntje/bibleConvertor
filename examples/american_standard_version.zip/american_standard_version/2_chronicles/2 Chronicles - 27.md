---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 27 - American Standard Version"
---
[[2 Chronicles - 26|<--]] 2 Chronicles - 27 [[2 Chronicles - 28|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[2 Chronicles]]

# 2 Chronicles - 27

Jotham was twenty and five years old when he began to reign; and he reigned sixteen years in Jerusalem: and his mother’s name was Jerushah the daughter of Zadok. [^1] And he did that which was right in the eyes of Jehovah, according to all that his father Uzziah had done: howbeit he entered not into the temple of Jehovah. And the people did yet corruptly. [^2] He built the upper gate of the house of Jehovah, and on the wall of Ophel he built much. [^3] Moreover he built cities in the hill-country of Judah, and in the forests he built castles and towers. [^4] He fought also with the king of the children of Ammon, and prevailed against them. And the children of Ammon gave him the same year a hundred talents of silver, and ten thousand measures of wheat, and ten thousand of barley. So much did the children of Ammon render unto him, in the second year also, and in the third. [^5] So Jotham became mighty, because he ordered his ways before Jehovah his God. [^6] Now the rest of the acts of Jotham, and all his wars, and his ways, behold, they are written in the book of the kings of Israel and Judah. [^7] He was five and twenty years old when he began to reign, and reigned sixteen years in Jerusalem. [^8] And Jotham slept with his fathers, and they buried him in the city of David: and Ahaz his son reigned in his stead. [^9] 

[[2 Chronicles - 26|<--]] 2 Chronicles - 27 [[2 Chronicles - 28|-->]]

---
# Notes
