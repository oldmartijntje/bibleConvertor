---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 5 - American Standard Version"
---
[[2 Chronicles - 4|<--]] 2 Chronicles - 5 [[2 Chronicles - 6|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[2 Chronicles]]

# 2 Chronicles - 5

Thus all the work that Solomon wrought for the house of Jehovah was finished. And Solomon brought in the things that David his father had dedicated, even the silver, and the gold, and all the vessels, and put them in the treasuries of the house of God. [^1] Then Solomon assembled the elders of Israel, and all the heads of the tribes, the princes of the fathers’ houses of the children of Israel, unto Jerusalem, to bring up the ark of the covenant of Jehovah out of the city of David, which is Zion. [^2] And all the men of Israel assembled themselves unto the king at the feast, which was in the seventh month. [^3] And all the elders of Israel came: and the Levites took up the ark; [^4] and they brought up the ark, and the tent of meeting, and all the holy vessels that were in the Tent; these did the priests the Levites bring up. [^5] And king Solomon and all the congregation of Israel, that were assembled unto him, were before the ark, sacrificing sheep and oxen, that could not be counted nor numbered for multitude. [^6] And the priests brought in the ark of the covenant of Jehovah unto its place, into the oracle of the house, to the most holy place, even under the wings of the cherubim. [^7] For the cherubim spread forth their wings over the place of the ark, and the cherubim covered the ark and the staves thereof above. [^8] And the staves were so long that the ends of the staves were seen from the ark before the oracle; but they were not seen without: and there it is unto this day. [^9] There was nothing in the ark save the two tables which Moses put there at Horeb, when Jehovah made a covenant with the children of Israel, when they came out of Egypt. [^10] And it came to pass, when the priests were come out of the holy place (for all the priests that were present had sanctified themselves, and did not keep their courses; [^11] also the Levites who were the singers, all of them, even Asaph, Heman, Jeduthun, and their sons and their brethren, arrayed in fine linen, with cymbals and psalteries and harps, stood at the east end of the altar, and with them a hundred and twenty priests sounding with trumpets); [^12] it came to pass, when the trumpeters and singers were as one, to make one sound to be heard in praising and thanking Jehovah; and when they lifted up their voice with the trumpets and cymbals and instruments of music, and praised Jehovah, saying, For he is good; for his lovingkindness endureth for ever; that then the house was filled with a cloud, even the house of Jehovah, [^13] so that the priests could not stand to minister by reason of the cloud: for the glory of Jehovah filled the house of God. [^14] 

[[2 Chronicles - 4|<--]] 2 Chronicles - 5 [[2 Chronicles - 6|-->]]

---
# Notes
