---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 4 - American Standard Version"
---
[[2 Chronicles - 3|<--]] 2 Chronicles - 4 [[2 Chronicles - 5|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[2 Chronicles]]

# 2 Chronicles - 4

Moreover he made an altar of brass, twenty cubits the length thereof, and twenty cubits the breadth thereof, and ten cubits the height thereof. [^1] Also he made the molten sea of ten cubits from brim to brim, round in compass; and the height thereof was five cubits; and a line of thirty cubits compassed it round about. [^2] And under it was the likeness of oxen, which did compass it round about, for ten cubits, compassing the sea round about. The oxen were in two rows, cast when it was cast. [^3] It stood upon twelve oxen, three looking toward the north, and three looking toward the west, and three looking toward the south, and three looking toward the east: and the sea was set upon them above, and all their hinder parts were inward. [^4] And it was a handbreadth thick; and the brim thereof was wrought like the brim of a cup, like the flower of a lily: it received and held three thousand baths. [^5] He made also ten lavers, and put five on the right hand, and five on the left, to wash in them; such things as belonged to the burnt-offering they washed in them; but the sea was for the priests to wash in. [^6] And he made the ten candlesticks of gold according to the ordinance concerning them; and he set them in the temple, five on the right hand, and five on the left. [^7] He made also ten tables, and placed them in the temple, five on the right side, and five on the left. And he made a hundred basins of gold. [^8] Furthermore he made the court of the priests, and the great court, and doors for the court, and overlaid the doors of them with brass. [^9] And he set the sea on the right side of the house eastward, toward the south. [^10] And Huram made the pots, and the shovels, and the basins.So Huram made an end of doing the work that he wrought for king Solomon in the house of God: [^11] the two pillars, and the bowls, and the two capitals which were on the top of the pillars, and the two networks to cover the two bowls of the capitals that were on the top of the pillars, [^12] and the four hundred pomegranates for the two networks; two rows of pomegranates for each network, to cover the two bowls of the capitals that were upon the pillars. [^13] He made also the bases, and the lavers made he upon the bases; [^14] one sea, and the twelve oxen under it. [^15] The pots also, and the shovels, and the flesh-hooks, and all the vessels thereof, did Huram his father make for king Solomon, for the house of Jehovah, of bright brass. [^16] In the plain of the Jordan did the king cast them, in the clay ground between Succoth and Zeredah. [^17] Thus Solomon made all these vessels in great abundance: for the weight of the brass could not be found out. [^18] And Solomon made all the vessels that were in the house of God, the golden altar also, and the tables whereon was the showbread; [^19] and the candlesticks with their lamps, to burn according to the ordinance before the oracle, of pure gold; [^20] and the flowers, and the lamps, and the tongs, of gold, and that perfect gold; [^21] and the snuffers, and the basins, and the spoons, and the firepans, of pure gold. And as for the entry of the house, the inner doors thereof for the most holy place, and the doors of the house, to wit, of the temple, were of gold. [^22] 

[[2 Chronicles - 3|<--]] 2 Chronicles - 4 [[2 Chronicles - 5|-->]]

---
# Notes
