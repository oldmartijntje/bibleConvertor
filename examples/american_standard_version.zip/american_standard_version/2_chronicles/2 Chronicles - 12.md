---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 12 - American Standard Version"
---
[[2 Chronicles - 11|<--]] 2 Chronicles - 12 [[2 Chronicles - 13|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[2 Chronicles]]

# 2 Chronicles - 12

And it came to pass, when the kingdom of Rehoboam was established, and he was strong, that he forsook the law of Jehovah, and all Israel with him. [^1] And it came to pass in the fifth year of king Rehoboam, that Shishak king of Egypt came up against Jerusalem, because they had trespassed against Jehovah, [^2] with twelve hundred chariots, and threescore thousand horsemen. And the people were without number that came with him out of Egypt: the Lubim, the Sukkiim, and the Ethiopians. [^3] And he took the fortified cities which pertained to Judah, and came unto Jerusalem. [^4] Now Shemaiah the prophet came to Rehoboam, and to the princes of Judah, that were gathered together to Jerusalem because of Shishak, and said unto them, Thus saith Jehovah, Ye have forsaken me, therefore have I also left you in the hand of Shishak. [^5] Then the princes of Israel and the king humbled themselves; and they said, Jehovah is righteous. [^6] And when Jehovah saw that they humbled themselves, the word of Jehovah came to Shemaiah, saying, They have humbled themselves: I will not destroy them; but I will grant them some deliverance, and my wrath shall not be poured out upon Jerusalem by the hand of Shishak. [^7] Nevertheless they shall be his servants, that they may know my service, and the service of the kingdoms of the countries. [^8] So Shishak king of Egypt came up against Jerusalem, and took away the treasures of the house of Jehovah, and the treasures of the king’s house: he took all away: he took away also the shields of gold which Solomon had made. [^9] And king Rehoboam made in their stead shields of brass, and committed them to the hands of the captains of the guard, that kept the door of the king’s house. [^10] And it was so, that, as oft as the king entered into the house of Jehovah, the guard came and bare them, and brought them back into the guard-chamber. [^11] And when he humbled himself, the wrath of Jehovah turned from him, so as not to destroy him altogether: and moreover in Judah there were good things found. [^12] So king Rehoboam strengthened himself in Jerusalem, and reigned: for Rehoboam was forty and one years old when he began to reign, and he reigned seventeen years in Jerusalem, the city which Jehovah had chosen out of all the tribes of Israel, to put his name there: and his mother’s name was Naamah the Ammonitess. [^13] And he did that which was evil, because he set not his heart to seek Jehovah. [^14] Now the acts of Rehoboam, first and last, are they not written in the histories of Shemaiah the prophet and of Iddo the seer, after the manner of genealogies? And there were wars between Rehoboam and Jeroboam continually. [^15] And Rehoboam slept with his fathers, and was buried in the city of David: and Abijah his son reigned in his stead. [^16] 

[[2 Chronicles - 11|<--]] 2 Chronicles - 12 [[2 Chronicles - 13|-->]]

---
# Notes
