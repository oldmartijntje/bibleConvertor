---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 1 - American Standard Version"
---
2 Chronicles - 1 [[2 Chronicles - 2|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[2 Chronicles]]

# 2 Chronicles - 1

And Solomon the son of David was strengthened in his kingdom, and Jehovah his God was with him, and magnified him exceedingly. [^1] And Solomon spake unto all Israel, to the captains of thousands and of hundreds, and to the judges, and to every prince in all Israel, the heads of the fathers’ houses. [^2] So Solomon, and all the assembly with him, went to the high place that was at Gibeon; for there was the tent of meeting of God, which Moses the servant of Jehovah had made in the wilderness. [^3] But the ark of God had David brought up from Kiriath-jearim to the place that David had prepared for it; for he had pitched a tent for it at Jerusalem. [^4] Moreover the brazen altar, that Bezalel the son of Uri, the son of Hur, had made, was there before the tabernacle of Jehovah: and Solomon and the assembly sought unto it. [^5] And Solomon went up thither to the brazen altar before Jehovah, which was at the tent of meeting, and offered a thousand burnt-offerings upon it. [^6] In that night did God appear unto Solomon, and said unto him, Ask what I shall give thee. [^7] And Solomon said unto God, Thou hast showed great lovingkindness unto David my father, and hast made me king in his stead. [^8] Now, O Jehovah God, let thy promise unto David my father be established; for thou hast made me king over a people like the dust of the earth in multitude. [^9] Give me now wisdom and knowledge, that I may go out and come in before this people; for who can judge this thy people, that is so great? [^10] And God said to Solomon, Because this was in thy heart, and thou hast not asked riches, wealth, or honor, nor the life of them that hate thee, neither yet hast asked long life; but hast asked wisdom and knowledge for thyself, that thou mayest judge my people, over whom I have made thee king: [^11] wisdom and knowledge is granted unto thee; and I will give thee riches, and wealth, and honor, such as none of the kings have had that have been before thee; neither shall there any after thee have the like. [^12] So Solomon came from the high place that was at Gibeon, from before the tent of meeting, unto Jerusalem; and he reigned over Israel. [^13] And Solomon gathered chariots and horsemen: and he had a thousand and four hundred chariots, and twelve thousand horsemen, that he placed in the chariot cities, and with the king at Jerusalem. [^14] And the king made silver and gold to be in Jerusalem as stones, and cedars made he to be as the sycomore-trees that are in the lowland, for abundance. [^15] And the horses which Solomon had were brought out of Egypt; the king’s merchants received them in droves, each drove at a price. [^16] And they fetched up and brought out of Egypt a chariot for six hundred shekels of silver, and a horse for a hundred and fifty: and so for all the kings of the Hittites, and the kings of Syria, did they bring them out by their means. [^17] 

2 Chronicles - 1 [[2 Chronicles - 2|-->]]

---
# Notes
