---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 15 - American Standard Version"
---
[[2 Chronicles - 14|<--]] 2 Chronicles - 15 [[2 Chronicles - 16|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[2 Chronicles]]

# 2 Chronicles - 15

And the Spirit of God came upon Azariah the son of Oded: [^1] and he went out to meet Asa, and said unto him, Hear ye me, Asa, and all Judah and Benjamin: Jehovah is with you, while ye are with him; and if ye seek him, he will be found of you; but if ye forsake him, he will forsake you. [^2] Now for a long season Israel was without the true God, and without a teaching priest, and without law: [^3] but when in their distress they turned unto Jehovah, the God of Israel, and sought him, he was found of them. [^4] And in those times there was no peace to him that went out, nor to him that came in; but great vexations were upon all the inhabitants of the lands. [^5] And they were broken in pieces, nation against nation, and city against city; for God did vex them with all adversity. [^6] But be ye strong, and let not your hands be slack; for your work shall be rewarded. [^7] And when Asa heard these words, and the prophecy of Oded the prophet, he took courage, and put away the abominations out of all the land of Judah and Benjamin, and out of the cities which he had taken from the hill-country of Ephraim; and he renewed the altar of Jehovah, that was before the porch of Jehovah. [^8] And he gathered all Judah and Benjamin, and them that sojourned with them out of Ephraim and Manasseh, and out of Simeon: for they fell to him out of Israel in abundance, when they saw that Jehovah his God was with him. [^9] So they gathered themselves together at Jerusalem in the third month, in the fifteenth year of the reign of Asa. [^10] And they sacrificed unto Jehovah in that day, of the spoil which they had brought, seven hundred oxen and seven thousand sheep. [^11] And they entered into the covenant to seek Jehovah, the God of their fathers, with all their heart and with all their soul; [^12] and that whosoever would not seek Jehovah, the God of Israel, should be put to death, whether small or great, whether man or woman. [^13] And they sware unto Jehovah with a loud voice, and with shouting, and with trumpets, and with cornets. [^14] And all Judah rejoiced at the oath; for they had sworn with all their heart, and sought him with their whole desire; and he was found of them: and Jehovah gave them rest round about. [^15] And also Maacah, the mother of Asa the king, he removed from being queen, because she had made an abominable image for an Asherah; and Asa cut down her image, and made dust of it, and burnt it at the brook Kidron. [^16] But the high places were not taken away out of Israel: nevertheless the heart of Asa was perfect all his days. [^17] And he brought into the house of God the things that his father had dedicated, and that he himself had dedicated, silver, and gold, and vessels. [^18] And there was no more war unto the five and thirtieth year of the reign of Asa. [^19] 

[[2 Chronicles - 14|<--]] 2 Chronicles - 15 [[2 Chronicles - 16|-->]]

---
# Notes
