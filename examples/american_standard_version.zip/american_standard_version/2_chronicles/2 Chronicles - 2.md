---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 2 - American Standard Version"
---
[[2 Chronicles - 1|<--]] 2 Chronicles - 2 [[2 Chronicles - 3|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[2 Chronicles]]

# 2 Chronicles - 2

Now Solomon purposed to build a house for the name of Jehovah, and a house for his kingdom. [^1] And Solomon counted out threescore and ten thousand men to bear burdens, and fourscore thousand men that were hewers in the mountains, and three thousand and six hundred to oversee them. [^2] And Solomon sent to Huram the king of Tyre, saying, As thou didst deal with David my father, and didst send him cedars to build him a house to dwell therein, even so deal with me. [^3] Behold, I am about to build a house for the name of Jehovah my God, to dedicate it to him, and to burn before him incense of sweet spices, and for the continual showbread, and for the burnt-offerings morning and evening, on the sabbaths, and on the new moons, and on the set feasts of Jehovah our God. This is an ordinance for ever to Israel. [^4] And the house which I build is great; for great is our God above all gods. [^5] But who is able to build him a house, seeing heaven and the heaven of heavens cannot contain him? who am I then, that I should build him a house, save only to burn incense before him? [^6] Now therefore send me a man skilful to work in gold, and in silver, and in brass, and in iron, and in purple, and crimson, and blue, and that knoweth how to grave all manner of gravings, to be with the skilful men that are with me in Judah and in Jerusalem, whom David my father did provide. [^7] Send me also cedar-trees, fir-trees, and algum-trees, out of Lebanon; for I know that thy servants know how to cut timber in Lebanon. And, behold, my servants shall be with thy servants, [^8] even to prepare me timber in abundance; for the house which I am about to build shall be great and wonderful. [^9] And, behold, I will give to thy servants, the hewers that cut timber, twenty thousand measures of beaten wheat, and twenty thousand measures of barley, and twenty thousand baths of wine, and twenty thousand baths of oil. [^10] Then Huram the king of Tyre answered in writing, which he sent to Solomon, Because Jehovah loveth his people, he hath made thee king over them. [^11] Huram said moreover, Blessed be Jehovah, the God of Israel, that made heaven and earth, who hath given to David the king a wise son, endued with discretion and understanding, that should build a house for Jehovah, and a house for his kingdom. [^12] And now I have sent a skilful man, endued with understanding, of Huram my father’s, [^13] the son of a woman of the daughters of Dan; and his father was a man of Tyre, skilful to work in gold, and in silver, in brass, in iron, in stone, and in timber, in purple, in blue, and in fine linen, and in crimson, also to grave any manner of graving, and to devise any device; that there may be a place appointed unto him with thy skilful men, and with the skilful men of my lord David thy father. [^14] Now therefore the wheat and the barley, the oil and the wine, which my lord hath spoken of, let him send unto his servants: [^15] and we will cut wood out of Lebanon, as much as thou shalt need; and we will bring it to thee in floats by sea to Joppa; and thou shalt carry it up to Jerusalem. [^16] And Solomon numbered all the sojourners that were in the land of Israel, after the numbering wherewith David his father had numbered them; and they were found a hundred and fifty thousand and three thousand and six hundred. [^17] And he set threescore and ten thousand of them to bear burdens, and fourscore thousand that were hewers in the mountains, and three thousand and six hundred overseers to set the people at work. [^18] 

[[2 Chronicles - 1|<--]] 2 Chronicles - 2 [[2 Chronicles - 3|-->]]

---
# Notes
