---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 3 - American Standard Version"
---
[[2 Chronicles - 2|<--]] 2 Chronicles - 3 [[2 Chronicles - 4|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[2 Chronicles]]

# 2 Chronicles - 3

Then Solomon began to build the house of Jehovah at Jerusalem on mount Moriah, where Jehovah appeared unto David his father, which he made ready in the place that David had appointed, in the threshing-floor of Ornan the Jebusite. [^1] And he began to build in the second day of the second month, in the fourth year of his reign. [^2] Now these are the foundations which Solomon laid for the building of the house of God. The length by cubits after the first measure was threescore cubits, and the breadth twenty cubits. [^3] And the porch that was before the house, the length of it, according to the breadth of the house, was twenty cubits, and the height a hundred and twenty; and he overlaid it within with pure gold. [^4] And the greater house he ceiled with fir-wood, which he overlaid with fine gold, and wrought thereon palm-trees and chains. [^5] And he garnished the house with precious stones for beauty: and the gold was gold of Parvaim. [^6] He overlaid also the house, the beams, the thresholds, and the walls thereof, and the doors thereof, with gold; and graved cherubim on the walls. [^7] And he made the most holy house: the length thereof, according to the breadth of the house, was twenty cubits, and the breadth thereof twenty cubits; and he overlaid it with fine gold, amounting to six hundred talents. [^8] And the weight of the nails was fifty shekels of gold. And he overlaid the upper chambers with gold. [^9] And in the most holy house he made two cherubim of image work; and they overlaid them with gold. [^10] And the wings of the cherubim were twenty cubits long: the wing of the one cherub was five cubits, reaching to the wall of the house; and the other wing was likewise five cubits, reaching to the wing of the other cherub. [^11] And the wing of the other cherub was five cubits, reaching to the wall of the house; and the other wing was five cubits also, joining to the wing of the other cherub. [^12] The wings of these cherubim spread themselves forth twenty cubits: and they stood on their feet, and their faces were toward the house. [^13] And he made the veil of blue, and purple, and crimson, and fine linen, and wrought cherubim thereon. [^14] Also he made before the house two pillars of thirty and five cubits high, and the capital that was on the top of each of them was five cubits. [^15] And he made chains in the oracle, and put them on the tops of the pillars; and he made a hundred pomegranates, and put them on the chains. [^16] And he set up the pillars before the temple, one on the right hand, and the other on the left; and called the name of that on the right hand Jachin, and the name of that on the left Boaz. [^17] 

[[2 Chronicles - 2|<--]] 2 Chronicles - 3 [[2 Chronicles - 4|-->]]

---
# Notes
