---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 21 - American Standard Version"
---
[[2 Chronicles - 20|<--]] 2 Chronicles - 21 [[2 Chronicles - 22|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[2 Chronicles]]

# 2 Chronicles - 21

And Jehoshaphat slept with his fathers, and was buried with his fathers in the city of David: and Jehoram his son reigned in his stead. [^1] And he had brethren, the sons of Jehoshaphat: Azariah, and Jehiel, and Zechariah, and Azariah, and Michael, and Shephatiah; all these were the sons of Jehoshaphat king of Israel. [^2] And their father gave them great gifts, of silver, and of gold, and of precious things, with fortified cities in Judah: but the kingdom gave he to Jehoram, because he was the first-born. [^3] Now when Jehoram was risen up over the kingdom of his father, and had strengthened himself, he slew all his brethren with the sword, and divers also of the princes of Israel. [^4] Jehoram was thirty and two years old when he began to reign; and he reigned eight years in Jerusalem. [^5] And he walked in the way of the kings of Israel, as did the house of Ahab; for he had the daughter of Ahab to wife: and he did that which was evil in the sight of Jehovah. [^6] Howbeit Jehovah would not destroy the house of David, because of the covenant that he had made with David, and as he promised to give a lamp to him and to his children alway. [^7] In his days Edom revolted from under the hand of Judah, and made a king over themselves. [^8] Then Jehoram passed over with his captains, and all his chariots with him: and he rose up by night, and smote the Edomites that compassed him about, and the captains of the chariots. [^9] So Edom revolted from under the hand of Judah unto this day: then did Libnah revolt at the same time from under his hand, because he had forsaken Jehovah, the God of his fathers. [^10] Moreover he made high places in the mountains of Judah, and made the inhabitants of Jerusalem to play the harlot, and led Judah astray. [^11] And there came a writing to him from Elijah the prophet, saying, Thus saith Jehovah, the God of David thy father, Because thou hast not walked in the ways of Jehoshaphat thy father, nor in the ways of Asa king of Judah, [^12] but hast walked in the way of the kings of Israel, and hast made Judah and the inhabitants of Jerusalem to play the harlot, like as the house of Ahab did, and also hast slain thy brethren of thy father’s house, who were better than thyself: [^13] behold, Jehovah will smite with a great plague thy people, and thy children, and thy wives, and all thy substance; [^14] and thou shalt have great sickness by disease of thy bowels, until thy bowels fall out by reason of the sickness, day by day. [^15] And Jehovah stirred up against Jehoram the spirit of the Philistines, and of the Arabians that are beside the Ethiopians: [^16] and they came up against Judah, and brake into it, and carried away all the substance that was found in the king’s house, and his sons also, and his wives; so that there was never a son left him, save Jehoahaz, the youngest of his sons. [^17] And after all this Jehovah smote him in his bowels with an incurable disease. [^18] And it came to pass, in process of time, at the end of two years, that his bowels fell out by reason of his sickness, and he died of sore diseases. And his people made no burning for him, like the burning of his fathers. [^19] Thirty and two years old was he when he began to reign, and he reigned in Jerusalem eight years: and he departed without being desired; and they buried him in the city of David, but not in the sepulchres of the kings. [^20] 

[[2 Chronicles - 20|<--]] 2 Chronicles - 21 [[2 Chronicles - 22|-->]]

---
# Notes
