---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 19 - American Standard Version"
---
[[2 Chronicles - 18|<--]] 2 Chronicles - 19 [[2 Chronicles - 20|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[2 Chronicles]]

# 2 Chronicles - 19

And Jehoshaphat the king of Judah returned to his house in peace to Jerusalem. [^1] And Jehu the son of Hanani the seer went out to meet him, and said to king Jehoshaphat, Shouldest thou help the wicked, and love them that hate Jehovah? for this thing wrath is upon thee from before Jehovah. [^2] Nevertheless there are good things found in thee, in that thou hast put away the Asheroth out of the land, and hast set thy heart to seek God. [^3] And Jehoshaphat dwelt at Jerusalem: and he went out again among the people from Beer-sheba to the hill-country of Ephraim, and brought them back unto Jehovah, the God of their fathers. [^4] And he set judges in the land throughout all the fortified cities of Judah, city by city, [^5] and said to the judges, Consider what ye do: for ye judge not for man, but for Jehovah; and he is with you in the judgment. [^6] Now therefore let the fear of Jehovah be upon you; take heed and do it: for there is no iniquity with Jehovah our God, nor respect of persons, nor taking of bribes. [^7] Moreover in Jerusalem did Jehoshaphat set of the Levites and the priests, and of the heads of the fathers’ houses of Israel, for the judgment of Jehovah, and for controversies. And they returned to Jerusalem. [^8] And he charged them, saying, Thus shall ye do in the fear of Jehovah, faithfully, and with a perfect heart. [^9] And whensoever any controversy shall come to you from your brethren that dwell in their cities, between blood and blood, between law and commandment, statutes and ordinances, ye shall warn them, that they be not guilty towards Jehovah, and so wrath come upon you and upon your brethren: this do, and ye shall not be guilty. [^10] And, behold, Amariah the chief priest is over you in all matters of Jehovah; and Zebadiah the son of Ishmael, the ruler of the house of Judah, in all the king’s matters: also the Levites shall be officers before you. Deal courageously, and Jehovah be with the good. [^11] 

[[2 Chronicles - 18|<--]] 2 Chronicles - 19 [[2 Chronicles - 20|-->]]

---
# Notes
