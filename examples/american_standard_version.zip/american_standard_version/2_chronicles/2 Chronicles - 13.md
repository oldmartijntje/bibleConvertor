---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 13 - American Standard Version"
---
[[2 Chronicles - 12|<--]] 2 Chronicles - 13 [[2 Chronicles - 14|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[2 Chronicles]]

# 2 Chronicles - 13

In the eighteenth year of king Jeroboam began Abijah to reign over Judah. [^1] Three years reigned he in Jerusalem: and his mother’s name was Micaiah the daughter of Uriel of Gibeah. And there was war between Abijah and Jeroboam. [^2] And Abijah joined battle with an army of valiant men of war, even four hundred thousand chosen men: and Jeroboam set the battle in array against him with eight hundred thousand chosen men, who were mighty men of valor. [^3] And Abijah stood up upon mount Zemaraim, which is in the hill-country of Ephraim, and said, Hear me, O Jeroboam and all Israel: [^4] Ought ye not to know that Jehovah, the God of Israel, gave the kingdom over Israel to David for ever, even to him and to his sons by a covenant of salt? [^5] Yet Jeroboam the son of Nebat, the servant of Solomon the son of David, rose up, and rebelled against his lord. [^6] And there were gathered unto him worthless men, base fellows, that strengthened themselves against Rehoboam the son of Solomon, when Rehoboam was young and tender-hearted, and could not withstand them. [^7] And now ye think to withstand the kingdom of Jehovah in the hand of the sons of David; and ye are a great multitude, and there are with you the golden calves which Jeroboam made you for gods. [^8] Have ye not driven out the priests of Jehovah, the sons of Aaron, and the Levites, and made you priests after the manner of the peoples of other lands? so that whosoever cometh to consecrate himself with a young bullock and seven rams, the same may be a priest of them that are no gods. [^9] But as for us, Jehovah is our God, and we have not forsaken him; and we have priests ministering unto Jehovah, the sons of Aaron, and the Levites in their work: [^10] and they burn unto Jehovah every morning and every evening burnt-offerings and sweet incense: the showbread also set they in order upon the pure table; and the candlestick of gold with the lamps thereof, to burn every evening: for we keep the charge of Jehovah our God; but ye have forsaken him. [^11] And, behold, God is with us at our head, and his priests with the trumpets of alarm to sound an alarm against you. O children of Israel, fight ye not against Jehovah, the God of your fathers; for ye shall not prosper. [^12] But Jeroboam caused an ambushment to come about behind them: so they were before Judah, and the ambushment was behind them. [^13] And when Judah looked back, behold, the battle was before and behind them; and they cried unto Jehovah, and the priests sounded with the trumpets. [^14] Then the men of Judah gave a shout: and as the men of Judah shouted, it came to pass, that God smote Jeroboam and all Israel before Abijah and Judah. [^15] And the children of Israel fled before Judah; and God delivered them into their hand. [^16] And Abijah and his people slew them with a great slaughter: so there fell down slain of Israel five hundred thousand chosen men. [^17] Thus the children of Israel were brought under at that time, and the children of Judah prevailed, because they relied upon Jehovah, the God of their fathers. [^18] And Abijah pursued after Jeroboam, and took cities from him, Beth-el with the towns thereof, and Jeshanah with the towns thereof, and Ephron with the towns thereof. [^19] Neither did Jeroboam recover strength again in the days of Abijah: and Jehovah smote him, and he died. [^20] But Abijah waxed mighty, and took unto himself fourteen wives, and begat twenty and two sons, and sixteen daughters. [^21] And the rest of the acts of Abijah, and his ways, and his sayings, are written in the commentary of the prophet Iddo. [^22] 

[[2 Chronicles - 12|<--]] 2 Chronicles - 13 [[2 Chronicles - 14|-->]]

---
# Notes
