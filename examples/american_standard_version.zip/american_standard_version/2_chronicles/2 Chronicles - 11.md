---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 11 - American Standard Version"
---
[[2 Chronicles - 10|<--]] 2 Chronicles - 11 [[2 Chronicles - 12|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[2 Chronicles]]

# 2 Chronicles - 11

And when Rehoboam was come to Jerusalem, he assembled the house of Judah and Benjamin, a hundred and fourscore thousand chosen men, that were warriors, to fight against Israel, to bring the kingdom again to Rehoboam. [^1] But the word of Jehovah came to Shemaiah the man of God, saying, [^2] Speak unto Rehoboam the son of Solomon, king of Judah, and to all Israel in Judah and Benjamin, saying, [^3] Thus saith Jehovah, Ye shall not go up, nor fight against your brethren: return every man to his house; for this thing is of me. So they hearkened unto the words of Jehovah, and returned from going against Jeroboam. [^4] And Rehoboam dwelt in Jerusalem, and built cities for defence in Judah. [^5] He built Beth-lehem, and Etam, and Tekoa, [^6] And Beth-zur, and Soco, and Adullam, [^7] and Gath, and Mareshah, and Ziph, [^8] and Adoraim, and Lachish, and Azekah, [^9] and Zorah, and Aijalon, and Hebron, which are in Judah and in Benjamin, fortified cities. [^10] And he fortified the strongholds, and put captains in them, and stores of victuals, and oil and wine. [^11] And in every city he put shields and spears, and made them exceeding strong. And Judah and Benjamin belonged to him. [^12] And the priests and the Levites that were in all Israel resorted to him out of all their border. [^13] For the Levites left their suburbs and their possession, and came to Judah and Jerusalem: for Jeroboam and his sons cast them off, that they should not execute the priest’s office unto Jehovah; [^14] and he appointed him priests for the high places, and for the he-goats, and for the calves which he had made. [^15] And after them, out of all the tribes of Israel, such as set their hearts to seek Jehovah, the God of Israel, came to Jerusalem to sacrifice unto Jehovah, the God of their fathers. [^16] So they strengthened the kingdom of Judah, and made Rehoboam the son of Solomon strong, three years; for they walked three years in the way of David and Solomon. [^17] And Rehoboam took him a wife, Mahalath the daughter of Jerimoth the son of David, and of Abihail the daughter of Eliab the son of Jesse; [^18] and she bare him sons: Jeush, and Shemariah, and Zaham. [^19] And after her he took Maacah the daughter of Absalom; and she bare him Abijah, and Attai, and Ziza, and Shelomith. [^20] And Rehoboam loved Maacah the daughter of Absalom above all his wives and his concubines (for he took eighteen wives, and threescore concubines, and begat twenty and eight sons and threescore daughters). [^21] And Rehoboam appointed Abijah the son of Maacah to be chief, even the prince among his brethren; for he was minded to make him king. [^22] And he dealt wisely, and dispersed of all his sons throughout all the lands of Judah and Benjamin, unto every fortified city: and he gave them victuals in abundance. And he sought for them many wives. [^23] 

[[2 Chronicles - 10|<--]] 2 Chronicles - 11 [[2 Chronicles - 12|-->]]

---
# Notes
