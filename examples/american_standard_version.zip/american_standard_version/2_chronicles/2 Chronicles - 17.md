---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 17 - American Standard Version"
---
[[2 Chronicles - 16|<--]] 2 Chronicles - 17 [[2 Chronicles - 18|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[2 Chronicles]]

# 2 Chronicles - 17

And Jehoshaphat his son reigned in his stead, and strengthened himself against Israel. [^1] And he placed forces in all the fortified cities of Judah, and set garrisons in the land of Judah, and in the cities of Ephraim, which Asa his father had taken. [^2] And Jehovah was with Jehoshaphat, because he walked in the first ways of his father David, and sought not unto the Baalim, [^3] but sought to the God of his father, and walked in his commandments, and not after the doings of Israel. [^4] Therefore Jehovah established the kingdom in his hand; and all Judah brought to Jehoshaphat tribute; and he had riches and honor in abundance. [^5] And his heart was lifted up in the ways of Jehovah: and furthermore he took away the high places and the Asherim out of Judah. [^6] Also in the third year of his reign he sent his princes, even Ben-hail, and Obadiah, and Zechariah, and Nethanel, and Micaiah, to teach in the cities of Judah; [^7] and with them the Levites, even Shemaiah, and Nethaniah, and Zebadiah, and Asahel, and Shemiramoth, and Jehonathan, and Adonijah, and Tobijah, and Tob-adonijah, the Levites; and with them Elishama and Jehoram, the priests. [^8] And they taught in Judah, having the book of the law of Jehovah with them; and they went about throughout all the cities of Judah, and taught among the people. [^9] And the fear of Jehovah fell upon all the kingdoms of the lands that were round about Judah, so that they made no war against Jehoshaphat. [^10] And some of the Philistines brought Jehoshaphat presents, and silver for tribute; the Arabians also brought him flocks, seven thousand and seven hundred rams, and seven thousand and seven hundred he-goats. [^11] And Jehoshaphat waxed great exceedingly; and he built in Judah castles and cities of store. [^12] And he had many works in the cities of Judah; and men of war, mighty men of valor, in Jerusalem. [^13] And this was the numbering of them according to their fathers’ houses: Of Judah, the captains of thousands: Adnah the captain, and with him mighty men of valor three hundred thousand; [^14] and next to him Jehohanan the captain, and with him two hundred and fourscore thousand; [^15] and next to him Amasiah the son of Zichri, who willingly offered himself unto Jehovah; and with him two hundred thousand mighty men of valor. [^16] And of Benjamin: Eliada a mighty man of valor, and with him two hundred thousand armed with bow and shield; [^17] and next to him Jehozabad, and with him a hundred and fourscore thousand ready prepared for war. [^18] These were they that waited on the king, besides those whom the king put in the fortified cities throughout all Judah. [^19] 

[[2 Chronicles - 16|<--]] 2 Chronicles - 17 [[2 Chronicles - 18|-->]]

---
# Notes
