---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 11 - American Standard Version"
---
[[Exodus - 10|<--]] Exodus - 11 [[Exodus - 12|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Exodus]]

# Exodus - 11

And Jehovah said unto Moses, Yet one plague more will I bring upon Pharaoh, and upon Egypt; afterwards he will let you go hence: when he shall let you go, he shall surely thrust you out hence altogether. [^1] Speak now in the ears of the people, and let them ask every man of his neighbor, and every woman of her neighbor, jewels of silver, and jewels of gold. [^2] And Jehovah gave the people favor in the sight of the Egyptians. Moreover the man Moses was very great in the land of Egypt, in the sight of Pharaoh’s servants, and in the sight of the people. [^3] And Moses said, Thus saith Jehovah, About midnight will I go out into the midst of Egypt: [^4] and all the first-born in the land of Egypt shall die, from the first-born of Pharaoh that sitteth upon his throne, even unto the first-born of the maid-servant that is behind the mill; and all the first-born of cattle. [^5] And there shall be a great cry throughout all the land of Egypt, such as there hath not been, nor shall be any more. [^6] But against any of the children of Israel shall not a dog move his tongue, against man or beast: that ye may know how that Jehovah doth make a distinction between the Egyptians and Israel. [^7] And all these thy servants shall come down unto me, and bow down themselves unto me, saying, Get thee out, and all the people that follow thee: and after that I will go out. And he went out from Pharaoh in hot anger. [^8] And Jehovah said unto Moses, Pharaoh will not hearken unto you; that my wonders may be multiplied in the land of Egypt. [^9] And Moses and Aaron did all these wonders before Pharaoh: and Jehovah hardened Pharaoh’s heart, and he did not let the children of Israel go out of his land. [^10] 

[[Exodus - 10|<--]] Exodus - 11 [[Exodus - 12|-->]]

---
# Notes
