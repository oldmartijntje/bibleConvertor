---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 13 - American Standard Version"
---
[[Exodus - 12|<--]] Exodus - 13 [[Exodus - 14|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Exodus]]

# Exodus - 13

And Jehovah spake unto Moses, saying, [^1] Sanctify unto me all the first-born, whatsoever openeth the womb among the children of Israel, both of man and of beast: it is mine. [^2] And Moses said unto the people, Remember this day, in which ye came out from Egypt, out of the house of bondage; for by strength of hand Jehovah brought you out from this place: there shall no leavened bread be eaten. [^3] This day ye go forth in the month Abib. [^4] And it shall be, when Jehovah shall bring thee into the land of the Canaanite, and the Hittite, and the Amorite, and the Hivite, and the Jebusite, which he sware unto thy fathers to give thee, a land flowing with milk and honey, that thou shalt keep this service in this month. [^5] Seven days thou shalt eat unleavened bread, and in the seventh day shall be a feast to Jehovah. [^6] Unleavened bread shall be eaten throughout the seven days; and there shall no leavened bread be seen with thee, neither shall there be leaven seen with thee, in all thy borders. [^7] And thou shalt tell thy son in that day, saying, It is because of that which Jehovah did for me when I came forth out of Egypt. [^8] And it shall be for a sign unto thee upon thy hand, and for a memorial between thine eyes, that the law of Jehovah may be in thy mouth: for with a strong hand hath Jehovah brought thee out of Egypt. [^9] Thou shalt therefore keep this ordinance in its season from year to year. [^10] And it shall be, when Jehovah shall bring thee into the land of the Canaanite, as he sware unto thee and to thy fathers, and shall give it thee, [^11] that thou shalt set apart unto Jehovah all that openeth the womb, and every firstling which thou hast that cometh of a beast; the males shall be Jehovah’s. [^12] And every firstling of an ass thou shalt redeem with a lamb; and if thou wilt not redeem it, then thou shalt break its neck: and all the first-born of man among thy sons shalt thou redeem. [^13] And it shall be, when thy son asketh thee in time to come, saying, What is this? that thou shalt say unto him, By strength of hand Jehovah brought us out from Egypt, from the house of bondage: [^14] and it came to pass, when Pharaoh would hardly let us go, that Jehovah slew all the first-born in the land of Egypt, both the first-born of man, and the first-born of beast: therefore I sacrifice to Jehovah all that openeth the womb, being males; but all the first-born of my sons I redeem. [^15] And it shall be for a sign upon thy hand, and for frontlets between thine eyes: for by strength of hand Jehovah brought us forth out of Egypt. [^16] And it came to pass, when Pharaoh had let the people go, that God led them not by the way of the land of the Philistines, although that was near; for God said, Lest peradventure the people repent when they see war, and they return to Egypt: [^17] but God led the people about, by the way of the wilderness by the Red Sea: and the children of Israel went up armed out of the land of Egypt. [^18] And Moses took the bones of Joseph with him: for he had straitly sworn the children of Israel, saying, God will surely visit you; and ye shall carry up my bones away hence with you. [^19] And they took their journey from Succoth, and encamped in Etham, in the edge of the wilderness. [^20] And Jehovah went before them by day in a pillar of cloud, to lead them the way, and by night in a pillar of fire, to give them light; that they might go by day and by night: [^21] the pillar of cloud by day, and the pillar of fire by night, departed not from before the people. [^22] 

[[Exodus - 12|<--]] Exodus - 13 [[Exodus - 14|-->]]

---
# Notes
