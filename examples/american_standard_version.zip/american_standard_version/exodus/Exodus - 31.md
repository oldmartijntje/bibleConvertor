---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 31 - American Standard Version"
---
[[Exodus - 30|<--]] Exodus - 31 [[Exodus - 32|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Exodus]]

# Exodus - 31

And Jehovah spake unto Moses, saying, [^1] See, I have called by name Bezalel the son of Uri, the son of Hur, of the tribe of Judah: [^2] and I have filled him with the Spirit of God, in wisdom, and in understanding, and in knowledge, and in all manner of workmanship, [^3] to devise skilful works, to work in gold, and in silver, and in brass, [^4] and in cutting of stones for setting, and in carving of wood, to work in all manner of workmanship. [^5] And I, behold, I have appointed with him Oholiab, the son of Ahisamach, of the tribe of Dan; and in the heart of all that are wise-hearted I have put wisdom, that they may make all that I have commanded thee: [^6] the tent of meeting, and the ark of the testimony, and the mercy-seat that is thereupon, and all the furniture of the Tent, [^7] and the table and its vessels, and the pure candlestick with all its vessels, and the altar of incense, [^8] and the altar of burnt-offering with all its vessels, and the laver and its base, [^9] and the finely wrought garments, and the holy garments for Aaron the priest, and the garments of his sons, to minister in the priest’s office, [^10] and the anointing oil, and the incense of sweet spices for the holy place: according to all that I have commanded thee shall they do. [^11] And Jehovah spake unto Moses, saying, [^12] Speak thou also unto the children of Israel, saying, Verily ye shall keep my sabbaths: for it is a sign between me and you throughout your generations; that ye may know that I am Jehovah who sanctifieth you. [^13] Ye shall keep the sabbath therefore; for it is holy unto you: every one that profaneth it shall surely be put to death; for whosoever doeth any work therein, that soul shall be cut off from among his people. [^14] Six days shall work be done, but on the seventh day is a sabbath of solemn rest, holy to Jehovah: whosoever doeth any work on the sabbath day, he shall surely be put to death. [^15] Wherefore the children of Israel shall keep the sabbath, to observe the sabbath throughout their generations, for a perpetual covenant. [^16] It is a sign between me and the children of Israel for ever: for in six days Jehovah made heaven and earth, and on the seventh day he rested, and was refreshed. [^17] And he gave unto Moses, when he had made an end of communing with him upon mount Sinai, the two tables of the testimony, tables of stone, written with the finger of God. [^18] 

[[Exodus - 30|<--]] Exodus - 31 [[Exodus - 32|-->]]

---
# Notes
