---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 15 - American Standard Version"
---
[[Exodus - 14|<--]] Exodus - 15 [[Exodus - 16|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Exodus]]

# Exodus - 15

Then sang Moses and the children of Israel this song unto Jehovah, and spake, saying,I will sing unto Jehovah, for he hath triumphed gloriously:The horse and his rider hath he thrown into the sea. [^1] Jehovah is my strength and song,And he is become my salvation:This is my God, and I will praise him;My father’s God, and I will exalt him. [^2] Jehovah is a man of war:Jehovah is his name. [^3] Pharaoh’s chariots and his host hath he cast into the sea;And his chosen captains are sunk in the Red Sea. [^4] The deeps cover them:They went down into the depths like a stone. [^5] Thy right hand, O Jehovah, is glorious in power,Thy right hand, O Jehovah, dasheth in pieces the enemy. [^6] And in the greatness of thine excellency thou overthrowest them that rise up against thee:Thou sendest forth thy wrath, it consumeth them as stubble. [^7] And with the blast of thy nostrils the waters were piled up,The floods stood upright as a heap;The deeps were congealed in the heart of the sea. [^8] The enemy said, I will pursue, I will overtake, I will divide the spoil;My desire shall be satisfied upon them;I will draw my sword, my hand shall destroy them. [^9] Thou didst blow with thy wind, the sea covered them:They sank as lead in the mighty waters. [^10] Who is like unto thee, O Jehovah, among the gods?Who is like thee, glorious in holiness,Fearful in praises, doing wonders? [^11] Thou stretchedst out thy right hand,The earth swallowed them. [^12] Thou in thy lovingkindness hast led the people that thou hast redeemed:Thou hast guided them in thy strength to thy holy habitation. [^13] The peoples have heard, they tremble:Pangs have taken hold on the inhabitants of Philistia. [^14] Then were the chiefs of Edom dismayed;The mighty men of Moab, trembling taketh hold upon them:All the inhabitants of Canaan are melted away. [^15] Terror and dread falleth upon them;By the greatness of thine arm they are as still as a stone;Till thy people pass over, O Jehovah,Till the people pass over that thou hast purchased. [^16] Thou wilt bring them in, and plant them in the mountain of thine inheritance,The place, O Jehovah, which thou hast made for thee to dwell in,The sanctuary, O Lord, which thy hands have established. [^17] Jehovah shall reign for ever and ever. [^18] For the horses of Pharaoh went in with his chariots and with his horsemen into the sea, and Jehovah brought back the waters of the sea upon them; but the children of Israel walked on dry land in the midst of the sea. [^19] And Miriam the prophetess, the sister of Aaron, took a timbrel in her hand; and all the women went out after her with timbrels and with dances. [^20] And Miriam answered them,Sing ye to Jehovah, for he hath triumphed gloriously;The horse and his rider hath he thrown into the sea. [^21] And Moses led Israel onward from the Red Sea, and they went out into the wilderness of Shur; and they went three days in the wilderness, and found no water. [^22] And when they came to Marah, they could not drink of the waters of Marah, for they were bitter: therefore the name of it was called Marah. [^23] And the people murmured against Moses, saying, What shall we drink? [^24] And he cried unto Jehovah; and Jehovah showed him a tree, and he cast it into the waters, and the waters were made sweet. There he made for them a statute and an ordinance, and there he proved them; [^25] and he said, If thou wilt diligently hearken to the voice of Jehovah thy God, and wilt do that which is right in his eyes, and wilt give ear to his commandments, and keep all his statutes, I will put none of the diseases upon thee, which I have put upon the Egyptians: for I am Jehovah that healeth thee. [^26] And they came to Elim, where were twelve springs of water, and threescore and ten palm-trees: and they encamped there by the waters. [^27] 

[[Exodus - 14|<--]] Exodus - 15 [[Exodus - 16|-->]]

---
# Notes
