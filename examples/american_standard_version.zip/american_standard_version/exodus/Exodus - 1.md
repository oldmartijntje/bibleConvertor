---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 1 - American Standard Version"
---
Exodus - 1 [[Exodus - 2|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Exodus]]

# Exodus - 1

Now these are the names of the sons of Israel, who came into Egypt (every man and his household came with Jacob): [^1] Reuben, Simeon, Levi, and Judah, [^2] Issachar, Zebulun, and Benjamin, [^3] Dan and Naphtali, Gad and Asher. [^4] And all the souls that came out of the loins of Jacob were seventy souls: and Joseph was in Egypt already. [^5] And Joseph died, and all his brethren, and all that generation. [^6] And the children of Israel were fruitful, and increased abundantly, and multiplied, and waxed exceeding mighty; and the land was filled with them. [^7] Now there arose a new king over Egypt, who knew not Joseph. [^8] And he said unto his people, Behold, the people of the children of Israel are more and mightier than we: [^9] come, let us deal wisely with them, lest they multiply, and it come to pass, that, when there falleth out any war, they also join themselves unto our enemies, and fight against us, and get them up out of the land. [^10] Therefore they did set over them taskmasters to afflict them with their burdens. And they built for Pharaoh store-cities, Pithom and Raamses. [^11] But the more they afflicted them, the more they multiplied and the more they spread abroad. And they were grieved because of the children of Israel. [^12] And the Egyptians made the children of Israel to serve with rigor: [^13] and they made their lives bitter with hard service, in mortar and in brick, and in all manner of service in the field, all their service, wherein they made them serve with rigor. [^14] And the king of Egypt spake to the Hebrew midwives, of whom the name of the one was Shiphrah, and the name of the other Puah: [^15] and he said, When ye do the office of a midwife to the Hebrew women, and see them upon the birth-stool; if it be a son, then ye shall kill him; but if it be a daughter, then she shall live. [^16] But the midwives feared God, and did not as the king of Egypt commanded them, but saved the men-children alive. [^17] And the king of Egypt called for the midwives, and said unto them, Why have ye done this thing, and have saved the men-children alive? [^18] And the midwives said unto Pharaoh, Because the Hebrew women are not as the Egyptian women; for they are lively, and are delivered ere the midwife come unto them. [^19] And God dealt well with the midwives: and the people multiplied, and waxed very mighty. [^20] And it came to pass, because the midwives feared God, that he made them households. [^21] And Pharaoh charged all his people, saying, Every son that is born ye shall cast into the river, and every daughter ye shall save alive. [^22] 

Exodus - 1 [[Exodus - 2|-->]]

---
# Notes
