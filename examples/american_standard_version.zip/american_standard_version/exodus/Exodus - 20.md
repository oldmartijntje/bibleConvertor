---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 20 - American Standard Version"
---
[[Exodus - 19|<--]] Exodus - 20 [[Exodus - 21|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Exodus]]

# Exodus - 20

And God spake all these words, saying, [^1] I am Jehovah thy God, who brought thee out of the land of Egypt, out of the house of bondage. [^2] Thou shalt have no other gods before me. [^3] Thou shalt not make unto thee a graven image, nor any likeness of any thing that is in heaven above, or that is in the earth beneath, or that is in the water under the earth: [^4] thou shalt not bow down thyself unto them, nor serve them; for I Jehovah thy God am a jealous God, visiting the iniquity of the fathers upon the children, upon the third and upon the fourth generation of them that hate me, [^5] and showing lovingkindness unto thousands of them that love me and keep my commandments. [^6] Thou shalt not take the name of Jehovah thy God in vain; for Jehovah will not hold him guiltless that taketh his name in vain. [^7] Remember the sabbath day, to keep it holy. [^8] Six days shalt thou labor, and do all thy work; [^9] but the seventh day is a sabbath unto Jehovah thy God: in it thou shalt not do any work, thou, nor thy son, nor thy daughter, thy man-servant, nor thy maid-servant, nor thy cattle, nor thy stranger that is within thy gates: [^10] for in six days Jehovah made heaven and earth, the sea, and all that in them is, and rested the seventh day: wherefore Jehovah blessed the sabbath day, and hallowed it. [^11] Honor thy father and thy mother, that thy days may be long in the land which Jehovah thy God giveth thee. [^12] Thou shalt not kill. [^13] Thou shalt not commit adultery. [^14] Thou shalt not steal. [^15] Thou shalt not bear false witness against thy neighbor. [^16] Thou shalt not covet thy neighbor’s house, thou shalt not covet thy neighbor’s wife, nor his man-servant, nor his maid-servant, nor his ox, nor his ass, nor anything that is thy neighbor’s. [^17] And all the people perceived the thunderings, and the lightnings, and the voice of the trumpet, and the mountain smoking: and when the people saw it, they trembled, and stood afar off. [^18] And they said unto Moses, Speak thou with us, and we will hear; but let not God speak with us, lest we die. [^19] And Moses said unto the people, Fear not: for God is come to prove you, and that his fear may be before you, that ye sin not. [^20] And the people stood afar off, and Moses drew near unto the thick darkness where God was. [^21] And Jehovah said unto Moses, Thus thou shalt say unto the children of Israel, Ye yourselves have seen that I have talked with you from heaven. [^22] Ye shall not make other gods with me; gods of silver, or gods of gold, ye shall not make unto you. [^23] An altar of earth thou shalt make unto me, and shalt sacrifice thereon thy burnt-offerings, and thy peace-offerings, thy sheep, and thine oxen: in every place where I record my name I will come unto thee and I will bless thee. [^24] And if thou make me an altar of stone, thou shalt not build it of hewn stones; for if thou lift up thy tool upon it, thou hast polluted it. [^25] Neither shalt thou go up by steps unto mine altar, that thy nakedness be not uncovered thereon. [^26] 

[[Exodus - 19|<--]] Exodus - 20 [[Exodus - 21|-->]]

---
# Notes
