---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 27 - American Standard Version"
---
[[Exodus - 26|<--]] Exodus - 27 [[Exodus - 28|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Exodus]]

# Exodus - 27

And thou shalt make the altar of acacia wood, five cubits long, and five cubits broad; the altar shall be foursquare: and the height thereof shall be three cubits. [^1] And thou shalt make the horns of it upon the four corners thereof; the horns thereof shall be of one piece with it: and thou shalt overlay it with brass. [^2] And thou shalt make its pots to take away its ashes, and its shovels, and its basins, and its flesh-hooks, and its firepans: all the vessels thereof thou shalt make of brass. [^3] And thou shalt make for it a grating of network of brass: and upon the net shalt thou make four brazen rings in the four corners thereof. [^4] And thou shalt put it under the ledge round the altar beneath, that the net may reach halfway up the altar. [^5] And thou shalt make staves for the altar, staves of acacia wood, and overlay them with brass. [^6] And the staves thereof shall be put into the rings, and the staves shall be upon the two sides of the altar, in bearing it. [^7] Hollow with planks shalt thou make it: as it hath been showed thee in the mount, so shall they make it. [^8] And thou shalt make the court of the tabernacle: for the south side southward there shall be hangings for the court of fine twined linen a hundred cubits long for one side: [^9] and the pillars thereof shall be twenty, and their sockets twenty, of brass; the hooks of the pillars and their fillets shall be of silver. [^10] And likewise for the north side in length there shall be hangings a hundred cubits long, and the pillars thereof twenty, and their sockets twenty, of brass; the hooks of the pillars, and their fillets, of silver. [^11] And for the breadth of the court on the west side shall be hangings of fifty cubits; their pillars ten, and their sockets ten. [^12] And the breadth of the court on the east side eastward shall be fifty cubits. [^13] The hangings for the one side of the gate shall be fifteen cubits; their pillars three, and their sockets three. [^14] And for the other side shall be hangings of fifteen cubits; their pillars three, and their sockets three. [^15] And for the gate of the court shall be a screen of twenty cubits, of blue, and purple, and scarlet, and fine twined linen, the work of the embroiderer; their pillars four, and their sockets four. [^16] All the pillars of the court round about shall be filleted with silver; their hooks of silver, and their sockets of brass. [^17] The length of the court shall be a hundred cubits, and the breadth fifty every where, and the height five cubits, of fine twined linen, and their sockets of brass. [^18] All the instruments of the tabernacle in all the service thereof, and all the pins thereof, and all the pins of the court, shall be of brass. [^19] And thou shalt command the children of Israel, that they bring unto thee pure olive oil beaten for the light, to cause a lamp to burn continually. [^20] In the tent of meeting, without the veil which is before the testimony, Aaron and his sons shall keep it in order from evening to morning before Jehovah: it shall be a statute for ever throughout their generations on the behalf of the children of Israel. [^21] 

[[Exodus - 26|<--]] Exodus - 27 [[Exodus - 28|-->]]

---
# Notes
