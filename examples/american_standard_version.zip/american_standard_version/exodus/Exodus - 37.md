---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 37 - American Standard Version"
---
[[Exodus - 36|<--]] Exodus - 37 [[Exodus - 38|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Exodus]]

# Exodus - 37

And Bezalel made the ark of acacia wood: two cubits and a half was the length of it, and a cubit and a half the breadth of it, and a cubit and a half the height of it. [^1] And he overlaid it with pure gold within and without, and made a crown of gold to it round about. [^2] And he cast for it four rings of gold, in the four feet thereof; even two rings on the one side of it, and two rings on the other side of it. [^3] And he made staves of acacia wood, and overlaid them with gold. [^4] And he put the staves into the rings on the sides of the ark, to bear the ark. [^5] And he made a mercy-seat of pure gold: two cubits and a half was the length thereof, and a cubit and a half the breadth thereof. [^6] And he made two cherubim of gold; of beaten work made he them, at the two ends of the mercy-seat; [^7] one cherub at the one end, and one cherub at the other end: of one piece with the mercy-seat made he the cherubim at the two ends thereof. [^8] And the cherubim spread out their wings on high, covering the mercy-seat with their wings, with their faces one to another; toward the mercy-seat were the faces of the cherubim. [^9] And he made the table of acacia wood: two cubits was the length thereof, and a cubit the breadth thereof, and a cubit and a half the height thereof. [^10] And he overlaid it with pure gold, and made thereto a crown of gold round about. [^11] And he made unto it a border of a handbreadth round about, and made a golden crown to the border thereof round about. [^12] And he cast for it four rings of gold, and put the rings in the four corners that were on the four feet thereof. [^13] Close by the border were the rings, the places for the staves to bear the table. [^14] And he made the staves of acacia wood, and overlaid them with gold, to bear the table. [^15] And he made the vessels which were upon the table, the dishes thereof, and the spoons thereof, and the bowls thereof, and the flagons thereof, wherewith to pour out, of pure gold. [^16] And he made the candlestick of pure gold: of beaten work made he the candlestick, even its base, and its shaft; its cups, its knops, and its flowers, were of one piece with it. [^17] And there were six branches going out of the sides thereof; three branches of the candlestick out of the one side thereof, and three branches of the candlestick out of the other side thereof: [^18] three cups made like almond-blossoms in one branch, a knop and a flower, and three cups made like almond-blossoms in the other branch, a knop and a flower: so for the six branches going out of the candlestick. [^19] And in the candlestick were four cups made like almond-blossoms, the knops thereof, and the flowers thereof; [^20] and a knop under two branches of one piece with it, and a knop under two branches of one piece with it, and a knop under two branches of one piece with it, for the six branches going out of it. [^21] Their knops and their branches were of one piece with it: the whole of it was one beaten work of pure gold. [^22] And he made the lamps thereof, seven, and the snuffers thereof, and the snuffdishes thereof, of pure gold. [^23] Of a talent of pure gold made he it, and all the vessels thereof. [^24] And he made the altar of incense of acacia wood: a cubit was the length thereof, and a cubit the breadth thereof, foursquare; and two cubits was the height thereof; the horns thereof were of one piece with it. [^25] And he overlaid it with pure gold, the top thereof, and the sides thereof round about, and the horns of it: and he made unto it a crown of gold round about. [^26] And he made for it two golden rings under the crown thereof, upon the two ribs thereof, upon the two sides of it, for places for staves wherewith to bear it. [^27] And he made the staves of acacia wood, and overlaid them with gold. [^28] And he made the holy anointing oil, and the pure incense of sweet spices, after the art of the perfumer. [^29] 

[[Exodus - 36|<--]] Exodus - 37 [[Exodus - 38|-->]]

---
# Notes
