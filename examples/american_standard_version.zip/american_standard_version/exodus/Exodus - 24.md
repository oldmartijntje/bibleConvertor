---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 24 - American Standard Version"
---
[[Exodus - 23|<--]] Exodus - 24 [[Exodus - 25|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Exodus]]

# Exodus - 24

And he said unto Moses, Come up unto Jehovah, thou, and Aaron, Nadab, and Abihu, and seventy of the elders of Israel; and worship ye afar off: [^1] and Moses alone shall come near unto Jehovah; but they shall not come near; neither shall the people go up with him. [^2] And Moses came and told the people all the words of Jehovah, and all the ordinances: and all the people answered with one voice, and said, All the words which Jehovah hath spoken will we do. [^3] And Moses wrote all the words of Jehovah, and rose up early in the morning, and builded an altar under the mount, and twelve pillars, according to the twelve tribes of Israel. [^4] And he sent young men of the children of Israel, who offered burnt-offerings, and sacrificed peace-offerings of oxen unto Jehovah. [^5] And Moses took half of the blood, and put it in basins; and half of the blood he sprinkled on the altar. [^6] And he took the book of the covenant, and read in the audience of the people: and they said, All that Jehovah hath spoken will we do, and be obedient. [^7] And Moses took the blood, and sprinkled it on the people, and said, Behold the blood of the covenant, which Jehovah hath made with you concerning all these words. [^8] Then went up Moses, and Aaron, Nadab, and Abihu, and seventy of the elders of Israel: [^9] and they saw the God of Israel; and there was under his feet as it were a paved work of sapphire stone, and as it were the very heaven for clearness. [^10] And upon the nobles of the children of Israel he laid not his hand: and they beheld God, and did eat and drink. [^11] And Jehovah said unto Moses, Come up to me into the mount, and be there: and I will give thee the tables of stone, and the law and the commandment, which I have written, that thou mayest teach them. [^12] And Moses rose up, and Joshua his minister: and Moses went up into the mount of God. [^13] And he said unto the elders, Tarry ye here for us, until we come again unto you: and, behold, Aaron and Hur are with you: whosoever hath a cause, let him come near unto them. [^14] And Moses went up into the mount, and the cloud covered the mount. [^15] And the glory of Jehovah abode upon mount Sinai, and the cloud covered it six days: and the seventh day he called unto Moses out of the midst of the cloud. [^16] And the appearance of the glory of Jehovah was like devouring fire on the top of the mount in the eyes of the children of Israel. [^17] And Moses entered into the midst of the cloud, and went up into the mount: and Moses was in the mount forty days and forty nights. [^18] 

[[Exodus - 23|<--]] Exodus - 24 [[Exodus - 25|-->]]

---
# Notes
