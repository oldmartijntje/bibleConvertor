---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 33 - American Standard Version"
---
[[Exodus - 32|<--]] Exodus - 33 [[Exodus - 34|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Exodus]]

# Exodus - 33

And Jehovah spake unto Moses, Depart, go up hence, thou and the people that thou hast brought up out of the land of Egypt, unto the land of which I sware unto Abraham, to Isaac, and to Jacob, saying, Unto thy seed will I give it: [^1] and I will send an angel before thee; and I will drive out the Canaanite, the Amorite, and the Hittite, and the Perizzite, the Hivite, and the Jebusite: [^2] unto a land flowing with milk and honey: for I will not go up in the midst of thee, for thou art a stiffnecked people, lest I consume thee in the way. [^3] And when the people heard these evil tidings, they mourned: and no man did put on him his ornaments. [^4] And Jehovah said unto Moses, Say unto the children of Israel, Ye are a stiffnecked people; if I go up into the midst of thee for one moment, I shall consume thee: therefore now put off thy ornaments from thee, that I may know what to do unto thee. [^5] And the children of Israel stripped themselves of their ornaments from mount Horeb onward. [^6] Now Moses used to take the tent and to pitch it without the camp, afar off from the camp; and he called it, The tent of meeting. And it came to pass, that every one that sought Jehovah went out unto the tent of meeting, which was without the camp. [^7] And it came to pass, when Moses went out unto the Tent, that all the people rose up, and stood, every man at his tent door, and looked after Moses, until he was gone into the Tent. [^8] And it came to pass, when Moses entered into the Tent, the pillar of cloud descended, and stood at the door of the Tent: and Jehovah spake with Moses. [^9] And all the people saw the pillar of cloud stand at the door of the Tent: and all the people rose up and worshipped, every man at his tent door. [^10] And Jehovah spake unto Moses face to face, as a man speaketh unto his friend. And he turned again into the camp: but his minister Joshua, the son of Nun, a young man, departed not out of the Tent. [^11] And Moses said unto Jehovah, See, thou sayest unto me, Bring up this people: and thou hast not let me know whom thou wilt send with me. Yet thou hast said, I know thee by name, and thou hast also found favor in my sight. [^12] Now therefore, I pray thee, if I have found favor in thy sight, show me now thy ways, that I may know thee, to the end that I may find favor in thy sight: and consider that this nation is thy people. [^13] And he said, My presence shall go with thee, and I will give thee rest. [^14] And he said unto him, If thy presence go not with me, carry us not up hence. [^15] For wherein now shall it be known that I have found favor in thy sight, I and thy people? is it not in that thou goest with us, so that we are separated, I and thy people, from all the people that are upon the face of the earth? [^16] And Jehovah said unto Moses, I will do this thing also that thou hast spoken; for thou hast found favor in my sight, and I know thee by name. [^17] And he said, Show me, I pray thee, thy glory. [^18] And he said, I will make all my goodness pass before thee, and will proclaim the name of Jehovah before thee; and I will be gracious to whom I will be gracious, and will show mercy on whom I will show mercy. [^19] And he said, Thou canst not see my face; for man shall not see me and live. [^20] And Jehovah said, Behold, there is a place by me, and thou shalt stand upon the rock: [^21] and it shall come to pass, while my glory passeth by, that I will put thee in a cleft of the rock, and will cover thee with my hand until I have passed by: [^22] and I will take away my hand, and thou shalt see my back; but my face shall not be seen. [^23] 

[[Exodus - 32|<--]] Exodus - 33 [[Exodus - 34|-->]]

---
# Notes
