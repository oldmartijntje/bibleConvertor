---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 2 - American Standard Version"
---
[[Exodus - 1|<--]] Exodus - 2 [[Exodus - 3|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Exodus]]

# Exodus - 2

And there went a man of the house of Levi, and took to wife a daughter of Levi. [^1] And the woman conceived, and bare a son: and when she saw him that he was a goodly child, she hid him three months. [^2] And when she could not longer hide him, she took for him an ark of bulrushes, and daubed it with slime and with pitch; and she put the child therein, and laid it in the flags by the river’s brink. [^3] And his sister stood afar off, to know what would be done to him. [^4] And the daughter of Pharaoh came down to bathe at the river; and her maidens walked along by the river-side; and she saw the ark among the flags, and sent her handmaid to fetch it. [^5] And she opened it, and saw the child: and, behold, the babe wept. And she had compassion on him, and said, This is one of the Hebrews’ children. [^6] Then said his sister to Pharaoh’s daughter, Shall I go and call thee a nurse of the Hebrew women, that she may nurse the child for thee? [^7] And Pharaoh’s daughter said to her, Go. And the maiden went and called the child’s mother. [^8] And Pharaoh’s daughter said unto her, Take this child away, and nurse it for me, and I will give thee thy wages. And the woman took the child, and nursed it. [^9] And the child grew, and she brought him unto Pharaoh’s daughter, and he became her son. And she called his name Moses, and said, Because I drew him out of the water. [^10] And it came to pass in those days, when Moses was grown up, that he went out unto his brethren, and looked on their burdens: and he saw an Egyptian smiting a Hebrew, one of his brethren. [^11] And he looked this way and that way, and when he saw that there was no man, he smote the Egyptian, and hid him in the sand. [^12] And he went out the second day, and, behold, two men of the Hebrews were striving together: and he said to him that did the wrong, Wherefore smitest thou thy fellow? [^13] And he said, Who made thee a prince and a judge over us? thinkest thou to kill me, as thou killedst the Egyptian? And Moses feared, and said, Surely the thing is known. [^14] Now when Pharaoh heard this thing, he sought to slay Moses. But Moses fled from the face of Pharaoh, and dwelt in the land of Midian: and he sat down by a well. [^15] Now the priest of Midian had seven daughters: and they came and drew water, and filled the troughs to water their father’s flock. [^16] And the shepherds came and drove them away; but Moses stood up and helped them, and watered their flock. [^17] And when they came to Reuel their father, he said, How is it that ye are come so soon to-day? [^18] And they said, An Egyptian delivered us out of the hand of the shepherds, and moreover he drew water for us, and watered the flock. [^19] And he said unto his daughters, And where is he? why is it that ye have left the man? call him, that he may eat bread. [^20] And Moses was content to dwell with the man: and he gave Moses Zipporah his daughter. [^21] And she bare a son, and he called his name Gershom; for he said, I have been a sojourner in a foreign land. [^22] And it came to pass in the course of those many days, that the king of Egypt died: and the children of Israel sighed by reason of the bondage, and they cried, and their cry came up unto God by reason of the bondage. [^23] And God heard their groaning, and God remembered his covenant with Abraham, with Isaac, and with Jacob. [^24] And God saw the children of Israel, and God took knowledge of them. [^25] 

[[Exodus - 1|<--]] Exodus - 2 [[Exodus - 3|-->]]

---
# Notes
