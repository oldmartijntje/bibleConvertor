---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 19 - American Standard Version"
---
[[Exodus - 18|<--]] Exodus - 19 [[Exodus - 20|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Exodus]]

# Exodus - 19

In the third month after the children of Israel were gone forth out of the land of Egypt, the same day came they into the wilderness of Sinai. [^1] And when they were departed from Rephidim, and were come to the wilderness of Sinai, they encamped in the wilderness; and there Israel encamped before the mount. [^2] And Moses went up unto God, and Jehovah called unto him out of the mountain, saying, Thus shalt thou say to the house of Jacob, and tell the children of Israel: [^3] Ye have seen what I did unto the Egyptians, and how I bare you on eagles’ wings, and brought you unto myself. [^4] Now therefore, if ye will obey my voice indeed, and keep my covenant, then ye shall be mine own possession from among all peoples: for all the earth is mine: [^5] and ye shall be unto me a kingdom of priests, and a holy nation. These are the words which thou shalt speak unto the children of Israel. [^6] And Moses came and called for the elders of the people, and set before them all these words which Jehovah commanded him. [^7] And all the people answered together, and said, All that Jehovah hath spoken we will do. And Moses reported the words of the people unto Jehovah. [^8] And Jehovah said unto Moses, Lo, I come unto thee in a thick cloud, that the people may hear when I speak with thee, and may also believe thee for ever. And Moses told the words of the people unto Jehovah. [^9] And Jehovah said unto Moses, Go unto the people, and sanctify them to-day and to-morrow, and let them wash their garments, [^10] and be ready against the third day; for the third day Jehovah will come down in the sight of all the people upon mount Sinai. [^11] And thou shalt set bounds unto the people round about, saying, Take heed to yourselves, that ye go not up into the mount, or touch the border of it: whosoever toucheth the mount shall be surely put to death: [^12] no hand shall touch him, but he shall surely be stoned, or shot through; whether it be beast or man, he shall not live: when the trumpet soundeth long, they shall come up to the mount. [^13] And Moses went down from the mount unto the people, and sanctified the people; and they washed their garments. [^14] And he said unto the people, Be ready against the third day: come not near a woman. [^15] And it came to pass on the third day, when it was morning, that there were thunders and lightnings, and a thick cloud upon the mount, and the voice of a trumpet exceeding loud; and all the people that were in the camp trembled. [^16] And Moses brought forth the people out of the camp to meet God; and they stood at the nether part of the mount. [^17] And mount Sinai, the whole of it, smoked, because Jehovah descended upon it in fire; and the smoke thereof ascended as the smoke of a furnace, and the whole mount quaked greatly. [^18] And when the voice of the trumpet waxed louder and louder, Moses spake, and God answered him by a voice. [^19] And Jehovah came down upon mount Sinai, to the top of the mount: and Jehovah called Moses to the top of the mount; and Moses went up. [^20] And Jehovah said unto Moses, Go down, charge the people, lest they break through unto Jehovah to gaze, and many of them perish. [^21] And let the priests also, that come near to Jehovah, sanctify themselves, lest Jehovah break forth upon them. [^22] And Moses said unto Jehovah, The people cannot come up to mount Sinai: for thou didst charge us, saying, Set bounds about the mount, and sanctify it. [^23] And Jehovah said unto him, Go, get thee down; and thou shalt come up, thou, and Aaron with thee: but let not the priests and the people break through to come up unto Jehovah, lest he break forth upon them. [^24] So Moses went down unto the people, and told them. [^25] 

[[Exodus - 18|<--]] Exodus - 19 [[Exodus - 20|-->]]

---
# Notes
