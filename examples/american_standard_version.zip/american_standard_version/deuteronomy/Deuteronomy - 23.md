---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 23 - American Standard Version"
---
[[Deuteronomy - 22|<--]] Deuteronomy - 23 [[Deuteronomy - 24|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Deuteronomy]]

# Deuteronomy - 23

He that is wounded in the stones, or hath his privy member cut off, shall not enter into the assembly of Jehovah. [^1] A bastard shall not enter into the assembly of Jehovah; even to the tenth generation shall none of his enter into the assembly of Jehovah. [^2] An Ammonite or a Moabite shall not enter into the assembly of Jehovah; even to the tenth generation shall none belonging to them enter into the assembly of Jehovah for ever: [^3] because they met you not with bread and with water in the way, when ye came forth out of Egypt, and because they hired against thee Balaam the son of Beor from Pethor of Mesopotamia, to curse thee. [^4] Nevertheless Jehovah thy God would not hearken unto Balaam; but Jehovah thy God turned the curse into a blessing unto thee, because Jehovah thy God loved thee. [^5] Thou shalt not seek their peace nor their prosperity all thy days for ever. [^6] Thou shalt not abhor an Edomite; for he is thy brother: thou shalt not abhor an Egyptian; because thou wast a sojourner in his land. [^7] The children of the third generation that are born unto them shall enter into the assembly of Jehovah. [^8] When thou goest forth in camp against thine enemies, then thou shalt keep thee from every evil thing. [^9] If there be among you any man, that is not clean by reason of that which chanceth him by night, then shall he go abroad out of the camp, he shall not come within the camp: [^10] but it shall be, when evening cometh on, he shall bathe himself in water; and when the sun is down, he shall come within the camp. [^11] Thou shalt have a place also without the camp, whither thou shalt go forth abroad: [^12] and thou shalt have a paddle among thy weapons; and it shall be, when thou sittest down abroad, thou shalt dig therewith, and shalt turn back and cover that which cometh from thee: [^13] for Jehovah thy God walketh in the midst of thy camp, to deliver thee, and to give up thine enemies before thee; therefore shall thy camp be holy, that he may not see an unclean thing in thee, and turn away from thee. [^14] Thou shalt not deliver unto his master a servant that is escaped from his master unto thee: [^15] he shall dwell with thee, in the midst of thee, in the place which he shall choose within one of thy gates, where it pleaseth him best: thou shalt not oppress him. [^16] There shall be no prostitute of the daughters of Israel, neither shall there be a sodomite of the sons of Israel. [^17] Thou shalt not bring the hire of a harlot, or the wages of a dog, into the house of Jehovah thy God for any vow: for even both these are an abomination unto Jehovah thy God. [^18] Thou shalt not lend upon interest to thy brother; interest of money, interest of victuals, interest of anything that is lent upon interest. [^19] Unto a foreigner thou mayest lend upon interest; but unto thy brother thou shalt not lend upon interest, that Jehovah thy God may bless thee in all that thou puttest thy hand unto, in the land whither thou goest in to possess it. [^20] When thou shalt vow a vow unto Jehovah thy God, thou shalt not be slack to pay it: for Jehovah thy God will surely require it of thee; and it would be sin in thee. [^21] But if thou shalt forbear to vow, it shall be no sin in thee. [^22] That which is gone out of thy lips thou shalt observe and do; according as thou hast vowed unto Jehovah thy God, a freewill-offering, which thou hast promised with thy mouth. [^23] When thou comest into thy neighbor’s vineyard, then thou mayest eat of grapes thy fill at thine own pleasure; but thou shalt not put any in thy vessel. [^24] When thou comest into thy neighbor’s standing grain, then thou mayest pluck the ears with thy hand; but thou shalt not move a sickle unto thy neighbor’s standing grain. [^25] 

[[Deuteronomy - 22|<--]] Deuteronomy - 23 [[Deuteronomy - 24|-->]]

---
# Notes
