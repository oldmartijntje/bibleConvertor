---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 26 - American Standard Version"
---
[[Deuteronomy - 25|<--]] Deuteronomy - 26 [[Deuteronomy - 27|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Deuteronomy]]

# Deuteronomy - 26

And it shall be, when thou art come in unto the land which Jehovah thy God giveth thee for an inheritance, and possessest it, and dwellest therein, [^1] that thou shalt take of the first of all the fruit of the ground, which thou shalt bring in from thy land that Jehovah thy God giveth thee; and thou shalt put it in a basket, and shalt go unto the place which Jehovah thy God shall choose, to cause his name to dwell there. [^2] And thou shalt come unto the priest that shall be in those days, and say unto him, I profess this day unto Jehovah thy God, that I am come unto the land which Jehovah sware unto our fathers to give us. [^3] And the priest shall take the basket out of thy hand, and set it down before the altar of Jehovah thy God. [^4] And thou shalt answer and say before Jehovah thy God, A Syrian ready to perish was my father; and he went down into Egypt, and sojourned there, few in number; and he became there a nation, great, mighty, and populous. [^5] And the Egyptians dealt ill with us, and afflicted us, and laid upon us hard bondage: [^6] and we cried unto Jehovah, the God of our fathers, and Jehovah heard our voice, and saw our affliction, and our toil, and our oppression; [^7] and Jehovah brought us forth out of Egypt with a mighty hand, and with an outstretched arm, and with great terribleness, and with signs, and with wonders; [^8] and he hath brought us into this place, and hath given us this land, a land flowing with milk and honey. [^9] And now, behold, I have brought the first of the fruit of the ground, which thou, O Jehovah, hast given me. And thou shalt set it down before Jehovah thy God, and worship before Jehovah thy God: [^10] and thou shalt rejoice in all the good which Jehovah thy God hath given unto thee, and unto thy house, thou, and the Levite, and the sojourner that is in the midst of thee. [^11] When thou hast made an end of tithing all the tithe of thine increase in the third year, which is the year of tithing, then thou shalt give it unto the Levite, to the sojourner, to the fatherless, and to the widow, that they may eat within thy gates, and be filled. [^12] And thou shalt say before Jehovah thy God, I have put away the hallowed things out of my house, and also have given them unto the Levite, and unto the sojourner, to the fatherless, and to the widow, according to all thy commandment which thou hast commanded me: I have not transgressed any of thy commandments, neither have I forgotten them: [^13] I have not eaten thereof in my mourning, neither have I put away thereof, being unclean, nor given thereof for the dead: I have hearkened to the voice of Jehovah my God; I have done according to all that thou hast commanded me. [^14] Look down from thy holy habitation, from heaven, and bless thy people Israel, and the ground which thou hast given us, as thou swarest unto our fathers, a land flowing with milk and honey. [^15] This day Jehovah thy God commandeth thee to do these statutes and ordinances: thou shalt therefore keep and do them with all thy heart, and with all thy soul. [^16] Thou hast avouched Jehovah this day to be thy God, and that thou wouldest walk in his ways, and keep his statutes, and his commandments, and his ordinances, and hearken unto his voice: [^17] and Jehovah hath avouched thee this day to be a people for his own possession, as he hath promised thee, and that thou shouldest keep all his commandments; [^18] and to make thee high above all nations that he hath made, in praise, and in name, and in honor; and that thou mayest be a holy people unto Jehovah thy God, as he hath spoken. [^19] 

[[Deuteronomy - 25|<--]] Deuteronomy - 26 [[Deuteronomy - 27|-->]]

---
# Notes
