---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 14 - American Standard Version"
---
[[Deuteronomy - 13|<--]] Deuteronomy - 14 [[Deuteronomy - 15|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Deuteronomy]]

# Deuteronomy - 14

Ye are the children of Jehovah your God: ye shall not cut yourselves, nor make any baldness between your eyes for the dead. [^1] For thou art a holy people unto Jehovah thy God, and Jehovah hath chosen thee to be a people for his own possession, above all peoples that are upon the face of the earth. [^2] Thou shalt not eat any abominable thing. [^3] These are the beasts which ye may eat: the ox, the sheep, and the goat, [^4] the hart, and the gazelle, and the roebuck, and the wild goat, and the pygarg, and the antelope, and the chamois. [^5] And every beast that parteth the hoof, and hath the hoof cloven in two, and cheweth the cud, among the beasts, that may ye eat. [^6] Nevertheless these ye shall not eat of them that chew the cud, or of them that have the hoof cloven: the camel, and the hare, and the coney; because they chew the cud but part not the hoof, they are unclean unto you. [^7] And the swine, because he parteth the hoof but cheweth not the cud, he is unclean unto you: of their flesh ye shall not eat, and their carcasses ye shall not touch. [^8] These ye may eat of all that are in the waters: whatsoever hath fins and scales may ye eat; [^9] and whatsoever hath not fins and scales ye shall not eat; it is unclean unto you. [^10] Of all clean birds ye may eat. [^11] But these are they of which ye shall not eat: the eagle, and the gier-eagle, and the ospray, [^12] and the glede, and the falcon, and the kite after its kind, [^13] and every raven after its kind, [^14] and the ostrich, and the night-hawk, and the sea-mew, and the hawk after its kind, [^15] the little owl, and the great owl, and the horned owl, [^16] and the pelican, and the vulture, and the cormorant, [^17] and the stork, and the heron after its kind, and the hoopoe, and the bat. [^18] And all winged creeping things are unclean unto you: they shall not be eaten. [^19] Of all clean birds ye may eat. [^20] Ye shall not eat of anything that dieth of itself: thou mayest give it unto the sojourner that is within thy gates, that he may eat it; or thou mayest sell it unto a foreigner: for thou art a holy people unto Jehovah thy God. Thou shalt not boil a kid in its mother’s milk. [^21] Thou shalt surely tithe all the increase of thy seed, that which cometh forth from the field year by year. [^22] And thou shalt eat before Jehovah thy God, in the place which he shall choose, to cause his name to dwell there, the tithe of thy grain, of thy new wine, and of thine oil, and the firstlings of thy herd and of thy flock; that thou mayest learn to fear Jehovah thy God always. [^23] And if the way be too long for thee, so that thou art not able to carry it, because the place is too far from thee, which Jehovah thy God shall choose, to set his name there, when Jehovah thy God shall bless thee; [^24] then shalt thou turn it into money, and bind up the money in thy hand, and shalt go unto the place which Jehovah thy God shall choose: [^25] and thou shalt bestow the money for whatsoever thy soul desireth, for oxen, or for sheep, or for wine, or for strong drink, or for whatsoever thy soul asketh of thee; and thou shalt eat there before Jehovah thy God, and thou shalt rejoice, thou and thy household. [^26] And the Levite that is within thy gates, thou shalt not forsake him; for he hath no portion nor inheritance with thee. [^27] At the end of every three years thou shalt bring forth all the tithe of thine increase in the same year, and shalt lay it up within thy gates: [^28] and the Levite, because he hath no portion nor inheritance with thee, and the sojourner, and the fatherless, and the widow, that are within thy gates, shall come, and shall eat and be satisfied; that Jehovah thy God may bless thee in all the work of thy hand which thou doest. [^29] 

[[Deuteronomy - 13|<--]] Deuteronomy - 14 [[Deuteronomy - 15|-->]]

---
# Notes
