---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 25 - American Standard Version"
---
[[Deuteronomy - 24|<--]] Deuteronomy - 25 [[Deuteronomy - 26|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Deuteronomy]]

# Deuteronomy - 25

If there be a controversy between men, and they come unto judgment, and the judges judge them; then they shall justify the righteous, and condemn the wicked. [^1] And it shall be, if the wicked man be worthy to be beaten, that the judge shall cause him to lie down, and to be beaten before his face, according to his wickedness, by number. [^2] Forty stripes he may give him, he shall not exceed; lest, if he should exceed, and beat him above these with many stripes, then thy brother should seem vile unto thee. [^3] Thou shalt not muzzle the ox when he treadeth out the grain. [^4] If brethren dwell together, and one of them die, and have no son, the wife of the dead shall not be married without unto a stranger: her husband’s brother shall go in unto her, and take her to him to wife, and perform the duty of a husband’s brother unto her. [^5] And it shall be, that the first-born that she beareth shall succeed in the name of his brother that is dead, that his name be not blotted out of Israel. [^6] And if the man like not to take his brother’s wife, then his brother’s wife shall go up to the gate unto the elders, and say, My husband’s brother refuseth to raise up unto his brother a name in Israel; he will not perform the duty of a husband’s brother unto me. [^7] Then the elders of his city shall call him, and speak unto him: and if he stand, and say, I like not to take her; [^8] then shall his brother’s wife come unto him in the presence of the elders, and loose his shoe from off his foot, and spit in his face; and she shall answer and say, So shall it be done unto the man that doth not build up his brother’s house. [^9] And his name shall be called in Israel, The house of him that hath his shoe loosed. [^10] When men strive together one with another, and the wife of the one draweth near to deliver her husband out of the hand of him that smiteth him, and putteth forth her hand, and taketh him by the secrets; [^11] then thou shalt cut off her hand, thine eye shall have no pity. [^12] Thou shalt not have in thy bag diverse weights, a great and a small. [^13] Thou shalt not have in thy house diverse measures, a great and a small. [^14] A perfect and just weight shalt thou have; a perfect and just measure shalt thou have: that thy days may be long in the land which Jehovah thy God giveth thee. [^15] For all that do such things, even all that do unrighteously, are an abomination unto Jehovah thy God. [^16] Remember what Amalek did unto thee by the way as ye came forth out of Egypt; [^17] how he met thee by the way, and smote the hindmost of thee, all that were feeble behind thee, when thou wast faint and weary; and he feared not God. [^18] Therefore it shall be, when Jehovah thy God hath given thee rest from all thine enemies round about, in the land which Jehovah thy God giveth thee for an inheritance to possess it, that thou shalt blot out the remembrance of Amalek from under heaven; thou shalt not forget. [^19] 

[[Deuteronomy - 24|<--]] Deuteronomy - 25 [[Deuteronomy - 26|-->]]

---
# Notes
