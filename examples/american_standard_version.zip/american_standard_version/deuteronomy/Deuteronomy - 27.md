---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 27 - American Standard Version"
---
[[Deuteronomy - 26|<--]] Deuteronomy - 27 [[Deuteronomy - 28|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Deuteronomy]]

# Deuteronomy - 27

And Moses and the elders of Israel commanded the people, saying, Keep all the commandment which I command you this day. [^1] And it shall be on the day when ye shall pass over the Jordan unto the land which Jehovah thy God giveth thee, that thou shalt set thee up great stones, and plaster them with plaster: [^2] and thou shalt write upon them all the words of this law, when thou art passed over; that thou mayest go in unto the land which Jehovah thy God giveth thee, a land flowing with milk and honey, as Jehovah, the God of thy fathers, hath promised thee. [^3] And it shall be, when ye are passed over the Jordan, that ye shall set up these stones, which I command you this day, in mount Ebal, and thou shalt plaster them with plaster. [^4] And there shalt thou build an altar unto Jehovah thy God, an altar of stones: thou shalt lift up no iron tool upon them. [^5] Thou shalt build the altar of Jehovah thy God of unhewn stones; and thou shalt offer burnt-offerings thereon unto Jehovah thy God: [^6] and thou shalt sacrifice peace-offerings, and shalt eat there; and thou shalt rejoice before Jehovah thy God. [^7] And thou shalt write upon the stones all the words of this law very plainly. [^8] And Moses and the priests the Levites spake unto all Israel, saying, Keep silence, and hearken, O Israel: This day thou art become the people of Jehovah thy God. [^9] Thou shalt therefore obey the voice of Jehovah thy God, and do his commandments and his statutes, which I command thee this day. [^10] And Moses charged the people the same day, saying, [^11] These shall stand upon mount Gerizim to bless the people, when ye are passed over the Jordan: Simeon, and Levi, and Judah, and Issachar, and Joseph, and Benjamin. [^12] And these shall stand upon mount Ebal for the curse: Reuben, Gad, and Asher, and Zebulun, Dan, and Naphtali. [^13] And the Levites shall answer, and say unto all the men of Israel with a loud voice, [^14] Cursed be the man that maketh a graven or molten image, an abomination unto Jehovah, the work of the hands of the craftsman, and setteth it up in secret. And all the people shall answer and say, Amen. [^15] Cursed be he that setteth light by his father or his mother. And all the people shall say, Amen. [^16] Cursed be he that removeth his neighbor’s landmark. And all the people shall say, Amen. [^17] Cursed be he that maketh the blind to wander out of the way. And all the people shall say, Amen. [^18] Cursed be he that wresteth the justice due to the sojourner, fatherless, and widow. And all the people shall say, Amen. [^19] Cursed be he that lieth with his father’s wife, because he hath uncovered his father’s skirt. And all the people shall say, Amen. [^20] Cursed be he that lieth with any manner of beast. And all the people shall say, Amen. [^21] Cursed be he that lieth with his sister, the daughter of his father, or the daughter of his mother. And all the people shall say, Amen. [^22] Cursed be he that lieth with his mother-in-law. And all the people shall say, Amen. [^23] Cursed be he that smiteth his neighbor in secret. And all the people shall say, Amen. [^24] Cursed be he that taketh a bribe to slay an innocent person. And all the people shall say, Amen. [^25] Cursed be he that confirmeth not the words of this law to do them. And all the people shall say, Amen. [^26] 

[[Deuteronomy - 26|<--]] Deuteronomy - 27 [[Deuteronomy - 28|-->]]

---
# Notes
