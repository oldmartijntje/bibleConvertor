---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 30 - American Standard Version"
---
[[Deuteronomy - 29|<--]] Deuteronomy - 30 [[Deuteronomy - 31|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Deuteronomy]]

# Deuteronomy - 30

And it shall come to pass, when all these things are come upon thee, the blessing and the curse, which I have set before thee, and thou shalt call them to mind among all the nations, whither Jehovah thy God hath driven thee, [^1] and shalt return unto Jehovah thy God, and shalt obey his voice according to all that I command thee this day, thou and thy children, with all thy heart, and with all thy soul; [^2] that then Jehovah thy God will turn thy captivity, and have compassion upon thee, and will return and gather thee from all the peoples, whither Jehovah thy God hath scattered thee. [^3] If any of thine outcasts be in the uttermost parts of heaven, from thence will Jehovah thy God gather thee, and from thence will he fetch thee: [^4] and Jehovah thy God will bring thee into the land which thy fathers possessed, and thou shalt possess it; and he will do thee good, and multiply thee above thy fathers. [^5] And Jehovah thy God will circumcise thy heart, and the heart of thy seed, to love Jehovah thy God with all thy heart, and with all thy soul, that thou mayest live. [^6] And Jehovah thy God will put all these curses upon thine enemies, and on them that hate thee, that persecuted thee. [^7] And thou shalt return and obey the voice of Jehovah, and do all his commandments which I command thee this day. [^8] And Jehovah thy God will make thee plenteous in all the work of thy hand, in the fruit of thy body, and in the fruit of thy cattle, and in the fruit of thy ground, for good: for Jehovah will again rejoice over thee for good, as he rejoiced over thy fathers; [^9] if thou shalt obey the voice of Jehovah thy God, to keep his commandments and his statutes which are written in this book of the law; if thou turn unto Jehovah thy God with all thy heart, and with all thy soul. [^10] For this commandment which I command thee this day, it is not too hard for thee, neither is it far off. [^11] It is not in heaven, that thou shouldest say, Who shall go up for us to heaven, and bring it unto us, and make us to hear it, that we may do it? [^12] Neither is it beyond the sea, that thou shouldest say, Who shall go over the sea for us, and bring it unto us, and make us to hear it, that we may do it? [^13] But the word is very nigh unto thee, in thy mouth, and in thy heart, that thou mayest do it. [^14] See, I have set before thee this day life and good, and death and evil; [^15] in that I command thee this day to love Jehovah thy God, to walk in his ways, and to keep his commandments and his statutes and his ordinances, that thou mayest live and multiply, and that Jehovah thy God may bless thee in the land whither thou goest in to possess it. [^16] But if thy heart turn away, and thou wilt not hear, but shalt be drawn away, and worship other gods, and serve them; [^17] I denounce unto you this day, that ye shall surely perish; ye shall not prolong your days in the land, whither thou passest over the Jordan to go in to possess it. [^18] I call heaven and earth to witness against you this day, that I have set before thee life and death, the blessing and the curse: therefore choose life, that thou mayest live, thou and thy seed; [^19] to love Jehovah thy God, to obey his voice, and to cleave unto him; for he is thy life, and the length of thy days; that thou mayest dwell in the land which Jehovah sware unto thy fathers, to Abraham, to Isaac, and to Jacob, to give them. [^20] 

[[Deuteronomy - 29|<--]] Deuteronomy - 30 [[Deuteronomy - 31|-->]]

---
# Notes
