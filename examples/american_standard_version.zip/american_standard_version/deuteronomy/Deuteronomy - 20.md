---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 20 - American Standard Version"
---
[[Deuteronomy - 19|<--]] Deuteronomy - 20 [[Deuteronomy - 21|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Deuteronomy]]

# Deuteronomy - 20

When thou goest forth to battle against thine enemies, and seest horses, and chariots, and a people more than thou, thou shalt not be afraid of them; for Jehovah thy God is with thee, who brought thee up out of the land of Egypt. [^1] And it shall be, when ye draw nigh unto the battle, that the priest shall approach and speak unto the people, [^2] and shall say unto them, Hear, O Israel, ye draw nigh this day unto battle against your enemies: let not your heart faint; fear not, nor tremble, neither be ye affrighted at them; [^3] for Jehovah your God is he that goeth with you, to fight for you against your enemies, to save you. [^4] And the officers shall speak unto the people, saying, What man is there that hath built a new house, and hath not dedicated it? let him go and return to his house, lest he die in the battle, and another man dedicate it. [^5] And what man is there that hath planted a vineyard, and hath not used the fruit thereof? let him go and return unto his house, lest he die in the battle, and another man use the fruit thereof. [^6] And what man is there that hath betrothed a wife, and hath not taken her? let him go and return unto his house, lest he die in the battle, and another man take her. [^7] And the officers shall speak further unto the people, and they shall say, What man is there that is fearful and faint-hearted? let him go and return unto his house, lest his brethren’s heart melt as his heart. [^8] And it shall be, when the officers have made an end of speaking unto the people, that they shall appoint captains of hosts at the head of the people. [^9] When thou drawest nigh unto a city to fight against it, then proclaim peace unto it. [^10] And it shall be, if it make thee answer of peace, and open unto thee, then it shall be, that all the people that are found therein shall become tributary unto thee, and shall serve thee. [^11] And if it will make no peace with thee, but will make war against thee, then thou shalt besiege it: [^12] and when Jehovah thy God delivereth it into thy hand, thou shalt smite every male thereof with the edge of the sword: [^13] but the women, and the little ones, and the cattle, and all that is in the city, even all the spoil thereof, shalt thou take for a prey unto thyself; and thou shalt eat the spoil of thine enemies, which Jehovah thy God hath given thee. [^14] Thus shalt thou do unto all the cities which are very far off from thee, which are not of the cities of these nations. [^15] But of the cities of these peoples, that Jehovah thy God giveth thee for an inheritance, thou shalt save alive nothing that breatheth; [^16] but thou shalt utterly destroy them: the Hittite, and the Amorite, the Canaanite, and the Perizzite, the Hivite, and the Jebusite; as Jehovah thy God hath commanded thee; [^17] that they teach you not to do after all their abominations, which they have done unto their gods; so would ye sin against Jehovah your God. [^18] When thou shalt besiege a city a long time, in making war against it to take it, thou shalt not destroy the trees thereof by wielding an axe against them; for thou mayest eat of them, and thou shalt not cut them down; for is the tree of the field man, that it should be besieged of thee? [^19] Only the trees of which thou knowest that they are not trees for food, thou shalt destroy and cut them down; and thou shalt build bulwarks against the city that maketh war with thee, until it fall. [^20] 

[[Deuteronomy - 19|<--]] Deuteronomy - 20 [[Deuteronomy - 21|-->]]

---
# Notes
