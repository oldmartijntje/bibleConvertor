---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 34 - American Standard Version"
---
[[Deuteronomy - 33|<--]] Deuteronomy - 34

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Deuteronomy]]

# Deuteronomy - 34

And Moses went up from the plains of Moab unto mount Nebo, to the top of Pisgah, that is over against Jericho. And Jehovah showed him all the land of Gilead, unto Dan, [^1] and all Naphtali, and the land of Ephraim and Manasseh, and all the land of Judah, unto the hinder sea, [^2] and the South, and the Plain of the valley of Jericho the city of palm-trees, unto Zoar. [^3] And Jehovah said unto him, This is the land which I sware unto Abraham, unto Isaac, and unto Jacob, saying, I will give it unto thy seed: I have caused thee to see it with thine eyes, but thou shalt not go over thither. [^4] So Moses the servant of Jehovah died there in the land of Moab, according to the word of Jehovah. [^5] And he buried him in the valley in the land of Moab over against Beth-peor: but no man knoweth of his sepulchre unto this day. [^6] And Moses was a hundred and twenty years old when he died: his eye was not dim, nor his natural force abated. [^7] And the children of Israel wept for Moses in the plains of Moab thirty days: so the days of weeping in the mourning for Moses were ended. [^8] And Joshua the son of Nun was full of the spirit of wisdom; for Moses had laid his hands upon him: and the children of Israel hearkened unto him, and did as Jehovah commanded Moses. [^9] And there hath not arisen a prophet since in Israel like unto Moses, whom Jehovah knew face to face, [^10] in all the signs and the wonders, which Jehovah sent him to do in the land of Egypt, to Pharaoh, and to all his servants, and to all his land, [^11] and in all the mighty hand, and in all the great terror, which Moses wrought in the sight of all Israel. [^12] 

[[Deuteronomy - 33|<--]] Deuteronomy - 34

---
# Notes
