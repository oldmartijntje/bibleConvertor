---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 6 - American Standard Version"
---
[[Deuteronomy - 5|<--]] Deuteronomy - 6 [[Deuteronomy - 7|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Deuteronomy]]

# Deuteronomy - 6

Now this is the commandment, the statutes, and the ordinances, which Jehovah your God commanded to teach you, that ye might do them in the land whither ye go over to possess it; [^1] that thou mightest fear Jehovah thy God, to keep all his statutes and his commandments, which I command thee, thou, and thy son, and thy son’s son, all the days of thy life; and that thy days may be prolonged. [^2] Hear therefore, O Israel, and observe to do it; that it may be well with thee, and that ye may increase mightily, as Jehovah, the God of thy fathers, hath promised unto thee, in a land flowing with milk and honey. [^3] Hear, O Israel: Jehovah our God is one Jehovah: [^4] and thou shalt love Jehovah thy God with all thy heart, and with all thy soul, and with all thy might. [^5] And these words, which I command thee this day, shall be upon thy heart; [^6] and thou shalt teach them diligently unto thy children, and shalt talk of them when thou sittest in thy house, and when thou walkest by the way, and when thou liest down, and when thou risest up. [^7] And thou shalt bind them for a sign upon thy hand, and they shall be for frontlets between thine eyes. [^8] And thou shalt write them upon the door-posts of thy house, and upon thy gates. [^9] And it shall be, when Jehovah thy God shall bring thee into the land which he sware unto thy fathers, to Abraham, to Isaac, and to Jacob, to give thee, great and goodly cities, which thou buildest not, [^10] and houses full of all good things, which thou filledst not, and cisterns hewn out, which thou hewedst not, vineyards and olive-trees, which thou plantedst not, and thou shalt eat and be full; [^11] then beware lest thou forget Jehovah, who brought thee forth out of the land of Egypt, out of the house of bondage. [^12] Thou shalt fear Jehovah thy God; and him shalt thou serve, and shalt swear by his name. [^13] Ye shall not go after other gods, of the gods of the peoples that are round about you; [^14] for Jehovah thy God in the midst of thee is a jealous God; lest the anger of Jehovah thy God be kindled against thee, and he destroy thee from off the face of the earth. [^15] Ye shall not tempt Jehovah your God, as ye tempted him in Massah. [^16] Ye shall diligently keep the commandments of Jehovah your God, and his testimonies, and his statutes, which he hath commanded thee. [^17] And thou shalt do that which is right and good in the sight of Jehovah; that it may be well with thee, and that thou mayest go in and possess the good land which Jehovah sware unto thy fathers, [^18] to thrust out all thine enemies from before thee, as Jehovah hath spoken. [^19] When thy son asketh thee in time to come, saying, What mean the testimonies, and the statutes, and the ordinances, which Jehovah our God hath commanded you? [^20] then thou shalt say unto thy son, We were Pharaoh’s bondmen in Egypt: and Jehovah brought us out of Egypt with a mighty hand; [^21] and Jehovah showed signs and wonders, great and sore, upon Egypt, upon Pharaoh, and upon all his house, before our eyes; [^22] and he brought us out from thence, that he might bring us in, to give us the land which he sware unto our fathers. [^23] And Jehovah commanded us to do all these statutes, to fear Jehovah our God, for our good always, that he might preserve us alive, as at this day. [^24] And it shall be righteousness unto us, if we observe to do all this commandment before Jehovah our God, as he hath commanded us. [^25] 

[[Deuteronomy - 5|<--]] Deuteronomy - 6 [[Deuteronomy - 7|-->]]

---
# Notes
