---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 8 - American Standard Version"
---
[[Deuteronomy - 7|<--]] Deuteronomy - 8 [[Deuteronomy - 9|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Deuteronomy]]

# Deuteronomy - 8

All the commandment which I command thee this day shall ye observe to do, that ye may live, and multiply, and go in and possess the land which Jehovah sware unto your fathers. [^1] And thou shalt remember all the way which Jehovah thy God hath led thee these forty years in the wilderness, that he might humble thee, to prove thee, to know what was in thy heart, whether thou wouldest keep his commandments, or not. [^2] And he humbled thee, and suffered thee to hunger, and fed thee with manna, which thou knewest not, neither did thy fathers know; that he might make thee know that man doth not live by bread only, but by everything that proceedeth out of the mouth of Jehovah doth man live. [^3] Thy raiment waxed not old upon thee, neither did thy foot swell, these forty years. [^4] And thou shalt consider in thy heart, that, as a man chasteneth his son, so Jehovah thy God chasteneth thee. [^5] And thou shalt keep the commandments of Jehovah thy God, to walk in his ways, and to fear him. [^6] For Jehovah thy God bringeth thee into a good land, a land of brooks of water, of fountains and springs, flowing forth in valleys and hills; [^7] a land of wheat and barley, and vines and fig-trees and pomegranates; a land of olive-trees and honey; [^8] a land wherein thou shalt eat bread without scarceness, thou shalt not lack anything in it; a land whose stones are iron, and out of whose hills thou mayest dig copper. [^9] And thou shalt eat and be full, and thou shalt bless Jehovah thy God for the good land which he hath given thee. [^10] Beware lest thou forget Jehovah thy God, in not keeping his commandments, and his ordinances, and his statutes, which I command thee this day: [^11] lest, when thou hast eaten and art full, and hast built goodly houses, and dwelt therein; [^12] and when thy herds and thy flocks multiply, and thy silver and thy gold is multiplied, and all that thou hast is multiplied; [^13] then thy heart be lifted up, and thou forget Jehovah thy God, who brought thee forth out of the land of Egypt, out of the house of bondage; [^14] who led thee through the great and terrible wilderness, wherein were fiery serpents and scorpions, and thirsty ground where was no water; who brought thee forth water out of the rock of flint; [^15] who fed thee in the wilderness with manna, which thy fathers knew not; that he might humble thee, and that he might prove thee, to do thee good at thy latter end: [^16] and lest thou say in thy heart, My power and the might of my hand hath gotten me this wealth. [^17] But thou shalt remember Jehovah thy God, for it is he that giveth thee power to get wealth; that he may establish his covenant which he sware unto thy fathers, as at this day. [^18] And it shall be, if thou shalt forget Jehovah thy God, and walk after other gods, and serve them, and worship them, I testify against you this day that ye shall surely perish. [^19] As the nations that Jehovah maketh to perish before you, so shall ye perish; because ye would not hearken unto the voice of Jehovah your God. [^20] 

[[Deuteronomy - 7|<--]] Deuteronomy - 8 [[Deuteronomy - 9|-->]]

---
# Notes
