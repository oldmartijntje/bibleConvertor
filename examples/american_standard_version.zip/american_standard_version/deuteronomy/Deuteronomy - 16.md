---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 16 - American Standard Version"
---
[[Deuteronomy - 15|<--]] Deuteronomy - 16 [[Deuteronomy - 17|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Deuteronomy]]

# Deuteronomy - 16

Observe the month of Abib, and keep the passover unto Jehovah thy God; for in the month of Abib Jehovah thy God brought thee forth out of Egypt by night. [^1] And thou shalt sacrifice the passover unto Jehovah thy God, of the flock and the herd, in the place which Jehovah shall choose, to cause his name to dwell there. [^2] Thou shalt eat no leavened bread with it; seven days shalt thou eat unleavened bread therewith, even the bread of affliction; for thou camest forth out of the land of Egypt in haste: that thou mayest remember the day when thou camest forth out of the land of Egypt all the days of thy life. [^3] And there shall be no leaven seen with thee in all thy borders seven days; neither shall any of the flesh, which thou sacrificest the first day at even, remain all night until the morning. [^4] Thou mayest not sacrifice the passover within any of thy gates, which Jehovah thy God giveth thee; [^5] but at the place which Jehovah thy God shall choose, to cause his name to dwell in, there thou shalt sacrifice the passover at even, at the going down of the sun, at the season that thou camest forth out of Egypt. [^6] And thou shalt roast and eat it in the place which Jehovah thy God shall choose: and thou shalt turn in the morning, and go unto thy tents. [^7] Six days thou shalt eat unleavened bread; and on the seventh day shall be a solemn assembly to Jehovah thy God; thou shalt do no work therein. [^8] Seven weeks shalt thou number unto thee: from the time thou beginnest to put the sickle to the standing grain shalt thou begin to number seven weeks. [^9] And thou shalt keep the feast of weeks unto Jehovah thy God with a tribute of a freewill-offering of thy hand, which thou shalt give, according as Jehovah thy God blesseth thee: [^10] and thou shalt rejoice before Jehovah thy God, thou, and thy son, and thy daughter, and thy man-servant, and thy maid-servant, and the Levite that is within thy gates, and the sojourner, and the fatherless, and the widow, that are in the midst of thee, in the place which Jehovah thy God shall choose, to cause his name to dwell there. [^11] And thou shalt remember that thou wast a bondman in Egypt: and thou shalt observe and do these statutes. [^12] Thou shalt keep the feast of tabernacles seven days, after that thou hast gathered in from thy threshing-floor and from thy winepress: [^13] and thou shalt rejoice in thy feast, thou, and thy son, and thy daughter, and thy man-servant, and thy maid-servant, and the Levite, and the sojourner, and the fatherless, and the widow, that are within thy gates. [^14] Seven days shalt thou keep a feast unto Jehovah thy God in the place which Jehovah shall choose; because Jehovah thy God will bless thee in all thine increase, and in all the work of thy hands, and thou shalt be altogether joyful. [^15] Three times in a year shall all thy males appear before Jehovah thy God in the place which he shall choose: in the feast of unleavened bread, and in the feast of weeks, and in the feast of tabernacles; and they shall not appear before Jehovah empty: [^16] every man shall give as he is able, according to the blessing of Jehovah thy God which he hath given thee. [^17] Judges and officers shalt thou make thee in all thy gates, which Jehovah thy God giveth thee, according to thy tribes; and they shall judge the people with righteous judgment. [^18] Thou shalt not wrest justice: thou shalt not respect persons; neither shalt thou take a bribe; for a bribe doth blind the eyes of the wise, and pervert the words of the righteous. [^19] That which is altogether just shalt thou follow, that thou mayest live, and inherit the land which Jehovah thy God giveth thee. [^20] Thou shalt not plant thee an Asherah of any kind of tree beside the altar of Jehovah thy God, which thou shalt make thee. [^21] Neither shalt thou set thee up a pillar; which Jehovah thy God hateth. [^22] 

[[Deuteronomy - 15|<--]] Deuteronomy - 16 [[Deuteronomy - 17|-->]]

---
# Notes
