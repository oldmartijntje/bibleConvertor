---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 10 - American Standard Version"
---
[[Deuteronomy - 9|<--]] Deuteronomy - 10 [[Deuteronomy - 11|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Deuteronomy]]

# Deuteronomy - 10

At that time Jehovah said unto me, Hew thee two tables of stone like unto the first, and come up unto me into the mount, and make thee an ark of wood. [^1] And I will write on the tables the words that were on the first tables which thou brakest, and thou shalt put them in the ark. [^2] So I made an ark of acacia wood, and hewed two tables of stone like unto the first, and went up into the mount, having the two tables in my hand. [^3] And he wrote on the tables, according to the first writing, the ten commandments, which Jehovah spake unto you in the mount out of the midst of the fire in the day of the assembly: and Jehovah gave them unto me. [^4] And I turned and came down from the mount, and put the tables in the ark which I had made; and there they are as Jehovah commanded me. [^5] (And the children of Israel journeyed from Beeroth Bene-jaakan to Moserah. There Aaron died, and there he was buried; and Eleazar his son ministered in the priest’s office in his stead. [^6] From thence they journeyed unto Gudgodah; and from Gudgodah to Jotbathah, a land of brooks of water. [^7] At that time Jehovah set apart the tribe of Levi, to bear the ark of the covenant of Jehovah, to stand before Jehovah to minister unto him, and to bless in his name, unto this day. [^8] Wherefore Levi hath no portion nor inheritance with his brethren; Jehovah is his inheritance, according as Jehovah thy God spake unto him.) [^9] And I stayed in the mount, as at the first time, forty days and forty nights: and Jehovah hearkened unto me that time also; Jehovah would not destroy thee. [^10] And Jehovah said unto me, Arise, take thy journey before the people; and they shall go in and possess the land, which I sware unto their fathers to give unto them. [^11] And now, Israel, what doth Jehovah thy God require of thee, but to fear Jehovah thy God, to walk in all his ways, and to love him, and to serve Jehovah thy God with all thy heart and with all thy soul, [^12] to keep the commandments of Jehovah, and his statutes, which I command thee this day for thy good? [^13] Behold, unto Jehovah thy God belongeth heaven and the heaven of heavens, the earth, with all that is therein. [^14] Only Jehovah had a delight in thy fathers to love them, and he chose their seed after them, even you above all peoples, as at this day. [^15] Circumcise therefore the foreskin of your heart, and be no more stiffnecked. [^16] For Jehovah your God, he is God of gods, and Lord of lords, the great God, the mighty, and the terrible, who regardeth not persons, nor taketh reward. [^17] He doth execute justice for the fatherless and widow, and loveth the sojourner, in giving him food and raiment. [^18] Love ye therefore the sojourner; for ye were sojourners in the land of Egypt. [^19] Thou shalt fear Jehovah thy God; him shalt thou serve; and to him shalt thou cleave, and by his name shalt thou swear. [^20] He is thy praise, and he is thy God, that hath done for thee these great and terrible things, which thine eyes have seen. [^21] Thy fathers went down into Egypt with threescore and ten persons; and now Jehovah thy God hath made thee as the stars of heaven for multitude. [^22] 

[[Deuteronomy - 9|<--]] Deuteronomy - 10 [[Deuteronomy - 11|-->]]

---
# Notes
