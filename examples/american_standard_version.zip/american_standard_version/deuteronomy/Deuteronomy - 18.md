---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 18 - American Standard Version"
---
[[Deuteronomy - 17|<--]] Deuteronomy - 18 [[Deuteronomy - 19|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Deuteronomy]]

# Deuteronomy - 18

The priests the Levites, even all the tribe of Levi, shall have no portion nor inheritance with Israel: they shall eat the offerings of Jehovah made by fire, and his inheritance. [^1] And they shall have no inheritance among their brethren: Jehovah is their inheritance, as he hath spoken unto them. [^2] And this shall be the priests’ due from the people, from them that offer a sacrifice, whether it be ox or sheep, that they shall give unto the priest the shoulder, and the two cheeks, and the maw. [^3] The first-fruits of thy grain, of thy new wine, and of thine oil, and the first of the fleece of thy sheep, shalt thou give him. [^4] For Jehovah thy God hath chosen him out of all thy tribes, to stand to minister in the name of Jehovah, him and his sons for ever. [^5] And if a Levite come from any of thy gates out of all Israel, where he sojourneth, and come with all the desire of his soul unto the place which Jehovah shall choose; [^6] then he shall minister in the name of Jehovah his God, as all his brethren the Levites do, who stand there before Jehovah. [^7] They shall have like portions to eat, besides that which cometh of the sale of his patrimony. [^8] When thou art come into the land which Jehovah thy God giveth thee, thou shalt not learn to do after the abominations of those nations. [^9] There shall not be found with thee any one that maketh his son or his daughter to pass through the fire, one that useth divination, one that practiseth augury, or an enchanter, or a sorcerer, [^10] or a charmer, or a consulter with a familiar spirit, or a wizard, or a necromancer. [^11] For whosoever doeth these things is an abomination unto Jehovah: and because of these abominations Jehovah thy God doth drive them out from before thee. [^12] Thou shalt be perfect with Jehovah thy God. [^13] For these nations, that thou shalt dispossess, hearken unto them that practise augury, and unto diviners; but as for thee, Jehovah thy God hath not suffered thee so to do. [^14] Jehovah thy God will raise up unto thee a prophet from the midst of thee, of thy brethren, like unto me; unto him ye shall hearken; [^15] according to all that thou desiredst of Jehovah thy God in Horeb in the day of the assembly, saying, Let me not hear again the voice of Jehovah my God, neither let me see this great fire any more, that I die not. [^16] And Jehovah said unto me, They have well said that which they have spoken. [^17] I will raise them up a prophet from among their brethren, like unto thee; and I will put my words in his mouth, and he shall speak unto them all that I shall command him. [^18] And it shall come to pass, that whosoever will not hearken unto my words which he shall speak in my name, I will require it of him. [^19] But the prophet, that shall speak a word presumptuously in my name, which I have not commanded him to speak, or that shall speak in the name of other gods, that same prophet shall die. [^20] And if thou say in thy heart, How shall we know the word which Jehovah hath not spoken? [^21] when a prophet speaketh in the name of Jehovah, if the thing follow not, nor come to pass, that is the thing which Jehovah hath not spoken: the prophet hath spoken it presumptuously, thou shalt not be afraid of him. [^22] 

[[Deuteronomy - 17|<--]] Deuteronomy - 18 [[Deuteronomy - 19|-->]]

---
# Notes
