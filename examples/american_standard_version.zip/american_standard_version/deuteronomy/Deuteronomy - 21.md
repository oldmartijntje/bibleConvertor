---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 21 - American Standard Version"
---
[[Deuteronomy - 20|<--]] Deuteronomy - 21 [[Deuteronomy - 22|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Deuteronomy]]

# Deuteronomy - 21

If one be found slain in the land which Jehovah thy God giveth thee to possess it, lying in the field, and it be not known who hath smitten him; [^1] then thy elders and thy judges shall come forth, and they shall measure unto the cities which are round about him that is slain: [^2] and it shall be, that the city which is nearest unto the slain man, even the elders of that city shall take a heifer of the herd, which hath not been wrought with, and which hath not drawn in the yoke; [^3] and the elders of that city shall bring down the heifer unto a valley with running water, which is neither plowed nor sown, and shall break the heifer’s neck there in the valley. [^4] And the priests the sons of Levi shall come near; for them Jehovah thy God hath chosen to minister unto him, and to bless in the name of Jehovah; and according to their word shall every controversy and every stroke be. [^5] And all the elders of that city, who are nearest unto the slain man, shall wash their hands over the heifer whose neck was broken in the valley; [^6] and they shall answer and say, Our hands have not shed this blood, neither have our eyes seen it. [^7] Forgive, O Jehovah, thy people Israel, whom thou hast redeemed, and suffer not innocent blood to remain in the midst of thy people Israel. And the blood shall be forgiven them. [^8] So shalt thou put away the innocent blood from the midst of thee, when thou shalt do that which is right in the eyes of Jehovah. [^9] When thou goest forth to battle against thine enemies, and Jehovah thy God delivereth them into thy hands, and thou carriest them away captive, [^10] and seest among the captives a beautiful woman, and thou hast a desire unto her, and wouldest take her to thee to wife; [^11] then thou shalt bring her home to thy house; and she shall shave her head, and pare her nails; [^12] and she shall put the raiment of her captivity from off her, and shall remain in thy house, and bewail her father and her mother a full month: and after that thou shalt go in unto her, and be her husband, and she shall be thy wife. [^13] And it shall be, if thou have no delight in her, then thou shalt let her go whither she will; but thou shalt not sell her at all for money, thou shalt not deal with her as a slave, because thou hast humbled her. [^14] If a man have two wives, the one beloved, and the other hated, and they have borne him children, both the beloved and the hated; and if the first-born son be hers that was hated; [^15] then it shall be, in the day that he causeth his sons to inherit that which he hath, that he may not make the son of the beloved the first-born before the son of the hated, who is the first-born: [^16] but he shall acknowledge the first-born, the son of the hated, by giving him a double portion of all that he hath; for he is the beginning of his strength; the right of the first-born is his. [^17] If a man have a stubborn and rebellious son, that will not obey the voice of his father, or the voice of his mother, and, though they chasten him, will not hearken unto them; [^18] then shall his father and his mother lay hold on him, and bring him out unto the elders of his city, and unto the gate of his place; [^19] and they shall say unto the elders of his city, This our son is stubborn and rebellious, he will not obey our voice; he is a glutton, and a drunkard. [^20] And all the men of his city shall stone him to death with stones: so shalt thou put away the evil from the midst of thee; and all Israel shall hear, and fear. [^21] And if a man have committed a sin worthy of death, and he be put to death, and thou hang him on a tree; [^22] his body shall not remain all night upon the tree, but thou shalt surely bury him the same day; for he that is hanged is accursed of God; that thou defile not thy land which Jehovah thy God giveth thee for an inheritance. [^23] 

[[Deuteronomy - 20|<--]] Deuteronomy - 21 [[Deuteronomy - 22|-->]]

---
# Notes
