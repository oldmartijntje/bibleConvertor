---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 13 - American Standard Version"
---
[[Deuteronomy - 12|<--]] Deuteronomy - 13 [[Deuteronomy - 14|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Deuteronomy]]

# Deuteronomy - 13

If there arise in the midst of thee a prophet, or a dreamer of dreams, and he give thee a sign or a wonder, [^1] and the sign or the wonder come to pass, whereof he spake unto thee, saying, Let us go after other gods, which thou hast not known, and let us serve them; [^2] thou shalt not hearken unto the words of that prophet, or unto that dreamer of dreams: for Jehovah your God proveth you, to know whether ye love Jehovah your God with all your heart and with all your soul. [^3] Ye shall walk after Jehovah your God, and fear him, and keep his commandments, and obey his voice, and ye shall serve him, and cleave unto him. [^4] And that prophet, or that dreamer of dreams, shall be put to death, because he hath spoken rebellion against Jehovah your God, who brought you out of the land of Egypt, and redeemed thee out of the house of bondage, to draw thee aside out of the way which Jehovah thy God commanded thee to walk in. So shalt thou put away the evil from the midst of thee. [^5] If thy brother, the son of thy mother, or thy son, or thy daughter, or the wife of thy bosom, or thy friend, that is as thine own soul, entice thee secretly, saying, Let us go and serve other gods, which thou hast not known, thou, nor thy fathers; [^6] of the gods of the peoples that are round about you, nigh unto thee, or far off from thee, from the one end of the earth even unto the other end of the earth; [^7] thou shalt not consent unto him, nor hearken unto him; neither shall thine eye pity him, neither shalt thou spare, neither shalt thou conceal him: [^8] but thou shalt surely kill him; thy hand shall be first upon him to put him to death, and afterwards the hand of all the people. [^9] And thou shalt stone him to death with stones, because he hath sought to draw thee away from Jehovah thy God, who brought thee out of the land of Egypt, out of the house of bondage. [^10] And all Israel shall hear, and fear, and shall do no more any such wickedness as this is in the midst of thee. [^11] If thou shalt hear tell concerning one of thy cities, which Jehovah thy God giveth thee to dwell there, saying, [^12] Certain base fellows are gone out from the midst of thee, and have drawn away the inhabitants of their city, saying, Let us go and serve other gods, which ye have not known; [^13] then shalt thou inquire, and make search, and ask diligently; and, behold, if it be truth, and the thing certain, that such abomination is wrought in the midst of thee, [^14] thou shalt surely smite the inhabitants of that city with the edge of the sword, destroying it utterly, and all that is therein and the cattle thereof, with the edge of the sword. [^15] And thou shalt gather all the spoil of it into the midst of the street thereof, and shalt burn with fire the city, and all the spoil thereof every whit, unto Jehovah thy God: and it shall be a heap for ever; it shall not be built again. [^16] And there shall cleave nought of the devoted thing to thy hand; that Jehovah may turn from the fierceness of his anger, and show thee mercy, and have compassion upon thee, and multiply thee, as he hath sworn unto thy fathers; [^17] when thou shalt hearken to the voice of Jehovah thy God, to keep all his commandments which I command thee this day, to do that which is right in the eyes of Jehovah thy God. [^18] 

[[Deuteronomy - 12|<--]] Deuteronomy - 13 [[Deuteronomy - 14|-->]]

---
# Notes
