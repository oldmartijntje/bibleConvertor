---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 24 - American Standard Version"
---
[[Deuteronomy - 23|<--]] Deuteronomy - 24 [[Deuteronomy - 25|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Deuteronomy]]

# Deuteronomy - 24

When a man taketh a wife, and marrieth her, then it shall be, if she find no favor in his eyes, because he hath found some unseemly thing in her, that he shall write her a bill of divorcement, and give it in her hand, and send her out of his house. [^1] And when she is departed out of his house, she may go and be another man’s wife. [^2] And if the latter husband hate her, and write her a bill of divorcement, and give it in her hand, and send her out of his house; or if the latter husband die, who took her to be his wife; [^3] her former husband, who sent her away, may not take her again to be his wife, after that she is defiled; for that is abomination before Jehovah: and thou shalt not cause the land to sin, which Jehovah thy God giveth thee for an inheritance. [^4] When a man taketh a new wife, he shall not go out in the host, neither shall he be charged with any business: he shall be free at home one year, and shall cheer his wife whom he hath taken. [^5] No man shall take the mill or the upper millstone to pledge; for he taketh a man’s life to pledge. [^6] If a man be found stealing any of his brethren of the children of Israel, and he deal with him as a slave, or sell him; then that thief shall die: so shalt thou put away the evil from the midst of thee. [^7] Take heed in the plague of leprosy, that thou observe diligently, and do according to all that the priests the Levites shall teach you: as I commanded them, so ye shall observe to do. [^8] Remember what Jehovah thy God did unto Miriam, by the way as ye came forth out of Egypt. [^9] When thou dost lend thy neighbor any manner of loan, thou shalt not go into his house to fetch his pledge. [^10] Thou shalt stand without, and the man to whom thou dost lend shall bring forth the pledge without unto thee. [^11] And if he be a poor man, thou shalt not sleep with his pledge; [^12] thou shalt surely restore to him the pledge when the sun goeth down, that he may sleep in his garment, and bless thee: and it shall be righteousness unto thee before Jehovah thy God. [^13] Thou shalt not oppress a hired servant that is poor and needy, whether he be of thy brethren, or of thy sojourners that are in thy land within thy gates: [^14] in his day thou shalt give him his hire, neither shall the sun go down upon it (for he is poor, and setteth his heart upon it); lest he cry against thee unto Jehovah, and it be sin unto thee. [^15] The fathers shall not be put to death for the children, neither shall the children be put to death for the fathers: every man shall be put to death for his own sin. [^16] Thou shalt not wrest the justice due to the sojourner, or to the fatherless, nor take the widow’s raiment to pledge; [^17] but thou shalt remember that thou wast a bondman in Egypt, and Jehovah thy God redeemed thee thence: therefore I command thee to do this thing. [^18] When thou reapest thy harvest in thy field, and hast forgot a sheaf in the field, thou shalt not go again to fetch it: it shall be for the sojourner, for the fatherless, and for the widow; that Jehovah thy God may bless thee in all the work of thy hands. [^19] When thou beatest thine olive-tree, thou shalt not go over the boughs again: it shall be for the sojourner, for the fatherless, and for the widow. [^20] When thou gatherest the grapes of thy vineyard, thou shalt not glean it after thee: it shall be for the sojourner, for the fatherless, and for the widow. [^21] And thou shalt remember that thou wast a bondman in the land of Egypt: therefore I command thee to do this thing. [^22] 

[[Deuteronomy - 23|<--]] Deuteronomy - 24 [[Deuteronomy - 25|-->]]

---
# Notes
