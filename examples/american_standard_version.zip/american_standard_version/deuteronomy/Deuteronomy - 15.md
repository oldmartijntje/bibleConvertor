---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 15 - American Standard Version"
---
[[Deuteronomy - 14|<--]] Deuteronomy - 15 [[Deuteronomy - 16|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Deuteronomy]]

# Deuteronomy - 15

At the end of every seven years thou shalt make a release. [^1] And this is the manner of the release: every creditor shall release that which he hath lent unto his neighbor; he shall not exact it of his neighbor and his brother; because Jehovah’s release hath been proclaimed. [^2] Of a foreigner thou mayest exact it: but whatsoever of thine is with thy brother thy hand shall release. [^3] Howbeit there shall be no poor with thee (for Jehovah will surely bless thee in the land which Jehovah thy God giveth thee for an inheritance to possess it), [^4] if only thou diligently hearken unto the voice of Jehovah thy God, to observe to do all this commandment which I command thee this day. [^5] For Jehovah thy God will bless thee, as he promised thee: and thou shalt lend unto many nations, but thou shalt not borrow; and thou shalt rule over many nations, but they shall not rule over thee. [^6] If there be with thee a poor man, one of thy brethren, within any of thy gates in thy land which Jehovah thy God giveth thee, thou shalt not harden thy heart, nor shut thy hand from thy poor brother; [^7] but thou shalt surely open thy hand unto him, and shalt surely lend him sufficient for his need in that which he wanteth. [^8] Beware that there be not a base thought in thy heart, saying, The seventh year, the year of release, is at hand; and thine eye be evil against thy poor brother, and thou give him nought; and he cry unto Jehovah against thee, and it be sin unto thee. [^9] Thou shalt surely give him, and thy heart shall not be grieved when thou givest unto him; because that for this thing Jehovah thy God will bless thee in all thy work, and in all that thou puttest thy hand unto. [^10] For the poor will never cease out of the land: therefore I command thee, saying, Thou shalt surely open thy hand unto thy brother, to thy needy, and to thy poor, in thy land. [^11] If thy brother, a Hebrew man, or a Hebrew woman, be sold unto thee, and serve thee six years; then in the seventh year thou shalt let him go free from thee. [^12] And when thou lettest him go free from thee, thou shalt not let him go empty: [^13] thou shalt furnish him liberally out of thy flock, and out of thy threshing-floor, and out of thy winepress; as Jehovah thy God hath blessed thee thou shalt give unto him. [^14] And thou shalt remember that thou wast a bondman in the land of Egypt, and Jehovah thy God redeemed thee: therefore I command thee this thing to-day. [^15] And it shall be, if he say unto thee, I will not go out from thee; because he loveth thee and thy house, because he is well with thee; [^16] then thou shalt take an awl, and thrust it through his ear unto the door, and he shall be thy servant for ever. And also unto thy maid-servant thou shalt do likewise. [^17] It shall not seem hard unto thee, when thou lettest him go free from thee; for to the double of the hire of a hireling hath he served thee six years: and Jehovah thy God will bless thee in all that thou doest. [^18] All the firstling males that are born of thy herd and of thy flock thou shalt sanctify unto Jehovah thy God: thou shalt do no work with the firstling of thy herd, nor shear the firstling of thy flock. [^19] Thou shalt eat it before Jehovah thy God year by year in the place which Jehovah shall choose, thou and thy household. [^20] And if it have any blemish, as if it be lame or blind, any ill blemish whatsoever, thou shalt not sacrifice it unto Jehovah thy God. [^21] Thou shalt eat it within thy gates: the unclean and the clean shall eat it alike, as the gazelle, and as the hart. [^22] Only thou shalt not eat the blood thereof; thou shalt pour it out upon the ground as water. [^23] 

[[Deuteronomy - 14|<--]] Deuteronomy - 15 [[Deuteronomy - 16|-->]]

---
# Notes
