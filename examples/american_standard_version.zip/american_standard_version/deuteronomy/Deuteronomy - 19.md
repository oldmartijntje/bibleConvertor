---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 19 - American Standard Version"
---
[[Deuteronomy - 18|<--]] Deuteronomy - 19 [[Deuteronomy - 20|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Deuteronomy]]

# Deuteronomy - 19

When Jehovah thy God shall cut off the nations, whose land Jehovah thy God giveth thee, and thou succeedest them, and dwellest in their cities, and in their houses; [^1] thou shalt set apart three cities for thee in the midst of thy land, which Jehovah thy God giveth thee to possess it. [^2] Thou shalt prepare thee the way, and divide the borders of thy land, which Jehovah thy God causeth thee to inherit, into three parts, that every manslayer may flee thither. [^3] And this is the case of the manslayer, that shall flee thither and live: whoso killeth his neighbor unawares, and hated him not in time past; [^4] as when a man goeth into the forest with his neighbor to hew wood, and his hand fetcheth a stroke with the axe to cut down the tree, and the head slippeth from the helve, and lighteth upon his neighbor, so that he dieth; he shall flee unto one of these cities and live: [^5] lest the avenger of blood pursue the manslayer, while his heart is hot, and overtake him, because the way is long, and smite him mortally; whereas he was not worthy of death, inasmuch as he hated him not in time past. [^6] Wherefore I command thee, saying, Thou shalt set apart three cities for thee. [^7] And if Jehovah thy God enlarge thy border, as he hath sworn unto thy fathers, and give thee all the land which he promised to give unto thy fathers; [^8] if thou shalt keep all this commandment to do it, which I command thee this day, to love Jehovah thy God, and to walk ever in his ways; then shalt thou add three cities more for thee, besides these three: [^9] that innocent blood be not shed in the midst of thy land, which Jehovah thy God giveth thee for an inheritance, and so blood be upon thee. [^10] But if any man hate his neighbor, and lie in wait for him, and rise up against him, and smite him mortally so that he dieth, and he flee into one of these cities; [^11] then the elders of his city shall send and fetch him thence, and deliver him into the hand of the avenger of blood, that he may die. [^12] Thine eye shall not pity him, but thou shalt put away the innocent blood from Israel, that it may go well with thee. [^13] Thou shalt not remove thy neighbor’s landmark, which they of old time have set, in thine inheritance which thou shalt inherit, in the land that Jehovah thy God giveth thee to possess it. [^14] One witness shall not rise up against a man for any iniquity, or for any sin, in any sin that he sinneth: at the mouth of two witnesses, or at the mouth of three witnesses, shall a matter be established. [^15] If an unrighteous witness rise up against any man to testify against him of wrong-doing, [^16] then both the men, between whom the controversy is, shall stand before Jehovah, before the priests and the judges that shall be in those days; [^17] and the judges shall make diligent inquisition: and, behold, if the witness be a false witness, and have testified falsely against his brother; [^18] then shall ye do unto him, as he had thought to do unto his brother: so shalt thou put away the evil from the midst of thee. [^19] And those that remain shall hear, and fear, and shall henceforth commit no more any such evil in the midst of thee. [^20] And thine eyes shall not pity; life shall go for life, eye for eye, tooth for tooth, hand for hand, foot for foot. [^21] 

[[Deuteronomy - 18|<--]] Deuteronomy - 19 [[Deuteronomy - 20|-->]]

---
# Notes
