---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 6 - American Standard Version"
---
[[2 Samuel - 5|<--]] 2 Samuel - 6 [[2 Samuel - 7|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[2 Samuel]]

# 2 Samuel - 6

And David again gathered together all the chosen men of Israel, thirty thousand. [^1] And David arose, and went with all the people that were with him, from Baale-judah, to bring up from thence the ark of God, which is called by the Name, even the name of Jehovah of hosts that sitteth above the cherubim. [^2] And they set the ark of God upon a new cart, and brought it out of the house of Abinadab that was in the hill: and Uzzah and Ahio, the sons of Abinadab, drove the new cart. [^3] And they brought it out of the house of Abinadab, which was in the hill, with the ark of God: and Ahio went before the ark. [^4] And David and all the house of Israel played before Jehovah with all manner of instruments made of fir-wood, and with harps, and with psalteries, and with timbrels, and with castanets, and with cymbals. [^5] And when they came to the threshing-floor of Nacon, Uzzah put forth his hand to the ark of God, and took hold of it; for the oxen stumbled. [^6] And the anger of Jehovah was kindled against Uzzah; and God smote him there for his error; and there he died by the ark of God. [^7] And David was displeased, because Jehovah had broken forth upon Uzzah; and he called that place Perez-uzzah, unto this day. [^8] And David was afraid of Jehovah that day; and he said, How shall the ark of Jehovah come unto me? [^9] So David would not remove the ark of Jehovah unto him into the city of David; but David carried it aside into the house of Obed-edom the Gittite. [^10] And the ark of Jehovah remained in the house of Obed-edom the Gittite three months: and Jehovah blessed Obed-edom, and all his house. [^11] And it was told king David, saying, Jehovah hath blessed the house of Obed-edom, and all that pertaineth unto him, because of the ark of God. And David went and brought up the ark of God from the house of Obed-edom into the city of David with joy. [^12] And it was so, that, when they that bare the ark of Jehovah had gone six paces, he sacrificed an ox and a fatling. [^13] And David danced before Jehovah with all his might; and David was girded with a linen ephod. [^14] So David and all the house of Israel brought up the ark of Jehovah with shouting, and with the sound of the trumpet. [^15] And it was so, as the ark of Jehovah came into the city of David, that Michal the daughter of Saul looked out at the window, and saw king David leaping and dancing before Jehovah; and she despised him in her heart. [^16] And they brought in the ark of Jehovah, and set it in its place, in the midst of the tent that David had pitched for it; and David offered burnt-offerings and peace-offerings before Jehovah. [^17] And when David had made an end of offering the burnt-offering and the peace-offerings, he blessed the people in the name of Jehovah of hosts. [^18] And he dealt among all the people, even among the whole multitude of Israel, both to men and women, to every one a cake of bread, and a portion of flesh, and a cake of raisins. So all the people departed every one to his house. [^19] Then David returned to bless his household. And Michal the daughter of Saul came out to meet David, and said, How glorious was the king of Israel to-day, who uncovered himself to-day in the eyes of the handmaids of his servants, as one of the vain fellows shamelessly uncovereth himself! [^20] And David said unto Michal, It was before Jehovah, who chose me above thy father, and above all his house, to appoint me prince over the people of Jehovah, over Israel: therefore will I play before Jehovah. [^21] And I will be yet more vile than this, and will be base in mine own sight: but of the handmaids of whom thou hast spoken, of them shall I be had in honor. [^22] And Michal the daughter of Saul had no child unto the day of her death. [^23] 

[[2 Samuel - 5|<--]] 2 Samuel - 6 [[2 Samuel - 7|-->]]

---
# Notes
