---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 10 - American Standard Version"
---
[[2 Samuel - 9|<--]] 2 Samuel - 10 [[2 Samuel - 11|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[2 Samuel]]

# 2 Samuel - 10

And it came to pass after this, that the king of the children of Ammon died, and Hanun his son reigned in his stead. [^1] And David said, I will show kindness unto Hanun the son of Nahash, as his father showed kindness unto me. So David sent by his servants to comfort him concerning his father. And David’s servants came into the land of the children of Ammon. [^2] But the princes of the children of Ammon said unto Hanun their lord, Thinkest thou that David doth honor thy father, in that he hath sent comforters unto thee? hath not David sent his servants unto thee to search the city, and to spy it out, and to overthrow it? [^3] So Hanun took David’s servants, and shaved off the one half of their beards, and cut off their garments in the middle, even to their buttocks, and sent them away. [^4] When they told it unto David, he sent to meet them; for the men were greatly ashamed. And the king said, Tarry at Jericho until your beards be grown, and then return. [^5] And when the children of Ammon saw that they were become odious to David, the children of Ammon sent and hired the Syrians of Beth-rehob, and the Syrians of Zobah, twenty thousand footmen, and the king of Maacah with a thousand men, and the men of Tob twelve thousand men. [^6] And when David heard of it, he sent Joab, and all the host of the mighty men. [^7] And the children of Ammon came out, and put the battle in array at the entrance of the gate: and the Syrians of Zobah and of Rehob, and the men of Tob and Maacah, were by themselves in the field. [^8] Now when Joab saw that the battle was set against him before and behind, he chose of all the choice men of Israel, and put them in array against the Syrians: [^9] and the rest of the people he committed into the hand of Abishai his brother; and he put them in array against the children of Ammon. [^10] And he said, If the Syrians be too strong for me, then thou shalt help me; but if the children of Ammon be too strong for thee, then I will come and help thee. [^11] Be of good courage, and let us play the man for our people, and for the cities of our God: and Jehovah do that which seemeth him good. [^12] So Joab and the people that were with him drew nigh unto the battle against the Syrians: and they fled before him. [^13] And when the children of Ammon saw that the Syrians were fled, they likewise fled before Abishai, and entered into the city. Then Joab returned from the children of Ammon, and came to Jerusalem. [^14] And when the Syrians saw that they were put to the worse before Israel, they gathered themselves together. [^15] And Hadarezer sent, and brought out the Syrians that were beyond the River: and they came to Helam, with Shobach the captain of the host of Hadarezer at their head. [^16] And it was told David; and he gathered all Israel together, and passed over the Jordan, and came to Helam. And the Syrians set themselves in array against David, and fought with him. [^17] And the Syrians fled before Israel; and David slew of the Syrians the men of seven hundred chariots, and forty thousand horsemen, and smote Shobach the captain of their host, so that he died there. [^18] And when all the kings that were servants to Hadarezer saw that they were put to the worse before Israel, they made peace with Israel, and served them. So the Syrians feared to help the children of Ammon any more. [^19] 

[[2 Samuel - 9|<--]] 2 Samuel - 10 [[2 Samuel - 11|-->]]

---
# Notes
