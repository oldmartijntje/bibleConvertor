---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 4 - American Standard Version"
---
[[2 Samuel - 3|<--]] 2 Samuel - 4 [[2 Samuel - 5|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[2 Samuel]]

# 2 Samuel - 4

And when Ish-bosheth, Saul’s son, heard that Abner was dead in Hebron, his hands became feeble, and all the Israelites were troubled. [^1] And Ish-bosheth, Saul’s son, had two men that were captains of bands: the name of the one was Baanah, and the name of the other Rechab, the sons of Rimmon the Beerothite, of the children of Benjamin (for Beeroth also is reckoned to Benjamin: [^2] and the Beerothites fled to Gittaim, and have been sojourners there until this day). [^3] Now Jonathan, Saul’s son, had a son that was lame of his feet. He was five years old when the tidings came of Saul and Jonathan out of Jezreel; and his nurse took him up, and fled: and it came to pass, as she made haste to flee, that he fell, and became lame. And his name was Mephibosheth. [^4] And the sons of Rimmon the Beerothite, Rechab and Baanah, went, and came about the heat of the day to the house of Ish-bosheth, as he took his rest at noon. [^5] And they came thither into the midst of the house, as though they would have fetched wheat; and they smote him in the body: and Rechab and Baanah his brother escaped. [^6] Now when they came into the house, as he lay on his bed in his bedchamber, they smote him, and slew him, and beheaded him, and took his head, and went by the way of the Arabah all night. [^7] And they brought the head of Ish-bosheth unto David to Hebron, and said to the king, Behold, the head of Ish-bosheth, the son of Saul, thine enemy, who sought thy life; and Jehovah hath avenged my lord the king this day of Saul, and of his seed. [^8] And David answered Rechab and Baanah his brother, the sons of Rimmon the Beerothite, and said unto them, As Jehovah liveth, who hath redeemed my soul out of all adversity, [^9] when one told me, saying, Behold, Saul is dead, thinking to have brought good tidings, I took hold of him, and slew him in Ziklag, which was the reward I gave him for his tidings. [^10] How much more, when wicked men have slain a righteous person in his own house upon his bed, shall I not now require his blood of your hand, and take you away from the earth? [^11] And David commanded his young men, and they slew them, and cut off their hands and their feet, and hanged them up beside the pool in Hebron. But they took the head of Ish-bosheth, and buried it in the grave of Abner in Hebron. [^12] 

[[2 Samuel - 3|<--]] 2 Samuel - 4 [[2 Samuel - 5|-->]]

---
# Notes
