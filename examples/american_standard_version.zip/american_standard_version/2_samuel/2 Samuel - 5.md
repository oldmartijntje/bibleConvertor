---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 5 - American Standard Version"
---
[[2 Samuel - 4|<--]] 2 Samuel - 5 [[2 Samuel - 6|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[2 Samuel]]

# 2 Samuel - 5

Then came all the tribes of Israel to David unto Hebron, and spake, saying, Behold, we are thy bone and thy flesh. [^1] In times past, when Saul was king over us, it was thou that leddest out and broughtest in Israel: and Jehovah said to thee, Thou shalt be shepherd of my people Israel, and thou shalt be prince over Israel. [^2] So all the elders of Israel came to the king to Hebron; and king David made a covenant with them in Hebron before Jehovah: and they anointed David king over Israel. [^3] David was thirty years old when he began to reign, and he reigned forty years. [^4] In Hebron he reigned over Judah seven years and six months; and in Jerusalem he reigned thirty and three years over all Israel and Judah. [^5] And the king and his men went to Jerusalem against the Jebusites, the inhabitants of the land, who spake unto David, saying, Except thou take away the blind and the lame, thou shalt not come in hither; thinking, David cannot come in hither. [^6] Nevertheless David took the stronghold of Zion; the same is the city of David. [^7] And David said on that day, Whosoever smiteth the Jebusites, let him get up to the watercourse, and smite the lame and the blind, that are hated of David’s soul. Wherefore they say, There are the blind and the lame; he cannot come into the house. [^8] And David dwelt in the stronghold, and called it the city of David. And David built round about from Millo and inward. [^9] And David waxed greater and greater; for Jehovah, the God of hosts, was with him. [^10] And Hiram king of Tyre sent messengers to David, and cedar-trees, and carpenters, and masons; and they built David a house. [^11] And David perceived that Jehovah had established him king over Israel, and that he had exalted his kingdom for his people Israel’s sake. [^12] And David took him more concubines and wives out of Jerusalem, after he was come from Hebron; and there were yet sons and daughters born to David. [^13] And these are the names of those that were born unto him in Jerusalem: Shammua, and Shobab, and Nathan, and Solomon, [^14] and Ibhar, and Elishua, and Nepheg, and Japhia, [^15] and Elishama, and Eliada, and Eliphelet. [^16] And when the Philistines heard that they had anointed David king over Israel, all the Philistines went up to seek David; and David heard of it, and went down to the stronghold. [^17] Now the Philistines had come and spread themselves in the valley of Rephaim. [^18] And David inquired of Jehovah, saying, Shall I go up against the Philistines? wilt thou deliver them into my hand? And Jehovah said unto David, Go up; for I will certainly deliver the Philistines into thy hand. [^19] And David came to Baal-perazim, and David smote them there; and he said, Jehovah hath broken mine enemies before me, like the breach of waters. Therefore he called the name of that place Baal-perazim. [^20] And they left their images there; and David and his men took them away. [^21] And the Philistines came up yet again, and spread themselves in the valley of Rephaim. [^22] And when David inquired of Jehovah, he said, Thou shalt not go up: make a circuit behind them, and come upon them over against the mulberry-trees. [^23] And it shall be, when thou hearest the sound of marching in the tops of the mulberry-trees, that then thou shalt bestir thyself; for then is Jehovah gone out before thee to smite the host of the Philistines. [^24] And David did so, as Jehovah commanded him, and smote the Philistines from Geba until thou come to Gezer. [^25] 

[[2 Samuel - 4|<--]] 2 Samuel - 5 [[2 Samuel - 6|-->]]

---
# Notes
