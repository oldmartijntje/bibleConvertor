---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 32 - American Standard Version"
---
[[Job - 31|<--]] Job - 32 [[Job - 33|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 32

So these three men ceased to answer Job, because he was righteous in his own eyes. [^1] Then was kindled the wrath of Elihu the son of Barachel the Buzite, of the family of Ram: against Job was his wrath kindled, because he justified himself rather than God. [^2] Also against his three friends was his wrath kindled, because they had found no answer, and yet had condemned Job. [^3] Now Elihu had waited to speak unto Job, because they were elder than he. [^4] And when Elihu saw that there was no answer in the mouth of these three men, his wrath was kindled. [^5] And Elihu the son of Barachel the Buzite answered and said,I am young, and ye are very old;Wherefore I held back, and durst not show you mine opinion. [^6] I said, Days should speak,And multitude of years should teach wisdom. [^7] But there is a spirit in man,And the breath of the Almighty giveth them understanding. [^8] It is not the great that are wise,Nor the aged that understand justice. [^9] Therefore I said, Hearken to me;I also will show mine opinion. [^10] Behold, I waited for your words,I listened for your reasonings,Whilst ye searched out what to say. [^11] Yea, I attended unto you,And, behold, there was none that convinced Job,Or that answered his words, among you. [^12] Beware lest ye say, We have found wisdom;God may vanquish him, not man: [^13] For he hath not directed his words against me;Neither will I answer him with your speeches. [^14] They are amazed, they answer no more:They have not a word to say. [^15] And shall I wait, because they speak not,Because they stand still, and answer no more? [^16] I also will answer my part,I also will show mine opinion. [^17] For I am full of words;The spirit within me constraineth me. [^18] Behold, my breast is as wine which hath no vent;Like new wine-skins it is ready to burst. [^19] I will speak, that I may be refreshed;I will open my lips and answer. [^20] Let me not, I pray you, respect any man’s person;Neither will I give flattering titles unto any man. [^21] For I know not to give flattering titles;Else would my Maker soon take me away. [^22] 

[[Job - 31|<--]] Job - 32 [[Job - 33|-->]]

---
# Notes
