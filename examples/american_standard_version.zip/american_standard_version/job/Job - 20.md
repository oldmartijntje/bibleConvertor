---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 20 - American Standard Version"
---
[[Job - 19|<--]] Job - 20 [[Job - 21|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 20

Then answered Zophar the Naamathite, and said, [^1] Therefore do my thoughts give answer to me,Even by reason of my haste that is in me. [^2] I have heard the reproof which putteth me to shame;And the spirit of my understanding answereth me. [^3] Knowest thou not this of old time,Since man was placed upon earth, [^4] That the triumphing of the wicked is short,And the joy of the godless but for a moment? [^5] Though his height mount up to the heavens,And his head reach unto the clouds; [^6] Yet he shall perish for ever like his own dung:They that have seen him shall say, Where is he? [^7] He shall fly away as a dream, and shall not be found:Yea, he shall be chased away as a vision of the night. [^8] The eye which saw him shall see him no more;Neither shall his place any more behold him. [^9] His children shall seek the favor of the poor,And his hands shall give back his wealth. [^10] His bones are full of his youth,But it shall lie down with him in the dust. [^11] Though wickedness be sweet in his mouth,Though he hide it under his tongue, [^12] Though he spare it, and will not let it go,But keep it still within his mouth; [^13] Yet his food in his bowels is turned,It is the gall of asps within him. [^14] He hath swallowed down riches, and he shall vomit them up again;God will cast them out of his belly. [^15] He shall suck the poison of asps:The viper’s tongue shall slay him. [^16] He shall not look upon the rivers,The flowing streams of honey and butter. [^17] That which he labored for shall he restore, and shall not swallow it down;According to the substance that he hath gotten, he shall not rejoice. [^18] For he hath oppressed and forsaken the poor;He hath violently taken away a house, and he shall not build it up. [^19] Because he knew no quietness within him,He shall not save aught of that wherein he delighteth. [^20] There was nothing left that he devoured not;Therefore his prosperity shall not endure. [^21] In the fulness of his sufficiency he shall be in straits:The hand of every one that is in misery shall come upon him. [^22] When he is about to fill his belly,God will cast the fierceness of his wrath upon him,And will rain it upon him while he is eating. [^23] He shall flee from the iron weapon,And the bow of brass shall strike him through. [^24] He draweth it forth, and it cometh out of his body;Yea, the glittering point cometh out of his gall:Terrors are upon him. [^25] All darkness is laid up for his treasures:A fire not blown by man shall devour him;It shall consume that which is left in his tent. [^26] The heavens shall reveal his iniquity,And the earth shall rise up against him. [^27] The increase of his house shall depart;His goods shall flow away in the day of his wrath. [^28] This is the portion of a wicked man from God,And the heritage appointed unto him by God. [^29] 

[[Job - 19|<--]] Job - 20 [[Job - 21|-->]]

---
# Notes
