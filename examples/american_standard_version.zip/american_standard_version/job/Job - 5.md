---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 5 - American Standard Version"
---
[[Job - 4|<--]] Job - 5 [[Job - 6|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 5

Call now; is there any that will answer thee?And to which of the holy ones wilt thou turn? [^1] For vexation killeth the foolish man,And jealousy slayeth the silly one. [^2] I have seen the foolish taking root:But suddenly I cursed his habitation. [^3] His children are far from safety,And they are crushed in the gate,Neither is there any to deliver them: [^4] Whose harvest the hungry eateth up,And taketh it even out of the thorns;And the snare gapeth for their substance. [^5] For affliction cometh not forth from the dust,Neither doth trouble spring out of the ground; [^6] But man is born unto trouble,As the sparks fly upward. [^7] But as for me, I would seek unto God,And unto God would I commit my cause; [^8] Who doeth great things and unsearchable,Marvellous things without number: [^9] Who giveth rain upon the earth,And sendeth waters upon the fields; [^10] So that he setteth up on high those that are low,And those that mourn are exalted to safety. [^11] He frustrateth the devices of the crafty,So that their hands cannot perform their enterprise. [^12] He taketh the wise in their own craftiness;And the counsel of the cunning is carried headlong. [^13] They meet with darkness in the day-time,And grope at noonday as in the night. [^14] But he saveth from the sword of their mouth,Even the needy from the hand of the mighty. [^15] So the poor hath hope,And iniquity stoppeth her mouth. [^16] Behold, happy is the man whom God correcteth:Therefore despise not thou the chastening of the Almighty. [^17] For he maketh sore, and bindeth up;He woundeth, and his hands make whole. [^18] He will deliver thee in six troubles;Yea, in seven there shall no evil touch thee. [^19] In famine he will redeem thee from death;And in war from the power of the sword. [^20] Thou shalt be hid from the scourge of the tongue;Neither shalt thou be afraid of destruction when it cometh. [^21] At destruction and dearth thou shalt laugh;Neither shalt thou be afraid of the beasts of the earth. [^22] For thou shalt be in league with the stones of the field;And the beasts of the field shall be at peace with thee. [^23] And thou shalt know that thy tent is in peace;And thou shalt visit thy fold, and shalt miss nothing. [^24] Thou shalt know also that thy seed shall be great,And thine offspring as the grass of the earth. [^25] Thou shalt come to thy grave in a full age,Like as a shock of grain cometh in in its season. [^26] Lo this, we have searched it, so it is;Hear it, and know thou it for thy good. [^27] 

[[Job - 4|<--]] Job - 5 [[Job - 6|-->]]

---
# Notes
