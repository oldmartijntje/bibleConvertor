---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 42 - American Standard Version"
---
[[Job - 41|<--]] Job - 42

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 42

Then Job answered Jehovah, and said, [^1] I know that thou canst do all things,And that no purpose of thine can be restrained. [^2] Who is this that hideth counsel without knowledge?Therefore have I uttered that which I understood not,Things too wonderful for me, which I knew not. [^3] Hear, I beseech thee, and I will speak;I will demand of thee, and declare thou unto me. [^4] I had heard of thee by the hearing of the ear;But now mine eye seeth thee: [^5] Wherefore I abhor myself,And repent in dust and ashes. [^6] And it was so, that, after Jehovah had spoken these words unto Job, Jehovah said to Eliphaz the Temanite, My wrath is kindled against thee, and against thy two friends; for ye have not spoken of me the thing that is right, as my servant Job hath. [^7] Now therefore, take unto you seven bullocks and seven rams, and go to my servant Job, and offer up for yourselves a burnt-offering; and my servant Job shall pray for you; for him will I accept, that I deal not with you after your folly; for ye have not spoken of me the thing that is right, as my servant Job hath. [^8] So Eliphaz the Temanite and Bildad the Shuhite and Zophar the Naamathite went, and did according as Jehovah commanded them: and Jehovah accepted Job. [^9] And Jehovah turned the captivity of Job, when he prayed for his friends: and Jehovah gave Job twice as much as he had before. [^10] Then came there unto him all his brethren, and all his sisters, and all they that had been of his acquaintance before, and did eat bread with him in his house: and they bemoaned him, and comforted him concerning all the evil that Jehovah had brought upon him: every man also gave him a piece of money, and every one a ring of gold. [^11] So Jehovah blessed the latter end of Job more than his beginning: and he had fourteen thousand sheep, and six thousand camels, and a thousand yoke of oxen, and a thousand she-asses. [^12] He had also seven sons and three daughters. [^13] And he called the name of the first, Jemimah; and the name of the second, Keziah; and the name of the third, Keren-happuch. [^14] And in all the land were no women found so fair as the daughters of Job: and their father gave them inheritance among their brethren. [^15] And after this Job lived a hundred and forty years, and saw his sons, and his sons’ sons, even four generations. [^16] So Job died, being old and full of days. [^17] 

[[Job - 41|<--]] Job - 42

---
# Notes
