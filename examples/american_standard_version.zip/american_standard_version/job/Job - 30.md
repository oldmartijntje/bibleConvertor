---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 30 - American Standard Version"
---
[[Job - 29|<--]] Job - 30 [[Job - 31|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 30

But now they that are younger than I have me in derision,Whose fathers I disdained to set with the dogs of my flock. [^1] Yea, the strength of their hands, whereto should it profit me?Men in whom ripe age is perished. [^2] They are gaunt with want and famine;They gnaw the dry ground, in the gloom of wasteness and desolation. [^3] They pluck salt-wort by the bushes;And the roots of the broom are their food. [^4] They are driven forth from the midst of men;They cry after them as after a thief; [^5] So that they dwell in frightful valleys,In holes of the earth and of the rocks. [^6] Among the bushes they bray;Under the nettles they are gathered together. [^7] They are children of fools, yea, children of base men;They were scourged out of the land. [^8] And now I am become their song,Yea, I am a byword unto them. [^9] They abhor me, they stand aloof from me,And spare not to spit in my face. [^10] For he hath loosed his cord, and afflicted me;And they have cast off the bridle before me. [^11] Upon my right hand rise the rabble;They thrust aside my feet,And they cast up against me their ways of destruction. [^12] They mar my path,They set forward my calamity,Even men that have no helper. [^13] As through a wide breach they come:In the midst of the ruin they roll themselves upon me. [^14] Terrors are turned upon me;They chase mine honor as the wind;And my welfare is passed away as a cloud. [^15] And now my soul is poured out within me;Days of affliction have taken hold upon me. [^16] In the night season my bones are pierced in me,And the pains that gnaw me take no rest. [^17] By God’s great force is my garment disfigured;It bindeth me about as the collar of my coat. [^18] He hath cast me into the mire,And I am become like dust and ashes. [^19] I cry unto thee, and thou dost not answer me:I stand up, and thou gazest at me. [^20] Thou art turned to be cruel to me;With the might of thy hand thou persecutest me. [^21] Thou liftest me up to the wind, thou causest me to ride upon it;And thou dissolvest me in the storm. [^22] For I know that thou wilt bring me to death,And to the house appointed for all living. [^23] Howbeit doth not one stretch out the hand in his fall?Or in his calamity therefore cry for help? [^24] Did not I weep for him that was in trouble?Was not my soul grieved for the needy? [^25] When I looked for good, then evil came;And when I waited for light, there came darkness. [^26] My heart is troubled, and resteth not;Days of affliction are come upon me. [^27] I go mourning without the sun:I stand up in the assembly, and cry for help. [^28] I am a brother to jackals,And a companion to ostriches. [^29] My skin is black, and falleth from me,And my bones are burned with heat. [^30] Therefore is my harp turned to mourning,And my pipe into the voice of them that weep. [^31] 

[[Job - 29|<--]] Job - 30 [[Job - 31|-->]]

---
# Notes
