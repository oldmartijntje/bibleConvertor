---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 31 - American Standard Version"
---
[[Job - 30|<--]] Job - 31 [[Job - 32|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 31

I made a covenant with mine eyes;How then should I look upon a virgin? [^1] For what is the portion from God above,And the heritage from the Almighty on high? [^2] Is it not calamity to the unrighteous,And disaster to the workers of iniquity? [^3] Doth not he see my ways,And number all my steps? [^4] If I have walked with falsehood,And my foot hath hasted to deceit [^5] (Let me be weighed in an even balance,That God may know mine integrity); [^6] If my step hath turned out of the way,And my heart walked after mine eyes,And if any spot hath cleaved to my hands: [^7] Then let me sow, and let another eat;Yea, let the produce of my field be rooted out. [^8] If my heart hath been enticed unto a woman,And I have laid wait at my neighbor’s door; [^9] Then let my wife grind unto another,And let others bow down upon her. [^10] For that were a heinous crime;Yea, it were an iniquity to be punished by the judges: [^11] For it is a fire that consumeth unto Destruction,And would root out all mine increase. [^12] If I have despised the cause of my man-servant or of my maid-servant,When they contended with me; [^13] What then shall I do when God riseth up?And when he visiteth, what shall I answer him? [^14] Did not he that made me in the womb make him?And did not one fashion us in the womb? [^15] If I have withheld the poor from their desire,Or have caused the eyes of the widow to fail, [^16] Or have eaten my morsel alone,And the fatherless hath not eaten thereof [^17] (Nay, from my youth he grew up with me as with a father,And her have I guided from my mother’s womb); [^18] If I have seen any perish for want of clothing,Or that the needy had no covering; [^19] If his loins have not blessed me,And if he hath not been warmed with the fleece of my sheep; [^20] If I have lifted up my hand against the fatherless,Because I saw my help in the gate: [^21] Then let my shoulder fall from the shoulder-blade,And mine arm be broken from the bone. [^22] For calamity from God is a terror to me,And by reason of his majesty I can do nothing. [^23] If I have made gold my hope,And have said to the fine gold, Thou art my confidence; [^24] If I have rejoiced because my wealth was great,And because my hand had gotten much; [^25] If I have beheld the sun when it shined,Or the moon walking in brightness, [^26] And my heart hath been secretly enticed,And my mouth hath kissed my hand: [^27] This also were an iniquity to be punished by the judges;For I should have denied the God that is above. [^28] If I have rejoiced at the destruction of him that hated me,Or lifted up myself when evil found him [^29] (Yea, I have not suffered my mouth to sinBy asking his life with a curse); [^30] If the men of my tent have not said,Who can find one that hath not been filled with his meat? [^31] (The sojourner hath not lodged in the street;But I have opened my doors to the traveller); [^32] If like Adam I have covered my transgressions,By hiding mine iniquity in my bosom, [^33] Because I feared the great multitude,And the contempt of families terrified me,So that I kept silence, and went not out of the door— [^34] Oh that I had one to hear me!(Lo, here is my signature, let the Almighty answer me)And that I had the indictment which mine adversary hath written! [^35] Surely I would carry it upon my shoulder;I would bind it unto me as a crown: [^36] I would declare unto him the number of my steps;As a prince would I go near unto him. [^37] If my land crieth out against me,And the furrows thereof weep together; [^38] If I have eaten the fruits thereof without money,Or have caused the owners thereof to lose their life: [^39] Let thistles grow instead of wheat,And cockle instead of barley.The words of Job are ended. [^40] 

[[Job - 30|<--]] Job - 31 [[Job - 32|-->]]

---
# Notes
