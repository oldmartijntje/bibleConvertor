---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 17 - American Standard Version"
---
[[Job - 16|<--]] Job - 17 [[Job - 18|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 17

My spirit is consumed, my days are extinct,The grave is ready for me. [^1] Surely there are mockers with me,And mine eye dwelleth upon their provocation. [^2] Give now a pledge, be surety for me with thyself;Who is there that will strike hands with me? [^3] For thou hast hid their heart from understanding:Therefore shalt thou not exalt them. [^4] He that denounceth his friends for a prey,Even the eyes of his children shall fail. [^5] But he hath made me a byword of the people;And they spit in my face. [^6] Mine eye also is dim by reason of sorrow,And all my members are as a shadow. [^7] Upright men shall be astonished at this,And the innocent shall stir up himself against the godless. [^8] Yet shall the righteous hold on his way,And he that hath clean hands shall wax stronger and stronger. [^9] But as for you all, come on now again;And I shall not find a wise man among you. [^10] My days are past, my purposes are broken off,Even the thoughts of my heart. [^11] They change the night into day:The light, say they, is near unto the darkness. [^12] If I look for Sheol as my house;If I have spread my couch in the darkness; [^13] If I have said to corruption, Thou art my father;To the worm, Thou art my mother, and my sister; [^14] Where then is my hope?And as for my hope, who shall see it? [^15] It shall go down to the bars of Sheol,When once there is rest in the dust. [^16] 

[[Job - 16|<--]] Job - 17 [[Job - 18|-->]]

---
# Notes
