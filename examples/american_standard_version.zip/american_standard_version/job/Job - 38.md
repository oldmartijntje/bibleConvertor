---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 38 - American Standard Version"
---
[[Job - 37|<--]] Job - 38 [[Job - 39|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 38

Then Jehovah answered Job out of the whirlwind, and said, [^1] Who is this that darkeneth counselBy words without knowledge? [^2] Gird up now thy loins like a man;For I will demand of thee, and declare thou unto me. [^3] Where wast thou when I laid the foundations of the earth?Declare, if thou hast understanding. [^4] Who determined the measures thereof, if thou knowest?Or who stretched the line upon it? [^5] Whereupon were the foundations thereof fastened?Or who laid the corner-stone thereof, [^6] When the morning stars sang together,And all the sons of God shouted for joy? [^7] Or who shut up the sea with doors,When it brake forth, as if it had issued out of the womb; [^8] When I made clouds the garment thereof,And thick darkness a swaddling-band for it, [^9] And marked out for it my bound,And set bars and doors, [^10] And said, Hitherto shalt thou come, but no further;And here shall thy proud waves be stayed? [^11] Hast thou commanded the morning since thy days began,And caused the dayspring to know its place; [^12] That it might take hold of the ends of the earth,And the wicked be shaken out of it? [^13] It is changed as clay under the seal;And all things stand forth as a garment: [^14] And from the wicked their light is withholden,And the high arm is broken. [^15] Hast thou entered into the springs of the sea?Or hast thou walked in the recesses of the deep? [^16] Have the gates of death been revealed unto thee?Or hast thou seen the gates of the shadow of death? [^17] Hast thou comprehended the earth in its breadth?Declare, if thou knowest it all. [^18] Where is the way to the dwelling of light?And as for darkness, where is the place thereof, [^19] That thou shouldest take it to the bound thereof,And that thou shouldest discern the paths to the house thereof? [^20] Doubtless, thou knowest, for thou wast then born,And the number of thy days is great! [^21] Hast thou entered the treasuries of the snow,Or hast thou seen the treasures of the hail, [^22] Which I have reserved against the time of trouble,Against the day of battle and war? [^23] By what way is the light parted,Or the east wind scattered upon the earth? [^24] Who hath cleft a channel for the waterflood,Or the way for the lightning of the thunder; [^25] To cause it to rain on a land where no man is;On the wilderness, wherein there is no man; [^26] To satisfy the waste and desolate ground,And to cause the tender grass to spring forth? [^27] Hath the rain a father?Or who hath begotten the drops of dew? [^28] Out of whose womb came the ice?And the hoary frost of heaven, who hath gendered it? [^29] The waters hide themselves and become like stone,And the face of the deep is frozen. [^30] Canst thou bind the cluster of the Pleiades,Or loose the bands of Orion? [^31] Canst thou lead forth the Mazzaroth in their season?Or canst thou guide the Bear with her train? [^32] Knowest thou the ordinances of the heavens?Canst thou establish the dominion thereof in the earth? [^33] Canst thou lift up thy voice to the clouds,That abundance of waters may cover thee? [^34] Canst thou send forth lightnings, that they may go,And say unto thee, Here we are? [^35] Who hath put wisdom in the inward parts?Or who hath given understanding to the mind? [^36] Who can number the clouds by wisdom?Or who can pour out the bottles of heaven, [^37] When the dust runneth into a mass,And the clods cleave fast together? [^38] Canst thou hunt the prey for the lioness,Or satisfy the appetite of the young lions, [^39] When they couch in their dens,And abide in the covert to lie in wait? [^40] Who provideth for the raven his prey,When his young ones cry unto God,And wander for lack of food? [^41] 

[[Job - 37|<--]] Job - 38 [[Job - 39|-->]]

---
# Notes
