---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 39 - American Standard Version"
---
[[Job - 38|<--]] Job - 39 [[Job - 40|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 39

Knowest thou the time when the wild goats of the rock bring forth?Or canst thou mark when the hinds do calve? [^1] Canst thou number the months that they fulfil?Or knowest thou the time when they bring forth? [^2] They bow themselves, they bring forth their young,They cast out their pains. [^3] Their young ones become strong, they grow up in the open field;They go forth, and return not again. [^4] Who hath sent out the wild ass free?Or who hath loosed the bonds of the swift ass, [^5] Whose home I have made the wilderness,And the salt land his dwelling-place? [^6] He scorneth the tumult of the city,Neither heareth he the shoutings of the driver. [^7] The range of the mountains is his pasture,And he searcheth after every green thing. [^8] Will the wild-ox be content to serve thee?Or will he abide by thy crib? [^9] Canst thou bind the wild-ox with his band in the furrow?Or will he harrow the valleys after thee? [^10] Wilt thou trust him, because his strength is great?Or wilt thou leave to him thy labor? [^11] Wilt thou confide in him, that he will bring home thy seed,And gather the grain of thy threshing-floor? [^12] The wings of the ostrich wave proudly;But are they the pinions and plumage of love? [^13] For she leaveth her eggs on the earth,And warmeth them in the dust, [^14] And forgetteth that the foot may crush them,Or that the wild beast may trample them. [^15] She dealeth hardly with her young ones, as if they were not hers:Though her labor be in vain, she is without fear; [^16] Because God hath deprived her of wisdom,Neither hath he imparted to her understanding. [^17] What time she lifteth up herself on high,She scorneth the horse and his rider. [^18] Hast thou given the horse his might?Hast thou clothed his neck with the quivering mane? [^19] Hast thou made him to leap as a locust?The glory of his snorting is terrible. [^20] He paweth in the valley, and rejoiceth in his strength:He goeth out to meet the armed men. [^21] He mocketh at fear, and is not dismayed;Neither turneth he back from the sword. [^22] The quiver rattleth against him,The flashing spear and the javelin. [^23] He swalloweth the ground with fierceness and rage;Neither believeth he that it is the voice of the trumpet. [^24] As oft as the trumpet soundeth he saith, Aha!And he smelleth the battle afar off,The thunder of the captains, and the shouting. [^25] Is it by thy wisdom that the hawk soareth,And stretcheth her wings toward the south? [^26] Is it at thy command that the eagle mounteth up,And maketh her nest on high? [^27] On the cliff she dwelleth, and maketh her home,Upon the point of the cliff, and the stronghold. [^28] From thence she spieth out the prey;Her eyes behold it afar off. [^29] Her young ones also suck up blood:And where the slain are, there is she. [^30] 

[[Job - 38|<--]] Job - 39 [[Job - 40|-->]]

---
# Notes
