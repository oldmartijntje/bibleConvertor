---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 11 - American Standard Version"
---
[[Job - 10|<--]] Job - 11 [[Job - 12|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 11

Then answered Zophar the Naamathite, and said, [^1] Should not the multitude of words be answered?And should a man full of talk be justified? [^2] Should thy boastings make men hold their peace?And when thou mockest, shall no man make thee ashamed? [^3] For thou sayest, My doctrine is pure,And I am clean in thine eyes. [^4] But oh that God would speak,And open his lips against thee, [^5] And that he would show thee the secrets of wisdom!For he is manifold in understanding.Know therefore that God exacteth of thee less than thine iniquity deserveth. [^6] Canst thou by searching find out God?Canst thou find out the Almighty unto perfection? [^7] It is high as heaven; what canst thou do?Deeper than Sheol; what canst thou know? [^8] The measure thereof is longer than the earth,And broader than the sea. [^9] If he pass through, and shut up,And call unto judgment, then who can hinder him? [^10] For he knoweth false men:He seeth iniquity also, even though he consider it not. [^11] But vain man is void of understanding,Yea, man is born as a wild ass’s colt. [^12] If thou set thy heart aright,And stretch out thy hands toward him; [^13] If iniquity be in thy hand, put it far away,And let not unrighteousness dwell in thy tents. [^14] Surely then shalt thou lift up thy face without spot;Yea, thou shalt be stedfast, and shalt not fear: [^15] For thou shalt forget thy misery;Thou shalt remember it as waters that are passed away, [^16] And thy life shall be clearer than the noonday;Though there be darkness, it shall be as the morning. [^17] And thou shalt be secure, because there is hope;Yea, thou shalt search about thee, and shalt take thy rest in safety. [^18] Also thou shalt lie down, and none shall make thee afraid;Yea, many shall make suit unto thee. [^19] But the eyes of the wicked shall fail,And they shall have no way to flee;And their hope shall be the giving up of the ghost. [^20] 

[[Job - 10|<--]] Job - 11 [[Job - 12|-->]]

---
# Notes
