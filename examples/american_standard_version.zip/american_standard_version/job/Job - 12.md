---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 12 - American Standard Version"
---
[[Job - 11|<--]] Job - 12 [[Job - 13|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 12

Then Job answered and said, [^1] No doubt but ye are the people,And wisdom shall die with you. [^2] But I have understanding as well as you;I am not inferior to you:Yea, who knoweth not such things as these? [^3] I am as one that is a laughing-stock to his neighbor,I who called upon God, and he answered:The just, the perfect man is a laughing-stock. [^4] In the thought of him that is at ease there is contempt for misfortune;It is ready for them whose foot slippeth. [^5] The tents of robbers prosper,And they that provoke God are secure;Into whose hand God bringeth abundantly. [^6] But ask now the beasts, and they shall teach thee;And the birds of the heavens, and they shall tell thee: [^7] Or speak to the earth, and it shall teach thee;And the fishes of the sea shall declare unto thee. [^8] Who knoweth not in all these,That the hand of Jehovah hath wrought this, [^9] In whose hand is the soul of every living thing,And the breath of all mankind? [^10] Doth not the ear try words,Even as the palate tasteth its food? [^11] With aged men is wisdom,And in length of days understanding. [^12] With God is wisdom and might;He hath counsel and understanding. [^13] Behold, he breaketh down, and it cannot be built again;He shutteth up a man, and there can be no opening. [^14] Behold, he withholdeth the waters, and they dry up;Again, he sendeth them out, and they overturn the earth. [^15] With him is strength and wisdom;The deceived and the deceiver are his. [^16] He leadeth counsellors away stripped,And judges maketh he fools. [^17] He looseth the bond of kings,And he bindeth their loins with a girdle. [^18] He leadeth priests away stripped,And overthroweth the mighty. [^19] He removeth the speech of the trusty,And taketh away the understanding of the elders. [^20] He poureth contempt upon princes,And looseth the belt of the strong. [^21] He uncovereth deep things out of darkness,And bringeth out to light the shadow of death. [^22] He increaseth the nations, and he destroyeth them:He enlargeth the nations, and he leadeth them captive. [^23] He taketh away understanding from the chiefs of the people of the earth,And causeth them to wander in a wilderness where there is no way. [^24] They grope in the dark without light;And he maketh them to stagger like a drunken man. [^25] 

[[Job - 11|<--]] Job - 12 [[Job - 13|-->]]

---
# Notes
