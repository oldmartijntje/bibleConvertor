---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 37 - American Standard Version"
---
[[Job - 36|<--]] Job - 37 [[Job - 38|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 37

Yea, at this my heart trembleth,And is moved out of its place. [^1] Hear, oh, hear the noise of his voice,And the sound that goeth out of his mouth. [^2] He sendeth it forth under the whole heaven,And his lightning unto the ends of the earth. [^3] After it a voice roareth;He thundereth with the voice of his majesty;And he restraineth not the lightnings when his voice is heard. [^4] God thundereth marvellously with his voice;Great things doeth he, which we cannot comprehend. [^5] For he saith to the snow, Fall thou on the earth;Likewise to the shower of rain,And to the showers of his mighty rain. [^6] He sealeth up the hand of every man,That all men whom he hath made may know it. [^7] Then the beasts go into coverts,And remain in their dens. [^8] Out of the chamber of the south cometh the storm,And cold out of the north. [^9] By the breath of God ice is given;And the breadth of the waters is straitened. [^10] Yea, he ladeth the thick cloud with moisture;He spreadeth abroad the cloud of his lightning: [^11] And it is turned round about by his guidance,That they may do whatsoever he commandeth themUpon the face of the habitable world, [^12] Whether it be for correction, or for his land,Or for lovingkindness, that he cause it to come. [^13] Hearken unto this, O Job:Stand still, and consider the wondrous works of God. [^14] Dost thou know how God layeth his charge upon them,And causeth the lightning of his cloud to shine? [^15] Dost thou know the balancings of the clouds,The wondrous works of him who is perfect in knowledge? [^16] How thy garments are warm,When the earth is still by reason of the south wind? [^17] Canst thou with him spread out the sky,Which is strong as a molten mirror? [^18] Teach us what we shall say unto him;For we cannot set our speech in order by reason of darkness. [^19] Shall it be told him that I would speak?Or should a man wish that he were swallowed up? [^20] And now men see not the light which is bright in the skies;But the wind passeth, and cleareth them. [^21] Out of the north cometh golden splendor:God hath upon him terrible majesty. [^22] Touching the Almighty, we cannot find him out:He is excellent in power;And in justice and plenteous righteousness he will not afflict. [^23] Men do therefore fear him:He regardeth not any that are wise of heart. [^24] 

[[Job - 36|<--]] Job - 37 [[Job - 38|-->]]

---
# Notes
