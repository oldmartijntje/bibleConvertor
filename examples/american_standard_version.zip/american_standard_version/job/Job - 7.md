---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 7 - American Standard Version"
---
[[Job - 6|<--]] Job - 7 [[Job - 8|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 7

Is there not a warfare to man upon earth?And are not his days like the days of a hireling? [^1] As a servant that earnestly desireth the shadow,And as a hireling that looketh for his wages: [^2] So am I made to possess months of misery,And wearisome nights are appointed to me. [^3] When I lie down, I say,When shall I arise, and the night be gone?And I am full of tossings to and fro unto the dawning of the day. [^4] My flesh is clothed with worms and clods of dust;My skin closeth up, and breaketh out afresh. [^5] My days are swifter than a weaver’s shuttle,And are spent without hope. [^6] Oh remember that my life is a breath:Mine eye shall no more see good. [^7] The eye of him that seeth me shall behold me no more;Thine eyes shall be upon me, but I shall not be. [^8] As the cloud is consumed and vanisheth away,So he that goeth down to Sheol shall come up no more. [^9] He shall return no more to his house,Neither shall his place know him any more. [^10] Therefore I will not refrain my mouth;I will speak in the anguish of my spirit;I will complain in the bitterness of my soul. [^11] Am I a sea, or a sea-monster,That thou settest a watch over me? [^12] When I say, My bed shall comfort me,My couch shall ease my complaint; [^13] Then thou scarest me with dreams,And terrifiest me through visions: [^14] So that my soul chooseth strangling,And death rather than these my bones. [^15] I loathe my life; I would not live alway:Let me alone; for my days are vanity. [^16] What is man, that thou shouldest magnify him,And that thou shouldest set thy mind upon him, [^17] And that thou shouldest visit him every morning,And try him every moment? [^18] How long wilt thou not look away from me,Nor let me alone till I swallow down my spittle? [^19] If I have sinned, what do I unto thee, O thou watcher of men?Why hast thou set me as a mark for thee,So that I am a burden to myself? [^20] And why dost thou not pardon my transgression, and take away mine iniquity?For now shall I lie down in the dust;And thou wilt seek me diligently, but I shall not be. [^21] 

[[Job - 6|<--]] Job - 7 [[Job - 8|-->]]

---
# Notes
