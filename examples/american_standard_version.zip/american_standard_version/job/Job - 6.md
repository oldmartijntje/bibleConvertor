---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 6 - American Standard Version"
---
[[Job - 5|<--]] Job - 6 [[Job - 7|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 6

Then Job answered and said, [^1] Oh that my vexation were but weighed,And all my calamity laid in the balances! [^2] For now it would be heavier than the sand of the seas:Therefore have my words been rash. [^3] For the arrows of the Almighty are within me,The poison whereof my spirit drinketh up:The terrors of God do set themselves in array against me. [^4] Doth the wild ass bray when he hath grass?Or loweth the ox over his fodder? [^5] Can that which hath no savor be eaten without salt?Or is there any taste in the white of an egg? [^6] My soul refuseth to touch them;They are as loathsome food to me. [^7] Oh that I might have my request;And that God would grant me the thing that I long for! [^8] Even that it would please God to crush me;That he would let loose his hand, and cut me off! [^9] And be it still my consolation,Yea, let me exult in pain that spareth not,That I have not denied the words of the Holy One. [^10] What is my strength, that I should wait?And what is mine end, that I should be patient? [^11] Is my strength the strength of stones?Or is my flesh of brass? [^12] Is it not that I have no help in me,And that wisdom is driven quite from me? [^13] To him that is ready to faint kindness should be showed from his friend;Even to him that forsaketh the fear of the Almighty. [^14] My brethren have dealt deceitfully as a brook,As the channel of brooks that pass away; [^15] Which are black by reason of the ice,And wherein the snow hideth itself: [^16] What time they wax warm, they vanish;When it is hot, they are consumed out of their place. [^17] The caravans that travel by the way of them turn aside;They go up into the waste, and perish. [^18] The caravans of Tema looked,The companies of Sheba waited for them. [^19] They were put to shame because they had hoped;They came thither, and were confounded. [^20] For now ye are nothing;Ye see a terror, and are afraid. [^21] Did I say, Give unto me?Or, Offer a present for me of your substance? [^22] Or, Deliver me from the adversary’s hand?Or, Redeem me from the hand of the oppressors? [^23] Teach me, and I will hold my peace;And cause me to understand wherein I have erred. [^24] How forcible are words of uprightness!But your reproof, what doth it reprove? [^25] Do ye think to reprove words,Seeing that the speeches of one that is desperate are as wind? [^26] Yea, ye would cast lots upon the fatherless,And make merchandise of your friend. [^27] Now therefore be pleased to look upon me;For surely I shall not lie to your face. [^28] Return, I pray you, let there be no injustice;Yea, return again, my cause is righteous. [^29] Is there injustice on my tongue?Cannot my taste discern mischievous things? [^30] 

[[Job - 5|<--]] Job - 6 [[Job - 7|-->]]

---
# Notes
