---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 25 - American Standard Version"
---
[[Job - 24|<--]] Job - 25 [[Job - 26|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 25

Then answered Bildad the Shuhite, and said, [^1] Dominion and fear are with him;He maketh peace in his high places. [^2] Is there any number of his armies?And upon whom doth not his light arise? [^3] How then can man be just with God?Or how can he be clean that is born of a woman? [^4] Behold, even the moon hath no brightness,And the stars are not pure in his sight: [^5] How much less man, that is a worm!And the son of man, that is a worm! [^6] 

[[Job - 24|<--]] Job - 25 [[Job - 26|-->]]

---
# Notes
