---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 28 - American Standard Version"
---
[[Job - 27|<--]] Job - 28 [[Job - 29|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 28

Surely there is a mine for silver,And a place for gold which they refine. [^1] Iron is taken out of the earth,And copper is molten out of the stone. [^2] Man setteth an end to darkness,And searcheth out, to the furthest bound,The stones of obscurity and of thick darkness. [^3] He breaketh open a shaft away from where men sojourn;They are forgotten of the foot;They hang afar from men, they swing to and fro. [^4] As for the earth, out of it cometh bread;And underneath it is turned up as it were by fire. [^5] The stones thereof are the place of sapphires,And it hath dust of gold. [^6] That path no bird of prey knoweth,Neither hath the falcon’s eye seen it: [^7] The proud beasts have not trodden it,Nor hath the fierce lion passed thereby. [^8] He putteth forth his hand upon the flinty rock;He overturneth the mountains by the roots. [^9] He cutteth out channels among the rocks;And his eye seeth every precious thing. [^10] He bindeth the streams that they trickle not;And the thing that is hid bringeth he forth to light. [^11] But where shall wisdom be found?And where is the place of understanding? [^12] Man knoweth not the price thereof;Neither is it found in the land of the living. [^13] The deep saith, It is not in me;And the sea saith, It is not with me. [^14] It cannot be gotten for gold,Neither shall silver be weighed for the price thereof. [^15] It cannot be valued with the gold of Ophir,With the precious onyx, or the sapphire. [^16] Gold and glass cannot equal it,Neither shall it be exchanged for jewels of fine gold. [^17] No mention shall be made of coral or of crystal:Yea, the price of wisdom is above rubies. [^18] The topaz of Ethiopia shall not equal it,Neither shall it be valued with pure gold. [^19] Whence then cometh wisdom?And where is the place of understanding? [^20] Seeing it is hid from the eyes of all living,And kept close from the birds of the heavens. [^21] Destruction and Death say,We have heard a rumor thereof with our ears. [^22] God understandeth the way thereof,And he knoweth the place thereof. [^23] For he looketh to the ends of the earth,And seeth under the whole heaven; [^24] To make a weight for the wind:Yea, he meteth out the waters by measure. [^25] When he made a decree for the rain,And a way for the lightning of the thunder; [^26] Then did he see it, and declare it;He established it, yea, and searched it out. [^27] And unto man he said,Behold, the fear of the Lord, that is wisdom;And to depart from evil is understanding. [^28] 

[[Job - 27|<--]] Job - 28 [[Job - 29|-->]]

---
# Notes
