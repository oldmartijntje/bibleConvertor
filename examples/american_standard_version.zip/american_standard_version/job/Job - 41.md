---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 41 - American Standard Version"
---
[[Job - 40|<--]] Job - 41 [[Job - 42|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 41

Canst thou draw out leviathan with a fishhook?Or press down his tongue with a cord? [^1] Canst thou put a rope into his nose?Or pierce his jaw through with a hook? [^2] Will he make many supplications unto thee?Or will he speak soft words unto thee? [^3] Will he make a covenant with thee,That thou shouldest take him for a servant for ever? [^4] Wilt thou play with him as with a bird?Or wilt thou bind him for thy maidens? [^5] Will the bands of fishermen make traffic of him?Will they part him among the merchants? [^6] Canst thou fill his skin with barbed irons,Or his head with fish-spears? [^7] Lay thy hand upon him;Remember the battle, and do so no more. [^8] Behold, the hope of him is in vain:Will not one be cast down even at the sight of him? [^9] None is so fierce that he dare stir him up;Who then is he that can stand before me? [^10] Who hath first given unto me, that I should repay him?Whatsoever is under the whole heaven is mine. [^11] I will not keep silence concerning his limbs,Nor his mighty strength, nor his goodly frame. [^12] Who can strip off his outer garment?Who shall come within his jaws? [^13] Who can open the doors of his face?Round about his teeth is terror. [^14] His strong scales are his pride,Shut up together as with a close seal. [^15] One is so near to another,That no air can come between them. [^16] They are joined one to another;They stick together, so that they cannot be sundered. [^17] His sneezings flash forth light,And his eyes are like the eyelids of the morning. [^18] Out of his mouth go burning torches,And sparks of fire leap forth. [^19] Out of his nostrils a smoke goeth,As of a boiling pot and burning rushes. [^20] His breath kindleth coals,And a flame goeth forth from his mouth. [^21] In his neck abideth strength,And terror danceth before him. [^22] The flakes of his flesh are joined together:They are firm upon him; they cannot be moved. [^23] His heart is as firm as a stone;Yea, firm as the nether millstone. [^24] When he raiseth himself up, the mighty are afraid:By reason of consternation they are beside themselves. [^25] If one lay at him with the sword, it cannot avail;Nor the spear, the dart, nor the pointed shaft. [^26] He counteth iron as straw,And brass as rotten wood. [^27] The arrow cannot make him flee:Sling-stones are turned with him into stubble. [^28] Clubs are counted as stubble:He laugheth at the rushing of the javelin. [^29] His underparts are like sharp potsherds:He spreadeth as it were a threshing-wain upon the mire. [^30] He maketh the deep to boil like a pot:He maketh the sea like a pot of ointment. [^31] He maketh a path to shine after him;One would think the deep to be hoary. [^32] Upon earth there is not his like,That is made without fear. [^33] He beholdeth everything that is high:He is king over all the sons of pride. [^34] 

[[Job - 40|<--]] Job - 41 [[Job - 42|-->]]

---
# Notes
