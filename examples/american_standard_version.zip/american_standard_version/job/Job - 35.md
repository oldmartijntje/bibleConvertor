---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 35 - American Standard Version"
---
[[Job - 34|<--]] Job - 35 [[Job - 36|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 35

Moreover Elihu answered and said, [^1] Thinkest thou this to be thy right,Or sayest thou, My righteousness is more than God’s, [^2] That thou sayest, What advantage will it be unto thee?And, What profit shall I have, more than if I had sinned? [^3] I will answer thee,And thy companions with thee. [^4] Look unto the heavens, and see;And behold the skies, which are higher than thou. [^5] If thou hast sinned, what effectest thou against him?And if thy transgressions be multiplied, what doest thou unto him? [^6] If thou be righteous, what givest thou him?Or what receiveth he of thy hand? [^7] Thy wickedness may hurt a man as thou art;And thy righteousness may profit a son of man. [^8] By reason of the multitude of oppressions they cry out;They cry for help by reason of the arm of the mighty. [^9] But none saith, Where is God my Maker,Who giveth songs in the night, [^10] Who teacheth us more than the beasts of the earth,And maketh us wiser than the birds of the heavens? [^11] There they cry, but none giveth answer,Because of the pride of evil men. [^12] Surely God will not hear an empty cry,Neither will the Almighty regard it. [^13] How much less when thou sayest thou beholdest him not,The cause is before him, and thou waitest for him! [^14] But now, because he hath not visited in his anger,Neither doth he greatly regard arrogance; [^15] Therefore doth Job open his mouth in vanity;He multiplieth words without knowledge. [^16] 

[[Job - 34|<--]] Job - 35 [[Job - 36|-->]]

---
# Notes
