---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 21 - American Standard Version"
---
[[Job - 20|<--]] Job - 21 [[Job - 22|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 21

Then Job answered and said, [^1] Hear diligently my speech;And let this be your consolations. [^2] Suffer me, and I also will speak;And after that I have spoken, mock on. [^3] As for me, is my complaint to man?And why should I not be impatient? [^4] Mark me, and be astonished,And lay your hand upon your mouth. [^5] Even when I remember I am troubled,And horror taketh hold on my flesh. [^6] Wherefore do the wicked live,Become old, yea, wax mighty in power? [^7] Their seed is established with them in their sight,And their offspring before their eyes. [^8] Their houses are safe from fear,Neither is the rod of God upon them. [^9] Their bull gendereth, and faileth not;Their cow calveth, and casteth not her calf. [^10] They send forth their little ones like a flock,And their children dance. [^11] They sing to the timbrel and harp,And rejoice at the sound of the pipe. [^12] They spend their days in prosperity,And in a moment they go down to Sheol. [^13] And they say unto God, Depart from us;For we desire not the knowledge of thy ways. [^14] What is the Almighty, that we should serve him?And what profit should we have, if we pray unto him? [^15] Lo, their prosperity is not in their hand:The counsel of the wicked is far from me. [^16] How oft is it that the lamp of the wicked is put out?That their calamity cometh upon them?That God distributeth sorrows in his anger? [^17] That they are as stubble before the wind,And as chaff that the storm carrieth away? [^18] Ye say, God layeth up his iniquity for his children.Let him recompense it unto himself, that he may know it: [^19] Let his own eyes see his destruction,And let him drink of the wrath of the Almighty. [^20] For what careth he for his house after him,When the number of his months is cut off? [^21] Shall any teach God knowledge,Seeing he judgeth those that are high? [^22] One dieth in his full strength,Being wholly at ease and quiet: [^23] His pails are full of milk,And the marrow of his bones is moistened. [^24] And another dieth in bitterness of soul,And never tasteth of good. [^25] They lie down alike in the dust,And the worm covereth them. [^26] Behold, I know your thoughts,And the devices wherewith ye would wrong me. [^27] For ye say, Where is the house of the prince?And where is the tent wherein the wicked dwelt? [^28] Have ye not asked wayfaring men?And do ye not know their evidences, [^29] That the evil man is reserved to the day of calamity?That they are led forth to the day of wrath? [^30] Who shall declare his way to his face?And who shall repay him what he hath done? [^31] Yet shall he be borne to the grave,And men shall keep watch over the tomb. [^32] The clods of the valley shall be sweet unto him,And all men shall draw after him,As there were innumerable before him. [^33] How then comfort ye me in vain,Seeing in your answers there remaineth only falsehood? [^34] 

[[Job - 20|<--]] Job - 21 [[Job - 22|-->]]

---
# Notes
