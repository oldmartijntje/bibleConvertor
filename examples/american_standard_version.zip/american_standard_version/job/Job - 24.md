---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 24 - American Standard Version"
---
[[Job - 23|<--]] Job - 24 [[Job - 25|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 24

Why are times not laid up by the Almighty?And why do not they that know him see his days? [^1] There are that remove the landmarks;They violently take away flocks, and feed them. [^2] They drive away the ass of the fatherless;They take the widow’s ox for a pledge. [^3] They turn the needy out of the way:The poor of the earth all hide themselves. [^4] Behold, as wild asses in the desertThey go forth to their work, seeking diligently for food;The wilderness yieldeth them bread for their children. [^5] They cut their provender in the field;And they glean the vintage of the wicked. [^6] They lie all night naked without clothing,And have no covering in the cold. [^7] They are wet with the showers of the mountains,And embrace the rock for want of a shelter. [^8] There are that pluck the fatherless from the breast,And take a pledge of the poor; [^9] So that they go about naked without clothing,And being hungry they carry the sheaves. [^10] They make oil within the walls of these men;They tread their winepresses, and suffer thirst. [^11] From out of the populous city men groan,And the soul of the wounded crieth out:Yet God regardeth not the folly. [^12] These are of them that rebel against the light;They know not the ways thereof,Nor abide in the paths thereof. [^13] The murderer riseth with the light;He killeth the poor and needy;And in the night he is as a thief. [^14] The eye also of the adulterer waiteth for the twilight,Saying, No eye shall see me:And he disguiseth his face. [^15] In the dark they dig through houses:They shut themselves up in the day-time;They know not the light. [^16] For the morning is to all of them as thick darkness;For they know the terrors of the thick darkness. [^17] Swiftly they pass away upon the face of the waters;Their portion is cursed in the earth:They turn not into the way of the vineyards. [^18] Drought and heat consume the snow waters:So doth Sheol those that have sinned. [^19] The womb shall forget him;The worm shall feed sweetly on him;He shall be no more remembered;And unrighteousness shall be broken as a tree. [^20] He devoureth the barren that beareth not,And doeth not good to the widow. [^21] Yet God preserveth the mighty by his power:He riseth up that hath no assurance of life. [^22] God giveth them to be in security, and they rest thereon;And his eyes are upon their ways. [^23] They are exalted; yet a little while, and they are gone;Yea, they are brought low, they are taken out of the way as all others,And are cut off as the tops of the ears of grain. [^24] And if it be not so now, who will prove me a liar,And make my speech nothing worth? [^25] 

[[Job - 23|<--]] Job - 24 [[Job - 25|-->]]

---
# Notes
