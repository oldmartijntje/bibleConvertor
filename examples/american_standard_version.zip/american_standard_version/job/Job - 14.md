---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 14 - American Standard Version"
---
[[Job - 13|<--]] Job - 14 [[Job - 15|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 14

Man, that is born of a woman,Is of few days, and full of trouble. [^1] He cometh forth like a flower, and is cut down:He fleeth also as a shadow, and continueth not. [^2] And dost thou open thine eyes upon such a one,And bringest me into judgment with thee? [^3] Who can bring a clean thing out of an unclean? not one. [^4] Seeing his days are determined,The number of his months is with thee,And thou hast appointed his bounds that he cannot pass; [^5] Look away from him, that he may rest,Till he shall accomplish, as a hireling, his day. [^6] For there is hope of a tree,If it be cut down, that it will sprout again,And that the tender branch thereof will not cease. [^7] Though the root thereof wax old in the earth,And the stock thereof die in the ground; [^8] Yet through the scent of water it will bud,And put forth boughs like a plant. [^9] But man dieth, and is laid low:Yea, man giveth up the ghost, and where is he? [^10] As the waters fail from the sea,And the river wasteth and drieth up; [^11] So man lieth down and riseth not:Till the heavens be no more, they shall not awake,Nor be roused out of their sleep. [^12] Oh that thou wouldest hide me in Sheol,That thou wouldest keep me secret, until thy wrath be past,That thou wouldest appoint me a set time, and remember me! [^13] If a man die, shall he live again?All the days of my warfare would I wait,Till my release should come. [^14] Thou wouldest call, and I would answer thee:Thou wouldest have a desire to the work of thy hands. [^15] But now thou numberest my steps:Dost thou not watch over my sin? [^16] My transgression is sealed up in a bag,And thou fastenest up mine iniquity. [^17] But the mountain falling cometh to nought;And the rock is removed out of its place; [^18] The waters wear the stones;The overflowings thereof wash away the dust of the earth:So thou destroyest the hope of man. [^19] Thou prevailest for ever against him, and he passeth;Thou changest his countenance, and sendest him away. [^20] His sons come to honor, and he knoweth it not;And they are brought low, but he perceiveth it not of them. [^21] But his flesh upon him hath pain,And his soul within him mourneth. [^22] 

[[Job - 13|<--]] Job - 14 [[Job - 15|-->]]

---
# Notes
