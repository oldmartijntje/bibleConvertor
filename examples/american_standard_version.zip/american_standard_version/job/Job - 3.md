---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 3 - American Standard Version"
---
[[Job - 2|<--]] Job - 3 [[Job - 4|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 3

After this opened Job his mouth, and cursed his day. [^1] And Job answered and said: [^2] Let the day perish wherein I was born,And the night which said, There is a man-child conceived. [^3] Let that day be darkness;Let not God from above seek for it,Neither let the light shine upon it. [^4] Let darkness and the shadow of death claim it for their own;Let a cloud dwell upon it;Let all that maketh black the day terrify it. [^5] As for that night, let thick darkness seize upon it:Let it not rejoice among the days of the year;Let it not come into the number of the months. [^6] Lo, let that night be barren;Let no joyful voice come therein. [^7] Let them curse it that curse the day,Who are ready to rouse up leviathan. [^8] Let the stars of the twilight thereof be dark:Let it look for light, but have none;Neither let it behold the eyelids of the morning: [^9] Because it shut not up the doors of my mother’s womb,Nor hid trouble from mine eyes. [^10] Why died I not from the womb?Why did I not give up the ghost when my mother bare me? [^11] Why did the knees receive me?Or why the breasts, that I should suck? [^12] For now should I have lain down and been quiet;I should have slept; then had I been at rest, [^13] With kings and counsellors of the earth,Who built up waste places for themselves; [^14] Or with princes that had gold,Who filled their houses with silver: [^15] Or as a hidden untimely birth I had not been,As infants that never saw light. [^16] There the wicked cease from troubling;And there the weary are at rest. [^17] There the prisoners are at ease together;They hear not the voice of the taskmaster. [^18] The small and the great are there:And the servant is free from his master. [^19] Wherefore is light given to him that is in misery,And life unto the bitter in soul; [^20] Who long for death, but it cometh not,And dig for it more than for hid treasures; [^21] Who rejoice exceedingly,And are glad, when they can find the grave? [^22] Why is light given to a man whose way is hid,And whom God hath hedged in? [^23] For my sighing cometh before I eat,And my groanings are poured out like water. [^24] For the thing which I fear cometh upon me,And that which I am afraid of cometh unto me. [^25] I am not at ease, neither am I quiet, neither have I rest;But trouble cometh. [^26] 

[[Job - 2|<--]] Job - 3 [[Job - 4|-->]]

---
# Notes
