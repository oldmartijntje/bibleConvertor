---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 23 - American Standard Version"
---
[[Job - 22|<--]] Job - 23 [[Job - 24|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 23

Then Job answered and said, [^1] Even to-day is my complaint rebellious:My stroke is heavier than my groaning. [^2] Oh that I knew where I might find him!That I might come even to his seat! [^3] I would set my cause in order before him,And fill my mouth with arguments. [^4] I would know the words which he would answer me,And understand what he would say unto me. [^5] Would he contend with me in the greatness of his power?Nay; but he would give heed unto me. [^6] There the upright might reason with him;So should I be delivered for ever from my judge. [^7] Behold, I go forward, but he is not there;And backward, but I cannot perceive him; [^8] On the left hand, when he doth work, but I cannot behold him;He hideth himself on the right hand, that I cannot see him. [^9] But he knoweth the way that I take;When he hath tried me, I shall come forth as gold. [^10] My foot hath held fast to his steps;His way have I kept, and turned not aside. [^11] I have not gone back from the commandment of his lips;I have treasured up the words of his mouth more than my necessary food. [^12] But he is in one mind, and who can turn him?And what his soul desireth, even that he doeth. [^13] For he performeth that which is appointed for me:And many such things are with him. [^14] Therefore am I terrified at his presence;When I consider, I am afraid of him. [^15] For God hath made my heart faint,And the Almighty hath terrified me; [^16] Because I was not cut off before the darkness,Neither did he cover the thick darkness from my face. [^17] 

[[Job - 22|<--]] Job - 23 [[Job - 24|-->]]

---
# Notes
