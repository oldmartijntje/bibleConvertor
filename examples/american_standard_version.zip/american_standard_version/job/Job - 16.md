---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 16 - American Standard Version"
---
[[Job - 15|<--]] Job - 16 [[Job - 17|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 16

Then Job answered and said, [^1] I have heard many such things:Miserable comforters are ye all. [^2] Shall vain words have an end?Or what provoketh thee that thou answerest? [^3] I also could speak as ye do;If your soul were in my soul’s stead,I could join words together against you,And shake my head at you. [^4] But I would strengthen you with my mouth,And the solace of my lips would assuage your grief. [^5] Though I speak, my grief is not assuaged;And though I forbear, what am I eased? [^6] But now he hath made me weary:Thou hast made desolate all my company. [^7] And thou hast laid fast hold on me, which is a witness against me:And my leanness riseth up against me,It testifieth to my face. [^8] He hath torn me in his wrath, and persecuted me;He hath gnashed upon me with his teeth:Mine adversary sharpeneth his eyes upon me. [^9] They have gaped upon me with their mouth;They have smitten me upon the cheek reproachfully:They gather themselves together against me. [^10] God delivereth me to the ungodly,And casteth me into the hands of the wicked. [^11] I was at ease, and he brake me asunder;Yea, he hath taken me by the neck, and dashed me to pieces:He hath also set me up for his mark. [^12] His archers compass me round about;He cleaveth my reins asunder, and doth not spare;He poureth out my gall upon the ground. [^13] He breaketh me with breach upon breach;He runneth upon me like a giant. [^14] I have sewed sackcloth upon my skin,And have laid my horn in the dust. [^15] My face is red with weeping,And on my eyelids is the shadow of death; [^16] Although there is no violence in my hands,And my prayer is pure. [^17] O earth, cover not thou my blood,And let my cry have no resting-place. [^18] Even now, behold, my witness is in heaven,And he that voucheth for me is on high. [^19] My friends scoff at me:But mine eye poureth out tears unto God, [^20] That he would maintain the right of a man with God,And of a son of man with his neighbor! [^21] For when a few years are come,I shall go the way whence I shall not return. [^22] 

[[Job - 15|<--]] Job - 16 [[Job - 17|-->]]

---
# Notes
