---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 2 - American Standard Version"
---
[[Job - 1|<--]] Job - 2 [[Job - 3|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 2

Again it came to pass on the day when the sons of God came to present themselves before Jehovah, that Satan came also among them to present himself before Jehovah. [^1] And Jehovah said unto Satan, From whence comest thou? And Satan answered Jehovah, and said, From going to and fro in the earth, and from walking up and down in it. [^2] And Jehovah said unto Satan, Hast thou considered my servant Job? for there is none like him in the earth, a perfect and an upright man, one that feareth God, and turneth away from evil: and he still holdeth fast his integrity, although thou movedst me against him, to destroy him without cause. [^3] And Satan answered Jehovah, and said, Skin for skin, yea, all that a man hath will he give for his life. [^4] But put forth thy hand now, and touch his bone and his flesh, and he will renounce thee to thy face. [^5] And Jehovah said unto Satan, Behold, he is in thy hand; only spare his life. [^6] So Satan went forth from the presence of Jehovah, and smote Job with sore boils from the sole of his foot unto his crown. [^7] And he took him a potsherd to scrape himself therewith; and he sat among the ashes. [^8] Then said his wife unto him, Dost thou still hold fast thine integrity? renounce God, and die. [^9] But he said unto her, Thou speakest as one of the foolish women speaketh. What? shall we receive good at the hand of God, and shall we not receive evil? In all this did not Job sin with his lips. [^10] Now when Job’s three friends heard of all this evil that was come upon him, they came every one from his own place: Eliphaz the Temanite, and Bildad the Shuhite, and Zophar the Naamathite; and they made an appointment together to come to bemoan him and to comfort him. [^11] And when they lifted up their eyes afar off, and knew him not, they lifted up their voice, and wept; and they rent every one his robe, and sprinkled dust upon their heads toward heaven. [^12] So they sat down with him upon the ground seven days and seven nights, and none spake a word unto him: for they saw that his grief was very great. [^13] 

[[Job - 1|<--]] Job - 2 [[Job - 3|-->]]

---
# Notes
