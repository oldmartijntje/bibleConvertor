---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 34 - American Standard Version"
---
[[Job - 33|<--]] Job - 34 [[Job - 35|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 34

Moreover Elihu answered and said, [^1] Hear my words, ye wise men;And give ear unto me, ye that have knowledge. [^2] For the ear trieth words,As the palate tasteth food. [^3] Let us choose for us that which is right:Let us know among ourselves what is good. [^4] For Job hath said, I am righteous,And God hath taken away my right: [^5] Notwithstanding my right I am accounted a liar;My wound is incurable, though I am without transgression. [^6] What man is like Job,Who drinketh up scoffing like water, [^7] Who goeth in company with the workers of iniquity,And walketh with wicked men? [^8] For he hath said, It profiteth a man nothingThat he should delight himself with God. [^9] Therefore hearken unto me, ye men of understanding:Far be it from God, that he should do wickedness,And from the Almighty, that he should commit iniquity. [^10] For the work of a man will he render unto him,And cause every man to find according to his ways. [^11] Yea, of a surety, God will not do wickedly,Neither will the Almighty pervert justice. [^12] Who gave him a charge over the earth?Or who hath disposed the whole world? [^13] If he set his heart upon himself,If he gather unto himself his spirit and his breath; [^14] All flesh shall perish together,And man shall turn again unto dust. [^15] If now thou hast understanding, hear this:Hearken to the voice of my words. [^16] Shall even one that hateth justice govern?And wilt thou condemn him that is righteous and mighty?— [^17] Him that saith to a king, Thou art vile,Or to nobles, Ye are wicked; [^18] That respecteth not the persons of princes,Nor regardeth the rich more than the poor;For they all are the work of his hands. [^19] In a moment they die, even at midnight;The people are shaken and pass away,And the mighty are taken away without hand. [^20] For his eyes are upon the ways of a man,And he seeth all his goings. [^21] There is no darkness, nor thick gloom,Where the workers of iniquity may hide themselves. [^22] For he needeth not further to consider a man,That he should go before God in judgment. [^23] He breaketh in pieces mighty men in ways past finding out,And setteth others in their stead. [^24] Therefore he taketh knowledge of their works;And he overturneth them in the night, so that they are destroyed. [^25] He striketh them as wicked menIn the open sight of others; [^26] Because they turned aside from following him,And would not have regard in any of his ways: [^27] So that they caused the cry of the poor to come unto him,And he heard the cry of the afflicted. [^28] When he giveth quietness, who then can condemn?And when he hideth his face, who then can behold him?Alike whether it be done unto a nation, or unto a man: [^29] That the godless man reign not,That there be none to ensnare the people. [^30] For hath any said unto God,I have borne chastisement, I will not offend any more: [^31] That which I see not teach thou me:If I have done iniquity, I will do it no more? [^32] Shall his recompense be as thou wilt, that thou refusest it?For thou must choose, and not I:Therefore speak what thou knowest. [^33] Men of understanding will say unto me,Yea, every wise man that heareth me: [^34] Job speaketh without knowledge,And his words are without wisdom. [^35] Would that Job were tried unto the end,Because of his answering like wicked men. [^36] For he addeth rebellion unto his sin;He clappeth his hands among us,And multiplieth his words against God. [^37] 

[[Job - 33|<--]] Job - 34 [[Job - 35|-->]]

---
# Notes
