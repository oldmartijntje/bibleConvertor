---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 18 - American Standard Version"
---
[[Job - 17|<--]] Job - 18 [[Job - 19|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 18

Then answered Bildad the Shuhite, and said, [^1] How long will ye hunt for words?Consider, and afterwards we will speak. [^2] Wherefore are we counted as beasts,And are become unclean in your sight? [^3] Thou that tearest thyself in thine anger,Shall the earth be forsaken for thee?Or shall the rock be removed out of its place? [^4] Yea, the light of the wicked shall be put out,And the spark of his fire shall not shine. [^5] The light shall be dark in his tent,And his lamp above him shall be put out. [^6] The steps of his strength shall be straitened,And his own counsel shall cast him down. [^7] For he is cast into a net by his own feet,And he walketh upon the toils. [^8] A gin shall take him by the heel,And a snare shall lay hold on him. [^9] A noose is hid for him in the ground,And a trap for him in the way. [^10] Terrors shall make him afraid on every side,And shall chase him at his heels. [^11] His strength shall be hunger-bitten,And calamity shall be ready at his side. [^12] The members of his body shall be devoured,Yea, the first-born of death shall devour his members. [^13] He shall be rooted out of his tent wherein he trusteth;And he shall be brought to the king of terrors. [^14] There shall dwell in his tent that which is none of his:Brimstone shall be scattered upon his habitation. [^15] His roots shall be dried up beneath,And above shall his branch be cut off. [^16] His remembrance shall perish from the earth,And he shall have no name in the street. [^17] He shall be driven from light into darkness,And chased out of the world. [^18] He shall have neither son nor son’s son among his people,Nor any remaining where he sojourned. [^19] They that come after shall be astonished at his day,As they that went before were affrighted. [^20] Surely such are the dwellings of the unrighteous,And this is the place of him that knoweth not God. [^21] 

[[Job - 17|<--]] Job - 18 [[Job - 19|-->]]

---
# Notes
