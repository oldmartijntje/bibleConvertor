---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 9 - American Standard Version"
---
[[Job - 8|<--]] Job - 9 [[Job - 10|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 9

Then Job answered and said, [^1] Of a truth I know that it is so:But how can man be just with God? [^2] If he be pleased to contend with him,He cannot answer him one of a thousand. [^3] He is wise in heart, and mighty in strength:Who hath hardened himself against him, and prospered?— [^4] Him that removeth the mountains, and they know it not,When he overturneth them in his anger; [^5] That shaketh the earth out of its place,And the pillars thereof tremble; [^6] That commandeth the sun, and it riseth not,And sealeth up the stars; [^7] That alone stretcheth out the heavens,And treadeth upon the waves of the sea; [^8] That maketh the Bear, Orion, and the Pleiades,And the chambers of the south; [^9] That doeth great things past finding out,Yea, marvellous things without number. [^10] Lo, he goeth by me, and I see him not:He passeth on also, but I perceive him not. [^11] Behold, he seizeth the prey, who can hinder him?Who will say unto him, What doest thou? [^12] God will not withdraw his anger;The helpers of Rahab do stoop under him. [^13] How much less shall I answer him,And choose out my words to reason with him? [^14] Whom, though I were righteous, yet would I not answer;I would make supplication to my judge. [^15] If I had called, and he had answered me,Yet would I not believe that he hearkened unto my voice. [^16] For he breaketh me with a tempest,And multiplieth my wounds without cause. [^17] He will not suffer me to take my breath,But filleth me with bitterness. [^18] If we speak of strength, lo, he is mighty!And if of justice, Who, saith he, will summon me? [^19] Though I be righteous, mine own mouth shall condemn me:Though I be perfect, it shall prove me perverse. [^20] I am perfect; I regard not myself;I despise my life. [^21] It is all one; therefore I say,He destroyeth the perfect and the wicked. [^22] If the scourge slay suddenly,He will mock at the trial of the innocent. [^23] The earth is given into the hand of the wicked;He covereth the faces of the judges thereof:If it be not he, who then is it? [^24] Now my days are swifter than a post:They flee away, they see no good. [^25] They are passed away as the swift ships;As the eagle that swoopeth on the prey. [^26] If I say, I will forget my complaint,I will put off my sad countenance, and be of good cheer; [^27] I am afraid of all my sorrows,I know that thou wilt not hold me innocent. [^28] I shall be condemned;Why then do I labor in vain? [^29] If I wash myself with snow water,And make my hands never so clean; [^30] Yet wilt thou plunge me in the ditch,And mine own clothes shall abhor me. [^31] For he is not a man, as I am, that I should answer him,That we should come together in judgment. [^32] There is no umpire betwixt us,That might lay his hand upon us both. [^33] Let him take his rod away from me,And let not his terror make me afraid: [^34] Then would I speak, and not fear him;For I am not so in myself. [^35] 

[[Job - 8|<--]] Job - 9 [[Job - 10|-->]]

---
# Notes
