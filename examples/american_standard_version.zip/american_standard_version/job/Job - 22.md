---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 22 - American Standard Version"
---
[[Job - 21|<--]] Job - 22 [[Job - 23|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 22

Then answered Eliphaz the Temanite, and said, [^1] Can a man be profitable unto God?Surely he that is wise is profitable unto himself. [^2] Is it any pleasure to the Almighty, that thou art righteous?Or is it gain to him, that thou makest thy ways perfect? [^3] Is it for thy fear of him that he reproveth thee,That he entereth with thee into judgment? [^4] Is not thy wickedness great?Neither is there any end to thine iniquities. [^5] For thou hast taken pledges of thy brother for nought,And stripped the naked of their clothing. [^6] Thou hast not given water to the weary to drink,And thou hast withholden bread from the hungry. [^7] But as for the mighty man, he had the earth;And the honorable man, he dwelt in it. [^8] Thou hast sent widows away empty,And the arms of the fatherless have been broken. [^9] Therefore snares are round about thee,And sudden fear troubleth thee, [^10] Or darkness, so that thou canst not see,And abundance of waters cover thee. [^11] Is not God in the height of heaven?And behold the height of the stars, how high they are! [^12] And thou sayest, What doth God know?Can he judge through the thick darkness? [^13] Thick clouds are a covering to him, so that he seeth not;And he walketh on the vault of heaven. [^14] Wilt thou keep the old wayWhich wicked men have trodden? [^15] Who were snatched away before their time,Whose foundation was poured out as a stream, [^16] Who said unto God, Depart from us;And, What can the Almighty do for us? [^17] Yet he filled their houses with good things:But the counsel of the wicked is far from me. [^18] The righteous see it, and are glad;And the innocent laugh them to scorn, [^19] Saying, Surely they that did rise up against us are cut off,And the remnant of them the fire hath consumed. [^20] Acquaint now thyself with him, and be at peace:Thereby good shall come unto thee. [^21] Receive, I pray thee, the law from his mouth,And lay up his words in thy heart. [^22] If thou return to the Almighty, thou shalt be built up,If thou put away unrighteousness far from thy tents. [^23] And lay thou thy treasure in the dust,And the gold of Ophir among the stones of the brooks; [^24] And the Almighty will be thy treasure,And precious silver unto thee. [^25] For then shalt thou delight thyself in the Almighty,And shalt lift up thy face unto God. [^26] Thou shalt make thy prayer unto him, and he will hear thee;And thou shalt pay thy vows. [^27] Thou shalt also decree a thing, and it shall be established unto thee;And light shall shine upon thy ways. [^28] When they cast thee down, thou shalt say, There is lifting up;And the humble person he will save. [^29] He will deliver even him that is not innocent:Yea, he shall be delivered through the cleanness of thy hands. [^30] 

[[Job - 21|<--]] Job - 22 [[Job - 23|-->]]

---
# Notes
