---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 1 - American Standard Version"
---
Job - 1 [[Job - 2|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 1

There was a man in the land of Uz, whose name was Job; and that man was perfect and upright, and one that feared God, and turned away from evil. [^1] And there were born unto him seven sons and three daughters. [^2] His substance also was seven thousand sheep, and three thousand camels, and five hundred yoke of oxen, and five hundred she-asses, and a very great household; so that this man was the greatest of all the children of the east. [^3] And his sons went and held a feast in the house of each one upon his day; and they sent and called for their three sisters to eat and to drink with them. [^4] And it was so, when the days of their feasting were gone about, that Job sent and sanctified them, and rose up early in the morning, and offered burnt-offerings according to the number of them all: for Job said, It may be that my sons have sinned, and renounced God in their hearts. Thus did Job continually. [^5] Now it came to pass on the day when the sons of God came to present themselves before Jehovah, that Satan also came among them. [^6] And Jehovah said unto Satan, Whence comest thou? Then Satan answered Jehovah, and said, From going to and fro in the earth, and from walking up and down in it. [^7] And Jehovah said unto Satan, Hast thou considered my servant Job? for there is none like him in the earth, a perfect and an upright man, one that feareth God, and turneth away from evil. [^8] Then Satan answered Jehovah, and said, Doth Job fear God for nought? [^9] Hast not thou made a hedge about him, and about his house, and about all that he hath, on every side? thou hast blessed the work of his hands, and his substance is increased in the land. [^10] But put forth thy hand now, and touch all that he hath, and he will renounce thee to thy face. [^11] And Jehovah said unto Satan, Behold, all that he hath is in thy power; only upon himself put not forth thy hand. So Satan went forth from the presence of Jehovah. [^12] And it fell on a day when his sons and his daughters were eating and drinking wine in their eldest brother’s house, [^13] that there came a messenger unto Job, and said, The oxen were plowing, and the asses feeding beside them; [^14] and the Sabeans fell upon them, and took them away: yea, they have slain the servants with the edge of the sword; and I only am escaped alone to tell thee. [^15] While he was yet speaking, there came also another, and said, The fire of God is fallen from heaven, and hath burned up the sheep and the servants, and consumed them; and I only am escaped alone to tell thee. [^16] While he was yet speaking, there came also another, and said, The Chaldeans made three bands, and fell upon the camels, and have taken them away, yea, and slain the servants with the edge of the sword; and I only am escaped alone to tell thee. [^17] While he was yet speaking, there came also another, and said, Thy sons and thy daughters were eating and drinking wine in their eldest brother’s house; [^18] and, behold, there came a great wind from the wilderness, and smote the four corners of the house, and it fell upon the young men, and they are dead; and I only am escaped alone to tell thee. [^19] Then Job arose, and rent his robe, and shaved his head, and fell down upon the ground, and worshipped; [^20] and he said, Naked came I out of my mother’s womb, and naked shall I return thither: Jehovah gave, and Jehovah hath taken away; blessed be the name of Jehovah. [^21] In all this Job sinned not, nor charged God foolishly. [^22] 

Job - 1 [[Job - 2|-->]]

---
# Notes
