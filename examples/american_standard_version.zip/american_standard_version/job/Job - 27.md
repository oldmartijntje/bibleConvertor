---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 27 - American Standard Version"
---
[[Job - 26|<--]] Job - 27 [[Job - 28|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 27

And Job again took up his parable, and said, [^1] As God liveth, who hath taken away my right,And the Almighty, who hath vexed my soul [^2] (For my life is yet whole in me,And the spirit of God is in my nostrils); [^3] Surely my lips shall not speak unrighteousness,Neither shall my tongue utter deceit. [^4] Far be it from me that I should justify you:Till I die I will not put away mine integrity from me. [^5] My righteousness I hold fast, and will not let it go:My heart shall not reproach me so long as I live. [^6] Let mine enemy be as the wicked,And let him that riseth up against me be as the unrighteous. [^7] For what is the hope of the godless, though he get him gain,When God taketh away his soul? [^8] Will God hear his cry,When trouble cometh upon him? [^9] Will he delight himself in the Almighty,And call upon God at all times? [^10] I will teach you concerning the hand of God;That which is with the Almighty will I not conceal. [^11] Behold, all ye yourselves have seen it;Why then are ye become altogether vain? [^12] This is the portion of a wicked man with God,And the heritage of oppressors, which they receive from the Almighty: [^13] If his children be multiplied, it is for the sword;And his offspring shall not be satisfied with bread. [^14] Those that remain of him shall be buried in death,And his widows shall make no lamentation. [^15] Though he heap up silver as the dust,And prepare raiment as the clay; [^16] He may prepare it, but the just shall put it on,And the innocent shall divide the silver. [^17] He buildeth his house as the moth,And as a booth which the keeper maketh. [^18] He lieth down rich, but he shall not be gathered to his fathers;He openeth his eyes, and he is not. [^19] Terrors overtake him like waters;A tempest stealeth him away in the night. [^20] The east wind carrieth him away, and he departeth;And it sweepeth him out of his place. [^21] For God shall hurl at him, and not spare:He would fain flee out of his hand. [^22] Men shall clap their hands at him,And shall hiss him out of his place. [^23] 

[[Job - 26|<--]] Job - 27 [[Job - 28|-->]]

---
# Notes
