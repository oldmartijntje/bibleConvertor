---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 26 - American Standard Version"
---
[[Job - 25|<--]] Job - 26 [[Job - 27|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 26

Then Job answered and said, [^1] How hast thou helped him that is without power!How hast thou saved the arm that hath no strength! [^2] How hast thou counselled him that hath no wisdom,And plentifully declared sound knowledge! [^3] To whom hast thou uttered words?And whose spirit came forth from thee? [^4] They that are deceased trembleBeneath the waters and the inhabitants thereof. [^5] Sheol is naked before God,And Abaddon hath no covering. [^6] He stretcheth out the north over empty space,And hangeth the earth upon nothing. [^7] He bindeth up the waters in his thick clouds;And the cloud is not rent under them. [^8] He incloseth the face of his throne,And spreadeth his cloud upon it. [^9] He hath described a boundary upon the face of the waters,Unto the confines of light and darkness. [^10] The pillars of heaven trembleAnd are astonished at his rebuke. [^11] He stirreth up the sea with his power,And by his understanding he smiteth through Rahab. [^12] By his Spirit the heavens are garnished;His hand hath pierced the swift serpent. [^13] Lo, these are but the outskirts of his ways:And how small a whisper do we hear of him!But the thunder of his power who can understand? [^14] 

[[Job - 25|<--]] Job - 26 [[Job - 27|-->]]

---
# Notes
