---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 29 - American Standard Version"
---
[[Job - 28|<--]] Job - 29 [[Job - 30|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 29

And Job again took up his parable, and said, [^1] Oh that I were as in the months of old,As in the days when God watched over me; [^2] When his lamp shined upon my head,And by his light I walked through darkness; [^3] As I was in the ripeness of my days,When the friendship of God was upon my tent; [^4] When the Almighty was yet with me,And my children were about me; [^5] When my steps were washed with butter,And the rock poured me out streams of oil! [^6] When I went forth to the gate unto the city,When I prepared my seat in the street, [^7] The young men saw me and hid themselves,And the aged rose up and stood; [^8] The princes refrained from talking,And laid their hand on their mouth; [^9] The voice of the nobles was hushed,And their tongue cleaved to the roof of their mouth. [^10] For when the ear heard me, then it blessed me;And when the eye saw me, it gave witness unto me: [^11] Because I delivered the poor that cried,The fatherless also, that had none to help him. [^12] The blessing of him that was ready to perish came upon me;And I caused the widow’s heart to sing for joy. [^13] I put on righteousness, and it clothed me:My justice was as a robe and a diadem. [^14] I was eyes to the blind,And feet was I to the lame. [^15] I was a father to the needy:And the cause of him that I knew not I searched out. [^16] And I brake the jaws of the unrighteous,And plucked the prey out of his teeth. [^17] Then I said, I shall die in my nest,And I shall multiply my days as the sand: [^18] My root is spread out to the waters,And the dew lieth all night upon my branch: [^19] My glory is fresh in me,And my bow is renewed in my hand. [^20] Unto me men gave ear, and waited,And kept silence for my counsel. [^21] After my words they spake not again;And my speech distilled upon them. [^22] And they waited for me as for the rain;And they opened their mouth wide as for the latter rain. [^23] I smiled on them, when they had no confidence;And the light of my countenance they cast not down. [^24] I chose out their way, and sat as chief,And dwelt as a king in the army,As one that comforteth the mourners. [^25] 

[[Job - 28|<--]] Job - 29 [[Job - 30|-->]]

---
# Notes
