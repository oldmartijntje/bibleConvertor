---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 33 - American Standard Version"
---
[[Job - 32|<--]] Job - 33 [[Job - 34|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 33

Howbeit, Job, I pray thee, hear my speech,And hearken to all my words. [^1] Behold now, I have opened my mouth;My tongue hath spoken in my mouth. [^2] My words shall utter the uprightness of my heart;And that which my lips know they shall speak sincerely. [^3] The Spirit of God hath made me,And the breath of the Almighty giveth me life. [^4] If thou canst, answer thou me;Set thy words in order before me, stand forth. [^5] Behold, I am toward God even as thou art:I also am formed out of the clay. [^6] Behold, my terror shall not make thee afraid,Neither shall my pressure be heavy upon thee. [^7] Surely thou hast spoken in my hearing,And I have heard the voice of thy words, saying, [^8] I am clean, without transgression;I am innocent, neither is there iniquity in me: [^9] Behold, he findeth occasions against me,He counteth me for his enemy; [^10] He putteth my feet in the stocks,He marketh all my paths. [^11] Behold, I will answer thee, in this thou art not just;For God is greater than man. [^12] Why dost thou strive against him,For that he giveth not account of any of his matters? [^13] For God speaketh once,Yea twice, though man regardeth it not. [^14] In a dream, in a vision of the night,When deep sleep falleth upon men,In slumberings upon the bed; [^15] Then he openeth the ears of men,And sealeth their instruction, [^16] That he may withdraw man from his purpose,And hide pride from man; [^17] He keepeth back his soul from the pit,And his life from perishing by the sword. [^18] He is chastened also with pain upon his bed,And with continual strife in his bones; [^19] So that his life abhorreth bread,And his soul dainty food. [^20] His flesh is consumed away, that it cannot be seen;And his bones that were not seen stick out. [^21] Yea, his soul draweth near unto the pit,And his life to the destroyers. [^22] If there be with him an angel,An interpreter, one among a thousand,To show unto man what is right for him; [^23] Then God is gracious unto him, and saith,Deliver him from going down to the pit,I have found a ransom. [^24] His flesh shall be fresher than a child’s;He returneth to the days of his youth. [^25] He prayeth unto God, and he is favorable unto him,So that he seeth his face with joy:And he restoreth unto man his righteousness. [^26] He singeth before men, and saith,I have sinned, and perverted that which was right,And it profited me not: [^27] He hath redeemed my soul from going into the pit,And my life shall behold the light. [^28] Lo, all these things doth God work,Twice, yea thrice, with a man, [^29] To bring back his soul from the pit,That he may be enlightened with the light of the living. [^30] Mark well, O Job, hearken unto me:Hold thy peace, and I will speak. [^31] If thou hast anything to say, answer me:Speak, for I desire to justify thee. [^32] If not, hearken thou unto me:Hold thy peace, and I will teach thee wisdom. [^33] 

[[Job - 32|<--]] Job - 33 [[Job - 34|-->]]

---
# Notes
