---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 13 - American Standard Version"
---
[[Job - 12|<--]] Job - 13 [[Job - 14|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 13

Lo, mine eye hath seen all this,Mine ear hath heard and understood it. [^1] What ye know, the same do I know also:I am not inferior unto you. [^2] Surely I would speak to the Almighty,And I desire to reason with God. [^3] But ye are forgers of lies;Ye are all physicians of no value. [^4] Oh that ye would altogether hold your peace!And it would be your wisdom. [^5] Hear now my reasoning,And hearken to the pleadings of my lips. [^6] Will ye speak unrighteously for God,And talk deceitfully for him? [^7] Will ye show partiality to him?Will ye contend for God? [^8] Is it good that he should search you out?Or as one deceiveth a man, will ye deceive him? [^9] He will surely reprove you,If ye do secretly show partiality. [^10] Shall not his majesty make you afraid,And his dread fall upon you? [^11] Your memorable sayings are proverbs of ashes,Your defences are defences of clay. [^12] Hold your peace, let me alone, that I may speak;And let come on me what will. [^13] Wherefore should I take my flesh in my teeth,And put my life in my hand? [^14] Behold, he will slay me; I have no hope:Nevertheless I will maintain my ways before him. [^15] This also shall be my salvation,That a godless man shall not come before him. [^16] Hear diligently my speech,And let my declaration be in your ears. [^17] Behold now, I have set my cause in order;I know that I am righteous. [^18] Who is he that will contend with me?For then would I hold my peace and give up the ghost. [^19] Only do not two things unto me;Then will I not hide myself from thy face: [^20] Withdraw thy hand far from me;And let not thy terror make me afraid. [^21] Then call thou, and I will answer;Or let me speak, and answer thou me. [^22] How many are mine iniquities and sins?Make me to know my transgression and my sin. [^23] Wherefore hidest thou thy face,And holdest me for thine enemy? [^24] Wilt thou harass a driven leaf?And wilt thou pursue the dry stubble? [^25] For thou writest bitter things against me,And makest me to inherit the iniquities of my youth: [^26] Thou puttest my feet also in the stocks,And markest all my paths;Thou settest a bound to the soles of my feet: [^27] Though I am like a rotten thing that consumeth,Like a garment that is moth-eaten. [^28] 

[[Job - 12|<--]] Job - 13 [[Job - 14|-->]]

---
# Notes
