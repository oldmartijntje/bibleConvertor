---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 19 - American Standard Version"
---
[[Job - 18|<--]] Job - 19 [[Job - 20|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 19

Then Job answered and said, [^1] How long will ye vex my soul,And break me in pieces with words? [^2] These ten times have ye reproached me:Ye are not ashamed that ye deal hardly with me. [^3] And be it indeed that I have erred,Mine error remaineth with myself. [^4] If indeed ye will magnify yourselves against me,And plead against me my reproach; [^5] Know now that God hath subverted me in my cause,And hath compassed me with his net. [^6] Behold, I cry out of wrong, but I am not heard:I cry for help, but there is no justice. [^7] He hath walled up my way that I cannot pass,And hath set darkness in my paths. [^8] He hath stripped me of my glory,And taken the crown from my head. [^9] He hath broken me down on every side, and I am gone;And my hope hath he plucked up like a tree. [^10] He hath also kindled his wrath against me,And he counteth me unto him as one of his adversaries. [^11] His troops come on together,And cast up their way against me,And encamp round about my tent. [^12] He hath put my brethren far from me,And mine acquaintance are wholly estranged from me. [^13] My kinsfolk have failed,And my familiar friends have forgotten me. [^14] They that dwell in my house, and my maids, count me for a stranger:I am an alien in their sight. [^15] I call unto my servant, and he giveth me no answer,Though I entreat him with my mouth. [^16] My breath is strange to my wife,And my supplication to the children of mine own mother. [^17] Even young children despise me;If I arise, they speak against me. [^18] All my familiar friends abhor me,And they whom I loved are turned against me. [^19] My bone cleaveth to my skin and to my flesh,And I am escaped with the skin of my teeth. [^20] Have pity upon me, have pity upon me, O ye my friends;For the hand of God hath touched me. [^21] Why do ye persecute me as God,And are not satisfied with my flesh? [^22] Oh that my words were now written!Oh that they were inscribed in a book! [^23] That with an iron pen and leadThey were graven in the rock for ever! [^24] But as for me I know that my Redeemer liveth,And at last he will stand up upon the earth: [^25] And after my skin, even this body, is destroyed,Then without my flesh shall I see God; [^26] Whom I, even I, shall see, on my side,And mine eyes shall behold, and not as a stranger.My heart is consumed within me. [^27] If ye say, How we will persecute him!And that the root of the matter is found in me; [^28] Be ye afraid of the sword:For wrath bringeth the punishments of the sword,That ye may know there is a judgment. [^29] 

[[Job - 18|<--]] Job - 19 [[Job - 20|-->]]

---
# Notes
