---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 8 - American Standard Version"
---
[[Job - 7|<--]] Job - 8 [[Job - 9|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 8

Then answered Bildad the Shuhite, and said, [^1] How long wilt thou speak these things?And how long shall the words of thy mouth be like a mighty wind? [^2] Doth God pervert justice?Or doth the Almighty pervert righteousness? [^3] If thy children have sinned against him,And he hath delivered them into the hand of their transgression; [^4] If thou wouldest seek diligently unto God,And make thy supplication to the Almighty; [^5] If thou wert pure and upright:Surely now he would awake for thee,And make the habitation of thy righteousness prosperous. [^6] And though thy beginning was small,Yet thy latter end would greatly increase. [^7] For inquire, I pray thee, of the former age,And apply thyself to that which their fathers have searched out [^8] (For we are but of yesterday, and know nothing,Because our days upon earth are a shadow); [^9] Shall not they teach thee, and tell thee,And utter words out of their heart? [^10] Can the rush grow up without mire?Can the flag grow without water? [^11] Whilst it is yet in its greenness, and not cut down,It withereth before any other herb. [^12] So are the paths of all that forget God;And the hope of the godless man shall perish: [^13] Whose confidence shall break in sunder,And whose trust is a spider’s web. [^14] He shall lean upon his house, but it shall not stand:He shall hold fast thereby, but it shall not endure. [^15] He is green before the sun,And his shoots go forth over his garden. [^16] His roots are wrapped about the stone-heap,He beholdeth the place of stones. [^17] If he be destroyed from his place,Then it shall deny him, saying, I have not seen thee. [^18] Behold, this is the joy of his way;And out of the earth shall others spring. [^19] Behold, God will not cast away a perfect man,Neither will he uphold the evil-doers. [^20] He will yet fill thy mouth with laughter,And thy lips with shouting. [^21] They that hate thee shall be clothed with shame;And the tent of the wicked shall be no more. [^22] 

[[Job - 7|<--]] Job - 8 [[Job - 9|-->]]

---
# Notes
