---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 36 - American Standard Version"
---
[[Job - 35|<--]] Job - 36 [[Job - 37|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 36

Elihu also proceeded, and said, [^1] Suffer me a little, and I will show thee;For I have yet somewhat to say on God’s behalf. [^2] I will fetch my knowledge from afar,And will ascribe righteousness to my Maker. [^3] For truly my words are not false:One that is perfect in knowledge is with thee. [^4] Behold, God is mighty, and despiseth not any:He is mighty in strength of understanding. [^5] He preserveth not the life of the wicked,But giveth to the afflicted their right. [^6] He withdraweth not his eyes from the righteous:But with kings upon the throneHe setteth them for ever, and they are exalted. [^7] And if they be bound in fetters,And be taken in the cords of affliction; [^8] Then he showeth them their work,And their transgressions, that they have behaved themselves proudly. [^9] He openeth also their ear to instruction,And commandeth that they return from iniquity. [^10] If they hearken and serve him,They shall spend their days in prosperity,And their years in pleasures. [^11] But if they hearken not, they shall perish by the sword,And they shall die without knowledge. [^12] But they that are godless in heart lay up anger:They cry not for help when he bindeth them. [^13] They die in youth,And their life perisheth among the unclean. [^14] He delivereth the afflicted by their affliction,And openeth their ear in oppression. [^15] Yea, he would have allured thee out of distressInto a broad place, where there is no straitness;And that which is set on thy table would be full of fatness. [^16] But thou art full of the judgment of the wicked:Judgment and justice take hold on thee. [^17] For let not wrath stir thee up against chastisements;Neither let the greatness of the ransom turn thee aside. [^18] Will thy cry avail, that thou be not in distress,Or all the forces of thy strength? [^19] Desire not the night,When peoples are cut off in their place. [^20] Take heed, regard not iniquity:For this hast thou chosen rather than affliction. [^21] Behold, God doeth loftily in his power:Who is a teacher like unto him? [^22] Who hath enjoined him his way?Or who can say, Thou hast wrought unrighteousness? [^23] Remember that thou magnify his work,Whereof men have sung. [^24] All men have looked thereon;Man beholdeth it afar off. [^25] Behold, God is great, and we know him not;The number of his years is unsearchable. [^26] For he draweth up the drops of water,Which distil in rain from his vapor, [^27] Which the skies pour downAnd drop upon man abundantly. [^28] Yea, can any understand the spreadings of the clouds,The thunderings of his pavilion? [^29] Behold, he spreadeth his light around him;And he covereth the bottom of the sea. [^30] For by these he judgeth the peoples;He giveth food in abundance. [^31] He covereth his hands with the lightning,And giveth it a charge that it strike the mark. [^32] The noise thereof telleth concerning him,The cattle also concerning the storm that cometh up. [^33] 

[[Job - 35|<--]] Job - 36 [[Job - 37|-->]]

---
# Notes
