---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 40 - American Standard Version"
---
[[Job - 39|<--]] Job - 40 [[Job - 41|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 40

Moreover Jehovah answered Job, and said, [^1] Shall he that cavilleth contend with the Almighty?He that argueth with God, let him answer it. [^2] Then Job answered Jehovah, and said, [^3] Behold, I am of small account; what shall I answer thee?I lay my hand upon my mouth. [^4] Once have I spoken, and I will not answer;Yea, twice, but I will proceed no further. [^5] Then Jehovah answered Job out of the whirlwind, and said, [^6] Gird up thy loins now like a man:I will demand of thee, and declare thou unto me. [^7] Wilt thou even annul my judgment?Wilt thou condemn me, that thou mayest be justified? [^8] Or hast thou an arm like God?And canst thou thunder with a voice like him? [^9] Deck thyself now with excellency and dignity;And array thyself with honor and majesty. [^10] Pour forth the overflowings of thine anger;And look upon every one that is proud, and abase him. [^11] Look on every one that is proud, and bring him low;And tread down the wicked where they stand. [^12] Hide them in the dust together;Bind their faces in the hidden place. [^13] Then will I also confess of theeThat thine own right hand can save thee. [^14] Behold now, behemoth, which I made as well as thee;He eateth grass as an ox. [^15] Lo now, his strength is in his loins,And his force is in the muscles of his belly. [^16] He moveth his tail like a cedar:The sinews of his thighs are knit together. [^17] His bones are as tubes of brass;His limbs are like bars of iron. [^18] He is the chief of the ways of God:He only that made him giveth him his sword. [^19] Surely the mountains bring him forth food,Where all the beasts of the field do play. [^20] He lieth under the lotus-trees,In the covert of the reed, and the fen. [^21] The lotus-trees cover him with their shade;The willows of the brook compass him about. [^22] Behold, if a river overflow, he trembleth not;He is confident, though a Jordan swell even to his mouth. [^23] Shall any take him when he is on the watch,Or pierce through his nose with a snare? [^24] 

[[Job - 39|<--]] Job - 40 [[Job - 41|-->]]

---
# Notes
