---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 15 - American Standard Version"
---
[[Job - 14|<--]] Job - 15 [[Job - 16|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 15

Then answered Eliphaz the Temanite, and said, [^1] Should a wise man make answer with vain knowledge,And fill himself with the east wind? [^2] Should he reason with unprofitable talk,Or with speeches wherewith he can do no good? [^3] Yea, thou doest away with fear,And hinderest devotion before God. [^4] For thine iniquity teacheth thy mouth,And thou choosest the tongue of the crafty. [^5] Thine own mouth condemneth thee, and not I;Yea, thine own lips testify against thee. [^6] Art thou the first man that was born?Or wast thou brought forth before the hills? [^7] Hast thou heard the secret counsel of God?And dost thou limit wisdom to thyself? [^8] What knowest thou, that we know not?What understandest thou, which is not in us? [^9] With us are both the gray-headed and the very aged men,Much elder than thy father. [^10] Are the consolations of God too small for thee,Even the word that is gentle toward thee? [^11] Why doth thy heart carry thee away?And why do thine eyes flash, [^12] That against God thou turnest thy spirit,And lettest words go out of thy mouth? [^13] What is man, that he should be clean?And he that is born of a woman, that he should be righteous? [^14] Behold, he putteth no trust in his holy ones;Yea, the heavens are not clean in his sight: [^15] How much less one that is abominable and corrupt,A man that drinketh iniquity like water! [^16] I will show thee, hear thou me;And that which I have seen I will declare [^17] (Which wise men have toldFrom their fathers, and have not hid it; [^18] Unto whom alone the land was given,And no stranger passed among them): [^19] The wicked man travaileth with pain all his days,Even the number of years that are laid up for the oppressor. [^20] A sound of terrors is in his ears;In prosperity the destroyer shall come upon him. [^21] He believeth not that he shall return out of darkness,And he is waited for of the sword. [^22] He wandereth abroad for bread, saying, Where is it?He knoweth that the day of darkness is ready at his hand. [^23] Distress and anguish make him afraid;They prevail against him, as a king ready to the battle. [^24] Because he hath stretched out his hand against God,And behaveth himself proudly against the Almighty; [^25] He runneth upon him with a stiff neck,With the thick bosses of his bucklers; [^26] Because he hath covered his face with his fatness,And gathered fat upon his loins; [^27] And he hath dwelt in desolate cities,In houses which no man inhabited,Which were ready to become heaps; [^28] He shall not be rich, neither shall his substance continue,Neither shall their possessions be extended on the earth. [^29] He shall not depart out of darkness;The flame shall dry up his branches,And by the breath of God’s mouth shall he go away. [^30] Let him not trust in vanity, deceiving himself;For vanity shall be his recompense. [^31] It shall be accomplished before his time,And his branch shall not be green. [^32] He shall shake off his unripe grape as the vine,And shall cast off his flower as the olive-tree. [^33] For the company of the godless shall be barren,And fire shall consume the tents of bribery. [^34] They conceive mischief, and bring forth iniquity,And their heart prepareth deceit. [^35] 

[[Job - 14|<--]] Job - 15 [[Job - 16|-->]]

---
# Notes
