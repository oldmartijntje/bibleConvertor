---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 4 - American Standard Version"
---
[[Job - 3|<--]] Job - 4 [[Job - 5|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Job]]

# Job - 4

Then answered Eliphaz the Temanite, and said, [^1] If one assay to commune with thee, wilt thou be grieved?But who can withhold himself from speaking? [^2] Behold, thou hast instructed many,And thou hast strengthened the weak hands. [^3] Thy words have upholden him that was falling,And thou hast made firm the feeble knees. [^4] But now it is come unto thee, and thou faintest;It toucheth thee, and thou art troubled. [^5] Is not thy fear of God thy confidence,And the integrity of thy ways thy hope? [^6] Remember, I pray thee, who ever perished, being innocent?Or where were the upright cut off? [^7] According as I have seen, they that plow iniquity,And sow trouble, reap the same. [^8] By the breath of God they perish,And by the blast of his anger are they consumed. [^9] The roaring of the lion, and the voice of the fierce lion,And the teeth of the young lions, are broken. [^10] The old lion perisheth for lack of prey,And the whelps of the lioness are scattered abroad. [^11] Now a thing was secretly brought to me,And mine ear received a whisper thereof. [^12] In thoughts from the visions of the night,When deep sleep falleth on men, [^13] Fear came upon me, and trembling,Which made all my bones to shake. [^14] Then a spirit passed before my face;The hair of my flesh stood up. [^15] It stood still, but I could not discern the appearance thereof;A form was before mine eyes:There was silence, and I heard a voice, saying, [^16] Shall mortal man be more just than God?Shall a man be more pure than his Maker? [^17] Behold, he putteth no trust in his servants;And his angels he chargeth with folly: [^18] How much more them that dwell in houses of clay,Whose foundation is in the dust,Who are crushed before the moth! [^19] Betwixt morning and evening they are destroyed:They perish for ever without any regarding it. [^20] Is not their tent-cord plucked up within them?They die, and that without wisdom. [^21] 

[[Job - 3|<--]] Job - 4 [[Job - 5|-->]]

---
# Notes
