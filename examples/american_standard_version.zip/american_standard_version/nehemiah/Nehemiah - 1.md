---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/nehemiah"
  - "#bible/testament/old"
aliases:
  - "Nehemiah - 1 - American Standard Version"
---
Nehemiah - 1 [[Nehemiah - 2|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Nehemiah]]

# Nehemiah - 1

The words of Nehemiah the son of Hacaliah.Now it came to pass in the month Chislev, in the twentieth year, as I was in Shushan the palace, [^1] that Hanani, one of my brethren, came, he and certain men out of Judah; and I asked them concerning the Jews that had escaped, that were left of the captivity, and concerning Jerusalem. [^2] And they said unto me, The remnant that are left of the captivity there in the province are in great affliction and reproach: the wall of Jerusalem also is broken down, and the gates thereof are burned with fire. [^3] And it came to pass, when I heard these words, that I sat down and wept, and mourned certain days; and I fasted and prayed before the God of heaven, [^4] and said, I beseech thee, O Jehovah, the God of heaven, the great and terrible God, that keepeth covenant and lovingkindness with them that love him and keep his commandments: [^5] let thine ear now be attentive, and thine eyes open, that thou mayest hearken unto the prayer of thy servant, which I pray before thee at this time, day and night, for the children of Israel thy servants, while I confess the sins of the children of Israel, which we have sinned against thee. Yea, I and my father’s house have sinned: [^6] we have dealt very corruptly against thee, and have not kept the commandments, nor the statutes, nor the ordinances, which thou commandedst thy servant Moses. [^7] Remember, I beseech thee, the word that thou commandedst thy servant Moses, saying, If ye trespass, I will scatter you abroad among the peoples: [^8] but if ye return unto me, and keep my commandments and do them, though your outcasts were in the uttermost part of the heavens, yet will I gather them from thence, and will bring them unto the place that I have chosen, to cause my name to dwell there. [^9] Now these are thy servants and thy people, whom thou hast redeemed by thy great power, and by thy strong hand. [^10] O Lord, I beseech thee, let now thine ear be attentive to the prayer of thy servant, and to the prayer of thy servants, who delight to fear thy name; and prosper, I pray thee, thy servant this day, and grant him mercy in the sight of this man.Now I was cupbearer to the king. [^11] 

Nehemiah - 1 [[Nehemiah - 2|-->]]

---
# Notes
