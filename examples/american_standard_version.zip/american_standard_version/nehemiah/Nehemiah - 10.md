---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/nehemiah"
  - "#bible/testament/old"
aliases:
  - "Nehemiah - 10 - American Standard Version"
---
[[Nehemiah - 9|<--]] Nehemiah - 10 [[Nehemiah - 11|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Nehemiah]]

# Nehemiah - 10

Now those that sealed were: Nehemiah the governor, the son of Hacaliah, and Zedekiah, [^1] Seraiah, Azariah, Jeremiah, [^2] Pashhur, Amariah, Malchijah, [^3] Hattush, Shebaniah, Malluch, [^4] Harim, Meremoth, Obadiah, [^5] Daniel, Ginnethon, Baruch, [^6] Meshullam, Abijah, Mijamin, [^7] Maaziah, Bilgai, Shemaiah; these were the priests. [^8] And the Levites: namely, Jeshua the son of Azaniah, Binnui of the sons of Henadad, Kadmiel; [^9] and their brethren, Shebaniah, Hodiah, Kelita, Pelaiah, Hanan, [^10] Mica, Rehob, Hashabiah, [^11] Zaccur, Sherebiah, Shebaniah, [^12] Hodiah, Bani, Beninu. [^13] The chiefs of the people: Parosh, Pahath-moab, Elam, Zattu, Bani, [^14] Bunni, Azgad, Bebai, [^15] Adonijah, Bigvai, Adin, [^16] Ater, Hezekiah, Azzur, [^17] Hodiah, Hashum, Bezai, [^18] Hariph, Anathoth, Nobai, [^19] Magpiash, Meshullam, Hezir, [^20] Meshezabel, Zadok, Jaddua, [^21] Pelatiah, Hanan, Anaiah, [^22] Hoshea, Hananiah, Hasshub, [^23] Hallohesh, Pilha, Shobek, [^24] Rehum, Hashabnah, Maaseiah, [^25] and Ahiah, Hanan, Anan, [^26] Malluch, Harim, Baanah. [^27] And the rest of the people, the priests, the Levites, the porters, the singers, the Nethinim, and all they that had separated themselves from the peoples of the lands unto the law of God, their wives, their sons, and their daughters, every one that had knowledge, and understanding; [^28] they clave to their brethren, their nobles, and entered into a curse, and into an oath, to walk in God’s law, which was given by Moses the servant of God, and to observe and do all the commandments of Jehovah our Lord, and his ordinances and his statutes; [^29] and that we would not give our daughters unto the peoples of the land, nor take their daughters for our sons; [^30] and if the peoples of the land bring wares or any grain on the sabbath day to sell, that we would not buy of them on the sabbath, or on a holy day; and that we would forego the seventh year, and the exaction of every debt. [^31] Also we made ordinances for us, to charge ourselves yearly with the third part of a shekel for the service of the house of our God; [^32] for the showbread, and for the continual meal-offering, and for the continual burnt-offering, for the sabbaths, for the new moons, for the set feasts, and for the holy things, and for the sin-offerings to make atonement for Israel, and for all the work of the house of our God. [^33] And we cast lots, the priests, the Levites, and the people, for the wood-offering, to bring it into the house of our God, according to our fathers’ houses, at times appointed, year by year, to burn upon the altar of Jehovah our God, as it is written in the law; [^34] and to bring the first-fruits of our ground, and the first-fruits of all fruit of all manner of trees, year by year, unto the house of Jehovah; [^35] also the first-born of our sons, and of our cattle, as it is written in the law, and the firstlings of our herds and of our flocks, to bring to the house of our God, unto the priests that minister in the house of our God; [^36] and that we should bring the first-fruits of our dough, and our heave-offerings, and the fruit of all manner of trees, the new wine and the oil, unto the priests, to the chambers of the house of our God; and the tithes of our ground unto the Levites; for they, the Levites, take the tithes in all the cities of our tillage. [^37] And the priest the son of Aaron shall be with the Levites, when the Levites take tithes: and the Levites shall bring up the tithe of the tithes unto the house of our God, to the chambers, into the treasure-house. [^38] For the children of Israel and the children of Levi shall bring the heave-offering of the grain, of the new wine, and of the oil, unto the chambers, where are the vessels of the sanctuary, and the priests that minister, and the porters, and the singers: and we will not forsake the house of our God. [^39] 

[[Nehemiah - 9|<--]] Nehemiah - 10 [[Nehemiah - 11|-->]]

---
# Notes
