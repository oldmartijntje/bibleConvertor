---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/nehemiah"
  - "#bible/testament/old"
aliases:
  - "Nehemiah - 4 - American Standard Version"
---
[[Nehemiah - 3|<--]] Nehemiah - 4 [[Nehemiah - 5|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Nehemiah]]

# Nehemiah - 4

But it came to pass that, when Sanballat heard that we were building the wall, he was wroth, and took great indignation, and mocked the Jews. [^1] And he spake before his brethren and the army of Samaria, and said, What are these feeble Jews doing? will they fortify themselves? will they sacrifice? will they make an end in a day? will they revive the stones out of the heaps of rubbish, seeing they are burned? [^2] Now Tobiah the Ammonite was by him, and he said, Even that which they are building, if a fox go up, he shall break down their stone wall. [^3] Hear, O our God; for we are despised: and turn back their reproach upon their own head, and give them up for a spoil in a land of captivity; [^4] and cover not their iniquity, and let not their sin be blotted out from before thee; for they have provoked thee to anger before the builders. [^5] So we built the wall; and all the wall was joined together unto half the height thereof: for the people had a mind to work. [^6] But it came to pass that, when Sanballat, and Tobiah, and the Arabians, and the Ammonites, and the Ashdodites, heard that the repairing of the walls of Jerusalem went forward, and that the breaches began to be stopped, then they were very wroth; [^7] and they conspired all of them together to come and fight against Jerusalem, and to cause confusion therein. [^8] But we made our prayer unto our God, and set a watch against them day and night, because of them. [^9] And Judah said, The strength of the bearers of burdens is decayed, and there is much rubbish; so that we are not able to build the wall. [^10] And our adversaries said, They shall not know, neither see, till we come into the midst of them, and slay them, and cause the work to cease. [^11] And it came to pass that, when the Jews that dwelt by them came, they said unto us ten times from all places, Ye must return unto us. [^12] Therefore set I in the lowest parts of the space behind the wall, in the open places, I set there the people after their families with their swords, their spears, and their bows. [^13] And I looked, and rose up, and said unto the nobles, and to the rulers, and to the rest of the people, Be not ye afraid of them: remember the Lord, who is great and terrible, and fight for your brethren, your sons, and your daughters, your wives, and your houses. [^14] And it came to pass, when our enemies heard that it was known unto us, and God had brought their counsel to nought, that we returned all of us to the wall, every one unto his work. [^15] And it came to pass from that time forth, that half of my servants wrought in the work, and half of them held the spears, the shields, and the bows, and the coats of mail; and the rulers were behind all the house of Judah. [^16] They that builded the wall and they that bare burdens laded themselves; every one with one of his hands wrought in the work, and with the other held his weapon; [^17] and the builders, every one had his sword girded by his side, and so builded. And he that sounded the trumpet was by me. [^18] And I said unto the nobles, and to the rulers and to the rest of the people, The work is great and large, and we are separated upon the wall, one far from another: [^19] in what place soever ye hear the sound of the trumpet, resort ye thither unto us; our God will fight for us. [^20] So we wrought in the work: and half of them held the spears from the rising of the morning till the stars appeared. [^21] Likewise at the same time said I unto the people, Let every one with his servant lodge within Jerusalem, that in the night they may be a guard to us, and may labor in the day. [^22] So neither I, nor my brethren, nor my servants, nor the men of the guard that followed me, none of us put off our clothes, every one went with his weapon to the water. [^23] 

[[Nehemiah - 3|<--]] Nehemiah - 4 [[Nehemiah - 5|-->]]

---
# Notes
