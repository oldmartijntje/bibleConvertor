---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/nehemiah"
  - "#bible/testament/old"
aliases:
  - "Nehemiah - 8 - American Standard Version"
---
[[Nehemiah - 7|<--]] Nehemiah - 8 [[Nehemiah - 9|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Nehemiah]]

# Nehemiah - 8

And all the people gathered themselves together as one man into the broad place that was before the water gate; and they spake unto Ezra the scribe to bring the book of the law of Moses, which Jehovah had commanded to Israel. [^1] And Ezra the priest brought the law before the assembly, both men and women, and all that could hear with understanding, upon the first day of the seventh month. [^2] And he read therein before the broad place that was before the water gate from early morning until midday, in the presence of the men and the women, and of those that could understand; and the ears of all the people were attentive unto the book of the law. [^3] And Ezra the scribe stood upon a pulpit of wood, which they had made for the purpose; and beside him stood Mattithiah, and Shema, and Anaiah, and Uriah, and Hilkiah, and Maaseiah, on his right hand; and on his left hand, Pedaiah, and Mishael, and Malchijah, and Hashum, and Hashbaddanah, Zechariah, and Meshullam. [^4] And Ezra opened the book in the sight of all the people (for he was above all the people); and when he opened it, all the people stood up. [^5] And Ezra blessed Jehovah, the great God; and all the people answered, Amen, Amen, with the lifting up of their hands: and they bowed their heads, and worshipped Jehovah with their faces to the ground. [^6] Also Jeshua, and Bani, and Sherebiah, Jamin, Akkub, Shabbethai, Hodiah, Maaseiah, Kelita, Azariah, Jozabad, Hanan, Pelaiah, and the Levites, caused the people to understand the law: and the people stood in their place. [^7] And they read in the book, in the law of God, distinctly; and they gave the sense, so that they understood the reading. [^8] And Nehemiah, who was the governor, and Ezra the priest the scribe, and the Levites that taught the people, said unto all the people, This day is holy unto Jehovah your God; mourn not, nor weep. For all the people wept, when they heard the words of the law. [^9] Then he said unto them, Go your way, eat the fat, and drink the sweet, and send portions unto him for whom nothing is prepared; for this day is holy unto our Lord: neither be ye grieved; for the joy of Jehovah is your strength. [^10] So the Levites stilled all the people, saying, Hold your peace, for the day is holy; neither be ye grieved. [^11] And all the people went their way to eat, and to drink, and to send portions, and to make great mirth, because they had understood the words that were declared unto them. [^12] And on the second day were gathered together the heads of fathers’ houses of all the people, the priests, and the Levites, unto Ezra the scribe, even to give attention to the words of the law. [^13] And they found written in the law, how that Jehovah had commanded by Moses, that the children of Israel should dwell in booths in the feast of the seventh month; [^14] and that they should publish and proclaim in all their cities, and in Jerusalem, saying, Go forth unto the mount, and fetch olive branches, and branches of wild olive, and myrtle branches, and palm branches, and branches of thick trees, to make booths, as it is written. [^15] So the people went forth, and brought them, and made themselves booths, every one upon the roof of his house, and in their courts, and in the courts of the house of God, and in the broad place of the water gate, and in the broad place of the gate of Ephraim. [^16] And all the assembly of them that were come again out of the captivity made booths, and dwelt in the booths: for since the days of Jeshua the son of Nun unto that day had not the children of Israel done so. And there was very great gladness. [^17] Also day by day, from the first day unto the last day, he read in the book of the law of God. And they kept the feast seven days; and on the eighth day was a solemn assembly, according unto the ordinance. [^18] 

[[Nehemiah - 7|<--]] Nehemiah - 8 [[Nehemiah - 9|-->]]

---
# Notes
