---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/nehemiah"
  - "#bible/testament/old"
aliases:
  - "Nehemiah - 6 - American Standard Version"
---
[[Nehemiah - 5|<--]] Nehemiah - 6 [[Nehemiah - 7|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Nehemiah]]

# Nehemiah - 6

Now it came to pass, when it was reported to Sanballat and Tobiah, and to Geshem the Arabian, and unto the rest of our enemies, that I had builded the wall, and that there was no breach left therein (though even unto that time I had not set up the doors in the gates), [^1] that Sanballat and Geshem sent unto me, saying, Come, let us meet together in one of the villages in the plain of Ono. But they thought to do me mischief. [^2] And I sent messengers unto them, saying, I am doing a great work, so that I cannot come down: why should the work cease, whilst I leave it, and come down to you? [^3] And they sent unto me four times after this sort; and I answered them after the same manner. [^4] Then sent Sanballat his servant unto me in like manner the fifth time with an open letter in his hand, [^5] wherein was written, It is reported among the nations, and Gashmu saith it, that thou and the Jews think to rebel; for which cause thou art building the wall: and thou wouldest be their king, according to these words. [^6] And thou hast also appointed prophets to preach of thee at Jerusalem, saying, There is a king in Judah: and now shall it be reported to the king according to these words. Come now therefore, and let us take counsel together. [^7] Then I sent unto him, saying, There are no such things done as thou sayest, but thou feignest them out of thine own heart. [^8] For they all would have made us afraid, saying, Their hands shall be weakened from the work, that it be not done. But now, O God, strengthen thou my hands. [^9] And I went unto the house of Shemaiah the son of Delaiah the son of Mehetabel, who was shut up; and he said, Let us meet together in the house of God, within the temple, and let us shut the doors of the temple: for they will come to slay thee; yea, in the night will they come to slay thee. [^10] And I said, Should such a man as I flee? and who is there, that, being such as I, would go into the temple to save his life? I will not go in. [^11] And I discerned, and, lo, God had not sent him; but he pronounced this prophecy against me: and Tobiah and Sanballat had hired him. [^12] For this cause was he hired, that I should be afraid, and do so, and sin, and that they might have matter for an evil report, that they might reproach me. [^13] Remember, O my God, Tobiah and Sanballat according to these their works, and also the prophetess Noadiah, and the rest of the prophets, that would have put me in fear. [^14] So the wall was finished in the twenty and fifth day of the month Elul, in fifty and two days. [^15] And it came to pass, when all our enemies heard thereof, that all the nations that were about us feared, and were much cast down in their own eyes; for they perceived that this work was wrought of our God. [^16] Moreover in those days the nobles of Judah sent many letters unto Tobiah, and the letters of Tobiah came unto them. [^17] For there were many in Judah sworn unto him, because he was the son-in-law of Shecaniah the son of Arah; and his son Jehohanan had taken the daughter of Meshullam the son of Berechiah to wife. [^18] Also they spake of his good deeds before me, and reported my words to him. And Tobiah sent letters to put me in fear. [^19] 

[[Nehemiah - 5|<--]] Nehemiah - 6 [[Nehemiah - 7|-->]]

---
# Notes
