---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/nehemiah"
  - "#bible/testament/old"
aliases:
  - "Nehemiah - 5 - American Standard Version"
---
[[Nehemiah - 4|<--]] Nehemiah - 5 [[Nehemiah - 6|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Nehemiah]]

# Nehemiah - 5

Then there arose a great cry of the people and of their wives against their brethren the Jews. [^1] For there were that said, We, our sons and our daughters, are many: let us get grain, that we may eat and live. [^2] Some also there were that said, We are mortgaging our fields, and our vineyards, and our houses: let us get grain, because of the dearth. [^3] There were also that said, We have borrowed money for the king’s tribute upon our fields and our vineyards. [^4] Yet now our flesh is as the flesh of our brethren, our children as their children: and, lo, we bring into bondage our sons and our daughters to be servants, and some of our daughters are brought into bondage already: neither is it in our power to help it; for other men have our fields and our vineyards. [^5] And I was very angry when I heard their cry and these words. [^6] Then I consulted with myself, and contended with the nobles and the rulers, and said unto them, Ye exact usury, every one of his brother. And I held a great assembly against them. [^7] And I said unto them, We after our ability have redeemed our brethren the Jews, that were sold unto the nations; and would ye even sell your brethren, and should they be sold unto us? Then held they their peace, and found never a word. [^8] Also I said, The thing that ye do is not good: ought ye not to walk in the fear of our God, because of the reproach of the nations our enemies? [^9] And I likewise, my brethren and my servants, do lend them money and grain. I pray you, let us leave off this usury. [^10] Restore, I pray you, to them, even this day, their fields, their vineyards, their oliveyards, and their houses, also the hundredth part of the money, and of the grain, the new wine, and the oil, that ye exact of them. [^11] Then said they, We will restore them, and will require nothing of them; so will we do, even as thou sayest. Then I called the priests, and took an oath of them, that they would do according to this promise. [^12] Also I shook out my lap, and said, So God shake out every man from his house, and from his labor, that performeth not this promise; even thus be he shaken out, and emptied. And all the assembly said, Amen, and praised Jehovah. And the people did according to this promise. [^13] Moreover from the time that I was appointed to be their governor in the land of Judah, from the twentieth year even unto the two and thirtieth year of Artaxerxes the king, that is, twelve years, I and my brethren have not eaten the bread of the governor. [^14] But the former governors that were before me were chargeable unto the people, and took of them bread and wine, besides forty shekels of silver; yea, even their servants bare rule over the people: but so did not I, because of the fear of God. [^15] Yea, also I continued in the work of this wall, neither bought we any land: and all my servants were gathered thither unto the work. [^16] Moreover there were at my table, of the Jews and the rulers, a hundred and fifty men, besides those that came unto us from among the nations that were round about us. [^17] Now that which was prepared for one day was one ox and six choice sheep; also fowls were prepared for me, and once in ten days store of all sorts of wine: yet for all this I demanded not the bread of the governor, because the bondage was heavy upon this people. [^18] Remember unto me, O my God, for good, all that I have done for this people. [^19] 

[[Nehemiah - 4|<--]] Nehemiah - 5 [[Nehemiah - 6|-->]]

---
# Notes
