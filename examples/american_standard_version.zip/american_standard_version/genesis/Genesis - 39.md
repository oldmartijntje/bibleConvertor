---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 39 - American Standard Version"
---
[[Genesis - 38|<--]] Genesis - 39 [[Genesis - 40|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Genesis]]

# Genesis - 39

And Joseph was brought down to Egypt; and Potiphar, an officer of Pharaoh’s, the captain of the guard, an Egyptian, bought him of the hand of the Ishmaelites, that had brought him down thither. [^1] And Jehovah was with Joseph, and he was a prosperous man; and he was in the house of his master the Egyptian. [^2] And his master saw that Jehovah was with him, and that Jehovah made all that he did to prosper in his hand. [^3] And Joseph found favor in his sight, and he ministered unto him: and he made him overseer over his house, and all that he had he put into his hand. [^4] And it came to pass from the time that he made him overseer in his house, and over all that he had, that Jehovah blessed the Egyptian’s house for Joseph’s sake; and the blessing of Jehovah was upon all that he had, in the house and in the field. [^5] And he left all that he had in Joseph’s hand; and he knew not aught that was with him, save the bread which he did eat. And Joseph was comely, and well-favored. [^6] And it came to pass after these things, that his master’s wife cast her eyes upon Joseph; and she said, Lie with me. [^7] But he refused, and said unto his master’s wife, Behold, my master knoweth not what is with me in the house, and he hath put all that he hath into my hand: [^8] he is not greater in this house than I; neither hath he kept back anything from me but thee, because thou art his wife: how then can I do this great wickedness, and sin against God? [^9] And it came to pass, as she spake to Joseph day by day, that he hearkened not unto her, to lie by her, or to be with her. [^10] And it came to pass about this time, that he went into the house to do his work; and there was none of the men of the house there within. [^11] And she caught him by his garment, saying, Lie with me: and he left his garment in her hand, and fled, and got him out. [^12] And it came to pass, when she saw that he had left his garment in her hand, and was fled forth, [^13] that she called unto the men of her house, and spake unto them, saying, See, he hath brought in a Hebrew unto us to mock us: he came in unto me to lie with me, and I cried with a loud voice: [^14] and it came to pass, when he heard that I lifted up my voice and cried, that he left his garment by me, and fled, and got him out. [^15] And she laid up his garment by her, until his master came home. [^16] And she spake unto him according to these words, saying, The Hebrew servant, whom thou hast brought unto us, came in unto me to mock me: [^17] and it came to pass, as I lifted up my voice and cried, that he left his garment by me, and fled out. [^18] And it came to pass, when his master heard the words of his wife, which she spake unto him, saying, After this manner did thy servant to me; that his wrath was kindled. [^19] And Joseph’s master took him, and put him into the prison, the place where the king’s prisoners were bound: and he was there in the prison. [^20] But Jehovah was with Joseph, and showed kindness unto him, and gave him favor in the sight of the keeper of the prison. [^21] And the keeper of the prison committed to Joseph’s hand all the prisoners that were in the prison; and whatsoever they did there, he was the doer of it. [^22] The keeper of the prison looked not to anything that was under his hand, because Jehovah was with him; and that which he did, Jehovah made it to prosper. [^23] 

[[Genesis - 38|<--]] Genesis - 39 [[Genesis - 40|-->]]

---
# Notes
