---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 17 - American Standard Version"
---
[[Genesis - 16|<--]] Genesis - 17 [[Genesis - 18|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Genesis]]

# Genesis - 17

And when Abram was ninety years old and nine, Jehovah appeared to Abram, and said unto him, I am God Almighty; walk before me, and be thou perfect. [^1] And I will make my covenant between me and thee, and will multiply thee exceedingly. [^2] And Abram fell on his face: and God talked with him, saying, [^3] As for me, behold, my covenant is with thee, and thou shalt be the father of a multitude of nations. [^4] Neither shall thy name any more be called Abram, but thy name shall be Abraham; for the father of a multitude of nations have I made thee. [^5] And I will make thee exceeding fruitful, and I will make nations of thee, and kings shall come out of thee. [^6] And I will establish my covenant between me and thee and thy seed after thee throughout their generations for an everlasting covenant, to be a God unto thee and to thy seed after thee. [^7] And I will give unto thee, and to thy seed after thee, the land of thy sojournings, all the land of Canaan, for an everlasting possession; and I will be their God. [^8] And God said unto Abraham, And as for thee, thou shalt keep my covenant, thou, and thy seed after thee throughout their generations. [^9] This is my covenant, which ye shall keep, between me and you and thy seed after thee: every male among you shall be circumcised. [^10] And ye shall be circumcised in the flesh of your foreskin; and it shall be a token of a covenant betwixt me and you. [^11] And he that is eight days old shall be circumcised among you, every male throughout your generations, he that is born in the house, or bought with money of any foreigner that is not of thy seed. [^12] He that is born in thy house, and he that is bought with thy money, must needs be circumcised: and my covenant shall be in your flesh for an everlasting covenant. [^13] And the uncircumcised male who is not circumcised in the flesh of his foreskin, that soul shall be cut off from his people; he hath broken my covenant. [^14] And God said unto Abraham, As for Sarai thy wife, thou shalt not call her name Sarai, but Sarah shall her name be. [^15] And I will bless her, and moreover I will give thee a son of her: yea, I will bless her, and she shall be a mother of nations; kings of peoples shall be of her. [^16] Then Abraham fell upon his face, and laughed, and said in his heart, Shall a child be born unto him that is a hundred years old? and shall Sarah, that is ninety years old, bear? [^17] And Abraham said unto God, Oh that Ishmael might live before thee! [^18] And God said, Nay, but Sarah thy wife shall bear thee a son; and thou shalt call his name Isaac: and I will establish my covenant with him for an everlasting covenant for his seed after him. [^19] And as for Ishmael, I have heard thee: behold, I have blessed him, and will make him fruitful, and will multiply him exceedingly; twelve princes shall he beget, and I will make him a great nation. [^20] But my covenant will I establish with Isaac, whom Sarah shall bear unto thee at this set time in the next year. [^21] And he left off talking with him, and God went up from Abraham. [^22] And Abraham took Ishmael his son, and all that were born in his house, and all that were bought with his money, every male among the men of Abraham’s house, and circumcised the flesh of their foreskin in the selfsame day, as God had said unto him. [^23] And Abraham was ninety years old and nine, when he was circumcised in the flesh of his foreskin. [^24] And Ishmael his son was thirteen years old, when he was circumcised in the flesh of his foreskin. [^25] In the selfsame day was Abraham circumcised, and Ishmael his son. [^26] And all the men of his house, those born in the house, and those bought with money of a foreigner, were circumcised with him. [^27] 

[[Genesis - 16|<--]] Genesis - 17 [[Genesis - 18|-->]]

---
# Notes
