---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 11 - American Standard Version"
---
[[Genesis - 10|<--]] Genesis - 11 [[Genesis - 12|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Genesis]]

# Genesis - 11

And the whole earth was of one language and of one speech. [^1] And it came to pass, as they journeyed east, that they found a plain in the land of Shinar; and they dwelt there. [^2] And they said one to another, Come, let us make brick, and burn them thoroughly. And they had brick for stone, and slime had they for mortar. [^3] And they said, Come, let us build us a city, and a tower, whose top may reach unto heaven, and let us make us a name; lest we be scattered abroad upon the face of the whole earth. [^4] And Jehovah came down to see the city and the tower, which the children of men builded. [^5] And Jehovah said, Behold, they are one people, and they have all one language; and this is what they begin to do: and now nothing will be withholden from them, which they purpose to do. [^6] Come, let us go down, and there confound their language, that they may not understand one another’s speech. [^7] So Jehovah scattered them abroad from thence upon the face of all the earth: and they left off building the city. [^8] Therefore was the name of it called Babel; because Jehovah did there confound the language of all the earth: and from thence did Jehovah scatter them abroad upon the face of all the earth. [^9] These are the generations of Shem. Shem was a hundred years old, and begat Arpachshad two years after the flood: [^10] and Shem lived after he begat Arpachshad five hundred years, and begat sons and daughters. [^11] And Arpachshad lived five and thirty years, and begat Shelah: [^12] and Arpachshad lived after he begat Shelah four hundred and three years, and begat sons and daughters. [^13] And Shelah lived thirty years, and begat Eber: [^14] and Shelah lived after he begat Eber four hundred and three years, and begat sons and daughters. [^15] And Eber lived four and thirty years, and begat Peleg: [^16] and Eber lived after he begat Peleg four hundred and thirty years, and begat sons and daughters. [^17] And Peleg lived thirty years, and begat Reu: [^18] and Peleg lived after he begat Reu two hundred and nine years, and begat sons and daughters. [^19] And Reu lived two and thirty years, and begat Serug: [^20] and Reu lived after he begat Serug two hundred and seven years, and begat sons and daughters. [^21] And Serug lived thirty years, and begat Nahor: [^22] and Serug lived after he begat Nahor two hundred years, and begat sons and daughters. [^23] And Nahor lived nine and twenty years, and begat Terah: [^24] and Nahor lived after he begat Terah a hundred and nineteen years, and begat sons and daughters. [^25] And Terah lived seventy years, and begat Abram, Nahor, and Haran. [^26] Now these are the generations of Terah. Terah begat Abram, Nahor, and Haran; and Haran begat Lot. [^27] And Haran died before his father Terah in the land of his nativity, in Ur of the Chaldees. [^28] And Abram and Nahor took them wives: the name of Abram’s wife was Sarai; and the name of Nahor’s wife, Milcah, the daughter of Haran, the father of Milcah, and the father of Iscah. [^29] And Sarai was barren; she had no child. [^30] And Terah took Abram his son, and Lot the son of Haran, his son’s son, and Sarai his daughter-in-law, his son Abram’s wife; and they went forth with them from Ur of the Chaldees, to go into the land of Canaan; and they came unto Haran, and dwelt there. [^31] And the days of Terah were two hundred and five years: and Terah died in Haran. [^32] 

[[Genesis - 10|<--]] Genesis - 11 [[Genesis - 12|-->]]

---
# Notes
