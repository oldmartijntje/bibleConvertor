---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 48 - American Standard Version"
---
[[Genesis - 47|<--]] Genesis - 48 [[Genesis - 49|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Genesis]]

# Genesis - 48

And it came to pass after these things, that one said to Joseph, Behold, thy father is sick: and he took with him his two sons, Manasseh and Ephraim. [^1] And one told Jacob, and said, Behold, thy son Joseph cometh unto thee: and Israel strengthened himself, and sat upon the bed. [^2] And Jacob said unto Joseph, God Almighty appeared unto me at Luz in the land of Canaan, and blessed me, [^3] and said unto me, Behold, I will make thee fruitful, and multiply thee, and I will make of thee a company of peoples, and will give this land to thy seed after thee for an everlasting possession. [^4] And now thy two sons, who were born unto thee in the land of Egypt before I came unto thee into Egypt, are mine; Ephraim and Manasseh, even as Reuben and Simeon, shall be mine. [^5] And thy issue, that thou begettest after them, shall be thine; they shall be called after the name of their brethren in their inheritance. [^6] And as for me, when I came from Paddan, Rachel died by me in the land of Canaan in the way, when there was still some distance to come unto Ephrath: and I buried her there in the way to Ephrath (the same is Beth-lehem). [^7] And Israel beheld Joseph’s sons, and said, Who are these? [^8] And Joseph said unto his father, They are my sons, whom God hath given me here. And he said, Bring them, I pray thee, unto me, and I will bless them. [^9] Now the eyes of Israel were dim for age, so that he could not see. And he brought them near unto him; and he kissed them, and embraced them. [^10] And Israel said unto Joseph, I had not thought to see thy face: and, lo, God hath let me see thy seed also. [^11] And Joseph brought them out from between his knees; and he bowed himself with his face to the earth. [^12] And Joseph took them both, Ephraim in his right hand toward Israel’s left hand, and Manasseh in his left hand toward Israel’s right hand, and brought them near unto him. [^13] And Israel stretched out his right hand, and laid it upon Ephraim’s head, who was the younger, and his left hand upon Manasseh’s head, guiding his hands wittingly; for Manasseh was the first-born. [^14] And he blessed Joseph, and said, The God before whom my fathers Abraham and Isaac did walk, the God who hath fed me all my life long unto this day, [^15] the angel who hath redeemed me from all evil, bless the lads; and let my name be named on them, and the name of my fathers Abraham and Isaac; and let them grow into a multitude in the midst of the earth. [^16] And when Joseph saw that his father laid his right hand upon the head of Ephraim, it displeased him: and he held up his father’s hand, to remove it from Ephraim’s head unto Manasseh’s head. [^17] And Joseph said unto his father, Not so, my father; for this is the first-born; put thy right hand upon his head. [^18] And his father refused, and said, I know it, my son, I know it; he also shall become a people, and he also shall be great: howbeit his younger brother shall be greater than he, and his seed shall become a multitude of nations. [^19] And he blessed them that day, saying, In thee will Israel bless, saying, God make thee as Ephraim and as Manasseh: and he set Ephraim before Manasseh. [^20] And Israel said unto Joseph, Behold, I die: but God will be with you, and bring you again unto the land of your fathers. [^21] Moreover I have given to thee one portion above thy brethren, which I took out of the hand of the Amorite with my sword and with my bow. [^22] 

[[Genesis - 47|<--]] Genesis - 48 [[Genesis - 49|-->]]

---
# Notes
