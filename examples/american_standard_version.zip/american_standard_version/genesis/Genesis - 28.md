---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 28 - American Standard Version"
---
[[Genesis - 27|<--]] Genesis - 28 [[Genesis - 29|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Genesis]]

# Genesis - 28

And Isaac called Jacob, and blessed him, and charged him, and said unto him, Thou shalt not take a wife of the daughters of Canaan. [^1] Arise, go to Paddan-aram, to the house of Bethuel thy mother’s father; and take thee a wife from thence of the daughters of Laban thy mother’s brother. [^2] And God Almighty bless thee, and make thee fruitful, and multiply thee, that thou mayest be a company of peoples; [^3] and give thee the blessing of Abraham, to thee, and to thy seed with thee; that thou mayest inherit the land of thy sojournings, which God gave unto Abraham. [^4] And Isaac sent away Jacob: and he went to Paddan-aram unto Laban, son of Bethuel the Syrian, the brother of Rebekah, Jacob’s and Esau’s mother. [^5] Now Esau saw that Isaac had blessed Jacob and sent him away to Paddan-aram, to take him a wife from thence; and that as he blessed him he gave him a charge, saying, Thou shalt not take a wife of the daughters of Canaan; [^6] and that Jacob obeyed his father and his mother, and was gone to Paddan-aram: [^7] and Esau saw that the daughters of Canaan pleased not Isaac his father; [^8] and Esau went unto Ishmael, and took, besides the wives that he had, Mahalath the daughter of Ishmael Abraham’s son, the sister of Nebaioth, to be his wife. [^9] And Jacob went out from Beer-sheba, and went toward Haran. [^10] And he lighted upon a certain place, and tarried there all night, because the sun was set; and he took one of the stones of the place, and put it under his head, and lay down in that place to sleep. [^11] And he dreamed; and behold, a ladder set up on the earth, and the top of it reached to heaven; and behold, the angels of God ascending and descending on it. [^12] And, behold, Jehovah stood above it, and said, I am Jehovah, the God of Abraham thy father, and the God of Isaac: the land whereon thou liest, to thee will I give it, and to thy seed; [^13] and thy seed shall be as the dust of the earth, and thou shalt spread abroad to the west, and to the east, and to the north, and to the south: and in thee and in thy seed shall all the families of the earth be blessed. [^14] And, behold, I am with thee, and will keep thee whithersoever thou goest, and will bring thee again into this land; for I will not leave thee, until I have done that which I have spoken to thee of. [^15] And Jacob awaked out of his sleep, and he said, Surely Jehovah is in this place; and I knew it not. [^16] And he was afraid, and said, How dreadful is this place! this is none other than the house of God, and this is the gate of heaven. [^17] And Jacob rose up early in the morning, and took the stone that he had put under his head, and set it up for a pillar, and poured oil upon the top of it. [^18] And he called the name of that place Beth-el: but the name of the city was Luz at the first. [^19] And Jacob vowed a vow, saying, If God will be with me, and will keep me in this way that I go, and will give me bread to eat, and raiment to put on, [^20] so that I come again to my father’s house in peace, and Jehovah will be my God, [^21] then this stone, which I have set up for a pillar, shall be God’s house: and of all that thou shalt give me I will surely give the tenth unto thee. [^22] 

[[Genesis - 27|<--]] Genesis - 28 [[Genesis - 29|-->]]

---
# Notes
