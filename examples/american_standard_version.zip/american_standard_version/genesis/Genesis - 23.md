---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 23 - American Standard Version"
---
[[Genesis - 22|<--]] Genesis - 23 [[Genesis - 24|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Genesis]]

# Genesis - 23

And the life of Sarah was a hundred and seven and twenty years: these were the years of the life of Sarah. [^1] And Sarah died in Kiriath-arba (the same is Hebron), in the land of Canaan: and Abraham came to mourn for Sarah, and to weep for her. [^2] And Abraham rose up from before his dead, and spake unto the children of Heth, saying, [^3] I am a stranger and a sojourner with you: give me a possession of a burying-place with you, that I may bury my dead out of my sight. [^4] And the children of Heth answered Abraham, saying unto him, [^5] Hear us, my lord; thou art a prince of God among us: in the choice of our sepulchres bury thy dead; none of us shall withhold from thee his sepulchre, but that thou mayest bury thy dead. [^6] And Abraham rose up, and bowed himself to the people of the land, even to the children of Heth. [^7] And he communed with them, saying, If it be your mind that I should bury my dead out of my sight, hear me, and entreat for me to Ephron the son of Zohar, [^8] that he may give me the cave of Machpelah, which he hath, which is in the end of his field; for the full price let him give it to me in the midst of you for a possession of a burying-place. [^9] Now Ephron was sitting in the midst of the children of Heth: and Ephron the Hittite answered Abraham in the audience of the children of Heth, even of all that went in at the gate of his city, saying, [^10] Nay, my lord, hear me: the field give I thee, and the cave that is therein, I give it thee; in the presence of the children of my people give I it thee: bury thy dead. [^11] And Abraham bowed himself down before the people of the land. [^12] And he spake unto Ephron in the audience of the people of the land, saying, But if thou wilt, I pray thee, hear me: I will give the price of the field; take it of me, and I will bury my dead there. [^13] And Ephron answered Abraham, saying unto him, [^14] My lord, hearken unto me: a piece of land worth four hundred shekels of silver, what is that betwixt me and thee? bury therefore thy dead. [^15] And Abraham hearkened unto Ephron; and Abraham weighed to Ephron the silver which he had named in the audience of the children of Heth, four hundred shekels of silver, current money with the merchant. [^16] So the field of Ephron, which was in Machpelah, which was before Mamre, the field, and the cave which was therein, and all the trees that were in the field, that were in all the border thereof round about, were made sure [^17] unto Abraham for a possession in the presence of the children of Heth, before all that went in at the gate of his city. [^18] And after this, Abraham buried Sarah his wife in the cave of the field of Machpelah before Mamre (the same is Hebron), in the land of Canaan. [^19] And the field, and the cave that is therein, were made sure unto Abraham for a possession of a burying-place by the children of Heth. [^20] 

[[Genesis - 22|<--]] Genesis - 23 [[Genesis - 24|-->]]

---
# Notes
