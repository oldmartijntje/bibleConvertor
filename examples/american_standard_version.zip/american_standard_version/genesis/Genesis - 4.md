---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 4 - American Standard Version"
---
[[Genesis - 3|<--]] Genesis - 4 [[Genesis - 5|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Genesis]]

# Genesis - 4

And the man knew Eve his wife; and she conceived, and bare Cain, and said, I have gotten a man with the help of Jehovah. [^1] And again she bare his brother Abel. And Abel was a keeper of sheep, but Cain was a tiller of the ground. [^2] And in process of time it came to pass, that Cain brought of the fruit of the ground an offering unto Jehovah. [^3] And Abel, he also brought of the firstlings of his flock and of the fat thereof. And Jehovah had respect unto Abel and to his offering: [^4] but unto Cain and to his offering he had not respect. And Cain was very wroth, and his countenance fell. [^5] And Jehovah said unto Cain, Why art thou wroth? and why is thy countenance fallen? [^6] If thou doest well, shall it not be lifted up? and if thou doest not well, sin coucheth at the door; and unto thee shall be its desire; but do thou rule over it. [^7] And Cain told Abel his brother. And it came to pass, when they were in the field, that Cain rose up against Abel his brother, and slew him. [^8] And Jehovah said unto Cain, Where is Abel thy brother? And he said, I know not: am I my brother’s keeper? [^9] And he said, What hast thou done? the voice of thy brother’s blood crieth unto me from the ground. [^10] And now cursed art thou from the ground, which hath opened its mouth to receive thy brother’s blood from thy hand; [^11] when thou tillest the ground, it shall not henceforth yield unto thee its strength; a fugitive and a wanderer shalt thou be in the earth. [^12] And Cain said unto Jehovah, My punishment is greater than I can bear. [^13] Behold, thou hast driven me out this day from the face of the ground; and from thy face shall I be hid; and I shall be a fugitive and a wanderer in the earth; and it will come to pass, that whosoever findeth me will slay me. [^14] And Jehovah said unto him, Therefore whosoever slayeth Cain, vengeance shall be taken on him sevenfold. And Jehovah appointed a sign for Cain, lest any finding him should smite him. [^15] And Cain went out from the presence of Jehovah, and dwelt in the land of Nod, on the east of Eden. [^16] And Cain knew his wife; and she conceived, and bare Enoch: and he builded a city, and called the name of the city, after the name of his son, Enoch. [^17] And unto Enoch was born Irad: and Irad begat Mehujael; and Mehujael begat Methushael; and Methushael begat Lamech. [^18] And Lamech took unto him two wives: the name of the one was Adah, and the name of the other Zillah. [^19] And Adah bare Jabal: he was the father of such as dwell in tents and have cattle. [^20] And his brother’s name was Jubal: he was the father of all such as handle the harp and pipe. [^21] And Zillah, she also bare Tubal-cain, the forger of every cutting instrument of brass and iron: and the sister of Tubal-cain was Naamah. [^22] And Lamech said unto his wives:Adah and Zillah, hear my voice;Ye wives of Lamech, hearken unto my speech:For I have slain a man for wounding me,And a young man for bruising me: [^23] If Cain shall be avenged sevenfold,Truly Lamech seventy and sevenfold. [^24] And Adam knew his wife again; and she bare a son, and called his name Seth: For, said she, God hath appointed me another seed instead of Abel; for Cain slew him. [^25] And to Seth, to him also there was born a son; and he called his name Enosh. Then began men to call upon the name of Jehovah. [^26] 

[[Genesis - 3|<--]] Genesis - 4 [[Genesis - 5|-->]]

---
# Notes
