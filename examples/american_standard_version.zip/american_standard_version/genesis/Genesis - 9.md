---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 9 - American Standard Version"
---
[[Genesis - 8|<--]] Genesis - 9 [[Genesis - 10|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Genesis]]

# Genesis - 9

And God blessed Noah and his sons, and said unto them, Be fruitful, and multiply, and replenish the earth. [^1] And the fear of you and the dread of you shall be upon every beast of the earth, and upon every bird of the heavens; with all wherewith the ground teemeth, and all the fishes of the sea, into your hand are they delivered. [^2] Every moving thing that liveth shall be food for you; as the green herb have I given you all. [^3] But flesh with the life thereof, which is the blood thereof, shall ye not eat. [^4] And surely your blood, the blood of your lives, will I require; at the hand of every beast will I require it: and at the hand of man, even at the hand of every man’s brother, will I require the life of man. [^5] Whoso sheddeth man’s blood, by man shall his blood be shed: for in the image of God made he man. [^6] And you, be ye fruitful, and multiply; bring forth abundantly in the earth, and multiply therein. [^7] And God spake unto Noah, and to his sons with him, saying, [^8] And I, behold, I establish my covenant with you, and with your seed after you; [^9] and with every living creature that is with you, the birds, the cattle, and every beast of the earth with you; of all that go out of the ark, even every beast of the earth. [^10] And I will establish my covenant with you; neither shall all flesh be cut off any more by the waters of the flood; neither shall there any more be a flood to destroy the earth. [^11] And God said, This is the token of the covenant which I make between me and you and every living creature that is with you, for perpetual generations: [^12] I do set my bow in the cloud, and it shall be for a token of a covenant between me and the earth. [^13] And it shall come to pass, when I bring a cloud over the earth, that the bow shall be seen in the cloud, [^14] and I will remember my covenant, which is between me and you and every living creature of all flesh; and the waters shall no more become a flood to destroy all flesh. [^15] And the bow shall be in the cloud; and I will look upon it, that I may remember the everlasting covenant between God and every living creature of all flesh that is upon the earth. [^16] And God said unto Noah, This is the token of the covenant which I have established between me and all flesh that is upon the earth. [^17] And the sons of Noah, that went forth from the ark, were Shem, and Ham, and Japheth: and Ham is the father of Canaan. [^18] These three were the sons of Noah: and of these was the whole earth overspread. [^19] And Noah began to be a husbandman, and planted a vineyard: [^20] and he drank of the wine, and was drunken; and he was uncovered within his tent. [^21] And Ham, the father of Canaan, saw the nakedness of his father, and told his two brethren without. [^22] And Shem and Japheth took a garment, and laid it upon both their shoulders, and went backward, and covered the nakedness of their father; and their faces were backward, and they saw not their father’s nakedness. [^23] And Noah awoke from his wine, and knew what his youngest son had done unto him. [^24] And he said,Cursed be Canaan;A servant of servants shall he be unto his brethren. [^25] And he said,Blessed be Jehovah, the God of Shem;And let Canaan be his servant. [^26] God enlarge Japheth,And let him dwell in the tents of Shem;And let Canaan be his servant. [^27] And Noah lived after the flood three hundred and fifty years. [^28] And all the days of Noah were nine hundred and fifty years: and he died. [^29] 

[[Genesis - 8|<--]] Genesis - 9 [[Genesis - 10|-->]]

---
# Notes
