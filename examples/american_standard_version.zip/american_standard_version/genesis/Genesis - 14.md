---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 14 - American Standard Version"
---
[[Genesis - 13|<--]] Genesis - 14 [[Genesis - 15|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Genesis]]

# Genesis - 14

And it came to pass in the days of Amraphel king of Shinar, Arioch king of Ellasar, Chedorlaomer king of Elam, and Tidal king of Goiim, [^1] that they made war with Bera king of Sodom, and with Birsha king of Gomorrah, Shinab king of Admah, and Shemeber king of Zeboiim, and the king of Bela (the same is Zoar). [^2] All these joined together in the vale of Siddim (the same is the Salt Sea). [^3] Twelve years they served Chedorlaomer, and in the thirteenth year they rebelled. [^4] And in the fourteenth year came Chedorlaomer, and the kings that were with him, and smote the Rephaim in Ashteroth-karnaim, and the Zuzim in Ham, and the Emim in Shaveh-kiriathaim, [^5] and the Horites in their mount Seir, unto El-paran, which is by the wilderness. [^6] And they returned, and came to En-mishpat (the same is Kadesh), and smote all the country of the Amalekites, and also the Amorites, that dwelt in Hazazon-tamar. [^7] And there went out the king of Sodom, and the king of Gomorrah, and the king of Admah, and the king of Zeboiim, and the king of Bela (the same is Zoar); and they set the battle in array against them in the vale of Siddim; [^8] against Chedorlaomer king of Elam, and Tidal king of Goiim, and Amraphel king of Shinar, and Arioch king of Ellasar; four kings against the five. [^9] Now the vale of Siddim was full of slime pits; and the kings of Sodom and Gomorrah fled, and they fell there, and they that remained fled to the mountain. [^10] And they took all the goods of Sodom and Gomorrah, and all their victuals, and went their way. [^11] And they took Lot, Abram’s brother’s son, who dwelt in Sodom, and his goods, and departed. [^12] And there came one that had escaped, and told Abram the Hebrew: now he dwelt by the oaks of Mamre, the Amorite, brother of Eshcol, and brother of Aner; and these were confederate with Abram. [^13] And when Abram heard that his brother was taken captive, he led forth his trained men, born in his house, three hundred and eighteen, and pursued as far as Dan. [^14] And he divided himself against them by night, he and his servants, and smote them, and pursued them unto Hobah, which is on the left hand of Damascus. [^15] And he brought back all the goods, and also brought back his brother Lot, and his goods, and the women also, and the people. [^16] And the king of Sodom went out to meet him, after his return from the slaughter of Chedorlaomer and the kings that were with him, at the vale of Shaveh (the same is the King’s Vale). [^17] And Melchizedek king of Salem brought forth bread and wine: and he was priest of God Most High. [^18] And he blessed him, and said, Blessed be Abram of God Most High, possessor of heaven and earth: [^19] and blessed be God Most High, who hath delivered thine enemies into thy hand. And he gave him a tenth of all. [^20] And the king of Sodom said unto Abram, Give me the persons, and take the goods to thyself. [^21] And Abram said to the king of Sodom, I have lifted up my hand unto Jehovah, God Most High, possessor of heaven and earth, [^22] that I will not take a thread nor a shoe-latchet nor aught that is thine, lest thou shouldest say, I have made Abram rich: [^23] save only that which the young men have eaten, and the portion of the men that went with me, Aner, Eshcol, and Mamre; let them take their portion. [^24] 

[[Genesis - 13|<--]] Genesis - 14 [[Genesis - 15|-->]]

---
# Notes
