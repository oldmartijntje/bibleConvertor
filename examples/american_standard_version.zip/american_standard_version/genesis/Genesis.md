---
translation: American Standard Version
aliases:
  - "Genesis - American Standard Version"
tags:
  - "#bible/type/book"
  - "#bible/book/genesis"
  - "#bible/testament/old"
---
Genesis [[Exodus|-->]]

# Genesis - American Standard Version

The Genesis book has 50 chapters. It is part of the old testament. It is the first book of the bible.

## Chapters

- Genesis [[Genesis - 1|chapter 1]]
- Genesis [[Genesis - 2|chapter 2]]
- Genesis [[Genesis - 3|chapter 3]]
- Genesis [[Genesis - 4|chapter 4]]
- Genesis [[Genesis - 5|chapter 5]]
- Genesis [[Genesis - 6|chapter 6]]
- Genesis [[Genesis - 7|chapter 7]]
- Genesis [[Genesis - 8|chapter 8]]
- Genesis [[Genesis - 9|chapter 9]]
- Genesis [[Genesis - 10|chapter 10]]
- Genesis [[Genesis - 11|chapter 11]]
- Genesis [[Genesis - 12|chapter 12]]
- Genesis [[Genesis - 13|chapter 13]]
- Genesis [[Genesis - 14|chapter 14]]
- Genesis [[Genesis - 15|chapter 15]]
- Genesis [[Genesis - 16|chapter 16]]
- Genesis [[Genesis - 17|chapter 17]]
- Genesis [[Genesis - 18|chapter 18]]
- Genesis [[Genesis - 19|chapter 19]]
- Genesis [[Genesis - 20|chapter 20]]
- Genesis [[Genesis - 21|chapter 21]]
- Genesis [[Genesis - 22|chapter 22]]
- Genesis [[Genesis - 23|chapter 23]]
- Genesis [[Genesis - 24|chapter 24]]
- Genesis [[Genesis - 25|chapter 25]]
- Genesis [[Genesis - 26|chapter 26]]
- Genesis [[Genesis - 27|chapter 27]]
- Genesis [[Genesis - 28|chapter 28]]
- Genesis [[Genesis - 29|chapter 29]]
- Genesis [[Genesis - 30|chapter 30]]
- Genesis [[Genesis - 31|chapter 31]]
- Genesis [[Genesis - 32|chapter 32]]
- Genesis [[Genesis - 33|chapter 33]]
- Genesis [[Genesis - 34|chapter 34]]
- Genesis [[Genesis - 35|chapter 35]]
- Genesis [[Genesis - 36|chapter 36]]
- Genesis [[Genesis - 37|chapter 37]]
- Genesis [[Genesis - 38|chapter 38]]
- Genesis [[Genesis - 39|chapter 39]]
- Genesis [[Genesis - 40|chapter 40]]
- Genesis [[Genesis - 41|chapter 41]]
- Genesis [[Genesis - 42|chapter 42]]
- Genesis [[Genesis - 43|chapter 43]]
- Genesis [[Genesis - 44|chapter 44]]
- Genesis [[Genesis - 45|chapter 45]]
- Genesis [[Genesis - 46|chapter 46]]
- Genesis [[Genesis - 47|chapter 47]]
- Genesis [[Genesis - 48|chapter 48]]
- Genesis [[Genesis - 49|chapter 49]]
- Genesis [[Genesis - 50|chapter 50]]

Genesis [[Exodus|-->]]

---
# Notes
