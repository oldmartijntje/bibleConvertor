---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 10 - American Standard Version"
---
[[Genesis - 9|<--]] Genesis - 10 [[Genesis - 11|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Genesis]]

# Genesis - 10

Now these are the generations of the sons of Noah, namely, of Shem, Ham, and Japheth: and unto them were sons born after the flood. [^1] The sons of Japheth: Gomer, and Magog, and Madai, and Javan, and Tubal, and Meshech, and Tiras. [^2] And the sons of Gomer: Ashkenaz, and Riphath, and Togarmah. [^3] And the sons of Javan: Elishah, and Tarshish, Kittim, and Dodanim. [^4] Of these were the isles of the nations divided in their lands, every one after his tongue, after their families, in their nations. [^5] And the sons of Ham: Cush, and Mizraim, and Put, and Canaan. [^6] And the sons of Cush: Seba, and Havilah, and Sabtah, and Raamah, and Sabteca; and the sons of Raamah: Sheba, and Dedan. [^7] And Cush begat Nimrod: he began to be a mighty one in the earth. [^8] He was a mighty hunter before Jehovah: wherefore it is said, Like Nimrod a mighty hunter before Jehovah. [^9] And the beginning of his kingdom was Babel, and Erech, and Accad, and Calneh, in the land of Shinar. [^10] Out of that land he went forth into Assyria, and builded Nineveh, and Rehoboth-Ir, and Calah, [^11] and Resen between Nineveh and Calah (the same is the great city). [^12] And Mizraim begat Ludim, and Anamim, and Lehabim, and Naphtuhim, [^13] and Pathrusim, and Casluhim (whence went forth the Philistines), and Caphtorim. [^14] And Canaan begat Sidon his first-born, and Heth, [^15] and the Jebusite, and the Amorite, and the Girgashite, [^16] and the Hivite, and the Arkite, and the Sinite, [^17] and the Arvadite, and the Zemarite, and the Hamathite: and afterward were the families of the Canaanite spread abroad. [^18] And the border of the Canaanite was from Sidon, as thou goest toward Gerar, unto Gaza; as thou goest toward Sodom and Gomorrah and Admah and Zeboiim, unto Lasha. [^19] These are the sons of Ham, after their families, after their tongues, in their lands, in their nations. [^20] And unto Shem, the father of all the children of Eber, the elder brother of Japheth, to him also were children born. [^21] The sons of Shem: Elam, and Asshur, and Arpachshad, and Lud, and Aram. [^22] And the sons of Aram: Uz, and Hul, and Gether, and Mash. [^23] And Arpachshad begat Shelah; and Shelah begat Eber. [^24] And unto Eber were born two sons: the name of the one was Peleg; for in his days was the earth divided; and his brother’s name was Joktan. [^25] And Joktan begat Almodad, and Sheleph, and Hazarmaveth, and Jerah, [^26] and Hadoram, and Uzal, and Diklah, [^27] and Obal, and Abimael, and Sheba, [^28] and Ophir, and Havilah, and Jobab: all these were the sons of Joktan. [^29] And their dwelling was from Mesha, as thou goest toward Sephar, the mountain of the east. [^30] These are the sons of Shem, after their families, after their tongues, in their lands, after their nations. [^31] These are the families of the sons of Noah, after their generations, in their nations: and of these were the nations divided in the earth after the flood. [^32] 

[[Genesis - 9|<--]] Genesis - 10 [[Genesis - 11|-->]]

---
# Notes
