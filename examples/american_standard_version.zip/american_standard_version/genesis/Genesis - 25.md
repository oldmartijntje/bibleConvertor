---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 25 - American Standard Version"
---
[[Genesis - 24|<--]] Genesis - 25 [[Genesis - 26|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Genesis]]

# Genesis - 25

And Abraham took another wife, and her name was Keturah. [^1] And she bare him Zimran, and Jokshan, and Medan, and Midian, and Ishbak, and Shuah. [^2] And Jokshan begat Sheba, and Dedan. And the sons of Dedan were Asshurim, and Letushim, and Leummim. [^3] And the sons of Midian: Ephah, and Epher, and Hanoch, and Abida, and Eldaah. All these were the children of Keturah. [^4] And Abraham gave all that he had unto Isaac. [^5] But unto the sons of the concubines, that Abraham had, Abraham gave gifts; and he sent them away from Isaac his son, while he yet lived, eastward, unto the east country. [^6] And these are the days of the years of Abraham’s life which he lived, a hundred threescore and fifteen years. [^7] And Abraham gave up the ghost, and died in a good old age, an old man, and full of years, and was gathered to his people. [^8] And Isaac and Ishmael his sons buried him in the cave of Machpelah, in the field of Ephron the son of Zohar the Hittite, which is before Mamre; [^9] the field which Abraham purchased of the children of Heth: there was Abraham buried, and Sarah his wife. [^10] And it came to pass after the death of Abraham, that God blessed Isaac his son: and Isaac dwelt by Beer-lahai-roi. [^11] Now these are the generations of Ishmael, Abraham’s son, whom Hagar the Egyptian, Sarah’s handmaid, bare unto Abraham: [^12] and these are the names of the sons of Ishmael, by their names, according to their generations: the first-born of Ishmael, Nebaioth; and Kedar, and Adbeel, and Mibsam, [^13] and Mishma, and Dumah, and Massa, [^14] Hadad, and Tema, Jetur, Naphish, and Kedemah: [^15] these are the sons of Ishmael, and these are their names, by their villages, and by their encampments; twelve princes according to their nations. [^16] And these are the years of the life of Ishmael, a hundred and thirty and seven years: and he gave up the ghost and died, and was gathered unto his people. [^17] And they dwelt from Havilah unto Shur that is before Egypt, as thou goest toward Assyria: he abode over against all his brethren. [^18] And these are the generations of Isaac, Abraham’s son: Abraham begat Isaac: [^19] and Isaac was forty years old when he took Rebekah, the daughter of Bethuel the Syrian of Paddan-aram, the sister of Laban the Syrian, to be his wife. [^20] And Isaac entreated Jehovah for his wife, because she was barren: and Jehovah was entreated of him, and Rebekah his wife conceived. [^21] And the children struggled together within her; and she said, If it be so, wherefore do I live? And she went to inquire of Jehovah. [^22] And Jehovah said unto her,Two nations are in thy womb,And two peoples shall be separated from thy bowels:And the one people shall be stronger than the other people;And the elder shall serve the younger. [^23] And when her days to be delivered were fulfilled, behold, there were twins in her womb. [^24] And the first came forth red, all over like a hairy garment; and they called his name Esau. [^25] And after that came forth his brother, and his hand had hold on Esau’s heel; and his name was called Jacob: and Isaac was threescore years old when she bare them. [^26] And the boys grew: and Esau was a skilful hunter, a man of the field; and Jacob was a quiet man, dwelling in tents. [^27] Now Isaac loved Esau, because he did eat of his venison: and Rebekah loved Jacob. [^28] And Jacob boiled pottage: and Esau came in from the field, and he was faint: [^29] and Esau said to Jacob, Feed me, I pray thee, with that same red pottage; for I am faint: therefore was his name called Edom. [^30] And Jacob said, Sell me first thy birthright. [^31] And Esau said, Behold, I am about to die: and what profit shall the birthright do to me? [^32] And Jacob said, Swear to me first; and he sware unto him: and he sold his birthright unto Jacob. [^33] And Jacob gave Esau bread and pottage of lentils; and he did eat and drink, and rose up, and went his way: so Esau despised his birthright. [^34] 

[[Genesis - 24|<--]] Genesis - 25 [[Genesis - 26|-->]]

---
# Notes
