---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 15 - American Standard Version"
---
[[Genesis - 14|<--]] Genesis - 15 [[Genesis - 16|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Genesis]]

# Genesis - 15

After these things the word of Jehovah came unto Abram in a vision, saying, Fear not, Abram: I am thy shield, and thy exceeding great reward. [^1] And Abram said, O Lord Jehovah, what wilt thou give me, seeing I go childless, and he that shall be possessor of my house is Eliezer of Damascus? [^2] And Abram said, Behold, to me thou hast given no seed: and, lo, one born in my house is mine heir. [^3] And, behold, the word of Jehovah came unto him, saying, This man shall not be thine heir; but he that shall come forth out of thine own bowels shall be thine heir. [^4] And he brought him forth abroad, and said, Look now toward heaven, and number the stars, if thou be able to number them: and he said unto him, So shall thy seed be. [^5] And he believed in Jehovah; and he reckoned it to him for righteousness. [^6] And he said unto him, I am Jehovah that brought thee out of Ur of the Chaldees, to give thee this land to inherit it. [^7] And he said, O Lord Jehovah, whereby shall I know that I shall inherit it? [^8] And he said unto him, Take me a heifer three years old, and a she-goat three years old, and a ram three years old, and a turtle-dove, and a young pigeon. [^9] And he took him all these, and divided them in the midst, and laid each half over against the other: but the birds divided he not. [^10] And the birds of prey came down upon the carcasses, and Abram drove them away. [^11] And when the sun was going down, a deep sleep fell upon Abram; and, lo, a horror of great darkness fell upon him. [^12] And he said unto Abram, Know of a surety that thy seed shall be sojourners in a land that is not theirs, and shall serve them; and they shall afflict them four hundred years; [^13] and also that nation, whom they shall serve, will I judge: and afterward shall they come out with great substance. [^14] But thou shalt go to thy fathers in peace; thou shalt be buried in a good old age. [^15] And in the fourth generation they shall come hither again: for the iniquity of the Amorite is not yet full. [^16] And it came to pass, that, when the sun went down, and it was dark, behold, a smoking furnace, and a flaming torch that passed between these pieces. [^17] In that day Jehovah made a covenant with Abram, saying, Unto thy seed have I given this land, from the river of Egypt unto the great river, the river Euphrates: [^18] the Kenite, and the Kenizzite, and the Kadmonite, [^19] and the Hittite, and the Perizzite, and the Rephaim, [^20] and the Amorite, and the Canaanite, and the Girgashite, and the Jebusite. [^21] 

[[Genesis - 14|<--]] Genesis - 15 [[Genesis - 16|-->]]

---
# Notes
