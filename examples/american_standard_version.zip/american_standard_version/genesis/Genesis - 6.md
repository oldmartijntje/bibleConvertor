---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 6 - American Standard Version"
---
[[Genesis - 5|<--]] Genesis - 6 [[Genesis - 7|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Genesis]]

# Genesis - 6

And it came to pass, when men began to multiply on the face of the ground, and daughters were born unto them, [^1] that the sons of God saw the daughters of men that they were fair; and they took them wives of all that they chose. [^2] And Jehovah said, My Spirit shall not strive with man for ever, for that he also is flesh: yet shall his days be a hundred and twenty years. [^3] The Nephilim were in the earth in those days, and also after that, when the sons of God came in unto the daughters of men, and they bare children to them: the same were the mighty men that were of old, the men of renown. [^4] And Jehovah saw that the wickedness of man was great in the earth, and that every imagination of the thoughts of his heart was only evil continually. [^5] And it repented Jehovah that he had made man on the earth, and it grieved him at his heart. [^6] And Jehovah said, I will destroy man whom I have created from the face of the ground; both man, and beast, and creeping things, and birds of the heavens; for it repenteth me that I have made them. [^7] But Noah found favor in the eyes of Jehovah. [^8] These are the generations of Noah. Noah was a righteous man, and perfect in his generations: Noah walked with God. [^9] And Noah begat three sons, Shem, Ham, and Japheth. [^10] And the earth was corrupt before God, and the earth was filled with violence. [^11] And God saw the earth, and, behold, it was corrupt; for all flesh had corrupted their way upon the earth. [^12] And God said unto Noah, The end of all flesh is come before me; for the earth is filled with violence through them; and, behold, I will destroy them with the earth. [^13] Make thee an ark of gopher wood; rooms shalt thou make in the ark, and shalt pitch it within and without with pitch. [^14] And this is how thou shalt make it: the length of the ark three hundred cubits, the breadth of it fifty cubits, and the height of it thirty cubits. [^15] A light shalt thou make to the ark, and to a cubit shalt thou finish it upward; and the door of the ark shalt thou set in the side thereof; with lower, second, and third stories shalt thou make it. [^16] And I, behold, I do bring the flood of waters upon the earth, to destroy all flesh, wherein is the breath of life, from under heaven; everything that is in the earth shall die. [^17] But I will establish my covenant with thee; and thou shalt come into the ark, thou, and thy sons, and thy wife, and thy sons’ wives with thee. [^18] And of every living thing of all flesh, two of every sort shalt thou bring into the ark, to keep them alive with thee; they shall be male and female. [^19] Of the birds after their kind, and of the cattle after their kind, of every creeping thing of the ground after its kind, two of every sort shall come unto thee, to keep them alive. [^20] And take thou unto thee of all food that is eaten, and gather it to thee; and it shall be for food for thee, and for them. [^21] Thus did Noah; according to all that God commanded him, so did he. [^22] 

[[Genesis - 5|<--]] Genesis - 6 [[Genesis - 7|-->]]

---
# Notes
