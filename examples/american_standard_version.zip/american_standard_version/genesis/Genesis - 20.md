---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 20 - American Standard Version"
---
[[Genesis - 19|<--]] Genesis - 20 [[Genesis - 21|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Genesis]]

# Genesis - 20

And Abraham journeyed from thence toward the land of the South, and dwelt between Kadesh and Shur; and he sojourned in Gerar. [^1] And Abraham said of Sarah his wife, She is my sister: and Abimelech king of Gerar sent, and took Sarah. [^2] But God came to Abimelech in a dream of the night, and said to him, Behold, thou art but a dead man, because of the woman whom thou hast taken; for she is a man’s wife. [^3] Now Abimelech had not come near her: and he said, Lord, wilt thou slay even a righteous nation? [^4] Said he not himself unto me, She is my sister? and she, even she herself said, He is my brother: in the integrity of my heart and the innocency of my hands have I done this. [^5] And God said unto him in the dream, Yea, I know that in the integrity of thy heart thou hast done this, and I also withheld thee from sinning against me: therefore suffered I thee not to touch her. [^6] Now therefore restore the man’s wife; for he is a prophet, and he shall pray for thee, and thou shalt live: and if thou restore her not, know thou that thou shalt surely die, thou, and all that are thine. [^7] And Abimelech rose early in the morning, and called all his servants, and told all these things in their ears: and the men were sore afraid. [^8] Then Abimelech called Abraham, and said unto him, What hast thou done unto us? and wherein have I sinned against thee, that thou hast brought on me and on my kingdom a great sin? thou hast done deeds unto me that ought not to be done. [^9] And Abimelech said unto Abraham, What sawest thou, that thou hast done this thing? [^10] And Abraham said, Because I thought, Surely the fear of God is not in this place; and they will slay me for my wife’s sake. [^11] And moreover she is indeed my sister, the daughter of my father, but not the daughter of my mother; and she became my wife: [^12] and it came to pass, when God caused me to wander from my father’s house, that I said unto her, This is thy kindness which thou shalt show unto me: at every place whither we shall come, say of me, He is my brother. [^13] And Abimelech took sheep and oxen, and men-servants and women-servants, and gave them unto Abraham, and restored him Sarah his wife. [^14] And Abimelech said, Behold, my land is before thee: dwell where it pleaseth thee. [^15] And unto Sarah he said, Behold, I have given thy brother a thousand pieces of silver: behold, it is for thee a covering of the eyes to all that are with thee; and in respect of all thou art righted. [^16] And Abraham prayed unto God: and God healed Abimelech, and his wife, and his maid-servants; and they bare children. [^17] For Jehovah had fast closed up all the wombs of the house of Abimelech, because of Sarah, Abraham’s wife. [^18] 

[[Genesis - 19|<--]] Genesis - 20 [[Genesis - 21|-->]]

---
# Notes
