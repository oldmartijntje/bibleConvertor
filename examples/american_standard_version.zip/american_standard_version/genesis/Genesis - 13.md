---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 13 - American Standard Version"
---
[[Genesis - 12|<--]] Genesis - 13 [[Genesis - 14|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Genesis]]

# Genesis - 13

And Abram went up out of Egypt, he, and his wife, and all that he had, and Lot with him, into the South. [^1] And Abram was very rich in cattle, in silver, and in gold. [^2] And he went on his journeys from the South even to Beth-el, unto the place where his tent had been at the beginning, between Beth-el and Ai, [^3] unto the place of the altar, which he had made there at the first: and there Abram called on the name of Jehovah. [^4] And Lot also, who went with Abram, had flocks, and herds, and tents. [^5] And the land was not able to bear them, that they might dwell together: for their substance was great, so that they could not dwell together. [^6] And there was a strife between the herdsmen of Abram’s cattle and the herdsmen of Lot’s cattle: and the Canaanite and the Perizzite dwelt then in the land. [^7] And Abram said unto Lot, Let there be no strife, I pray thee, between me and thee, and between my herdsmen and thy herdsmen; for we are brethren. [^8] Is not the whole land before thee? separate thyself, I pray thee, from me: if thou wilt take the left hand, then I will go to the right; or if thou take the right hand, then I will go to the left. [^9] And Lot lifted up his eyes, and beheld all the Plain of the Jordan, that it was well watered every where, before Jehovah destroyed Sodom and Gomorrah, like the garden of Jehovah, like the land of Egypt, as thou goest unto Zoar. [^10] So Lot chose him all the Plain of the Jordan; and Lot journeyed east: and they separated themselves the one from the other. [^11] Abram dwelt in the land of Canaan, and Lot dwelt in the cities of the Plain, and moved his tent as far as Sodom. [^12] Now the men of Sodom were wicked and sinners against Jehovah exceedingly. [^13] And Jehovah said unto Abram, after that Lot was separated from him, Lift up now thine eyes, and look from the place where thou art, northward and southward and eastward and westward: [^14] for all the land which thou seest, to thee will I give it, and to thy seed for ever. [^15] And I will make thy seed as the dust of the earth: so that if a man can number the dust of the earth, then may thy seed also be numbered. [^16] Arise, walk through the land in the length of it and in the breadth of it; for unto thee will I give it. [^17] And Abram moved his tent, and came and dwelt by the oaks of Mamre, which are in Hebron, and built there an altar unto Jehovah. [^18] 

[[Genesis - 12|<--]] Genesis - 13 [[Genesis - 14|-->]]

---
# Notes
