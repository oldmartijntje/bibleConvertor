---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 12 - American Standard Version"
---
[[Genesis - 11|<--]] Genesis - 12 [[Genesis - 13|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Genesis]]

# Genesis - 12

Now Jehovah said unto Abram, Get thee out of thy country, and from thy kindred, and from thy father’s house, unto the land that I will show thee: [^1] and I will make of thee a great nation, and I will bless thee, and make thy name great; and be thou a blessing: [^2] and I will bless them that bless thee, and him that curseth thee will I curse: and in thee shall all the families of the earth be blessed. [^3] So Abram went, as Jehovah had spoken unto him; and Lot went with him: and Abram was seventy and five years old when he departed out of Haran. [^4] And Abram took Sarai his wife, and Lot his brother’s son, and all their substance that they had gathered, and the souls that they had gotten in Haran; and they went forth to go into the land of Canaan; and into the land of Canaan they came. [^5] And Abram passed through the land unto the place of Shechem, unto the oak of Moreh. And the Canaanite was then in the land. [^6] And Jehovah appeared unto Abram, and said, Unto thy seed will I give this land: and there builded he an altar unto Jehovah, who appeared unto him. [^7] And he removed from thence unto the mountain on the east of Beth-el, and pitched his tent, having Beth-el on the west, and Ai on the east: and there he builded an altar unto Jehovah, and called upon the name of Jehovah. [^8] And Abram journeyed, going on still toward the South. [^9] And there was a famine in the land: and Abram went down into Egypt to sojourn there; for the famine was sore in the land. [^10] And it came to pass, when he was come near to enter into Egypt, that he said unto Sarai his wife, Behold now, I know that thou art a fair woman to look upon: [^11] and it will come to pass, when the Egyptians shall see thee, that they will say, This is his wife: and they will kill me, but they will save thee alive. [^12] Say, I pray thee, thou art my sister; that it may be well with me for thy sake, and that my soul may live because of thee. [^13] And it came to pass, that, when Abram was come into Egypt, the Egyptians beheld the woman that she was very fair. [^14] And the princes of Pharaoh saw her, and praised her to Pharaoh: and the woman was taken into Pharaoh’s house. [^15] And he dealt well with Abram for her sake: and he had sheep, and oxen, and he-asses, and men-servants, and maid-servants, and she-asses, and camels. [^16] And Jehovah plagued Pharaoh and his house with great plagues because of Sarai, Abram’s wife. [^17] And Pharaoh called Abram, and said, What is this that thou hast done unto me? why didst thou not tell me that she was thy wife? [^18] why saidst thou, She is my sister, so that I took her to be my wife? now therefore behold thy wife, take her, and go thy way. [^19] And Pharaoh gave men charge concerning him: and they brought him on the way, and his wife, and all that he had. [^20] 

[[Genesis - 11|<--]] Genesis - 12 [[Genesis - 13|-->]]

---
# Notes
