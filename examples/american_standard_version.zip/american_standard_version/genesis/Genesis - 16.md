---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 16 - American Standard Version"
---
[[Genesis - 15|<--]] Genesis - 16 [[Genesis - 17|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Genesis]]

# Genesis - 16

Now Sarai, Abram’s wife, bare him no children: and she had a handmaid, an Egyptian, whose name was Hagar. [^1] And Sarai said unto Abram, Behold now, Jehovah hath restrained me from bearing; go in, I pray thee, unto my handmaid; it may be that I shall obtain children by her. And Abram hearkened to the voice of Sarai. [^2] And Sarai, Abram’s wife, took Hagar the Egyptian, her handmaid, after Abram had dwelt ten years in the land of Canaan, and gave her to Abram her husband to be his wife. [^3] And he went in unto Hagar, and she conceived: and when she saw that she had conceived, her mistress was despised in her eyes. [^4] And Sarai said unto Abram, My wrong be upon thee: I gave my handmaid into thy bosom; and when she saw that she had conceived, I was despised in her eyes: Jehovah judge between me and thee. [^5] But Abram said unto Sarai, Behold, thy maid is in thy hand; do to her that which is good in thine eyes. And Sarai dealt hardly with her, and she fled from her face. [^6] And the angel of Jehovah found her by a fountain of water in the wilderness, by the fountain in the way to Shur. [^7] And he said, Hagar, Sarai’s handmaid, whence camest thou? and whither goest thou? And she said, I am fleeing from the face of my mistress Sarai. [^8] And the angel of Jehovah said unto her, Return to thy mistress, and submit thyself under her hands. [^9] And the angel of Jehovah said unto her, I will greatly multiply thy seed, that it shall not be numbered for multitude. [^10] And the angel of Jehovah said unto her, Behold, thou art with child, and shalt bear a son; and thou shalt call his name Ishmael, because Jehovah hath heard thy affliction. [^11] And he shall be as a wild ass among men; his hand shall be against every man, and every man’s hand against him; and he shall dwell over against all his brethren. [^12] And she called the name of Jehovah that spake unto her, Thou art a God that seeth: for she said, Have I even here looked after him that seeth me? [^13] Wherefore the well was called Beer-lahai-roi; behold, it is between Kadesh and Bered. [^14] And Hagar bare Abram a son: and Abram called the name of his son, whom Hagar bare, Ishmael. [^15] And Abram was fourscore and six years old, when Hagar bare Ishmael to Abram. [^16] 

[[Genesis - 15|<--]] Genesis - 16 [[Genesis - 17|-->]]

---
# Notes
