---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 24 - American Standard Version"
---
[[Numbers - 23|<--]] Numbers - 24 [[Numbers - 25|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Numbers]]

# Numbers - 24

And when Balaam saw that it pleased Jehovah to bless Israel, he went not, as at the other times, to meet with enchantments, but he set his face toward the wilderness. [^1] And Balaam lifted up his eyes, and he saw Israel dwelling according to their tribes; and the Spirit of God came upon him. [^2] And he took up his parable, and said,Balaam the son of Beor saith,And the man whose eye was closed saith; [^3] He saith, who heareth the words of God,Who seeth the vision of the Almighty,Falling down, and having his eyes open: [^4] How goodly are thy tents, O Jacob,Thy tabernacles, O Israel! [^5] As valleys are they spread forth,As gardens by the river-side,As lign-aloes which Jehovah hath planted,As cedar-trees beside the waters. [^6] Water shall flow from his buckets,And his seed shall be in many waters,And his king shall be higher than Agag,And his kingdom shall be exalted. [^7] God bringeth him forth out of Egypt;He hath as it were the strength of the wild-ox:He shall eat up the nations his adversaries,And shall break their bones in pieces,And smite them through with his arrows. [^8] He couched, he lay down as a lion,And as a lioness; who shall rouse him up?Blessed be every one that blesseth thee,And cursed be every one that curseth thee. [^9] And Balak’s anger was kindled against Balaam, and he smote his hands together; and Balak said unto Balaam, I called thee to curse mine enemies, and, behold, thou hast altogether blessed them these three times. [^10] Therefore now flee thou to thy place: I thought to promote thee unto great honor; but, lo, Jehovah hath kept thee back from honor. [^11] And Balaam said unto Balak, Spake I not also to thy messengers that thou sentest unto me, saying, [^12] If Balak would give me his house full of silver and gold, I cannot go beyond the word of Jehovah, to do either good or bad of mine own mind; what Jehovah speaketh, that will I speak? [^13] And now, behold, I go unto my people: come, and I will advertise thee what this people shall do to thy people in the latter days. [^14] And he took up his parable, and said,Balaam the son of Beor saith,And the man whose eye was closed saith; [^15] He saith, who heareth the words of God,And knoweth the knowledge of the Most High,Who seeth the vision of the Almighty,Falling down, and having his eyes open: [^16] I see him, but not now;I behold him, but not nigh:There shall come forth a star out of Jacob,And a sceptre shall rise out of Israel,And shall smite through the corners of Moab,And break down all the sons of tumult. [^17] And Edom shall be a possession,Seir also shall be a possession, who were his enemies;While Israel doeth valiantly. [^18] And out of Jacob shall one have dominion,And shall destroy the remnant from the city. [^19] And he looked on Amalek, and took up his parable, and said,Amalek was the first of the nations;But his latter end shall come to destruction. [^20] And he looked on the Kenite, and took up his parable, and said,Strong is thy dwelling-place,And thy nest is set in the rock. [^21] Nevertheless Kain shall be wasted,Until Asshur shall carry thee away captive. [^22] And he took up his parable, and said,Alas, who shall live when God doeth this? [^23] But ships shall come from the coast of Kittim,And they shall afflict Asshur, and shall afflict Eber;And he also shall come to destruction. [^24] And Balaam rose up, and went and returned to his place; and Balak also went his way. [^25] 

[[Numbers - 23|<--]] Numbers - 24 [[Numbers - 25|-->]]

---
# Notes
