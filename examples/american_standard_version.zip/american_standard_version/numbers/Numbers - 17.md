---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 17 - American Standard Version"
---
[[Numbers - 16|<--]] Numbers - 17 [[Numbers - 18|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Numbers]]

# Numbers - 17

And Jehovah spake unto Moses, saying, [^1] Speak unto the children of Israel, and take of them rods, one for each fathers’ house, of all their princes according to their fathers’ houses, twelve rods: write thou every man’s name upon his rod. [^2] And thou shalt write Aaron’s name upon the rod of Levi; for there shall be one rod for each head of their fathers’ houses. [^3] And thou shalt lay them up in the tent of meeting before the testimony, where I meet with you. [^4] And it shall come to pass, that the rod of the man whom I shall choose shall bud: and I will make to cease from me the murmurings of the children of Israel, which they murmur against you. [^5] And Moses spake unto the children of Israel; and all their princes gave him rods, for each prince one, according to their fathers’ houses, even twelve rods: and the rod of Aaron was among their rods. [^6] And Moses laid up the rods before Jehovah in the tent of the testimony. [^7] And it came to pass on the morrow, that Moses went into the tent of the testimony; and, behold, the rod of Aaron for the house of Levi was budded, and put forth buds, and produced blossoms, and bare ripe almonds. [^8] And Moses brought out all the rods from before Jehovah unto all the children of Israel: and they looked, and took every man his rod. [^9] And Jehovah said unto Moses, Put back the rod of Aaron before the testimony, to be kept for a token against the children of rebellion; that thou mayest make an end of their murmurings against me, that they die not. [^10] Thus did Moses: as Jehovah commanded him, so did he. [^11] And the children of Israel spake unto Moses, saying, Behold, we perish, we are undone, we are all undone. [^12] Every one that cometh near, that cometh near unto the tabernacle of Jehovah, dieth: shall we perish all of us? [^13] 

[[Numbers - 16|<--]] Numbers - 17 [[Numbers - 18|-->]]

---
# Notes
