---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 36 - American Standard Version"
---
[[Numbers - 35|<--]] Numbers - 36

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Numbers]]

# Numbers - 36

And the heads of the fathers’ houses of the family of the children of Gilead, the son of Machir, the son of Manasseh, of the families of the sons of Joseph, came near, and spake before Moses, and before the princes, the heads of the fathers’ houses of the children of Israel: [^1] and they said, Jehovah commanded my lord to give the land for inheritance by lot to the children of Israel: and my lord was commanded by Jehovah to give the inheritance of Zelophehad our brother unto his daughters. [^2] And if they be married to any of the sons of the other tribes of the children of Israel, then will their inheritance be taken away from the inheritance of our fathers, and will be added to the inheritance of the tribe whereunto they shall belong: so will it be taken away from the lot of our inheritance. [^3] And when the jubilee of the children of Israel shall be, then will their inheritance be added unto the inheritance of the tribe whereunto they shall belong: so will their inheritance be taken away from the inheritance of the tribe of our fathers. [^4] And Moses commanded the children of Israel according to the word of Jehovah, saying, The tribe of the sons of Joseph speaketh right. [^5] This is the thing which Jehovah doth command concerning the daughters of Zelophehad, saying, Let them be married to whom they think best; only into the family of the tribe of their father shall they be married. [^6] So shall no inheritance of the children of Israel remove from tribe to tribe; for the children of Israel shall cleave every one to the inheritance of the tribe of his fathers. [^7] And every daughter, that possesseth an inheritance in any tribe of the children of Israel, shall be wife unto one of the family of the tribe of her father, that the children of Israel may possess every man the inheritance of his fathers. [^8] So shall no inheritance remove from one tribe to another tribe; for the tribes of the children of Israel shall cleave every one to his own inheritance. [^9] Even as Jehovah commanded Moses, so did the daughters of Zelophehad: [^10] for Mahlah, Tirzah, and Hoglah, and Milcah, and Noah, the daughters of Zelophehad, were married unto their father’s brothers’ sons. [^11] They were married into the families of the sons of Manasseh the son of Joseph; and their inheritance remained in the tribe of the family of their father. [^12] These are the commandments and the ordinances which Jehovah commanded by Moses unto the children of Israel in the plains of Moab by the Jordan at Jericho. [^13] 

[[Numbers - 35|<--]] Numbers - 36

---
# Notes
