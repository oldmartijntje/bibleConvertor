---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 19 - American Standard Version"
---
[[Numbers - 18|<--]] Numbers - 19 [[Numbers - 20|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Numbers]]

# Numbers - 19

And Jehovah spake unto Moses and unto Aaron, saying, [^1] This is the statute of the law which Jehovah hath commanded, saying, Speak unto the children of Israel, that they bring thee a red heifer without spot, wherein is no blemish, and upon which never came yoke. [^2] And ye shall give her unto Eleazar the priest, and he shall bring her forth without the camp, and one shall slay her before his face: [^3] and Eleazar the priest shall take of her blood with his finger, and sprinkle her blood toward the front of the tent of meeting seven times. [^4] And one shall burn the heifer in his sight; her skin, and her flesh, and her blood, with her dung, shall he burn: [^5] and the priest shall take cedar-wood, and hyssop, and scarlet, and cast it into the midst of the burning of the heifer. [^6] Then the priest shall wash his clothes, and he shall bathe his flesh in water, and afterward he shall come into the camp, and the priest shall be unclean until the even. [^7] And he that burneth her shall wash his clothes in water, and bathe his flesh in water, and shall be unclean until the even. [^8] And a man that is clean shall gather up the ashes of the heifer, and lay them up without the camp in a clean place; and it shall be kept for the congregation of the children of Israel for a water for impurity: it is a sin-offering. [^9] And he that gathereth the ashes of the heifer shall wash his clothes, and be unclean until the even: and it shall be unto the children of Israel, and unto the stranger that sojourneth among them, for a statute for ever. [^10] He that toucheth the dead body of any man shall be unclean seven days: [^11] the same shall purify himself therewith on the third day, and on the seventh day he shall be clean: but if he purify not himself the third day, then the seventh day he shall not be clean. [^12] Whosoever toucheth a dead person, the body of a man that hath died, and purifieth not himself, defileth the tabernacle of Jehovah; and that soul shall be cut off from Israel: because the water for impurity was not sprinkled upon him, he shall be unclean; his uncleanness is yet upon him. [^13] This is the law when a man dieth in a tent: every one that cometh into the tent, and every one that is in the tent, shall be unclean seven days. [^14] And every open vessel, which hath no covering bound upon it, is unclean. [^15] And whosoever in the open field toucheth one that is slain with a sword, or a dead body, or a bone of a man, or a grave, shall be unclean seven days. [^16] And for the unclean they shall take of the ashes of the burning of the sin-offering; and running water shall be put thereto in a vessel: [^17] and a clean person shall take hyssop, and dip it in the water, and sprinkle it upon the tent, and upon all the vessels, and upon the persons that were there, and upon him that touched the bone, or the slain, or the dead, or the grave: [^18] and the clean person shall sprinkle upon the unclean on the third day, and on the seventh day: and on the seventh day he shall purify him; and he shall wash his clothes, and bathe himself in water, and shall be clean at even. [^19] But the man that shall be unclean, and shall not purify himself, that soul shall be cut off from the midst of the assembly, because he hath defiled the sanctuary of Jehovah: the water for impurity hath not been sprinkled upon him; he is unclean. [^20] And it shall be a perpetual statute unto them: and he that sprinkleth the water for impurity shall wash his clothes, and he that toucheth the water for impurity shall be unclean until even. [^21] And whatsoever the unclean person toucheth shall be unclean; and the soul that toucheth it shall be unclean until even. [^22] 

[[Numbers - 18|<--]] Numbers - 19 [[Numbers - 20|-->]]

---
# Notes
