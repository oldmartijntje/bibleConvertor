---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 34 - American Standard Version"
---
[[Numbers - 33|<--]] Numbers - 34 [[Numbers - 35|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Numbers]]

# Numbers - 34

And Jehovah spake unto Moses, saying, [^1] Command the children of Israel, and say unto them, When ye come into the land of Canaan (this is the land that shall fall unto you for an inheritance, even the land of Canaan according to the borders thereof), [^2] then your south quarter shall be from the wilderness of Zin along by the side of Edom, and your south border shall be from the end of the Salt Sea eastward; [^3] and your border shall turn about southward of the ascent of Akrabbim, and pass along to Zin; and the goings out thereof shall be southward of Kadesh-barnea; and it shall go forth to Hazar-addar, and pass along to Azmon; [^4] and the border shall turn about from Azmon unto the brook of Egypt, and the goings out thereof shall be at the sea. [^5] And for the western border, ye shall have the great sea and the border thereof: this shall be your west border. [^6] And this shall be your north border: from the great sea ye shall mark out for you mount Hor; [^7] from mount Hor ye shall mark out unto the entrance of Hamath; and the goings out of the border shall be at Zedad; [^8] and the border shall go forth to Ziphron, and the goings out thereof shall be at Hazar-enan: this shall be your north border. [^9] And ye shall mark out your east border from Hazar-enan to Shepham; [^10] and the border shall go down from Shepham to Riblah, on the east side of Ain; and the border shall go down, and shall reach unto the side of the sea of Chinnereth eastward; [^11] and the border shall go down to the Jordan, and the goings out thereof shall be at the Salt Sea. This shall be your land according to the borders thereof round about. [^12] And Moses commanded the children of Israel, saying, This is the land which ye shall inherit by lot, which Jehovah hath commanded to give unto the nine tribes, and to the half-tribe; [^13] for the tribe of the children of Reuben according to their fathers’ houses, and the tribe of the children of Gad according to their fathers’ houses, have received, and the half-tribe of Manasseh have received, their inheritance: [^14] the two tribes and the half-tribe have received their inheritance beyond the Jordan at Jericho eastward, toward the sunrising. [^15] And Jehovah spake unto Moses, saying, [^16] These are the names of the men that shall divide the land unto you for inheritance: Eleazar the priest, and Joshua the son of Nun. [^17] And ye shall take one prince of every tribe, to divide the land for inheritance. [^18] And these are the names of the men: Of the tribe of Judah, Caleb the son of Jephunneh. [^19] And of the tribe of the children of Simeon, Shemuel the son of Ammihud. [^20] Of the tribe of Benjamin, Elidad the son of Chislon. [^21] And of the tribe of the children of Dan a prince, Bukki the son of Jogli. [^22] Of the children of Joseph: of the tribe of the children of Manasseh a prince, Hanniel the son of Ephod. [^23] And of the tribe of the children of Ephraim a prince, Kemuel the son of Shiphtan. [^24] And of the tribe of the children of Zebulun a prince, Elizaphan the son of Parnach. [^25] And of the tribe of the children of Issachar a prince, Paltiel the son of Azzan. [^26] And of the tribe of the children of Asher a prince, Ahihud the son of Shelomi. [^27] And of the tribe of the children of Naphtali a prince, Pedahel the son of Ammihud. [^28] These are they whom Jehovah commanded to divide the inheritance unto the children of Israel in the land of Canaan. [^29] 

[[Numbers - 33|<--]] Numbers - 34 [[Numbers - 35|-->]]

---
# Notes
