---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 12 - American Standard Version"
---
[[Numbers - 11|<--]] Numbers - 12 [[Numbers - 13|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Numbers]]

# Numbers - 12

And Miriam and Aaron spake against Moses because of the Cushite woman whom he had married; for he had married a Cushite woman. [^1] And they said, Hath Jehovah indeed spoken only with Moses? hath he not spoken also with us? And Jehovah heard it. [^2] Now the man Moses was very meek, above all the men that were upon the face of the earth. [^3] And Jehovah spake suddenly unto Moses, and unto Aaron, and unto Miriam, Come out ye three unto the tent of meeting. And they three came out. [^4] And Jehovah came down in a pillar of cloud, and stood at the door of the Tent, and called Aaron and Miriam; and they both came forth. [^5] And he said, Hear now my words: if there be a prophet among you, I Jehovah will make myself known unto him in a vision, I will speak with him in a dream. [^6] My servant Moses is not so; he is faithful in all my house: [^7] with him will I speak mouth to mouth, even manifestly, and not in dark speeches; and the form of Jehovah shall he behold: wherefore then were ye not afraid to speak against my servant, against Moses? [^8] And the anger of Jehovah was kindled against them; and he departed. [^9] And the cloud removed from over the Tent; and, behold, Miriam was leprous, as white as snow: and Aaron looked upon Miriam, and, behold, she was leprous. [^10] And Aaron said unto Moses, Oh, my lord, lay not, I pray thee, sin upon us, for that we have done foolishly, and for that we have sinned. [^11] Let her not, I pray, be as one dead, of whom the flesh is half consumed when he cometh out of his mother’s womb. [^12] And Moses cried unto Jehovah, saying, Heal her, O God, I beseech thee. [^13] And Jehovah said unto Moses, If her father had but spit in her face, should she not be ashamed seven days? let her be shut up without the camp seven days, and after that she shall be brought in again. [^14] And Miriam was shut up without the camp seven days: and the people journeyed not till Miriam was brought in again. [^15] And afterward the people journeyed from Hazeroth, and encamped in the wilderness of Paran. [^16] 

[[Numbers - 11|<--]] Numbers - 12 [[Numbers - 13|-->]]

---
# Notes
