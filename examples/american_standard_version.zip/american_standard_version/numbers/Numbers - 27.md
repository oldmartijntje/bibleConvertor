---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 27 - American Standard Version"
---
[[Numbers - 26|<--]] Numbers - 27 [[Numbers - 28|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Numbers]]

# Numbers - 27

Then drew near the daughters of Zelophehad, the son of Hepher, the son of Gilead, the son of Machir, the son of Manasseh, of the families of Manasseh the son of Joseph; and these are the names of his daughters: Mahlah, Noah, and Hoglah, and Milcah, and Tirzah. [^1] And they stood before Moses, and before Eleazar the priest, and before the princes and all the congregation, at the door of the tent of meeting, saying, [^2] Our father died in the wilderness, and he was not among the company of them that gathered themselves together against Jehovah in the company of Korah: but he died in his own sin; and he had no sons. [^3] Why should the name of our father be taken away from among his family, because he had no son? Give unto us a possession among the brethren of our father. [^4] And Moses brought their cause before Jehovah. [^5] And Jehovah spake unto Moses, saying, [^6] The daughters of Zelophehad speak right: thou shalt surely give them a possession of an inheritance among their father’s brethren; and thou shalt cause the inheritance of their father to pass unto them. [^7] And thou shalt speak unto the children of Israel, saying, If a man die, and have no son, then ye shall cause his inheritance to pass unto his daughter. [^8] And if he have no daughter, then ye shall give his inheritance unto his brethren. [^9] And if he have no brethren, then ye shall give his inheritance unto his father’s brethren. [^10] And if his father have no brethren, then ye shall give his inheritance unto his kinsman that is next to him of his family, and he shall possess it: and it shall be unto the children of Israel a statute and ordinance, as Jehovah commanded Moses. [^11] And Jehovah said unto Moses, Get thee up into this mountain of Abarim, and behold the land which I have given unto the children of Israel. [^12] And when thou hast seen it, thou also shalt be gathered unto thy people, as Aaron thy brother was gathered; [^13] because ye rebelled against my word in the wilderness of Zin, in the strife of the congregation, to sanctify me at the waters before their eyes. (These are the waters of Meribah of Kadesh in the wilderness of Zin.) [^14] And Moses spake unto Jehovah, saying, [^15] Let Jehovah, the God of the spirits of all flesh, appoint a man over the congregation, [^16] who may go out before them, and who may come in before them, and who may lead them out, and who may bring them in; that the congregation of Jehovah be not as sheep which have no shepherd. [^17] And Jehovah said unto Moses, Take thee Joshua the son of Nun, a man in whom is the Spirit, and lay thy hand upon him; [^18] and set him before Eleazar the priest, and before all the congregation; and give him a charge in their sight. [^19] And thou shalt put of thine honor upon him, that all the congregation of the children of Israel may obey. [^20] And he shall stand before Eleazar the priest, who shall inquire for him by the judgment of the Urim before Jehovah: at his word shall they go out, and at his word they shall come in, both he, and all the children of Israel with him, even all the congregation. [^21] And Moses did as Jehovah commanded him; and he took Joshua, and set him before Eleazar the priest, and before all the congregation: [^22] and he laid his hands upon him, and gave him a charge, as Jehovah spake by Moses. [^23] 

[[Numbers - 26|<--]] Numbers - 27 [[Numbers - 28|-->]]

---
# Notes
