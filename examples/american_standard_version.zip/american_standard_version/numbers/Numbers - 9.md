---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 9 - American Standard Version"
---
[[Numbers - 8|<--]] Numbers - 9 [[Numbers - 10|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Numbers]]

# Numbers - 9

And Jehovah spake unto Moses in the wilderness of Sinai, in the first month of the second year after they were come out of the land of Egypt, saying, [^1] Moreover let the children of Israel keep the passover in its appointed season. [^2] In the fourteenth day of this month, at even, ye shall keep it in its appointed season: according to all the statutes of it, and according to all the ordinances thereof, shall ye keep it. [^3] And Moses spake unto the children of Israel, that they should keep the passover. [^4] And they kept the passover in the first month, on the fourteenth day of the month, at even, in the wilderness of Sinai: according to all that Jehovah commanded Moses, so did the children of Israel. [^5] And there were certain men, who were unclean by reason of the dead body of a man, so that they could not keep the passover on that day: and they came before Moses and before Aaron on that day: [^6] and those men said unto him, We are unclean by reason of the dead body of a man: wherefore are we kept back, that we may not offer the oblation of Jehovah in its appointed season among the children of Israel? [^7] And Moses said unto them, Stay ye, that I may hear what Jehovah will command concerning you. [^8] And Jehovah spake unto Moses, saying, [^9] Speak unto the children of Israel, saying, If any man of you or of your generations shall be unclean by reason of a dead body, or be on a journey afar off, yet he shall keep the passover unto Jehovah. [^10] In the second month on the fourteenth day at even they shall keep it; they shall eat it with unleavened bread and bitter herbs: [^11] they shall leave none of it unto the morning, nor break a bone thereof: according to all the statute of the passover they shall keep it. [^12] But the man that is clean, and is not on a journey, and forbeareth to keep the passover, that soul shall be cut off from his people; because he offered not the oblation of Jehovah in its appointed season, that man shall bear his sin. [^13] And if a stranger shall sojourn among you, and will keep the passover unto Jehovah; according to the statute of the passover, and according to the ordinance thereof, so shall he do: ye shall have one statute, both for the sojourner, and for him that is born in the land. [^14] And on the day that the tabernacle was reared up the cloud covered the tabernacle, even the tent of the testimony: and at even it was upon the tabernacle as it were the appearance of fire, until morning. [^15] So it was alway: the cloud covered it, and the appearance of fire by night. [^16] And whenever the cloud was taken up from over the Tent, then after that the children of Israel journeyed: and in the place where the cloud abode, there the children of Israel encamped. [^17] At the commandment of Jehovah the children of Israel journeyed, and at the commandment of Jehovah they encamped: as long as the cloud abode upon the tabernacle they remained encamped. [^18] And when the cloud tarried upon the tabernacle many days, then the children of Israel kept the charge of Jehovah, and journeyed not. [^19] And sometimes the cloud was a few days upon the tabernacle; then according to the commandment of Jehovah they remained encamped, and according to the commandment of Jehovah they journeyed. [^20] And sometimes the cloud was from evening until morning; and when the cloud was taken up in the morning, they journeyed: or if it continued by day and by night, when the cloud was taken up, they journeyed. [^21] Whether it were two days, or a month, or a year, that the cloud tarried upon the tabernacle, abiding thereon, the children of Israel remained encamped, and journeyed not; but when it was taken up, they journeyed. [^22] At the commandment of Jehovah they encamped, and at the commandment of Jehovah they journeyed: they kept the charge of Jehovah, at the commandment of Jehovah by Moses. [^23] 

[[Numbers - 8|<--]] Numbers - 9 [[Numbers - 10|-->]]

---
# Notes
