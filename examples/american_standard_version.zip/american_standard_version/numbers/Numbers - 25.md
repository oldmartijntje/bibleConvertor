---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 25 - American Standard Version"
---
[[Numbers - 24|<--]] Numbers - 25 [[Numbers - 26|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Numbers]]

# Numbers - 25

And Israel abode in Shittim; and the people began to play the harlot with the daughters of Moab: [^1] for they called the people unto the sacrifices of their gods; and the people did eat, and bowed down to their gods. [^2] And Israel joined himself unto Baal-peor: and the anger of Jehovah was kindled against Israel. [^3] And Jehovah said unto Moses, Take all the chiefs of the people, and hang them up unto Jehovah before the sun, that the fierce anger of Jehovah may turn away from Israel. [^4] And Moses said unto the judges of Israel, Slay ye every one his men that have joined themselves unto Baal-peor. [^5] And, behold, one of the children of Israel came and brought unto his brethren a Midianitish woman in the sight of Moses, and in the sight of all the congregation of the children of Israel, while they were weeping at the door of the tent of meeting. [^6] And when Phinehas, the son of Eleazar, the son of Aaron the priest, saw it, he rose up from the midst of the congregation, and took a spear in his hand; [^7] and he went after the man of Israel into the pavilion, and thrust both of them through, the man of Israel, and the woman through her body. So the plague was stayed from the children of Israel. [^8] And those that died by the plague were twenty and four thousand. [^9] And Jehovah spake unto Moses, saying, [^10] Phinehas, the son of Eleazar, the son of Aaron the priest, hath turned my wrath away from the children of Israel, in that he was jealous with my jealousy among them, so that I consumed not the children of Israel in my jealousy. [^11] Wherefore say, Behold, I give unto him my covenant of peace: [^12] and it shall be unto him, and to his seed after him, the covenant of an everlasting priesthood; because he was jealous for his God, and made atonement for the children of Israel. [^13] Now the name of the man of Israel that was slain, who was slain with the Midianitish woman, was Zimri, the son of Salu, a prince of a fathers’ house among the Simeonites. [^14] And the name of the Midianitish woman that was slain was Cozbi, the daughter of Zur; he was head of the people of a fathers’ house in Midian. [^15] And Jehovah spake unto Moses, saying, [^16] Vex the Midianites, and smite them; [^17] for they vex you with their wiles, wherewith they have beguiled you in the matter of Peor, and in the matter of Cozbi, the daughter of the prince of Midian, their sister, who was slain on the day of the plague in the matter of Peor. [^18] 

[[Numbers - 24|<--]] Numbers - 25 [[Numbers - 26|-->]]

---
# Notes
