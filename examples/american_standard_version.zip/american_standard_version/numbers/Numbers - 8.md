---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 8 - American Standard Version"
---
[[Numbers - 7|<--]] Numbers - 8 [[Numbers - 9|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Numbers]]

# Numbers - 8

And Jehovah spake unto Moses, saying, [^1] Speak unto Aaron, and say unto him, When thou lightest the lamps, the seven lamps shall give light in front of the candlestick. [^2] And Aaron did so; he lighted the lamps thereof so as to give light in front of the candlestick, as Jehovah commanded Moses. [^3] And this was the work of the candlestick, beaten work of gold; unto the base thereof, and unto the flowers thereof, it was beaten work: according unto the pattern which Jehovah had showed Moses, so he made the candlestick. [^4] And Jehovah spake unto Moses, saying, [^5] Take the Levites from among the children of Israel, and cleanse them. [^6] And thus shalt thou do unto them, to cleanse them: sprinkle the water of expiation upon them, and let them cause a razor to pass over all their flesh, and let them wash their clothes, and cleanse themselves. [^7] Then let them take a young bullock, and its meal-offering, fine flour mingled with oil; and another young bullock shalt thou take for a sin-offering. [^8] And thou shalt present the Levites before the tent of meeting: and thou shalt assemble the whole congregation of the children of Israel: [^9] and thou shalt present the Levites before Jehovah. And the children of Israel shall lay their hands upon the Levites: [^10] and Aaron shall offer the Levites before Jehovah for a wave-offering, on the behalf of the children of Israel, that it may be theirs to do the service of Jehovah. [^11] And the Levites shall lay their hands upon the heads of the bullocks: and offer thou the one for a sin-offering, and the other for a burnt-offering, unto Jehovah, to make atonement for the Levites. [^12] And thou shalt set the Levites before Aaron, and before his sons, and offer them for a wave-offering unto Jehovah. [^13] Thus shalt thou separate the Levites from among the children of Israel; and the Levites shall be mine. [^14] And after that shall the Levites go in to do the service of the tent of meeting: and thou shalt cleanse them, and offer them for a wave-offering. [^15] For they are wholly given unto me from among the children of Israel; instead of all that openeth the womb, even the first-born of all the children of Israel, have I taken them unto me. [^16] For all the first-born among the children of Israel are mine, both man and beast: on the day that I smote all the first-born in the land of Egypt I sanctified them for myself. [^17] And I have taken the Levites instead of all the first-born among the children of Israel. [^18] And I have given the Levites as a gift to Aaron and to his sons from among the children of Israel, to do the service of the children of Israel in the tent of meeting, and to make atonement for the children of Israel; that there be no plague among the children of Israel, when the children of Israel come nigh unto the sanctuary. [^19] Thus did Moses, and Aaron, and all the congregation of the children of Israel, unto the Levites: according unto all that Jehovah commanded Moses touching the Levites, so did the children of Israel unto them. [^20] And the Levites purified themselves from sin, and they washed their clothes: and Aaron offered them for a wave-offering before Jehovah; and Aaron made atonement for them to cleanse them. [^21] And after that went the Levites in to do their service in the tent of meeting before Aaron, and before his sons: as Jehovah had commanded Moses concerning the Levites, so did they unto them. [^22] And Jehovah spake unto Moses, saying, [^23] This is that which belongeth unto the Levites: from twenty and five years old and upward they shall go in to wait upon the service in the work of the tent of meeting: [^24] and from the age of fifty years they shall cease waiting upon the work, and shall serve no more, [^25] but shall minister with their brethren in the tent of meeting, to keep the charge, and shall do no service. Thus shalt thou do unto the Levites touching their charges. [^26] 

[[Numbers - 7|<--]] Numbers - 8 [[Numbers - 9|-->]]

---
# Notes
