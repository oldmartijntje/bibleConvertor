---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 30 - American Standard Version"
---
[[Numbers - 29|<--]] Numbers - 30 [[Numbers - 31|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Numbers]]

# Numbers - 30

And Moses spake unto the heads of the tribes of the children of Israel, saying, This is the thing which Jehovah hath commanded. [^1] When a man voweth a vow unto Jehovah, or sweareth an oath to bind his soul with a bond, he shall not break his word; he shall do according to all that proceedeth out of his mouth. [^2] Also when a woman voweth a vow unto Jehovah, and bindeth herself by a bond, being in her father’s house, in her youth, [^3] and her father heareth her vow, and her bond wherewith she hath bound her soul, and her father holdeth his peace at her; then all her vows shall stand, and every bond wherewith she hath bound her soul shall stand. [^4] But if her father disallow her in the day that he heareth, none of her vows, or of her bonds wherewith she hath bound her soul, shall stand: and Jehovah will forgive her, because her father disallowed her. [^5] And if she be married to a husband, while her vows are upon her, or the rash utterance of her lips, wherewith she hath bound her soul, [^6] and her husband hear it, and hold his peace at her in the day that he heareth it; then her vows shall stand, and her bonds wherewith she hath bound her soul shall stand. [^7] But if her husband disallow her in the day that he heareth it, then he shall make void her vow which is upon her, and the rash utterance of her lips, wherewith she hath bound her soul: and Jehovah will forgive her. [^8] But the vow of a widow, or of her that is divorced, even everything wherewith she hath bound her soul, shall stand against her. [^9] And if she vowed in her husband’s house, or bound her soul by a bond with an oath, [^10] and her husband heard it, and held his peace at her, and disallowed her not; then all her vows shall stand, and every bond wherewith she bound her soul shall stand. [^11] But if her husband made them null and void in the day that he heard them, then whatsoever proceeded out of her lips concerning her vows, or concerning the bond of her soul, shall not stand: her husband hath made them void; and Jehovah will forgive her. [^12] Every vow, and every binding oath to afflict the soul, her husband may establish it, or her husband may make it void. [^13] But if her husband altogether hold his peace at her from day to day, then he establisheth all her vows, or all her bonds, which are upon her: he hath established them, because he held his peace at her in the day that he heard them. [^14] But if he shall make them null and void after that he hath heard them, then he shall bear her iniquity. [^15] These are the statutes, which Jehovah commanded Moses, between a man and his wife, between a father and his daughter, being in her youth, in her father’s house. [^16] 

[[Numbers - 29|<--]] Numbers - 30 [[Numbers - 31|-->]]

---
# Notes
