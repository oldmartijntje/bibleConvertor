---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/psalms"
  - "#bible/testament/old"
aliases:
  - "Psalms - 2 - American Standard Version"
---
[[Psalms - 1|<--]] Psalms - 2 [[Psalms - 3|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Psalms]]

# Psalms - 2

Why do the nations rage,And the peoples meditate a vain thing? [^1] The kings of the earth set themselves,And the rulers take counsel together,Against Jehovah, and against his anointed, saying, [^2] Let us break their bonds asunder,And cast away their cords from us. [^3] He that sitteth in the heavens will laugh:The Lord will have them in derision. [^4] Then will he speak unto them in his wrath,And vex them in his sore displeasure: [^5] Yet I have set my kingUpon my holy hill of Zion. [^6] I will tell of the decree:Jehovah said unto me, Thou art my son;This day have I begotten thee. [^7] Ask of me, and I will give thee the nations for thine inheritance,And the uttermost parts of the earth for thy possession. [^8] Thou shalt break them with a rod of iron;Thou shalt dash them in pieces like a potter’s vessel. [^9] Now therefore be wise, O ye kings:Be instructed, ye judges of the earth. [^10] Serve Jehovah with fear,And rejoice with trembling. [^11] Kiss the son, lest he be angry, and ye perish in the way,For his wrath will soon be kindled.Blessed are all they that take refuge in him. [^12] 

[[Psalms - 1|<--]] Psalms - 2 [[Psalms - 3|-->]]

---
# Notes
