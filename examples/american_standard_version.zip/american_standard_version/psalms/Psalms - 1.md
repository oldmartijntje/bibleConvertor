---
translation: American Standard Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/psalms"
  - "#bible/testament/old"
aliases:
  - "Psalms - 1 - American Standard Version"
---
Psalms - 1 [[Psalms - 2|-->]]

Translation: [[bible - American Standard Version|American Standard Version]]
Book: [[Psalms]]

# Psalms - 1

Blessed is the man that walketh not in the counsel of the wicked,Nor standeth in the way of sinners,Nor sitteth in the seat of scoffers: [^1] But his delight is in the law of Jehovah;And on his law doth he meditate day and night. [^2] And he shall be like a tree planted by the streams of water,That bringeth forth its fruit in its season,Whose leaf also doth not wither;And whatsoever he doeth shall prosper. [^3] The wicked are not so,But are like the chaff which the wind driveth away. [^4] Therefore the wicked shall not stand in the judgment,Nor sinners in the congregation of the righteous. [^5] For Jehovah knoweth the way of the righteous;But the way of the wicked shall perish. [^6] 

Psalms - 1 [[Psalms - 2|-->]]

---
# Notes
