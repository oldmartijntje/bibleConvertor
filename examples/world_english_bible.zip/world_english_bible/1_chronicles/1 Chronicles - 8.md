---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 8 - World English Bible"
---
[[1 Chronicles - 7|<--]] 1 Chronicles - 8 [[1 Chronicles - 9|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[1 Chronicles]]

# 1 Chronicles - 8

Benjamin became the father of Bela his firstborn, Ashbel the second, Aharah the third, [^1] Nohah the fourth, and Rapha the fifth. [^2] Bela had sons: Addar, Gera, Abihud, [^3] Abishua, Naaman, Ahoah, [^4] Gera, Shephuphan, and Huram. [^5] These are the sons of Ehud. These are the heads of fathers’ households of the inhabitants of Geba, who were carried captive to Manahath: [^6] Naaman, Ahijah, and Gera, who carried them captive; and he became the father of Uzza and Ahihud. [^7] Shaharaim became the father of children in the field of Moab, after he had sent them away. Hushim and Baara were his wives. [^8] By Hodesh his wife, he became the father of Jobab, Zibia, Mesha, Malcam, [^9] Jeuz, Shachia, and Mirmah. These were his sons, heads of fathers’ households. [^10] By Hushim, he became the father of Abitub and Elpaal. [^11] The sons of Elpaal: Eber, Misham, and Shemed, who built Ono and Lod, with its towns; [^12] and Beriah and Shema, who were heads of fathers’ households of the inhabitants of Aijalon, who put to flight the inhabitants of Gath; [^13] and Ahio, Shashak, Jeremoth, [^14] Zebadiah, Arad, Eder, [^15] Michael, Ishpah, Joha, the sons of Beriah, [^16] Zebadiah, Meshullam, Hizki, Heber, [^17] Ishmerai, Izliah, Jobab, the sons of Elpaal, [^18] Jakim, Zichri, Zabdi, [^19] Elienai, Zillethai, Eliel, [^20] Adaiah, Beraiah, Shimrath, the sons of Shimei, [^21] Ishpan, Eber, Eliel, [^22] Abdon, Zichri, Hanan, [^23] Hananiah, Elam, Anthothijah, [^24] Iphdeiah, Penuel, the sons of Shashak, [^25] Shamsherai, Shehariah, Athaliah, [^26] Jaareshiah, Elijah, Zichri, and the sons of Jeroham. [^27] These were heads of fathers’ households throughout their generations, chief men. These lived in Jerusalem. [^28] The father of Gibeon, whose wife’s name was Maacah, lived in Gibeon [^29] with his firstborn son Abdon, Zur, Kish, Baal, Nadab, [^30] Gedor, Ahio, Zecher, [^31] and Mikloth, who became the father of Shimeah. They also lived with their families in Jerusalem, near their relatives. [^32] Ner became the father of Kish. Kish became the father of Saul. Saul became the father of Jonathan, Malchishua, Abinadab, and Eshbaal. [^33] The son of Jonathan was Merib-baal. Merib-baal became the father of Micah. [^34] The sons of Micah: Pithon, Melech, Tarea, and Ahaz. [^35] Ahaz became the father of Jehoaddah. Jehoaddah became the father of Alemeth, Azmaveth, and Zimri. Zimri became the father of Moza. [^36] Moza became the father of Binea. Raphah was his son, Eleasah his son, and Azel his son. [^37] Azel had six sons, whose names are these: Azrikam, Bocheru, Ishmael, Sheariah, Obadiah, and Hanan. All these were the sons of Azel. [^38] The sons of Eshek his brother: Ulam his firstborn, Jeush the second, and Eliphelet the third. [^39] The sons of Ulam were mighty men of valor, archers, and had many sons, and grandsons, one hundred fifty. All these were of the sons of Benjamin. [^40] 

[[1 Chronicles - 7|<--]] 1 Chronicles - 8 [[1 Chronicles - 9|-->]]

---
# Notes
