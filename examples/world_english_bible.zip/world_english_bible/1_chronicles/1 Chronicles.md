---
translation: World English Bible
aliases:
  - "1 Chronicles - World English Bible"
tags:
  - "#bible/type/book"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
---
[[2 Kings|<--]] 1 Chronicles [[2 Chronicles|-->]]

# 1 Chronicles - World English Bible

The 1 Chronicles book has 29 chapters. It is part of the old testament.

## Chapters

- 1 Chronicles [[1 Chronicles - 1|chapter 1]]
- 1 Chronicles [[1 Chronicles - 2|chapter 2]]
- 1 Chronicles [[1 Chronicles - 3|chapter 3]]
- 1 Chronicles [[1 Chronicles - 4|chapter 4]]
- 1 Chronicles [[1 Chronicles - 5|chapter 5]]
- 1 Chronicles [[1 Chronicles - 6|chapter 6]]
- 1 Chronicles [[1 Chronicles - 7|chapter 7]]
- 1 Chronicles [[1 Chronicles - 8|chapter 8]]
- 1 Chronicles [[1 Chronicles - 9|chapter 9]]
- 1 Chronicles [[1 Chronicles - 10|chapter 10]]
- 1 Chronicles [[1 Chronicles - 11|chapter 11]]
- 1 Chronicles [[1 Chronicles - 12|chapter 12]]
- 1 Chronicles [[1 Chronicles - 13|chapter 13]]
- 1 Chronicles [[1 Chronicles - 14|chapter 14]]
- 1 Chronicles [[1 Chronicles - 15|chapter 15]]
- 1 Chronicles [[1 Chronicles - 16|chapter 16]]
- 1 Chronicles [[1 Chronicles - 17|chapter 17]]
- 1 Chronicles [[1 Chronicles - 18|chapter 18]]
- 1 Chronicles [[1 Chronicles - 19|chapter 19]]
- 1 Chronicles [[1 Chronicles - 20|chapter 20]]
- 1 Chronicles [[1 Chronicles - 21|chapter 21]]
- 1 Chronicles [[1 Chronicles - 22|chapter 22]]
- 1 Chronicles [[1 Chronicles - 23|chapter 23]]
- 1 Chronicles [[1 Chronicles - 24|chapter 24]]
- 1 Chronicles [[1 Chronicles - 25|chapter 25]]
- 1 Chronicles [[1 Chronicles - 26|chapter 26]]
- 1 Chronicles [[1 Chronicles - 27|chapter 27]]
- 1 Chronicles [[1 Chronicles - 28|chapter 28]]
- 1 Chronicles [[1 Chronicles - 29|chapter 29]]

[[2 Kings|<--]] 1 Chronicles [[2 Chronicles|-->]]

---
# Notes
