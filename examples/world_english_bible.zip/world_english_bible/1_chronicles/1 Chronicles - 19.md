---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 19 - World English Bible"
---
[[1 Chronicles - 18|<--]] 1 Chronicles - 19 [[1 Chronicles - 20|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[1 Chronicles]]

# 1 Chronicles - 19

After this, Nahash the king of the children of Ammon died, and his son reigned in his place. [^1] David said, “I will show kindness to Hanun the son of Nahash, because his father showed kindness to me.”So David sent messengers to comfort him concerning his father. David’s servants came into the land of the children of Ammon to Hanun to comfort him. [^2] But the princes of the children of Ammon said to Hanun, “Do you think that David honors your father, in that he has sent comforters to you? Haven’t his servants come to you to search, to overthrow, and to spy out the land?” [^3] So Hanun took David’s servants, shaved them, and cut off their garments in the middle at their buttocks, and sent them away. [^4] Then some people went and told David how the men were treated. He sent to meet them; for the men were greatly humiliated. The king said, “Stay at Jericho until your beards have grown, and then return.” [^5] When the children of Ammon saw that they had made themselves odious to David, Hanun and the children of Ammon sent one thousand talents#19:6 A talent is about 30 kilograms or 66 pounds, so 1000 talents is about 30 metric tons of silver to hire chariots and horsemen out of Mesopotamia, out of Aram-maacah, and out of Zobah. [^6] So they hired for themselves thirty-two thousand chariots, and the king of Maacah with his people, who came and encamped near Medeba. The children of Ammon gathered themselves together from their cities, and came to battle. [^7] When David heard of it, he sent Joab with all the army of the mighty men. [^8] The children of Ammon came out, and put the battle in array at the gate of the city; and the kings who had come were by themselves in the field. [^9] Now when Joab saw that the battle was set against him before and behind, he chose some of all the choice men of Israel, and put them in array against the Syrians. [^10] The rest of the people he committed into the hand of Abishai his brother; and they put themselves in array against the children of Ammon. [^11] He said, “If the Syrians are too strong for me, then you are to help me; but if the children of Ammon are too strong for you, then I will help you. [^12] Be courageous, and let’s be strong for our people and for the cities of our God. May Yahweh do that which seems good to him.” [^13] So Joab and the people who were with him came near to the front of the Syrians to the battle; and they fled before him. [^14] When the children of Ammon saw that the Syrians had fled, they likewise fled before Abishai his brother, and entered into the city. Then Joab came to Jerusalem. [^15] When the Syrians saw that they were defeated by Israel, they sent messengers and called out the Syrians who were beyond the River,#19:16 or, the Euphrates River with Shophach the captain of the army of Hadadezer leading them. [^16] David was told that, so he gathered all Israel together, passed over the Jordan, came to them, and set the battle in array against them. So when David had put the battle in array against the Syrians, they fought with him. [^17] The Syrians fled before Israel; and David killed of the Syrian men seven thousand charioteers and forty thousand footmen, and also killed Shophach the captain of the army. [^18] When the servants of Hadadezer saw that they were defeated by Israel, they made peace with David and served him. The Syrians would not help the children of Ammon any more. [^19] 

[[1 Chronicles - 18|<--]] 1 Chronicles - 19 [[1 Chronicles - 20|-->]]

---
# Notes
