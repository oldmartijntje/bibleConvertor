---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 5 - World English Bible"
---
[[1 Chronicles - 4|<--]] 1 Chronicles - 5 [[1 Chronicles - 6|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[1 Chronicles]]

# 1 Chronicles - 5

The sons of Reuben the firstborn of Israel (for he was the firstborn, but because he defiled his father’s couch, his birthright was given to the sons of Joseph the son of Israel; and the genealogy is not to be listed according to the birthright. [^1] For Judah prevailed above his brothers, and from him came the prince; but the birthright was Joseph’s)— [^2] the sons of Reuben the firstborn of Israel: Hanoch, Pallu, Hezron, and Carmi. [^3] The sons of Joel: Shemaiah his son, Gog his son, Shimei his son, [^4] Micah his son, Reaiah his son, Baal his son, [^5] and Beerah his son, whom Tilgath Pilneser king of Assyria carried away captive. He was prince of the Reubenites. [^6] His brothers by their families, when the genealogy of their generations was listed: the chief, Jeiel, and Zechariah, [^7] and Bela the son of Azaz, the son of Shema, the son of Joel, who lived in Aroer, even to Nebo and Baal Meon; [^8] and he lived eastward even to the entrance of the wilderness from the river Euphrates, because their livestock were multiplied in the land of Gilead. [^9] In the days of Saul, they made war with the Hagrites, who fell by their hand; and they lived in their tents throughout all the land east of Gilead. [^10] The sons of Gad lived beside them in the land of Bashan to Salecah: [^11] Joel the chief, Shapham the second, Janai, and Shaphat in Bashan. [^12] Their brothers of their fathers’ houses: Michael, Meshullam, Sheba, Jorai, Jacan, Zia, and Eber, seven. [^13] These were the sons of Abihail, the son of Huri, the son of Jaroah, the son of Gilead, the son of Michael, the son of Jeshishai, the son of Jahdo, the son of Buz; [^14] Ahi the son of Abdiel, the son of Guni, chief of their fathers’ houses. [^15] They lived in Gilead in Bashan and in its towns, and in all the pasture lands of Sharon as far as their borders. [^16] All these were listed by genealogies in the days of Jotham king of Judah, and in the days of Jeroboam king of Israel. [^17] The sons of Reuben, the Gadites, and the half-tribe of Manasseh, of valiant men, men able to bear buckler and sword, able to shoot with bow, and skillful in war, were forty-four thousand seven hundred sixty that were able to go out to war. [^18] They made war with the Hagrites, with Jetur, and Naphish, and Nodab. [^19] They were helped against them, and the Hagrites were delivered into their hand, and all who were with them; for they cried to God in the battle, and he answered them because they put their trust in him. [^20] They took away their livestock: of their camels fifty thousand, and of sheep two hundred fifty thousand, and of donkeys two thousand, and of men one hundred thousand. [^21] For many fell slain, because the war was of God. They lived in their place until the captivity. [^22] The children of the half-tribe of Manasseh lived in the land. They increased from Bashan to Baal Hermon, Senir, and Mount Hermon. [^23] These were the heads of their fathers’ houses: Epher, Ishi, Eliel, Azriel, Jeremiah, Hodaviah, and Jahdiel—mighty men of valor, famous men, heads of their fathers’ houses. [^24] They trespassed against the God of their fathers, and played the prostitute after the gods of the peoples of the land whom God destroyed before them. [^25] So the God of Israel stirred up the spirit of Pul king of Assyria, and the spirit of Tilgath Pilneser king of Assyria, and he carried away the Reubenites, the Gadites, and the half-tribe of Manasseh, and brought them to Halah, Habor, Hara, and to the river of Gozan, to this day. [^26] 

[[1 Chronicles - 4|<--]] 1 Chronicles - 5 [[1 Chronicles - 6|-->]]

---
# Notes
