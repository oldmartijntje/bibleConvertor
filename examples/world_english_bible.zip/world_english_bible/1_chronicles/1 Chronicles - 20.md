---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 20 - World English Bible"
---
[[1 Chronicles - 19|<--]] 1 Chronicles - 20 [[1 Chronicles - 21|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[1 Chronicles]]

# 1 Chronicles - 20

At the time of the return of the year, at the time when kings go out, Joab led out the army and wasted the country of the children of Ammon, and came and besieged Rabbah. But David stayed at Jerusalem. Joab struck Rabbah, and overthrew it. [^1] David took the crown of their king from off his head, and found it to weigh a talent of gold,#20:2 A talent is about 30 kilograms or 66 pounds or 965 Troy ounces and there were precious stones in it. It was set on David’s head, and he brought very much plunder out of the city. [^2] He brought out the people who were in it, and had them cut with saws, with iron picks, and with axes. David did so to all the cities of the children of Ammon. Then David and all the people returned to Jerusalem. [^3] After this, war arose at Gezer with the Philistines. Then Sibbecai the Hushathite killed Sippai, of the sons of the giant; and they were subdued. [^4] Again there was war with the Philistines; and Elhanan the son of Jair killed Lahmi the brother of Goliath the Gittite, the staff of whose spear was like a weaver’s beam. [^5] There was again war at Gath, where there was a man of great stature, who had twenty-four fingers and toes, six on each hand and six on each foot; and he also was born to the giant. [^6] When he defied Israel, Jonathan the son of Shimea, David’s brother, killed him. [^7] These were born to the giant in Gath; and they fell by the hand of David and by the hand of his servants. [^8] 

[[1 Chronicles - 19|<--]] 1 Chronicles - 20 [[1 Chronicles - 21|-->]]

---
# Notes
