---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 14 - World English Bible"
---
[[1 Chronicles - 13|<--]] 1 Chronicles - 14 [[1 Chronicles - 15|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[1 Chronicles]]

# 1 Chronicles - 14

Hiram king of Tyre sent messengers to David with cedar trees, masons, and carpenters, to build him a house. [^1] David perceived that Yahweh had established him king over Israel, for his kingdom was highly exalted, for his people Israel’s sake. [^2] David took more wives in Jerusalem, and David became the father of more sons and daughters. [^3] These are the names of the children whom he had in Jerusalem: Shammua, Shobab, Nathan, Solomon, [^4] Ibhar, Elishua, Elpelet, [^5] Nogah, Nepheg, Japhia, [^6] Elishama, Beeliada, and Eliphelet. [^7] When the Philistines heard that David was anointed king over all Israel, all the Philistines went up to seek David; and David heard of it, and went out against them. [^8] Now the Philistines had come and made a raid in the valley of Rephaim. [^9] David inquired of God, saying, “Shall I go up against the Philistines? Will you deliver them into my hand?”Yahweh said to him, “Go up; for I will deliver them into your hand.” [^10] So they came up to Baal Perazim, and David defeated them there. David said, God has broken my enemies by my hand, like waters breaking out. Therefore they called the name of that place Baal Perazim.#14:11 “Baal Perazim” means “The Lord who breaks out”. [^11] They left their gods there; and David gave a command, and they were burned with fire. [^12] The Philistines made another raid in the valley. [^13] David inquired again of God; and God said to him, “You shall not go up after them. Turn away from them, and come on them opposite the mulberry trees. [^14] When you hear the sound of marching in the tops of the mulberry trees, then go out to battle; for God has gone out before you to strike the army of the Philistines.” [^15] David did as God commanded him; and they attacked the army of the Philistines from Gibeon even to Gezer. [^16] The fame of David went out into all lands; and Yahweh brought the fear of him on all nations. [^17] 

[[1 Chronicles - 13|<--]] 1 Chronicles - 14 [[1 Chronicles - 15|-->]]

---
# Notes
