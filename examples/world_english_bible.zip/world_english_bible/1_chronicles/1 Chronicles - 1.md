---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 1 - World English Bible"
---
1 Chronicles - 1 [[1 Chronicles - 2|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[1 Chronicles]]

# 1 Chronicles - 1

Adam, Seth, Enosh, [^1] Kenan, Mahalalel, Jared, [^2] Enoch, Methuselah, Lamech, [^3] Noah, Shem, Ham, and Japheth. [^4] The sons of Japheth: Gomer, Magog, Madai, Javan, Tubal, Meshech, and Tiras. [^5] The sons of Gomer: Ashkenaz, Diphath, and Togarmah. [^6] The sons of Javan: Elishah, Tarshish, Kittim, and Rodanim. [^7] The sons of Ham: Cush, Mizraim, Put, and Canaan. [^8] The sons of Cush: Seba, Havilah, Sabta, Raama, Sabteca. The sons of Raamah: Sheba and Dedan. [^9] Cush became the father of Nimrod. He began to be a mighty one in the earth. [^10] Mizraim became the father of Ludim, Anamim, Lehabim, Naphtuhim, [^11] Pathrusim, Casluhim (where the Philistines came from), and Caphtorim. [^12] Canaan became the father of Sidon his firstborn, Heth, [^13] the Jebusite, the Amorite, the Girgashite, [^14] the Hivite, the Arkite, the Sinite, [^15] the Arvadite, the Zemarite, and the Hamathite. [^16] The sons of Shem: Elam, Asshur, Arpachshad, Lud, Aram, Uz, Hul, Gether, and Meshech. [^17] Arpachshad became the father of Shelah, and Shelah became the father of Eber. [^18] To Eber were born two sons: the name of the one was Peleg, for in his days the earth was divided; and his brother’s name was Joktan. [^19] Joktan became the father of Almodad, Sheleph, Hazarmaveth, Jerah, [^20] Hadoram, Uzal, Diklah, [^21] Ebal, Abimael, Sheba, [^22] Ophir, Havilah, and Jobab. All these were the sons of Joktan. [^23] Shem, Arpachshad, Shelah, [^24] Eber, Peleg, Reu, [^25] Serug, Nahor, Terah, [^26] Abram (also called Abraham). [^27] The sons of Abraham: Isaac and Ishmael. [^28] These are their generations: the firstborn of Ishmael, Nebaioth; then Kedar, Adbeel, Mibsam, [^29] Mishma, Dumah, Massa, Hadad, Tema, [^30] Jetur, Naphish, and Kedemah. These are the sons of Ishmael. [^31] The sons of Keturah, Abraham’s concubine: she bore Zimran, Jokshan, Medan, Midian, Ishbak, and Shuah. The sons of Jokshan: Sheba and Dedan. [^32] The sons of Midian: Ephah, Epher, Hanoch, Abida, and Eldaah. All these were the sons of Keturah. [^33] Abraham became the father of Isaac. The sons of Isaac: Esau and Israel. [^34] The sons of Esau: Eliphaz, Reuel, Jeush, Jalam, and Korah. [^35] The sons of Eliphaz: Teman, Omar, Zephi, Gatam, Kenaz, Timna, and Amalek. [^36] The sons of Reuel: Nahath, Zerah, Shammah, and Mizzah. [^37] The sons of Seir: Lotan, Shobal, Zibeon, Anah, Dishon, Ezer, and Dishan. [^38] The sons of Lotan: Hori and Homam; and Timna was Lotan’s sister. [^39] The sons of Shobal: Alian, Manahath, Ebal, Shephi, and Onam. The sons of Zibeon: Aiah and Anah. [^40] The son of Anah: Dishon. The sons of Dishon: Hamran, Eshban, Ithran, and Cheran. [^41] The sons of Ezer: Bilhan, Zaavan, and Jaakan. The sons of Dishan: Uz and Aran. [^42] Now these are the kings who reigned in the land of Edom, before any king reigned over the children of Israel: Bela the son of Beor; and the name of his city was Dinhabah. [^43] Bela died, and Jobab the son of Zerah of Bozrah reigned in his place. [^44] Jobab died, and Husham of the land of the Temanites reigned in his place. [^45] Husham died, and Hadad the son of Bedad, who struck Midian in the field of Moab, reigned in his place; and the name of his city was Avith. [^46] Hadad died, and Samlah of Masrekah reigned in his place. [^47] Samlah died, and Shaul of Rehoboth by the River reigned in his place. [^48] Shaul died, and Baal Hanan the son of Achbor reigned in his place. [^49] Baal Hanan died, and Hadad reigned in his place; and the name of his city was Pai. His wife’s name was Mehetabel, the daughter of Matred, the daughter of Mezahab. [^50] Then Hadad died. The chiefs of Edom were: chief Timna, chief Aliah, chief Jetheth, [^51] chief Oholibamah, chief Elah, chief Pinon, [^52] chief Kenaz, chief Teman, chief Mibzar, [^53] chief Magdiel, and chief Iram. These are the chiefs of Edom. [^54] 

1 Chronicles - 1 [[1 Chronicles - 2|-->]]

---
# Notes
