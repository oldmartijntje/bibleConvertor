---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 25 - World English Bible"
---
[[1 Chronicles - 24|<--]] 1 Chronicles - 25 [[1 Chronicles - 26|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[1 Chronicles]]

# 1 Chronicles - 25

Moreover, David and the captains of the army set apart for the service certain of the sons of Asaph, of Heman, and of Jeduthun, who were to prophesy with harps, with stringed instruments, and with cymbals. The number of those who did the work according to their service was: [^1] of the sons of Asaph: Zaccur, Joseph, Nethaniah, and Asharelah. The sons of Asaph were under the hand of Asaph, who prophesied at the order of the king. [^2] Of Jeduthun, the sons of Jeduthun: Gedaliah, Zeri, Jeshaiah, Shimei, Hashabiah, and Mattithiah, six, under the hands of their father Jeduthun, who prophesied in giving thanks and praising Yahweh with the harp. [^3] Of Heman, the sons of Heman: Bukkiah, Mattaniah, Uzziel, Shebuel, Jerimoth, Hananiah, Hanani, Eliathah, Giddalti, Romamti-Ezer, Joshbekashah, Mallothi, Hothir, and Mahazioth. [^4] All these were the sons of Heman the king’s seer in the words of God, to lift up the horn. God gave to Heman fourteen sons and three daughters. [^5] All these were under the hands of their father for song in Yahweh’s house, with cymbals, stringed instruments, and harps, for the service of God’s house: Asaph, Jeduthun, and Heman being under the order of the king. [^6] The number of them, with their brothers who were instructed in singing to Yahweh, even all who were skillful, was two hundred eighty-eight. [^7] They cast lots for their offices, all alike, the small as well as the great, the teacher as well as the student. [^8] Now the first lot came out for Asaph to Joseph; the second to Gedaliah, he and his brothers and sons were twelve; [^9] the third to Zaccur, his sons and his brothers, twelve; [^10] the fourth to Izri, his sons and his brothers, twelve; [^11] the fifth to Nethaniah, his sons and his brothers, twelve; [^12] the sixth to Bukkiah, his sons and his brothers, twelve; [^13] the seventh to Jesharelah, his sons and his brothers, twelve; [^14] the eighth to Jeshaiah, his sons and his brothers, twelve; [^15] the ninth to Mattaniah, his sons and his brothers, twelve; [^16] the tenth to Shimei, his sons and his brothers, twelve; [^17] the eleventh to Azarel, his sons and his brothers, twelve; [^18] the twelfth to Hashabiah, his sons and his brothers, twelve; [^19] for the thirteenth, Shubael, his sons and his brothers, twelve; [^20] for the fourteenth, Mattithiah, his sons and his brothers, twelve; [^21] for the fifteenth to Jeremoth, his sons and his brothers, twelve; [^22] for the sixteenth to Hananiah, his sons and his brothers, twelve; [^23] for the seventeenth to Joshbekashah, his sons and his brothers, twelve; [^24] for the eighteenth to Hanani, his sons and his brothers, twelve; [^25] for the nineteenth to Mallothi, his sons and his brothers, twelve; [^26] for the twentieth to Eliathah, his sons and his brothers, twelve; [^27] for the twenty-first to Hothir, his sons and his brothers, twelve; [^28] for the twenty-second to Giddalti, his sons and his brothers, twelve; [^29] for the twenty-third to Mahazioth, his sons and his brothers, twelve; [^30] for the twenty-fourth to Romamti-Ezer, his sons and his brothers, twelve. [^31] 

[[1 Chronicles - 24|<--]] 1 Chronicles - 25 [[1 Chronicles - 26|-->]]

---
# Notes
