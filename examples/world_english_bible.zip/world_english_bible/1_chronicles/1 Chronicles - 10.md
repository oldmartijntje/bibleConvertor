---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 10 - World English Bible"
---
[[1 Chronicles - 9|<--]] 1 Chronicles - 10 [[1 Chronicles - 11|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[1 Chronicles]]

# 1 Chronicles - 10

Now the Philistines fought against Israel; and the men of Israel fled from before the Philistines, and fell down slain on Mount Gilboa. [^1] The Philistines followed hard after Saul and after his sons; and the Philistines killed Jonathan, Abinadab, and Malchishua, the sons of Saul. [^2] The battle went hard against Saul, and the archers overtook him; and he was distressed by reason of the archers. [^3] Then Saul said to his armor bearer, “Draw your sword, and thrust me through with it, lest these uncircumcised come and abuse me.”But his armor bearer would not, for he was terrified. Therefore Saul took his sword and fell on it. [^4] When his armor bearer saw that Saul was dead, he likewise fell on his sword and died. [^5] So Saul died with his three sons; and all his house died together. [^6] When all the men of Israel who were in the valley saw that they fled, and that Saul and his sons were dead, they abandoned their cities, and fled; and the Philistines came and lived in them. [^7] On the next day, when the Philistines came to strip the slain, they found Saul and his sons fallen on Mount Gilboa. [^8] They stripped him and took his head and his armor, then sent into the land of the Philistines all around to carry the news to their idols and to the people. [^9] They put his armor in the house of their gods, and fastened his head in the house of Dagon. [^10] When all Jabesh Gilead heard all that the Philistines had done to Saul, [^11] all the valiant men arose and took away the body of Saul and the bodies of his sons, and brought them to Jabesh, and buried their bones under the oak in Jabesh, and fasted seven days. [^12] So Saul died for his trespass which he committed against Yahweh, because of Yahweh’s word, which he didn’t keep, and also because he asked counsel of one who had a familiar spirit, to inquire, [^13] and didn’t inquire of Yahweh. Therefore he killed him, and turned the kingdom over to David the son of Jesse. [^14] 

[[1 Chronicles - 9|<--]] 1 Chronicles - 10 [[1 Chronicles - 11|-->]]

---
# Notes
