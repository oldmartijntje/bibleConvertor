---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 13 - World English Bible"
---
[[1 Chronicles - 12|<--]] 1 Chronicles - 13 [[1 Chronicles - 14|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[1 Chronicles]]

# 1 Chronicles - 13

David consulted with the captains of thousands and of hundreds, even with every leader. [^1] David said to all the assembly of Israel, “If it seems good to you, and if it is of Yahweh our God, let’s send word everywhere to our brothers who are left in all the land of Israel, with whom the priests and Levites are in their cities that have pasture lands, that they may gather themselves to us. [^2] Also, let’s bring the ark of our God back to us again, for we didn’t seek it in the days of Saul.” [^3] All the assembly said that they would do so, for the thing was right in the eyes of all the people. [^4] So David assembled all Israel together, from the Shihor River of Egypt even to the entrance of Hamath, to bring God’s ark from Kiriath Jearim. [^5] David went up with all Israel to Baalah, that is, to Kiriath Jearim, which belonged to Judah, to bring up from there God Yahweh’s ark that sits above the cherubim, that is called by the Name. [^6] They carried God’s ark on a new cart, and brought it out of Abinadab’s house; and Uzza and Ahio drove the cart. [^7] David and all Israel played before God with all their might, even with songs, with harps, with stringed instruments, with tambourines, with cymbals, and with trumpets. [^8] When they came to Chidon’s threshing floor, Uzza put out his hand to hold the ark, for the oxen stumbled. [^9] Yahweh’s anger burned against Uzza, and he struck him because he put his hand on the ark; and he died there before God. [^10] David was displeased, because Yahweh had broken out against Uzza. He called that place Perez Uzza, to this day. [^11] David was afraid of God that day, saying, “How can I bring God’s ark home to me?” [^12] So David didn’t move the ark with him into David’s city, but carried it aside into Obed-Edom the Gittite’s house. [^13] God’s ark remained with the family of Obed-Edom in his house three months; and Yahweh blessed Obed-Edom’s house and all that he had. [^14] 

[[1 Chronicles - 12|<--]] 1 Chronicles - 13 [[1 Chronicles - 14|-->]]

---
# Notes
