---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 22 - World English Bible"
---
[[1 Chronicles - 21|<--]] 1 Chronicles - 22 [[1 Chronicles - 23|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[1 Chronicles]]

# 1 Chronicles - 22

Then David said, “This is the house of Yahweh God, and this is the altar of burnt offering for Israel.” [^1] David gave orders to gather together the foreigners who were in the land of Israel; and he set masons to cut dressed stones to build God’s house. [^2] David prepared iron in abundance for the nails for the doors of the gates and for the couplings, and bronze in abundance without weight, [^3] and cedar trees without number, for the Sidonians and the people of Tyre brought cedar trees in abundance to David. [^4] David said, “Solomon my son is young and tender, and the house that is to be built for Yahweh must be exceedingly magnificent, of fame and of glory throughout all countries. I will therefore make preparation for it.” So David prepared abundantly before his death. [^5] Then he called for Solomon his son, and commanded him to build a house for Yahweh, the God of Israel. [^6] David said to Solomon his son, “As for me, it was in my heart to build a house to the name of Yahweh my God. [^7] But Yahweh’s word came to me, saying, ‘You have shed blood abundantly and have made great wars. You shall not build a house to my name, because you have shed much blood on the earth in my sight. [^8] Behold, a son shall be born to you, who shall be a man of peace. I will give him rest from all his enemies all around; for his name shall be Solomon, and I will give peace and quietness to Israel in his days. [^9] He shall build a house for my name; and he will be my son, and I will be his father; and I will establish the throne of his kingdom over Israel forever.’ [^10] Now, my son, may Yahweh be with you and prosper you, and build the house of Yahweh your God, as he has spoken concerning you. [^11] May Yahweh give you discretion and understanding, and put you in charge of Israel, so that you may keep the law of Yahweh your God. [^12] Then you will prosper, if you observe to do the statutes and the ordinances which Yahweh gave Moses concerning Israel. Be strong and courageous. Don’t be afraid and don’t be dismayed. [^13] Now, behold, in my affliction I have prepared for Yahweh’s house one hundred thousand talents#22:14 A talent is about 30 kilograms or 66 pounds or 965 Troy ounces, so 100,000 talents is about 3 metric tons of gold, one million talents#22:14 about 30,000 metric tons of silver, and bronze and iron without weight; for it is in abundance. I have also prepared timber and stone; and you may add to them. [^14] There are also workmen with you in abundance—cutters and workers of stone and timber, and all kinds of men who are skillful in every kind of work; [^15] of the gold, the silver, the bronze, and the iron, there is no number. Arise and be doing, and may Yahweh be with you.” [^16] David also commanded all the princes of Israel to help Solomon his son, saying, [^17] “Isn’t Yahweh your God with you? Hasn’t he given you rest on every side? For he has delivered the inhabitants of the land into my hand; and the land is subdued before Yahweh and before his people. [^18] Now set your heart and your soul to follow Yahweh your God. Arise therefore, and build the sanctuary of Yahweh God, to bring the ark of Yahweh’s covenant and the holy vessels of God into the house that is to be built for Yahweh’s name.” [^19] 

[[1 Chronicles - 21|<--]] 1 Chronicles - 22 [[1 Chronicles - 23|-->]]

---
# Notes
