---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 3 - World English Bible"
---
[[1 Chronicles - 2|<--]] 1 Chronicles - 3 [[1 Chronicles - 4|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[1 Chronicles]]

# 1 Chronicles - 3

Now these were the sons of David, who were born to him in Hebron: the firstborn, Amnon, of Ahinoam the Jezreelitess; the second, Daniel, of Abigail the Carmelitess; [^1] the third, Absalom the son of Maacah the daughter of Talmai king of Geshur; the fourth, Adonijah the son of Haggith; [^2] the fifth, Shephatiah of Abital; the sixth, Ithream by Eglah his wife: [^3] six were born to him in Hebron; and he reigned there seven years and six months. He reigned thirty-three years in Jerusalem; [^4] and these were born to him in Jerusalem: Shimea, Shobab, Nathan, and Solomon, four, by Bathshua the daughter of Ammiel; [^5] and Ibhar, Elishama, Eliphelet, [^6] Nogah, Nepheg, Japhia, [^7] Elishama, Eliada, and Eliphelet, nine. [^8] All these were the sons of David, in addition to the sons of the concubines; and Tamar was their sister. [^9] Solomon’s son was Rehoboam, Abijah his son, Asa his son, Jehoshaphat his son, [^10] Joram his son, Ahaziah his son, Joash his son, [^11] Amaziah his son, Azariah his son, Jotham his son, [^12] Ahaz his son, Hezekiah his son, Manasseh his son, [^13] Amon his son, and Josiah his son. [^14] The sons of Josiah: the firstborn Johanan, the second Jehoiakim, the third Zedekiah, and the fourth Shallum. [^15] The sons of Jehoiakim: Jeconiah his son, and Zedekiah his son. [^16] The sons of Jeconiah, the captive: Shealtiel his son, [^17] Malchiram, Pedaiah, Shenazzar, Jekamiah, Hoshama, and Nedabiah. [^18] The sons of Pedaiah: Zerubbabel and Shimei. The sons of Zerubbabel: Meshullam and Hananiah; and Shelomith was their sister; [^19] and Hashubah, Ohel, Berechiah, Hasadiah, and Jushab Hesed, five. [^20] The sons of Hananiah: Pelatiah and Jeshaiah; the sons of Rephaiah, the sons of Arnan, the sons of Obadiah, the sons of Shecaniah. [^21] The son of Shecaniah: Shemaiah. The sons of Shemaiah: Hattush, Igal, Bariah, Neariah, and Shaphat, six. [^22] The sons of Neariah: Elioenai, Hizkiah, and Azrikam, three. [^23] The sons of Elioenai: Hodaviah, Eliashib, Pelaiah, Akkub, Johanan, Delaiah, and Anani, seven. [^24] 

[[1 Chronicles - 2|<--]] 1 Chronicles - 3 [[1 Chronicles - 4|-->]]

---
# Notes
