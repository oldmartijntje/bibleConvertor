---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 7 - World English Bible"
---
[[Esther - 6|<--]] Esther - 7 [[Esther - 8|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Esther]]

# Esther - 7

So the king and Haman came to banquet with Esther the queen. [^1] The king said again to Esther on the second day at the banquet of wine, “What is your petition, queen Esther? It shall be granted you. What is your request? Even to the half of the kingdom it shall be performed.” [^2] Then Esther the queen answered, “If I have found favor in your sight, O king, and if it pleases the king, let my life be given me at my petition, and my people at my request. [^3] For we are sold, I and my people, to be destroyed, to be slain, and to perish. But if we had been sold for male and female slaves, I would have held my peace, although the adversary could not have compensated for the king’s loss.” [^4] Then King Ahasuerus said to Esther the queen, “Who is he, and where is he who dared presume in his heart to do so?” [^5] Esther said, “An adversary and an enemy, even this wicked Haman!”Then Haman was afraid before the king and the queen. [^6] The king arose in his wrath from the banquet of wine and went into the palace garden. Haman stood up to make request for his life to Esther the queen, for he saw that there was evil determined against him by the king. [^7] Then the king returned out of the palace garden into the place of the banquet of wine; and Haman had fallen on the couch where Esther was. Then the king said, “Will he even assault the queen in front of me in the house?” As the word went out of the king’s mouth, they covered Haman’s face. [^8] Then Harbonah, one of the eunuchs who were with the king, said, “Behold, the gallows fifty cubits#7:9 A cubit is the length from the tip of the middle finger to the elbow on a man’s arm, or about 18 inches or 46 centimeters. high, which Haman has made for Mordecai, who spoke good for the king, is standing at Haman’s house.”The king said, “Hang him on it!” [^9] So they hanged Haman on the gallows that he had prepared for Mordecai. Then the king’s wrath was pacified. [^10] 

[[Esther - 6|<--]] Esther - 7 [[Esther - 8|-->]]

---
# Notes
