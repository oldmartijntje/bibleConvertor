---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 10 - World English Bible"
---
[[Esther - 9|<--]] Esther - 10

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Esther]]

# Esther - 10

King Ahasuerus laid a tribute on the land and on the islands of the sea. [^1] Aren’t all the acts of his power and of his might, and the full account of the greatness of Mordecai, to which the king advanced him, written in the book of the chronicles of the kings of Media and Persia? [^2] For Mordecai the Jew was next to King Ahasuerus, and great among the Jews and accepted by the multitude of his brothers, seeking the good of his people and speaking peace to all his descendants. [^3] 

[[Esther - 9|<--]] Esther - 10

---
# Notes
