---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 6 - World English Bible"
---
[[Esther - 5|<--]] Esther - 6 [[Esther - 7|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Esther]]

# Esther - 6

On that night, the king couldn’t sleep. He commanded the book of records of the chronicles to be brought, and they were read to the king. [^1] It was found written that Mordecai had told of Bigthana and Teresh, two of the king’s eunuchs, who were doorkeepers, who had tried to lay hands on the King Ahasuerus. [^2] The king said, “What honor and dignity has been given to Mordecai for this?”Then the king’s servants who attended him said, “Nothing has been done for him.” [^3] The king said, “Who is in the court?” Now Haman had come into the outer court of the king’s house, to speak to the king about hanging Mordecai on the gallows that he had prepared for him. [^4] The king’s servants said to him, “Behold,#6:5 “Behold”, from “הִנֵּה”, means look at, take notice, observe, see, or gaze at. It is often used as an interjection. Haman stands in the court.”The king said, “Let him come in.” [^5] So Haman came in. The king said to him, “What shall be done to the man whom the king delights to honor?”Now Haman said in his heart, “Who would the king delight to honor more than myself?” [^6] Haman said to the king, “For the man whom the king delights to honor, [^7] let royal clothing be brought which the king uses to wear, and the horse that the king rides on, and on the head of which a royal crown is set. [^8] Let the clothing and the horse be delivered to the hand of one of the king’s most noble princes, that they may array the man whom the king delights to honor with them, and have him ride on horseback through the city square, and proclaim before him, ‘Thus it shall be done to the man whom the king delights to honor!’” [^9] Then the king said to Haman, “Hurry and take the clothing and the horse, as you have said, and do this for Mordecai the Jew, who sits at the king’s gate. Let nothing fail of all that you have spoken.” [^10] Then Haman took the clothing and the horse, and arrayed Mordecai, and had him ride through the city square, and proclaimed before him, “Thus it shall be done to the man whom the king delights to honor!” [^11] Mordecai came back to the king’s gate, but Haman hurried to his house, mourning and having his head covered. [^12] Haman recounted to Zeresh his wife and all his friends everything that had happened to him. Then his wise men and Zeresh his wife said to him, “If Mordecai, before whom you have begun to fall, is of Jewish descent, you will not prevail against him, but you will surely fall before him.” [^13] While they were yet talking with him, the king’s eunuchs came, and hurried to bring Haman to the banquet that Esther had prepared. [^14] 

[[Esther - 5|<--]] Esther - 6 [[Esther - 7|-->]]

---
# Notes
