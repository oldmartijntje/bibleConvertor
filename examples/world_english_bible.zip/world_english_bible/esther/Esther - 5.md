---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 5 - World English Bible"
---
[[Esther - 4|<--]] Esther - 5 [[Esther - 6|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Esther]]

# Esther - 5

Now on the third day, Esther put on her royal clothing and stood in the inner court of the king’s house, next to the king’s house. The king sat on his royal throne in the royal house, next to the entrance of the house. [^1] When the king saw Esther the queen standing in the court, she obtained favor in his sight; and the king held out to Esther the golden scepter that was in his hand. So Esther came near and touched the top of the scepter. [^2] Then the king asked her, “What would you like, queen Esther? What is your request? It shall be given you even to the half of the kingdom.” [^3] Esther said, “If it seems good to the king, let the king and Haman come today to the banquet that I have prepared for him.” [^4] Then the king said, “Bring Haman quickly, so that it may be done as Esther has said.” So the king and Haman came to the banquet that Esther had prepared. [^5] The king said to Esther at the banquet of wine, “What is your petition? It shall be granted you. What is your request? Even to the half of the kingdom it shall be performed.” [^6] Then Esther answered and said, “My petition and my request is this. [^7] If I have found favor in the sight of the king, and if it pleases the king to grant my petition and to perform my request, let the king and Haman come to the banquet that I will prepare for them, and I will do tomorrow as the king has said.” [^8] Then Haman went out that day joyful and glad of heart, but when Haman saw Mordecai in the king’s gate, that he didn’t stand up nor move for him, he was filled with wrath against Mordecai. [^9] Nevertheless Haman restrained himself, and went home. There, he sent and called for his friends and Zeresh his wife. [^10] Haman recounted to them the glory of his riches, the multitude of his children, all the things in which the king had promoted him, and how he had advanced him above the princes and servants of the king. [^11] Haman also said, “Yes, Esther the queen let no man come in with the king to the banquet that she had prepared but myself; and tomorrow I am also invited by her together with the king. [^12] Yet all this avails me nothing, so long as I see Mordecai the Jew sitting at the king’s gate.” [^13] Then Zeresh his wife and all his friends said to him, “Let a gallows be made fifty cubits#5:14 A cubit is the length from the tip of the middle finger to the elbow on a man’s arm, or about 18 inches or 46 centimeters. high, and in the morning speak to the king about hanging Mordecai on it. Then go in merrily with the king to the banquet.” This pleased Haman, so he had the gallows made. [^14] 

[[Esther - 4|<--]] Esther - 5 [[Esther - 6|-->]]

---
# Notes
