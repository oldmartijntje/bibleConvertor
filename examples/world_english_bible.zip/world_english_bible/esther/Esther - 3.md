---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 3 - World English Bible"
---
[[Esther - 2|<--]] Esther - 3 [[Esther - 4|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Esther]]

# Esther - 3

After these things King Ahasuerus promoted Haman the son of Hammedatha the Agagite, and advanced him, and set his seat above all the princes who were with him. [^1] All the king’s servants who were in the king’s gate bowed down and paid homage to Haman, for the king had so commanded concerning him. But Mordecai didn’t bow down or pay him homage. [^2] Then the king’s servants who were in the king’s gate said to Mordecai, “Why do you disobey the king’s commandment?” [^3] Now it came to pass, when they spoke daily to him, and he didn’t listen to them, that they told Haman, to see whether Mordecai’s reason would stand; for he had told them that he was a Jew. [^4] When Haman saw that Mordecai didn’t bow down nor pay him homage, Haman was full of wrath. [^5] But he scorned the thought of laying hands on Mordecai alone, for they had made known to him Mordecai’s people. Therefore Haman sought to destroy all the Jews who were throughout the whole kingdom of Ahasuerus, even Mordecai’s people. [^6] In the first month, which is the month Nisan, in the twelfth year of King Ahasuerus, they cast Pur, that is, the lot, before Haman from day to day, and from month to month, and chose the twelfth month, which is the month Adar. [^7] Haman said to King Ahasuerus, “There is a certain people scattered abroad and dispersed among the peoples in all the provinces of your kingdom, and their laws are different from other people’s. They don’t keep the king’s laws. Therefore it is not for the king’s profit to allow them to remain. [^8] If it pleases the king, let it be written that they be destroyed; and I will pay ten thousand talents#3:9 A talent is about 30 kilograms or 66 pounds or 965 Troy ounces of silver into the hands of those who are in charge of the king’s business, to bring it into the king’s treasuries.” [^9] The king took his ring from his hand, and gave it to Haman the son of Hammedatha the Agagite, the Jews’ enemy. [^10] The king said to Haman, “The silver is given to you, the people also, to do with them as it seems good to you.” [^11] Then the king’s scribes were called in on the first month, on the thirteenth day of the month; and all that Haman commanded was written to the king’s local governors, and to the governors who were over every province, and to the princes of every people, to every province according to its writing, and to every people in their language. It was written in the name of King Ahasuerus, and it was sealed with the king’s ring. [^12] Letters were sent by couriers into all the king’s provinces, to destroy, to kill, and to cause to perish, all Jews, both young and old, little children and women, in one day, even on the thirteenth day of the twelfth month, which is the month Adar, and to plunder their possessions. [^13] A copy of the letter, that the decree should be given out in every province, was published to all the peoples, that they should be ready against that day. [^14] The couriers went out in haste by the king’s commandment, and the decree was given out in the citadel of Susa. The king and Haman sat down to drink; but the city of Susa was perplexed. [^15] 

[[Esther - 2|<--]] Esther - 3 [[Esther - 4|-->]]

---
# Notes
