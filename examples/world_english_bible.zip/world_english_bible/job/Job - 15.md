---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 15 - World English Bible"
---
[[Job - 14|<--]] Job - 15 [[Job - 16|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 15

Then Eliphaz the Temanite answered, [^1] “Should a wise man answer with vain knowledge,and fill himself with the east wind? [^2] Should he reason with unprofitable talk,or with speeches with which he can do no good? [^3] Yes, you do away with fear,and hinder devotion before God. [^4] For your iniquity teaches your mouth,and you choose the language of the crafty. [^5] Your own mouth condemns you, and not I.Yes, your own lips testify against you. [^6] “Are you the first man who was born?Or were you brought out before the hills? [^7] Have you heard the secret counsel of God?Do you limit wisdom to yourself? [^8] What do you know that we don’t know?What do you understand which is not in us? [^9] With us are both the gray-headed and the very aged men,much older than your father. [^10] Are the consolations of God too small for you,even the word that is gentle toward you? [^11] Why does your heart carry you away?Why do your eyes flash, [^12] that you turn your spirit against God,and let such words go out of your mouth? [^13] What is man, that he should be clean?What is he who is born of a woman, that he should be righteous? [^14] Behold, he puts no trust in his holy ones.Yes, the heavens are not clean in his sight; [^15] how much less one who is abominable and corrupt,a man who drinks iniquity like water! [^16] “I will show you, listen to me;that which I have seen I will declare [^17] (which wise men have told by their fathers,and have not hidden it; [^18] to whom alone the land was given,and no stranger passed among them): [^19] the wicked man writhes in pain all his days,even the number of years that are laid up for the oppressor. [^20] A sound of terrors is in his ears.In prosperity the destroyer will come on him. [^21] He doesn’t believe that he will return out of darkness.He is waited for by the sword. [^22] He wanders abroad for bread, saying, ‘Where is it?’He knows that the day of darkness is ready at his hand. [^23] Distress and anguish make him afraid.They prevail against him, as a king ready to the battle. [^24] Because he has stretched out his hand against God,and behaves himself proudly against the Almighty, [^25] he runs at him with a stiff neck,with the thick shields of his bucklers, [^26] because he has covered his face with his fatness,and gathered fat on his thighs. [^27] He has lived in desolate cities,in houses which no one inhabited,which were ready to become heaps. [^28] He will not be rich, neither will his substance continue,neither will their possessions be extended on the earth. [^29] He will not depart out of darkness.The flame will dry up his branches.He will go away by the breath of God’s mouth. [^30] Let him not trust in emptiness, deceiving himself,for emptiness will be his reward. [^31] It will be accomplished before his time.His branch will not be green. [^32] He will shake off his unripe grape as the vine,and will cast off his flower as the olive tree. [^33] For the company of the godless will be barren,and fire will consume the tents of bribery. [^34] They conceive mischief and produce iniquity.Their heart prepares deceit.” [^35] 

[[Job - 14|<--]] Job - 15 [[Job - 16|-->]]

---
# Notes
