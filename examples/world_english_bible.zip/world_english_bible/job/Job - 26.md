---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 26 - World English Bible"
---
[[Job - 25|<--]] Job - 26 [[Job - 27|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 26

Then Job answered, [^1] “How have you helped him who is without power!How have you saved the arm that has no strength! [^2] How have you counseled him who has no wisdom,and plentifully declared sound knowledge! [^3] To whom have you uttered words?Whose spirit came out of you? [^4] “The departed spirits tremble,those beneath the waters and all that live in them. [^5] Sheol#26:6 Sheol is the place of the dead. is naked before God,and Abaddon#26:6 Abaddon means Destroyer. has no covering. [^6] He stretches out the north over empty space,and hangs the earth on nothing. [^7] He binds up the waters in his thick clouds,and the cloud is not burst under them. [^8] He encloses the face of his throne,and spreads his cloud on it. [^9] He has described a boundary on the surface of the waters,and to the confines of light and darkness. [^10] The pillars of heaven trembleand are astonished at his rebuke. [^11] He stirs up the sea with his power,and by his understanding he strikes through Rahab. [^12] By his Spirit the heavens are garnished.His hand has pierced the swift serpent. [^13] Behold, these are but the outskirts of his ways.How small a whisper do we hear of him!But the thunder of his power who can understand?” [^14] 

[[Job - 25|<--]] Job - 26 [[Job - 27|-->]]

---
# Notes
