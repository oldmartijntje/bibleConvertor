---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 31 - World English Bible"
---
[[Job - 30|<--]] Job - 31 [[Job - 32|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 31

“I made a covenant with my eyes;how then should I look lustfully at a young woman? [^1] For what is the portion from God above,and the heritage from the Almighty on high? [^2] Is it not calamity to the unrighteous,and disaster to the workers of iniquity? [^3] Doesn’t he see my ways,and count all my steps? [^4] “If I have walked with falsehood,and my foot has hurried to deceit [^5] (let me be weighed in an even balance,that God may know my integrity); [^6] if my step has turned out of the way,if my heart walked after my eyes,if any defilement has stuck to my hands, [^7] then let me sow, and let another eat.Yes, let the produce of my field be rooted out. [^8] “If my heart has been enticed to a woman,and I have laid wait at my neighbor’s door, [^9] then let my wife grind for another,and let others sleep with her. [^10] For that would be a heinous crime.Yes, it would be an iniquity to be punished by the judges, [^11] for it is a fire that consumes to destruction,and would root out all my increase. [^12] “If I have despised the cause of my male servantor of my female servant,when they contended with me, [^13] what then will I do when God rises up?When he visits, what will I answer him? [^14] Didn’t he who made me in the womb make him?Didn’t one fashion us in the womb? [^15] “If I have withheld the poor from their desire,or have caused the eyes of the widow to fail, [^16] or have eaten my morsel alone,and the fatherless has not eaten of it [^17] (no, from my youth he grew up with me as with a father,I have guided her from my mother’s womb); [^18] if I have seen any perish for want of clothing,or that the needy had no covering; [^19] if his heart hasn’t blessed me,if he hasn’t been warmed with my sheep’s fleece; [^20] if I have lifted up my hand against the fatherless,because I saw my help in the gate; [^21] then let my shoulder fall from the shoulder blade,and my arm be broken from the bone. [^22] For calamity from God is a terror to me.Because of his majesty, I can do nothing. [^23] “If I have made gold my hope,and have said to the fine gold, ‘You are my confidence;’ [^24] If I have rejoiced because my wealth was great,and because my hand had gotten much; [^25] if I have seen the sun when it shined,or the moon moving in splendor, [^26] and my heart has been secretly enticed,and my hand threw a kiss from my mouth; [^27] this also would be an iniquity to be punished by the judges,for I would have denied the God who is above. [^28] “If I have rejoiced at the destruction of him who hated me,or lifted up myself when evil found him [^29] (I have certainly not allowed my mouth to sinby asking his life with a curse); [^30] if the men of my tent have not said,‘Who can find one who has not been filled with his meat?’ [^31] (the foreigner has not camped in the street,but I have opened my doors to the traveler); [^32] if like Adam I have covered my transgressions,by hiding my iniquity in my heart, [^33] because I feared the great multitude,and the contempt of families terrified me,so that I kept silence, and didn’t go out of the door— [^34] oh that I had one to hear me!Behold, here is my signature! Let the Almighty answer me!Let the accuser write my indictment! [^35] Surely I would carry it on my shoulder,and I would bind it to me as a crown. [^36] I would declare to him the number of my steps.I would go near to him like a prince. [^37] If my land cries out against me,and its furrows weep together; [^38] if I have eaten its fruits without money,or have caused its owners to lose their life, [^39] let briers grow instead of wheat,and stinkweed instead of barley.”The words of Job are ended. [^40] 

[[Job - 30|<--]] Job - 31 [[Job - 32|-->]]

---
# Notes
