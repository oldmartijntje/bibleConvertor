---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 12 - World English Bible"
---
[[Job - 11|<--]] Job - 12 [[Job - 13|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 12

Then Job answered, [^1] “No doubt, but you are the people,and wisdom will die with you. [^2] But I have understanding as well as you;I am not inferior to you.Yes, who doesn’t know such things as these? [^3] I am like one who is a joke to his neighbor,I, who called on God, and he answered.The just, the blameless man is a joke. [^4] In the thought of him who is at ease there is contempt for misfortune.It is ready for them whose foot slips. [^5] The tents of robbers prosper.Those who provoke God are secure,who carry their god in their hands. [^6] “But ask the animals now, and they will teach you;the birds of the sky, and they will tell you. [^7] Or speak to the earth, and it will teach you.The fish of the sea will declare to you. [^8] Who doesn’t know that in all these,Yahweh’s hand has done this, [^9] in whose hand is the life of every living thing,and the breath of all mankind? [^10] Doesn’t the ear try words,even as the palate tastes its food? [^11] With aged men is wisdom,in length of days understanding. [^12] “With God is wisdom and might.He has counsel and understanding. [^13] Behold, he breaks down, and it can’t be built again.He imprisons a man, and there can be no release. [^14] Behold, he withholds the waters, and they dry up.Again, he sends them out, and they overturn the earth. [^15] With him is strength and wisdom.The deceived and the deceiver are his. [^16] He leads counselors away stripped.He makes judges fools. [^17] He loosens the bond of kings.He binds their waist with a belt. [^18] He leads priests away stripped,and overthrows the mighty. [^19] He removes the speech of those who are trusted,and takes away the understanding of the elders. [^20] He pours contempt on princes,and loosens the belt of the strong. [^21] He uncovers deep things out of darkness,and brings out to light the shadow of death. [^22] He increases the nations, and he destroys them.He enlarges the nations, and he leads them captive. [^23] He takes away understanding from the chiefs of the people of the earth,and causes them to wander in a wilderness where there is no way. [^24] They grope in the dark without light.He makes them stagger like a drunken man. [^25] 

[[Job - 11|<--]] Job - 12 [[Job - 13|-->]]

---
# Notes
