---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 25 - World English Bible"
---
[[Job - 24|<--]] Job - 25 [[Job - 26|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 25

Then Bildad the Shuhite answered, [^1] “Dominion and fear are with him.He makes peace in his high places. [^2] Can his armies be counted?On whom does his light not arise? [^3] How then can man be just with God?Or how can he who is born of a woman be clean? [^4] Behold, even the moon has no brightness,and the stars are not pure in his sight; [^5] How much less man, who is a worm,and the son of man, who is a worm!” [^6] 

[[Job - 24|<--]] Job - 25 [[Job - 26|-->]]

---
# Notes
