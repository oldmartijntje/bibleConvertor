---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 13 - World English Bible"
---
[[Job - 12|<--]] Job - 13 [[Job - 14|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 13

“Behold, my eye has seen all this.My ear has heard and understood it. [^1] What you know, I know also.I am not inferior to you. [^2] “Surely I would speak to the Almighty.I desire to reason with God. [^3] But you are forgers of lies.You are all physicians of no value. [^4] Oh that you would be completely silent!Then you would be wise. [^5] Hear now my reasoning.Listen to the pleadings of my lips. [^6] Will you speak unrighteously for God,and talk deceitfully for him? [^7] Will you show partiality to him?Will you contend for God? [^8] Is it good that he should search you out?Or as one deceives a man, will you deceive him? [^9] He will surely reprove youif you secretly show partiality. [^10] Won’t his majesty make you afraidand his dread fall on you? [^11] Your memorable sayings are proverbs of ashes.Your defenses are defenses of clay. [^12] “Be silent!Leave me alone, that I may speak.Let come on me what will. [^13] Why should I take my flesh in my teeth,and put my life in my hand? [^14] Behold, he will kill me.I have no hope.Nevertheless, I will maintain my ways before him. [^15] This also will be my salvation,that a godless man will not come before him. [^16] Listen carefully to my speech.Let my declaration be in your ears. [^17] See now, I have set my cause in order.I know that I am righteous. [^18] Who is he who will contend with me?For then I would hold my peace and give up the spirit. [^19] “Only don’t do two things to me,then I will not hide myself from your face: [^20] withdraw your hand far from me,and don’t let your terror make me afraid. [^21] Then call, and I will answer,or let me speak, and you answer me. [^22] How many are my iniquities and sins?Make me know my disobedience and my sin. [^23] Why do you hide your face,and consider me your enemy? [^24] Will you harass a driven leaf?Will you pursue the dry stubble? [^25] For you write bitter things against me,and make me inherit the iniquities of my youth. [^26] You also put my feet in the stocks,and mark all my paths.You set a bound to the soles of my feet, [^27] though I am decaying like a rotten thing,like a garment that is moth-eaten. [^28] 

[[Job - 12|<--]] Job - 13 [[Job - 14|-->]]

---
# Notes
