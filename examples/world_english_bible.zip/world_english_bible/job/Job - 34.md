---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 34 - World English Bible"
---
[[Job - 33|<--]] Job - 34 [[Job - 35|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 34

Moreover Elihu answered, [^1] “Hear my words, you wise men.Give ear to me, you who have knowledge. [^2] For the ear tries words,as the palate tastes food. [^3] Let us choose for us that which is right.Let us know among ourselves what is good. [^4] For Job has said, ‘I am righteous,God has taken away my right. [^5] Notwithstanding my right I am considered a liar.My wound is incurable, though I am without disobedience.’ [^6] What man is like Job,who drinks scorn like water, [^7] who goes in company with the workers of iniquity,and walks with wicked men? [^8] For he has said, ‘It profits a man nothingthat he should delight himself with God.’ [^9] “Therefore listen to me, you men of understanding:far be it from God, that he should do wickedness,from the Almighty, that he should commit iniquity. [^10] For the work of a man he will give to him,and cause every man to find according to his ways. [^11] Yes surely, God will not do wickedly,neither will the Almighty pervert justice. [^12] Who put him in charge of the earth?Or who has appointed him over the whole world? [^13] If he set his heart on himself,if he gathered to himself his spirit and his breath, [^14] all flesh would perish together,and man would turn again to dust. [^15] “If now you have understanding, hear this.Listen to the voice of my words. [^16] Should even one who hates justice govern?Will you condemn him who is righteous and mighty, [^17] who says to a king, ‘Vile!’or to nobles, ‘Wicked!’? [^18] He doesn’t respect the persons of princes,nor respect the rich more than the poor,for they all are the work of his hands. [^19] In a moment they die, even at midnight.The people are shaken and pass away.The mighty are taken away without a hand. [^20] “For his eyes are on the ways of a man.He sees all his goings. [^21] There is no darkness, nor thick gloom,where the workers of iniquity may hide themselves. [^22] For he doesn’t need to consider a man further,that he should go before God in judgment. [^23] He breaks mighty men in pieces in ways past finding out,and sets others in their place. [^24] Therefore he takes knowledge of their works.He overturns them in the night, so that they are destroyed. [^25] He strikes them as wicked menin the open sight of others; [^26] because they turned away from following him,and wouldn’t pay attention to any of his ways, [^27] so that they caused the cry of the poor to come to him.He heard the cry of the afflicted. [^28] When he gives quietness, who then can condemn?When he hides his face, who then can see him?He is over a nation or a man alike, [^29] that the godless man may not reign,that there be no one to ensnare the people. [^30] “For has any said to God,‘I am guilty, but I will not offend any more. [^31] Teach me that which I don’t see.If I have done iniquity, I will do it no more’? [^32] Shall his recompense be as you desire, that you refuse it?For you must choose, and not I.Therefore speak what you know. [^33] Men of understanding will tell me,yes, every wise man who hears me: [^34] ‘Job speaks without knowledge.His words are without wisdom.’ [^35] I wish that Job were tried to the end,because of his answering like wicked men. [^36] For he adds rebellion to his sin.He claps his hands among us,and multiplies his words against God.” [^37] 

[[Job - 33|<--]] Job - 34 [[Job - 35|-->]]

---
# Notes
