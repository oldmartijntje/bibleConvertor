---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 24 - World English Bible"
---
[[Job - 23|<--]] Job - 24 [[Job - 25|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 24

“Why aren’t times laid up by the Almighty?Why don’t those who know him see his days? [^1] There are people who remove the landmarks.They violently take away flocks, and feed them. [^2] They drive away the donkey of the fatherless,and they take the widow’s ox for a pledge. [^3] They turn the needy out of the way.The poor of the earth all hide themselves. [^4] Behold, as wild donkeys in the desert,they go out to their work, seeking diligently for food.The wilderness yields them bread for their children. [^5] They cut their food in the field.They glean the vineyard of the wicked. [^6] They lie all night naked without clothing,and have no covering in the cold. [^7] They are wet with the showers of the mountains,and embrace the rock for lack of a shelter. [^8] There are those who pluck the fatherless from the breast,and take a pledge of the poor, [^9] so that they go around naked without clothing.Being hungry, they carry the sheaves. [^10] They make oil within the walls of these men.They tread wine presses, and suffer thirst. [^11] From out of the populous city, men groan.The soul of the wounded cries out,yet God doesn’t regard the folly. [^12] “These are of those who rebel against the light.They don’t know its ways,nor stay in its paths. [^13] The murderer rises with the light.He kills the poor and needy.In the night he is like a thief. [^14] The eye also of the adulterer waits for the twilight,saying, ‘No eye will see me.’He disguises his face. [^15] In the dark they dig through houses.They shut themselves up in the daytime.They don’t know the light. [^16] For the morning is to all of them like thick darkness,for they know the terrors of the thick darkness. [^17] “They are foam on the surface of the waters.Their portion is cursed in the earth.They don’t turn into the way of the vineyards. [^18] Drought and heat consume the snow waters,so does Sheol#24:19 Sheol is the place of the dead. those who have sinned. [^19] The womb will forget him.The worm will feed sweetly on him.He will be no more remembered.Unrighteousness will be broken as a tree. [^20] He devours the barren who don’t bear.He shows no kindness to the widow. [^21] Yet God preserves the mighty by his power.He rises up who has no assurance of life. [^22] God gives them security, and they rest in it.His eyes are on their ways. [^23] They are exalted; yet a little while, and they are gone.Yes, they are brought low, they are taken out of the way as all others,and are cut off as the tops of the ears of grain. [^24] If it isn’t so now, who will prove me a liar,and make my speech worth nothing?” [^25] 

[[Job - 23|<--]] Job - 24 [[Job - 25|-->]]

---
# Notes
