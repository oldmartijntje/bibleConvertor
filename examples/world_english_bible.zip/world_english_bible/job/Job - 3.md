---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 3 - World English Bible"
---
[[Job - 2|<--]] Job - 3 [[Job - 4|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 3

After this Job opened his mouth, and cursed the day of his birth. [^1] Job answered: [^2] “Let the day perish in which I was born,the night which said, ‘There is a boy conceived.’ [^3] Let that day be darkness.Don’t let God from above seek for it,neither let the light shine on it. [^4] Let darkness and the shadow of death claim it for their own.Let a cloud dwell on it.Let all that makes the day black terrify it. [^5] As for that night, let thick darkness seize on it.Let it not rejoice among the days of the year.Let it not come into the number of the months. [^6] Behold, let that night be barren.Let no joyful voice come therein. [^7] Let them curse it who curse the day,who are ready to rouse up leviathan. [^8] Let the stars of its twilight be dark.Let it look for light, but have none,neither let it see the eyelids of the morning, [^9] because it didn’t shut up the doors of my mother’s womb,nor did it hide trouble from my eyes. [^10] “Why didn’t I die from the womb?Why didn’t I give up the spirit when my mother bore me? [^11] Why did the knees receive me?Or why the breast, that I should nurse? [^12] For now I should have lain down and been quiet.I should have slept, then I would have been at rest, [^13] with kings and counselors of the earth,who built up waste places for themselves; [^14] or with princes who had gold,who filled their houses with silver; [^15] or as a hidden untimely birth I had not been,as infants who never saw light. [^16] There the wicked cease from troubling.There the weary are at rest. [^17] There the prisoners are at ease together.They don’t hear the voice of the taskmaster. [^18] The small and the great are there.The servant is free from his master. [^19] “Why is light given to him who is in misery,life to the bitter in soul, [^20] who long for death, but it doesn’t come;and dig for it more than for hidden treasures, [^21] who rejoice exceedingly,and are glad, when they can find the grave? [^22] Why is light given to a man whose way is hidden,whom God has hedged in? [^23] For my sighing comes before I eat.My groanings are poured out like water. [^24] For the thing which I fear comes on me,that which I am afraid of comes to me. [^25] I am not at ease, neither am I quiet, neither do I have rest;but trouble comes.” [^26] 

[[Job - 2|<--]] Job - 3 [[Job - 4|-->]]

---
# Notes
