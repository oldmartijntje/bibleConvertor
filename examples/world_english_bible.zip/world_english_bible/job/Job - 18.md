---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 18 - World English Bible"
---
[[Job - 17|<--]] Job - 18 [[Job - 19|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 18

Then Bildad the Shuhite answered, [^1] “How long will you hunt for words?Consider, and afterwards we will speak. [^2] Why are we counted as animals,which have become unclean in your sight? [^3] You who tear yourself in your anger,will the earth be forsaken for you?Or will the rock be removed out of its place? [^4] “Yes, the light of the wicked will be put out.The spark of his fire won’t shine. [^5] The light will be dark in his tent.His lamp above him will be put out. [^6] The steps of his strength will be shortened.His own counsel will cast him down. [^7] For he is cast into a net by his own feet,and he wanders into its mesh. [^8] A snare will take him by the heel.A trap will catch him. [^9] A noose is hidden for him in the ground,a trap for him on the path. [^10] Terrors will make him afraid on every side,and will chase him at his heels. [^11] His strength will be famished.Calamity will be ready at his side. [^12] The members of his body will be devoured.The firstborn of death will devour his members. [^13] He will be rooted out of the security of his tent.He will be brought to the king of terrors. [^14] There will dwell in his tent that which is none of his.Sulfur will be scattered on his habitation. [^15] His roots will be dried up beneath.His branch will be cut off above. [^16] His memory will perish from the earth.He will have no name in the street. [^17] He will be driven from light into darkness,and chased out of the world. [^18] He will have neither son nor grandson among his people,nor any remaining where he lived. [^19] Those who come after will be astonished at his day,as those who went before were frightened. [^20] Surely such are the dwellings of the unrighteous.This is the place of him who doesn’t know God.” [^21] 

[[Job - 17|<--]] Job - 18 [[Job - 19|-->]]

---
# Notes
