---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 19 - World English Bible"
---
[[Job - 18|<--]] Job - 19 [[Job - 20|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 19

Then Job answered, [^1] “How long will you torment me,and crush me with words? [^2] You have reproached me ten times.You aren’t ashamed that you attack me. [^3] If it is true that I have erred,my error remains with myself. [^4] If indeed you will magnify yourselves against me,and plead against me my reproach, [^5] know now that God has subverted me,and has surrounded me with his net. [^6] “Behold, I cry out of wrong, but I am not heard.I cry for help, but there is no justice. [^7] He has walled up my way so that I can’t pass,and has set darkness in my paths. [^8] He has stripped me of my glory,and taken the crown from my head. [^9] He has broken me down on every side, and I am gone.He has plucked my hope up like a tree. [^10] He has also kindled his wrath against me.He counts me among his adversaries. [^11] His troops come on together,build a siege ramp against me,and encamp around my tent. [^12] “He has put my brothers far from me.My acquaintances are wholly estranged from me. [^13] My relatives have gone away.My familiar friends have forgotten me. [^14] Those who dwell in my house and my maids consider me a stranger.I am an alien in their sight. [^15] I call to my servant, and he gives me no answer.I beg him with my mouth. [^16] My breath is offensive to my wife.I am loathsome to the children of my own mother. [^17] Even young children despise me.If I arise, they speak against me. [^18] All my familiar friends abhor me.They whom I loved have turned against me. [^19] My bones stick to my skin and to my flesh.I have escaped by the skin of my teeth. [^20] “Have pity on me. Have pity on me, you my friends,for the hand of God has touched me. [^21] Why do you persecute me as God,and are not satisfied with my flesh? [^22] “Oh that my words were now written!Oh that they were inscribed in a book! [^23] That with an iron pen and leadthey were engraved in the rock forever! [^24] But as for me, I know that my Redeemer lives.In the end, he will stand upon the earth. [^25] After my skin is destroyed,then I will see God in my flesh, [^26] whom I, even I, will see on my side.My eyes will see, and not as a stranger.“My heart is consumed within me. [^27] If you say, ‘How we will persecute him!’because the root of the matter is found in me, [^28] be afraid of the sword,for wrath brings the punishments of the sword,that you may know there is a judgment.” [^29] 

[[Job - 18|<--]] Job - 19 [[Job - 20|-->]]

---
# Notes
