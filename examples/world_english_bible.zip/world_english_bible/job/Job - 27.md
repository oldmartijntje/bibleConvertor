---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 27 - World English Bible"
---
[[Job - 26|<--]] Job - 27 [[Job - 28|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 27

Job again took up his parable, and said, [^1] “As God lives, who has taken away my right,the Almighty, who has made my soul bitter [^2] (for the length of my life is still in me,and the spirit of God is in my nostrils); [^3] surely my lips will not speak unrighteousness,neither will my tongue utter deceit. [^4] Far be it from me that I should justify you.Until I die I will not put away my integrity from me. [^5] I hold fast to my righteousness, and will not let it go.My heart will not reproach me so long as I live. [^6] “Let my enemy be as the wicked.Let him who rises up against me be as the unrighteous. [^7] For what is the hope of the godless, when he is cut off,when God takes away his life? [^8] Will God hear his cry when trouble comes on him? [^9] Will he delight himself in the Almighty,and call on God at all times? [^10] I will teach you about the hand of God.I will not conceal that which is with the Almighty. [^11] Behold, all of you have seen it yourselves;why then have you become altogether vain? [^12] “This is the portion of a wicked man with God,the heritage of oppressors, which they receive from the Almighty. [^13] If his children are multiplied, it is for the sword.His offspring will not be satisfied with bread. [^14] Those who remain of him will be buried in death.His widows will make no lamentation. [^15] Though he heap up silver as the dust,and prepare clothing as the clay; [^16] he may prepare it, but the just will put it on,and the innocent will divide the silver. [^17] He builds his house as the moth,as a booth which the watchman makes. [^18] He lies down rich, but he will not do so again.He opens his eyes, and he is not. [^19] Terrors overtake him like waters.A storm steals him away in the night. [^20] The east wind carries him away, and he departs.It sweeps him out of his place. [^21] For it hurls at him, and does not spare,as he flees away from his hand. [^22] Men will clap their hands at him,and will hiss him out of his place. [^23] 

[[Job - 26|<--]] Job - 27 [[Job - 28|-->]]

---
# Notes
