---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 8 - World English Bible"
---
[[Job - 7|<--]] Job - 8 [[Job - 9|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 8

Then Bildad the Shuhite answered, [^1] “How long will you speak these things?Shall the words of your mouth be a mighty wind? [^2] Does God pervert justice?Or does the Almighty pervert righteousness? [^3] If your children have sinned against him,he has delivered them into the hand of their disobedience. [^4] If you want to seek God diligently,make your supplication to the Almighty. [^5] If you were pure and upright,surely now he would awaken for you,and make the habitation of your righteousness prosperous. [^6] Though your beginning was small,yet your latter end would greatly increase. [^7] “Please inquire of past generations.Find out about the learning of their fathers. [^8] (For we are but of yesterday, and know nothing,because our days on earth are a shadow.) [^9] Shall they not teach you, tell you,and utter words out of their heart? [^10] “Can the papyrus grow up without mire?Can the rushes grow without water? [^11] While it is yet in its greenness, not cut down,it withers before any other reed. [^12] So are the paths of all who forget God.The hope of the godless man will perish, [^13] whose confidence will break apart,whose trust is a spider’s web. [^14] He will lean on his house, but it will not stand.He will cling to it, but it will not endure. [^15] He is green before the sun.His shoots go out along his garden. [^16] His roots are wrapped around the rock pile.He sees the place of stones. [^17] If he is destroyed from his place,then it will deny him, saying, ‘I have not seen you.’ [^18] Behold, this is the joy of his way.Out of the earth, others will spring. [^19] “Behold, God will not cast away a blameless man,neither will he uphold the evildoers. [^20] He will still fill your mouth with laughter,your lips with shouting. [^21] Those who hate you will be clothed with shame.The tent of the wicked will be no more.” [^22] 

[[Job - 7|<--]] Job - 8 [[Job - 9|-->]]

---
# Notes
