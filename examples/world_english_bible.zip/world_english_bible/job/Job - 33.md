---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 33 - World English Bible"
---
[[Job - 32|<--]] Job - 33 [[Job - 34|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 33

“However, Job, please hear my speech,and listen to all my words. [^1] See now, I have opened my mouth.My tongue has spoken in my mouth. [^2] My words will utter the uprightness of my heart.That which my lips know they will speak sincerely. [^3] The Spirit of God has made me,and the breath of the Almighty gives me life. [^4] If you can, answer me.Set your words in order before me, and stand up. [^5] Behold, I am toward God even as you are.I am also formed out of the clay. [^6] Behold, my terror will not make you afraid,neither will my pressure be heavy on you. [^7] “Surely you have spoken in my hearing,I have heard the voice of your words, saying, [^8] ‘I am clean, without disobedience.I am innocent, neither is there iniquity in me. [^9] Behold, he finds occasions against me.He counts me for his enemy. [^10] He puts my feet in the stocks.He marks all my paths.’ [^11] “Behold, I will answer you. In this you are not just,for God is greater than man. [^12] Why do you strive against him,because he doesn’t give account of any of his matters? [^13] For God speaks once,yes twice, though man pays no attention. [^14] In a dream, in a vision of the night,when deep sleep falls on men,in slumbering on the bed, [^15] then he opens the ears of men,and seals their instruction, [^16] that he may withdraw man from his purpose,and hide pride from man. [^17] He keeps back his soul from the pit,and his life from perishing by the sword. [^18] “He is chastened also with pain on his bed,with continual strife in his bones, [^19] so that his life abhors bread,and his soul dainty food. [^20] His flesh is so consumed away that it can’t be seen.His bones that were not seen stick out. [^21] Yes, his soul draws near to the pit,and his life to the destroyers. [^22] “If there is beside him an angel,an interpreter, one among a thousand,to show to man what is right for him, [^23] then God is gracious to him, and says,‘Deliver him from going down to the pit,I have found a ransom.’ [^24] His flesh will be fresher than a child’s.He returns to the days of his youth. [^25] He prays to God, and he is favorable to him,so that he sees his face with joy.He restores to man his righteousness. [^26] He sings before men, and says,‘I have sinned, and perverted that which was right,and it didn’t profit me. [^27] He has redeemed my soul from going into the pit.My life will see the light.’ [^28] “Behold, God does all these things,twice, yes three times, with a man, [^29] to bring back his soul from the pit,that he may be enlightened with the light of the living. [^30] Mark well, Job, and listen to me.Hold your peace, and I will speak. [^31] If you have anything to say, answer me.Speak, for I desire to justify you. [^32] If not, listen to me.Hold your peace, and I will teach you wisdom.” [^33] 

[[Job - 32|<--]] Job - 33 [[Job - 34|-->]]

---
# Notes
