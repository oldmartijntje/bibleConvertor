---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 35 - World English Bible"
---
[[Job - 34|<--]] Job - 35 [[Job - 36|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 35

Moreover Elihu answered, [^1] “Do you think this to be your right,or do you say, ‘My righteousness is more than God’s,’ [^2] that you ask, ‘What advantage will it be to you?What profit will I have, more than if I had sinned?’ [^3] I will answer you,and your companions with you. [^4] Look to the skies, and see.See the skies, which are higher than you. [^5] If you have sinned, what effect do you have against him?If your transgressions are multiplied, what do you do to him? [^6] If you are righteous, what do you give him?Or what does he receive from your hand? [^7] Your wickedness may hurt a man as you are,and your righteousness may profit a son of man. [^8] “By reason of the multitude of oppressions they cry out.They cry for help by reason of the arm of the mighty. [^9] But no one says, ‘Where is God my Maker,who gives songs in the night, [^10] who teaches us more than the animals of the earth,and makes us wiser than the birds of the sky?’ [^11] There they cry, but no one answers,because of the pride of evil men. [^12] Surely God will not hear an empty cry,neither will the Almighty regard it. [^13] How much less when you say you don’t see him.The cause is before him, and you wait for him! [^14] But now, because he has not visited in his anger,neither does he greatly regard arrogance, [^15] therefore Job opens his mouth with empty talk,and he multiplies words without knowledge.” [^16] 

[[Job - 34|<--]] Job - 35 [[Job - 36|-->]]

---
# Notes
