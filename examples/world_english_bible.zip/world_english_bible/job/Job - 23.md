---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 23 - World English Bible"
---
[[Job - 22|<--]] Job - 23 [[Job - 24|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 23

Then Job answered, [^1] “Even today my complaint is rebellious.His hand is heavy in spite of my groaning. [^2] Oh that I knew where I might find him!That I might come even to his seat! [^3] I would set my cause in order before him,and fill my mouth with arguments. [^4] I would know the words which he would answer me,and understand what he would tell me. [^5] Would he contend with me in the greatness of his power?No, but he would listen to me. [^6] There the upright might reason with him,so I should be delivered forever from my judge. [^7] “If I go east, he is not there.If I go west, I can’t find him. [^8] He works to the north, but I can’t see him.He turns south, but I can’t catch a glimpse of him. [^9] But he knows the way that I take.When he has tried me, I will come out like gold. [^10] My foot has held fast to his steps.I have kept his way, and not turned away. [^11] I haven’t gone back from the commandment of his lips.I have treasured up the words of his mouth more than my necessary food. [^12] But he stands alone, and who can oppose him?What his soul desires, even that he does. [^13] For he performs that which is appointed for me.Many such things are with him. [^14] Therefore I am terrified at his presence.When I consider, I am afraid of him. [^15] For God has made my heart faint.The Almighty has terrified me. [^16] Because I was not cut off before the darkness,neither did he cover the thick darkness from my face. [^17] 

[[Job - 22|<--]] Job - 23 [[Job - 24|-->]]

---
# Notes
