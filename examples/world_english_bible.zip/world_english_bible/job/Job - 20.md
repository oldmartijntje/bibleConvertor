---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 20 - World English Bible"
---
[[Job - 19|<--]] Job - 20 [[Job - 21|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 20

Then Zophar the Naamathite answered, [^1] “Therefore my thoughts answer me,even by reason of my haste that is in me. [^2] I have heard the reproof which puts me to shame.The spirit of my understanding answers me. [^3] Don’t you know this from old time,since man was placed on earth, [^4] that the triumphing of the wicked is short,the joy of the godless but for a moment? [^5] Though his height mount up to the heavens,and his head reach to the clouds, [^6] yet he will perish forever like his own dung.Those who have seen him will say, ‘Where is he?’ [^7] He will fly away as a dream, and will not be found.Yes, he will be chased away like a vision of the night. [^8] The eye which saw him will see him no more,neither will his place see him any more. [^9] His children will seek the favor of the poor.His hands will give back his wealth. [^10] His bones are full of his youth,but youth will lie down with him in the dust. [^11] “Though wickedness is sweet in his mouth,though he hide it under his tongue, [^12] though he spare it, and will not let it go,but keep it still within his mouth, [^13] yet his food in his bowels is turned.It is cobra venom within him. [^14] He has swallowed down riches, and he will vomit them up again.God will cast them out of his belly. [^15] He will suck cobra venom.The viper’s tongue will kill him. [^16] He will not look at the rivers,the flowing streams of honey and butter. [^17] He will restore that for which he labored, and will not swallow it down.He will not rejoice according to the substance that he has gotten. [^18] For he has oppressed and forsaken the poor.He has violently taken away a house, and he will not build it up. [^19] “Because he knew no quietness within him,he will not save anything of that in which he delights. [^20] There was nothing left that he didn’t devour,therefore his prosperity will not endure. [^21] In the fullness of his sufficiency, distress will overtake him.The hand of everyone who is in misery will come on him. [^22] When he is about to fill his belly, God will cast the fierceness of his wrath on him.It will rain on him while he is eating. [^23] He will flee from the iron weapon.The bronze arrow will strike him through. [^24] He draws it out, and it comes out of his body.Yes, the glittering point comes out of his liver.Terrors are on him. [^25] All darkness is laid up for his treasures.An unfanned fire will devour him.It will consume that which is left in his tent. [^26] The heavens will reveal his iniquity.The earth will rise up against him. [^27] The increase of his house will depart.They will rush away in the day of his wrath. [^28] This is the portion of a wicked man from God,the heritage appointed to him by God.” [^29] 

[[Job - 19|<--]] Job - 20 [[Job - 21|-->]]

---
# Notes
