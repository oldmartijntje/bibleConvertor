---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 22 - World English Bible"
---
[[Job - 21|<--]] Job - 22 [[Job - 23|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 22

Then Eliphaz the Temanite answered, [^1] “Can a man be profitable to God?Surely he who is wise is profitable to himself. [^2] Is it any pleasure to the Almighty that you are righteous?Or does it benefit him that you make your ways perfect? [^3] Is it for your piety that he reproves you,that he enters with you into judgment? [^4] Isn’t your wickedness great?Neither is there any end to your iniquities. [^5] For you have taken pledges from your brother for nothing,and stripped the naked of their clothing. [^6] You haven’t given water to the weary to drink,and you have withheld bread from the hungry. [^7] But as for the mighty man, he had the earth.The honorable man, he lived in it. [^8] You have sent widows away empty,and the arms of the fatherless have been broken. [^9] Therefore snares are around you.Sudden fear troubles you, [^10] or darkness, so that you can not see,and floods of waters cover you. [^11] “Isn’t God in the heights of heaven?See the height of the stars, how high they are! [^12] You say, ‘What does God know?Can he judge through the thick darkness? [^13] Thick clouds are a covering to him, so that he doesn’t see.He walks on the vault of the sky.’ [^14] Will you keep the old way,which wicked men have trodden, [^15] who were snatched away before their time,whose foundation was poured out as a stream, [^16] who said to God, ‘Depart from us!’and, ‘What can the Almighty do for us?’ [^17] Yet he filled their houses with good things,but the counsel of the wicked is far from me. [^18] The righteous see it, and are glad.The innocent ridicule them, [^19] saying, ‘Surely those who rose up against us are cut off.The fire has consumed their remnant.’ [^20] “Acquaint yourself with him now, and be at peace.By it, good will come to you. [^21] Please receive instruction from his mouth,and lay up his words in your heart. [^22] If you return to the Almighty, you will be built up,if you put away unrighteousness far from your tents. [^23] Lay your treasure in the dust,the gold of Ophir among the stones of the brooks. [^24] The Almighty will be your treasure,and precious silver to you. [^25] For then you will delight yourself in the Almighty,and will lift up your face to God. [^26] You will make your prayer to him, and he will hear you.You will pay your vows. [^27] You will also decree a thing, and it will be established to you.Light will shine on your ways. [^28] When they cast down, you will say, ‘be lifted up.’He will save the humble person. [^29] He will even deliver him who is not innocent.Yes, he will be delivered through the cleanness of your hands.” [^30] 

[[Job - 21|<--]] Job - 22 [[Job - 23|-->]]

---
# Notes
