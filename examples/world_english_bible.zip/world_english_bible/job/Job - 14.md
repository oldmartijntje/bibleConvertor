---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 14 - World English Bible"
---
[[Job - 13|<--]] Job - 14 [[Job - 15|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 14

“Man, who is born of a woman,is of few days, and full of trouble. [^1] He grows up like a flower, and is cut down.He also flees like a shadow, and doesn’t continue. [^2] Do you open your eyes on such a one,and bring me into judgment with you? [^3] Who can bring a clean thing out of an unclean?Not one. [^4] Seeing his days are determined,the number of his months is with you,and you have appointed his bounds that he can’t pass. [^5] Look away from him, that he may rest,until he accomplishes, as a hireling, his day. [^6] “For there is hope for a tree if it is cut down,that it will sprout again,that the tender branch of it will not cease. [^7] Though its root grows old in the earth,and its stock dies in the ground, [^8] yet through the scent of water it will bud,and sprout boughs like a plant. [^9] But man dies, and is laid low.Yes, man gives up the spirit, and where is he? [^10] As the waters fail from the sea,and the river wastes and dries up, [^11] so man lies down and doesn’t rise.Until the heavens are no more, they will not awake,nor be roused out of their sleep. [^12] “Oh that you would hide me in Sheol,#14:13 Sheol is the place of the dead.that you would keep me secret until your wrath is past,that you would appoint me a set time and remember me! [^13] If a man dies, will he live again?I would wait all the days of my warfare,until my release should come. [^14] You would call, and I would answer you.You would have a desire for the work of your hands. [^15] But now you count my steps.Don’t you watch over my sin? [^16] My disobedience is sealed up in a bag.You fasten up my iniquity. [^17] “But the mountain falling comes to nothing.The rock is removed out of its place. [^18] The waters wear the stones.The torrents of it wash away the dust of the earth.So you destroy the hope of man. [^19] You forever prevail against him, and he departs.You change his face, and send him away. [^20] His sons come to honor, and he doesn’t know it.They are brought low, but he doesn’t perceive it of them. [^21] But his flesh on him has pain,and his soul within him mourns.” [^22] 

[[Job - 13|<--]] Job - 14 [[Job - 15|-->]]

---
# Notes
