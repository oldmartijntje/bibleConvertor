---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 28 - World English Bible"
---
[[Job - 27|<--]] Job - 28 [[Job - 29|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 28

“Surely there is a mine for silver,and a place for gold which they refine. [^1] Iron is taken out of the earth,and copper is smelted out of the ore. [^2] Man sets an end to darkness,and searches out, to the furthest bound,the stones of obscurity and of thick darkness. [^3] He breaks open a shaft away from where people live.They are forgotten by the foot.They hang far from men, they swing back and forth. [^4] As for the earth, out of it comes bread.Underneath it is turned up as it were by fire. [^5] Sapphires come from its rocks.It has dust of gold. [^6] That path no bird of prey knows,neither has the falcon’s eye seen it. [^7] The proud animals have not trodden it,nor has the fierce lion passed by there. [^8] He puts his hand on the flinty rock,and he overturns the mountains by the roots. [^9] He cuts out channels among the rocks.His eye sees every precious thing. [^10] He binds the streams that they don’t trickle.The thing that is hidden he brings out to light. [^11] “But where will wisdom be found?Where is the place of understanding? [^12] Man doesn’t know its price,and it isn’t found in the land of the living. [^13] The deep says, ‘It isn’t in me.’The sea says, ‘It isn’t with me.’ [^14] It can’t be gotten for gold,neither will silver be weighed for its price. [^15] It can’t be valued with the gold of Ophir,with the precious onyx, or the sapphire.#28:16 or, lapis lazuli [^16] Gold and glass can’t equal it,neither will it be exchanged for jewels of fine gold. [^17] No mention will be made of coral or of crystal.Yes, the price of wisdom is above rubies. [^18] The topaz of Ethiopia will not equal it.It won’t be valued with pure gold. [^19] Where then does wisdom come from?Where is the place of understanding? [^20] Seeing it is hidden from the eyes of all living,and kept close from the birds of the sky. [^21] Destruction and Death say,‘We have heard a rumor of it with our ears.’ [^22] “God understands its way,and he knows its place. [^23] For he looks to the ends of the earth,and sees under the whole sky. [^24] He establishes the force of the wind.Yes, he measures out the waters by measure. [^25] When he made a decree for the rain,and a way for the lightning of the thunder, [^26] then he saw it, and declared it.He established it, yes, and searched it out. [^27] To man he said,‘Behold, the fear of the Lord,#28:28 The word translated “Lord” is “Adonai.”  that is wisdom.To depart from evil is understanding.’” [^28] 

[[Job - 27|<--]] Job - 28 [[Job - 29|-->]]

---
# Notes
