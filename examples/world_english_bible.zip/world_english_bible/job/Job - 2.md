---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 2 - World English Bible"
---
[[Job - 1|<--]] Job - 2 [[Job - 3|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 2

Again, on the day when God’s sons came to present themselves before Yahweh, Satan came also among them to present himself before Yahweh. [^1] Yahweh said to Satan, “Where have you come from?”Satan answered Yahweh, and said, “From going back and forth in the earth, and from walking up and down in it.” [^2] Yahweh said to Satan, “Have you considered my servant Job? For there is no one like him in the earth, a blameless and an upright man, one who fears God, and turns away from evil. He still maintains his integrity, although you incited me against him, to ruin him without cause.” [^3] Satan answered Yahweh, and said, “Skin for skin. Yes, all that a man has he will give for his life. [^4] But stretch out your hand now, and touch his bone and his flesh, and he will renounce you to your face.” [^5] Yahweh said to Satan, “Behold, he is in your hand. Only spare his life.” [^6] So Satan went out from the presence of Yahweh, and struck Job with painful sores from the sole of his foot to his head. [^7] He took for himself a potsherd to scrape himself with, and he sat among the ashes. [^8] Then his wife said to him, “Do you still maintain your integrity? Renounce God, and die.” [^9] But he said to her, “You speak as one of the foolish women would speak. What? Shall we receive good at the hand of God, and shall we not receive evil?”In all this Job didn’t sin with his lips. [^10] Now when Job’s three friends heard of all this evil that had come on him, they each came from his own place: Eliphaz the Temanite, Bildad the Shuhite, and Zophar the Naamathite; and they made an appointment together to come to sympathize with him and to comfort him. [^11] When they lifted up their eyes from a distance, and didn’t recognize him, they raised their voices, and wept; and they each tore his robe, and sprinkled dust on their heads toward the sky. [^12] So they sat down with him on the ground seven days and seven nights, and no one spoke a word to him, for they saw that his grief was very great. [^13] 

[[Job - 1|<--]] Job - 2 [[Job - 3|-->]]

---
# Notes
