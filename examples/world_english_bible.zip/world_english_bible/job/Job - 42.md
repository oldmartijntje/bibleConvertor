---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 42 - World English Bible"
---
[[Job - 41|<--]] Job - 42

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 42

Then Job answered Yahweh: [^1] “I know that you can do all things,and that no purpose of yours can be restrained. [^2] You asked, ‘Who is this who hides counsel without knowledge?’therefore I have uttered that which I didn’t understand,things too wonderful for me, which I didn’t know. [^3] You said, ‘Listen, now, and I will speak;I will question you, and you will answer me.’ [^4] I had heard of you by the hearing of the ear,but now my eye sees you. [^5] Therefore I abhor myself,and repent in dust and ashes.” [^6] It was so, that after Yahweh had spoken these words to Job, Yahweh said to Eliphaz the Temanite, “My wrath is kindled against you, and against your two friends; for you have not spoken of me the thing that is right, as my servant Job has. [^7] Now therefore, take to yourselves seven bulls and seven rams, and go to my servant Job, and offer up for yourselves a burnt offering; and my servant Job shall pray for you, for I will accept him, that I not deal with you according to your folly. For you have not spoken of me the thing that is right, as my servant Job has.” [^8] So Eliphaz the Temanite and Bildad the Shuhite and Zophar the Naamathite went and did what Yahweh commanded them, and Yahweh accepted Job. [^9] Yahweh restored Job’s prosperity when he prayed for his friends. Yahweh gave Job twice as much as he had before. [^10] Then all his brothers, all his sisters, and all those who had been of his acquaintance before, came to him and ate bread with him in his house. They comforted him, and consoled him concerning all the evil that Yahweh had brought on him. Everyone also gave him a piece of money,#42:11 literally, kesitah, a unit of money, probably silver and everyone a ring of gold. [^11] So Yahweh blessed the latter end of Job more than his beginning. He had fourteen thousand sheep, six thousand camels, one thousand yoke of oxen, and a thousand female donkeys. [^12] He had also seven sons and three daughters. [^13] He called the name of the first, Jemimah; and the name of the second, Keziah; and the name of the third, Keren Happuch. [^14] In all the land were no women found so beautiful as the daughters of Job. Their father gave them an inheritance among their brothers. [^15] After this Job lived one hundred forty years, and saw his sons, and his sons’ sons, to four generations. [^16] So Job died, being old and full of days. [^17] 

[[Job - 41|<--]] Job - 42

---
# Notes
