---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 36 - World English Bible"
---
[[Job - 35|<--]] Job - 36 [[Job - 37|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 36

Elihu also continued, and said, [^1] “Bear with me a little, and I will show you;for I still have something to say on God’s behalf. [^2] I will get my knowledge from afar,and will ascribe righteousness to my Maker. [^3] For truly my words are not false.One who is perfect in knowledge is with you. [^4] “Behold, God is mighty, and doesn’t despise anyone.He is mighty in strength of understanding. [^5] He doesn’t preserve the life of the wicked,but gives justice to the afflicted. [^6] He doesn’t withdraw his eyes from the righteous,but with kings on the throne,he sets them forever, and they are exalted. [^7] If they are bound in fetters,and are taken in the cords of afflictions, [^8] then he shows them their work,and their transgressions, that they have behaved themselves proudly. [^9] He also opens their ears to instruction,and commands that they return from iniquity. [^10] If they listen and serve him,they will spend their days in prosperity,and their years in pleasures. [^11] But if they don’t listen, they will perish by the sword;they will die without knowledge. [^12] “But those who are godless in heart lay up anger.They don’t cry for help when he binds them. [^13] They die in youth.Their life perishes among the unclean. [^14] He delivers the afflicted by their affliction,and opens their ear in oppression. [^15] Yes, he would have allured you out of distress,into a wide place, where there is no restriction.That which is set on your table would be full of fatness. [^16] “But you are full of the judgment of the wicked.Judgment and justice take hold of you. [^17] Don’t let riches entice you to wrath,neither let the great size of a bribe turn you aside. [^18] Would your wealth sustain you in distress,or all the might of your strength? [^19] Don’t desire the night,when people are cut off in their place. [^20] Take heed, don’t regard iniquity;for you have chosen this rather than affliction. [^21] Behold, God is exalted in his power.Who is a teacher like him? [^22] Who has prescribed his way for him?Or who can say, ‘You have committed unrighteousness’? [^23] “Remember that you magnify his work,about which men have sung. [^24] All men have looked on it.Man sees it afar off. [^25] Behold, God is great, and we don’t know him.The number of his years is unsearchable. [^26] For he draws up the drops of water,which distill in rain from his vapor, [^27] which the skies pour downand which drop on man abundantly. [^28] Indeed, can anyone understand the spreading of the cloudsand the thunderings of his pavilion? [^29] Behold, he spreads his light around him.He covers the bottom of the sea. [^30] For by these he judges the people.He gives food in abundance. [^31] He covers his hands with the lightning,and commands it to strike the mark. [^32] Its noise tells about him,and the livestock also, concerning the storm that comes up. [^33] 

[[Job - 35|<--]] Job - 36 [[Job - 37|-->]]

---
# Notes
