---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 37 - World English Bible"
---
[[Job - 36|<--]] Job - 37 [[Job - 38|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 37

“Yes, at this my heart trembles,and is moved out of its place. [^1] Hear, oh, hear the noise of his voice,the sound that goes out of his mouth. [^2] He sends it out under the whole sky,and his lightning to the ends of the earth. [^3] After it a voice roars.He thunders with the voice of his majesty.He doesn’t hold back anything when his voice is heard. [^4] God thunders marvelously with his voice.He does great things, which we can’t comprehend. [^5] For he says to the snow, ‘Fall on the earth,’likewise to the shower of rain,and to the showers of his mighty rain. [^6] He seals up the hand of every man,that all men whom he has made may know it. [^7] Then the animals take cover,and remain in their dens. [^8] Out of its room comes the storm,and cold out of the north. [^9] By the breath of God, ice is given,and the width of the waters is frozen. [^10] Yes, he loads the thick cloud with moisture.He spreads abroad the cloud of his lightning. [^11] It is turned around by his guidance,that they may do whatever he commands themon the surface of the habitable world, [^12] whether it is for correction, or for his land,or for loving kindness, that he causes it to come. [^13] “Listen to this, Job.Stand still, and consider the wondrous works of God. [^14] Do you know how God controls them,and causes the lightning of his cloud to shine? [^15] Do you know the workings of the clouds,the wondrous works of him who is perfect in knowledge? [^16] You whose clothing is warmwhen the earth is still by reason of the south wind? [^17] Can you, with him, spread out the sky,which is strong as a cast metal mirror? [^18] Teach us what we will tell him,for we can’t make our case by reason of darkness. [^19] Will it be told him that I would speak?Or should a man wish that he were swallowed up? [^20] Now men don’t see the light which is bright in the skies,but the wind passes, and clears them. [^21] Out of the north comes golden splendor.With God is awesome majesty. [^22] We can’t reach the Almighty.He is exalted in power.In justice and great righteousness, he will not oppress. [^23] Therefore men revere him.He doesn’t regard any who are wise of heart.” [^24] 

[[Job - 36|<--]] Job - 37 [[Job - 38|-->]]

---
# Notes
