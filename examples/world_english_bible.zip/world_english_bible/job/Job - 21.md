---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 21 - World English Bible"
---
[[Job - 20|<--]] Job - 21 [[Job - 22|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 21

Then Job answered, [^1] “Listen diligently to my speech.Let this be your consolation. [^2] Allow me, and I also will speak.After I have spoken, mock on. [^3] As for me, is my complaint to man?Why shouldn’t I be impatient? [^4] Look at me, and be astonished.Lay your hand on your mouth. [^5] When I remember, I am troubled.Horror takes hold of my flesh. [^6] “Why do the wicked live,become old, yes, and grow mighty in power? [^7] Their child is established with them in their sight,their offspring before their eyes. [^8] Their houses are safe from fear,neither is the rod of God upon them. [^9] Their bulls breed without fail.Their cows calve, and don’t miscarry. [^10] They send out their little ones like a flock.Their children dance. [^11] They sing to the tambourine and harp,and rejoice at the sound of the pipe. [^12] They spend their days in prosperity.In an instant they go down to Sheol.#21:13 Sheol is the place of the dead. [^13] They tell God, ‘Depart from us,for we don’t want to know about your ways. [^14] What is the Almighty, that we should serve him?What profit should we have, if we pray to him?’ [^15] Behold, their prosperity is not in their hand.The counsel of the wicked is far from me. [^16] “How often is it that the lamp of the wicked is put out,that their calamity comes on them,that God distributes sorrows in his anger? [^17] How often is it that they are as stubble before the wind,as chaff that the storm carries away? [^18] You say, ‘God lays up his iniquity for his children.’Let him recompense it to himself, that he may know it. [^19] Let his own eyes see his destruction.Let him drink of the wrath of the Almighty. [^20] For what does he care for his house after him,when the number of his months is cut off? [^21] “Shall any teach God knowledge,since he judges those who are high? [^22] One dies in his full strength,being wholly at ease and quiet. [^23] His pails are full of milk.The marrow of his bones is moistened. [^24] Another dies in bitterness of soul,and never tastes of good. [^25] They lie down alike in the dust.The worm covers them. [^26] “Behold, I know your thoughts,the plans with which you would wrong me. [^27] For you say, ‘Where is the house of the prince?Where is the tent in which the wicked lived?’ [^28] Haven’t you asked wayfaring men?Don’t you know their evidences, [^29] that the evil man is reserved to the day of calamity,that they are led out to the day of wrath? [^30] Who will declare his way to his face?Who will repay him what he has done? [^31] Yet he will be borne to the grave.Men will keep watch over the tomb. [^32] The clods of the valley will be sweet to him.All men will draw after him,as there were innumerable before him. [^33] So how can you comfort me with nonsense,because in your answers there remains only falsehood?” [^34] 

[[Job - 20|<--]] Job - 21 [[Job - 22|-->]]

---
# Notes
