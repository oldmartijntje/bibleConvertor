---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 17 - World English Bible"
---
[[Job - 16|<--]] Job - 17 [[Job - 18|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 17

“My spirit is consumed.My days are extinctand the grave is ready for me. [^1] Surely there are mockers with me.My eye dwells on their provocation. [^2] “Now give a pledge. Be collateral for me with yourself.Who is there who will strike hands with me? [^3] For you have hidden their heart from understanding,therefore you will not exalt them. [^4] He who denounces his friends for plunder,even the eyes of his children will fail. [^5] “But he has made me a byword of the people.They spit in my face. [^6] My eye also is dim by reason of sorrow.All my members are as a shadow. [^7] Upright men will be astonished at this.The innocent will stir himself up against the godless. [^8] Yet the righteous will hold to his way.He who has clean hands will grow stronger and stronger. [^9] But as for you all, come back.I will not find a wise man among you. [^10] My days are past.My plans are broken off,as are the thoughts of my heart. [^11] They change the night into day,saying ‘The light is near’ in the presence of darkness. [^12] If I look for Sheol#17:13 Sheol is the place of the dead. as my house,if I have spread my couch in the darkness, [^13] if I have said to corruption, ‘You are my father,’and to the worm, ‘My mother,’ and ‘My sister,’ [^14] where then is my hope?As for my hope, who will see it? [^15] Shall it go down with me to the gates of Sheol,#17:16 Sheol is the place of the dead.or descend together into the dust?” [^16] 

[[Job - 16|<--]] Job - 17 [[Job - 18|-->]]

---
# Notes
