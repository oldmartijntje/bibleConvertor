---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 41 - World English Bible"
---
[[Job - 40|<--]] Job - 41 [[Job - 42|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 41

“Can you draw out Leviathan#41:1 Leviathan is a name for a crocodile or similar creature. with a fish hook,or press down his tongue with a cord? [^1] Can you put a rope into his nose,or pierce his jaw through with a hook? [^2] Will he make many petitions to you,or will he speak soft words to you? [^3] Will he make a covenant with you,that you should take him for a servant forever? [^4] Will you play with him as with a bird?Or will you bind him for your girls? [^5] Will traders barter for him?Will they part him among the merchants? [^6] Can you fill his skin with barbed irons,or his head with fish spears? [^7] Lay your hand on him.Remember the battle, and do so no more. [^8] Behold, the hope of him is in vain.Won’t one be cast down even at the sight of him? [^9] None is so fierce that he dare stir him up.Who then is he who can stand before me? [^10] Who has first given to me, that I should repay him?Everything under the heavens is mine. [^11] “I will not keep silence concerning his limbs,nor his mighty strength, nor his goodly frame. [^12] Who can strip off his outer garment?Who will come within his jaws? [^13] Who can open the doors of his face?Around his teeth is terror. [^14] Strong scales are his pride,shut up together with a close seal. [^15] One is so near to another,that no air can come between them. [^16] They are joined to one another.They stick together, so that they can’t be pulled apart. [^17] His sneezing flashes out light.His eyes are like the eyelids of the morning. [^18] Out of his mouth go burning torches.Sparks of fire leap out. [^19] Out of his nostrils a smoke goes,as of a boiling pot over a fire of reeds. [^20] His breath kindles coals.A flame goes out of his mouth. [^21] There is strength in his neck.Terror dances before him. [^22] The flakes of his flesh are joined together.They are firm on him.They can’t be moved. [^23] His heart is as firm as a stone,yes, firm as the lower millstone. [^24] When he raises himself up, the mighty are afraid.They retreat before his thrashing. [^25] If one attacks him with the sword, it can’t prevail;nor the spear, the dart, nor the pointed shaft. [^26] He counts iron as straw,and bronze as rotten wood. [^27] The arrow can’t make him flee.Sling stones are like chaff to him. [^28] Clubs are counted as stubble.He laughs at the rushing of the javelin. [^29] His undersides are like sharp potsherds,leaving a trail in the mud like a threshing sledge. [^30] He makes the deep to boil like a pot.He makes the sea like a pot of ointment. [^31] He makes a path shine after him.One would think the deep had white hair. [^32] On earth there is not his equal,that is made without fear. [^33] He sees everything that is high.He is king over all the sons of pride.” [^34] 

[[Job - 40|<--]] Job - 41 [[Job - 42|-->]]

---
# Notes
