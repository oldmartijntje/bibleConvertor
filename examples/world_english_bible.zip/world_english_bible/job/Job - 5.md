---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 5 - World English Bible"
---
[[Job - 4|<--]] Job - 5 [[Job - 6|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 5

“Call now; is there any who will answer you?To which of the holy ones will you turn? [^1] For resentment kills the foolish man,and jealousy kills the simple. [^2] I have seen the foolish taking root,but suddenly I cursed his habitation. [^3] His children are far from safety.They are crushed in the gate.Neither is there any to deliver them, [^4] whose harvest the hungry eat up,and take it even out of the thorns.The snare gapes for their substance. [^5] For affliction doesn’t come out of the dust,neither does trouble spring out of the ground; [^6] but man is born to trouble,as the sparks fly upward. [^7] “But as for me, I would seek God.I would commit my cause to God, [^8] who does great things that can’t be fathomed,marvelous things without number; [^9] who gives rain on the earth,and sends waters on the fields; [^10] so that he sets up on high those who are low,those who mourn are exalted to safety. [^11] He frustrates the plans of the crafty,so that their hands can’t perform their enterprise. [^12] He takes the wise in their own craftiness;the counsel of the cunning is carried headlong. [^13] They meet with darkness in the day time,and grope at noonday as in the night. [^14] But he saves from the sword of their mouth,even the needy from the hand of the mighty. [^15] So the poor has hope,and injustice shuts her mouth. [^16] “Behold, happy is the man whom God corrects.Therefore do not despise the chastening of the Almighty. [^17] For he wounds and binds up.He injures and his hands make whole. [^18] He will deliver you in six troubles;yes, in seven no evil will touch you. [^19] In famine he will redeem you from death;in war, from the power of the sword. [^20] You will be hidden from the scourge of the tongue,neither will you be afraid of destruction when it comes. [^21] You will laugh at destruction and famine,neither will you be afraid of the animals of the earth. [^22] For you will be allied with the stones of the field.The animals of the field will be at peace with you. [^23] You will know that your tent is in peace.You will visit your fold, and will miss nothing. [^24] You will know also that your offspring#5:25 or, seed will be great,your offspring as the grass of the earth. [^25] You will come to your grave in a full age,like a shock of grain comes in its season. [^26] Behold, we have researched it. It is so.Hear it, and know it for your good.” [^27] 

[[Job - 4|<--]] Job - 5 [[Job - 6|-->]]

---
# Notes
