---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 30 - World English Bible"
---
[[Job - 29|<--]] Job - 30 [[Job - 31|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 30

“But now those who are younger than I have me in derision,whose fathers I considered unworthy to put with my sheep dogs. [^1] Of what use is the strength of their hands to me,men in whom ripe age has perished? [^2] They are gaunt from lack and famine.They gnaw the dry ground, in the gloom of waste and desolation. [^3] They pluck salt herbs by the bushes.The roots of the broom tree are their food. [^4] They are driven out from among men.They cry after them as after a thief, [^5] so that they live in frightful valleys,and in holes of the earth and of the rocks. [^6] They bray among the bushes.They are gathered together under the nettles. [^7] They are children of fools, yes, children of wicked men.They were flogged out of the land. [^8] “Now I have become their song.Yes, I am a byword to them. [^9] They abhor me, they stand aloof from me,and don’t hesitate to spit in my face. [^10] For he has untied his cord, and afflicted me;and they have thrown off restraint before me. [^11] On my right hand rise the rabble.They thrust aside my feet.They cast their ways of destruction up against me. [^12] They mar my path.They promote my destructionwithout anyone’s help. [^13] As through a wide breach they come.They roll themselves in amid the ruin. [^14] Terrors have turned on me.They chase my honor as the wind.My welfare has passed away as a cloud. [^15] “Now my soul is poured out within me.Days of affliction have taken hold of me. [^16] In the night season my bones are pierced in me,and the pains that gnaw me take no rest. [^17] My garment is disfigured by great force.It binds me about as the collar of my tunic. [^18] He has cast me into the mire.I have become like dust and ashes. [^19] I cry to you, and you do not answer me.I stand up, and you gaze at me. [^20] You have turned to be cruel to me.With the might of your hand you persecute me. [^21] You lift me up to the wind, and drive me with it.You dissolve me in the storm. [^22] For I know that you will bring me to death,to the house appointed for all living. [^23] “However doesn’t one stretch out a hand in his fall?Or in his calamity therefore cry for help? [^24] Didn’t I weep for him who was in trouble?Wasn’t my soul grieved for the needy? [^25] When I looked for good, then evil came.When I waited for light, darkness came. [^26] My heart is troubled, and doesn’t rest.Days of affliction have come on me. [^27] I go mourning without the sun.I stand up in the assembly, and cry for help. [^28] I am a brother to jackals,and a companion to ostriches. [^29] My skin grows black and peels from me.My bones are burned with heat. [^30] Therefore my harp has turned to mourning,and my pipe into the voice of those who weep. [^31] 

[[Job - 29|<--]] Job - 30 [[Job - 31|-->]]

---
# Notes
