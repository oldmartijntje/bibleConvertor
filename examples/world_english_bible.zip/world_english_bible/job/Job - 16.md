---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 16 - World English Bible"
---
[[Job - 15|<--]] Job - 16 [[Job - 17|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 16

Then Job answered, [^1] “I have heard many such things.You are all miserable comforters! [^2] Shall vain words have an end?Or what provokes you that you answer? [^3] I also could speak as you do.If your soul were in my soul’s place,I could join words together against you,and shake my head at you, [^4] but I would strengthen you with my mouth.The solace of my lips would relieve you. [^5] “Though I speak, my grief is not subsided.Though I forbear, what am I eased? [^6] But now, God, you have surely worn me out.You have made all my company desolate. [^7] You have shriveled me up. This is a witness against me.My leanness rises up against me.It testifies to my face. [^8] He has torn me in his wrath and persecuted me.He has gnashed on me with his teeth.My adversary sharpens his eyes on me. [^9] They have gaped on me with their mouth.They have struck me on the cheek reproachfully.They gather themselves together against me. [^10] God delivers me to the ungodly,and casts me into the hands of the wicked. [^11] I was at ease, and he broke me apart.Yes, he has taken me by the neck, and dashed me to pieces.He has also set me up for his target. [^12] His archers surround me.He splits my kidneys apart, and does not spare.He pours out my bile on the ground. [^13] He breaks me with breach on breach.He runs at me like a giant. [^14] I have sewed sackcloth on my skin,and have thrust my horn in the dust. [^15] My face is red with weeping.Deep darkness is on my eyelids, [^16] although there is no violence in my hands,and my prayer is pure. [^17] “Earth, don’t cover my blood.Let my cry have no place to rest. [^18] Even now, behold, my witness is in heaven.He who vouches for me is on high. [^19] My friends scoff at me.My eyes pour out tears to God, [^20] that he would maintain the right of a man with God,of a son of man with his neighbor! [^21] For when a few years have come,I will go the way of no return. [^22] 

[[Job - 15|<--]] Job - 16 [[Job - 17|-->]]

---
# Notes
