---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 9 - World English Bible"
---
[[Job - 8|<--]] Job - 9 [[Job - 10|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 9

Then Job answered, [^1] “Truly I know that it is so,but how can man be just with God? [^2] If he is pleased to contend with him,he can’t answer him one time in a thousand. [^3] God is wise in heart, and mighty in strength.Who has hardened himself against him and prospered? [^4] He removes the mountains, and they don’t know it,when he overturns them in his anger. [^5] He shakes the earth out of its place.Its pillars tremble. [^6] He commands the sun and it doesn’t rise,and seals up the stars. [^7] He alone stretches out the heavens,and treads on the waves of the sea. [^8] He makes the Bear, Orion, and the Pleiades,and the rooms of the south. [^9] He does great things past finding out;yes, marvelous things without number. [^10] Behold, he goes by me, and I don’t see him.He passes on also, but I don’t perceive him. [^11] Behold, he snatches away.Who can hinder him?Who will ask him, ‘What are you doing?’ [^12] “God will not withdraw his anger.The helpers of Rahab stoop under him. [^13] How much less will I answer him,and choose my words to argue with him? [^14] Though I were righteous, yet I wouldn’t answer him.I would make supplication to my judge. [^15] If I had called, and he had answered me,yet I wouldn’t believe that he listened to my voice. [^16] For he breaks me with a storm,and multiplies my wounds without cause. [^17] He will not allow me to catch my breath,but fills me with bitterness. [^18] If it is a matter of strength, behold, he is mighty!If of justice, ‘Who,’ says he, ‘will summon me?’ [^19] Though I am righteous, my own mouth will condemn me.Though I am blameless, it will prove me perverse. [^20] I am blameless.I don’t respect myself.I despise my life. [^21] “It is all the same.Therefore I say he destroys the blameless and the wicked. [^22] If the scourge kills suddenly,he will mock at the trial of the innocent. [^23] The earth is given into the hand of the wicked.He covers the faces of its judges.If not he, then who is it? [^24] “Now my days are swifter than a runner.They flee away. They see no good. [^25] They have passed away as the swift ships,as the eagle that swoops on the prey. [^26] If I say, ‘I will forget my complaint,I will put off my sad face, and cheer up,’ [^27] I am afraid of all my sorrows.I know that you will not hold me innocent. [^28] I will be condemned.Why then do I labor in vain? [^29] If I wash myself with snow,and cleanse my hands with lye, [^30] yet you will plunge me in the ditch.My own clothes will abhor me. [^31] For he is not a man, as I am, that I should answer him,that we should come together in judgment. [^32] There is no umpire between us,that might lay his hand on us both. [^33] Let him take his rod away from me.Let his terror not make me afraid; [^34] then I would speak, and not fear him,for I am not so in myself. [^35] 

[[Job - 8|<--]] Job - 9 [[Job - 10|-->]]

---
# Notes
