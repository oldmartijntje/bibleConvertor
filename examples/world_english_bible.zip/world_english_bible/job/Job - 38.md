---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 38 - World English Bible"
---
[[Job - 37|<--]] Job - 38 [[Job - 39|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 38

Then Yahweh answered Job out of the whirlwind, [^1] “Who is this who darkens counselby words without knowledge? [^2] Brace yourself like a man,for I will question you, then you answer me! [^3] “Where were you when I laid the foundations of the earth?Declare, if you have understanding. [^4] Who determined its measures, if you know?Or who stretched the line on it? [^5] What were its foundations fastened on?Or who laid its cornerstone, [^6] when the morning stars sang together,and all the sons of God shouted for joy? [^7] “Or who shut up the sea with doors,when it broke out of the womb, [^8] when I made clouds its garment,and wrapped it in thick darkness, [^9] marked out for it my bound,set bars and doors, [^10] and said, ‘You may come here, but no further.Your proud waves shall be stopped here’? [^11] “Have you commanded the morning in your days,and caused the dawn to know its place, [^12] that it might take hold of the ends of the earth,and shake the wicked out of it? [^13] It is changed as clay under the seal,and presented as a garment. [^14] From the wicked, their light is withheld.The high arm is broken. [^15] “Have you entered into the springs of the sea?Or have you walked in the recesses of the deep? [^16] Have the gates of death been revealed to you?Or have you seen the gates of the shadow of death? [^17] Have you comprehended the earth in its width?Declare, if you know it all. [^18] “What is the way to the dwelling of light?As for darkness, where is its place, [^19] that you should take it to its bound,that you should discern the paths to its house? [^20] Surely you know, for you were born then,and the number of your days is great! [^21] Have you entered the storehouses of the snow,or have you seen the storehouses of the hail, [^22] which I have reserved against the time of trouble,against the day of battle and war? [^23] By what way is the lightning distributed,or the east wind scattered on the earth? [^24] Who has cut a channel for the flood water,or the path for the thunderstorm, [^25] to cause it to rain on a land where there is no man,on the wilderness, in which there is no man, [^26] to satisfy the waste and desolate ground,to cause the tender grass to grow? [^27] Does the rain have a father?Or who fathers the drops of dew? [^28] Whose womb did the ice come out of?Who has given birth to the gray frost of the sky? [^29] The waters become hard like stone,when the surface of the deep is frozen. [^30] “Can you bind the cluster of the Pleiades,or loosen the cords of Orion? [^31] Can you lead the constellations out in their season?Or can you guide the Bear with her cubs? [^32] Do you know the laws of the heavens?Can you establish its dominion over the earth? [^33] “Can you lift up your voice to the clouds,that abundance of waters may cover you? [^34] Can you send out lightnings, that they may go?Do they report to you, ‘Here we are’? [^35] Who has put wisdom in the inward parts?Or who has given understanding to the mind? [^36] Who can count the clouds by wisdom?Or who can pour out the containers of the sky, [^37] when the dust runs into a mass,and the clods of earth stick together? [^38] “Can you hunt the prey for the lioness,or satisfy the appetite of the young lions, [^39] when they crouch in their dens,and lie in wait in the thicket? [^40] Who provides for the raven his prey,when his young ones cry to God,and wander for lack of food? [^41] 

[[Job - 37|<--]] Job - 38 [[Job - 39|-->]]

---
# Notes
