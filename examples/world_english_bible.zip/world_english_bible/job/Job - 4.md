---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 4 - World English Bible"
---
[[Job - 3|<--]] Job - 4 [[Job - 5|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 4

Then Eliphaz the Temanite answered, [^1] “If someone ventures to talk with you, will you be grieved?But who can withhold himself from speaking? [^2] Behold, you have instructed many,you have strengthened the weak hands. [^3] Your words have supported him who was falling,you have made the feeble knees firm. [^4] But now it has come to you, and you faint.It touches you, and you are troubled. [^5] Isn’t your piety your confidence?Isn’t the integrity of your ways your hope? [^6] “Remember, now, who ever perished, being innocent?Or where were the upright cut off? [^7] According to what I have seen, those who plow iniquityand sow trouble, reap the same. [^8] By the breath of God they perish.By the blast of his anger are they consumed. [^9] The roaring of the lion,and the voice of the fierce lion,the teeth of the young lions, are broken. [^10] The old lion perishes for lack of prey.The cubs of the lioness are scattered abroad. [^11] “Now a thing was secretly brought to me.My ear received a whisper of it. [^12] In thoughts from the visions of the night,when deep sleep falls on men, [^13] fear came on me, and trembling,which made all my bones shake. [^14] Then a spirit passed before my face.The hair of my flesh stood up. [^15] It stood still, but I couldn’t discern its appearance.A form was before my eyes.Silence, then I heard a voice, saying, [^16] ‘Shall mortal man be more just than God?Shall a man be more pure than his Maker? [^17] Behold, he puts no trust in his servants.He charges his angels with error. [^18] How much more those who dwell in houses of clay,whose foundation is in the dust,who are crushed before the moth! [^19] Between morning and evening they are destroyed.They perish forever without any regarding it. [^20] Isn’t their tent cord plucked up within them?They die, and that without wisdom.’ [^21] 

[[Job - 3|<--]] Job - 4 [[Job - 5|-->]]

---
# Notes
