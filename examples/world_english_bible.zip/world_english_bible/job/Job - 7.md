---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 7 - World English Bible"
---
[[Job - 6|<--]] Job - 7 [[Job - 8|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 7

“Isn’t a man forced to labor on earth?Aren’t his days like the days of a hired hand? [^1] As a servant who earnestly desires the shadow,as a hireling who looks for his wages, [^2] so I am made to possess months of misery,wearisome nights are appointed to me. [^3] When I lie down, I say,‘When will I arise, and the night be gone?’I toss and turn until the dawning of the day. [^4] My flesh is clothed with worms and clods of dust.My skin closes up, and breaks out afresh. [^5] My days are swifter than a weaver’s shuttle,and are spent without hope. [^6] Oh remember that my life is a breath.My eye will no more see good. [^7] The eye of him who sees me will see me no more.Your eyes will be on me, but I will not be. [^8] As the cloud is consumed and vanishes away,so he who goes down to Sheol#7:9 Sheol is the place of the dead. will come up no more. [^9] He will return no more to his house,neither will his place know him any more. [^10] “Therefore I will not keep silent.I will speak in the anguish of my spirit.I will complain in the bitterness of my soul. [^11] Am I a sea, or a sea monster,that you put a guard over me? [^12] When I say, ‘My bed will comfort me.My couch will ease my complaint,’ [^13] then you scare me with dreamsand terrify me through visions, [^14] so that my soul chooses strangling,death rather than my bones. [^15] I loathe my life.I don’t want to live forever.Leave me alone, for my days are but a breath. [^16] What is man, that you should magnify him,that you should set your mind on him, [^17] that you should visit him every morning,and test him every moment? [^18] How long will you not look away from me,nor leave me alone until I swallow down my spittle? [^19] If I have sinned, what do I do to you, you watcher of men?Why have you set me as a mark for you,so that I am a burden to myself? [^20] Why do you not pardon my disobedience, and take away my iniquity?For now will I lie down in the dust.You will seek me diligently, but I will not be.” [^21] 

[[Job - 6|<--]] Job - 7 [[Job - 8|-->]]

---
# Notes
