---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 11 - World English Bible"
---
[[Job - 10|<--]] Job - 11 [[Job - 12|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 11

Then Zophar, the Naamathite, answered, [^1] “Shouldn’t the multitude of words be answered?Should a man full of talk be justified? [^2] Should your boastings make men hold their peace?When you mock, will no man make you ashamed? [^3] For you say, ‘My doctrine is pure.I am clean in your eyes.’ [^4] But oh that God would speak,and open his lips against you, [^5] that he would show you the secrets of wisdom!For true wisdom has two sides.Know therefore that God exacts of you less than your iniquity deserves. [^6] “Can you fathom the mystery of God?Or can you probe the limits of the Almighty? [^7] They are high as heaven. What can you do?They are deeper than Sheol.#11:8 Sheol is the place of the dead. What can you know? [^8] Its measure is longer than the earth,and broader than the sea. [^9] If he passes by, or confines,or convenes a court, then who can oppose him? [^10] For he knows false men.He sees iniquity also, even though he doesn’t consider it. [^11] An empty-headed man becomes wisewhen a man is born as a wild donkey’s colt. [^12] “If you set your heart aright,stretch out your hands toward him. [^13] If iniquity is in your hand, put it far away.Don’t let unrighteousness dwell in your tents. [^14] Surely then you will lift up your face without spot.Yes, you will be steadfast, and will not fear, [^15] for you will forget your misery.You will remember it like waters that have passed away. [^16] Life will be clearer than the noonday.Though there is darkness, it will be as the morning. [^17] You will be secure, because there is hope.Yes, you will search, and will take your rest in safety. [^18] Also you will lie down, and no one will make you afraid.Yes, many will court your favor. [^19] But the eyes of the wicked will fail.They will have no way to flee.Their hope will be the giving up of the spirit.” [^20] 

[[Job - 10|<--]] Job - 11 [[Job - 12|-->]]

---
# Notes
