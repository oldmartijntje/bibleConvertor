---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 32 - World English Bible"
---
[[Job - 31|<--]] Job - 32 [[Job - 33|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 32

So these three men ceased to answer Job, because he was righteous in his own eyes. [^1] Then the wrath of Elihu the son of Barachel, the Buzite, of the family of Ram, was kindled against Job. His wrath was kindled because he justified himself rather than God. [^2] Also his wrath was kindled against his three friends, because they had found no answer, and yet had condemned Job. [^3] Now Elihu had waited to speak to Job, because they were older than he. [^4] When Elihu saw that there was no answer in the mouth of these three men, his wrath was kindled. [^5] Elihu the son of Barachel the Buzite answered,“I am young, and you are very old.Therefore I held back, and didn’t dare show you my opinion. [^6] I said, ‘Days should speak,and multitude of years should teach wisdom.’ [^7] But there is a spirit in man,and the Spirit#32:8 or, breath of the Almighty gives them understanding. [^8] It is not the great who are wise,nor the aged who understand justice. [^9] Therefore I said, ‘Listen to me;I also will show my opinion.’ [^10] “Behold, I waited for your words,and I listened for your reasoning,while you searched out what to say. [^11] Yes, I gave you my full attention,but there was no one who convinced Job,or who answered his words, among you. [^12] Beware lest you say, ‘We have found wisdom.God may refute him, not man;’ [^13] for he has not directed his words against me;neither will I answer him with your speeches. [^14] “They are amazed. They answer no more.They don’t have a word to say. [^15] Shall I wait, because they don’t speak,because they stand still, and answer no more? [^16] I also will answer my part,and I also will show my opinion. [^17] For I am full of words.The spirit within me constrains me. [^18] Behold, my breast is as wine which has no vent;like new wineskins it is ready to burst. [^19] I will speak, that I may be refreshed.I will open my lips and answer. [^20] Please don’t let me respect any man’s person,neither will I give flattering titles to any man. [^21] For I don’t know how to give flattering titles,or else my Maker would soon take me away. [^22] 

[[Job - 31|<--]] Job - 32 [[Job - 33|-->]]

---
# Notes
