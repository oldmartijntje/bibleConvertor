---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 6 - World English Bible"
---
[[Job - 5|<--]] Job - 6 [[Job - 7|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 6

Then Job answered, [^1] “Oh that my anguish were weighed,and all my calamity laid in the balances! [^2] For now it would be heavier than the sand of the seas,therefore my words have been rash. [^3] For the arrows of the Almighty are within me.My spirit drinks up their poison.The terrors of God set themselves in array against me. [^4] Does the wild donkey bray when he has grass?Or does the ox low over his fodder? [^5] Can that which has no flavor be eaten without salt?Or is there any taste in the white of an egg? [^6] My soul refuses to touch them.They are as loathsome food to me. [^7] “Oh that I might have my request,that God would grant the thing that I long for, [^8] even that it would please God to crush me;that he would let loose his hand, and cut me off! [^9] Let it still be my consolation,yes, let me exult in pain that doesn’t spare,that I have not denied the words of the Holy One. [^10] What is my strength, that I should wait?What is my end, that I should be patient? [^11] Is my strength the strength of stones?Or is my flesh of bronze? [^12] Isn’t it that I have no help in me,that wisdom is driven away from me? [^13] “To him who is ready to faint, kindness should be shown from his friend;even to him who forsakes the fear of the Almighty. [^14] My brothers have dealt deceitfully as a brook,as the channel of brooks that pass away; [^15] which are black by reason of the ice,in which the snow hides itself. [^16] In the dry season, they vanish.When it is hot, they are consumed out of their place. [^17] The caravans that travel beside them turn away.They go up into the waste, and perish. [^18] The caravans of Tema looked.The companies of Sheba waited for them. [^19] They were distressed because they were confident.They came there, and were confounded. [^20] For now you are nothing.You see a terror, and are afraid. [^21] Did I ever say, ‘Give to me’?or, ‘Offer a present for me from your substance’? [^22] or, ‘Deliver me from the adversary’s hand’?or, ‘Redeem me from the hand of the oppressors’? [^23] “Teach me, and I will hold my peace.Cause me to understand my error. [^24] How forcible are words of uprightness!But your reproof, what does it reprove? [^25] Do you intend to reprove words,since the speeches of one who is desperate are as wind? [^26] Yes, you would even cast lots for the fatherless,and make merchandise of your friend. [^27] Now therefore be pleased to look at me,for surely I will not lie to your face. [^28] Please return.Let there be no injustice.Yes, return again.My cause is righteous. [^29] Is there injustice on my tongue?Can’t my taste discern mischievous things? [^30] 

[[Job - 5|<--]] Job - 6 [[Job - 7|-->]]

---
# Notes
