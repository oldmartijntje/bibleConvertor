---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 40 - World English Bible"
---
[[Job - 39|<--]] Job - 40 [[Job - 41|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 40

Moreover Yahweh answered Job, [^1] “Shall he who argues contend with the Almighty?He who argues with God, let him answer it.” [^2] Then Job answered Yahweh, [^3] “Behold, I am of small account. What will I answer you?I lay my hand on my mouth. [^4] I have spoken once, and I will not answer;Yes, twice, but I will proceed no further.” [^5] Then Yahweh answered Job out of the whirlwind: [^6] “Now brace yourself like a man.I will question you, and you will answer me. [^7] Will you even annul my judgment?Will you condemn me, that you may be justified? [^8] Or do you have an arm like God?Can you thunder with a voice like him? [^9] “Now deck yourself with excellency and dignity.Array yourself with honor and majesty. [^10] Pour out the fury of your anger.Look at everyone who is proud, and bring him low. [^11] Look at everyone who is proud, and humble him.Crush the wicked in their place. [^12] Hide them in the dust together.Bind their faces in the hidden place. [^13] Then I will also admit to youthat your own right hand can save you. [^14] “See now behemoth, which I made as well as you.He eats grass as an ox. [^15] Look now, his strength is in his thighs.His force is in the muscles of his belly. [^16] He moves his tail like a cedar.The sinews of his thighs are knit together. [^17] His bones are like tubes of bronze.His limbs are like bars of iron. [^18] He is the chief of the ways of God.He who made him gives him his sword. [^19] Surely the mountains produce food for him,where all the animals of the field play. [^20] He lies under the lotus trees,in the covert of the reed, and the marsh. [^21] The lotuses cover him with their shade.The willows of the brook surround him. [^22] Behold, if a river overflows, he doesn’t tremble.He is confident, though the Jordan swells even to his mouth. [^23] Shall any take him when he is on the watch,or pierce through his nose with a snare? [^24] 

[[Job - 39|<--]] Job - 40 [[Job - 41|-->]]

---
# Notes
