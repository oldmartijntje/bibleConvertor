---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 1 - World English Bible"
---
Job - 1 [[Job - 2|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 1

There was a man in the land of Uz, whose name was Job. That man was blameless and upright, and one who feared God,#1:1 The Hebrew word rendered “God” is “אֱלֹהִ֑ים” (Elohim). and turned away from evil. [^1] There were born to him seven sons and three daughters. [^2] His possessions also were seven thousand sheep, three thousand camels, five hundred yoke of oxen, five hundred female donkeys, and a very great household; so that this man was the greatest of all the children of the east. [^3] His sons went and held a feast in the house of each one on his birthday; and they sent and called for their three sisters to eat and to drink with them. [^4] It was so, when the days of their feasting had run their course, that Job sent and sanctified them, and rose up early in the morning, and offered burnt offerings according to the number of them all. For Job said, “It may be that my sons have sinned, and renounced God in their hearts.” Job did so continually. [^5] Now on the day when God’s sons came to present themselves before Yahweh,#1:6 “Yahweh” is God’s proper Name, sometimes rendered “Lord” (all caps) in other translations. Satan also came among them. [^6] Yahweh said to Satan, “Where have you come from?”Then Satan answered Yahweh, and said, “From going back and forth in the earth, and from walking up and down in it.” [^7] Yahweh said to Satan, “Have you considered my servant, Job? For there is no one like him in the earth, a blameless and an upright man, one who fears God, and turns away from evil.” [^8] Then Satan answered Yahweh, and said, “Does Job fear God for nothing? [^9] Haven’t you made a hedge around him, and around his house, and around all that he has, on every side? You have blessed the work of his hands, and his substance is increased in the land. [^10] But stretch out your hand now, and touch all that he has, and he will renounce you to your face.” [^11] Yahweh said to Satan, “Behold,#1:12 “Behold”, from “הִנֵּה”, means look at, take notice, observe, see, or gaze at. It is often used as an interjection. all that he has is in your power. Only on himself don’t stretch out your hand.”So Satan went out from the presence of Yahweh. [^12] It fell on a day when his sons and his daughters were eating and drinking wine in their oldest brother’s house, [^13] that a messenger came to Job, and said, “The oxen were plowing, and the donkeys feeding beside them, [^14] and the Sabeans attacked, and took them away. Yes, they have killed the servants with the edge of the sword, and I alone have escaped to tell you.” [^15] While he was still speaking, another also came and said, “The fire of God has fallen from the sky, and has burned up the sheep and the servants, and consumed them, and I alone have escaped to tell you.” [^16] While he was still speaking, another also came and said, “The Chaldeans made three bands, and swept down on the camels, and have taken them away, yes, and killed the servants with the edge of the sword; and I alone have escaped to tell you.” [^17] While he was still speaking, there came also another, and said, “Your sons and your daughters were eating and drinking wine in their oldest brother’s house, [^18] and behold, there came a great wind from the wilderness, and struck the four corners of the house, and it fell on the young men, and they are dead. I alone have escaped to tell you.” [^19] Then Job arose, and tore his robe, and shaved his head, and fell down on the ground, and worshiped. [^20] He said, “Naked I came out of my mother’s womb, and naked will I return there. Yahweh gave, and Yahweh has taken away. Blessed be Yahweh’s name.” [^21] In all this, Job didn’t sin, nor charge God with wrongdoing. [^22] 

Job - 1 [[Job - 2|-->]]

---
# Notes
