---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 10 - World English Bible"
---
[[Job - 9|<--]] Job - 10 [[Job - 11|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Job]]

# Job - 10

“My soul is weary of my life.I will give free course to my complaint.I will speak in the bitterness of my soul. [^1] I will tell God, ‘Do not condemn me.Show me why you contend with me. [^2] Is it good to you that you should oppress,that you should despise the work of your hands,and smile on the counsel of the wicked? [^3] Do you have eyes of flesh?Or do you see as man sees? [^4] Are your days as the days of mortals,or your years as man’s years, [^5] that you inquire after my iniquity,and search after my sin? [^6] Although you know that I am not wicked,there is no one who can deliver out of your hand. [^7] “‘Your hands have framed me and fashioned me altogether,yet you destroy me. [^8] Remember, I beg you, that you have fashioned me as clay.Will you bring me into dust again? [^9] Haven’t you poured me out like milk,and curdled me like cheese? [^10] You have clothed me with skin and flesh,and knit me together with bones and sinews. [^11] You have granted me life and loving kindness.Your visitation has preserved my spirit. [^12] Yet you hid these things in your heart.I know that this is with you: [^13] if I sin, then you mark me.You will not acquit me from my iniquity. [^14] If I am wicked, woe to me.If I am righteous, I still will not lift up my head,being filled with disgrace,and conscious of my affliction. [^15] If my head is held high, you hunt me like a lion.Again you show yourself powerful to me. [^16] You renew your witnesses against me,and increase your indignation on me.Changes and warfare are with me. [^17] “‘Why, then, have you brought me out of the womb?I wish I had given up the spirit, and no eye had seen me. [^18] I should have been as though I had not been.I should have been carried from the womb to the grave. [^19] Aren’t my days few?Stop!Leave me alone, that I may find a little comfort, [^20] before I go where I will not return from,to the land of darkness and of the shadow of death; [^21] the land dark as midnight,of the shadow of death,without any order,where the light is as midnight.’” [^22] 

[[Job - 9|<--]] Job - 10 [[Job - 11|-->]]

---
# Notes
