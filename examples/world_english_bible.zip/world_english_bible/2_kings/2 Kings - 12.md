---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 12 - World English Bible"
---
[[2 Kings - 11|<--]] 2 Kings - 12 [[2 Kings - 13|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[2 Kings]]

# 2 Kings - 12

Jehoash began to reign in the seventh year of Jehu, and he reigned forty years in Jerusalem. His mother’s name was Zibiah of Beersheba. [^1] Jehoash did that which was right in Yahweh’s eyes all his days in which Jehoiada the priest instructed him. [^2] However, the high places were not taken away. The people still sacrificed and burned incense in the high places. [^3] Jehoash said to the priests, “All the money of the holy things that is brought into Yahweh’s house, in current money, the money of the people for whom each man is evaluated,#Exodus 30:12 and all the money that it comes into any man’s heart to bring into Yahweh’s house, [^4] let the priests take it to them, each man from his donor; and they shall repair the damage to the house, wherever any damage is found.” [^5] But it was so, that in the twenty-third year of King Jehoash the priests had not repaired the damage to the house. [^6] Then King Jehoash called for Jehoiada the priest, and for the other priests, and said to them, “Why aren’t you repairing the damage to the house? Now therefore take no more money from your treasurers, but deliver it for repair of the damage to the house.” [^7] The priests consented that they should take no more money from the people, and not repair the damage to the house. [^8] But Jehoiada the priest took a chest and bored a hole in its lid, and set it beside the altar, on the right side as one comes into Yahweh’s house; and the priests who kept the threshold put all the money that was brought into Yahweh’s house into it. [^9] When they saw that there was much money in the chest, the king’s scribe and the high priest came up, and they put it in bags and counted the money that was found in Yahweh’s house. [^10] They gave the money that was weighed out into the hands of those who did the work, who had the oversight of Yahweh’s house; and they paid it out to the carpenters and the builders who worked on Yahweh’s house, [^11] and to the masons and the stone cutters, and for buying timber and cut stone to repair the damage to Yahweh’s house, and for all that was laid out for the house to repair it. [^12] But there were not made for Yahweh’s house cups of silver, snuffers, basins, trumpets, any vessels of gold or vessels of silver, of the money that was brought into Yahweh’s house; [^13] for they gave that to those who did the work, and repaired Yahweh’s house with it. [^14] Moreover they didn’t demand an accounting from the men into whose hand they delivered the money to give to those who did the work; for they dealt faithfully. [^15] The money for the trespass offerings and the money for the sin offerings was not brought into Yahweh’s house. It was the priests’. [^16] Then Hazael king of Syria went up and fought against Gath, and took it; and Hazael set his face to go up to Jerusalem. [^17] Jehoash king of Judah took all the holy things that Jehoshaphat and Jehoram and Ahaziah, his fathers, kings of Judah, had dedicated, and his own holy things, and all the gold that was found in the treasures of Yahweh’s house, and of the king’s house, and sent it to Hazael king of Syria; and he went away from Jerusalem. [^18] Now the rest of the acts of Joash, and all that he did, aren’t they written in the book of the chronicles of the kings of Judah? [^19] His servants arose and made a conspiracy, and struck Joash at the house of Millo, on the way that goes down to Silla. [^20] For Jozacar the son of Shimeath, and Jehozabad the son of Shomer, his servants, struck him, and he died; and they buried him with his fathers in David’s city; and Amaziah his son reigned in his place. [^21] 

[[2 Kings - 11|<--]] 2 Kings - 12 [[2 Kings - 13|-->]]

---
# Notes
