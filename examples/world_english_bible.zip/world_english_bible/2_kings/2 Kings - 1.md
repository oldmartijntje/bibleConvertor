---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 1 - World English Bible"
---
2 Kings - 1 [[2 Kings - 2|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[2 Kings]]

# 2 Kings - 1

Moab rebelled against Israel after the death of Ahab. [^1] Ahaziah fell down through the lattice in his upper room that was in Samaria, and was sick. So he sent messengers, and said to them, “Go, inquire of Baal Zebub, the god of Ekron, whether I will recover of this sickness.” [^2] But Yahweh’s#1:3 “Yahweh” is God’s proper Name, sometimes rendered “Lord” (all caps) in other translations. angel said to Elijah the Tishbite, “Arise, go up to meet the messengers of the king of Samaria, and tell them, ‘Is it because there is no God#1:3 The Hebrew word rendered “God” is “אֱלֹהִ֑ים” (Elohim). in Israel that you go to inquire of Baal Zebub, the god of Ekron? [^3] Now therefore Yahweh says, “You will not come down from the bed where you have gone up, but you will surely die.”’” Then Elijah departed. [^4] The messengers returned to him, and he said to them, “Why is it that you have returned?” [^5] They said to him, “A man came up to meet us, and said to us, ‘Go, return to the king who sent you, and tell him, “Yahweh says, ‘Is it because there is no God in Israel that you send to inquire of Baal Zebub, the god of Ekron? Therefore you will not come down from the bed where you have gone up, but you will surely die.’”’” [^6] He said to them, “What kind of man was he who came up to meet you and told you these words?” [^7] They answered him, “He was a hairy man, and wearing a leather belt around his waist.”He said, “It’s Elijah the Tishbite.” [^8] Then the king sent a captain of fifty with his fifty to him. He went up to him; and behold,#1:9 “Behold”, from “הִנֵּה”, means look at, take notice, observe, see, or gaze at. It is often used as an interjection. he was sitting on the top of the hill. He said to him, “Man of God, the king has said, ‘Come down!’” [^9] Elijah answered to the captain of fifty, “If I am a man of God, then let fire come down from the sky and consume you and your fifty!” Then fire came down from the sky, and consumed him and his fifty. [^10] Again he sent to him another captain of fifty with his fifty. He answered him, “Man of God, the king has said, ‘Come down quickly!’” [^11] Elijah answered them, “If I am a man of God, then let fire come down from the sky and consume you and your fifty!” Then God’s fire came down from the sky, and consumed him and his fifty. [^12] Again he sent the captain of a third fifty with his fifty. The third captain of fifty went up, and came and fell on his knees before Elijah, and begged him, and said to him, “Man of God, please let my life and the life of these fifty of your servants be precious in your sight. [^13] Behold, fire came down from the sky and consumed the last two captains of fifty with their fifties. But now let my life be precious in your sight.” [^14] Yahweh’s angel said to Elijah, “Go down with him. Don’t be afraid of him.”Then he arose and went down with him to the king. [^15] He said to him, “Yahweh says, ‘Because you have sent messengers to inquire of Baal Zebub, the god of Ekron, is it because there is no God in Israel to inquire of his word? Therefore you will not come down from the bed where you have gone up, but you will surely die.’” [^16] So he died according to Yahweh’s word which Elijah had spoken. Jehoram began to reign in his place in the second year of Jehoram the son of Jehoshaphat king of Judah, because he had no son. [^17] Now the rest of the acts of Ahaziah which he did, aren’t they written in the book of the chronicles of the kings of Israel? [^18] 

2 Kings - 1 [[2 Kings - 2|-->]]

---
# Notes
