---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 22 - World English Bible"
---
[[2 Kings - 21|<--]] 2 Kings - 22 [[2 Kings - 23|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[2 Kings]]

# 2 Kings - 22

Josiah was eight years old when he began to reign, and he reigned thirty-one years in Jerusalem. His mother’s name was Jedidah the daughter of Adaiah of Bozkath. [^1] He did that which was right in Yahweh’s eyes, and walked in all the ways of David his father, and didn’t turn away to the right hand or to the left. [^2] In the eighteenth year of King Josiah, the king sent Shaphan, the son of Azaliah the son of Meshullam, the scribe, to Yahweh’s house, saying, [^3] “Go up to Hilkiah the high priest, that he may count the money which is brought into Yahweh’s house, which the keepers of the threshold have gathered of the people. [^4] Let them deliver it into the hand of the workers who have the oversight of Yahweh’s house; and let them give it to the workers who are in Yahweh’s house, to repair the damage to the house, [^5] to the carpenters, and to the builders, and to the masons, and for buying timber and cut stone to repair the house. [^6] However, no accounting shall be asked of them for the money delivered into their hand, for they deal faithfully.” [^7] Hilkiah the high priest said to Shaphan the scribe, “I have found the book of the law in Yahweh’s house.” Hilkiah delivered the book to Shaphan, and he read it. [^8] Shaphan the scribe came to the king, and brought the king word again, and said, “Your servants have emptied out the money that was found in the house, and have delivered it into the hands of the workmen who have the oversight of Yahweh’s house.” [^9] Shaphan the scribe told the king, saying, “Hilkiah the priest has delivered a book to me.” Then Shaphan read it before the king. [^10] When the king had heard the words of the book of the law, he tore his clothes. [^11] The king commanded Hilkiah the priest, Ahikam the son of Shaphan, Achbor the son of Micaiah, Shaphan the scribe, and Asaiah the king’s servant, saying, [^12] “Go inquire of Yahweh for me, and for the people, and for all Judah, concerning the words of this book that is found; for great is Yahweh’s wrath that is kindled against us, because our fathers have not listened to the words of this book, to do according to all that which is written concerning us.” [^13] So Hilkiah the priest, Ahikam, Achbor, Shaphan, and Asaiah went to Huldah the prophetess, the wife of Shallum the son of Tikvah, the son of Harhas, keeper of the wardrobe (now she lived in Jerusalem in the second quarter); and they talked with her. [^14] She said to them, “Yahweh the God of Israel says, ‘Tell the man who sent you to me, [^15] “Yahweh says, ‘Behold, I will bring evil on this place and on its inhabitants, even all the words of the book which the king of Judah has read. [^16] Because they have forsaken me and have burned incense to other gods, that they might provoke me to anger with all the work of their hands, therefore my wrath shall be kindled against this place, and it will not be quenched.’” [^17] But to the king of Judah, who sent you to inquire of Yahweh, tell him, “Yahweh the God of Israel says, ‘Concerning the words which you have heard, [^18] because your heart was tender, and you humbled yourself before Yahweh when you heard what I spoke against this place and against its inhabitants, that they should become a desolation and a curse, and have torn your clothes and wept before me, I also have heard you,’ says Yahweh. [^19] ‘Therefore behold, I will gather you to your fathers, and you will be gathered to your grave in peace. Your eyes will not see all the evil which I will bring on this place.’”’” So they brought this message back to the king. [^20] 

[[2 Kings - 21|<--]] 2 Kings - 22 [[2 Kings - 23|-->]]

---
# Notes
