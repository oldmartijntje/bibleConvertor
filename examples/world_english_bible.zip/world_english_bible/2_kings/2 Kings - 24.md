---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 24 - World English Bible"
---
[[2 Kings - 23|<--]] 2 Kings - 24 [[2 Kings - 25|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[2 Kings]]

# 2 Kings - 24

In his days Nebuchadnezzar king of Babylon came up, and Jehoiakim became his servant three years. Then he turned and rebelled against him. [^1] Yahweh sent against him bands of the Chaldeans, bands of the Syrians, bands of the Moabites, and bands of the children of Ammon, and sent them against Judah to destroy it, according to Yahweh’s word which he spoke by his servants the prophets. [^2] Surely at the commandment of Yahweh this came on Judah, to remove them out of his sight for the sins of Manasseh, according to all that he did, [^3] and also for the innocent blood that he shed; for he filled Jerusalem with innocent blood, and Yahweh would not pardon. [^4] Now the rest of the acts of Jehoiakim, and all that he did, aren’t they written in the book of the chronicles of the kings of Judah? [^5] So Jehoiakim slept with his fathers, and Jehoiachin his son reigned in his place. [^6] The king of Egypt didn’t come out of his land any more; for the king of Babylon had taken, from the brook of Egypt to the river Euphrates, all that belonged to the king of Egypt. [^7] Jehoiachin was eighteen years old when he began to reign, and he reigned in Jerusalem three months. His mother’s name was Nehushta the daughter of Elnathan of Jerusalem. [^8] He did that which was evil in Yahweh’s sight, according to all that his father had done. [^9] At that time the servants of Nebuchadnezzar king of Babylon came up to Jerusalem, and the city was besieged. [^10] Nebuchadnezzar king of Babylon came to the city while his servants were besieging it, [^11] and Jehoiachin the king of Judah went out to the king of Babylon—he, his mother, his servants, his princes, and his officers; and the king of Babylon captured him in the eighth year of his reign. [^12] He carried out from there all the treasures of Yahweh’s house and the treasures of the king’s house, and cut in pieces all the vessels of gold which Solomon king of Israel had made in Yahweh’s temple, as Yahweh had said. [^13] He carried away all Jerusalem, and all the princes, and all the mighty men of valor, even ten thousand captives, and all the craftsmen and the smiths. No one remained except the poorest people of the land. [^14] He carried away Jehoiachin to Babylon, with the king’s mother, the king’s wives, his officers, and the chief men of the land. He carried them into captivity from Jerusalem to Babylon. [^15] All the men of might, even seven thousand, and the craftsmen and the smiths one thousand, all of them strong and fit for war, even them the king of Babylon brought captive to Babylon. [^16] The king of Babylon made Mattaniah, Jehoiachin’s father’s brother, king in his place, and changed his name to Zedekiah. [^17] Zedekiah was twenty-one years old when he began to reign, and he reigned eleven years in Jerusalem. His mother’s name was Hamutal the daughter of Jeremiah of Libnah. [^18] He did that which was evil in Yahweh’s sight, according to all that Jehoiakim had done. [^19] For through the anger of Yahweh, this happened in Jerusalem and Judah, until he had cast them out from his presence.Then Zedekiah rebelled against the king of Babylon. [^20] 

[[2 Kings - 23|<--]] 2 Kings - 24 [[2 Kings - 25|-->]]

---
# Notes
