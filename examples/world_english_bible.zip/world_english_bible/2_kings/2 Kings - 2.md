---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 2 - World English Bible"
---
[[2 Kings - 1|<--]] 2 Kings - 2 [[2 Kings - 3|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[2 Kings]]

# 2 Kings - 2

When Yahweh was about to take Elijah up by a whirlwind into heaven, Elijah went with Elisha from Gilgal. [^1] Elijah said to Elisha, “Please wait here, for Yahweh has sent me as far as Bethel.”Elisha said, “As Yahweh lives, and as your soul lives, I will not leave you.” So they went down to Bethel. [^2] The sons of the prophets who were at Bethel came out to Elisha, and said to him, “Do you know that Yahweh will take away your master from over you today?”He said, “Yes, I know it. Hold your peace.” [^3] Elijah said to him, “Elisha, please wait here, for Yahweh has sent me to Jericho.”He said, “As Yahweh lives, and as your soul lives, I will not leave you.” So they came to Jericho. [^4] The sons of the prophets who were at Jericho came near to Elisha, and said to him, “Do you know that Yahweh will take away your master from over you today?”He answered, “Yes, I know it. Hold your peace.” [^5] Elijah said to him, “Please wait here, for Yahweh has sent me to the Jordan.”He said, “As Yahweh lives, and as your soul lives, I will not leave you.” Then they both went on. [^6] Fifty men of the sons of the prophets went and stood opposite them at a distance; and they both stood by the Jordan. [^7] Elijah took his mantle, and rolled it up, and struck the waters; and they were divided here and there, so that they both went over on dry ground. [^8] When they had gone over, Elijah said to Elisha, “Ask what I shall do for you, before I am taken from you.”Elisha said, “Please let a double portion of your spirit be on me.” [^9] He said, “You have asked a hard thing. If you see me when I am taken from you, it will be so for you; but if not, it will not be so.” [^10] As they continued on and talked, behold, a chariot of fire and horses of fire separated them; and Elijah went up by a whirlwind into heaven. [^11] Elisha saw it, and he cried, “My father, my father, the chariots of Israel and its horsemen!”He saw him no more. Then he took hold of his own clothes and tore them in two pieces. [^12] He also took up Elijah’s mantle that fell from him, and went back and stood by the bank of the Jordan. [^13] He took Elijah’s mantle that fell from him, and struck the waters, and said, “Where is Yahweh, the God of Elijah?” When he also had struck the waters, they were divided apart, and Elisha went over. [^14] When the sons of the prophets who were at Jericho facing him saw him, they said, “The spirit of Elijah rests on Elisha.” They came to meet him, and bowed themselves to the ground before him. [^15] They said to him, “See now, there are with your servants fifty strong men. Please let them go and seek your master. Perhaps Yahweh’s Spirit has taken him up, and put him on some mountain or into some valley.”He said, “Don’t send them.” [^16] When they urged him until he was ashamed, he said, “Send them.”Therefore they sent fifty men; and they searched for three days, but didn’t find him. [^17] They came back to him while he stayed at Jericho; and he said to them, “Didn’t I tell you, ‘Don’t go’?” [^18] The men of the city said to Elisha, “Behold, please, the situation of this city is pleasant, as my lord sees; but the water is bad, and the land is barren.” [^19] He said, “Bring me a new jar, and put salt in it.” Then they brought it to him. [^20] He went out to the spring of the waters, and threw salt into it, and said, “Yahweh says, ‘I have healed these waters. There shall not be from there any more death or barren wasteland.’” [^21] So the waters were healed to this day, according to Elisha’s word which he spoke. [^22] He went up from there to Bethel. As he was going up by the way, some youths came out of the city and mocked him, and said to him, “Go up, you baldy! Go up, you baldy!” [^23] He looked behind him and saw them, and cursed them in Yahweh’s name. Then two female bears came out of the woods and mauled forty-two of those youths. [^24] He went from there to Mount Carmel, and from there he returned to Samaria. [^25] 

[[2 Kings - 1|<--]] 2 Kings - 2 [[2 Kings - 3|-->]]

---
# Notes
