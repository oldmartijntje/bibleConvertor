---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 20 - World English Bible"
---
[[2 Kings - 19|<--]] 2 Kings - 20 [[2 Kings - 21|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[2 Kings]]

# 2 Kings - 20

In those days Hezekiah was sick and dying. Isaiah the prophet the son of Amoz came to him, and said to him, “Yahweh says, ‘Set your house in order; for you will die, and not live.’” [^1] Then he turned his face to the wall, and prayed to Yahweh, saying, [^2] “Remember now, Yahweh, I beg you, how I have walked before you in truth and with a perfect heart, and have done that which is good in your sight.” And Hezekiah wept bitterly. [^3] Before Isaiah had gone out into the middle part of the city, Yahweh’s word came to him, saying, [^4] “Turn back, and tell Hezekiah the prince of my people, ‘Yahweh, the God of David your father, says, “I have heard your prayer. I have seen your tears. Behold, I will heal you. On the third day, you will go up to Yahweh’s house. [^5] I will add to your days fifteen years. I will deliver you and this city out of the hand of the king of Assyria. I will defend this city for my own sake, and for my servant David’s sake.”’” [^6] Isaiah said, “Take a cake of figs.”They took and laid it on the boil, and he recovered. [^7] Hezekiah said to Isaiah, “What will be the sign that Yahweh will heal me, and that I will go up to Yahweh’s house the third day?” [^8] Isaiah said, “This will be the sign to you from Yahweh, that Yahweh will do the thing that he has spoken: should the shadow go forward ten steps, or go back ten steps?” [^9] Hezekiah answered, “It is a light thing for the shadow to go forward ten steps. No, but let the shadow return backward ten steps.” [^10] Isaiah the prophet cried to Yahweh; and he brought the shadow ten steps backward, by which it had gone down on the sundial of Ahaz. [^11] At that time Berodach Baladan the son of Baladan, king of Babylon, sent letters and a present to Hezekiah, for he had heard that Hezekiah had been sick. [^12] Hezekiah listened to them, and showed them all the storehouse of his precious things—the silver, the gold, the spices, and the precious oil, and the house of his armor, and all that was found in his treasures. There was nothing in his house, or in all his dominion, that Hezekiah didn’t show them. [^13] Then Isaiah the prophet came to King Hezekiah, and said to him, “What did these men say? From where did they come to you?”Hezekiah said, “They have come from a far country, even from Babylon.” [^14] He said, “What have they seen in your house?”Hezekiah answered, “They have seen all that is in my house. There is nothing among my treasures that I have not shown them.” [^15] Isaiah said to Hezekiah, “Hear Yahweh’s word. [^16] ‘Behold, the days come that all that is in your house, and that which your fathers have laid up in store to this day, will be carried to Babylon. Nothing will be left,’ says Yahweh. [^17] ‘They will take away some of your sons who will issue from you, whom you will father; and they will be eunuchs in the palace of the king of Babylon.’” [^18] Then Hezekiah said to Isaiah, “Yahweh’s word which you have spoken is good.” He said moreover, “Isn’t it so, if peace and truth will be in my days?” [^19] Now the rest of the acts of Hezekiah, and all his might, and how he made the pool, and the conduit, and brought water into the city, aren’t they written in the book of the chronicles of the kings of Judah? [^20] Hezekiah slept with his fathers, and Manasseh his son reigned in his place. [^21] 

[[2 Kings - 19|<--]] 2 Kings - 20 [[2 Kings - 21|-->]]

---
# Notes
