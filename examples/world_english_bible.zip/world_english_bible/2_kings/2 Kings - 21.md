---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 21 - World English Bible"
---
[[2 Kings - 20|<--]] 2 Kings - 21 [[2 Kings - 22|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[2 Kings]]

# 2 Kings - 21

Manasseh was twelve years old when he began to reign, and he reigned fifty-five years in Jerusalem. His mother’s name was Hephzibah. [^1] He did that which was evil in Yahweh’s sight, after the abominations of the nations whom Yahweh cast out before the children of Israel. [^2] For he built again the high places which Hezekiah his father had destroyed; and he raised up altars for Baal, and made an Asherah, as Ahab king of Israel did, and worshiped all the army of the sky, and served them. [^3] He built altars in Yahweh’s house, of which Yahweh said, “I will put my name in Jerusalem.” [^4] He built altars for all the army of the sky in the two courts of Yahweh’s house. [^5] He made his son to pass through the fire, practiced sorcery, used enchantments, and dealt with those who had familiar spirits and with wizards. He did much evil in Yahweh’s sight, to provoke him to anger. [^6] He set the engraved image of Asherah that he had made in the house of which Yahweh said to David and to Solomon his son, “In this house, and in Jerusalem, which I have chosen out of all the tribes of Israel, I will put my name forever; [^7] I will not cause the feet of Israel to wander any more out of the land which I gave their fathers, if only they will observe to do according to all that I have commanded them, and according to all the law that my servant Moses commanded them.” [^8] But they didn’t listen, and Manasseh seduced them to do that which is evil more than the nations did whom Yahweh destroyed before the children of Israel. [^9] Yahweh spoke by his servants the prophets, saying, [^10] “Because Manasseh king of Judah has done these abominations, and has done wickedly above all that the Amorites did, who were before him, and has also made Judah to sin with his idols; [^11] therefore Yahweh the God of Israel says, ‘Behold, I will bring such evil on Jerusalem and Judah that whoever hears of it, both his ears will tingle. [^12] I will stretch over Jerusalem the line of Samaria, and the plumb line of Ahab’s house; and I will wipe Jerusalem as a man wipes a dish, wiping it and turning it upside down. [^13] I will cast off the remnant of my inheritance and deliver them into the hands of their enemies. They will become a prey and a plunder to all their enemies, [^14] because they have done that which is evil in my sight, and have provoked me to anger since the day their fathers came out of Egypt, even to this day.’” [^15] Moreover Manasseh shed innocent blood very much, until he had filled Jerusalem from one end to another; in addition to his sin with which he made Judah to sin, in doing that which was evil in Yahweh’s sight. [^16] Now the rest of the acts of Manasseh, and all that he did, and his sin that he sinned, aren’t they written in the book of the chronicles of the kings of Judah? [^17] Manasseh slept with his fathers, and was buried in the garden of his own house, in the garden of Uzza; and Amon his son reigned in his place. [^18] Amon was twenty-two years old when he began to reign; and he reigned two years in Jerusalem. His mother’s name was Meshullemeth the daughter of Haruz of Jotbah. [^19] He did that which was evil in Yahweh’s sight, as Manasseh his father did. [^20] He walked in all the ways that his father walked in, and served the idols that his father served, and worshiped them; [^21] and he abandoned Yahweh, the God of his fathers, and didn’t walk in the way of Yahweh. [^22] The servants of Amon conspired against him, and put the king to death in his own house. [^23] But the people of the land killed all those who had conspired against King Amon; and the people of the land made Josiah his son king in his place. [^24] Now the rest of the acts of Amon which he did, aren’t they written in the book of the chronicles of the kings of Judah? [^25] He was buried in his tomb in the garden of Uzza, and Josiah his son reigned in his place. [^26] 

[[2 Kings - 20|<--]] 2 Kings - 21 [[2 Kings - 22|-->]]

---
# Notes
