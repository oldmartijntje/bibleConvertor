---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 16 - World English Bible"
---
[[2 Kings - 15|<--]] 2 Kings - 16 [[2 Kings - 17|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[2 Kings]]

# 2 Kings - 16

In the seventeenth year of Pekah the son of Remaliah, Ahaz the son of Jotham king of Judah began to reign. [^1] Ahaz was twenty years old when he began to reign, and he reigned sixteen years in Jerusalem. He didn’t do that which was right in Yahweh his God’s eyes, like David his father. [^2] But he walked in the way of the kings of Israel, and even made his son to pass through the fire, according to the abominations of the nations whom Yahweh cast out from before the children of Israel. [^3] He sacrificed and burned incense in the high places, on the hills, and under every green tree. [^4] Then Rezin king of Syria and Pekah son of Remaliah king of Israel came up to Jerusalem to wage war. They besieged Ahaz, but could not overcome him. [^5] At that time Rezin king of Syria recovered Elath to Syria, and drove the Jews from Elath; and the Syrians came to Elath, and lived there to this day. [^6] So Ahaz sent messengers to Tiglath Pileser king of Assyria, saying, “I am your servant and your son. Come up and save me out of the hand of the king of Syria and out of the hand of the king of Israel, who rise up against me.” [^7] Ahaz took the silver and gold that was found in Yahweh’s house, and in the treasures of the king’s house, and sent it for a present to the king of Assyria. [^8] The king of Assyria listened to him; and the king of Assyria went up against Damascus and took it, and carried its people captive to Kir, and killed Rezin. [^9] King Ahaz went to Damascus to meet Tiglath Pileser king of Assyria, and saw the altar that was at Damascus; and King Ahaz sent to Urijah the priest a drawing of the altar and plans to build it. [^10] Urijah the priest built an altar. According to all that King Ahaz had sent from Damascus, so Urijah the priest made it for the coming of King Ahaz from Damascus. [^11] When the king had come from Damascus, the king saw the altar; and the king came near to the altar, and offered on it. [^12] He burned his burnt offering and his meal offering, poured his drink offering, and sprinkled the blood of his peace offerings on the altar. [^13] The bronze altar, which was before Yahweh, he brought from the front of the house, from between his altar and Yahweh’s house, and put it on the north side of his altar. [^14] King Ahaz commanded Urijah the priest, saying, “On the great altar burn the morning burnt offering, the evening meal offering, the king’s burnt offering and his meal offering, with the burnt offering of all the people of the land, their meal offering, and their drink offerings; and sprinkle on it all the blood of the burnt offering, and all the blood of the sacrifice; but the bronze altar will be for me to inquire by.” [^15] Urijah the priest did so, according to all that King Ahaz commanded. [^16] King Ahaz cut off the panels of the bases, and removed the basin from off them, and took down the sea from off the bronze oxen that were under it, and put it on a pavement of stone. [^17] He removed the covered way for the Sabbath that they had built in the house, and the king’s outer entrance to Yahweh’s house, because of the king of Assyria. [^18] Now the rest of the acts of Ahaz which he did, aren’t they written in the book of the chronicles of the kings of Judah? [^19] Ahaz slept with his fathers, and was buried with his fathers in David’s city; and Hezekiah his son reigned in his place. [^20] 

[[2 Kings - 15|<--]] 2 Kings - 16 [[2 Kings - 17|-->]]

---
# Notes
