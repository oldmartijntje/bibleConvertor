---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 11 - World English Bible"
---
[[2 Kings - 10|<--]] 2 Kings - 11 [[2 Kings - 12|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[2 Kings]]

# 2 Kings - 11

Now when Athaliah the mother of Ahaziah saw that her son was dead, she arose and destroyed all the royal offspring. [^1] But Jehosheba, the daughter of King Joram, sister of Ahaziah, took Joash the son of Ahaziah, and stole him away from among the king’s sons who were slain, even him and his nurse, and put them in the bedroom; and they hid him from Athaliah, so that he was not slain. [^2] He was with her hidden in Yahweh’s house six years while Athaliah reigned over the land. [^3] In the seventh year Jehoiada sent and fetched the captains over hundreds of the Carites and of the guard, and brought them to him into Yahweh’s house; and he made a covenant with them, and made a covenant with them in Yahweh’s house, and showed them the king’s son. [^4] He commanded them, saying, “This is what you must do: a third of you, who come in on the Sabbath, shall be keepers of the watch of the king’s house; [^5] a third of you shall be at the gate Sur; and a third of you at the gate behind the guard. So you shall keep the watch of the house, and be a barrier. [^6] The two companies of you, even all who go out on the Sabbath, shall keep the watch of Yahweh’s house around the king. [^7] You shall surround the king, every man with his weapons in his hand; and he who comes within the ranks, let him be slain. Be with the king when he goes out, and when he comes in.” [^8] The captains over hundreds did according to all that Jehoiada the priest commanded; and they each took his men, those who were to come in on the Sabbath with those who were to go out on the Sabbath, and came to Jehoiada the priest. [^9] The priest delivered to the captains over hundreds the spears and shields that had been King David’s, which were in Yahweh’s house. [^10] The guard stood, every man with his weapons in his hand, from the right side of the house to the left side of the house, along by the altar and the house, around the king. [^11] Then he brought out the king’s son, and put the crown on him, and gave him the covenant; and they made him king and anointed him; and they clapped their hands, and said, “Long live the king!” [^12] When Athaliah heard the noise of the guard and of the people, she came to the people into Yahweh’s house; [^13] and she looked, and behold, the king stood by the pillar, as the tradition was, with the captains and the trumpets by the king; and all the people of the land rejoiced, and blew trumpets. Then Athaliah tore her clothes and cried, “Treason! Treason!” [^14] Jehoiada the priest commanded the captains of hundreds who were set over the army, and said to them, “Bring her out between the ranks. Kill anyone who follows her with the sword.” For the priest said, “Don’t let her be slain in Yahweh’s house.” [^15] So they seized her; and she went by the way of the horses’ entry to the king’s house, and she was slain there. [^16] Jehoiada made a covenant between Yahweh and the king and the people, that they should be Yahweh’s people; also between the king and the people. [^17] All the people of the land went to the house of Baal, and broke it down. They broke his altars and his images in pieces thoroughly, and killed Mattan the priest of Baal before the altars. The priest appointed officers over Yahweh’s house. [^18] He took the captains over hundreds, and the Carites, and the guard, and all the people of the land; and they brought down the king from Yahweh’s house, and came by the way of the gate of the guard to the king’s house. He sat on the throne of the kings. [^19] So all the people of the land rejoiced, and the city was quiet. They had slain Athaliah with the sword at the king’s house. [^20] Jehoash was seven years old when he began to reign. [^21] 

[[2 Kings - 10|<--]] 2 Kings - 11 [[2 Kings - 12|-->]]

---
# Notes
