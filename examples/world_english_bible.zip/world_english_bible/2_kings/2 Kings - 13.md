---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 13 - World English Bible"
---
[[2 Kings - 12|<--]] 2 Kings - 13 [[2 Kings - 14|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[2 Kings]]

# 2 Kings - 13

In the twenty-third year of Joash the son of Ahaziah, king of Judah, Jehoahaz the son of Jehu began to reign over Israel in Samaria for seventeen years. [^1] He did that which was evil in Yahweh’s sight, and followed the sins of Jeroboam the son of Nebat, with which he made Israel to sin. He didn’t depart from it. [^2] Yahweh’s anger burned against Israel, and he delivered them into the hand of Hazael king of Syria, and into the hand of Benhadad the son of Hazael, continually. [^3] Jehoahaz begged Yahweh, and Yahweh listened to him; for he saw the oppression of Israel, how the king of Syria oppressed them. [^4] (Yahweh gave Israel a savior, so that they went out from under the hand of the Syrians; and the children of Israel lived in their tents as before. [^5] Nevertheless they didn’t depart from the sins of the house of Jeroboam, with which he made Israel to sin, but walked in them; and the Asherah also remained in Samaria.) [^6] For he didn’t leave to Jehoahaz of the people any more than fifty horsemen, and ten chariots, and ten thousand footmen; for the king of Syria destroyed them and made them like the dust in threshing. [^7] Now the rest of the acts of Jehoahaz, and all that he did, and his might, aren’t they written in the book of the chronicles of the kings of Israel? [^8] Jehoahaz slept with his fathers; and they buried him in Samaria; and Joash his son reigned in his place. [^9] In the thirty-seventh year of Joash king of Judah, Jehoash the son of Jehoahaz began to reign over Israel in Samaria for sixteen years. [^10] He did that which was evil in Yahweh’s sight. He didn’t depart from all the sins of Jeroboam the son of Nebat, with which he made Israel to sin; but he walked in them. [^11] Now the rest of the acts of Joash, and all that he did, and his might with which he fought against Amaziah king of Judah, aren’t they written in the book of the chronicles of the kings of Israel? [^12] Joash slept with his fathers; and Jeroboam sat on his throne. Joash was buried in Samaria with the kings of Israel. [^13] Now Elisha became sick with the illness of which he died; and Joash the king of Israel came down to him, and wept over him, and said, “My father, my father, the chariots of Israel and its horsemen!” [^14] Elisha said to him, “Take bow and arrows;” and he took bow and arrows for himself. [^15] He said to the king of Israel, “Put your hand on the bow;” and he put his hand on it. Elisha laid his hands on the king’s hands. [^16] He said, “Open the window eastward;” and he opened it. Then Elisha said, “Shoot!” and he shot. He said, “Yahweh’s arrow of victory, even the arrow of victory over Syria; for you will strike the Syrians in Aphek until you have consumed them.” [^17] He said, “Take the arrows;” and he took them. He said to the king of Israel, “Strike the ground;” and he struck three times, and stopped. [^18] The man of God was angry with him, and said, “You should have struck five or six times. Then you would have struck Syria until you had consumed it, but now you will strike Syria just three times.” [^19] Elisha died, and they buried him.Now the bands of the Moabites invaded the land at the coming in of the year. [^20] As they were burying a man, behold, they saw a band of raiders; and they threw the man into Elisha’s tomb. As soon as the man touched Elisha’s bones, he revived, and stood up on his feet. [^21] Hazael king of Syria oppressed Israel all the days of Jehoahaz. [^22] But Yahweh was gracious to them, and had compassion on them, and favored them because of his covenant with Abraham, Isaac, and Jacob, and would not destroy them and he didn’t cast them from his presence as yet. [^23] Hazael king of Syria died; and Benhadad his son reigned in his place. [^24] Jehoash the son of Jehoahaz took again out of the hand of Benhadad the son of Hazael the cities which he had taken out of the hand of Jehoahaz his father by war. Joash struck him three times, and recovered the cities of Israel. [^25] 

[[2 Kings - 12|<--]] 2 Kings - 13 [[2 Kings - 14|-->]]

---
# Notes
