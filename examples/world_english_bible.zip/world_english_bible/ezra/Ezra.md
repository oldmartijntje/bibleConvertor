---
translation: World English Bible
aliases:
  - "Ezra - World English Bible"
tags:
  - "#bible/type/book"
  - "#bible/book/ezra"
  - "#bible/testament/old"
---
[[2 Chronicles|<--]] Ezra [[Nehemiah|-->]]

# Ezra - World English Bible

The Ezra book has 10 chapters. It is part of the old testament.

## Chapters

- Ezra [[Ezra - 1|chapter 1]]
- Ezra [[Ezra - 2|chapter 2]]
- Ezra [[Ezra - 3|chapter 3]]
- Ezra [[Ezra - 4|chapter 4]]
- Ezra [[Ezra - 5|chapter 5]]
- Ezra [[Ezra - 6|chapter 6]]
- Ezra [[Ezra - 7|chapter 7]]
- Ezra [[Ezra - 8|chapter 8]]
- Ezra [[Ezra - 9|chapter 9]]
- Ezra [[Ezra - 10|chapter 10]]

[[2 Chronicles|<--]] Ezra [[Nehemiah|-->]]

---
# Notes
