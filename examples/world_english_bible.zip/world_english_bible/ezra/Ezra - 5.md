---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/ezra"
  - "#bible/testament/old"
aliases:
  - "Ezra - 5 - World English Bible"
---
[[Ezra - 4|<--]] Ezra - 5 [[Ezra - 6|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Ezra]]

# Ezra - 5

Now the prophets, Haggai the prophet and Zechariah the son of Iddo, prophesied to the Jews who were in Judah and Jerusalem. They prophesied to them in the name of the God of Israel. [^1] Then Zerubbabel the son of Shealtiel, and Jeshua the son of Jozadak rose up and began to build God’s house which is at Jerusalem; and with them were the prophets of God, helping them. [^2] At the same time Tattenai, the governor beyond the River, came to them, with Shetharbozenai and their companions, and asked them, “Who gave you a decree to build this house and to finish this wall?” [^3] They also asked for the names of the men who were making this building. [^4] But the eye of their God was on the elders of the Jews, and they didn’t make them cease until the matter should come to Darius, and an answer should be returned by letter concerning it. [^5] The copy of the letter that Tattenai, the governor beyond the River, and Shetharbozenai, and his companions the Apharsachites who were beyond the River, sent to Darius the king follows. [^6] They sent a letter to him, in which was written:To Darius the king, all peace. [^7] Be it known to the king that we went into the province of Judah, to the house of the great God, which is being built with great stones and timber is laid in the walls. This work goes on with diligence and prospers in their hands. [^8] Then we asked those elders, and said to them thus, “Who gave you a decree to build this house, and to finish this wall?” [^9] We asked them their names also, to inform you that we might write the names of the men who were at their head. [^10] Thus they returned us answer, saying, “We are the servants of the God of heaven and earth and are building the house that was built these many years ago, which a great king of Israel built and finished. [^11] But after our fathers had provoked the God of heaven to wrath, he gave them into the hand of Nebuchadnezzar king of Babylon, the Chaldean, who destroyed this house and carried the people away into Babylon. [^12] But in the first year of Cyrus king of Babylon, Cyrus the king made a decree to build this house of God. [^13] The gold and silver vessels of God’s house, which Nebuchadnezzar took out of the temple that was in Jerusalem and brought into the temple of Babylon, those Cyrus the king also took out of the temple of Babylon, and they were delivered to one whose name was Sheshbazzar, whom he had made governor. [^14] He said to him, ‘Take these vessels, go, put them in the temple that is in Jerusalem, and let God’s house be built in its place.’ [^15] Then the same Sheshbazzar came and laid the foundations of God’s house which is in Jerusalem. Since that time even until now it has been being built, and yet it is not completed. [^16] Now therefore, if it seems good to the king, let a search be made in the king’s treasure house, which is there at Babylon, whether it is so that a decree was made by Cyrus the king to build this house of God at Jerusalem; and let the king send his pleasure to us concerning this matter.” [^17] 

[[Ezra - 4|<--]] Ezra - 5 [[Ezra - 6|-->]]

---
# Notes
