---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/ezra"
  - "#bible/testament/old"
aliases:
  - "Ezra - 1 - World English Bible"
---
Ezra - 1 [[Ezra - 2|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Ezra]]

# Ezra - 1

Now in the first year of Cyrus king of Persia, that Yahweh’s#1:1 “Yahweh” is God’s proper Name, sometimes rendered “Lord” (all caps) in other translations. word by Jeremiah’s mouth might be accomplished, Yahweh stirred up the spirit of Cyrus king of Persia, so that he made a proclamation throughout all his kingdom, and put it also in writing, saying, [^1] “Cyrus king of Persia says, ‘Yahweh, the God#1:2 The Hebrew word rendered “God” is “אֱלֹהִ֑ים” (Elohim). of heaven, has given me all the kingdoms of the earth; and he has commanded me to build him a house in Jerusalem, which is in Judah. [^2] Whoever there is among you of all his people, may his God be with him, and let him go up to Jerusalem, which is in Judah, and build the house of Yahweh, the God of Israel (he is God), which is in Jerusalem. [^3] Whoever is left, in any place where he lives, let the men of his place help him with silver, with gold, with goods, and with animals, in addition to the free will offering for God’s house which is in Jerusalem.’” [^4] Then the heads of fathers’ households of Judah and Benjamin, the priests and the Levites, all whose spirit God had stirred to go up, rose up to build Yahweh’s house which is in Jerusalem. [^5] All those who were around them strengthened their hands with vessels of silver, with gold, with goods, with animals, and with precious things, in addition to all that was willingly offered. [^6] Also Cyrus the king brought out the vessels of Yahweh’s house, which Nebuchadnezzar had brought out of Jerusalem, and had put in the house of his gods; [^7] even those, Cyrus king of Persia brought out by the hand of Mithredath the treasurer, and counted them out to Sheshbazzar the prince of Judah. [^8] This is the number of them: thirty platters of gold, one thousand platters of silver, twenty-nine knives, [^9] thirty bowls of gold, four hundred ten silver bowls of a second kind, and one thousand other vessels. [^10] All the vessels of gold and of silver were five thousand four hundred. Sheshbazzar brought all these up when the captives were brought up from Babylon to Jerusalem. [^11] 

Ezra - 1 [[Ezra - 2|-->]]

---
# Notes
