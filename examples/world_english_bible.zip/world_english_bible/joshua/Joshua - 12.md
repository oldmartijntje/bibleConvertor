---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 12 - World English Bible"
---
[[Joshua - 11|<--]] Joshua - 12 [[Joshua - 13|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Joshua]]

# Joshua - 12

Now these are the kings of the land, whom the children of Israel struck, and possessed their land beyond the Jordan toward the sunrise, from the valley of the Arnon to Mount Hermon, and all the Arabah eastward: [^1] Sihon king of the Amorites, who lived in Heshbon, and ruled from Aroer, which is on the edge of the valley of the Arnon, and the middle of the valley, and half Gilead, even to the river Jabbok, the border of the children of Ammon; [^2] and the Arabah to the sea of Chinneroth, eastward, and to the sea of the Arabah, even the Salt Sea, eastward, the way to Beth Jeshimoth; and on the south, under the slopes of Pisgah: [^3] and the border of Og king of Bashan, of the remnant of the Rephaim, who lived at Ashtaroth and at Edrei, [^4] and ruled in Mount Hermon, and in Salecah, and in all Bashan, to the border of the Geshurites and the Maacathites, and half Gilead, the border of Sihon king of Heshbon. [^5] Moses the servant of Yahweh and the children of Israel struck them. Moses the servant of Yahweh gave it for a possession to the Reubenites, and the Gadites, and the half-tribe of Manasseh. [^6] These are the kings of the land whom Joshua and the children of Israel struck beyond the Jordan westward, from Baal Gad in the valley of Lebanon even to Mount Halak, that goes up to Seir. Joshua gave it to the tribes of Israel for a possession according to their divisions; [^7] in the hill country, and in the lowland, and in the Arabah, and in the slopes, and in the wilderness, and in the South; the Hittite, the Amorite, and the Canaanite, the Perizzite, the Hivite, and the Jebusite: [^8] the king of Jericho, one;the king of Ai, which is beside Bethel, one; [^9] the king of Jerusalem, one;the king of Hebron, one; [^10] the king of Jarmuth, one;the king of Lachish, one; [^11] the king of Eglon, one;the king of Gezer, one; [^12] the king of Debir, one;the king of Geder, one; [^13] the king of Hormah, one;the king of Arad, one; [^14] the king of Libnah, one;the king of Adullam, one; [^15] the king of Makkedah, one;the king of Bethel, one; [^16] the king of Tappuah, one;the king of Hepher, one; [^17] the king of Aphek, one;the king of Lassharon, one; [^18] the king of Madon, one;the king of Hazor, one; [^19] the king of Shimron Meron, one;the king of Achshaph, one; [^20] the king of Taanach, one;the king of Megiddo, one; [^21] the king of Kedesh, one;the king of Jokneam in Carmel, one; [^22] the king of Dor in the height of Dor, one;the king of Goiim in Gilgal, one; [^23] the king of Tirzah, one:all the kings thirty-one. [^24] 

[[Joshua - 11|<--]] Joshua - 12 [[Joshua - 13|-->]]

---
# Notes
