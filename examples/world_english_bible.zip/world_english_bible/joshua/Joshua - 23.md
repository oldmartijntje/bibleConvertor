---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 23 - World English Bible"
---
[[Joshua - 22|<--]] Joshua - 23 [[Joshua - 24|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Joshua]]

# Joshua - 23

After many days, when Yahweh had given rest to Israel from their enemies all around, and Joshua was old and well advanced in years, [^1] Joshua called for all Israel, for their elders and for their heads, and for their judges and for their officers, and said to them, “I am old and well advanced in years. [^2] You have seen all that Yahweh your God has done to all these nations because of you; for it is Yahweh your God who has fought for you. [^3] Behold, I have allotted to you these nations that remain, to be an inheritance for your tribes, from the Jordan, with all the nations that I have cut off, even to the great sea toward the going down of the sun. [^4] Yahweh your God will thrust them out from before you, and drive them from out of your sight. You shall possess their land, as Yahweh your God spoke to you. [^5] “Therefore be very courageous to keep and to do all that is written in the book of the law of Moses, that you not turn away from it to the right hand or to the left; [^6] that you not come among these nations, these that remain among you; neither make mention of the name of their gods, nor cause to swear by them, neither serve them, nor bow down yourselves to them; [^7] but hold fast to Yahweh your God, as you have done to this day. [^8] “For Yahweh has driven great and strong nations out from before you. But as for you, no man has stood before you to this day. [^9] One man of you shall chase a thousand; for it is Yahweh your God who fights for you, as he spoke to you. [^10] Take good heed therefore to yourselves, that you love Yahweh your God. [^11] “But if you do at all go back, and hold fast to the remnant of these nations, even these who remain among you, and make marriages with them, and go in to them, and they to you; [^12] know for a certainty that Yahweh your God will no longer drive these nations from out of your sight; but they shall be a snare and a trap to you, a scourge in your sides, and thorns in your eyes, until you perish from off this good land which Yahweh your God has given you. [^13] “Behold, today I am going the way of all the earth. You know in all your hearts and in all your souls that not one thing has failed of all the good things which Yahweh your God spoke concerning you. All have happened to you. Not one thing has failed of it. [^14] It shall happen that as all the good things have come on you of which Yahweh your God spoke to you, so Yahweh will bring on you all the evil things, until he has destroyed you from off this good land which Yahweh your God has given you, [^15] when you disobey the covenant of Yahweh your God, which he commanded you, and go and serve other gods, and bow down yourselves to them. Then Yahweh’s anger will be kindled against you, and you will perish quickly from off the good land which he has given to you.” [^16] 

[[Joshua - 22|<--]] Joshua - 23 [[Joshua - 24|-->]]

---
# Notes
