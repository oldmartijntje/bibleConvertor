---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 2 - World English Bible"
---
[[Joshua - 1|<--]] Joshua - 2 [[Joshua - 3|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Joshua]]

# Joshua - 2

Joshua the son of Nun secretly sent two men out of Shittim as spies, saying, “Go, view the land, including Jericho.” They went and came into the house of a prostitute whose name was Rahab, and slept there. [^1] The king of Jericho was told, “Behold,#2:2 “Behold”, from “הִנֵּה”, means look at, take notice, observe, see, or gaze at. It is often used as an interjection. men of the children of Israel came in here tonight to spy out the land.” [^2] Jericho’s king sent to Rahab, saying, “Bring out the men who have come to you, who have entered into your house; for they have come to spy out all the land.” [^3] The woman took the two men and hid them. Then she said, “Yes, the men came to me, but I didn’t know where they came from. [^4] About the time of the shutting of the gate, when it was dark, the men went out. Where the men went, I don’t know. Pursue them quickly. You may catch up with them.” [^5] But she had brought them up to the roof, and hidden them under the stalks of flax which she had laid in order on the roof. [^6] The men pursued them along the way to the fords of the Jordan River. As soon as those who pursued them had gone out, they shut the gate. [^7] Before they had lain down, she came up to them on the roof. [^8] She said to the men, “I know that Yahweh has given you the land, and that the fear of you has fallen upon us, and that all the inhabitants of the land melt away before you. [^9] For we have heard how Yahweh dried up the water of the Red Sea before you, when you came out of Egypt; and what you did to the two kings of the Amorites, who were beyond the Jordan, to Sihon and to Og, whom you utterly destroyed. [^10] As soon as we had heard it, our hearts melted, and there wasn’t any more spirit in any man, because of you: for Yahweh your God, he is God in heaven above, and on earth beneath. [^11] Now therefore, please swear to me by Yahweh, since I have dealt kindly with you, that you also will deal kindly with my father’s house, and give me a true sign; [^12] and that you will save alive my father, my mother, my brothers, and my sisters, and all that they have, and will deliver our lives from death.” [^13] The men said to her, “Our life for yours, if you don’t talk about this business of ours; and it shall be, when Yahweh gives us the land, that we will deal kindly and truly with you.” [^14] Then she let them down by a cord through the window; for her house was on the side of the wall, and she lived on the wall. [^15] She said to them, “Go to the mountain, lest the pursuers find you. Hide yourselves there three days, until the pursuers have returned. Afterward, you may go your way.” [^16] The men said to her, “We will be guiltless of this your oath which you’ve made us to swear. [^17] Behold, when we come into the land, tie this line of scarlet thread in the window which you used to let us down. Gather to yourself into the house your father, your mother, your brothers, and all your father’s household. [^18] It shall be that whoever goes out of the doors of your house into the street, his blood will be on his head, and we will be guiltless. Whoever is with you in the house, his blood shall be on our head, if any hand is on him. [^19] But if you talk about this business of ours, then we shall be guiltless of your oath which you’ve made us to swear.” [^20] She said, “Let it be as you have said.” She sent them away, and they departed. Then she tied the scarlet line in the window. [^21] They went and came to the mountain, and stayed there three days, until the pursuers had returned. The pursuers sought them all along the way, but didn’t find them. [^22] Then the two men returned, descended from the mountain, crossed the river, and came to Joshua the son of Nun. They told him all that had happened to them. [^23] They said to Joshua, “Truly Yahweh has delivered all the land into our hands. Moreover, all the inhabitants of the land melt away before us.” [^24] 

[[Joshua - 1|<--]] Joshua - 2 [[Joshua - 3|-->]]

---
# Notes
