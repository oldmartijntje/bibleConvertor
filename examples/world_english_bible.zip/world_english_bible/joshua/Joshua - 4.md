---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 4 - World English Bible"
---
[[Joshua - 3|<--]] Joshua - 4 [[Joshua - 5|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Joshua]]

# Joshua - 4

When all the nation had completely crossed over the Jordan, Yahweh spoke to Joshua, saying, [^1] “Take twelve men out of the people, a man out of every tribe, [^2] and command them, saying, ‘Take from out of the middle of the Jordan, out of the place where the priests’ feet stood firm, twelve stones, carry them over with you, and lay them down in the place where you’ll camp tonight.’” [^3] Then Joshua called the twelve men whom he had prepared of the children of Israel, a man out of every tribe. [^4] Joshua said to them, “Cross before the ark of Yahweh your God into the middle of the Jordan, and each of you pick up a stone and put it on your shoulder, according to the number of the tribes of the children of Israel; [^5] that this may be a sign among you, that when your children ask in the future, saying, ‘What do you mean by these stones?’ [^6] then you shall tell them, ‘Because the waters of the Jordan were cut off before the ark of Yahweh’s covenant. When it crossed over the Jordan, the waters of the Jordan were cut off. These stones shall be for a memorial to the children of Israel forever.’” [^7] The children of Israel did as Joshua commanded, and took up twelve stones out of the middle of the Jordan, as Yahweh spoke to Joshua, according to the number of the tribes of the children of Israel. They carried them over with them to the place where they camped, and laid them down there. [^8] Joshua set up twelve stones in the middle of the Jordan, in the place where the feet of the priests who bore the ark of the covenant stood; and they are there to this day. [^9] For the priests who bore the ark stood in the middle of the Jordan until everything was finished that Yahweh commanded Joshua to speak to the people, according to all that Moses commanded Joshua; and the people hurried and passed over. [^10] When all the people had completely crossed over, Yahweh’s ark crossed over with the priests in the presence of the people. [^11] The children of Reuben, and the children of Gad, and the half-tribe of Manasseh crossed over armed before the children of Israel, as Moses spoke to them. [^12] About forty thousand men, ready and armed for war, passed over before Yahweh to battle, to the plains of Jericho. [^13] On that day, Yahweh magnified Joshua in the sight of all Israel; and they feared him, as they feared Moses, all the days of his life. [^14] Yahweh spoke to Joshua, saying, [^15] “Command the priests who bear the ark of the covenant, that they come up out of the Jordan.” [^16] Joshua therefore commanded the priests, saying, “Come up out of the Jordan!” [^17] When the priests who bore the ark of Yahweh’s covenant had come up out of the middle of the Jordan, and the soles of the priests’ feet had been lifted up to the dry ground, the waters of the Jordan returned to their place, and went over all its banks, as before. [^18] The people came up out of the Jordan on the tenth day of the first month, and encamped in Gilgal, on the east border of Jericho. [^19] Joshua set up those twelve stones, which they took out of the Jordan, in Gilgal. [^20] He spoke to the children of Israel, saying, “When your children ask their fathers in time to come, saying, ‘What do these stones mean?’ [^21] Then you shall let your children know, saying, ‘Israel came over this Jordan on dry land. [^22] For Yahweh your God dried up the waters of the Jordan from before you until you had crossed over, as Yahweh your God did to the Red Sea, which he dried up from before us, until we had crossed over, [^23] that all the peoples of the earth may know that Yahweh’s hand is mighty, and that you may fear Yahweh your God forever.’” [^24] 

[[Joshua - 3|<--]] Joshua - 4 [[Joshua - 5|-->]]

---
# Notes
