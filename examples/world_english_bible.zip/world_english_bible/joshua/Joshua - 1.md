---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 1 - World English Bible"
---
Joshua - 1 [[Joshua - 2|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Joshua]]

# Joshua - 1

Now after the death of Moses the servant of Yahweh,#1:1 “Yahweh” is God’s proper Name, sometimes rendered “Lord” (all caps) in other translations. Yahweh spoke to Joshua the son of Nun, Moses’ servant, saying, [^1] “Moses my servant is dead. Now therefore arise, go across this Jordan, you and all these people, to the land which I am giving to them, even to the children of Israel. [^2] I have given you every place that the sole of your foot will tread on, as I told Moses. [^3] From the wilderness and this Lebanon even to the great river, the river Euphrates, all the land of the Hittites, and to the great sea toward the going down of the sun, shall be your border. [^4] No man will be able to stand before you all the days of your life. As I was with Moses, so I will be with you. I will not fail you nor forsake you. [^5] “Be strong and courageous; for you shall cause this people to inherit the land which I swore to their fathers to give them. [^6] Only be strong and very courageous. Be careful to observe to do according to all the law which Moses my servant commanded you. Don’t turn from it to the right hand or to the left, that you may have good success wherever you go. [^7] This book of the law shall not depart from your mouth, but you shall meditate on it day and night, that you may observe to do according to all that is written in it; for then you shall make your way prosperous, and then you shall have good success. [^8] Haven’t I commanded you? Be strong and courageous. Don’t be afraid. Don’t be dismayed, for Yahweh your God#1:9 The Hebrew word rendered “God” is “אֱלֹהִ֑ים” (Elohim). is with you wherever you go.” [^9] Then Joshua commanded the officers of the people, saying, [^10] “Pass through the middle of the camp, and command the people, saying, ‘Prepare food; for within three days you are to pass over this Jordan, to go in to possess the land which Yahweh your God gives you to possess.’” [^11] Joshua spoke to the Reubenites, and to the Gadites, and to the half-tribe of Manasseh, saying, [^12] “Remember the word which Moses the servant of Yahweh commanded you, saying, ‘Yahweh your God gives you rest, and will give you this land. [^13] Your wives, your little ones, and your livestock shall live in the land which Moses gave you beyond the Jordan; but you shall pass over before your brothers armed, all the mighty men of valor, and shall help them [^14] until Yahweh has given your brothers rest, as he has given you, and they have also possessed the land which Yahweh your God gives them. Then you shall return to the land of your possession and possess it, which Moses the servant of Yahweh gave you beyond the Jordan toward the sunrise.’” [^15] They answered Joshua, saying, “All that you have commanded us we will do, and wherever you send us we will go. [^16] Just as we listened to Moses in all things, so will we listen to you. Only may Yahweh your God be with you, as he was with Moses. [^17] Whoever rebels against your commandment, and doesn’t listen to your words in all that you command him shall himself be put to death. Only be strong and courageous.” [^18] 

Joshua - 1 [[Joshua - 2|-->]]

---
# Notes
