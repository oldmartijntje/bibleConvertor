---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 3 - World English Bible"
---
[[Joshua - 2|<--]] Joshua - 3 [[Joshua - 4|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Joshua]]

# Joshua - 3

Joshua got up early in the morning; and they moved from Shittim and came to the Jordan, he and all the children of Israel. They camped there before they crossed over. [^1] After three days, the officers went through the middle of the camp; [^2] and they commanded the people, saying, “When you see the ark of Yahweh your God’s covenant, and the Levitical priests bearing it, then leave your place and follow it. [^3] Yet there shall be a space between you and it of about two thousand cubits#3:4 A cubit is the length from the tip of the middle finger to the elbow on a man’s arm, or about 18 inches or 46 centimeters, so 2,000 cubits is about 920 meters. by measure—don’t come closer to it—that you may know the way by which you must go; for you have not passed this way before.” [^4] Joshua said to the people, “Sanctify yourselves; for tomorrow Yahweh will do wonders among you.” [^5] Joshua spoke to the priests, saying, “Take up the ark of the covenant, and cross over before the people.” They took up the ark of the covenant, and went before the people. [^6] Yahweh said to Joshua, “Today I will begin to magnify you in the sight of all Israel, that they may know that as I was with Moses, so I will be with you. [^7] You shall command the priests who bear the ark of the covenant, saying, ‘When you come to the brink of the waters of the Jordan, you shall stand still in the Jordan.’” [^8] Joshua said to the children of Israel, “Come here, and hear the words of Yahweh your God.” [^9] Joshua said, “By this you shall know that the living God is among you, and that he will without fail drive the Canaanite, the Hittite, the Hivite, the Perizzite, the Girgashite, the Amorite, and the Jebusite out from before you. [^10] Behold, the ark of the covenant of the Lord#3:11 The word translated “Lord” is “Adonai.” of all the earth passes over before you into the Jordan. [^11] Now therefore take twelve men out of the tribes of Israel, for every tribe a man. [^12] It shall be that when the soles of the feet of the priests who bear the ark of Yahweh, the Lord of all the earth, rest in the waters of the Jordan, that the waters of the Jordan will be cut off. The waters that come down from above shall stand in one heap.” [^13] When the people moved from their tents to pass over the Jordan, the priests who bore the ark of the covenant being before the people, [^14] and when those who bore the ark had come to the Jordan, and the feet of the priests who bore the ark had dipped in the edge of the water (for the Jordan overflows all its banks all the time of harvest), [^15] the waters which came down from above stood, and rose up in one heap a great way off, at Adam, the city that is beside Zarethan; and those that went down toward the sea of the Arabah, even the Salt Sea, were wholly cut off. Then the people passed over near Jericho. [^16] The priests who bore the ark of Yahweh’s covenant stood firm on dry ground in the middle of the Jordan; and all Israel crossed over on dry ground, until all the nation had passed completely over the Jordan. [^17] 

[[Joshua - 2|<--]] Joshua - 3 [[Joshua - 4|-->]]

---
# Notes
