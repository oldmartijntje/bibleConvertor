---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 5 - World English Bible"
---
[[Joshua - 4|<--]] Joshua - 5 [[Joshua - 6|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Joshua]]

# Joshua - 5

When all the kings of the Amorites, who were beyond the Jordan westward, and all the kings of the Canaanites, who were by the sea, heard how Yahweh had dried up the waters of the Jordan from before the children of Israel until we had crossed over, their heart melted, and there was no more spirit in them, because of the children of Israel. [^1] At that time, Yahweh said to Joshua, “Make flint knives, and circumcise again the sons of Israel the second time.” [^2] Joshua made himself flint knives, and circumcised the sons of Israel at the hill of the foreskins. [^3] This is the reason Joshua circumcised them: all the people who came out of Egypt, who were males, even all the men of war, died in the wilderness along the way, after they came out of Egypt. [^4] For all the people who came out were circumcised; but all the people who were born in the wilderness along the way as they came out of Egypt had not been circumcised. [^5] For the children of Israel walked forty years in the wilderness until all the nation, even the men of war who came out of Egypt, were consumed, because they didn’t listen to Yahweh’s voice. Yahweh swore to them that he wouldn’t let them see the land which Yahweh swore to their fathers that he would give us, a land flowing with milk and honey. [^6] Their children, whom he raised up in their place, were circumcised by Joshua, for they were uncircumcised, because they had not circumcised them on the way. [^7] When they were done circumcising the whole nation, they stayed in their places in the camp until they were healed. [^8] Yahweh said to Joshua, “Today I have rolled away the reproach of Egypt from you.” Therefore the name of that place was called Gilgal#5:9 “Gilgal” sounds like the Hebrew for “roll.” to this day. [^9] The children of Israel encamped in Gilgal. They kept the Passover on the fourteenth day of the month at evening in the plains of Jericho. [^10] They ate unleavened cakes and parched grain of the produce of the land on the next day after the Passover, in the same day. [^11] The manna ceased on the next day, after they had eaten of the produce of the land. The children of Israel didn’t have manna any more, but they ate of the fruit of the land of Canaan that year. [^12] When Joshua was by Jericho, he lifted up his eyes and looked, and behold, a man stood in front of him with his sword drawn in his hand. Joshua went to him and said to him, “Are you for us, or for our enemies?” [^13] He said, “No; but I have come now as commander of Yahweh’s army.”Joshua fell on his face to the earth, and worshiped, and asked him, “What does my lord say to his servant?” [^14] The prince of Yahweh’s army said to Joshua, “Take off your sandals, for the place on which you stand is holy.” Joshua did so. [^15] 

[[Joshua - 4|<--]] Joshua - 5 [[Joshua - 6|-->]]

---
# Notes
