---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_kings"
  - "#bible/testament/old"
aliases:
  - "1 Kings - 5 - World English Bible"
---
[[1 Kings - 4|<--]] 1 Kings - 5 [[1 Kings - 6|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[1 Kings]]

# 1 Kings - 5

Hiram king of Tyre sent his servants to Solomon, for he had heard that they had anointed him king in the place of his father, and Hiram had always loved David. [^1] Solomon sent to Hiram, saying, [^2] “You know that David my father could not build a house for the name of Yahweh his God because of the wars which were around him on every side, until Yahweh put his enemies under the soles of his feet. [^3] But now Yahweh my God has given me rest on every side. There is no enemy and no evil occurrence. [^4] Behold, I intend to build a house for the name of Yahweh my God, as Yahweh spoke to David my father, saying, ‘Your son, whom I will set on your throne in your place shall build the house for my name.’ [^5] Now therefore command that cedar trees be cut for me out of Lebanon. My servants will be with your servants; and I will give you wages for your servants according to all that you say. For you know that there is nobody among us who knows how to cut timber like the Sidonians.” [^6] When Hiram heard the words of Solomon, he rejoiced greatly, and said, “Blessed is Yahweh today, who has given to David a wise son to rule over this great people.” [^7] Hiram sent to Solomon, saying, “I have heard the message which you have sent to me. I will do all your desire concerning timber of cedar, and concerning cypress timber. [^8] My servants will bring them down from Lebanon to the sea. I will make them into rafts to go by sea to the place that you specify to me, and will cause them to be broken up there, and you will receive them. You will accomplish my desire, in giving food for my household.” [^9] So Hiram gave Solomon cedar timber and cypress timber according to all his desire. [^10] Solomon gave Hiram twenty thousand cors#5:11 20,000 cors would be about 120,000 bushels or about 4.2 megaliters of wheat, which would weigh about 3,270 metric tons. of wheat for food to his household, and twenty cors#5:11 20 cors is about 1,100 gallons or about 4220 liters. of pure oil. Solomon gave this to Hiram year by year. [^11] Yahweh gave Solomon wisdom, as he promised him. There was peace between Hiram and Solomon, and the two of them made a treaty together. [^12] King Solomon raised a levy out of all Israel; and the levy was thirty thousand men. [^13] He sent them to Lebanon, ten thousand a month by courses: for a month they were in Lebanon, and two months at home; and Adoniram was over the men subject to forced labor. [^14] Solomon had seventy thousand who bore burdens, and eighty thousand who were stone cutters in the mountains, [^15] besides Solomon’s chief officers who were over the work: three thousand three hundred who ruled over the people who labored in the work. [^16] The king commanded, and they cut out large stones, costly stones, to lay the foundation of the house with worked stone. [^17] Solomon’s builders and Hiram’s builders and the Gebalites cut them, and prepared the timber and the stones to build the house. [^18] 

[[1 Kings - 4|<--]] 1 Kings - 5 [[1 Kings - 6|-->]]

---
# Notes
