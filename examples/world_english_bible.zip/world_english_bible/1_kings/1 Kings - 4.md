---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_kings"
  - "#bible/testament/old"
aliases:
  - "1 Kings - 4 - World English Bible"
---
[[1 Kings - 3|<--]] 1 Kings - 4 [[1 Kings - 5|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[1 Kings]]

# 1 Kings - 4

King Solomon was king over all Israel. [^1] These were the princes whom he had: Azariah the son of Zadok, the priest; [^2] Elihoreph and Ahijah, the sons of Shisha, scribes; Jehoshaphat the son of Ahilud, the recorder; [^3] Benaiah the son of Jehoiada was over the army; Zadok and Abiathar were priests; [^4] Azariah the son of Nathan was over the officers; Zabud the son of Nathan was chief minister, the king’s friend; [^5] Ahishar was over the household; and Adoniram the son of Abda was over the men subject to forced labor. [^6] Solomon had twelve officers over all Israel, who provided food for the king and his household. Each man had to make provision for a month in the year. [^7] These are their names: Ben Hur, in the hill country of Ephraim; [^8] Ben Deker, in Makaz, in Shaalbim, Beth Shemesh, and Elon Beth Hanan; [^9] Ben Hesed, in Arubboth (Socoh and all the land of Hepher belonged to him); [^10] Ben Abinadab, in all the height of Dor (he had Taphath, Solomon’s daughter, as wife); [^11] Baana the son of Ahilud, in Taanach and Megiddo, and all Beth Shean which is beside Zarethan, beneath Jezreel, from Beth Shean to Abel Meholah, as far as beyond Jokmeam; [^12] Ben Geber, in Ramoth Gilead (the towns of Jair the son of Manasseh, which are in Gilead, belonged to him; and the region of Argob, which is in Bashan, sixty great cities with walls and bronze bars, belonged to him); [^13] Ahinadab the son of Iddo, in Mahanaim; [^14] Ahimaaz, in Naphtali (he also took Basemath the daughter of Solomon as wife); [^15] Baana the son of Hushai, in Asher and Bealoth; [^16] Jehoshaphat the son of Paruah, in Issachar; [^17] Shimei the son of Ela, in Benjamin; [^18] Geber the son of Uri, in the land of Gilead, the country of Sihon king of the Amorites and of Og king of Bashan; and he was the only officer who was in the land. [^19] Judah and Israel were numerous as the sand which is by the sea in multitude, eating and drinking and making merry. [^20] Solomon ruled over all the kingdoms from the River to the land of the Philistines, and to the border of Egypt. They brought tribute and served Solomon all the days of his life. [^21] Solomon’s provision for one day was thirty cors#4:22 1 cor is the same as a homer, or about 55.9 U. S. gallons (liquid) or 211 liters or 6 bushels of fine flour, sixty measures of meal, [^22] ten head of fat cattle, twenty head of cattle out of the pastures, and one hundred sheep, in addition to deer, gazelles, roebucks, and fattened fowl. [^23] For he had dominion over all on this side of the River, from Tiphsah even to Gaza, over all the kings on this side of the River; and he had peace on all sides around him. [^24] Judah and Israel lived safely, every man under his vine and under his fig tree, from Dan even to Beersheba, all the days of Solomon. [^25] Solomon had forty thousand stalls of horses for his chariots, and twelve thousand horsemen. [^26] Those officers provided food for King Solomon, and for all who came to King Solomon’s table, every man in his month. They let nothing be lacking. [^27] They also brought barley and straw for the horses and swift steeds to the place where the officers were, each man according to his duty. [^28] God gave Solomon abundant wisdom, understanding, and breadth of mind like the sand that is on the seashore. [^29] Solomon’s wisdom excelled the wisdom of all the children of the east and all the wisdom of Egypt. [^30] For he was wiser than all men—wiser than Ethan the Ezrahite, Heman, Calcol, and Darda, the sons of Mahol; and his fame was in all the nations all around. [^31] He spoke three thousand proverbs, and his songs numbered one thousand five. [^32] He spoke of trees, from the cedar that is in Lebanon even to the hyssop that grows out of the wall; he also spoke of animals, of birds, of creeping things, and of fish. [^33] People of all nations came to hear the wisdom of Solomon, sent by all kings of the earth who had heard of his wisdom. [^34] 

[[1 Kings - 3|<--]] 1 Kings - 4 [[1 Kings - 5|-->]]

---
# Notes
