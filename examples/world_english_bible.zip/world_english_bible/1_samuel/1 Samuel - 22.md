---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 22 - World English Bible"
---
[[1 Samuel - 21|<--]] 1 Samuel - 22 [[1 Samuel - 23|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[1 Samuel]]

# 1 Samuel - 22

David therefore departed from there and escaped to Adullam’s cave. When his brothers and all his father’s house heard it, they went down there to him. [^1] Everyone who was in distress, everyone who was in debt, and everyone who was discontented gathered themselves to him; and he became captain over them. There were with him about four hundred men. [^2] David went from there to Mizpeh of Moab; and he said to the king of Moab, “Please let my father and my mother come out to you, until I know what God will do for me.” [^3] He brought them before the king of Moab; and they lived with him all the time that David was in the stronghold. [^4] The prophet Gad said to David, “Don’t stay in the stronghold. Depart, and go into the land of Judah.”Then David departed, and came into the forest of Hereth. [^5] Saul heard that David was discovered, with the men who were with him. Now Saul was sitting in Gibeah, under the tamarisk tree in Ramah, with his spear in his hand, and all his servants were standing around him. [^6] Saul said to his servants who stood around him, “Hear now, you Benjamites! Will the son of Jesse give everyone of you fields and vineyards? Will he make you all captains of thousands and captains of hundreds? [^7] Is that why all of you have conspired against me, and there is no one who discloses to me when my son makes a treaty with the son of Jesse, and there is none of you who is sorry for me, or discloses to me that my son has stirred up my servant against me, to lie in wait, as it is today?” [^8] Then Doeg the Edomite, who stood by the servants of Saul, answered and said, “I saw the son of Jesse coming to Nob, to Ahimelech the son of Ahitub. [^9] He inquired of Yahweh for him, gave him food, and gave him the sword of Goliath the Philistine.” [^10] Then the king sent to call Ahimelech the priest, the son of Ahitub, and all his father’s house, the priests who were in Nob; and they all came to the king. [^11] Saul said, “Hear now, you son of Ahitub.”He answered, “Here I am, my lord.” [^12] Saul said to him, “Why have you conspired against me, you and the son of Jesse, in that you have given him bread, and a sword, and have inquired of God for him, that he should rise against me, to lie in wait, as it is today?” [^13] Then Ahimelech answered the king, and said, “Who among all your servants is so faithful as David, who is the king’s son-in-law, captain of your body guard, and honored in your house? [^14] Have I today begun to inquire of God for him? Be it far from me! Don’t let the king impute anything to his servant, nor to all the house of my father; for your servant knew nothing of all this, less or more.” [^15] The king said, “You shall surely die, Ahimelech, you and all your father’s house.” [^16] The king said to the guard who stood about him, “Turn and kill the priests of Yahweh, because their hand also is with David, and because they knew that he fled and didn’t disclose it to me.” But the servants of the king wouldn’t put out their hand to fall on the priests of Yahweh. [^17] The king said to Doeg, “Turn and attack the priests!”Doeg the Edomite turned, and he attacked the priests, and he killed on that day eighty-five people who wore a linen ephod. [^18] He struck Nob, the city of the priests, with the edge of the sword—both men and women, children and nursing babies, and cattle, donkeys, and sheep, with the edge of the sword. [^19] One of the sons of Ahimelech the son of Ahitub, named Abiathar, escaped and fled after David. [^20] Abiathar told David that Saul had slain Yahweh’s priests. [^21] David said to Abiathar, “I knew on that day, when Doeg the Edomite was there, that he would surely tell Saul. I am responsible for the death of all the persons of your father’s house. [^22] Stay with me. Don’t be afraid, for he who seeks my life seeks your life. You will be safe with me.” [^23] 

[[1 Samuel - 21|<--]] 1 Samuel - 22 [[1 Samuel - 23|-->]]

---
# Notes
