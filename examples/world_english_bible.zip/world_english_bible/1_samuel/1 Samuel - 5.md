---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 5 - World English Bible"
---
[[1 Samuel - 4|<--]] 1 Samuel - 5 [[1 Samuel - 6|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[1 Samuel]]

# 1 Samuel - 5

Now the Philistines had taken God’s ark, and they brought it from Ebenezer to Ashdod. [^1] The Philistines took God’s ark, and brought it into the house of Dagon and set it by Dagon. [^2] When the people of Ashdod arose early on the next day, behold, Dagon had fallen on his face to the ground before Yahweh’s ark. They took Dagon and set him in his place again. [^3] When they arose early on the following morning, behold, Dagon had fallen on his face to the ground before Yahweh’s ark; and the head of Dagon and both the palms of his hands were cut off on the threshold. Only Dagon’s torso was intact. [^4] Therefore neither the priests of Dagon nor any who come into Dagon’s house step on the threshold of Dagon in Ashdod to this day. [^5] But Yahweh’s hand was heavy on the people of Ashdod, and he destroyed them and struck them with tumors, even Ashdod and its borders. [^6] When the men of Ashdod saw that it was so, they said, “The ark of the God of Israel shall not stay with us, for his hand is severe on us and on Dagon our god.” [^7] They sent therefore and gathered together all the lords of the Philistines, and said, “What shall we do with the ark of the God of Israel?”They answered, “Let the ark of the God of Israel be carried over to Gath.” They carried the ark of the God of Israel there. [^8] It was so, that after they had carried it there, Yahweh’s hand was against the city with a very great confusion; and he struck the men of the city, both small and great, so that tumors broke out on them. [^9] So they sent God’s ark to Ekron.As God’s ark came to Ekron, the Ekronites cried out, saying, “They have brought the ark of the God of Israel here to us, to kill us and our people.” [^10] They sent therefore and gathered together all the lords of the Philistines, and they said, “Send the ark of the God of Israel away, and let it go again to its own place, that it not kill us and our people.” For there was a deadly panic throughout all the city. The hand of God was very heavy there. [^11] The men who didn’t die were struck with the tumors; and the cry of the city went up to heaven. [^12] 

[[1 Samuel - 4|<--]] 1 Samuel - 5 [[1 Samuel - 6|-->]]

---
# Notes
