---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 29 - World English Bible"
---
[[1 Samuel - 28|<--]] 1 Samuel - 29 [[1 Samuel - 30|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[1 Samuel]]

# 1 Samuel - 29

Now the Philistines gathered together all their armies to Aphek; and the Israelites encamped by the spring which is in Jezreel. [^1] The lords of the Philistines passed on by hundreds and by thousands; and David and his men passed on in the rear with Achish. [^2] Then the princes of the Philistines said, “What about these Hebrews?”Achish said to the princes of the Philistines, “Isn’t this David, the servant of Saul the king of Israel, who has been with me these days, or rather these years? I have found no fault in him since he fell away until today.” [^3] But the princes of the Philistines were angry with him; and the princes of the Philistines said to him, “Make the man return, that he may go back to his place where you have appointed him, and let him not go down with us to battle, lest in the battle he become an adversary to us. For with what should this fellow reconcile himself to his lord? Should it not be with the heads of these men? [^4] Isn’t this David, of whom people sang to one another in dances, saying,‘Saul has slain his thousands,and David his ten thousands’?” [^5] Then Achish called David and said to him, “As Yahweh lives, you have been upright, and your going out and your coming in with me in the army is good in my sight; for I have not found evil in you since the day of your coming to me to this day. Nevertheless, the lords don’t favor you. [^6] Therefore now return, and go in peace, that you not displease the lords of the Philistines.” [^7] David said to Achish, “But what have I done? What have you found in your servant so long as I have been before you to this day, that I may not go and fight against the enemies of my lord the king?” [^8] Achish answered David, “I know that you are good in my sight, as an angel of God. Notwithstanding, the princes of the Philistines have said, ‘He shall not go up with us to the battle.’ [^9] Therefore now rise up early in the morning with the servants of your lord who have come with you; and as soon as you are up early in the morning and have light, depart.” [^10] So David rose up early, he and his men, to depart in the morning, to return into the land of the Philistines; and the Philistines went up to Jezreel. [^11] 

[[1 Samuel - 28|<--]] 1 Samuel - 29 [[1 Samuel - 30|-->]]

---
# Notes
