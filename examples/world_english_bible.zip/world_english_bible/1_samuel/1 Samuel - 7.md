---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 7 - World English Bible"
---
[[1 Samuel - 6|<--]] 1 Samuel - 7 [[1 Samuel - 8|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[1 Samuel]]

# 1 Samuel - 7

The men of Kiriath Jearim came and took Yahweh’s ark, and brought it into Abinadab’s house on the hill, and consecrated Eleazar his son to keep Yahweh’s ark. [^1] From the day that the ark stayed in Kiriath Jearim, the time was long—for it was twenty years; and all the house of Israel lamented after Yahweh. [^2] Samuel spoke to all the house of Israel, saying, “If you are returning to Yahweh with all your heart, then put away the foreign gods and the Ashtaroth from among you, and direct your hearts to Yahweh, and serve him only; and he will deliver you out of the hand of the Philistines.” [^3] Then the children of Israel removed the Baals and the Ashtaroth, and served Yahweh only. [^4] Samuel said, “Gather all Israel to Mizpah, and I will pray to Yahweh for you.” [^5] They gathered together to Mizpah, and drew water, and poured it out before Yahweh, and fasted on that day, and said there, “We have sinned against Yahweh.” Samuel judged the children of Israel in Mizpah. [^6] When the Philistines heard that the children of Israel were gathered together at Mizpah, the lords of the Philistines went up against Israel. When the children of Israel heard it, they were afraid of the Philistines. [^7] The children of Israel said to Samuel, “Don’t stop crying to Yahweh our God for us, that he will save us out of the hand of the Philistines.” [^8] Samuel took a suckling lamb, and offered it for a whole burnt offering to Yahweh. Samuel cried to Yahweh for Israel, and Yahweh answered him. [^9] As Samuel was offering up the burnt offering, the Philistines came near to battle against Israel; but Yahweh thundered with a great thunder on that day on the Philistines and confused them; and they were struck down before Israel. [^10] The men of Israel went out of Mizpah and pursued the Philistines, and struck them until they came under Beth Kar. [^11] Then Samuel took a stone and set it between Mizpah and Shen, and called its name Ebenezer,#7:12 “Ebenezer” means “stone of help”. saying, “Yahweh helped us until now.” [^12] So the Philistines were subdued, and they stopped coming within the border of Israel. Yahweh’s hand was against the Philistines all the days of Samuel. [^13] The cities which the Philistines had taken from Israel were restored to Israel, from Ekron even to Gath; and Israel recovered its border out of the hand of the Philistines. There was peace between Israel and the Amorites. [^14] Samuel judged Israel all the days of his life. [^15] He went from year to year in a circuit to Bethel, Gilgal, and Mizpah; and he judged Israel in all those places. [^16] His return was to Ramah, for his house was there, and he judged Israel there; and he built an altar to Yahweh there. [^17] 

[[1 Samuel - 6|<--]] 1 Samuel - 7 [[1 Samuel - 8|-->]]

---
# Notes
