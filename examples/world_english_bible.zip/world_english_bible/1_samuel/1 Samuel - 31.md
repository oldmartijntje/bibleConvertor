---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 31 - World English Bible"
---
[[1 Samuel - 30|<--]] 1 Samuel - 31

Translation: [[bible - World English Bible|World English Bible]]
Book: [[1 Samuel]]

# 1 Samuel - 31

Now the Philistines fought against Israel; and the men of Israel fled from before the Philistines, and fell down slain on Mount Gilboa. [^1] The Philistines overtook Saul and his sons; and the Philistines killed Jonathan, Abinadab, and Malchishua, the sons of Saul. [^2] The battle went hard against Saul, and the archers overtook him; and he was greatly distressed by reason of the archers. [^3] Then Saul said to his armor bearer, “Draw your sword, and thrust me through with it, lest these uncircumcised come and thrust me through and abuse me!” But his armor bearer would not, for he was terrified. Therefore Saul took his sword and fell on it. [^4] When his armor bearer saw that Saul was dead, he likewise fell on his sword, and died with him. [^5] So Saul died with his three sons, his armor bearer, and all his men that same day together. [^6] When the men of Israel who were on the other side of the valley, and those who were beyond the Jordan, saw that the men of Israel fled and that Saul and his sons were dead, they abandoned the cities and fled; and the Philistines came and lived in them. [^7] On the next day, when the Philistines came to strip the slain, they found Saul and his three sons fallen on Mount Gilboa. [^8] They cut off his head, stripped off his armor, and sent into the land of the Philistines all around, to carry the news to the house of their idols and to the people. [^9] They put his armor in the house of the Ashtaroth, and they fastened his body to the wall of Beth Shan. [^10] When the inhabitants of Jabesh Gilead heard what the Philistines had done to Saul, [^11] all the valiant men arose, went all night, and took the body of Saul and the bodies of his sons from the wall of Beth Shan; and they came to Jabesh and burned them there. [^12] They took their bones and buried them under the tamarisk#31:13 or, salt cedar tree in Jabesh, and fasted seven days. [^13] 

[[1 Samuel - 30|<--]] 1 Samuel - 31

---
# Notes
