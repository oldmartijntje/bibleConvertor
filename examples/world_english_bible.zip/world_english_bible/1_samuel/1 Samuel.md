---
translation: World English Bible
aliases:
  - "1 Samuel - World English Bible"
tags:
  - "#bible/type/book"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
---
[[Ruth|<--]] 1 Samuel [[2 Samuel|-->]]

# 1 Samuel - World English Bible

The 1 Samuel book has 31 chapters. It is part of the old testament.

## Chapters

- 1 Samuel [[1 Samuel - 1|chapter 1]]
- 1 Samuel [[1 Samuel - 2|chapter 2]]
- 1 Samuel [[1 Samuel - 3|chapter 3]]
- 1 Samuel [[1 Samuel - 4|chapter 4]]
- 1 Samuel [[1 Samuel - 5|chapter 5]]
- 1 Samuel [[1 Samuel - 6|chapter 6]]
- 1 Samuel [[1 Samuel - 7|chapter 7]]
- 1 Samuel [[1 Samuel - 8|chapter 8]]
- 1 Samuel [[1 Samuel - 9|chapter 9]]
- 1 Samuel [[1 Samuel - 10|chapter 10]]
- 1 Samuel [[1 Samuel - 11|chapter 11]]
- 1 Samuel [[1 Samuel - 12|chapter 12]]
- 1 Samuel [[1 Samuel - 13|chapter 13]]
- 1 Samuel [[1 Samuel - 14|chapter 14]]
- 1 Samuel [[1 Samuel - 15|chapter 15]]
- 1 Samuel [[1 Samuel - 16|chapter 16]]
- 1 Samuel [[1 Samuel - 17|chapter 17]]
- 1 Samuel [[1 Samuel - 18|chapter 18]]
- 1 Samuel [[1 Samuel - 19|chapter 19]]
- 1 Samuel [[1 Samuel - 20|chapter 20]]
- 1 Samuel [[1 Samuel - 21|chapter 21]]
- 1 Samuel [[1 Samuel - 22|chapter 22]]
- 1 Samuel [[1 Samuel - 23|chapter 23]]
- 1 Samuel [[1 Samuel - 24|chapter 24]]
- 1 Samuel [[1 Samuel - 25|chapter 25]]
- 1 Samuel [[1 Samuel - 26|chapter 26]]
- 1 Samuel [[1 Samuel - 27|chapter 27]]
- 1 Samuel [[1 Samuel - 28|chapter 28]]
- 1 Samuel [[1 Samuel - 29|chapter 29]]
- 1 Samuel [[1 Samuel - 30|chapter 30]]
- 1 Samuel [[1 Samuel - 31|chapter 31]]

[[Ruth|<--]] 1 Samuel [[2 Samuel|-->]]

---
# Notes
