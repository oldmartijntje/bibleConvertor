---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 12 - World English Bible"
---
[[1 Samuel - 11|<--]] 1 Samuel - 12 [[1 Samuel - 13|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[1 Samuel]]

# 1 Samuel - 12

Samuel said to all Israel, “Behold, I have listened to your voice in all that you said to me, and have made a king over you. [^1] Now, behold, the king walks before you. I am old and gray-headed. Behold, my sons are with you. I have walked before you from my youth to this day. [^2] Here I am. Witness against me before Yahweh and before his anointed. Whose ox have I taken? Whose donkey have I taken? Whom have I defrauded? Whom have I oppressed? Of whose hand have I taken a bribe to make me blind my eyes? I will restore it to you.” [^3] They said, “You have not defrauded us, nor oppressed us, neither have you taken anything from anyone’s hand.” [^4] He said to them, “Yahweh is witness against you, and his anointed is witness today, that you have not found anything in my hand.”They said, “He is witness.” [^5] Samuel said to the people, “It is Yahweh who appointed Moses and Aaron, and that brought your fathers up out of the land of Egypt. [^6] Now therefore stand still, that I may plead with you before Yahweh concerning all the righteous acts of Yahweh, which he did to you and to your fathers. [^7] “When Jacob had come into Egypt, and your fathers cried to Yahweh, then Yahweh sent Moses and Aaron, who brought your fathers out of Egypt, and made them to dwell in this place. [^8] But they forgot Yahweh their God; and he sold them into the hand of Sisera, captain of the army of Hazor, and into the hand of the Philistines, and into the hand of the king of Moab; and they fought against them. [^9] They cried to Yahweh, and said, ‘We have sinned, because we have forsaken Yahweh and have served the Baals and the Ashtaroth; but now deliver us out of the hand of our enemies, and we will serve you.’ [^10] Yahweh sent Jerubbaal, Bedan, Jephthah, and Samuel, and delivered you out of the hand of your enemies on every side; and you lived in safety. [^11] “When you saw that Nahash the king of the children of Ammon came against you, you said to me, ‘No, but a king shall reign over us,’ when Yahweh your God was your king. [^12] Now therefore see the king whom you have chosen and whom you have asked for. Behold, Yahweh has set a king over you. [^13] If you will fear Yahweh, and serve him, and listen to his voice, and not rebel against the commandment of Yahweh, then both you and also the king who reigns over you are followers of Yahweh your God. [^14] But if you will not listen to Yahweh’s voice, but rebel against the commandment of Yahweh, then Yahweh’s hand will be against you, as it was against your fathers. [^15] “Now therefore stand still and see this great thing, which Yahweh will do before your eyes. [^16] Isn’t it wheat harvest today? I will call to Yahweh, that he may send thunder and rain; and you will know and see that your wickedness is great, which you have done in Yahweh’s sight, in asking for a king.” [^17] So Samuel called to Yahweh, and Yahweh sent thunder and rain that day. Then all the people greatly feared Yahweh and Samuel. [^18] All the people said to Samuel, “Pray for your servants to Yahweh your God, that we not die; for we have added to all our sins this evil, to ask for a king.” [^19] Samuel said to the people, “Don’t be afraid. You have indeed done all this evil; yet don’t turn away from following Yahweh, but serve Yahweh with all your heart. [^20] Don’t turn away to go after vain things which can’t profit or deliver, for they are vain. [^21] For Yahweh will not forsake his people for his great name’s sake, because it has pleased Yahweh to make you a people for himself. [^22] Moreover, as for me, far be it from me that I should sin against Yahweh in ceasing to pray for you; but I will instruct you in the good and the right way. [^23] Only fear Yahweh, and serve him in truth with all your heart; for consider what great things he has done for you. [^24] But if you keep doing evil, you will be consumed, both you and your king.” [^25] 

[[1 Samuel - 11|<--]] 1 Samuel - 12 [[1 Samuel - 13|-->]]

---
# Notes
