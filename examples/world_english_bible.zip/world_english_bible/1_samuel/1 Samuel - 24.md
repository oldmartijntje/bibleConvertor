---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 24 - World English Bible"
---
[[1 Samuel - 23|<--]] 1 Samuel - 24 [[1 Samuel - 25|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[1 Samuel]]

# 1 Samuel - 24

When Saul had returned from following the Philistines, he was told, “Behold, David is in the wilderness of En Gedi.” [^1] Then Saul took three thousand chosen men out of all Israel, and went to seek David and his men on the rocks of the wild goats. [^2] He came to the sheep pens by the way, where there was a cave; and Saul went in to relieve himself. Now David and his men were staying in the innermost parts of the cave. [^3] David’s men said to him, “Behold, the day of which Yahweh said to you, ‘Behold, I will deliver your enemy into your hand, and you shall do to him as it shall seem good to you.’” Then David arose and cut off the skirt of Saul’s robe secretly. [^4] Afterward, David’s heart struck him because he had cut off Saul’s skirt. [^5] He said to his men, “Yahweh forbid that I should do this thing to my lord, Yahweh’s anointed, to stretch out my hand against him, since he is Yahweh’s anointed.” [^6] So David checked his men with these words, and didn’t allow them to rise against Saul. Saul rose up out of the cave, and went on his way. [^7] David also arose afterward, and went out of the cave and cried after Saul, saying, “My lord the king!”When Saul looked behind him, David bowed with his face to the earth, and showed respect. [^8] David said to Saul, “Why do you listen to men’s words, saying, ‘Behold, David seeks to harm you’? [^9] Behold, today your eyes have seen how Yahweh had delivered you today into my hand in the cave. Some urged me to kill you, but I spared you. I said, ‘I will not stretch out my hand against my lord, for he is Yahweh’s anointed.’ [^10] Moreover, my father, behold, yes, see the skirt of your robe in my hand; for in that I cut off the skirt of your robe and didn’t kill you, know and see that there is neither evil nor disobedience in my hand. I have not sinned against you, though you hunt for my life to take it. [^11] May Yahweh judge between me and you, and may Yahweh avenge me of you; but my hand will not be on you. [^12] As the proverb of the ancients says, ‘Out of the wicked comes wickedness;’ but my hand will not be on you. [^13] Against whom has the king of Israel come out? Whom do you pursue? A dead dog? A flea? [^14] May Yahweh therefore be judge, and give sentence between me and you, and see, and plead my cause, and deliver me out of your hand.” [^15] It came to pass, when David had finished speaking these words to Saul, that Saul said, “Is that your voice, my son David?” Saul lifted up his voice and wept. [^16] He said to David, “You are more righteous than I; for you have done good to me, whereas I have done evil to you. [^17] You have declared today how you have dealt well with me, because when Yahweh had delivered me up into your hand, you didn’t kill me. [^18] For if a man finds his enemy, will he let him go away unharmed? Therefore may Yahweh reward you good for that which you have done to me today. [^19] Now, behold, I know that you will surely be king, and that the kingdom of Israel will be established in your hand. [^20] Swear now therefore to me by Yahweh that you will not cut off my offspring after me, and that you will not destroy my name out of my father’s house.” [^21] David swore to Saul. Saul went home, but David and his men went up to the stronghold. [^22] 

[[1 Samuel - 23|<--]] 1 Samuel - 24 [[1 Samuel - 25|-->]]

---
# Notes
