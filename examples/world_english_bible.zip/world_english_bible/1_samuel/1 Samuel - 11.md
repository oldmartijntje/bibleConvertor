---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 11 - World English Bible"
---
[[1 Samuel - 10|<--]] 1 Samuel - 11 [[1 Samuel - 12|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[1 Samuel]]

# 1 Samuel - 11

Then Nahash the Ammonite came up and encamped against Jabesh Gilead; and all the men of Jabesh said to Nahash, “Make a covenant with us, and we will serve you.” [^1] Nahash the Ammonite said to them, “On this condition I will make it with you, that all your right eyes be gouged out. I will make this dishonor all Israel.” [^2] The elders of Jabesh said to him, “Give us seven days, that we may send messengers to all the borders of Israel; and then, if there is no one to save us, we will come out to you.” [^3] Then the messengers came to Gibeah of Saul, and spoke these words in the ears of the people, then all the people lifted up their voice and wept. [^4] Behold, Saul came following the oxen out of the field; and Saul said, “What ails the people that they weep?” They told him the words of the men of Jabesh. [^5] God’s Spirit came mightily on Saul when he heard those words, and his anger burned hot. [^6] He took a yoke of oxen and cut them in pieces, then sent them throughout all the borders of Israel by the hand of messengers, saying, “Whoever doesn’t come out after Saul and after Samuel, so shall it be done to his oxen.” The dread of Yahweh fell on the people, and they came out as one man. [^7] He counted them in Bezek; and the children of Israel were three hundred thousand, and the men of Judah thirty thousand. [^8] They said to the messengers who came, “Tell the men of Jabesh Gilead, ‘Tomorrow, by the time the sun is hot, you will be rescued.’” The messengers came and told the men of Jabesh; and they were glad. [^9] Therefore the men of Jabesh said, “Tomorrow we will come out to you, and you shall do with us all that seems good to you.” [^10] On the next day, Saul put the people in three companies; and they came into the middle of the camp in the morning watch, and struck the Ammonites until the heat of the day. Those who remained were scattered, so that no two of them were left together. [^11] The people said to Samuel, “Who is he who said, ‘Shall Saul reign over us?’ Bring those men, that we may put them to death!” [^12] Saul said, “No man shall be put to death today; for today Yahweh has rescued Israel.” [^13] Then Samuel said to the people, “Come! Let’s go to Gilgal, and renew the kingdom there.” [^14] All the people went to Gilgal; and there they made Saul king before Yahweh in Gilgal. There they offered sacrifices of peace offerings before Yahweh; and there Saul and all the men of Israel rejoiced greatly. [^15] 

[[1 Samuel - 10|<--]] 1 Samuel - 11 [[1 Samuel - 12|-->]]

---
# Notes
