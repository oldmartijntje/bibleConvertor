---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 3 - World English Bible"
---
[[1 Samuel - 2|<--]] 1 Samuel - 3 [[1 Samuel - 4|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[1 Samuel]]

# 1 Samuel - 3

The child Samuel ministered to Yahweh before Eli. Yahweh’s word was rare in those days. There were not many visions, then. [^1] At that time, when Eli was laid down in his place (now his eyes had begun to grow dim, so that he could not see), [^2] and God’s lamp hadn’t yet gone out, and Samuel had laid down in Yahweh’s temple where God’s ark was, [^3] Yahweh called Samuel. He said, “Here I am.” [^4] He ran to Eli and said, “Here I am; for you called me.”He said, “I didn’t call. Lie down again.”He went and lay down. [^5] Yahweh called yet again, “Samuel!”Samuel arose and went to Eli and said, “Here I am; for you called me.”He answered, “I didn’t call, my son. Lie down again.” [^6] Now Samuel didn’t yet know Yahweh, neither was Yahweh’s word yet revealed to him. [^7] Yahweh called Samuel again the third time. He arose and went to Eli and said, “Here I am; for you called me.”Eli perceived that Yahweh had called the child. [^8] Therefore Eli said to Samuel, “Go, lie down. It shall be, if he calls you, that you shall say, ‘Speak, Yahweh; for your servant hears.’” So Samuel went and lay down in his place. [^9] Yahweh came, and stood, and called as at other times, “Samuel! Samuel!”Then Samuel said, “Speak; for your servant hears.” [^10] Yahweh said to Samuel, “Behold, I will do a thing in Israel at which both the ears of everyone who hears it will tingle. [^11] In that day I will perform against Eli all that I have spoken concerning his house, from the beginning even to the end. [^12] For I have told him that I will judge his house forever for the iniquity which he knew, because his sons brought a curse on themselves, and he didn’t restrain them. [^13] Therefore I have sworn to the house of Eli that the iniquity of Eli’s house shall not be removed with sacrifice or offering forever.” [^14] Samuel lay until the morning, and opened the doors of Yahweh’s house. Samuel was afraid to show Eli the vision. [^15] Then Eli called Samuel and said, “Samuel, my son!”He said, “Here I am.” [^16] He said, “What is the thing that he has spoken to you? Please don’t hide it from me. God do so to you, and more also, if you hide anything from me of all the things that he spoke to you.” [^17] Samuel told him every bit, and hid nothing from him.He said, “It is Yahweh. Let him do what seems good to him.” [^18] Samuel grew, and Yahweh was with him and let none of his words fall to the ground. [^19] All Israel from Dan even to Beersheba knew that Samuel was established to be a prophet of Yahweh. [^20] Yahweh appeared again in Shiloh; for Yahweh revealed himself to Samuel in Shiloh by Yahweh’s word. [^21] 

[[1 Samuel - 2|<--]] 1 Samuel - 3 [[1 Samuel - 4|-->]]

---
# Notes
