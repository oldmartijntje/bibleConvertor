---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 4 - World English Bible"
---
[[1 Samuel - 3|<--]] 1 Samuel - 4 [[1 Samuel - 5|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[1 Samuel]]

# 1 Samuel - 4

The word of Samuel came to all Israel.Now Israel went out against the Philistines to battle, and encamped beside Ebenezer; and the Philistines encamped in Aphek. [^1] The Philistines put themselves in array against Israel. When they joined battle, Israel was defeated by the Philistines, who killed about four thousand men of the army in the field. [^2] When the people had come into the camp, the elders of Israel said, “Why has Yahweh defeated us today before the Philistines? Let’s get the ark of Yahweh’s covenant out of Shiloh and bring it to us, that it may come among us and save us out of the hand of our enemies.” [^3] So the people sent to Shiloh, and they brought from there the ark of the covenant of Yahweh of Armies, who sits above the cherubim; and the two sons of Eli, Hophni and Phinehas, were there with the ark of the covenant of God. [^4] When the ark of Yahweh’s covenant came into the camp, all Israel shouted with a great shout, so that the earth resounded. [^5] When the Philistines heard the noise of the shout, they said, “What does the noise of this great shout in the camp of the Hebrews mean?” They understood that Yahweh’s ark had come into the camp. [^6] The Philistines were afraid, for they said, “God has come into the camp.” They said, “Woe to us! For there has not been such a thing before. [^7] Woe to us! Who shall deliver us out of the hand of these mighty gods? These are the gods that struck the Egyptians with all kinds of plagues in the wilderness. [^8] Be strong and behave like men, O you Philistines, that you not be servants to the Hebrews, as they have been to you. Strengthen yourselves like men, and fight!” [^9] The Philistines fought, and Israel was defeated, and each man fled to his tent. There was a very great slaughter; for thirty thousand footmen of Israel fell. [^10] God’s ark was taken; and the two sons of Eli, Hophni and Phinehas, were slain. [^11] A man of Benjamin ran out of the army and came to Shiloh the same day, with his clothes torn and with dirt on his head. [^12] When he came, behold, Eli was sitting on his seat by the road watching, for his heart trembled for God’s ark. When the man came into the city and told about it, all the city cried out. [^13] When Eli heard the noise of the crying, he said, “What does the noise of this tumult mean?”The man hurried, and came and told Eli. [^14] Now Eli was ninety-eight years old. His eyes were set, so that he could not see. [^15] The man said to Eli, “I am he who came out of the army, and I fled today out of the army.”He said, “How did the matter go, my son?” [^16] He who brought the news answered, “Israel has fled before the Philistines, and there has been also a great slaughter among the people. Your two sons also, Hophni and Phinehas, are dead, and God’s ark has been captured.” [^17] When he made mention of God’s ark, Eli fell from off his seat backward by the side of the gate; and his neck broke, and he died, for he was an old man and heavy. He had judged Israel forty years. [^18] His daughter-in-law, Phinehas’ wife, was with child, near to giving birth. When she heard the news that God’s ark was taken and that her father-in-law and her husband were dead, she bowed herself and gave birth; for her pains came on her. [^19] About the time of her death the women who stood by her said to her, “Don’t be afraid, for you have given birth to a son.” But she didn’t answer, neither did she regard it. [^20] She named the child Ichabod,#4:21 “Ichabod” means “no glory”. saying, “The glory has departed from Israel!” because God’s ark was taken, and because of her father-in-law and her husband. [^21] She said, “The glory has departed from Israel; for God’s ark has been taken.” [^22] 

[[1 Samuel - 3|<--]] 1 Samuel - 4 [[1 Samuel - 5|-->]]

---
# Notes
