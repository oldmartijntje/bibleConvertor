---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 2 - World English Bible"
---
[[Judges - 1|<--]] Judges - 2 [[Judges - 3|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Judges]]

# Judges - 2

Yahweh’s angel came up from Gilgal to Bochim. He said, “I brought you out of Egypt, and have brought you to the land which I swore to give your fathers. I said, ‘I will never break my covenant with you. [^1] You shall make no covenant with the inhabitants of this land. You shall break down their altars.’ But you have not listened to my voice. Why have you done this? [^2] Therefore I also said, ‘I will not drive them out from before you; but they shall be in your sides, and their gods will be a snare to you.’” [^3] When Yahweh’s angel spoke these words to all the children of Israel, the people lifted up their voice and wept. [^4] They called the name of that place Bochim,#2:5 “Bochim” means “weepers”. and they sacrificed there to Yahweh. [^5] Now when Joshua had sent the people away, the children of Israel each went to his inheritance to possess the land. [^6] The people served Yahweh all the days of Joshua, and all the days of the elders who outlived Joshua, who had seen all the great work of Yahweh that he had worked for Israel. [^7] Joshua the son of Nun, the servant of Yahweh, died, being one hundred ten years old. [^8] They buried him in the border of his inheritance in Timnath Heres, in the hill country of Ephraim, on the north of the mountain of Gaash. [^9] After all that generation were gathered to their fathers, another generation arose after them who didn’t know Yahweh, nor the work which he had done for Israel. [^10] The children of Israel did that which was evil in Yahweh’s sight, and served the Baals. [^11] They abandoned Yahweh, the God of their fathers, who brought them out of the land of Egypt, and followed other gods, of the gods of the peoples who were around them, and bowed themselves down to them; and they provoked Yahweh to anger. [^12] They abandoned Yahweh, and served Baal and the Ashtaroth. [^13] Yahweh’s anger burned against Israel, and he delivered them into the hands of raiders who plundered them. He sold them into the hands of their enemies all around, so that they could no longer stand before their enemies. [^14] Wherever they went out, Yahweh’s hand was against them for evil, as Yahweh had spoken, and as Yahweh had sworn to them; and they were very distressed. [^15] Yahweh raised up judges, who saved them out of the hand of those who plundered them. [^16] Yet they didn’t listen to their judges; for they prostituted themselves to other gods, and bowed themselves down to them. They quickly turned away from the way in which their fathers walked, obeying Yahweh’s commandments. They didn’t do so. [^17] When Yahweh raised up judges for them, then Yahweh was with the judge, and saved them out of the hand of their enemies all the days of the judge; for it grieved Yahweh because of their groaning by reason of those who oppressed them and troubled them. [^18] But when the judge was dead, they turned back, and dealt more corruptly than their fathers in following other gods to serve them and to bow down to them. They didn’t cease what they were doing, or give up their stubborn ways. [^19] Yahweh’s anger burned against Israel; and he said, “Because this nation transgressed my covenant which I commanded their fathers, and has not listened to my voice, [^20] I also will no longer drive out any of the nations that Joshua left when he died from before them; [^21] that by them I may test Israel, to see if they will keep Yahweh’s way to walk therein, as their fathers kept it, or not.” [^22] So Yahweh left those nations, without driving them out hastily. He didn’t deliver them into Joshua’s hand. [^23] 

[[Judges - 1|<--]] Judges - 2 [[Judges - 3|-->]]

---
# Notes
