---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 12 - World English Bible"
---
[[Judges - 11|<--]] Judges - 12 [[Judges - 13|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Judges]]

# Judges - 12

The men of Ephraim were gathered together, and passed northward; and they said to Jephthah, “Why did you pass over to fight against the children of Ammon, and didn’t call us to go with you? We will burn your house around you with fire!” [^1] Jephthah said to them, “I and my people were at great strife with the children of Ammon; and when I called you, you didn’t save me out of their hand. [^2] When I saw that you didn’t save me, I put my life in my hand, and passed over against the children of Ammon, and Yahweh delivered them into my hand. Why then have you come up to me today, to fight against me?” [^3] Then Jephthah gathered together all the men of Gilead, and fought with Ephraim. The men of Gilead struck Ephraim, because they said, “You are fugitives of Ephraim, you Gileadites, in the middle of Ephraim, and in the middle of Manasseh.” [^4] The Gileadites took the fords of the Jordan against the Ephraimites. Whenever a fugitive of Ephraim said, “Let me go over,” the men of Gilead said to him, “Are you an Ephraimite?” If he said, “No;” [^5] then they said to him, “Now say ‘Shibboleth;’” and he said “Sibboleth”; for he couldn’t manage to pronounce it correctly, then they seized him and killed him at the fords of the Jordan. At that time, forty-two thousand of Ephraim fell. [^6] Jephthah judged Israel six years. Then Jephthah the Gileadite died, and was buried in the cities of Gilead. [^7] After him Ibzan of Bethlehem judged Israel. [^8] He had thirty sons. He sent his thirty daughters outside his clan, and he brought in thirty daughters from outside his clan for his sons. He judged Israel seven years. [^9] Ibzan died, and was buried at Bethlehem. [^10] After him, Elon the Zebulunite judged Israel; and he judged Israel ten years. [^11] Elon the Zebulunite died, and was buried in Aijalon in the land of Zebulun. [^12] After him, Abdon the son of Hillel the Pirathonite judged Israel. [^13] He had forty sons and thirty sons’ sons who rode on seventy donkey colts. He judged Israel eight years. [^14] Abdon the son of Hillel the Pirathonite died, and was buried in Pirathon in the land of Ephraim, in the hill country of the Amalekites. [^15] 

[[Judges - 11|<--]] Judges - 12 [[Judges - 13|-->]]

---
# Notes
