---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 21 - World English Bible"
---
[[Judges - 20|<--]] Judges - 21

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Judges]]

# Judges - 21

Now the men of Israel had sworn in Mizpah, saying, “None of us will give his daughter to Benjamin as a wife.” [^1] The people came to Bethel and sat there until evening before God, and lifted up their voices, and wept severely. [^2] They said, “Yahweh, the God of Israel, why has this happened in Israel, that there should be one tribe lacking in Israel today?” [^3] On the next day, the people rose early and built an altar there, and offered burnt offerings and peace offerings. [^4] The children of Israel said, “Who is there among all the tribes of Israel who didn’t come up in the assembly to Yahweh?” For they had made a great oath concerning him who didn’t come up to Yahweh to Mizpah, saying, “He shall surely be put to death.” [^5] The children of Israel grieved for Benjamin their brother, and said, “There is one tribe cut off from Israel today. [^6] How shall we provide wives for those who remain, since we have sworn by Yahweh that we will not give them of our daughters to wives?” [^7] They said, “What one is there of the tribes of Israel who didn’t come up to Yahweh to Mizpah?” Behold, no one came from Jabesh Gilead to the camp to the assembly. [^8] For when the people were counted, behold, there were none of the inhabitants of Jabesh Gilead there. [^9] The congregation sent twelve thousand of the most valiant men there, and commanded them, saying, “Go and strike the inhabitants of Jabesh Gilead with the edge of the sword, with the women and the little ones. [^10] This is the thing that you shall do: you shall utterly destroy every male, and every woman who has lain with a man.” [^11] They found among the inhabitants of Jabesh Gilead four hundred young virgins who had not known man by lying with him; and they brought them to the camp to Shiloh, which is in the land of Canaan. [^12] The whole congregation sent and spoke to the children of Benjamin who were in the rock of Rimmon, and proclaimed peace to them. [^13] Benjamin returned at that time; and they gave them the women whom they had saved alive of the women of Jabesh Gilead. There still weren’t enough for them. [^14] The people grieved for Benjamin, because Yahweh had made a breach in the tribes of Israel. [^15] Then the elders of the congregation said, “How shall we provide wives for those who remain, since the women are destroyed out of Benjamin?” [^16] They said, “There must be an inheritance for those who are escaped of Benjamin, that a tribe not be blotted out from Israel. [^17] However, we may not give them wives of our daughters, for the children of Israel had sworn, saying, ‘Cursed is he who gives a wife to Benjamin.’” [^18] They said, “Behold, there is a feast of Yahweh from year to year in Shiloh, which is on the north of Bethel, on the east side of the highway that goes up from Bethel to Shechem, and on the south of Lebonah.” [^19] They commanded the children of Benjamin, saying, “Go and lie in wait in the vineyards, [^20] and see, and behold, if the daughters of Shiloh come out to dance in the dances, then come out of the vineyards, and each man catch his wife of the daughters of Shiloh, and go to the land of Benjamin. [^21] It shall be, when their fathers or their brothers come to complain to us, that we will say to them, ‘Grant them graciously to us, because we didn’t take for each man his wife in battle, neither did you give them to them; otherwise you would now be guilty.’” [^22] The children of Benjamin did so, and took wives for themselves according to their number, of those who danced, whom they carried off. They went and returned to their inheritance, built the cities, and lived in them. [^23] The children of Israel departed from there at that time, every man to his tribe and to his family, and they each went out from there to his own inheritance. [^24] In those days there was no king in Israel. Everyone did that which was right in his own eyes. [^25] 

[[Judges - 20|<--]] Judges - 21

---
# Notes
