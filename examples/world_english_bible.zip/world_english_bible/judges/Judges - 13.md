---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 13 - World English Bible"
---
[[Judges - 12|<--]] Judges - 13 [[Judges - 14|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Judges]]

# Judges - 13

The children of Israel again did that which was evil in Yahweh’s sight; and Yahweh delivered them into the hand of the Philistines forty years. [^1] There was a certain man of Zorah, of the family of the Danites, whose name was Manoah; and his wife was barren, and childless. [^2] Yahweh’s angel appeared to the woman, and said to her, “See now, you are barren and childless; but you shall conceive and bear a son. [^3] Now therefore please beware and drink no wine nor strong drink, and don’t eat any unclean thing; [^4] for, behold, you shall conceive and give birth to a son. No razor shall come on his head, for the child shall be a Nazirite to God from the womb. He shall begin to save Israel out of the hand of the Philistines.” [^5] Then the woman came and told her husband, saying, “A man of God came to me, and his face was like the face of the angel of God, very awesome. I didn’t ask him where he was from, neither did he tell me his name; [^6] but he said to me, ‘Behold, you shall conceive and bear a son; and now drink no wine nor strong drink. Don’t eat any unclean thing, for the child shall be a Nazirite to God from the womb to the day of his death.’” [^7] Then Manoah entreated Yahweh, and said, “Oh, Lord, please let the man of God whom you sent come again to us, and teach us what we should do to the child who shall be born.” [^8] God listened to the voice of Manoah, and the angel of God came again to the woman as she sat in the field; but Manoah, her husband, wasn’t with her. [^9] The woman hurried and ran, and told her husband, saying to him, “Behold, the man who came to me that day has appeared to me.” [^10] Manoah arose and followed his wife, and came to the man, and said to him, “Are you the man who spoke to my wife?”He said, “I am.” [^11] Manoah said, “Now let your words happen. What shall the child’s way of life and mission be?” [^12] Yahweh’s angel said to Manoah, “Of all that I said to the woman let her beware. [^13] She may not eat of anything that comes of the vine, neither let her drink wine or strong drink, nor eat any unclean thing. Let her observe all that I commanded her.” [^14] Manoah said to Yahweh’s angel, “Please stay with us, that we may make a young goat ready for you.” [^15] Yahweh’s angel said to Manoah, “Though you detain me, I won’t eat your bread. If you will prepare a burnt offering, you must offer it to Yahweh.” For Manoah didn’t know that he was Yahweh’s angel. [^16] Manoah said to Yahweh’s angel, “What is your name, that when your words happen, we may honor you?” [^17] Yahweh’s angel said to him, “Why do you ask about my name, since it is incomprehensible#13:18 or, wonderful?” [^18] So Manoah took the young goat with the meal offering, and offered it on the rock to Yahweh. Then the angel did an amazing thing as Manoah and his wife watched. [^19] For when the flame went up toward the sky from off the altar, Yahweh’s angel ascended in the flame of the altar. Manoah and his wife watched; and they fell on their faces to the ground. [^20] But Yahweh’s angel didn’t appear to Manoah or to his wife any more. Then Manoah knew that he was Yahweh’s angel. [^21] Manoah said to his wife, “We shall surely die, because we have seen God.” [^22] But his wife said to him, “If Yahweh were pleased to kill us, he wouldn’t have received a burnt offering and a meal offering at our hand, and he wouldn’t have shown us all these things, nor would he have told us such things as these at this time.” [^23] The woman bore a son and named him Samson. The child grew, and Yahweh blessed him. [^24] Yahweh’s Spirit began to move him in Mahaneh Dan, between Zorah and Eshtaol. [^25] 

[[Judges - 12|<--]] Judges - 13 [[Judges - 14|-->]]

---
# Notes
