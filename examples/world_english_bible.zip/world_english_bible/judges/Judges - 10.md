---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 10 - World English Bible"
---
[[Judges - 9|<--]] Judges - 10 [[Judges - 11|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Judges]]

# Judges - 10

After Abimelech, Tola the son of Puah, the son of Dodo, a man of Issachar, arose to save Israel. He lived in Shamir in the hill country of Ephraim. [^1] He judged Israel twenty-three years, and died, and was buried in Shamir. [^2] After him Jair, the Gileadite, arose. He judged Israel twenty-two years. [^3] He had thirty sons who rode on thirty donkey colts. They had thirty cities, which are called Havvoth Jair to this day, which are in the land of Gilead. [^4] Jair died, and was buried in Kamon. [^5] The children of Israel again did that which was evil in Yahweh’s sight, and served the Baals, the Ashtaroth, the gods of Syria, the gods of Sidon, the gods of Moab, the gods of the children of Ammon, and the gods of the Philistines. They abandoned Yahweh, and didn’t serve him. [^6] Yahweh’s anger burned against Israel, and he sold them into the hand of the Philistines and into the hand of the children of Ammon. [^7] They troubled and oppressed the children of Israel that year. For eighteen years they oppressed all the children of Israel that were beyond the Jordan in the land of the Amorites, which is in Gilead. [^8] The children of Ammon passed over the Jordan to fight also against Judah, and against Benjamin, and against the house of Ephraim, so that Israel was very distressed. [^9] The children of Israel cried to Yahweh, saying, “We have sinned against you, even because we have forsaken our God, and have served the Baals.” [^10] Yahweh said to the children of Israel, “Didn’t I save you from the Egyptians, and from the Amorites, from the children of Ammon, and from the Philistines? [^11] The Sidonians also, and the Amalekites, and the Maonites, oppressed you; and you cried to me, and I saved you out of their hand. [^12] Yet you have forsaken me and served other gods. Therefore I will save you no more. [^13] Go and cry to the gods which you have chosen. Let them save you in the time of your distress!” [^14] The children of Israel said to Yahweh, “We have sinned! Do to us whatever seems good to you; only deliver us, please, today.” [^15] They put away the foreign gods from among them and served Yahweh; and his soul was grieved for the misery of Israel. [^16] Then the children of Ammon were gathered together and encamped in Gilead. The children of Israel assembled themselves together and encamped in Mizpah. [^17] The people, the princes of Gilead, said to one another, “Who is the man who will begin to fight against the children of Ammon? He shall be head over all the inhabitants of Gilead.” [^18] 

[[Judges - 9|<--]] Judges - 10 [[Judges - 11|-->]]

---
# Notes
