---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 14 - World English Bible"
---
[[Judges - 13|<--]] Judges - 14 [[Judges - 15|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Judges]]

# Judges - 14

Samson went down to Timnah, and saw a woman in Timnah of the daughters of the Philistines. [^1] He came up, and told his father and his mother, saying, “I have seen a woman in Timnah of the daughters of the Philistines. Now therefore get her for me as my wife.” [^2] Then his father and his mother said to him, “Isn’t there a woman among your brothers’ daughters, or among all my people, that you go to take a wife of the uncircumcised Philistines?”Samson said to his father, “Get her for me, for she pleases me well.” [^3] But his father and his mother didn’t know that it was of Yahweh; for he sought an occasion against the Philistines. Now at that time the Philistines ruled over Israel. [^4] Then Samson went down to Timnah with his father and his mother, and came to the vineyards of Timnah; and behold, a young lion roared at him. [^5] Yahweh’s Spirit came mightily on him, and he tore him as he would have torn a young goat with his bare hands, but he didn’t tell his father or his mother what he had done. [^6] He went down and talked with the woman, and she pleased Samson well. [^7] After a while he returned to take her, and he went over to see the carcass of the lion; and behold, there was a swarm of bees in the body of the lion, and honey. [^8] He took it into his hands, and went on, eating as he went. He came to his father and mother and gave to them, and they ate, but he didn’t tell them that he had taken the honey out of the lion’s body. [^9] His father went down to the woman; and Samson made a feast there, for the young men used to do so. [^10] When they saw him, they brought thirty companions to be with him. [^11] Samson said to them, “Let me tell you a riddle now. If you can tell me the answer within the seven days of the feast, and find it out, then I will give you thirty linen garments and thirty changes of clothing; [^12] but if you can’t tell me the answer, then you shall give me thirty linen garments and thirty changes of clothing.”They said to him, “Tell us your riddle, that we may hear it.” [^13] He said to them,“Out of the eater came out food.Out of the strong came out sweetness.”They couldn’t in three days declare the riddle. [^14] On the seventh day, they said to Samson’s wife, “Entice your husband, that he may declare to us the riddle, lest we burn you and your father’s house with fire. Have you called us to impoverish us? Isn’t that so?” [^15] Samson’s wife wept before him, and said, “You just hate me, and don’t love me. You’ve told a riddle to the children of my people, and haven’t told it to me.”He said to her, “Behold, I haven’t told my father or my mother, so why should I tell you?” [^16] She wept before him the seven days, while their feast lasted; and on the seventh day, he told her, because she pressed him severely; and she told the riddle to the children of her people. [^17] The men of the city said to him on the seventh day before the sun went down, “What is sweeter than honey? What is stronger than a lion?”He said to them,“If you hadn’t plowed with my heifer,you wouldn’t have found out my riddle.” [^18] Yahweh’s Spirit came mightily on him, and he went down to Ashkelon and struck thirty men of them. He took their plunder, then gave the changes of clothing to those who declared the riddle. His anger burned, and he went up to his father’s house. [^19] But Samson’s wife was given to his companion, who had been his friend. [^20] 

[[Judges - 13|<--]] Judges - 14 [[Judges - 15|-->]]

---
# Notes
