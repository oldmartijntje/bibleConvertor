---
translation: World English Bible
aliases:
  - "Judges - World English Bible"
tags:
  - "#bible/type/book"
  - "#bible/book/judges"
  - "#bible/testament/old"
---
[[Joshua|<--]] Judges [[Ruth|-->]]

# Judges - World English Bible

The Judges book has 21 chapters. It is part of the old testament.

## Chapters

- Judges [[Judges - 1|chapter 1]]
- Judges [[Judges - 2|chapter 2]]
- Judges [[Judges - 3|chapter 3]]
- Judges [[Judges - 4|chapter 4]]
- Judges [[Judges - 5|chapter 5]]
- Judges [[Judges - 6|chapter 6]]
- Judges [[Judges - 7|chapter 7]]
- Judges [[Judges - 8|chapter 8]]
- Judges [[Judges - 9|chapter 9]]
- Judges [[Judges - 10|chapter 10]]
- Judges [[Judges - 11|chapter 11]]
- Judges [[Judges - 12|chapter 12]]
- Judges [[Judges - 13|chapter 13]]
- Judges [[Judges - 14|chapter 14]]
- Judges [[Judges - 15|chapter 15]]
- Judges [[Judges - 16|chapter 16]]
- Judges [[Judges - 17|chapter 17]]
- Judges [[Judges - 18|chapter 18]]
- Judges [[Judges - 19|chapter 19]]
- Judges [[Judges - 20|chapter 20]]
- Judges [[Judges - 21|chapter 21]]

[[Joshua|<--]] Judges [[Ruth|-->]]

---
# Notes
