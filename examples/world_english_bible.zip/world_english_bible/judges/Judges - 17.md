---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 17 - World English Bible"
---
[[Judges - 16|<--]] Judges - 17 [[Judges - 18|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Judges]]

# Judges - 17

There was a man of the hill country of Ephraim, whose name was Micah. [^1] He said to his mother, “The eleven hundred pieces of silver that were taken from you, about which you uttered a curse, and also spoke it in my ears—behold, the silver is with me. I took it.”His mother said, “May Yahweh bless my son!” [^2] He restored the eleven hundred pieces of silver to his mother, then his mother said, “I most certainly dedicate the silver to Yahweh from my hand for my son, to make a carved image and a molten image. Now therefore I will restore it to you.” [^3] When he restored the money to his mother, his mother took two hundred pieces of silver, and gave them to a silversmith, who made a carved image and a molten image out of it. It was in the house of Micah. [^4] The man Micah had a house of gods, and he made an ephod, and teraphim,#17:5 teraphim were household idols that may have been associated with inheritance rights to the household property. and consecrated one of his sons, who became his priest. [^5] In those days there was no king in Israel. Everyone did that which was right in his own eyes. [^6] There was a young man out of Bethlehem Judah, of the family of Judah, who was a Levite; and he lived there. [^7] The man departed out of the city, out of Bethlehem Judah, to live where he could find a place, and he came to the hill country of Ephraim, to the house of Micah, as he traveled. [^8] Micah said to him, “Where did you come from?”He said to him, “I am a Levite of Bethlehem Judah, and I am looking for a place to live.” [^9] Micah said to him, “Dwell with me, and be to me a father and a priest, and I will give you ten pieces of silver per year, a suit of clothing, and your food.” So the Levite went in. [^10] The Levite was content to dwell with the man; and the young man was to him as one of his sons. [^11] Micah consecrated the Levite, and the young man became his priest, and was in the house of Micah. [^12] Then Micah said, “Now I know that Yahweh will do good to me, since I have a Levite as my priest.” [^13] 

[[Judges - 16|<--]] Judges - 17 [[Judges - 18|-->]]

---
# Notes
