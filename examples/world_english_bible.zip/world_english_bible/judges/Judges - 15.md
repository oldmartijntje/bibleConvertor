---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 15 - World English Bible"
---
[[Judges - 14|<--]] Judges - 15 [[Judges - 16|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Judges]]

# Judges - 15

But after a while, in the time of wheat harvest, Samson visited his wife with a young goat. He said, “I will go in to my wife’s room.”But her father wouldn’t allow him to go in. [^1] Her father said, “I most certainly thought that you utterly hated her; therefore I gave her to your companion. Isn’t her younger sister more beautiful than she? Please, take her instead.” [^2] Samson said to them, “This time I will be blameless in the case of the Philistines when I harm them.” [^3] Samson went and caught three hundred foxes, and took torches, and turned tail to tail, and put a torch in the middle between every two tails. [^4] When he had set the torches on fire, he let them go into the standing grain of the Philistines, and burned up both the shocks and the standing grain, and also the olive groves. [^5] Then the Philistines said, “Who has done this?”They said, “Samson, the son-in-law of the Timnite, because he has taken his wife and given her to his companion.” The Philistines came up, and burned her and her father with fire. [^6] Samson said to them, “If you behave like this, surely I will take revenge on you, and after that I will cease.” [^7] He struck them hip and thigh with a great slaughter; and he went down and lived in the cave in Etam’s rock. [^8] Then the Philistines went up, encamped in Judah, and spread themselves in Lehi. [^9] The men of Judah said, “Why have you come up against us?”They said, “We have come up to bind Samson, to do to him as he has done to us.” [^10] Then three thousand men of Judah went down to the cave in Etam’s rock, and said to Samson, “Don’t you know that the Philistines are rulers over us? What then is this that you have done to us?”He said to them, “As they did to me, so I have done to them.” [^11] They said to him, “We have come down to bind you, that we may deliver you into the hand of the Philistines.”Samson said to them, “Swear to me that you will not attack me yourselves.” [^12] They spoke to him, saying, “No, but we will bind you securely and deliver you into their hands; but surely we will not kill you.” They bound him with two new ropes, and brought him up from the rock. [^13] When he came to Lehi, the Philistines shouted as they met him. Then Yahweh’s Spirit came mightily on him, and the ropes that were on his arms became as flax that was burned with fire; and his bands dropped from off his hands. [^14] He found a fresh jawbone of a donkey, put out his hand, took it, and struck a thousand men with it. [^15] Samson said, “With the jawbone of a donkey, heaps on heaps; with the jawbone of a donkey I have struck a thousand men.” [^16] When he had finished speaking, he threw the jawbone out of his hand; and that place was called Ramath Lehi.#15:17 “Ramath” means “hill” and “Lehi” means “jawbone”. [^17] He was very thirsty, and called on Yahweh and said, “You have given this great deliverance by the hand of your servant; and now shall I die of thirst, and fall into the hands of the uncircumcised?” [^18] But God split the hollow place that is in Lehi, and water came out of it. When he had drunk, his spirit came again, and he revived. Therefore its name was called En Hakkore, which is in Lehi, to this day. [^19] He judged Israel twenty years in the days of the Philistines. [^20] 

[[Judges - 14|<--]] Judges - 15 [[Judges - 16|-->]]

---
# Notes
