---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/ruth"
  - "#bible/testament/old"
aliases:
  - "Ruth - 1 - World English Bible"
---
Ruth - 1 [[Ruth - 2|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Ruth]]

# Ruth - 1

In the days when the judges judged, there was a famine in the land. A certain man of Bethlehem Judah went to live in the country of Moab with his wife and his two sons. [^1] The name of the man was Elimelech, and the name of his wife Naomi. The names of his two sons were Mahlon and Chilion, Ephrathites of Bethlehem Judah. They came into the country of Moab and lived there. [^2] Elimelech, Naomi’s husband, died; and she was left with her two sons. [^3] They took for themselves wives of the women of Moab. The name of the one was Orpah, and the name of the other was Ruth. They lived there about ten years. [^4] Mahlon and Chilion both died, and the woman was bereaved of her two children and of her husband. [^5] Then she arose with her daughters-in-law, that she might return from the country of Moab; for she had heard in the country of Moab how Yahweh#1:6 “Yahweh” is God’s proper Name, sometimes rendered “Lord” (all caps) in other translations. had visited his people in giving them bread. [^6] She went out of the place where she was, and her two daughters-in-law with her. They went on the way to return to the land of Judah. [^7] Naomi said to her two daughters-in-law, “Go, return each of you to her mother’s house. May Yahweh deal kindly with you, as you have dealt with the dead and with me. [^8] May Yahweh grant you that you may find rest, each of you in the house of her husband.”Then she kissed them, and they lifted up their voices, and wept. [^9] They said to her, “No, but we will return with you to your people.” [^10] Naomi said, “Go back, my daughters. Why do you want to go with me? Do I still have sons in my womb, that they may be your husbands? [^11] Go back, my daughters, go your way; for I am too old to have a husband. If I should say, ‘I have hope,’ if I should even have a husband tonight, and should also bear sons, [^12] would you then wait until they were grown? Would you then refrain from having husbands? No, my daughters, for it grieves me seriously for your sakes, for Yahweh’s hand has gone out against me.” [^13] They lifted up their voices and wept again; then Orpah kissed her mother-in-law, but Ruth stayed with her. [^14] She said, “Behold,#1:15 “Behold”, from “הִנֵּה”, means look at, take notice, observe, see, or gaze at. It is often used as an interjection. your sister-in-law has gone back to her people and to her god. Follow your sister-in-law.” [^15] Ruth said, “Don’t urge me to leave you, and to return from following you, for where you go, I will go; and where you stay, I will stay. Your people will be my people, and your God#1:16 The Hebrew word rendered “God” is “אֱלֹהִ֑ים” (Elohim). my God. [^16] Where you die, I will die, and there I will be buried. May Yahweh do so to me, and more also, if anything but death parts you and me.” [^17] When Naomi saw that she was determined to go with her, she stopped urging her. [^18] So they both went until they came to Bethlehem. When they had come to Bethlehem, all the city was excited about them, and they asked, “Is this Naomi?” [^19] She said to them, “Don’t call me Naomi.#1:20 “Naomi” means “pleasant”. Call me Mara,#1:20 “Mara” means “bitter”. for the Almighty has dealt very bitterly with me. [^20] I went out full, and Yahweh has brought me home again empty. Why do you call me Naomi, since Yahweh has testified against me, and the Almighty has afflicted me?” [^21] So Naomi returned, and Ruth the Moabitess, her daughter-in-law, with her, who returned out of the country of Moab. They came to Bethlehem in the beginning of barley harvest. [^22] 

Ruth - 1 [[Ruth - 2|-->]]

---
# Notes
