---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/ruth"
  - "#bible/testament/old"
aliases:
  - "Ruth - 2 - World English Bible"
---
[[Ruth - 1|<--]] Ruth - 2 [[Ruth - 3|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Ruth]]

# Ruth - 2

Naomi had a relative of her husband’s, a mighty man of wealth, of the family of Elimelech, and his name was Boaz. [^1] Ruth the Moabitess said to Naomi, “Let me now go to the field, and glean among the ears of grain after him in whose sight I find favor.”She said to her, “Go, my daughter.” [^2] She went, and came and gleaned in the field after the reapers; and she happened to come to the portion of the field belonging to Boaz, who was of the family of Elimelech. [^3] Behold, Boaz came from Bethlehem, and said to the reapers, “May Yahweh be with you.”They answered him, “May Yahweh bless you.” [^4] Then Boaz said to his servant who was set over the reapers, “Whose young lady is this?” [^5] The servant who was set over the reapers answered, “It is the Moabite lady who came back with Naomi out of the country of Moab. [^6] She said, ‘Please let me glean and gather after the reapers among the sheaves.’ So she came, and has continued even from the morning until now, except that she rested a little in the house.” [^7] Then Boaz said to Ruth, “Listen, my daughter. Don’t go to glean in another field, and don’t go from here, but stay here close to my maidens. [^8] Let your eyes be on the field that they reap, and go after them. Haven’t I commanded the young men not to touch you? When you are thirsty, go to the vessels, and drink from that which the young men have drawn.” [^9] Then she fell on her face and bowed herself to the ground, and said to him, “Why have I found favor in your sight, that you should take knowledge of me, since I am a foreigner?” [^10] Boaz answered her, “I have been told all about what you have done for your mother-in-law since the death of your husband, and how you have left your father, your mother, and the land of your birth, and have come to a people that you didn’t know before. [^11] May Yahweh repay your work, and a full reward be given to you from Yahweh, the God of Israel, under whose wings you have come to take refuge.” [^12] Then she said, “Let me find favor in your sight, my lord, because you have comforted me, and because you have spoken kindly to your servant, though I am not as one of your servants.” [^13] At meal time Boaz said to her, “Come here, and eat some bread, and dip your morsel in the vinegar.”She sat beside the reapers, and they passed her parched grain. She ate, was satisfied, and left some of it. [^14] When she had risen up to glean, Boaz commanded his young men, saying, “Let her glean even among the sheaves, and don’t reproach her. [^15] Also pull out some for her from the bundles, and leave it. Let her glean, and don’t rebuke her.” [^16] So she gleaned in the field until evening; and she beat out that which she had gleaned, and it was about an ephah#2:17 1 ephah is about 22 liters or about 2/3 of a bushel of barley. [^17] She took it up, and went into the city. Then her mother-in-law saw what she had gleaned; and she brought out and gave to her that which she had left after she had enough. [^18] Her mother-in-law said to her, “Where have you gleaned today? Where have you worked? Blessed be he who noticed you.”She told her mother-in-law with whom she had worked, “The man’s name with whom I worked today is Boaz.” [^19] Naomi said to her daughter-in-law, “May he be blessed by Yahweh, who has not abandoned his kindness to the living and to the dead.” Naomi said to her, “The man is a close relative to us, one of our near kinsmen.” [^20] Ruth the Moabitess said, “Yes, he said to me, ‘You shall stay close to my young men until they have finished all my harvest.’” [^21] Naomi said to Ruth her daughter-in-law, “It is good, my daughter, that you go out with his maidens, and that they not harm you in any other field.” [^22] So she stayed close to the maidens of Boaz, to glean to the end of barley harvest and of wheat harvest; and she lived with her mother-in-law. [^23] 

[[Ruth - 1|<--]] Ruth - 2 [[Ruth - 3|-->]]

---
# Notes
