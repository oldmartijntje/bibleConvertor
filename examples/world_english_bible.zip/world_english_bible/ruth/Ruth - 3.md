---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/ruth"
  - "#bible/testament/old"
aliases:
  - "Ruth - 3 - World English Bible"
---
[[Ruth - 2|<--]] Ruth - 3 [[Ruth - 4|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Ruth]]

# Ruth - 3

Naomi her mother-in-law said to her, “My daughter, shall I not seek rest for you, that it may be well with you? [^1] Now isn’t Boaz our kinsman, with whose maidens you were? Behold, he will be winnowing barley tonight on the threshing floor. [^2] Therefore wash yourself, anoint yourself, get dressed, and go down to the threshing floor; but don’t make yourself known to the man until he has finished eating and drinking. [^3] It shall be, when he lies down, that you shall note the place where he is lying. Then you shall go in, uncover his feet, and lie down. Then he will tell you what to do.” [^4] She said to her, “All that you say, I will do.” [^5] She went down to the threshing floor, and did everything that her mother-in-law told her. [^6] When Boaz had eaten and drunk, and his heart was merry, he went to lie down at the end of the heap of grain. She came softly, uncovered his feet, and lay down. [^7] At midnight, the man was startled and turned himself; and behold, a woman lay at his feet. [^8] He said, “Who are you?”She answered, “I am Ruth your servant. Therefore spread the corner of your garment over your servant; for you are a near kinsman.” [^9] He said, “You are blessed by Yahweh, my daughter. You have shown more kindness in the latter end than at the beginning, because you didn’t follow young men, whether poor or rich. [^10] Now, my daughter, don’t be afraid. I will do to you all that you say; for all the city of my people knows that you are a worthy woman. [^11] Now it is true that I am a near kinsman. However, there is a kinsman nearer than I. [^12] Stay this night, and in the morning, if he will perform for you the part of a kinsman, good. Let him do the kinsman’s duty. But if he will not do the duty of a kinsman for you, then I will do the duty of a kinsman for you, as Yahweh lives. Lie down until the morning.” [^13] She lay at his feet until the morning, then she rose up before one could discern another. For he said, “Let it not be known that the woman came to the threshing floor.” [^14] He said, “Bring the mantle that is on you, and hold it.” She held it; and he measured six measures of barley, and laid it on her; then he went into the city. [^15] When she came to her mother-in-law, she said, “How did it go, my daughter?”She told her all that the man had done for her. [^16] She said, “He gave me these six measures of barley; for he said, ‘Don’t go empty to your mother-in-law.’” [^17] Then she said, “Wait, my daughter, until you know what will happen; for the man will not rest until he has settled this today.” [^18] 

[[Ruth - 2|<--]] Ruth - 3 [[Ruth - 4|-->]]

---
# Notes
