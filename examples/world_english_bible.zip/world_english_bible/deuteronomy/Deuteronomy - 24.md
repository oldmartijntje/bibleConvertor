---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 24 - World English Bible"
---
[[Deuteronomy - 23|<--]] Deuteronomy - 24 [[Deuteronomy - 25|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Deuteronomy]]

# Deuteronomy - 24

When a man takes a wife and marries her, then it shall be, if she finds no favor in his eyes because he has found some unseemly thing in her, that he shall write her a certificate of divorce, put it in her hand, and send her out of his house. [^1] When she has departed out of his house, she may go and be another man’s wife. [^2] If the latter husband hates her, and writes her a certificate of divorce, puts it in her hand, and sends her out of his house; or if the latter husband dies, who took her to be his wife; [^3] her former husband, who sent her away, may not take her again to be his wife after she is defiled; for that would be an abomination to Yahweh. You shall not cause the land to sin, which Yahweh your God gives you for an inheritance. [^4] When a man takes a new wife, he shall not go out in the army, neither shall he be assigned any business. He shall be free at home one year, and shall cheer his wife whom he has taken. [^5] No man shall take the mill or the upper millstone as a pledge, for he takes a life in pledge. [^6] If a man is found stealing any of his brothers of the children of Israel, and he deals with him as a slave, or sells him, then that thief shall die. So you shall remove the evil from among you. [^7] Be careful in the plague of leprosy, that you observe diligently and do according to all that the Levitical priests teach you. As I commanded them, so you shall observe to do. [^8] Remember what Yahweh your God did to Miriam, by the way as you came out of Egypt. [^9] When you lend your neighbor any kind of loan, you shall not go into his house to get his pledge. [^10] You shall stand outside, and the man to whom you lend shall bring the pledge outside to you. [^11] If he is a poor man, you shall not sleep with his pledge. [^12] You shall surely restore to him the pledge when the sun goes down, that he may sleep in his garment and bless you. It shall be righteousness to you before Yahweh your God. [^13] You shall not oppress a hired servant who is poor and needy, whether he is one of your brothers or one of the foreigners who are in your land within your gates. [^14] In his day you shall give him his wages, neither shall the sun go down on it, for he is poor and sets his heart on it, lest he cry against you to Yahweh, and it be sin to you. [^15] The fathers shall not be put to death for the children, neither shall the children be put to death for the fathers. Every man shall be put to death for his own sin. [^16] You shall not deprive the foreigner or the fatherless of justice, nor take a widow’s clothing in pledge; [^17] but you shall remember that you were a slave in Egypt, and Yahweh your God redeemed you there. Therefore I command you to do this thing. [^18] When you reap your harvest in your field, and have forgotten a sheaf in the field, you shall not go again to get it. It shall be for the foreigner, for the fatherless, and for the widow, that Yahweh your God may bless you in all the work of your hands. [^19] When you beat your olive tree, you shall not go over the boughs again. It shall be for the foreigner, for the fatherless, and for the widow. [^20] When you harvest your vineyard, you shall not glean it after yourselves. It shall be for the foreigner, for the fatherless, and for the widow. [^21] You shall remember that you were a slave in the land of Egypt. Therefore I command you to do this thing. [^22] 

[[Deuteronomy - 23|<--]] Deuteronomy - 24 [[Deuteronomy - 25|-->]]

---
# Notes
