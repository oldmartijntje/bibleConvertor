---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 8 - World English Bible"
---
[[Deuteronomy - 7|<--]] Deuteronomy - 8 [[Deuteronomy - 9|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Deuteronomy]]

# Deuteronomy - 8

You shall observe to do all the commandments which I command you today, that you may live, and multiply, and go in and possess the land which Yahweh swore to your fathers. [^1] You shall remember all the way which Yahweh your God has led you these forty years in the wilderness, that he might humble you, to test you, to know what was in your heart, whether you would keep his commandments or not. [^2] He humbled you, allowed you to be hungry, and fed you with manna, which you didn’t know, neither did your fathers know, that he might teach you that man does not live by bread only, but man lives by every word that proceeds out of Yahweh’s mouth. [^3] Your clothing didn’t grow old on you, neither did your foot swell, these forty years. [^4] You shall consider in your heart that as a man disciplines his son, so Yahweh your God disciplines you. [^5] You shall keep the commandments of Yahweh your God, to walk in his ways, and to fear him. [^6] For Yahweh your God brings you into a good land, a land of brooks of water, of springs, and underground water flowing into valleys and hills; [^7] a land of wheat, barley, vines, fig trees, and pomegranates; a land of olive trees and honey; [^8] a land in which you shall eat bread without scarcity, you shall not lack anything in it; a land whose stones are iron, and out of whose hills you may dig copper. [^9] You shall eat and be full, and you shall bless Yahweh your God for the good land which he has given you. [^10] Beware lest you forget Yahweh your God, in not keeping his commandments, his ordinances, and his statutes, which I command you today; [^11] lest, when you have eaten and are full, and have built fine houses and lived in them; [^12] and when your herds and your flocks multiply, and your silver and your gold is multiplied, and all that you have is multiplied; [^13] then your heart might be lifted up, and you forget Yahweh your God, who brought you out of the land of Egypt, out of the house of bondage; [^14] who led you through the great and terrible wilderness, with venomous snakes and scorpions, and thirsty ground where there was no water; who poured water for you out of the rock of flint; [^15] who fed you in the wilderness with manna, which your fathers didn’t know, that he might humble you, and that he might prove you, to do you good at your latter end; [^16] and lest you say in your heart, “My power and the might of my hand has gotten me this wealth.” [^17] But you shall remember Yahweh your God, for it is he who gives you power to get wealth, that he may establish his covenant which he swore to your fathers, as it is today. [^18] It shall be, if you shall forget Yahweh your God, and walk after other gods, and serve them and worship them, I testify against you today that you shall surely perish. [^19] As the nations that Yahweh makes to perish before you, so you shall perish, because you wouldn’t listen to Yahweh your God’s voice. [^20] 

[[Deuteronomy - 7|<--]] Deuteronomy - 8 [[Deuteronomy - 9|-->]]

---
# Notes
