---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 19 - World English Bible"
---
[[Deuteronomy - 18|<--]] Deuteronomy - 19 [[Deuteronomy - 20|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Deuteronomy]]

# Deuteronomy - 19

When Yahweh your God cuts off the nations whose land Yahweh your God gives you, and you succeed them and dwell in their cities and in their houses, [^1] you shall set apart three cities for yourselves in the middle of your land, which Yahweh your God gives you to possess. [^2] You shall prepare the way, and divide the borders of your land which Yahweh your God causes you to inherit into three parts, that every man slayer may flee there. [^3] This is the case of the man slayer who shall flee there and live: Whoever kills his neighbor unintentionally, and didn’t hate him in time past— [^4] as when a man goes into the forest with his neighbor to chop wood and his hand swings the ax to cut down the tree, and the head slips from the handle and hits his neighbor so that he dies—he shall flee to one of these cities and live. [^5] Otherwise, the avenger of blood might pursue the man slayer while hot anger is in his heart and overtake him, because the way is long, and strike him mortally, even though he was not worthy of death, because he didn’t hate him in time past. [^6] Therefore I command you to set apart three cities for yourselves. [^7] If Yahweh your God enlarges your border, as he has sworn to your fathers, and gives you all the land which he promised to give to your fathers; [^8] and if you keep all this commandment to do it, which I command you today, to love Yahweh your God, and to walk ever in his ways, then you shall add three cities more for yourselves, in addition to these three. [^9] This is so that innocent blood will not be shed in the middle of your land which Yahweh your God gives you for an inheritance, leaving blood guilt on you. [^10] But if any man hates his neighbor, lies in wait for him, rises up against him, strikes him mortally so that he dies, and he flees into one of these cities; [^11] then the elders of his city shall send and bring him there, and deliver him into the hand of the avenger of blood, that he may die. [^12] Your eye shall not pity him, but you shall purge the innocent blood from Israel that it may go well with you. [^13] You shall not remove your neighbor’s landmark, which they of old time have set, in your inheritance which you shall inherit, in the land that Yahweh your God gives you to possess. [^14] One witness shall not rise up against a man for any iniquity, or for any sin that he sins. At the mouth of two witnesses, or at the mouth of three witnesses, shall a matter be established. [^15] If an unrighteous witness rises up against any man to testify against him of wrongdoing, [^16] then both the men, between whom the controversy is, shall stand before Yahweh, before the priests and the judges who shall be in those days; [^17] and the judges shall make diligent inquisition; and behold, if the witness is a false witness, and has testified falsely against his brother, [^18] then you shall do to him as he had thought to do to his brother. So you shall remove the evil from among you. [^19] Those who remain shall hear, and fear, and will never again commit any such evil among you. [^20] Your eyes shall not pity: life for life, eye for eye, tooth for tooth, hand for hand, foot for foot. [^21] 

[[Deuteronomy - 18|<--]] Deuteronomy - 19 [[Deuteronomy - 20|-->]]

---
# Notes
