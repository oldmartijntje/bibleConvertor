---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 14 - World English Bible"
---
[[Deuteronomy - 13|<--]] Deuteronomy - 14 [[Deuteronomy - 15|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Deuteronomy]]

# Deuteronomy - 14

You are the children of Yahweh your God. You shall not cut yourselves, nor make any baldness between your eyes for the dead. [^1] For you are a holy people to Yahweh your God, and Yahweh has chosen you to be a people for his own possession, above all peoples who are on the face of the earth. [^2] You shall not eat any abominable thing. [^3] These are the animals which you may eat: the ox, the sheep, the goat, [^4] the deer, the gazelle, the roebuck, the wild goat, the ibex, the antelope, and the chamois. [^5] Every animal that parts the hoof, and has the hoof split in two and chews the cud, among the animals, you may eat. [^6] Nevertheless these you shall not eat of them that chew the cud, or of those who have the hoof split: the camel, the hare, and the rabbit. Because they chew the cud but don’t part the hoof, they are unclean to you. [^7] The pig, because it has a split hoof but doesn’t chew the cud, is unclean to you. You shall not eat their meat. You shall not touch their carcasses. [^8] These you may eat of all that are in the waters: you may eat whatever has fins and scales. [^9] You shall not eat whatever doesn’t have fins and scales. It is unclean to you. [^10] Of all clean birds you may eat. [^11] But these are they of which you shall not eat: the eagle, the vulture, the osprey, [^12] the red kite, the falcon, the kite of any kind, [^13] every raven of any kind, [^14] the ostrich, the owl, the seagull, the hawk of any kind, [^15] the little owl, the great owl, the horned owl, [^16] the pelican, the vulture, the cormorant, [^17] the stork, the heron after its kind, the hoopoe, and the bat. [^18] All winged creeping things are unclean to you. They shall not be eaten. [^19] Of all clean birds you may eat. [^20] You shall not eat of anything that dies of itself. You may give it to the foreigner living among you who is within your gates, that he may eat it; or you may sell it to a foreigner; for you are a holy people to Yahweh your God.You shall not boil a young goat in its mother’s milk. [^21] You shall surely tithe all the increase of your seed, that which comes out of the field year by year. [^22] You shall eat before Yahweh your God, in the place which he chooses to cause his name to dwell, the tithe of your grain, of your new wine, and of your oil, and the firstborn of your herd and of your flock; that you may learn to fear Yahweh your God always. [^23] If the way is too long for you, so that you are not able to carry it because the place which Yahweh your God shall choose to set his name there is too far from you, when Yahweh your God blesses you, [^24] then you shall turn it into money, bind up the money in your hand, and shall go to the place which Yahweh your God shall choose. [^25] You shall trade the money for whatever your soul desires: for cattle, or for sheep, or for wine, or for strong drink, or for whatever your soul asks of you. You shall eat there before Yahweh your God, and you shall rejoice, you and your household. [^26] You shall not forsake the Levite who is within your gates, for he has no portion nor inheritance with you. [^27] At the end of every three years you shall bring all the tithe of your increase in the same year, and shall store it within your gates. [^28] The Levite, because he has no portion nor inheritance with you, as well as the foreigner living among you, the fatherless, and the widow who are within your gates shall come, and shall eat and be satisfied; that Yahweh your God may bless you in all the work of your hand which you do. [^29] 

[[Deuteronomy - 13|<--]] Deuteronomy - 14 [[Deuteronomy - 15|-->]]

---
# Notes
