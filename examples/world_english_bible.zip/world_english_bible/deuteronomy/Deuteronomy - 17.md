---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 17 - World English Bible"
---
[[Deuteronomy - 16|<--]] Deuteronomy - 17 [[Deuteronomy - 18|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Deuteronomy]]

# Deuteronomy - 17

You shall not sacrifice to Yahweh your God an ox or a sheep in which is a defect or anything evil; for that is an abomination to Yahweh your God. [^1] If there is found among you, within any of your gates which Yahweh your God gives you, a man or woman who does that which is evil in Yahweh your God’s sight in transgressing his covenant, [^2] and has gone and served other gods and worshiped them, or the sun, or the moon, or any of the stars of the sky, which I have not commanded, [^3] and you are told, and you have heard of it, then you shall inquire diligently. Behold, if it is true, and the thing certain, that such abomination is done in Israel, [^4] then you shall bring out that man or that woman who has done this evil thing to your gates, even that same man or woman; and you shall stone them to death with stones. [^5] At the mouth of two witnesses, or three witnesses, he who is to die shall be put to death. At the mouth of one witness he shall not be put to death. [^6] The hands of the witnesses shall be first on him to put him to death, and afterward the hands of all the people. So you shall remove the evil from among you. [^7] If there arises a matter too hard for you in judgment, between blood and blood, between plea and plea, and between stroke and stroke, being matters of controversy within your gates, then you shall arise, and go up to the place which Yahweh your God chooses. [^8] You shall come to the priests who are Levites and to the judge who shall be in those days. You shall inquire, and they shall give you the verdict. [^9] You shall do according to the decisions of the verdict which they shall give you from that place which Yahweh chooses. You shall observe to do according to all that they shall teach you. [^10] According to the decisions of the law which they shall teach you, and according to the judgment which they shall tell you, you shall do. You shall not turn away from the sentence which they announce to you, to the right hand, nor to the left. [^11] The man who does presumptuously in not listening to the priest who stands to minister there before Yahweh your God, or to the judge, even that man shall die. You shall put away the evil from Israel. [^12] All the people shall hear and fear, and do no more presumptuously. [^13] When you have come to the land which Yahweh your God gives you, and possess it and dwell in it, and say, “I will set a king over me, like all the nations that are around me,” [^14] you shall surely set him whom Yahweh your God chooses as king over yourselves. You shall set as king over you one from among your brothers. You may not put a foreigner over you, who is not your brother. [^15] Only he shall not multiply horses to himself, nor cause the people to return to Egypt, to the end that he may multiply horses; because Yahweh has said to you, “You shall not go back that way again.” [^16] He shall not multiply wives to himself, that his heart not turn away. He shall not greatly multiply to himself silver and gold. [^17] It shall be, when he sits on the throne of his kingdom, that he shall write himself a copy of this law in a book, out of that which is before the Levitical priests. [^18] It shall be with him, and he shall read from it all the days of his life, that he may learn to fear Yahweh his God, to keep all the words of this law and these statutes, to do them; [^19] that his heart not be lifted up above his brothers, and that he not turn away from the commandment to the right hand, or to the left, to the end that he may prolong his days in his kingdom, he and his children, in the middle of Israel. [^20] 

[[Deuteronomy - 16|<--]] Deuteronomy - 17 [[Deuteronomy - 18|-->]]

---
# Notes
