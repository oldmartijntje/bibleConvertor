---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 23 - World English Bible"
---
[[Deuteronomy - 22|<--]] Deuteronomy - 23 [[Deuteronomy - 24|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Deuteronomy]]

# Deuteronomy - 23

He who is emasculated by crushing or cutting shall not enter into Yahweh’s assembly. [^1] A person born of a forbidden union shall not enter into Yahweh’s assembly; even to the tenth generation shall no one of his enter into Yahweh’s assembly. [^2] An Ammonite or a Moabite shall not enter into Yahweh’s assembly; even to the tenth generation shall no one belonging to them enter into Yahweh’s assembly forever, [^3] because they didn’t meet you with bread and with water on the way when you came out of Egypt, and because they hired against you Balaam the son of Beor from Pethor of Mesopotamia, to curse you. [^4] Nevertheless Yahweh your God wouldn’t listen to Balaam, but Yahweh your God turned the curse into a blessing to you, because Yahweh your God loved you. [^5] You shall not seek their peace nor their prosperity all your days forever. [^6] You shall not abhor an Edomite, for he is your brother. You shall not abhor an Egyptian, because you lived as a foreigner in his land. [^7] The children of the third generation who are born to them may enter into Yahweh’s assembly. [^8] When you go out and camp against your enemies, then you shall keep yourselves from every evil thing. [^9] If there is among you any man who is not clean by reason of that which happens to him by night, then shall he go outside of the camp. He shall not come within the camp; [^10] but it shall be, when evening comes, he shall bathe himself in water. When the sun is down, he shall come within the camp. [^11] You shall have a place also outside of the camp where you go relieve yourself. [^12] You shall have a trowel among your weapons. It shall be, when you relieve yourself, you shall dig with it, and shall turn back and cover your excrement; [^13] for Yahweh your God walks in the middle of your camp, to deliver you, and to give up your enemies before you. Therefore your camp shall be holy, that he may not see an unclean thing in you, and turn away from you. [^14] You shall not deliver to his master a servant who has escaped from his master to you. [^15] He shall dwell with you, among you, in the place which he shall choose within one of your gates, where it pleases him best. You shall not oppress him. [^16] There shall be no prostitute of the daughters of Israel, neither shall there be a sodomite of the sons of Israel. [^17] You shall not bring the hire of a prostitute, or the wages of a male prostitute,#23:18 literally, dog into the house of Yahweh your God for any vow; for both of these are an abomination to Yahweh your God. [^18] You shall not lend on interest to your brother: interest of money, interest of food, interest of anything that is lent on interest. [^19] You may charge a foreigner interest; but you shall not charge your brother interest, that Yahweh your God may bless you in all that you put your hand to, in the land where you go in to possess it. [^20] When you vow a vow to Yahweh your God, you shall not be slack to pay it, for Yahweh your God will surely require it of you; and it would be sin in you. [^21] But if you refrain from making a vow, it shall be no sin in you. [^22] You shall observe and do that which has gone out of your lips. Whatever you have vowed to Yahweh your God as a free will offering, which you have promised with your mouth, you must do. [^23] When you come into your neighbor’s vineyard, then you may eat your fill of grapes at your own pleasure; but you shall not put any in your container. [^24] When you come into your neighbor’s standing grain, then you may pluck the ears with your hand; but you shall not use a sickle on your neighbor’s standing grain. [^25] 

[[Deuteronomy - 22|<--]] Deuteronomy - 23 [[Deuteronomy - 24|-->]]

---
# Notes
