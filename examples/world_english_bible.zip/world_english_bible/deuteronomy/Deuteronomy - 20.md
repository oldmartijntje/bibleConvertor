---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 20 - World English Bible"
---
[[Deuteronomy - 19|<--]] Deuteronomy - 20 [[Deuteronomy - 21|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Deuteronomy]]

# Deuteronomy - 20

When you go out to battle against your enemies, and see horses, chariots, and a people more numerous than you, you shall not be afraid of them; for Yahweh your God, who brought you up out of the land of Egypt, is with you. [^1] It shall be, when you draw near to the battle, that the priest shall approach and speak to the people, [^2] and shall tell them, “Hear, Israel, you draw near today to battle against your enemies. Don’t let your heart faint! Don’t be afraid, nor tremble, neither be scared of them; [^3] for Yahweh your God is he who goes with you, to fight for you against your enemies, to save you.” [^4] The officers shall speak to the people, saying, “What man is there who has built a new house, and has not dedicated it? Let him go and return to his house, lest he die in the battle, and another man dedicate it. [^5] What man is there who has planted a vineyard, and has not used its fruit? Let him go and return to his house, lest he die in the battle, and another man use its fruit. [^6] What man is there who has pledged to be married to a wife, and has not taken her? Let him go and return to his house, lest he die in the battle, and another man take her.” [^7] The officers shall speak further to the people, and they shall say, “What man is there who is fearful and faint-hearted? Let him go and return to his house, lest his brother’s heart melt as his heart.” [^8] It shall be, when the officers have finished speaking to the people, that they shall appoint captains of armies at the head of the people. [^9] When you draw near to a city to fight against it, then proclaim peace to it. [^10] It shall be, if it gives you answer of peace and opens to you, then it shall be that all the people who are found therein shall become forced laborers to you, and shall serve you. [^11] If it will make no peace with you, but will make war against you, then you shall besiege it. [^12] When Yahweh your God delivers it into your hand, you shall strike every male of it with the edge of the sword; [^13] but the women, the little ones, the livestock, and all that is in the city, even all its plunder, you shall take for plunder for yourself. You may use the plunder of your enemies, which Yahweh your God has given you. [^14] Thus you shall do to all the cities which are very far off from you, which are not of the cities of these nations. [^15] But of the cities of these peoples that Yahweh your God gives you for an inheritance, you shall save alive nothing that breathes; [^16] but you shall utterly destroy them: the Hittite, the Amorite, the Canaanite, the Perizzite, the Hivite, and the Jebusite, as Yahweh your God has commanded you; [^17] that they not teach you to follow all their abominations, which they have done for their gods; so would you sin against Yahweh your God. [^18] When you shall besiege a city a long time, in making war against it to take it, you shall not destroy its trees by wielding an ax against them; for you may eat of them. You shall not cut them down, for is the tree of the field man, that it should be besieged by you? [^19] Only the trees that you know are not trees for food, you shall destroy and cut them down. You shall build bulwarks against the city that makes war with you, until it falls. [^20] 

[[Deuteronomy - 19|<--]] Deuteronomy - 20 [[Deuteronomy - 21|-->]]

---
# Notes
