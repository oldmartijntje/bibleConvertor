---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 10 - World English Bible"
---
[[Deuteronomy - 9|<--]] Deuteronomy - 10 [[Deuteronomy - 11|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Deuteronomy]]

# Deuteronomy - 10

At that time Yahweh said to me, “Cut two stone tablets like the first, and come up to me onto the mountain, and make an ark of wood. [^1] I will write on the tablets the words that were on the first tablets which you broke, and you shall put them in the ark.” [^2] So I made an ark of acacia wood, and cut two stone tablets like the first, and went up onto the mountain, having the two tablets in my hand. [^3] He wrote on the tablets, according to the first writing, the ten commandments, which Yahweh spoke to you on the mountain out of the middle of the fire in the day of the assembly; and Yahweh gave them to me. [^4] I turned and came down from the mountain, and put the tablets in the ark which I had made; and there they are as Yahweh commanded me. [^5] (The children of Israel traveled from Beeroth Bene Jaakan to Moserah. There Aaron died, and there he was buried; and Eleazar his son ministered in the priest’s office in his place. [^6] From there they traveled to Gudgodah; and from Gudgodah to Jotbathah, a land of brooks of water. [^7] At that time Yahweh set apart the tribe of Levi to bear the ark of Yahweh’s covenant, to stand before Yahweh to minister to him, and to bless in his name, to this day. [^8] Therefore Levi has no portion nor inheritance with his brothers; Yahweh is his inheritance, according as Yahweh your God spoke to him.) [^9] I stayed on the mountain, as at the first time, forty days and forty nights; and Yahweh listened to me that time also. Yahweh would not destroy you. [^10] Yahweh said to me, “Arise, take your journey before the people; and they shall go in and possess the land which I swore to their fathers to give to them.” [^11] Now, Israel, what does Yahweh your God require of you, but to fear Yahweh your God, to walk in all his ways, to love him, and to serve Yahweh your God with all your heart and with all your soul, [^12] to keep Yahweh’s commandments and statutes, which I command you today for your good? [^13] Behold, to Yahweh your God belongs heaven, the heaven of heavens, and the earth, with all that is therein. [^14] Only Yahweh had a delight in your fathers to love them, and he chose their offspring after them, even you above all peoples, as it is today. [^15] Circumcise therefore the foreskin of your heart, and be no more stiff-necked. [^16] For Yahweh your God, he is God of gods and Lord of lords, the great God, the mighty, and the awesome, who doesn’t respect persons or take bribes. [^17] He executes justice for the fatherless and widow and loves the foreigner in giving him food and clothing. [^18] Therefore love the foreigner, for you were foreigners in the land of Egypt. [^19] You shall fear Yahweh your God. You shall serve him. You shall cling to him, and you shall swear by his name. [^20] He is your praise, and he is your God, who has done for you these great and awesome things which your eyes have seen. [^21] Your fathers went down into Egypt with seventy persons; and now Yahweh your God has made you as the stars of the sky for multitude. [^22] 

[[Deuteronomy - 9|<--]] Deuteronomy - 10 [[Deuteronomy - 11|-->]]

---
# Notes
