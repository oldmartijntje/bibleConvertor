---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 25 - World English Bible"
---
[[Deuteronomy - 24|<--]] Deuteronomy - 25 [[Deuteronomy - 26|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Deuteronomy]]

# Deuteronomy - 25

If there is a controversy between men, and they come to judgment and the judges judge them, then they shall justify the righteous and condemn the wicked. [^1] It shall be, if the wicked man is worthy to be beaten, that the judge shall cause him to lie down and to be beaten before his face, according to his wickedness, by number. [^2] He may sentence him to no more than forty stripes. He shall not give more, lest if he should give more and beat him more than that many stripes, then your brother will be degraded in your sight. [^3] You shall not muzzle the ox when he treads out the grain. [^4] If brothers dwell together, and one of them dies and has no son, the wife of the dead shall not be married outside to a stranger. Her husband’s brother shall go in to her, and take her as his wife, and perform the duty of a husband’s brother to her. [^5] It shall be that the firstborn whom she bears shall succeed in the name of his brother who is dead, that his name not be blotted out of Israel. [^6] If the man doesn’t want to take his brother’s wife, then his brother’s wife shall go up to the gate to the elders, and say, “My husband’s brother refuses to raise up to his brother a name in Israel. He will not perform the duty of a husband’s brother to me.” [^7] Then the elders of his city shall call him, and speak to him. If he stands and says, “I don’t want to take her,” [^8] then his brother’s wife shall come to him in the presence of the elders, and loose his sandal from off his foot, and spit in his face. She shall answer and say, “So shall it be done to the man who does not build up his brother’s house.” [^9] His name shall be called in Israel, “The house of him who had his sandal removed.” [^10] When men strive against each other, and the wife of one draws near to deliver her husband out of the hand of him who strikes him, and puts out her hand, and grabs him by his private parts, [^11] then you shall cut off her hand. Your eye shall have no pity. [^12] You shall not have in your bag diverse weights, one heavy and one light. [^13] You shall not have in your house diverse measures, one large and one small. [^14] You shall have a perfect and just weight. You shall have a perfect and just measure, that your days may be long in the land which Yahweh your God gives you. [^15] For all who do such things, all who do unrighteously, are an abomination to Yahweh your God. [^16] Remember what Amalek did to you by the way as you came out of Egypt, [^17] how he met you by the way, and struck the rearmost of you, all who were feeble behind you, when you were faint and weary; and he didn’t fear God. [^18] Therefore it shall be, when Yahweh your God has given you rest from all your enemies all around, in the land which Yahweh your God gives you for an inheritance to possess it, that you shall blot out the memory of Amalek from under the sky. You shall not forget. [^19] 

[[Deuteronomy - 24|<--]] Deuteronomy - 25 [[Deuteronomy - 26|-->]]

---
# Notes
