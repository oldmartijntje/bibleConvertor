---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 26 - World English Bible"
---
[[Deuteronomy - 25|<--]] Deuteronomy - 26 [[Deuteronomy - 27|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Deuteronomy]]

# Deuteronomy - 26

It shall be, when you have come in to the land which Yahweh your God gives you for an inheritance, possess it, and dwell in it, [^1] that you shall take some of the first of all the fruit of the ground, which you shall bring in from your land that Yahweh your God gives you. You shall put it in a basket, and shall go to the place which Yahweh your God shall choose to cause his name to dwell there. [^2] You shall come to the priest who shall be in those days, and tell him, “I profess today to Yahweh your God, that I have come to the land which Yahweh swore to our fathers to give us.” [^3] The priest shall take the basket out of your hand, and set it down before Yahweh your God’s altar. [^4] You shall answer and say before Yahweh your God, “My father#26:5 or, forefather was a Syrian ready to perish. He went down into Egypt, and lived there, few in number. There he became a great, mighty, and populous nation. [^5] The Egyptians mistreated us, afflicted us, and imposed hard labor on us. [^6] Then we cried to Yahweh, the God of our fathers. Yahweh heard our voice, and saw our affliction, our toil, and our oppression. [^7] Yahweh brought us out of Egypt with a mighty hand, with an outstretched arm, with great terror, with signs, and with wonders; [^8] and he has brought us into this place, and has given us this land, a land flowing with milk and honey. [^9] Now, behold, I have brought the first of the fruit of the ground, which you, Yahweh, have given me.” You shall set it down before Yahweh your God, and worship before Yahweh your God. [^10] You shall rejoice in all the good which Yahweh your God has given to you, and to your house, you, and the Levite, and the foreigner who is among you. [^11] When you have finished tithing all the tithe of your increase in the third year, which is the year of tithing, then you shall give it to the Levite, to the foreigner, to the fatherless, and to the widow, that they may eat within your gates and be filled. [^12] You shall say before Yahweh your God, “I have put away the holy things out of my house, and also have given them to the Levite, to the foreigner, to the fatherless, and to the widow, according to all your commandment which you have commanded me. I have not transgressed any of your commandments, neither have I forgotten them. [^13] I have not eaten of it in my mourning, neither have I removed any of it while I was unclean, nor given of it for the dead. I have listened to Yahweh my God’s voice. I have done according to all that you have commanded me. [^14] Look down from your holy habitation, from heaven, and bless your people Israel, and the ground which you have given us, as you swore to our fathers, a land flowing with milk and honey.” [^15] Today Yahweh your God commands you to do these statutes and ordinances. You shall therefore keep and do them with all your heart and with all your soul. [^16] You have declared today that Yahweh is your God, and that you would walk in his ways, keep his statutes, his commandments, and his ordinances, and listen to his voice. [^17] Yahweh has declared today that you are a people for his own possession, as he has promised you, and that you should keep all his commandments. [^18] He will make you high above all nations that he has made, in praise, in name, and in honor, and that you may be a holy people to Yahweh your God, as he has spoken. [^19] 

[[Deuteronomy - 25|<--]] Deuteronomy - 26 [[Deuteronomy - 27|-->]]

---
# Notes
