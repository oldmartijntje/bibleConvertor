---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 34 - World English Bible"
---
[[Deuteronomy - 33|<--]] Deuteronomy - 34

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Deuteronomy]]

# Deuteronomy - 34

Moses went up from the plains of Moab to Mount Nebo, to the top of Pisgah, that is opposite Jericho. Yahweh showed him all the land of Gilead to Dan, [^1] and all Naphtali, and the land of Ephraim and Manasseh, and all the land of Judah, to the Western Sea, [^2] and the south,#34:3 or, Negev and the Plain of the valley of Jericho the city of palm trees, to Zoar. [^3] Yahweh said to him, “This is the land which I swore to Abraham, to Isaac, and to Jacob, saying, ‘I will give it to your offspring.’ I have caused you to see it with your eyes, but you shall not go over there.” [^4] So Moses the servant of Yahweh died there in the land of Moab, according to Yahweh’s word. [^5] He buried him in the valley in the land of Moab opposite Beth Peor, but no man knows where his tomb is to this day. [^6] Moses was one hundred twenty years old when he died. His eye was not dim, nor his strength gone. [^7] The children of Israel wept for Moses in the plains of Moab thirty days, until the days of weeping in the mourning for Moses were ended. [^8] Joshua the son of Nun was full of the spirit of wisdom, for Moses had laid his hands on him. The children of Israel listened to him, and did as Yahweh commanded Moses. [^9] Since then, there has not arisen a prophet in Israel like Moses, whom Yahweh knew face to face, [^10] in all the signs and the wonders which Yahweh sent him to do in the land of Egypt, to Pharaoh, and to all his servants, and to all his land, [^11] and in all the mighty hand, and in all the awesome deeds, which Moses did in the sight of all Israel. [^12] 

[[Deuteronomy - 33|<--]] Deuteronomy - 34

---
# Notes
