---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 17 - World English Bible"
---
[[Leviticus - 16|<--]] Leviticus - 17 [[Leviticus - 18|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Leviticus]]

# Leviticus - 17

Yahweh spoke to Moses, saying, [^1] “Speak to Aaron, and to his sons, and to all the children of Israel, and say to them, ‘This is the thing which Yahweh has commanded: [^2] Whatever man there is of the house of Israel who kills a bull, or lamb, or goat in the camp, or who kills it outside the camp, [^3] and hasn’t brought it to the door of the Tent of Meeting to offer it as an offering to Yahweh before Yahweh’s tabernacle: blood shall be imputed to that man. He has shed blood. That man shall be cut off from among his people. [^4] This is to the end that the children of Israel may bring their sacrifices, which they sacrifice in the open field, that they may bring them to Yahweh, to the door of the Tent of Meeting, to the priest, and sacrifice them for sacrifices of peace offerings to Yahweh. [^5] The priest shall sprinkle the blood on Yahweh’s altar at the door of the Tent of Meeting, and burn the fat for a pleasant aroma to Yahweh. [^6] They shall no more sacrifice their sacrifices to the goat idols, after which they play the prostitute. This shall be a statute forever to them throughout their generations.’ [^7] “You shall say to them, ‘Any man there is of the house of Israel, or of the strangers who live as foreigners among them, who offers a burnt offering or sacrifice, [^8] and doesn’t bring it to the door of the Tent of Meeting to sacrifice it to Yahweh, that man shall be cut off from his people. [^9] “‘Any man of the house of Israel, or of the strangers who live as foreigners among them, who eats any kind of blood, I will set my face against that soul who eats blood, and will cut him off from among his people. [^10] For the life of the flesh is in the blood. I have given it to you on the altar to make atonement for your souls; for it is the blood that makes atonement by reason of the life. [^11] Therefore I have said to the children of Israel, “No person among you may eat blood, nor may any stranger who lives as a foreigner among you eat blood.” [^12] “‘Whatever man there is of the children of Israel, or of the strangers who live as foreigners among them, who takes in hunting any animal or bird that may be eaten, he shall pour out its blood, and cover it with dust. [^13] For as to the life of all flesh, its blood is with its life. Therefore I said to the children of Israel, “You shall not eat the blood of any kind of flesh; for the life of all flesh is its blood. Whoever eats it shall be cut off.” [^14] “‘Every person that eats what dies of itself, or that which is torn by animals, whether he is native-born or a foreigner, shall wash his clothes, and bathe himself in water, and be unclean until the evening. Then he shall be clean. [^15] But if he doesn’t wash them, or bathe his flesh, then he shall bear his iniquity.’” [^16] 

[[Leviticus - 16|<--]] Leviticus - 17 [[Leviticus - 18|-->]]

---
# Notes
