---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 9 - World English Bible"
---
[[Leviticus - 8|<--]] Leviticus - 9 [[Leviticus - 10|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Leviticus]]

# Leviticus - 9

On the eighth day, Moses called Aaron and his sons, and the elders of Israel; [^1] and he said to Aaron, “Take a calf from the herd for a sin offering, and a ram for a burnt offering, without defect, and offer them before Yahweh. [^2] You shall speak to the children of Israel, saying, ‘Take a male goat for a sin offering; and a calf and a lamb, both a year old, without defect, for a burnt offering; [^3] and a bull and a ram for peace offerings, to sacrifice before Yahweh; and a meal offering mixed with oil: for today Yahweh appears to you.’” [^4] They brought what Moses commanded before the Tent of Meeting. All the congregation came near and stood before Yahweh. [^5] Moses said, “This is the thing which Yahweh commanded that you should do; and Yahweh’s glory shall appear to you.” [^6] Moses said to Aaron, “Draw near to the altar, and offer your sin offering, and your burnt offering, and make atonement for yourself, and for the people; and offer the offering of the people, and make atonement for them, as Yahweh commanded.” [^7] So Aaron came near to the altar, and killed the calf of the sin offering, which was for himself. [^8] The sons of Aaron presented the blood to him; and he dipped his finger in the blood, and put it on the horns of the altar, and poured out the blood at the base of the altar; [^9] but the fat, and the kidneys, and the cover from the liver of the sin offering, he burned upon the altar, as Yahweh commanded Moses. [^10] The meat and the skin he burned with fire outside the camp. [^11] He killed the burnt offering; and Aaron’s sons delivered the blood to him, and he sprinkled it around on the altar. [^12] They delivered the burnt offering to him, piece by piece, and the head. He burned them upon the altar. [^13] He washed the innards and the legs, and burned them on the burnt offering on the altar. [^14] He presented the people’s offering, and took the goat of the sin offering which was for the people, and killed it, and offered it for sin, like the first. [^15] He presented the burnt offering, and offered it according to the ordinance. [^16] He presented the meal offering, and filled his hand from there, and burned it upon the altar, in addition to the burnt offering of the morning. [^17] He also killed the bull and the ram, the sacrifice of peace offerings, which was for the people. Aaron’s sons delivered to him the blood, which he sprinkled around on the altar; [^18] and the fat of the bull and of the ram, the fat tail, and that which covers the innards, and the kidneys, and the cover of the liver; [^19] and they put the fat upon the breasts, and he burned the fat on the altar. [^20] Aaron waved the breasts and the right thigh for a wave offering before Yahweh, as Moses commanded. [^21] Aaron lifted up his hands toward the people, and blessed them; and he came down from offering the sin offering, and the burnt offering, and the peace offerings. [^22] Moses and Aaron went into the Tent of Meeting, and came out, and blessed the people; and Yahweh’s glory appeared to all the people. [^23] Fire came out from before Yahweh, and consumed the burnt offering and the fat upon the altar. When all the people saw it, they shouted, and fell on their faces. [^24] 

[[Leviticus - 8|<--]] Leviticus - 9 [[Leviticus - 10|-->]]

---
# Notes
