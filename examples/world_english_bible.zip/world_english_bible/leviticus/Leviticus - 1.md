---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 1 - World English Bible"
---
Leviticus - 1 [[Leviticus - 2|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Leviticus]]

# Leviticus - 1

Yahweh#1:1 “Yahweh” is God’s proper Name, sometimes rendered “Lord” (all caps) in other translations. called to Moses, and spoke to him from the Tent of Meeting, saying, [^1] “Speak to the children of Israel, and tell them, ‘When anyone of you offers an offering to Yahweh, you shall offer your offering of the livestock, from the herd and from the flock. [^2] “‘If his offering is a burnt offering from the herd, he shall offer a male without defect. He shall offer it at the door of the Tent of Meeting, that he may be accepted before Yahweh. [^3] He shall lay his hand on the head of the burnt offering, and it shall be accepted for him to make atonement for him. [^4] He shall kill the bull before Yahweh. Aaron’s sons, the priests, shall present the blood and sprinkle the blood around on the altar that is at the door of the Tent of Meeting. [^5] He shall skin the burnt offering and cut it into pieces. [^6] The sons of Aaron the priest shall put fire on the altar, and lay wood in order on the fire; [^7] and Aaron’s sons, the priests, shall lay the pieces, the head, and the fat in order on the wood that is on the fire which is on the altar; [^8] but he shall wash its innards and its legs with water. The priest shall burn all of it on the altar, for a burnt offering, an offering made by fire, of a pleasant aroma to Yahweh. [^9] “‘If his offering is from the flock, from the sheep or from the goats, for a burnt offering, he shall offer a male without defect. [^10] He shall kill it on the north side of the altar before Yahweh. Aaron’s sons, the priests, shall sprinkle its blood around on the altar. [^11] He shall cut it into its pieces, with its head and its fat. The priest shall lay them in order on the wood that is on the fire which is on the altar, [^12] but the innards and the legs he shall wash with water. The priest shall offer the whole, and burn it on the altar. It is a burnt offering, an offering made by fire, of a pleasant aroma to Yahweh. [^13] “‘If his offering to Yahweh is a burnt offering of birds, then he shall offer his offering from turtledoves or of young pigeons. [^14] The priest shall bring it to the altar, and wring off its head, and burn it on the altar; and its blood shall be drained out on the side of the altar; [^15] and he shall take away its crop and its feathers, and cast it beside the altar on the east part, in the place of the ashes. [^16] He shall tear it by its wings, but shall not divide it apart. The priest shall burn it on the altar, on the wood that is on the fire. It is a burnt offering, an offering made by fire, of a pleasant aroma to Yahweh. [^17] 

Leviticus - 1 [[Leviticus - 2|-->]]

---
# Notes
