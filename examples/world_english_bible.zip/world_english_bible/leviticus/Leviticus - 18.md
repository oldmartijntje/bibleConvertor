---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 18 - World English Bible"
---
[[Leviticus - 17|<--]] Leviticus - 18 [[Leviticus - 19|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Leviticus]]

# Leviticus - 18

Yahweh said to Moses, [^1] “Speak to the children of Israel, and say to them, ‘I am Yahweh your God. [^2] You shall not do as they do in the land of Egypt, where you lived. You shall not do as they do in the land of Canaan, where I am bringing you. You shall not follow their statutes. [^3] You shall do my ordinances. You shall keep my statutes and walk in them. I am Yahweh your God. [^4] You shall therefore keep my statutes and my ordinances, which if a man does, he shall live in them. I am Yahweh. [^5] “‘None of you shall approach any close relatives, to uncover their nakedness: I am Yahweh. [^6] “‘You shall not uncover the nakedness of your father, nor the nakedness of your mother: she is your mother. You shall not uncover her nakedness. [^7] “‘You shall not uncover the nakedness of your father’s wife. It is your father’s nakedness. [^8] “‘You shall not uncover the nakedness of your sister, the daughter of your father, or the daughter of your mother, whether born at home or born abroad. [^9] “‘You shall not uncover the nakedness of your son’s daughter, or of your daughter’s daughter, even their nakedness; for theirs is your own nakedness. [^10] “‘You shall not uncover the nakedness of your father’s wife’s daughter, conceived by your father, since she is your sister. [^11] “‘You shall not uncover the nakedness of your father’s sister. She is your father’s near kinswoman. [^12] “‘You shall not uncover the nakedness of your mother’s sister, for she is your mother’s near kinswoman. [^13] “‘You shall not uncover the nakedness of your father’s brother. You shall not approach his wife. She is your aunt. [^14] “‘You shall not uncover the nakedness of your daughter-in-law. She is your son’s wife. You shall not uncover her nakedness. [^15] “‘You shall not uncover the nakedness of your brother’s wife. It is your brother’s nakedness. [^16] “‘You shall not uncover the nakedness of a woman and her daughter. You shall not take her son’s daughter, or her daughter’s daughter, to uncover her nakedness. They are near kinswomen. It is wickedness. [^17] “‘You shall not take a wife in addition to her sister, to be a rival, to uncover her nakedness, while her sister is still alive. [^18] “‘You shall not approach a woman to uncover her nakedness, as long as she is impure by her uncleanness. [^19] “‘You shall not lie carnally with your neighbor’s wife, and defile yourself with her. [^20] “‘You shall not give any of your children as a sacrifice to Molech. You shall not profane the name of your God. I am Yahweh. [^21] “‘You shall not lie with a man as with a woman. That is detestable. [^22] “‘You shall not lie with any animal to defile yourself with it. No woman may give herself to an animal, to lie down with it: it is a perversion. [^23] “‘Don’t defile yourselves in any of these things; for in all these the nations which I am casting out before you were defiled. [^24] The land was defiled. Therefore I punished its iniquity, and the land vomited out her inhabitants. [^25] You therefore shall keep my statutes and my ordinances, and shall not do any of these abominations; neither the native-born, nor the stranger who lives as a foreigner among you [^26] (for the men of the land that were before you had done all these abominations, and the land became defiled), [^27] that the land not vomit you out also, when you defile it, as it vomited out the nation that was before you. [^28] “‘For whoever shall do any of these abominations, even the souls that do them shall be cut off from among their people. [^29] Therefore you shall keep my requirements, that you do not practice any of these abominable customs which were practiced before you, and that you do not defile yourselves with them. I am Yahweh your God.’” [^30] 

[[Leviticus - 17|<--]] Leviticus - 18 [[Leviticus - 19|-->]]

---
# Notes
