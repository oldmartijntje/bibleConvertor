---
translation: World English Bible
aliases:
  - "Leviticus - World English Bible"
tags:
  - "#bible/type/book"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
---
[[Exodus|<--]] Leviticus [[Numbers|-->]]

# Leviticus - World English Bible

The Leviticus book has 27 chapters. It is part of the old testament.

## Chapters

- Leviticus [[Leviticus - 1|chapter 1]]
- Leviticus [[Leviticus - 2|chapter 2]]
- Leviticus [[Leviticus - 3|chapter 3]]
- Leviticus [[Leviticus - 4|chapter 4]]
- Leviticus [[Leviticus - 5|chapter 5]]
- Leviticus [[Leviticus - 6|chapter 6]]
- Leviticus [[Leviticus - 7|chapter 7]]
- Leviticus [[Leviticus - 8|chapter 8]]
- Leviticus [[Leviticus - 9|chapter 9]]
- Leviticus [[Leviticus - 10|chapter 10]]
- Leviticus [[Leviticus - 11|chapter 11]]
- Leviticus [[Leviticus - 12|chapter 12]]
- Leviticus [[Leviticus - 13|chapter 13]]
- Leviticus [[Leviticus - 14|chapter 14]]
- Leviticus [[Leviticus - 15|chapter 15]]
- Leviticus [[Leviticus - 16|chapter 16]]
- Leviticus [[Leviticus - 17|chapter 17]]
- Leviticus [[Leviticus - 18|chapter 18]]
- Leviticus [[Leviticus - 19|chapter 19]]
- Leviticus [[Leviticus - 20|chapter 20]]
- Leviticus [[Leviticus - 21|chapter 21]]
- Leviticus [[Leviticus - 22|chapter 22]]
- Leviticus [[Leviticus - 23|chapter 23]]
- Leviticus [[Leviticus - 24|chapter 24]]
- Leviticus [[Leviticus - 25|chapter 25]]
- Leviticus [[Leviticus - 26|chapter 26]]
- Leviticus [[Leviticus - 27|chapter 27]]

[[Exodus|<--]] Leviticus [[Numbers|-->]]

---
# Notes
