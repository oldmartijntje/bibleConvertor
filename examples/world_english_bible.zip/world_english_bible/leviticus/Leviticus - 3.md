---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 3 - World English Bible"
---
[[Leviticus - 2|<--]] Leviticus - 3 [[Leviticus - 4|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Leviticus]]

# Leviticus - 3

“‘If his offering is a sacrifice of peace offerings, if he offers it from the herd, whether male or female, he shall offer it without defect before Yahweh. [^1] He shall lay his hand on the head of his offering, and kill it at the door of the Tent of Meeting. Aaron’s sons, the priests, shall sprinkle the blood around on the altar. [^2] He shall offer of the sacrifice of peace offerings an offering made by fire to Yahweh. The fat that covers the innards, and all the fat that is on the innards, [^3] and the two kidneys, and the fat that is on them, which is by the loins, and the cover on the liver, with the kidneys, he shall take away. [^4] Aaron’s sons shall burn it on the altar on the burnt offering, which is on the wood that is on the fire: it is an offering made by fire, of a pleasant aroma to Yahweh. [^5] “‘If his offering for a sacrifice of peace offerings to Yahweh is from the flock, either male or female, he shall offer it without defect. [^6] If he offers a lamb for his offering, then he shall offer it before Yahweh; [^7] and he shall lay his hand on the head of his offering, and kill it before the Tent of Meeting. Aaron’s sons shall sprinkle its blood around on the altar. [^8] He shall offer from the sacrifice of peace offerings an offering made by fire to Yahweh; its fat, the entire tail fat, he shall take away close to the backbone; and the fat that covers the entrails, and all the fat that is on the entrails, [^9] and the two kidneys, and the fat that is on them, which is by the loins, and the cover on the liver, with the kidneys, he shall take away. [^10] The priest shall burn it on the altar: it is the food of the offering made by fire to Yahweh. [^11] “‘If his offering is a goat, then he shall offer it before Yahweh. [^12] He shall lay his hand on its head, and kill it before the Tent of Meeting; and the sons of Aaron shall sprinkle its blood around on the altar. [^13] He shall offer from it as his offering, an offering made by fire to Yahweh; the fat that covers the innards, and all the fat that is on the innards, [^14] and the two kidneys, and the fat that is on them, which is by the loins, and the cover on the liver, with the kidneys, he shall take away. [^15] The priest shall burn them on the altar: it is the food of the offering made by fire, for a pleasant aroma; all the fat is Yahweh’s. [^16] “‘It shall be a perpetual statute throughout your generations in all your dwellings, that you shall eat neither fat nor blood.’” [^17] 

[[Leviticus - 2|<--]] Leviticus - 3 [[Leviticus - 4|-->]]

---
# Notes
