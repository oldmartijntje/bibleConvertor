---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 24 - World English Bible"
---
[[Leviticus - 23|<--]] Leviticus - 24 [[Leviticus - 25|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Leviticus]]

# Leviticus - 24

Yahweh spoke to Moses, saying, [^1] “Command the children of Israel, that they bring to you pure olive oil beaten for the light, to cause a lamp to burn continually. [^2] Outside of the veil of the Testimony, in the Tent of Meeting, Aaron shall keep it in order from evening to morning before Yahweh continually. It shall be a statute forever throughout your generations. [^3] He shall keep in order the lamps on the pure gold lamp stand before Yahweh continually. [^4] “You shall take fine flour, and bake twelve cakes of it: two tenths of an ephah#24:5 1 ephah is about 22 liters or about 2/3 of a bushel shall be in one cake. [^5] You shall set them in two rows, six on a row, on the pure gold table before Yahweh. [^6] You shall put pure frankincense on each row, that it may be to the bread for a memorial, even an offering made by fire to Yahweh. [^7] Every Sabbath day he shall set it in order before Yahweh continually. It is an everlasting covenant on the behalf of the children of Israel. [^8] It shall be for Aaron and his sons. They shall eat it in a holy place; for it is most holy to him of the offerings of Yahweh made by fire by a perpetual statute.” [^9] The son of an Israelite woman, whose father was an Egyptian, went out among the children of Israel; and the son of the Israelite woman and a man of Israel strove together in the camp. [^10] The son of the Israelite woman blasphemed the Name, and cursed; and they brought him to Moses. His mother’s name was Shelomith, the daughter of Dibri, of the tribe of Dan. [^11] They put him in custody until Yahweh’s will should be declared to them. [^12] Yahweh spoke to Moses, saying, [^13] “Bring him who cursed out of the camp; and let all who heard him lay their hands on his head, and let all the congregation stone him. [^14] You shall speak to the children of Israel, saying, ‘Whoever curses his God shall bear his sin. [^15] He who blasphemes Yahweh’s name, he shall surely be put to death. All the congregation shall certainly stone him. The foreigner as well as the native-born shall be put to death when he blasphemes the Name. [^16] “‘He who strikes any man mortally shall surely be put to death. [^17] He who strikes an animal mortally shall make it good, life for life. [^18] If anyone injures his neighbor, it shall be done to him as he has done: [^19] fracture for fracture, eye for eye, tooth for tooth. It shall be done to him as he has injured someone. [^20] He who kills an animal shall make it good; and he who kills a man shall be put to death. [^21] You shall have one kind of law for the foreigner as well as the native-born; for I am Yahweh your God.’” [^22] Moses spoke to the children of Israel; and they brought him who had cursed out of the camp, and stoned him with stones. The children of Israel did as Yahweh commanded Moses. [^23] 

[[Leviticus - 23|<--]] Leviticus - 24 [[Leviticus - 25|-->]]

---
# Notes
