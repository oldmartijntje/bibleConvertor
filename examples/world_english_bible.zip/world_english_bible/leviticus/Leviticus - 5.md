---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 5 - World English Bible"
---
[[Leviticus - 4|<--]] Leviticus - 5 [[Leviticus - 6|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Leviticus]]

# Leviticus - 5

“‘If anyone sins, in that he hears a public adjuration to testify, he being a witness, whether he has seen or known, if he doesn’t report it, then he shall bear his iniquity. [^1] “‘Or if anyone touches any unclean thing, whether it is the carcass of an unclean animal, or the carcass of unclean livestock, or the carcass of unclean creeping things, and it is hidden from him, and he is unclean, then he shall be guilty. [^2] “‘Or if he touches the uncleanness of man, whatever his uncleanness is with which he is unclean, and it is hidden from him; when he knows of it, then he shall be guilty. [^3] “‘Or if anyone swears rashly with his lips to do evil or to do good—whatever it is that a man might utter rashly with an oath, and it is hidden from him—when he knows of it, then he will be guilty of one of these. [^4] It shall be, when he is guilty of one of these, he shall confess that in which he has sinned; [^5] and he shall bring his trespass offering to Yahweh for his sin which he has sinned: a female from the flock, a lamb or a goat, for a sin offering; and the priest shall make atonement for him concerning his sin. [^6] “‘If he can’t afford a lamb, then he shall bring his trespass offering for that in which he has sinned, two turtledoves, or two young pigeons, to Yahweh; one for a sin offering, and the other for a burnt offering. [^7] He shall bring them to the priest, who shall first offer the one which is for the sin offering. He shall wring off its head from its neck, but shall not sever it completely. [^8] He shall sprinkle some of the blood of the sin offering on the side of the altar; and the rest of the blood shall be drained out at the base of the altar. It is a sin offering. [^9] He shall offer the second for a burnt offering, according to the ordinance; and the priest shall make atonement for him concerning his sin which he has sinned, and he shall be forgiven. [^10] “‘But if he can’t afford two turtledoves or two young pigeons, then he shall bring as his offering for that in which he has sinned, one tenth of an ephah#5:11 1 ephah is about 22 liters or about 2/3 of a bushel of fine flour for a sin offering. He shall put no oil on it, and he shall not put any frankincense on it, for it is a sin offering. [^11] He shall bring it to the priest, and the priest shall take his handful of it as the memorial portion, and burn it on the altar, on the offerings of Yahweh made by fire. It is a sin offering. [^12] The priest shall make atonement for him concerning his sin that he has sinned in any of these things, and he will be forgiven; and the rest shall be the priest’s, as the meal offering.’” [^13] Yahweh spoke to Moses, saying, [^14] “If anyone commits a trespass, and sins unwittingly regarding Yahweh’s holy things, then he shall bring his trespass offering to Yahweh: a ram without defect from the flock, according to your estimation in silver by shekels, according to the shekel#5:15 A shekel is about 10 grams or about 0.35 ounces. of the sanctuary, for a trespass offering. [^15] He shall make restitution for that which he has done wrong regarding the holy thing, and shall add a fifth part to it, and give it to the priest; and the priest shall make atonement for him with the ram of the trespass offering, and he will be forgiven. [^16] “If anyone sins, doing any of the things which Yahweh has commanded not to be done, though he didn’t know it, he is still guilty, and shall bear his iniquity. [^17] He shall bring a ram without defect from of the flock, according to your estimation, for a trespass offering, to the priest; and the priest shall make atonement for him concerning the thing in which he sinned and didn’t know it, and he will be forgiven. [^18] It is a trespass offering. He is certainly guilty before Yahweh.” [^19] 

[[Leviticus - 4|<--]] Leviticus - 5 [[Leviticus - 6|-->]]

---
# Notes
