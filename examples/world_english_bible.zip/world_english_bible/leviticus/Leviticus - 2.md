---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 2 - World English Bible"
---
[[Leviticus - 1|<--]] Leviticus - 2 [[Leviticus - 3|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Leviticus]]

# Leviticus - 2

“‘When anyone offers an offering of a meal offering to Yahweh, his offering shall be of fine flour. He shall pour oil on it, and put frankincense on it. [^1] He shall bring it to Aaron’s sons, the priests. He shall take his handful of its fine flour, and of its oil, with all its frankincense, and the priest shall burn its memorial on the altar, an offering made by fire, of a pleasant aroma to Yahweh. [^2] That which is left of the meal offering shall be Aaron’s and his sons’. It is a most holy part of the offerings of Yahweh made by fire. [^3] “‘When you offer an offering of a meal offering baked in the oven, it shall be unleavened cakes of fine flour mixed with oil, or unleavened wafers anointed with oil. [^4] If your offering is a meal offering made on a griddle, it shall be of unleavened fine flour, mixed with oil. [^5] You shall cut it in pieces, and pour oil on it. It is a meal offering. [^6] If your offering is a meal offering of the pan, it shall be made of fine flour with oil. [^7] You shall bring the meal offering that is made of these things to Yahweh. It shall be presented to the priest, and he shall bring it to the altar. [^8] The priest shall take from the meal offering its memorial, and shall burn it on the altar, an offering made by fire, of a pleasant aroma to Yahweh. [^9] That which is left of the meal offering shall be Aaron’s and his sons’. It is a most holy part of the offerings of Yahweh made by fire. [^10] “‘No meal offering which you shall offer to Yahweh shall be made with yeast; for you shall burn no yeast, nor any honey, as an offering made by fire to Yahweh. [^11] As an offering of first fruits you shall offer them to Yahweh, but they shall not rise up as a pleasant aroma on the altar. [^12] Every offering of your meal offering you shall season with salt. You shall not allow the salt of the covenant of your God#2:13 The Hebrew word rendered “God” is “אֱלֹהִ֑ים” (Elohim). to be lacking from your meal offering. With all your offerings you shall offer salt. [^13] “‘If you offer a meal offering of first fruits to Yahweh, you shall offer for the meal offering of your first fruits fresh heads of grain parched with fire and crushed. [^14] You shall put oil on it and lay frankincense on it. It is a meal offering. [^15] The priest shall burn as its memorial part of its crushed grain and part of its oil, along with all its frankincense. It is an offering made by fire to Yahweh. [^16] 

[[Leviticus - 1|<--]] Leviticus - 2 [[Leviticus - 3|-->]]

---
# Notes
