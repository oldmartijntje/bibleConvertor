---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 12 - World English Bible"
---
[[Leviticus - 11|<--]] Leviticus - 12 [[Leviticus - 13|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Leviticus]]

# Leviticus - 12

Yahweh spoke to Moses, saying, [^1] “Speak to the children of Israel, saying, ‘If a woman conceives, and bears a male child, then she shall be unclean seven days; as in the days of her monthly period she shall be unclean. [^2] In the eighth day the flesh of his foreskin shall be circumcised. [^3] She shall continue in the blood of purification thirty-three days. She shall not touch any holy thing, nor come into the sanctuary, until the days of her purifying are completed. [^4] But if she bears a female child, then she shall be unclean two weeks, as in her period; and she shall continue in the blood of purification sixty-six days. [^5] “‘When the days of her purification are completed for a son or for a daughter, she shall bring to the priest at the door of the Tent of Meeting, a year old lamb for a burnt offering, and a young pigeon or a turtledove, for a sin offering. [^6] He shall offer it before Yahweh, and make atonement for her; then she shall be cleansed from the fountain of her blood.“‘This is the law for her who bears, whether a male or a female. [^7] If she cannot afford a lamb, then she shall take two turtledoves or two young pigeons: the one for a burnt offering, and the other for a sin offering. The priest shall make atonement for her, and she shall be clean.’” [^8] 

[[Leviticus - 11|<--]] Leviticus - 12 [[Leviticus - 13|-->]]

---
# Notes
