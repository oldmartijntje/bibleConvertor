---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 10 - World English Bible"
---
[[Leviticus - 9|<--]] Leviticus - 10 [[Leviticus - 11|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Leviticus]]

# Leviticus - 10

Nadab and Abihu, the sons of Aaron, each took his censer, and put fire in it, and laid incense on it, and offered strange fire before Yahweh, which he had not commanded them. [^1] Fire came out from before Yahweh, and devoured them, and they died before Yahweh. [^2] Then Moses said to Aaron, “This is what Yahweh spoke of, saying,‘I will show myself holy to those who come near me,and before all the people I will be glorified.’”Aaron held his peace. [^3] Moses called Mishael and Elzaphan, the sons of Uzziel the uncle of Aaron, and said to them, “Draw near, carry your brothers from before the sanctuary out of the camp.” [^4] So they came near, and carried them in their tunics out of the camp, as Moses had said. [^5] Moses said to Aaron, and to Eleazar and to Ithamar, his sons, “Don’t let the hair of your heads go loose, and don’t tear your clothes, so that you don’t die, and so that he will not be angry with all the congregation; but let your brothers, the whole house of Israel, bewail the burning which Yahweh has kindled. [^6] You shall not go out from the door of the Tent of Meeting, lest you die; for the anointing oil of Yahweh is on you.” They did according to the word of Moses. [^7] Then Yahweh said to Aaron, [^8] “You and your sons are not to drink wine or strong drink whenever you go into the Tent of Meeting, or you will die. This shall be a statute forever throughout your generations. [^9] You are to make a distinction between the holy and the common, and between the unclean and the clean. [^10] You are to teach the children of Israel all the statutes which Yahweh has spoken to them by Moses.” [^11] Moses spoke to Aaron, and to Eleazar and to Ithamar, his sons who were left, “Take the meal offering that remains of the offerings of Yahweh made by fire, and eat it without yeast beside the altar; for it is most holy; [^12] and you shall eat it in a holy place, because it is your portion, and your sons’ portion, of the offerings of Yahweh made by fire; for so I am commanded. [^13] The waved breast and the heaved thigh you shall eat in a clean place, you, and your sons, and your daughters with you: for they are given as your portion, and your sons’ portion, out of the sacrifices of the peace offerings of the children of Israel. [^14] They shall bring the heaved thigh and the waved breast with the offerings made by fire of the fat, to wave it for a wave offering before Yahweh. It shall be yours, and your sons’ with you, as a portion forever, as Yahweh has commanded.” [^15] Moses diligently inquired about the goat of the sin offering, and, behold,#10:16 “Behold”, from “הִנֵּה”, means look at, take notice, observe, see, or gaze at. It is often used as an interjection. it was burned. He was angry with Eleazar and with Ithamar, the sons of Aaron who were left, saying, [^16] “Why haven’t you eaten the sin offering in the place of the sanctuary, since it is most holy, and he has given it to you to bear the iniquity of the congregation, to make atonement for them before Yahweh? [^17] Behold, its blood was not brought into the inner part of the sanctuary. You certainly should have eaten it in the sanctuary, as I commanded.” [^18] Aaron spoke to Moses, “Behold, today they have offered their sin offering and their burnt offering before Yahweh; and such things as these have happened to me. If I had eaten the sin offering today, would it have been pleasing in Yahweh’s sight?” [^19] When Moses heard that, it was pleasing in his sight. [^20] 

[[Leviticus - 9|<--]] Leviticus - 10 [[Leviticus - 11|-->]]

---
# Notes
