---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 21 - World English Bible"
---
[[Leviticus - 20|<--]] Leviticus - 21 [[Leviticus - 22|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Leviticus]]

# Leviticus - 21

Yahweh said to Moses, “Speak to the priests, the sons of Aaron, and say to them, ‘A priest shall not defile himself for the dead among his people, [^1] except for his relatives that are near to him: for his mother, for his father, for his son, for his daughter, for his brother, [^2] and for his virgin sister who is near to him, who has had no husband; for her he may defile himself. [^3] He shall not defile himself, being a chief man among his people, to profane himself. [^4] “‘They shall not shave their heads or shave off the corners of their beards or make any cuttings in their flesh. [^5] They shall be holy to their God, and not profane the name of their God, for they offer the offerings of Yahweh made by fire, the bread of their God. Therefore they shall be holy. [^6] “‘They shall not marry a woman who is a prostitute, or profane. A priest shall not marry a woman divorced from her husband; for he is holy to his God. [^7] Therefore you shall sanctify him, for he offers the bread of your God. He shall be holy to you, for I Yahweh, who sanctify you, am holy. [^8] “‘The daughter of any priest, if she profanes herself by playing the prostitute, she profanes her father. She shall be burned with fire. [^9] “‘He who is the high priest among his brothers, upon whose head the anointing oil is poured, and who is consecrated to put on the garments, shall not let the hair of his head hang loose, or tear his clothes. [^10] He must not go in to any dead body, or defile himself for his father or for his mother. [^11] He shall not go out of the sanctuary, nor profane the sanctuary of his God; for the crown of the anointing oil of his God is upon him. I am Yahweh. [^12] “‘He shall take a wife in her virginity. [^13] He shall not marry a widow, or one divorced, or a woman who has been defiled, or a prostitute. He shall take a virgin of his own people as a wife. [^14] He shall not profane his offspring among his people, for I am Yahweh who sanctifies him.’” [^15] Yahweh spoke to Moses, saying, [^16] “Say to Aaron, ‘None of your offspring throughout their generations who has a defect may approach to offer the bread of his God. [^17] For whatever man he is that has a defect, he shall not draw near: a blind man, or a lame, or he who has a flat nose, or any deformity, [^18] or a man who has an injured foot, or an injured hand, [^19] or hunchbacked, or a dwarf, or one who has a defect in his eye, or an itching disease, or scabs, or who has damaged testicles. [^20] No man of the offspring of Aaron the priest who has a defect shall come near to offer the offerings of Yahweh made by fire. Since he has a defect, he shall not come near to offer the bread of his God. [^21] He shall eat the bread of his God, both of the most holy, and of the holy. [^22] He shall not come near to the veil, nor come near to the altar, because he has a defect; that he may not profane my sanctuaries, for I am Yahweh who sanctifies them.’” [^23] So Moses spoke to Aaron, and to his sons, and to all the children of Israel. [^24] 

[[Leviticus - 20|<--]] Leviticus - 21 [[Leviticus - 22|-->]]

---
# Notes
