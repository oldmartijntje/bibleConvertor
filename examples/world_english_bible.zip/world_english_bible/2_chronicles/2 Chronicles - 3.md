---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 3 - World English Bible"
---
[[2 Chronicles - 2|<--]] 2 Chronicles - 3 [[2 Chronicles - 4|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[2 Chronicles]]

# 2 Chronicles - 3

Then Solomon began to build Yahweh’s house at Jerusalem on Mount Moriah, where Yahweh appeared to David his father, which he prepared in the place that David had appointed, on the threshing floor of Ornan the Jebusite. [^1] He began to build in the second day of the second month, in the fourth year of his reign. [^2] Now these are the foundations which Solomon laid for the building of God’s house: the length by cubits#3:3 A cubit is the length from the tip of the middle finger to the elbow on a man’s arm, or about 18 inches or 46 centimeters. after the first measure was sixty cubits, and the width twenty cubits. [^3] The porch that was in front, its length, across the width of the house, was twenty cubits, and the height one hundred twenty; and he overlaid it within with pure gold. [^4] He made the larger room with a ceiling of cypress wood, which he overlaid with fine gold, and ornamented it with palm trees and chains. [^5] He decorated the house with precious stones for beauty. The gold was gold from Parvaim. [^6] He also overlaid the house, the beams, the thresholds, its walls, and its doors with gold, and engraved cherubim on the walls. [^7] He made the most holy place. Its length, according to the width of the house, was twenty cubits, and its width twenty cubits; and he overlaid it with fine gold, amounting to six hundred talents.#3:8 A talent is about 30 kilograms or 66 pounds or 965 Troy ounces, so 600 talents is about 18 metric tons [^8] The weight of the nails was fifty shekels#3:9 A shekel is about 10 grams or about 0.32 Troy ounces, so 50 shekels was about 0.5 kilograms or about 16 Troy ounces. of gold. He overlaid the upper rooms with gold. [^9] In the most holy place he made two cherubim by carving, and they overlaid them with gold. [^10] The wings of the cherubim were twenty cubits long: the wing of the one was five cubits, reaching to the wall of the house; and the other wing was five cubits, reaching to the wing of the other cherub. [^11] The wing of the other cherub was five cubits, reaching to the wall of the house; and the other wing was five cubits, joining to the wing of the other cherub. [^12] The wings of these cherubim spread themselves out twenty cubits. They stood on their feet, and their faces were toward the house. [^13] He made the veil of blue, purple, crimson, and fine linen, and ornamented it with cherubim. [^14] Also he made before the house two pillars thirty-five cubits high, and the capital that was on the top of each of them was five cubits. [^15] He made chains in the inner sanctuary, and put them on the tops of the pillars; and he made one hundred pomegranates, and put them on the chains. [^16] He set up the pillars before the temple, one on the right hand and the other on the left; and called the name of that on the right hand Jachin, and the name of that on the left Boaz. [^17] 

[[2 Chronicles - 2|<--]] 2 Chronicles - 3 [[2 Chronicles - 4|-->]]

---
# Notes
