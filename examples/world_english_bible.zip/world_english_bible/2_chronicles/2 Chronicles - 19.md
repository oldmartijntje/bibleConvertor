---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 19 - World English Bible"
---
[[2 Chronicles - 18|<--]] 2 Chronicles - 19 [[2 Chronicles - 20|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[2 Chronicles]]

# 2 Chronicles - 19

Jehoshaphat the king of Judah returned to his house in peace to Jerusalem. [^1] Jehu the son of Hanani the seer went out to meet him, and said to King Jehoshaphat, “Should you help the wicked, and love those who hate Yahweh? Because of this, wrath is on you from before Yahweh. [^2] Nevertheless there are good things found in you, in that you have put away the Asheroth out of the land, and have set your heart to seek God.” [^3] Jehoshaphat lived at Jerusalem; and he went out again among the people from Beersheba to the hill country of Ephraim, and brought them back to Yahweh, the God of their fathers. [^4] He set judges in the land throughout all the fortified cities of Judah, city by city, [^5] and said to the judges, “Consider what you do, for you don’t judge for man, but for Yahweh; and he is with you in the judgment. [^6] Now therefore let the fear of Yahweh be on you. Take heed and do it; for there is no iniquity with Yahweh our God, nor respect of persons, nor taking of bribes.” [^7] Moreover in Jerusalem Jehoshaphat appointed certain Levites, priests, and heads of the fathers’ households of Israel to give judgment for Yahweh and for controversies. They returned to Jerusalem. [^8] He commanded them, saying, “You shall do this in the fear of Yahweh, faithfully, and with a perfect heart. [^9] Whenever any controversy comes to you from your brothers who dwell in their cities, between blood and blood, between law and commandment, statutes and ordinances, you must warn them, that they not be guilty toward Yahweh, and so wrath come on you and on your brothers. Do this, and you will not be guilty. [^10] Behold, Amariah the chief priest is over you in all matters of Yahweh; and Zebadiah the son of Ishmael, the ruler of the house of Judah, in all the king’s matters. Also the Levites shall be officers before you. Deal courageously, and may Yahweh be with the good.” [^11] 

[[2 Chronicles - 18|<--]] 2 Chronicles - 19 [[2 Chronicles - 20|-->]]

---
# Notes
