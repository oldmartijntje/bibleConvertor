---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 17 - World English Bible"
---
[[2 Chronicles - 16|<--]] 2 Chronicles - 17 [[2 Chronicles - 18|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[2 Chronicles]]

# 2 Chronicles - 17

Jehoshaphat his son reigned in his place, and strengthened himself against Israel. [^1] He placed forces in all the fortified cities of Judah, and set garrisons in the land of Judah and in the cities of Ephraim, which Asa his father had taken. [^2] Yahweh was with Jehoshaphat, because he walked in the first ways of his father David, and didn’t seek the Baals, [^3] but sought the God of his father, and walked in his commandments, and not in the ways of Israel. [^4] Therefore Yahweh established the kingdom in his hand. All Judah brought tribute to Jehoshaphat, and he had riches and honor in abundance. [^5] His heart was lifted up in the ways of Yahweh. Furthermore, he took away the high places and the Asherah poles out of Judah. [^6] Also in the third year of his reign he sent his princes, even Ben Hail, Obadiah, Zechariah, Nethanel, and Micaiah, to teach in the cities of Judah; [^7] and with them Levites, even Shemaiah, Nethaniah, Zebadiah, Asahel, Shemiramoth, Jehonathan, Adonijah, Tobijah, and Tobadonijah, the Levites; and with them Elishama and Jehoram, the priests. [^8] They taught in Judah, having the book of Yahweh’s law with them. They went about throughout all the cities of Judah and taught among the people. [^9] The fear of Yahweh fell on all the kingdoms of the lands that were around Judah, so that they made no war against Jehoshaphat. [^10] Some of the Philistines brought Jehoshaphat presents and silver for tribute. The Arabians also brought him flocks: seven thousand seven hundred rams and seven thousand seven hundred male goats. [^11] Jehoshaphat grew great exceedingly; and he built fortresses and store cities in Judah. [^12] He had many works in the cities of Judah; and men of war, mighty men of valor, in Jerusalem. [^13] This was the numbering of them according to their fathers’ houses: From Judah, the captains of thousands: Adnah the captain, and with him three hundred thousand mighty men of valor; [^14] and next to him Jehohanan the captain, and with him two hundred eighty thousand; [^15] and next to him Amasiah the son of Zichri, who willingly offered himself to Yahweh, and with him two hundred thousand mighty men of valor. [^16] From Benjamin: Eliada, a mighty man of valor, and with him two hundred thousand armed with bow and shield; [^17] and next to him Jehozabad, and with him one hundred eighty thousand ready and prepared for war. [^18] These were those who waited on the king, in addition to those whom the king put in the fortified cities throughout all Judah. [^19] 

[[2 Chronicles - 16|<--]] 2 Chronicles - 17 [[2 Chronicles - 18|-->]]

---
# Notes
