---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 5 - World English Bible"
---
[[2 Chronicles - 4|<--]] 2 Chronicles - 5 [[2 Chronicles - 6|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[2 Chronicles]]

# 2 Chronicles - 5

Thus all the work that Solomon did for Yahweh’s house was finished. Solomon brought in the things that David his father had dedicated, even the silver, the gold, and all the vessels, and put them in the treasuries of God’s house. [^1] Then Solomon assembled the elders of Israel and all the heads of the tribes, the princes of the fathers’ households of the children of Israel, to Jerusalem, to bring up the ark of Yahweh’s covenant out of David’s city, which is Zion. [^2] So all the men of Israel assembled themselves to the king at the feast, which was in the seventh month. [^3] All the elders of Israel came. The Levites took up the ark. [^4] They brought up the ark, the Tent of Meeting, and all the holy vessels that were in the Tent. The Levitical priests brought these up. [^5] King Solomon and all the congregation of Israel who were assembled to him were before the ark, sacrificing sheep and cattle that could not be counted or numbered for multitude. [^6] The priests brought in the ark of Yahweh’s covenant to its place, into the inner sanctuary of the house, to the most holy place, even under the wings of the cherubim. [^7] For the cherubim spread out their wings over the place of the ark, and the cherubim covered the ark and its poles above. [^8] The poles were so long that the ends of the poles were seen from the ark in front of the inner sanctuary, but they were not seen outside; and it is there to this day. [^9] There was nothing in the ark except the two tablets which Moses put there at Horeb, when Yahweh made a covenant with the children of Israel, when they came out of Egypt. [^10] When the priests had come out of the holy place (for all the priests who were present had sanctified themselves, and didn’t keep their divisions; [^11] also the Levites who were the singers, all of them, even Asaph, Heman, Jeduthun, and their sons and their brothers, arrayed in fine linen, with cymbals and stringed instruments and harps, stood at the east end of the altar, and with them one hundred twenty priests sounding with trumpets); [^12] when the trumpeters and singers were as one, to make one sound to be heard in praising and thanking Yahweh; and when they lifted up their voice with the trumpets and cymbals and instruments of music, and praised Yahweh, saying,“For he is good,for his loving kindness endures forever!”then the house was filled with a cloud, even Yahweh’s house, [^13] so that the priests could not stand to minister by reason of the cloud; for Yahweh’s glory filled God’s house. [^14] 

[[2 Chronicles - 4|<--]] 2 Chronicles - 5 [[2 Chronicles - 6|-->]]

---
# Notes
