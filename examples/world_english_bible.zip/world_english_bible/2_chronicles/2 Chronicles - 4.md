---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 4 - World English Bible"
---
[[2 Chronicles - 3|<--]] 2 Chronicles - 4 [[2 Chronicles - 5|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[2 Chronicles]]

# 2 Chronicles - 4

Then he made an altar of bronze, twenty cubits#4:1 A cubit is the length from the tip of the middle finger to the elbow on a man’s arm, or about 18 inches or 46 centimeters. long, twenty cubits wide, and ten cubits high. [^1] Also he made the molten sea#4:2 or, pool, or, reservoir of ten cubits from brim to brim. It was round, five cubits high, and thirty cubits in circumference. [^2] Under it was the likeness of oxen, which encircled it, for ten cubits, encircling the sea. The oxen were in two rows, cast when it was cast. [^3] It stood on twelve oxen, three looking toward the north, three looking toward the west, three looking toward the south, and three looking toward the east; and the sea was set on them above, and all their hindquarters were inward. [^4] It was a handbreadth thick. Its brim was made like the brim of a cup, like the flower of a lily. It received and held three thousand baths.#4:5 A bath is about 5.6 U. S. gallons or 21.1 liters, so 3,000 baths is about 16,800 gallons or 63.3 kiloliters. [^5] He also made ten basins, and put five on the right hand and five on the left, to wash in them. The things that belonged to the burnt offering were washed in them, but the sea was for the priests to wash in. [^6] He made the ten lamp stands of gold according to the ordinance concerning them; and he set them in the temple, five on the right hand and five on the left. [^7] He made also ten tables, and placed them in the temple, five on the right side and five on the left. He made one hundred basins of gold. [^8] Furthermore he made the court of the priests, the great court, and doors for the court, and overlaid their doors with bronze. [^9] He set the sea on the right side of the house eastward, toward the south. [^10] Huram made the pots, the shovels, and the basins.So Huram finished doing the work that he did for King Solomon in God’s house: [^11] the two pillars, the bowls, the two capitals which were on the top of the pillars, the two networks to cover the two bowls of the capitals that were on the top of the pillars, [^12] and the four hundred pomegranates for the two networks—two rows of pomegranates for each network, to cover the two bowls of the capitals that were on the pillars. [^13] He also made the bases, and he made the basins on the bases— [^14] one sea, and the twelve oxen under it. [^15] Huram-abi#4:16 “abi” means “his father” also made the pots, the shovels, the forks, and all its vessels for King Solomon, for Yahweh’s house, of bright bronze. [^16] The king cast them in the plain of the Jordan, in the clay ground between Succoth and Zeredah. [^17] Thus Solomon made all these vessels in great abundance, so that the weight of the bronze could not be determined. [^18] Solomon made all the vessels that were in God’s house: the golden altar, the tables with the show bread on them, [^19] and the lamp stands with their lamps to burn according to the ordinance before the inner sanctuary, of pure gold; [^20] and the flowers, the lamps, and the tongs of gold that was purest gold; [^21] and the snuffers, the basins, the spoons, and the fire pans of pure gold. As for the entry of the house, its inner doors for the most holy place and the doors of the main hall of the temple were of gold. [^22] 

[[2 Chronicles - 3|<--]] 2 Chronicles - 4 [[2 Chronicles - 5|-->]]

---
# Notes
