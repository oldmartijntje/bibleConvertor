---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 1 - World English Bible"
---
2 Chronicles - 1 [[2 Chronicles - 2|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[2 Chronicles]]

# 2 Chronicles - 1

Solomon the son of David was firmly established in his kingdom, and Yahweh#1:1 “Yahweh” is God’s proper Name, sometimes rendered “Lord” (all caps) in other translations. his God#1:1 The Hebrew word rendered “God” is “אֱלֹהִ֑ים” (Elohim). was with him, and made him exceedingly great. [^1] Solomon spoke to all Israel, to the captains of thousands and of hundreds, to the judges, and to every prince in all Israel, the heads of the fathers’ households. [^2] Then Solomon, and all the assembly with him, went to the high place that was at Gibeon; for God’s Tent of Meeting was there, which Yahweh’s servant Moses had made in the wilderness. [^3] But David had brought God’s ark up from Kiriath Jearim to the place that David had prepared for it; for he had pitched a tent for it at Jerusalem. [^4] Moreover the bronze altar that Bezalel the son of Uri, the son of Hur, had made was there before Yahweh’s tabernacle; and Solomon and the assembly were seeking counsel there. [^5] Solomon went up there to the bronze altar before Yahweh, which was at the Tent of Meeting, and offered one thousand burnt offerings on it. [^6] That night, God appeared to Solomon and said to him, “Ask for what you want me to give you.” [^7] Solomon said to God, “You have shown great loving kindness to David my father, and have made me king in his place. [^8] Now, Yahweh God, let your promise to David my father be established; for you have made me king over a people like the dust of the earth in multitude. [^9] Now give me wisdom and knowledge, that I may go out and come in before this people; for who can judge this great people of yours?” [^10] God said to Solomon, “Because this was in your heart, and you have not asked riches, wealth, honor, or the life of those who hate you, nor yet have you asked for long life; but have asked for wisdom and knowledge for yourself, that you may judge my people, over whom I have made you king, [^11] therefore wisdom and knowledge is granted to you. I will give you riches, wealth, and honor, such as none of the kings have had who have been before you, and none after you will have.” [^12] So Solomon came from the high place that was at Gibeon, from before the Tent of Meeting, to Jerusalem; and he reigned over Israel. [^13] Solomon gathered chariots and horsemen. He had one thousand four hundred chariots and twelve thousand horsemen that he placed in the chariot cities, and with the king at Jerusalem. [^14] The king made silver and gold to be as common as stones in Jerusalem, and he made cedars to be as common as the sycamore trees that are in the lowland. [^15] The horses which Solomon had were brought out of Egypt and from Kue. The king’s merchants purchased them from Kue. [^16] They imported from Egypt then exported a chariot for six hundred pieces of silver and a horse for one hundred fifty.#1:17 The pieces of silver were probably shekels, so 600 pieces would be about 13.2 pounds or 6 kilograms of silver, and 150 would be about 3.3 pounds or 1.5 kilograms of silver. They also exported them to the Hittite kings and the Syrian#1:17 or, Aramean kings. [^17] 

2 Chronicles - 1 [[2 Chronicles - 2|-->]]

---
# Notes
