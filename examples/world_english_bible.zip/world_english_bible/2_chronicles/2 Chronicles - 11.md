---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 11 - World English Bible"
---
[[2 Chronicles - 10|<--]] 2 Chronicles - 11 [[2 Chronicles - 12|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[2 Chronicles]]

# 2 Chronicles - 11

When Rehoboam had come to Jerusalem, he assembled the house of Judah and Benjamin, one hundred eighty thousand chosen men who were warriors, to fight against Israel, to bring the kingdom again to Rehoboam. [^1] But Yahweh’s word came to Shemaiah the man of God, saying, [^2] “Speak to Rehoboam the son of Solomon, king of Judah, and to all Israel in Judah and Benjamin, saying, [^3] ‘Yahweh says, “You shall not go up, nor fight against your brothers! Every man return to his house; for this thing is of me.”’” So they listened to Yahweh’s words, and returned from going against Jeroboam. [^4] Rehoboam lived in Jerusalem, and built cities for defense in Judah. [^5] He built Bethlehem, Etam, Tekoa, [^6] Beth Zur, Soco, Adullam, [^7] Gath, Mareshah, Ziph, [^8] Adoraim, Lachish, Azekah, [^9] Zorah, Aijalon, and Hebron, which are fortified cities in Judah and in Benjamin. [^10] He fortified the strongholds and put captains in them with stores of food, oil and wine. [^11] He put shields and spears in every city, and made them exceedingly strong. Judah and Benjamin belonged to him. [^12] The priests and the Levites who were in all Israel stood with him out of all their territory. [^13] For the Levites left their pasture lands and their possessions, and came to Judah and Jerusalem; for Jeroboam and his sons cast them off, that they should not execute the priest’s office to Yahweh. [^14] He himself appointed priests for the high places, for the male goat and calf idols which he had made. [^15] After them, out of all the tribes of Israel, those who set their hearts to seek Yahweh, the God of Israel, came to Jerusalem to sacrifice to Yahweh, the God of their fathers. [^16] So they strengthened the kingdom of Judah and made Rehoboam the son of Solomon strong for three years, for they walked three years in the way of David and Solomon. [^17] Rehoboam took a wife for himself, Mahalath the daughter of Jerimoth the son of David and of Abihail the daughter of Eliab the son of Jesse. [^18] She bore him sons: Jeush, Shemariah, and Zaham. [^19] After her, he took Maacah the granddaughter of Absalom; and she bore him Abijah, Attai, Ziza, and Shelomith. [^20] Rehoboam loved Maacah the granddaughter of Absalom above all his wives and his concubines; for he took eighteen wives and sixty concubines, and became the father of twenty-eight sons and sixty daughters. [^21] Rehoboam appointed Abijah the son of Maacah to be chief, the prince among his brothers, for he intended to make him king. [^22] He dealt wisely, and dispersed some of his sons throughout all the lands of Judah and Benjamin, to every fortified city. He gave them food in abundance; and he sought many wives for them. [^23] 

[[2 Chronicles - 10|<--]] 2 Chronicles - 11 [[2 Chronicles - 12|-->]]

---
# Notes
