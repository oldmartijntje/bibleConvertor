---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 27 - World English Bible"
---
[[2 Chronicles - 26|<--]] 2 Chronicles - 27 [[2 Chronicles - 28|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[2 Chronicles]]

# 2 Chronicles - 27

Jotham was twenty-five years old when he began to reign, and he reigned sixteen years in Jerusalem. His mother’s name was Jerushah the daughter of Zadok. [^1] He did that which was right in Yahweh’s eyes, according to all that his father Uzziah had done. However he didn’t enter into Yahweh’s temple. The people still acted corruptly. [^2] He built the upper gate of Yahweh’s house, and he built much on the wall of Ophel. [^3] Moreover he built cities in the hill country of Judah, and in the forests he built fortresses and towers. [^4] He also fought with the king of the children of Ammon, and prevailed against them. The children of Ammon gave him the same year one hundred talents#27:5 A talent is about 30 kilograms or 66 pounds of silver, ten thousand cors#27:5 1 cor is the same as a homer, or about 55.9 U. S. gallons (liquid) or 211 liters or 6 bushels. 10,000 cors of wheat would weigh about 1,640 metric tons. of wheat, and ten thousand cors of barley.#27:5 10,000 cors of barley would weigh about 1,310 metric tons. The children of Ammon also gave that much to him in the second year, and in the third. [^5] So Jotham became mighty, because he ordered his ways before Yahweh his God. [^6] Now the rest of the acts of Jotham, and all his wars and his ways, behold, they are written in the book of the kings of Israel and Judah. [^7] He was twenty-five years old when he began to reign, and reigned sixteen years in Jerusalem. [^8] Jotham slept with his fathers, and they buried him in David’s city; and Ahaz his son reigned in his place. [^9] 

[[2 Chronicles - 26|<--]] 2 Chronicles - 27 [[2 Chronicles - 28|-->]]

---
# Notes
