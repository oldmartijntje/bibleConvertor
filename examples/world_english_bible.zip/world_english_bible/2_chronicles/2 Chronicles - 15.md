---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 15 - World English Bible"
---
[[2 Chronicles - 14|<--]] 2 Chronicles - 15 [[2 Chronicles - 16|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[2 Chronicles]]

# 2 Chronicles - 15

The Spirit of God came on Azariah the son of Oded. [^1] He went out to meet Asa, and said to him, “Hear me, Asa, and all Judah and Benjamin! Yahweh is with you while you are with him; and if you seek him, he will be found by you; but if you forsake him, he will forsake you. [^2] Now for a long time Israel was without the true God, without a teaching priest, and without law. [^3] But when in their distress they turned to Yahweh, the God of Israel, and sought him, he was found by them. [^4] In those times there was no peace to him who went out, nor to him who came in; but great troubles were on all the inhabitants of the lands. [^5] They were broken in pieces, nation against nation, and city against city; for God troubled them with all adversity. [^6] But you be strong! Don’t let your hands be slack, for your work will be rewarded.” [^7] When Asa heard these words and the prophecy of Oded the prophet, he took courage, and put away the abominations out of all the land of Judah and Benjamin, and out of the cities which he had taken from the hill country of Ephraim; and he renewed Yahweh’s altar that was before Yahweh’s porch. [^8] He gathered all Judah and Benjamin, and those who lived with them out of Ephraim, Manasseh, and Simeon; for they came to him out of Israel in abundance when they saw that Yahweh his God was with him. [^9] So they gathered themselves together at Jerusalem in the third month, in the fifteenth year of Asa’s reign. [^10] They sacrificed to Yahweh in that day, of the plunder which they had brought, seven hundred head of cattle and seven thousand sheep. [^11] They entered into the covenant to seek Yahweh, the God of their fathers, with all their heart and with all their soul; [^12] and that whoever would not seek Yahweh, the God of Israel, should be put to death, whether small or great, whether man or woman. [^13] They swore to Yahweh with a loud voice, with shouting, with trumpets, and with cornets. [^14] All Judah rejoiced at the oath, for they had sworn with all their heart and sought him with their whole desire; and he was found by them. Then Yahweh gave them rest all around. [^15] Also Maacah, the mother of Asa the king, he removed from being queen mother, because she had made an abominable image for an Asherah; so Asa cut down her image, ground it into dust, and burned it at the brook Kidron. [^16] But the high places were not taken away out of Israel; nevertheless the heart of Asa was perfect all his days. [^17] He brought the things that his father had dedicated and that he himself had dedicated, silver, gold, and vessels into God’s house. [^18] There was no more war to the thirty-fifth year of Asa’s reign. [^19] 

[[2 Chronicles - 14|<--]] 2 Chronicles - 15 [[2 Chronicles - 16|-->]]

---
# Notes
