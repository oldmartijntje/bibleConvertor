---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 7 - World English Bible"
---
[[2 Chronicles - 6|<--]] 2 Chronicles - 7 [[2 Chronicles - 8|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[2 Chronicles]]

# 2 Chronicles - 7

Now when Solomon had finished praying, fire came down from heaven and consumed the burnt offering and the sacrifices; and Yahweh’s glory filled the house. [^1] The priests could not enter into Yahweh’s house, because Yahweh’s glory filled Yahweh’s house. [^2] All the children of Israel looked on, when the fire came down, and Yahweh’s glory was on the house. They bowed themselves with their faces to the ground on the pavement, worshiped, and gave thanks to Yahweh, saying,“For he is good,for his loving kindness endures forever!” [^3] Then the king and all the people offered sacrifices before Yahweh. [^4] King Solomon offered a sacrifice of twenty-two thousand head of cattle and a hundred twenty thousand sheep. So the king and all the people dedicated God’s house. [^5] The priests stood, according to their positions; the Levites also with instruments of music of Yahweh, which David the king had made to give thanks to Yahweh, when David praised by their ministry, saying “For his loving kindness endures forever.” The priests sounded trumpets before them; and all Israel stood. [^6] Moreover Solomon made the middle of the court that was before Yahweh’s house holy; for there he offered the burnt offerings and the fat of the peace offerings, because the bronze altar which Solomon had made was not able to receive the burnt offering, the meal offering, and the fat. [^7] So Solomon held the feast at that time for seven days, and all Israel with him, a very great assembly, from the entrance of Hamath to the brook of Egypt. [^8] On the eighth day, they held a solemn assembly; for they kept the dedication of the altar seven days, and the feast seven days. [^9] On the twenty-third day of the seventh month, he sent the people away to their tents, joyful and glad of heart for the goodness that Yahweh had shown to David, to Solomon, and to Israel his people. [^10] Thus Solomon finished Yahweh’s house and the king’s house; and he successfully completed all that came into Solomon’s heart to make in Yahweh’s house and in his own house. [^11] Then Yahweh appeared to Solomon by night, and said to him, “I have heard your prayer, and have chosen this place for myself for a house of sacrifice. [^12] “If I shut up the sky so that there is no rain, or if I command the locust to devour the land, or if I send pestilence among my people, [^13] if my people who are called by my name will humble themselves, pray, seek my face, and turn from their wicked ways, then I will hear from heaven, will forgive their sin, and will heal their land. [^14] Now my eyes will be open and my ears attentive to prayer that is made in this place. [^15] For now I have chosen and made this house holy, that my name may be there forever; and my eyes and my heart will be there perpetually. [^16] “As for you, if you will walk before me as David your father walked, and do according to all that I have commanded you, and will keep my statutes and my ordinances, [^17] then I will establish the throne of your kingdom, according as I covenanted with David your father, saying, ‘There shall not fail you a man to be ruler in Israel.’ [^18] But if you turn away and forsake my statutes and my commandments which I have set before you, and go and serve other gods and worship them, [^19] then I will pluck them up by the roots out of my land which I have given them; and this house, which I have made holy for my name, I will cast out of my sight, and I will make it a proverb and a byword among all peoples. [^20] This house, which is so high, everyone who passes by it will be astonished and say, ‘Why has Yahweh done this to this land and to this house?’ [^21] They shall answer, ‘Because they abandoned Yahweh, the God of their fathers, who brought them out of the land of Egypt, and took other gods, worshiped them, and served them. Therefore he has brought all this evil on them.’” [^22] 

[[2 Chronicles - 6|<--]] 2 Chronicles - 7 [[2 Chronicles - 8|-->]]

---
# Notes
