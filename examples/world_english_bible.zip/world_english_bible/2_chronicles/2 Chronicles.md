---
translation: World English Bible
aliases:
  - "2 Chronicles - World English Bible"
tags:
  - "#bible/type/book"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
---
[[1 Chronicles|<--]] 2 Chronicles [[Ezra|-->]]

# 2 Chronicles - World English Bible

The 2 Chronicles book has 36 chapters. It is part of the old testament.

## Chapters

- 2 Chronicles [[2 Chronicles - 1|chapter 1]]
- 2 Chronicles [[2 Chronicles - 2|chapter 2]]
- 2 Chronicles [[2 Chronicles - 3|chapter 3]]
- 2 Chronicles [[2 Chronicles - 4|chapter 4]]
- 2 Chronicles [[2 Chronicles - 5|chapter 5]]
- 2 Chronicles [[2 Chronicles - 6|chapter 6]]
- 2 Chronicles [[2 Chronicles - 7|chapter 7]]
- 2 Chronicles [[2 Chronicles - 8|chapter 8]]
- 2 Chronicles [[2 Chronicles - 9|chapter 9]]
- 2 Chronicles [[2 Chronicles - 10|chapter 10]]
- 2 Chronicles [[2 Chronicles - 11|chapter 11]]
- 2 Chronicles [[2 Chronicles - 12|chapter 12]]
- 2 Chronicles [[2 Chronicles - 13|chapter 13]]
- 2 Chronicles [[2 Chronicles - 14|chapter 14]]
- 2 Chronicles [[2 Chronicles - 15|chapter 15]]
- 2 Chronicles [[2 Chronicles - 16|chapter 16]]
- 2 Chronicles [[2 Chronicles - 17|chapter 17]]
- 2 Chronicles [[2 Chronicles - 18|chapter 18]]
- 2 Chronicles [[2 Chronicles - 19|chapter 19]]
- 2 Chronicles [[2 Chronicles - 20|chapter 20]]
- 2 Chronicles [[2 Chronicles - 21|chapter 21]]
- 2 Chronicles [[2 Chronicles - 22|chapter 22]]
- 2 Chronicles [[2 Chronicles - 23|chapter 23]]
- 2 Chronicles [[2 Chronicles - 24|chapter 24]]
- 2 Chronicles [[2 Chronicles - 25|chapter 25]]
- 2 Chronicles [[2 Chronicles - 26|chapter 26]]
- 2 Chronicles [[2 Chronicles - 27|chapter 27]]
- 2 Chronicles [[2 Chronicles - 28|chapter 28]]
- 2 Chronicles [[2 Chronicles - 29|chapter 29]]
- 2 Chronicles [[2 Chronicles - 30|chapter 30]]
- 2 Chronicles [[2 Chronicles - 31|chapter 31]]
- 2 Chronicles [[2 Chronicles - 32|chapter 32]]
- 2 Chronicles [[2 Chronicles - 33|chapter 33]]
- 2 Chronicles [[2 Chronicles - 34|chapter 34]]
- 2 Chronicles [[2 Chronicles - 35|chapter 35]]
- 2 Chronicles [[2 Chronicles - 36|chapter 36]]

[[1 Chronicles|<--]] 2 Chronicles [[Ezra|-->]]

---
# Notes
