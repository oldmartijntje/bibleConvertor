---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 14 - World English Bible"
---
[[2 Chronicles - 13|<--]] 2 Chronicles - 14 [[2 Chronicles - 15|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[2 Chronicles]]

# 2 Chronicles - 14

So Abijah slept with his fathers, and they buried him in David’s city; and Asa his son reigned in his place. In his days, the land was quiet ten years. [^1] Asa did that which was good and right in Yahweh his God’s eyes, [^2] for he took away the foreign altars and the high places, broke down the pillars, cut down the Asherah poles, [^3] and commanded Judah to seek Yahweh, the God of their fathers, and to obey his law and command. [^4] Also he took away out of all the cities of Judah the high places and the sun images; and the kingdom was quiet before him. [^5] He built fortified cities in Judah; for the land was quiet, and he had no war in those years, because Yahweh had given him rest. [^6] For he said to Judah, “Let’s build these cities and make walls around them, with towers, gates, and bars. The land is yet before us, because we have sought Yahweh our God. We have sought him, and he has given us rest on every side.” So they built and prospered. [^7] Asa had an army of three hundred thousand out of Judah who bore bucklers and spears, and two hundred eighty thousand out of Benjamin who bore shields and drew bows. All these were mighty men of valor. [^8] Zerah the Ethiopian came out against them with an army of a million troops and three hundred chariots, and he came to Mareshah. [^9] Then Asa went out to meet him, and they set the battle in array in the valley of Zephathah at Mareshah. [^10] Asa cried to Yahweh his God, and said, “Yahweh, there is no one besides you to help, between the mighty and him who has no strength. Help us, Yahweh our God; for we rely on you, and in your name are we come against this multitude. Yahweh, you are our God. Don’t let man prevail against you.” [^11] So Yahweh struck the Ethiopians before Asa and before Judah; and the Ethiopians fled. [^12] Asa and the people who were with him pursued them to Gerar. So many of the Ethiopians fell that they could not recover themselves, for they were destroyed before Yahweh and before his army. Judah’s army carried away very much booty. [^13] They struck all the cities around Gerar, for the fear of Yahweh came on them. They plundered all the cities, for there was much plunder in them. [^14] They also struck the tents of those who had livestock, and carried away sheep and camels in abundance, then returned to Jerusalem. [^15] 

[[2 Chronicles - 13|<--]] 2 Chronicles - 14 [[2 Chronicles - 15|-->]]

---
# Notes
