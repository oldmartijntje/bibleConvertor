---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 26 - World English Bible"
---
[[2 Chronicles - 25|<--]] 2 Chronicles - 26 [[2 Chronicles - 27|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[2 Chronicles]]

# 2 Chronicles - 26

All the people of Judah took Uzziah, who was sixteen years old, and made him king in the place of his father Amaziah. [^1] He built Eloth and restored it to Judah. After that the king slept with his fathers. [^2] Uzziah was sixteen years old when he began to reign; and he reigned fifty-two years in Jerusalem. His mother’s name was Jechiliah, of Jerusalem. [^3] He did that which was right in Yahweh’s eyes, according to all that his father Amaziah had done. [^4] He set himself to seek God in the days of Zechariah, who had understanding in the vision of God; and as long as he sought Yahweh, God made him prosper. [^5] He went out and fought against the Philistines, and broke down the wall of Gath, the wall of Jabneh, and the wall of Ashdod; and he built cities in the country of Ashdod, and among the Philistines. [^6] God helped him against the Philistines, and against the Arabians who lived in Gur Baal, and the Meunim. [^7] The Ammonites gave tribute to Uzziah. His name spread abroad even to the entrance of Egypt, for he grew exceedingly strong. [^8] Moreover Uzziah built towers in Jerusalem at the corner gate, at the valley gate, and at the turning of the wall, and fortified them. [^9] He built towers in the wilderness, and dug out many cisterns, for he had much livestock, both in the lowlands and in the plains. He had farmers and vineyard keepers in the mountains and in the fruitful fields, for he loved farming. [^10] Moreover Uzziah had an army of fighting men who went out to war by bands, according to the number of their reckoning made by Jeiel the scribe and Maaseiah the officer, under the hand of Hananiah, one of the king’s captains. [^11] The whole number of the heads of fathers’ households, even the mighty men of valor, was two thousand six hundred. [^12] Under their hand was an army, three hundred seven thousand five hundred, who made war with mighty power, to help the king against the enemy. [^13] Uzziah prepared for them, even for all the army, shields, spears, helmets, coats of mail, bows, and stones for slinging. [^14] In Jerusalem, he made devices, invented by skillful men, to be on the towers and on the battlements, with which to shoot arrows and great stones. His name spread far abroad, because he was marvelously helped until he was strong. [^15] But when he was strong, his heart was lifted up, so that he did corruptly and he trespassed against Yahweh his God, for he went into Yahweh’s temple to burn incense on the altar of incense. [^16] Azariah the priest went in after him, and with him eighty priests of Yahweh, who were valiant men. [^17] They resisted Uzziah the king, and said to him, “It isn’t for you, Uzziah, to burn incense to Yahweh, but for the priests the sons of Aaron, who are consecrated to burn incense. Go out of the sanctuary, for you have trespassed. It will not be for your honor from Yahweh God.” [^18] Then Uzziah was angry. He had a censer in his hand to burn incense, and while he was angry with the priests, the leprosy broke out on his forehead before the priests in Yahweh’s house, beside the altar of incense. [^19] Azariah the chief priest and all the priests looked at him, and behold, he was leprous in his forehead; and they thrust him out quickly from there. Indeed, he himself also hurried to go out, because Yahweh had struck him. [^20] Uzziah the king was a leper to the day of his death, and lived in a separate house, being a leper; for he was cut off from Yahweh’s house. Jotham his son was over the king’s house, judging the people of the land. [^21] Now the rest of the acts of Uzziah, first and last, Isaiah the prophet, the son of Amoz, wrote. [^22] So Uzziah slept with his fathers; and they buried him with his fathers in the field of burial which belonged to the kings, for they said, “He is a leper.” Jotham his son reigned in his place. [^23] 

[[2 Chronicles - 25|<--]] 2 Chronicles - 26 [[2 Chronicles - 27|-->]]

---
# Notes
