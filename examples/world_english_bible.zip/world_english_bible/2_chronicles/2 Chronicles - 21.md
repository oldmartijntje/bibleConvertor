---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 21 - World English Bible"
---
[[2 Chronicles - 20|<--]] 2 Chronicles - 21 [[2 Chronicles - 22|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[2 Chronicles]]

# 2 Chronicles - 21

Jehoshaphat slept with his fathers, and was buried with his fathers in David’s city; and Jehoram his son reigned in his place. [^1] He had brothers, the sons of Jehoshaphat: Azariah, Jehiel, Zechariah, Azariah, Michael, and Shephatiah. All these were the sons of Jehoshaphat king of Israel. [^2] Their father gave them great gifts of silver, of gold, and of precious things, with fortified cities in Judah; but he gave the kingdom to Jehoram, because he was the firstborn. [^3] Now when Jehoram had risen up over the kingdom of his father, and had strengthened himself, he killed all his brothers with the sword, and also some of the princes of Israel. [^4] Jehoram was thirty-two years old when he began to reign, and he reigned eight years in Jerusalem. [^5] He walked in the way of the kings of Israel, as did Ahab’s house, for he had Ahab’s daughter as his wife. He did that which was evil in Yahweh’s sight. [^6] However Yahweh would not destroy David’s house, because of the covenant that he had made with David, and as he promised to give a lamp to him and to his children always. [^7] In his days Edom revolted from under the hand of Judah, and made a king over themselves. [^8] Then Jehoram went there with his captains and all his chariots with him. He rose up by night and struck the Edomites who surrounded him, along with the captains of the chariots. [^9] So Edom has been in revolt from under the hand of Judah to this day. Then Libnah revolted at the same time from under his hand, because he had forsaken Yahweh, the God of his fathers. [^10] Moreover he made high places in the mountains of Judah, and made the inhabitants of Jerusalem play the prostitute, and led Judah astray. [^11] A letter came to him from Elijah the prophet, saying, “Yahweh, the God of David your father, says, ‘Because you have not walked in the ways of Jehoshaphat your father, nor in the ways of Asa king of Judah, [^12] but have walked in the way of the kings of Israel, and have made Judah and the inhabitants of Jerusalem to play the prostitute like Ahab’s house did, and also have slain your brothers of your father’s house, who were better than yourself, [^13] behold, Yahweh will strike your people with a great plague, including your children, your wives, and all your possessions; [^14] and you will have great sickness with a disease of your bowels, until your bowels fall out by reason of the sickness, day by day.’” [^15] Yahweh stirred up against Jehoram the spirit of the Philistines and of the Arabians who are beside the Ethiopians; [^16] and they came up against Judah, broke into it, and carried away all the possessions that were found in the king’s house, including his sons and his wives, so that there was no son left to him except Jehoahaz, the youngest of his sons. [^17] After all this Yahweh struck him in his bowels with an incurable disease. [^18] In process of time, at the end of two years, his bowels fell out by reason of his sickness, and he died of severe diseases. His people made no burning for him, like the burning of his fathers. [^19] He was thirty-two years old when he began to reign, and he reigned in Jerusalem eight years. He departed with no one’s regret. They buried him in David’s city, but not in the tombs of the kings. [^20] 

[[2 Chronicles - 20|<--]] 2 Chronicles - 21 [[2 Chronicles - 22|-->]]

---
# Notes
