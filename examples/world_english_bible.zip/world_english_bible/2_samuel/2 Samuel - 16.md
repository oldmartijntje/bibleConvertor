---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 16 - World English Bible"
---
[[2 Samuel - 15|<--]] 2 Samuel - 16 [[2 Samuel - 17|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[2 Samuel]]

# 2 Samuel - 16

When David was a little past the top, behold, Ziba the servant of Mephibosheth met him with a couple of donkeys saddled, and on them two hundred loaves of bread, and one hundred clusters of raisins, and one hundred summer fruits, and a container of wine. [^1] The king said to Ziba, “What do you mean by these?”Ziba said, “The donkeys are for the king’s household to ride on; and the bread and summer fruit for the young men to eat; and the wine, that those who are faint in the wilderness may drink.” [^2] The king said, “Where is your master’s son?”Ziba said to the king, “Behold, he is staying in Jerusalem; for he said, ‘Today the house of Israel will restore me the kingdom of my father.’” [^3] Then the king said to Ziba, “Behold, all that belongs to Mephibosheth is yours.”Ziba said, “I bow down. Let me find favor in your sight, my lord, O king.” [^4] When King David came to Bahurim, behold, a man of the family of Saul’s house came out, whose name was Shimei, the son of Gera. He came out and cursed as he came. [^5] He cast stones at David and at all the servants of King David, and all the people and all the mighty men were on his right hand and on his left. [^6] Shimei said when he cursed, “Be gone, be gone, you man of blood, and wicked fellow! [^7] Yahweh has returned on you all the blood of Saul’s house, in whose place you have reigned! Yahweh has delivered the kingdom into the hand of Absalom your son! Behold, you are caught by your own mischief, because you are a man of blood!” [^8] Then Abishai the son of Zeruiah said to the king, “Why should this dead dog curse my lord the king? Please let me go over and take off his head.” [^9] The king said, “What have I to do with you, you sons of Zeruiah? Because he curses, and because Yahweh has said to him, ‘Curse David,’ who then shall say, ‘Why have you done so?’” [^10] David said to Abishai and to all his servants, “Behold, my son, who came out of my bowels, seeks my life. How much more this Benjamite, now? Leave him alone, and let him curse; for Yahweh has invited him. [^11] It may be that Yahweh will look on the wrong done to me, and that Yahweh will repay me good for the cursing of me today.” [^12] So David and his men went by the way; and Shimei went along on the hillside opposite him and cursed as he went, threw stones at him, and threw dust. [^13] The king and all the people who were with him arrived weary; and he refreshed himself there. [^14] Absalom and all the people, the men of Israel, came to Jerusalem, and Ahithophel with him. [^15] When Hushai the Archite, David’s friend, had come to Absalom, Hushai said to Absalom, “Long live the king! Long live the king!” [^16] Absalom said to Hushai, “Is this your kindness to your friend? Why didn’t you go with your friend?” [^17] Hushai said to Absalom, “No; but whomever Yahweh and this people and all the men of Israel have chosen, I will be his, and I will stay with him. [^18] Again, whom should I serve? Shouldn’t I serve in the presence of his son? As I have served in your father’s presence, so I will be in your presence.” [^19] Then Absalom said to Ahithophel, “Give your counsel what we shall do.” [^20] Ahithophel said to Absalom, “Go in to your father’s concubines that he has left to keep the house. Then all Israel will hear that you are abhorred by your father. Then the hands of all who are with you will be strong.” [^21] So they spread a tent for Absalom on the top of the house, and Absalom went in to his father’s concubines in the sight of all Israel. [^22] The counsel of Ahithophel, which he gave in those days, was as if a man inquired at the inner sanctuary of God. All the counsel of Ahithophel was like this both with David and with Absalom. [^23] 

[[2 Samuel - 15|<--]] 2 Samuel - 16 [[2 Samuel - 17|-->]]

---
# Notes
