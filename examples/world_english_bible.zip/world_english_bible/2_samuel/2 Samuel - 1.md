---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 1 - World English Bible"
---
2 Samuel - 1 [[2 Samuel - 2|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[2 Samuel]]

# 2 Samuel - 1

After the death of Saul, when David had returned from the slaughter of the Amalekites, and David had stayed two days in Ziklag, [^1] on the third day, behold,#1:2 “Behold”, from “הִנֵּה”, means look at, take notice, observe, see, or gaze at. It is often used as an interjection. a man came out of the camp from Saul, with his clothes torn and earth on his head. When he came to David, he fell to the earth and showed respect. [^2] David said to him, “Where do you come from?”He said to him, “I have escaped out of the camp of Israel.” [^3] David said to him, “How did it go? Please tell me.”He answered, “The people have fled from the battle, and many of the people also have fallen and are dead. Saul and Jonathan his son are dead also.” [^4] David said to the young man who told him, “How do you know that Saul and Jonathan his son are dead?” [^5] The young man who told him said, “As I happened by chance on Mount Gilboa, behold, Saul was leaning on his spear; and behold, the chariots and the horsemen followed close behind him. [^6] When he looked behind him, he saw me and called to me. I answered, ‘Here I am.’ [^7] He said to me, ‘Who are you?’ I answered him, ‘I am an Amalekite.’ [^8] He said to me, ‘Please stand beside me, and kill me, for anguish has taken hold of me because my life lingers in me.’ [^9] So I stood beside him and killed him, because I was sure that he could not live after he had fallen. I took the crown that was on his head and the bracelet that was on his arm, and have brought them here to my lord.” [^10] Then David took hold on his clothes and tore them; and all the men who were with him did likewise. [^11] They mourned, wept, and fasted until evening for Saul and for Jonathan his son, and for the people of Yahweh,#1:12 “Yahweh” is God’s proper Name, sometimes rendered “Lord” (all caps) in other translations. and for the house of Israel, because they had fallen by the sword. [^12] David said to the young man who told him, “Where are you from?”He answered, “I am the son of a foreigner, an Amalekite.” [^13] David said to him, “Why were you not afraid to stretch out your hand to destroy Yahweh’s anointed?” [^14] David called one of the young men and said, “Go near, and cut him down!” He struck him so that he died. [^15] David said to him, “Your blood be on your head, for your mouth has testified against you, saying, ‘I have slain Yahweh’s anointed.’” [^16] David lamented with this lamentation over Saul and over Jonathan his son [^17] (and he commanded them to teach the children of Judah the song of the bow; behold, it is written in the book of Jashar): [^18] “Your glory, Israel, was slain on your high places!How the mighty have fallen! [^19] Don’t tell it in Gath.Don’t publish it in the streets of Ashkelon,lest the daughters of the Philistines rejoice,lest the daughters of the uncircumcised triumph. [^20] You mountains of Gilboa,let there be no dew or rain on you, and no fields of offerings;for there the shield of the mighty was defiled and cast away,the shield of Saul was not anointed with oil. [^21] From the blood of the slain,from the fat of the mighty,Jonathan’s bow didn’t turn back.Saul’s sword didn’t return empty. [^22] Saul and Jonathan were lovely and pleasant in their lives.In their death, they were not divided.They were swifter than eagles.They were stronger than lions. [^23] You daughters of Israel, weep over Saul,who clothed you delicately in scarlet,who put ornaments of gold on your clothing. [^24] How the mighty have fallen in the middle of the battle!Jonathan was slain on your high places. [^25] I am distressed for you, my brother Jonathan.You have been very pleasant to me.Your love to me was wonderful,surpassing the love of women. [^26] How the mighty have fallen,and the weapons of war have perished!” [^27] 

2 Samuel - 1 [[2 Samuel - 2|-->]]

---
# Notes
