---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 8 - World English Bible"
---
[[2 Samuel - 7|<--]] 2 Samuel - 8 [[2 Samuel - 9|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[2 Samuel]]

# 2 Samuel - 8

After this, David struck the Philistines and subdued them; and David took the bridle of the mother city out of the hand of the Philistines. [^1] He defeated Moab, and measured them with the line, making them to lie down on the ground; and he measured two lines to put to death, and one full line to keep alive. The Moabites became servants to David, and brought tribute. [^2] David also struck Hadadezer the son of Rehob, king of Zobah, as he went to recover his dominion at the River. [^3] David took from him one thousand seven hundred horsemen and twenty thousand footmen. David hamstrung the chariot horses, but reserved enough of them for one hundred chariots. [^4] When the Syrians of Damascus came to help Hadadezer king of Zobah, David struck twenty two thousand men of the Syrians. [^5] Then David put garrisons in Syria of Damascus; and the Syrians became servants to David, and brought tribute. Yahweh gave victory to David wherever he went. [^6] David took the shields of gold that were on the servants of Hadadezer, and brought them to Jerusalem. [^7] From Betah and from Berothai, cities of Hadadezer, King David took a great quantity of bronze. [^8] When Toi king of Hamath heard that David had struck all the army of Hadadezer, [^9] then Toi sent Joram his son to King David to greet him and to bless him, because he had fought against Hadadezer and struck him; for Hadadezer had wars with Toi. Joram brought with him vessels of silver, vessels of gold, and vessels of bronze. [^10] King David also dedicated these to Yahweh, with the silver and gold that he dedicated of all the nations which he subdued— [^11] of Syria, of Moab, of the children of Ammon, of the Philistines, of Amalek, and of the plunder of Hadadezer, son of Rehob, king of Zobah. [^12] David earned a reputation when he returned from striking down eighteen thousand men of the Syrians in the Valley of Salt. [^13] He put garrisons in Edom. Throughout all Edom, he put garrisons, and all the Edomites became servants to David. Yahweh gave victory to David wherever he went. [^14] David reigned over all Israel; and David executed justice and righteousness for all his people. [^15] Joab the son of Zeruiah was over the army, Jehoshaphat the son of Ahilud was recorder, [^16] Zadok the son of Ahitub and Ahimelech the son of Abiathar were priests, Seraiah was scribe, [^17] Benaiah the son of Jehoiada was over the Cherethites and the Pelethites; and David’s sons were chief ministers. [^18] 

[[2 Samuel - 7|<--]] 2 Samuel - 8 [[2 Samuel - 9|-->]]

---
# Notes
