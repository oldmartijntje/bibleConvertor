---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 9 - World English Bible"
---
[[2 Samuel - 8|<--]] 2 Samuel - 9 [[2 Samuel - 10|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[2 Samuel]]

# 2 Samuel - 9

David said, “Is there yet any who is left of Saul’s house, that I may show him kindness for Jonathan’s sake?” [^1] There was of Saul’s house a servant whose name was Ziba, and they called him to David; and the king said to him, “Are you Ziba?”He said, “I am your servant.” [^2] The king said, “Is there not yet any of Saul’s house, that I may show the kindness of God to him?”Ziba said to the king, “Jonathan still has a son, who is lame in his feet.” [^3] The king said to him, “Where is he?”Ziba said to the king, “Behold, he is in the house of Machir the son of Ammiel, in Lo Debar.” [^4] Then King David sent and brought him out of the house of Machir the son of Ammiel, from Lo Debar. [^5] Mephibosheth, the son of Jonathan, the son of Saul, came to David, fell on his face, and showed respect. David said, “Mephibosheth?”He answered, “Behold, your servant!” [^6] David said to him, “Don’t be afraid, for I will surely show you kindness for Jonathan your father’s sake, and will restore to you all the land of Saul your father. You will eat bread at my table continually.” [^7] He bowed down, and said, “What is your servant, that you should look at such a dead dog as I am?” [^8] Then the king called to Ziba, Saul’s servant, and said to him, “All that belonged to Saul and to all his house I have given to your master’s son. [^9] Till the land for him—you, your sons, and your servants. Bring in the harvest, that your master’s son may have bread to eat; but Mephibosheth your master’s son will always eat bread at my table.”Now Ziba had fifteen sons and twenty servants. [^10] Then Ziba said to the king, “According to all that my lord the king commands his servant, so your servant will do.” So Mephibosheth ate at the king’s table like one of the king’s sons. [^11] Mephibosheth had a young son, whose name was Mica. All who lived in Ziba’s house were servants to Mephibosheth. [^12] So Mephibosheth lived in Jerusalem, for he ate continually at the king’s table. He was lame in both his feet. [^13] 

[[2 Samuel - 8|<--]] 2 Samuel - 9 [[2 Samuel - 10|-->]]

---
# Notes
