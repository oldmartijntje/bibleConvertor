---
translation: World English Bible
aliases:
  - "2 Samuel - World English Bible"
tags:
  - "#bible/type/book"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
---
[[1 Samuel|<--]] 2 Samuel [[1 Kings|-->]]

# 2 Samuel - World English Bible

The 2 Samuel book has 24 chapters. It is part of the old testament.

## Chapters

- 2 Samuel [[2 Samuel - 1|chapter 1]]
- 2 Samuel [[2 Samuel - 2|chapter 2]]
- 2 Samuel [[2 Samuel - 3|chapter 3]]
- 2 Samuel [[2 Samuel - 4|chapter 4]]
- 2 Samuel [[2 Samuel - 5|chapter 5]]
- 2 Samuel [[2 Samuel - 6|chapter 6]]
- 2 Samuel [[2 Samuel - 7|chapter 7]]
- 2 Samuel [[2 Samuel - 8|chapter 8]]
- 2 Samuel [[2 Samuel - 9|chapter 9]]
- 2 Samuel [[2 Samuel - 10|chapter 10]]
- 2 Samuel [[2 Samuel - 11|chapter 11]]
- 2 Samuel [[2 Samuel - 12|chapter 12]]
- 2 Samuel [[2 Samuel - 13|chapter 13]]
- 2 Samuel [[2 Samuel - 14|chapter 14]]
- 2 Samuel [[2 Samuel - 15|chapter 15]]
- 2 Samuel [[2 Samuel - 16|chapter 16]]
- 2 Samuel [[2 Samuel - 17|chapter 17]]
- 2 Samuel [[2 Samuel - 18|chapter 18]]
- 2 Samuel [[2 Samuel - 19|chapter 19]]
- 2 Samuel [[2 Samuel - 20|chapter 20]]
- 2 Samuel [[2 Samuel - 21|chapter 21]]
- 2 Samuel [[2 Samuel - 22|chapter 22]]
- 2 Samuel [[2 Samuel - 23|chapter 23]]
- 2 Samuel [[2 Samuel - 24|chapter 24]]

[[1 Samuel|<--]] 2 Samuel [[1 Kings|-->]]

---
# Notes
