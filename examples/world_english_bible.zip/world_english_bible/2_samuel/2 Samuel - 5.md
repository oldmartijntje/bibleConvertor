---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 5 - World English Bible"
---
[[2 Samuel - 4|<--]] 2 Samuel - 5 [[2 Samuel - 6|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[2 Samuel]]

# 2 Samuel - 5

Then all the tribes of Israel came to David at Hebron and spoke, saying, “Behold, we are your bone and your flesh. [^1] In times past, when Saul was king over us, it was you who led Israel out and in. Yahweh said to you, ‘You will be shepherd of my people Israel, and you will be prince over Israel.’” [^2] So all the elders of Israel came to the king to Hebron, and King David made a covenant with them in Hebron before Yahweh; and they anointed David king over Israel. [^3] David was thirty years old when he began to reign, and he reigned forty years. [^4] In Hebron he reigned over Judah seven years and six months, and in Jerusalem he reigned thirty-three years over all Israel and Judah. [^5] The king and his men went to Jerusalem against the Jebusites, the inhabitants of the land, who spoke to David, saying, “The blind and the lame will keep you out of here,” thinking, “David can’t come in here.” [^6] Nevertheless David took the stronghold of Zion. This is David’s city. [^7] David said on that day, “Whoever strikes the Jebusites, let him go up to the watercourse and strike those lame and blind, who are hated by David’s soul.” Therefore they say, “The blind and the lame can’t come into the house.” [^8] David lived in the stronghold, and called it David’s city. David built around from Millo and inward. [^9] David grew greater and greater, for Yahweh, the God of Armies, was with him. [^10] Hiram king of Tyre sent messengers to David, with cedar trees, carpenters, and masons; and they built David a house. [^11] David perceived that Yahweh had established him king over Israel, and that he had exalted his kingdom for his people Israel’s sake. [^12] David took more concubines and wives for himself out of Jerusalem, after he had come from Hebron; and more sons and daughters were born to David. [^13] These are the names of those who were born to him in Jerusalem: Shammua, Shobab, Nathan, Solomon, [^14] Ibhar, Elishua, Nepheg, Japhia, [^15] Elishama, Eliada, and Eliphelet. [^16] When the Philistines heard that they had anointed David king over Israel, all the Philistines went up to seek David, but David heard about it and went down to the stronghold. [^17] Now the Philistines had come and spread themselves in the valley of Rephaim. [^18] David inquired of Yahweh, saying, “Shall I go up against the Philistines? Will you deliver them into my hand?”Yahweh said to David, “Go up; for I will certainly deliver the Philistines into your hand.” [^19] David came to Baal Perazim, and David struck them there. Then he said, “Yahweh has broken my enemies before me, like the breach of waters.” Therefore he called the name of that place Baal Perazim.#5:20 “Baal Perazim” means “Lord who breaks out”. [^20] They left their images there, and David and his men took them away. [^21] The Philistines came up yet again and spread themselves in the valley of Rephaim. [^22] When David inquired of Yahweh, he said, “You shall not go up. Circle around behind them, and attack them in front of the mulberry trees. [^23] When you hear the sound of marching in the tops of the mulberry trees, then stir yourself up; for then Yahweh has gone out before you to strike the army of the Philistines.” [^24] David did so, as Yahweh commanded him, and struck the Philistines all the way from Geba to Gezer. [^25] 

[[2 Samuel - 4|<--]] 2 Samuel - 5 [[2 Samuel - 6|-->]]

---
# Notes
