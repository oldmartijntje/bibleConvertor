---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/nehemiah"
  - "#bible/testament/old"
aliases:
  - "Nehemiah - 4 - World English Bible"
---
[[Nehemiah - 3|<--]] Nehemiah - 4 [[Nehemiah - 5|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Nehemiah]]

# Nehemiah - 4

But when Sanballat heard that we were building the wall, he was angry, and was very indignant, and mocked the Jews. [^1] He spoke before his brothers and the army of Samaria, and said, “What are these feeble Jews doing? Will they fortify themselves? Will they sacrifice? Will they finish in a day? Will they revive the stones out of the heaps of rubbish, since they are burned?” [^2] Now Tobiah the Ammonite was by him, and he said, “What they are building, if a fox climbed up it, he would break down their stone wall.” [^3] “Hear, our God, for we are despised. Turn back their reproach on their own head. Give them up for a plunder in a land of captivity. [^4] Don’t cover their iniquity. Don’t let their sin be blotted out from before you; for they have insulted the builders.” [^5] So we built the wall; and all the wall was joined together to half its height, for the people had a mind to work. [^6] But when Sanballat, Tobiah, the Arabians, the Ammonites, and the Ashdodites heard that the repairing of the walls of Jerusalem went forward, and that the breaches began to be filled, they were very angry; [^7] and they all conspired together to come and fight against Jerusalem, and to cause confusion among us. [^8] But we made our prayer to our God, and set a watch against them day and night because of them. [^9] Judah said, “The strength of the bearers of burdens is fading and there is much rubble, so that we are not able to build the wall.” [^10] Our adversaries said, “They will not know or see, until we come in among them and kill them, and cause the work to cease.” [^11] When the Jews who lived by them came, they said to us ten times from all places, “Wherever you turn, they will attack us.” [^12] Therefore I set guards in the lowest parts of the space behind the wall, in the open places. I set the people by family groups with their swords, their spears, and their bows. [^13] I looked, and rose up, and said to the nobles, to the rulers, and to the rest of the people, “Don’t be afraid of them! Remember the Lord, who is great and awesome, and fight for your brothers, your sons, your daughters, your wives, and your houses.” [^14] When our enemies heard that it was known to us, and God had brought their counsel to nothing, all of us returned to the wall, everyone to his work. [^15] From that time forth, half of my servants did the work, and half of them held the spears, the shields, the bows, and the coats of mail; and the rulers were behind all the house of Judah. [^16] Those who built the wall, and those who bore burdens loaded themselves; everyone with one of his hands did the work, and with the other held his weapon. [^17] Among the builders, everyone wore his sword at his side, and so built. He who sounded the trumpet was by me. [^18] I said to the nobles, and to the rulers and to the rest of the people, “The work is great and widely spread out, and we are separated on the wall, far from one another. [^19] Wherever you hear the sound of the trumpet, rally there to us. Our God will fight for us.” [^20] So we did the work. Half of the people held the spears from the rising of the morning until the stars appeared. [^21] Likewise at the same time I said to the people, “Let everyone with his servant lodge within Jerusalem, that in the night they may be a guard to us, and may labor in the day.” [^22] So neither I, nor my brothers, nor my servants, nor the men of the guard who followed me took off our clothes. Everyone took his weapon to the water. [^23] 

[[Nehemiah - 3|<--]] Nehemiah - 4 [[Nehemiah - 5|-->]]

---
# Notes
