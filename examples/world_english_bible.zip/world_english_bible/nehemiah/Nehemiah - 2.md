---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/nehemiah"
  - "#bible/testament/old"
aliases:
  - "Nehemiah - 2 - World English Bible"
---
[[Nehemiah - 1|<--]] Nehemiah - 2 [[Nehemiah - 3|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Nehemiah]]

# Nehemiah - 2

In the month Nisan, in the twentieth year of Artaxerxes the king, when wine was before him, I picked up the wine, and gave it to the king. Now I had not been sad before in his presence. [^1] The king said to me, “Why is your face sad, since you are not sick? This is nothing else but sorrow of heart.”Then I was very much afraid. [^2] I said to the king, “Let the king live forever! Why shouldn’t my face be sad, when the city, the place of my fathers’ tombs, lies waste, and its gates have been consumed with fire?” [^3] Then the king said to me, “What is your request?”So I prayed to the God of heaven. [^4] I said to the king, “If it pleases the king, and if your servant has found favor in your sight, I ask that you would send me to Judah, to the city of my fathers’ tombs, that I may build it.” [^5] The king said to me (the queen was also sitting by him), “How long will your journey be? When will you return?”So it pleased the king to send me, and I set a time for him. [^6] Moreover I said to the king, “If it pleases the king, let letters be given me to the governors beyond the River, that they may let me pass through until I come to Judah; [^7] and a letter to Asaph the keeper of the king’s forest, that he may give me timber to make beams for the gates of the citadel by the temple, for the wall of the city, and for the house that I will occupy.”The king granted my requests, because of the good hand of my God on me. [^8] Then I came to the governors beyond the River, and gave them the king’s letters. Now the king had sent captains of the army and horsemen with me. [^9] When Sanballat the Horonite and Tobiah the Ammonite servant heard of it, it grieved them exceedingly, because a man had come to seek the welfare of the children of Israel. [^10] So I came to Jerusalem, and was there three days. [^11] I arose in the night, I and a few men with me. I didn’t tell anyone what my God put into my heart to do for Jerusalem. There wasn’t any animal with me except the animal that I rode on. [^12] I went out by night by the valley gate toward the jackal’s well, then to the dung gate; and I inspected the walls of Jerusalem, which were broken down, and its gates were consumed with fire. [^13] Then I went on to the spring gate and to the king’s pool, but there was no place for the animal that was under me to pass. [^14] Then I went up in the night by the brook and inspected the wall; and I turned back, and entered by the valley gate, and so returned. [^15] The rulers didn’t know where I went, or what I did. I had not as yet told it to the Jews, nor to the priests, nor to the nobles, nor to the rulers, nor to the rest who did the work. [^16] Then I said to them, “You see the bad situation that we are in, how Jerusalem lies waste, and its gates are burned with fire. Come, let’s build up the wall of Jerusalem, that we won’t be disgraced.” [^17] I told them about the hand of my God which was good on me, and also about the king’s words that he had spoken to me.They said, “Let’s rise up and build.” So they strengthened their hands for the good work. [^18] But when Sanballat the Horonite, Tobiah the Ammonite servant, and Geshem the Arabian, heard it, they ridiculed us and despised us, and said, “What is this thing that you are doing? Will you rebel against the king?” [^19] Then I answered them, and said to them, “The God of heaven will prosper us. Therefore we, his servants, will arise and build; but you have no portion, nor right, nor memorial in Jerusalem.” [^20] 

[[Nehemiah - 1|<--]] Nehemiah - 2 [[Nehemiah - 3|-->]]

---
# Notes
