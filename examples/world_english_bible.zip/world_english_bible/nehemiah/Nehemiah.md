---
translation: World English Bible
aliases:
  - "Nehemiah - World English Bible"
tags:
  - "#bible/type/book"
  - "#bible/book/nehemiah"
  - "#bible/testament/old"
---
[[Ezra|<--]] Nehemiah [[Esther|-->]]

# Nehemiah - World English Bible

The Nehemiah book has 13 chapters. It is part of the old testament.

## Chapters

- Nehemiah [[Nehemiah - 1|chapter 1]]
- Nehemiah [[Nehemiah - 2|chapter 2]]
- Nehemiah [[Nehemiah - 3|chapter 3]]
- Nehemiah [[Nehemiah - 4|chapter 4]]
- Nehemiah [[Nehemiah - 5|chapter 5]]
- Nehemiah [[Nehemiah - 6|chapter 6]]
- Nehemiah [[Nehemiah - 7|chapter 7]]
- Nehemiah [[Nehemiah - 8|chapter 8]]
- Nehemiah [[Nehemiah - 9|chapter 9]]
- Nehemiah [[Nehemiah - 10|chapter 10]]
- Nehemiah [[Nehemiah - 11|chapter 11]]
- Nehemiah [[Nehemiah - 12|chapter 12]]
- Nehemiah [[Nehemiah - 13|chapter 13]]

[[Ezra|<--]] Nehemiah [[Esther|-->]]

---
# Notes
