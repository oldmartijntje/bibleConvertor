---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/nehemiah"
  - "#bible/testament/old"
aliases:
  - "Nehemiah - 8 - World English Bible"
---
[[Nehemiah - 7|<--]] Nehemiah - 8 [[Nehemiah - 9|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Nehemiah]]

# Nehemiah - 8

All the people gathered themselves together as one man into the wide place that was in front of the water gate; and they spoke to Ezra the scribe to bring the book of the law of Moses, which Yahweh had commanded to Israel. [^1] Ezra the priest brought the law before the assembly, both men and women, and all who could hear with understanding, on the first day of the seventh month. [^2] He read from it before the wide place that was in front of the water gate from early morning until midday, in the presence of the men and the women, and of those who could understand. The ears of all the people were attentive to the book of the law. [^3] Ezra the scribe stood on a pulpit of wood, which they had made for the purpose; and beside him stood Mattithiah, Shema, Anaiah, Uriah, Hilkiah, and Maaseiah, on his right hand; and on his left hand, Pedaiah, Mishael, Malchijah, Hashum, Hashbaddanah, Zechariah, and Meshullam. [^4] Ezra opened the book in the sight of all the people (for he was above all the people), and when he opened it, all the people stood up. [^5] Then Ezra blessed Yahweh, the great God.All the people answered, “Amen, Amen,” with the lifting up of their hands. They bowed their heads, and worshiped Yahweh with their faces to the ground. [^6] Also Jeshua, Bani, Sherebiah, Jamin, Akkub, Shabbethai, Hodiah, Maaseiah, Kelita, Azariah, Jozabad, Hanan, Pelaiah, and the Levites, caused the people to understand the law; and the people stayed in their place. [^7] They read in the book, in the law of God, distinctly; and they gave the sense, so that they understood the reading. [^8] Nehemiah, who was the governor, Ezra the priest and scribe, and the Levites who taught the people said to all the people, “Today is holy to Yahweh your God. Don’t mourn, nor weep.” For all the people wept when they heard the words of the law. [^9] Then he said to them, “Go your way. Eat the fat, drink the sweet, and send portions to him for whom nothing is prepared, for today is holy to our Lord. Don’t be grieved, for the joy of Yahweh is your strength.” [^10] So the Levites calmed all the people, saying, “Hold your peace, for the day is holy. Don’t be grieved.” [^11] All the people went their way to eat, to drink, to send portions, and to celebrate, because they had understood the words that were declared to them. [^12] On the second day, the heads of fathers’ households of all the people, the priests, and the Levites were gathered together to Ezra the scribe, to study the words of the law. [^13] They found written in the law how Yahweh had commanded by Moses that the children of Israel should dwell in booths in the feast of the seventh month; [^14] and that they should publish and proclaim in all their cities and in Jerusalem, saying, “Go out to the mountain, and get olive branches, branches of wild olive, myrtle branches, palm branches, and branches of thick trees, to make temporary shelters,#8:15 or, booths as it is written.” [^15] So the people went out and brought them, and made themselves temporary shelters,#8:16 or, booths everyone on the roof of his house, in their courts, in the courts of God’s house, in the wide place of the water gate, and in the wide place of Ephraim’s gate. [^16] All the assembly of those who had come back out of the captivity made temporary shelters#8:17 or, booths and lived in the temporary shelters, for since the days of Joshua the son of Nun to that day the children of Israel had not done so. There was very great gladness. [^17] Also day by day, from the first day to the last day, he read in the book of the law of God. They kept the feast seven days; and on the eighth day was a solemn assembly, according to the ordinance. [^18] 

[[Nehemiah - 7|<--]] Nehemiah - 8 [[Nehemiah - 9|-->]]

---
# Notes
