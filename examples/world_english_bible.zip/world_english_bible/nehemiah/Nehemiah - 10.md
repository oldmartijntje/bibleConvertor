---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/nehemiah"
  - "#bible/testament/old"
aliases:
  - "Nehemiah - 10 - World English Bible"
---
[[Nehemiah - 9|<--]] Nehemiah - 10 [[Nehemiah - 11|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Nehemiah]]

# Nehemiah - 10

Now those who sealed were: Nehemiah the governor, the son of Hacaliah, and Zedekiah, [^1] Seraiah, Azariah, Jeremiah, [^2] Pashhur, Amariah, Malchijah, [^3] Hattush, Shebaniah, Malluch, [^4] Harim, Meremoth, Obadiah, [^5] Daniel, Ginnethon, Baruch, [^6] Meshullam, Abijah, Mijamin, [^7] Maaziah, Bilgai, and Shemaiah. These were the priests. [^8] The Levites: Jeshua the son of Azaniah, Binnui of the sons of Henadad, Kadmiel; [^9] and their brothers, Shebaniah, Hodiah, Kelita, Pelaiah, Hanan, [^10] Mica, Rehob, Hashabiah, [^11] Zaccur, Sherebiah, Shebaniah, [^12] Hodiah, Bani, and Beninu. [^13] The chiefs of the people: Parosh, Pahathmoab, Elam, Zattu, Bani, [^14] Bunni, Azgad, Bebai, [^15] Adonijah, Bigvai, Adin, [^16] Ater, Hezekiah, Azzur, [^17] Hodiah, Hashum, Bezai, [^18] Hariph, Anathoth, Nobai, [^19] Magpiash, Meshullam, Hezir, [^20] Meshezabel, Zadok, Jaddua, [^21] Pelatiah, Hanan, Anaiah, [^22] Hoshea, Hananiah, Hasshub, [^23] Hallohesh, Pilha, Shobek, [^24] Rehum, Hashabnah, Maaseiah, [^25] Ahiah, Hanan, Anan, [^26] Malluch, Harim, and Baanah. [^27] The rest of the people, the priests, the Levites, the gatekeepers, the singers, the temple servants, and all those who had separated themselves from the peoples of the lands to the law of God, their wives, their sons, and their daughters—everyone who had knowledge and understanding— [^28] joined with their brothers, their nobles, and entered into a curse and into an oath, to walk in God’s law, which was given by Moses the servant of God, and to observe and do all the commandments of Yahweh our Lord, and his ordinances and his statutes; [^29] and that we would not give our daughters to the peoples of the land, nor take their daughters for our sons; [^30] and if the peoples of the land bring wares or any grain on the Sabbath day to sell, that we would not buy from them on the Sabbath, or on a holy day; and that we would forego the seventh year crops and the exaction of every debt. [^31] Also we made ordinances for ourselves, to charge ourselves yearly with the third part of a shekel#10:32 A shekel is about 10 grams or about 0.35 ounces. for the service of the house of our God: [^32] for the show bread, for the continual meal offering, for the continual burnt offering, for the Sabbaths, for the new moons, for the set feasts, for the holy things, for the sin offerings to make atonement for Israel, and for all the work of the house of our God. [^33] We, the priests, the Levites, and the people, cast lots for the wood offering, to bring it into the house of our God, according to our fathers’ houses, at times appointed year by year, to burn on Yahweh our God’s altar, as it is written in the law; [^34] and to bring the first fruits of our ground and the first fruits of all fruit of all kinds of trees, year by year, to Yahweh’s house; [^35] also the firstborn of our sons and of our livestock, as it is written in the law, and the firstborn of our herds and of our flocks, to bring to the house of our God, to the priests who minister in the house of our God; [^36] and that we should bring the first fruits of our dough, our wave offerings, the fruit of all kinds of trees, and the new wine and the oil, to the priests, to the rooms of the house of our God; and the tithes of our ground to the Levites; for they, the Levites, take the tithes in all our farming villages. [^37] The priest, the descendent of Aaron, shall be with the Levites when the Levites take tithes. The Levites shall bring up the tithe of the tithes to the house of our God, to the rooms, into the treasure house. [^38] For the children of Israel and the children of Levi shall bring the wave offering of the grain, of the new wine, and of the oil, to the rooms where the vessels of the sanctuary are, and the priests who minister, with the gatekeepers and the singers. We will not forsake the house of our God. [^39] 

[[Nehemiah - 9|<--]] Nehemiah - 10 [[Nehemiah - 11|-->]]

---
# Notes
