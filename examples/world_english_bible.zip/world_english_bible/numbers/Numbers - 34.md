---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 34 - World English Bible"
---
[[Numbers - 33|<--]] Numbers - 34 [[Numbers - 35|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Numbers]]

# Numbers - 34

Yahweh spoke to Moses, saying, [^1] “Command the children of Israel, and tell them, ‘When you come into the land of Canaan (this is the land that shall fall to you for an inheritance, even the land of Canaan according to its borders), [^2] then your south quarter shall be from the wilderness of Zin along by the side of Edom, and your south border shall be from the end of the Salt Sea eastward. [^3] Your border shall turn about southward of the ascent of Akrabbim, and pass along to Zin; and it shall pass southward of Kadesh Barnea; and it shall go from there to Hazar Addar, and pass along to Azmon. [^4] The border shall turn about from Azmon to the brook of Egypt, and it shall end at the sea. [^5] “‘For the western border, you shall have the great sea and its border. This shall be your west border. [^6] “‘This shall be your north border: from the great sea you shall mark out for yourselves Mount Hor. [^7] From Mount Hor you shall mark out to the entrance of Hamath; and the border shall pass by Zedad. [^8] Then the border shall go to Ziphron, and it shall end at Hazar Enan. This shall be your north border. [^9] “‘You shall mark out your east border from Hazar Enan to Shepham. [^10] The border shall go down from Shepham to Riblah, on the east side of Ain. The border shall go down, and shall reach to the side of the sea of Chinnereth eastward. [^11] The border shall go down to the Jordan, and end at the Salt Sea. This shall be your land according to its borders around it.’” [^12] Moses commanded the children of Israel, saying, “This is the land which you shall inherit by lot, which Yahweh has commanded to give to the nine tribes, and to the half-tribe; [^13] for the tribe of the children of Reuben according to their fathers’ houses, the tribe of the children of Gad according to their fathers’ houses, and the half-tribe of Manasseh have received their inheritance. [^14] The two tribes and the half-tribe have received their inheritance beyond the Jordan at Jericho eastward, toward the sunrise.” [^15] Yahweh spoke to Moses, saying, [^16] “These are the names of the men who shall divide the land to you for inheritance: Eleazar the priest, and Joshua the son of Nun. [^17] You shall take one prince of every tribe, to divide the land for inheritance. [^18] These are the names of the men: Of the tribe of Judah, Caleb the son of Jephunneh. [^19] Of the tribe of the children of Simeon, Shemuel the son of Ammihud. [^20] Of the tribe of Benjamin, Elidad the son of Chislon. [^21] Of the tribe of the children of Dan a prince, Bukki the son of Jogli. [^22] Of the children of Joseph: of the tribe of the children of Manasseh a prince, Hanniel the son of Ephod. [^23] Of the tribe of the children of Ephraim a prince, Kemuel the son of Shiphtan. [^24] Of the tribe of the children of Zebulun a prince, Elizaphan the son of Parnach. [^25] Of the tribe of the children of Issachar a prince, Paltiel the son of Azzan. [^26] Of the tribe of the children of Asher a prince, Ahihud the son of Shelomi. [^27] Of the tribe of the children of Naphtali a prince, Pedahel the son of Ammihud.” [^28] These are they whom Yahweh commanded to divide the inheritance to the children of Israel in the land of Canaan. [^29] 

[[Numbers - 33|<--]] Numbers - 34 [[Numbers - 35|-->]]

---
# Notes
