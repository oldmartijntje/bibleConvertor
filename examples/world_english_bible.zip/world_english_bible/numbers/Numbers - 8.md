---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 8 - World English Bible"
---
[[Numbers - 7|<--]] Numbers - 8 [[Numbers - 9|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Numbers]]

# Numbers - 8

Yahweh spoke to Moses, saying, [^1] “Speak to Aaron, and tell him, ‘When you light the lamps, the seven lamps shall give light in front of the lamp stand.’” [^2] Aaron did so. He lit its lamps to light the area in front of the lamp stand, as Yahweh commanded Moses. [^3] This was the workmanship of the lamp stand, beaten work of gold. From its base to its flowers, it was beaten work. He made the lamp stand according to the pattern which Yahweh had shown Moses. [^4] Yahweh spoke to Moses, saying, [^5] “Take the Levites from among the children of Israel, and cleanse them. [^6] You shall do this to them to cleanse them: sprinkle the water of cleansing on them, let them shave their whole bodies with a razor, let them wash their clothes, and cleanse themselves. [^7] Then let them take a young bull and its meal offering, fine flour mixed with oil; and another young bull you shall take for a sin offering. [^8] You shall present the Levites before the Tent of Meeting. You shall assemble the whole congregation of the children of Israel. [^9] You shall present the Levites before Yahweh. The children of Israel shall lay their hands on the Levites, [^10] and Aaron shall offer the Levites before Yahweh for a wave offering on the behalf of the children of Israel, that it may be theirs to do the service of Yahweh. [^11] “The Levites shall lay their hands on the heads of the bulls, and you shall offer the one for a sin offering and the other for a burnt offering to Yahweh, to make atonement for the Levites. [^12] You shall set the Levites before Aaron and before his sons, and offer them as a wave offering to Yahweh. [^13] Thus you shall separate the Levites from among the children of Israel, and the Levites shall be mine. [^14] “After that, the Levites shall go in to do the service of the Tent of Meeting. You shall cleanse them, and offer them as a wave offering. [^15] For they are wholly given to me from among the children of Israel; instead of all who open the womb, even the firstborn of all the children of Israel, I have taken them to me. [^16] For all the firstborn among the children of Israel are mine, both man and animal. On the day that I struck all the firstborn in the land of Egypt, I sanctified them for myself. [^17] I have taken the Levites instead of all the firstborn among the children of Israel. [^18] I have given the Levites as a gift to Aaron and to his sons from among the children of Israel, to do the service of the children of Israel in the Tent of Meeting, and to make atonement for the children of Israel, so that there will be no plague among the children of Israel when the children of Israel come near to the sanctuary.” [^19] Moses, and Aaron, and all the congregation of the children of Israel did so to the Levites. According to all that Yahweh commanded Moses concerning the Levites, so the children of Israel did to them. [^20] The Levites purified themselves from sin, and they washed their clothes; and Aaron offered them for a wave offering before Yahweh and Aaron made atonement for them to cleanse them. [^21] After that, the Levites went in to do their service in the Tent of Meeting before Aaron and before his sons: as Yahweh had commanded Moses concerning the Levites, so they did to them. [^22] Yahweh spoke to Moses, saying, [^23] “This is what is assigned to the Levites: from twenty-five years old and upward they shall go in to wait on the service in the work of the Tent of Meeting; [^24] and from the age of fifty years they shall retire from doing the work, and shall serve no more, [^25] but shall assist their brothers in the Tent of Meeting, to perform the duty, and shall perform no service. This is how you shall have the Levites do their duties.” [^26] 

[[Numbers - 7|<--]] Numbers - 8 [[Numbers - 9|-->]]

---
# Notes
