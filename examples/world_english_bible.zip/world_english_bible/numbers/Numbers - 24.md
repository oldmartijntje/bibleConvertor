---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 24 - World English Bible"
---
[[Numbers - 23|<--]] Numbers - 24 [[Numbers - 25|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Numbers]]

# Numbers - 24

When Balaam saw that it pleased Yahweh to bless Israel, he didn’t go, as at the other times, to use divination, but he set his face toward the wilderness. [^1] Balaam lifted up his eyes, and he saw Israel dwelling according to their tribes; and the Spirit of God came on him. [^2] He took up his parable, and said,“Balaam the son of Beor says,the man whose eyes are open says; [^3] he says, who hears the words of God,who sees the vision of the Almighty,falling down, and having his eyes open: [^4] How goodly are your tents, Jacob,and your dwellings, Israel! [^5] As valleys they are spread out,as gardens by the riverside,as aloes which Yahweh has planted,as cedar trees beside the waters. [^6] Water shall flow from his buckets.His seed shall be in many waters.His king shall be higher than Agag.His kingdom shall be exalted. [^7] God brings him out of Egypt.He has as it were the strength of the wild ox.He shall consume the nations his adversaries,shall break their bones in pieces,and pierce them with his arrows. [^8] He couched, he lay down as a lion,as a lioness;who shall rouse him up?Everyone who blesses you is blessed.Everyone who curses you is cursed.” [^9] Balak’s anger burned against Balaam, and he struck his hands together. Balak said to Balaam, “I called you to curse my enemies, and, behold, you have altogether blessed them these three times. [^10] Therefore, flee to your place, now! I thought to promote you to great honor; but, behold, Yahweh has kept you back from honor.” [^11] Balaam said to Balak, “Didn’t I also tell your messengers whom you sent to me, saying, [^12] ‘If Balak would give me his house full of silver and gold, I can’t go beyond Yahweh’s word, to do either good or bad from my own mind. I will say what Yahweh says’? [^13] Now, behold, I go to my people. Come, I will inform you what this people shall do to your people in the latter days.” [^14] He took up his parable, and said,“Balaam the son of Beor says,the man whose eyes are open says; [^15] he says, who hears the words of God,knows the knowledge of the Most High,and who sees the vision of the Almighty,falling down, and having his eyes open: [^16] I see him, but not now.I see him, but not near.A star will come out of Jacob.A scepter will rise out of Israel,and shall strike through the corners of Moab,and crush all the sons of Sheth. [^17] Edom shall be a possession.Seir, his enemy, also shall be a possession,while Israel does valiantly. [^18] Out of Jacob shall one have dominion,and shall destroy the remnant from the city.” [^19] He looked at Amalek, and took up his parable, and said,“Amalek was the first of the nations,but his latter end shall come to destruction.” [^20] He looked at the Kenite, and took up his parable, and said,“Your dwelling place is strong.Your nest is set in the rock. [^21] Nevertheless Kain shall be wasted,until Asshur carries you away captive.” [^22] He took up his parable, and said,“Alas, who shall live when God does this? [^23] But ships shall come from the coast of Kittim.They shall afflict Asshur, and shall afflict Eber.He also shall come to destruction.” [^24] Balaam rose up, and went and returned to his place; and Balak also went his way. [^25] 

[[Numbers - 23|<--]] Numbers - 24 [[Numbers - 25|-->]]

---
# Notes
