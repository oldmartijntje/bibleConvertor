---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 13 - World English Bible"
---
[[Numbers - 12|<--]] Numbers - 13 [[Numbers - 14|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Numbers]]

# Numbers - 13

Yahweh spoke to Moses, saying, [^1] “Send men, that they may spy out the land of Canaan, which I give to the children of Israel. Of every tribe of their fathers, you shall send a man, every one a prince among them.” [^2] Moses sent them from the wilderness of Paran according to the commandment of Yahweh. All of them were men who were heads of the children of Israel. [^3] These were their names:Of the tribe of Reuben, Shammua the son of Zaccur. [^4] Of the tribe of Simeon, Shaphat the son of Hori. [^5] Of the tribe of Judah, Caleb the son of Jephunneh. [^6] Of the tribe of Issachar, Igal the son of Joseph. [^7] Of the tribe of Ephraim, Hoshea the son of Nun. [^8] Of the tribe of Benjamin, Palti the son of Raphu. [^9] Of the tribe of Zebulun, Gaddiel the son of Sodi. [^10] Of the tribe of Joseph, of the tribe of Manasseh, Gaddi the son of Susi. [^11] Of the tribe of Dan, Ammiel the son of Gemalli. [^12] Of the tribe of Asher, Sethur the son of Michael. [^13] Of the tribe of Naphtali, Nahbi the son of Vophsi. [^14] Of the tribe of Gad, Geuel the son of Machi. [^15] These are the names of the men who Moses sent to spy out the land. Moses called Hoshea the son of Nun Joshua. [^16] Moses sent them to spy out the land of Canaan, and said to them, “Go up this way by the South, and go up into the hill country. [^17] See the land, what it is; and the people who dwell therein, whether they are strong or weak, whether they are few or many; [^18] and what the land is that they dwell in, whether it is good or bad; and what cities they are that they dwell in, whether in camps, or in strongholds; [^19] and what the land is, whether it is fertile or poor, whether there is wood therein, or not. Be courageous, and bring some of the fruit of the land.” Now the time was the time of the first-ripe grapes. [^20] So they went up, and spied out the land from the wilderness of Zin to Rehob, to the entrance of Hamath. [^21] They went up by the South, and came to Hebron; and Ahiman, Sheshai, and Talmai, the children of Anak, were there. (Now Hebron was built seven years before Zoan in Egypt.) [^22] They came to the valley of Eshcol, and cut down from there a branch with one cluster of grapes, and they bore it on a staff between two. They also brought some of the pomegranates and figs. [^23] That place was called the valley of Eshcol, because of the cluster which the children of Israel cut down from there. [^24] They returned from spying out the land at the end of forty days. [^25] They went and came to Moses, to Aaron, and to all the congregation of the children of Israel, to the wilderness of Paran, to Kadesh; and brought back word to them and to all the congregation. They showed them the fruit of the land. [^26] They told him, and said, “We came to the land where you sent us. Surely it flows with milk and honey, and this is its fruit. [^27] However, the people who dwell in the land are strong, and the cities are fortified and very large. Moreover, we saw the children of Anak there. [^28] Amalek dwells in the land of the South. The Hittite, the Jebusite, and the Amorite dwell in the hill country. The Canaanite dwells by the sea, and along the side of the Jordan.” [^29] Caleb stilled the people before Moses, and said, “Let’s go up at once, and possess it; for we are well able to overcome it!” [^30] But the men who went up with him said, “We aren’t able to go up against the people; for they are stronger than we.” [^31] They brought up an evil report of the land which they had spied out to the children of Israel, saying, “The land, through which we have gone to spy it out, is a land that eats up its inhabitants; and all the people who we saw in it are men of great stature. [^32] There we saw the Nephilim,#13:33 or, giants the sons of Anak, who come from the Nephilim.#13:33 or, giants We were in our own sight as grasshoppers, and so we were in their sight.” [^33] 

[[Numbers - 12|<--]] Numbers - 13 [[Numbers - 14|-->]]

---
# Notes
