---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 6 - World English Bible"
---
[[Numbers - 5|<--]] Numbers - 6 [[Numbers - 7|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Numbers]]

# Numbers - 6

Yahweh spoke to Moses, saying, [^1] “Speak to the children of Israel, and tell them: ‘When either man or woman shall make a special vow, the vow of a Nazirite, to separate himself to Yahweh, [^2] he shall separate himself from wine and strong drink. He shall drink no vinegar of wine, or vinegar of fermented drink, neither shall he drink any juice of grapes, nor eat fresh grapes or dried. [^3] All the days of his separation he shall eat nothing that is made of the grapevine, from the seeds even to the skins. [^4] “‘All the days of his vow of separation no razor shall come on his head, until the days are fulfilled in which he separates himself to Yahweh. He shall be holy. He shall let the locks of the hair of his head grow long. [^5] “‘All the days that he separates himself to Yahweh he shall not go near a dead body. [^6] He shall not make himself unclean for his father, or for his mother, for his brother, or for his sister, when they die, because his separation to God#6:7 The Hebrew word rendered “God” is “אֱלֹהִ֑ים” (Elohim). is on his head. [^7] All the days of his separation he is holy to Yahweh. [^8] “‘If any man dies very suddenly beside him, and he defiles the head of his separation, then he shall shave his head in the day of his cleansing. On the seventh day he shall shave it. [^9] On the eighth day he shall bring two turtledoves or two young pigeons to the priest, to the door of the Tent of Meeting. [^10] The priest shall offer one for a sin offering, and the other for a burnt offering, and make atonement for him, because he sinned by reason of the dead, and shall make his head holy that same day. [^11] He shall separate to Yahweh the days of his separation, and shall bring a male lamb a year old for a trespass offering; but the former days shall be void, because his separation was defiled. [^12] “‘This is the law of the Nazirite: when the days of his separation are fulfilled, he shall be brought to the door of the Tent of Meeting, [^13] and he shall offer his offering to Yahweh: one male lamb a year old without defect for a burnt offering, one ewe lamb a year old without defect for a sin offering, one ram without defect for peace offerings, [^14] a basket of unleavened bread, cakes of fine flour mixed with oil, and unleavened wafers anointed with oil with their meal offering and their drink offerings. [^15] The priest shall present them before Yahweh, and shall offer his sin offering and his burnt offering. [^16] He shall offer the ram for a sacrifice of peace offerings to Yahweh, with the basket of unleavened bread. The priest shall offer also its meal offering and its drink offering. [^17] The Nazirite shall shave the head of his separation at the door of the Tent of Meeting, take the hair of the head of his separation, and put it on the fire which is under the sacrifice of peace offerings. [^18] The priest shall take the boiled shoulder of the ram, one unleavened cake out of the basket, and one unleavened wafer, and shall put them on the hands of the Nazirite after he has shaved the head of his separation; [^19] and the priest shall wave them for a wave offering before Yahweh. They are holy for the priest, together with the breast that is waved and the thigh that is offered. After that the Nazirite may drink wine. [^20] “‘This is the law of the Nazirite who vows and of his offering to Yahweh for his separation, in addition to that which he is able to afford. According to his vow which he vows, so he must do after the law of his separation.’” [^21] Yahweh spoke to Moses, saying, [^22] “Speak to Aaron and to his sons, saying, ‘This is how you shall bless the children of Israel.’ You shall tell them, [^23] ‘Yahweh bless you, and keep you. [^24] Yahweh make his face to shine on you,and be gracious to you. [^25] Yahweh lift up his face toward you,and give you peace.’ [^26] “So they shall put my name on the children of Israel; and I will bless them.” [^27] 

[[Numbers - 5|<--]] Numbers - 6 [[Numbers - 7|-->]]

---
# Notes
