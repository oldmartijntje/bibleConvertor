---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 25 - World English Bible"
---
[[Numbers - 24|<--]] Numbers - 25 [[Numbers - 26|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Numbers]]

# Numbers - 25

Israel stayed in Shittim; and the people began to play the prostitute with the daughters of Moab; [^1] for they called the people to the sacrifices of their gods. The people ate and bowed down to their gods. [^2] Israel joined himself to Baal Peor, and Yahweh’s anger burned against Israel. [^3] Yahweh said to Moses, “Take all the chiefs of the people, and hang them up to Yahweh before the sun, that the fierce anger of Yahweh may turn away from Israel.” [^4] Moses said to the judges of Israel, “Everyone kill his men who have joined themselves to Baal Peor.” [^5] Behold, one of the children of Israel came and brought to his brothers a Midianite woman in the sight of Moses, and in the sight of all the congregation of the children of Israel, while they were weeping at the door of the Tent of Meeting. [^6] When Phinehas, the son of Eleazar, the son of Aaron the priest, saw it, he rose up from the middle of the congregation, and took a spear in his hand. [^7] He went after the man of Israel into the pavilion, and thrust both of them through, the man of Israel, and the woman through her body. So the plague was stopped among the children of Israel. [^8] Those who died by the plague were twenty-four thousand. [^9] Yahweh spoke to Moses, saying, [^10] “Phinehas, the son of Eleazar, the son of Aaron the priest, has turned my wrath away from the children of Israel, in that he was jealous with my jealousy among them, so that I didn’t consume the children of Israel in my jealousy. [^11] Therefore say, ‘Behold, I give to him my covenant of peace. [^12] It shall be to him, and to his offspring after him, the covenant of an everlasting priesthood, because he was jealous for his God, and made atonement for the children of Israel.’” [^13] Now the name of the man of Israel that was slain, who was slain with the Midianite woman, was Zimri, the son of Salu, a prince of a fathers’ house among the Simeonites. [^14] The name of the Midianite woman who was slain was Cozbi, the daughter of Zur. He was head of the people of a fathers’ house in Midian. [^15] Yahweh spoke to Moses, saying, [^16] “Harass the Midianites, and strike them; [^17] for they harassed you with their wiles, wherein they have deceived you in the matter of Peor, and in the incident regarding Cozbi, the daughter of the prince of Midian, their sister, who was slain on the day of the plague in the matter of Peor.” [^18] 

[[Numbers - 24|<--]] Numbers - 25 [[Numbers - 26|-->]]

---
# Notes
