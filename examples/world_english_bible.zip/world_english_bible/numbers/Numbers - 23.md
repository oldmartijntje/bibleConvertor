---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 23 - World English Bible"
---
[[Numbers - 22|<--]] Numbers - 23 [[Numbers - 24|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Numbers]]

# Numbers - 23

Balaam said to Balak, “Build here seven altars for me, and prepare here seven bulls and seven rams for me.” [^1] Balak did as Balaam had spoken; and Balak and Balaam offered on every altar a bull and a ram. [^2] Balaam said to Balak, “Stand by your burnt offering, and I will go. Perhaps Yahweh will come to meet me. Whatever he shows me I will tell you.”He went to a bare height. [^3] God met Balaam, and he said to him, “I have prepared the seven altars, and I have offered up a bull and a ram on every altar.” [^4] Yahweh put a word in Balaam’s mouth, and said, “Return to Balak, and thus you shall speak.” [^5] He returned to him, and behold, he was standing by his burnt offering, he, and all the princes of Moab. [^6] He took up his parable, and said,“From Aram has Balak brought me,the king of Moab from the mountains of the East.Come, curse Jacob for me.Come, defy Israel. [^7] How shall I curse whom God has not cursed?How shall I defy whom Yahweh has not defied? [^8] For from the top of the rocks I see him.From the hills I see him.Behold, it is a people that dwells alone,and shall not be listed among the nations. [^9] Who can count the dust of Jacob,or count the fourth part of Israel?Let me die the death of the righteous!Let my last end be like his!” [^10] Balak said to Balaam, “What have you done to me? I took you to curse my enemies, and behold, you have blessed them altogether.” [^11] He answered and said, “Must I not take heed to speak that which Yahweh puts in my mouth?” [^12] Balak said to him, “Please come with me to another place, where you may see them. You shall see just part of them, and shall not see them all. Curse them from there for me.” [^13] He took him into the field of Zophim, to the top of Pisgah, and built seven altars, and offered up a bull and a ram on every altar. [^14] He said to Balak, “Stand here by your burnt offering, while I meet God over there.” [^15] Yahweh met Balaam, and put a word in his mouth, and said, “Return to Balak, and say this.” [^16] He came to him, and behold, he was standing by his burnt offering, and the princes of Moab with him. Balak said to him, “What has Yahweh spoken?” [^17] He took up his parable, and said,“Rise up, Balak, and hear!Listen to me, you son of Zippor. [^18] God is not a man, that he should lie,nor a son of man, that he should repent.Has he said, and he won’t do it?Or has he spoken, and he won’t make it good? [^19] Behold, I have received a command to bless.He has blessed, and I can’t reverse it. [^20] He has not seen iniquity in Jacob.Neither has he seen perverseness in Israel.Yahweh his God is with him.The shout of a king is among them. [^21] God brings them out of Egypt.He has as it were the strength of the wild ox. [^22] Surely there is no enchantment with Jacob;neither is there any divination with Israel.Now it shall be said of Jacob and of Israel,‘What has God done!’ [^23] Behold, a people rises up as a lioness.As a lion he lifts himself up.He shall not lie down until he eats of the prey,and drinks the blood of the slain.” [^24] Balak said to Balaam, “Neither curse them at all, nor bless them at all.” [^25] But Balaam answered Balak, “Didn’t I tell you, saying, ‘All that Yahweh speaks, that I must do’?” [^26] Balak said to Balaam, “Come now, I will take you to another place; perhaps it will please God that you may curse them for me from there.” [^27] Balak took Balaam to the top of Peor, that looks down on the desert. [^28] Balaam said to Balak, “Build seven altars for me here, and prepare seven bulls and seven rams for me here.” [^29] Balak did as Balaam had said, and offered up a bull and a ram on every altar. [^30] 

[[Numbers - 22|<--]] Numbers - 23 [[Numbers - 24|-->]]

---
# Notes
