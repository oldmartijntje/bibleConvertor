---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 17 - World English Bible"
---
[[Numbers - 16|<--]] Numbers - 17 [[Numbers - 18|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Numbers]]

# Numbers - 17

Yahweh spoke to Moses, saying, [^1] “Speak to the children of Israel, and take rods from them, one for each fathers’ house, of all their princes according to their fathers’ houses, twelve rods. Write each man’s name on his rod. [^2] You shall write Aaron’s name on Levi’s rod. There shall be one rod for each head of their fathers’ houses. [^3] You shall lay them up in the Tent of Meeting before the covenant, where I meet with you. [^4] It shall happen that the rod of the man whom I shall choose shall bud. I will make the murmurings of the children of Israel, which they murmur against you, cease from me.” [^5] Moses spoke to the children of Israel; and all their princes gave him rods, for each prince one, according to their fathers’ houses, a total of twelve rods. Aaron’s rod was among their rods. [^6] Moses laid up the rods before Yahweh in the Tent of the Testimony. [^7] On the next day, Moses went into the Tent of the Testimony; and behold, Aaron’s rod for the house of Levi had sprouted, budded, produced blossoms, and bore ripe almonds. [^8] Moses brought out all the rods from before Yahweh to all the children of Israel. They looked, and each man took his rod. [^9] Yahweh said to Moses, “Put back the rod of Aaron before the covenant, to be kept for a token against the children of rebellion; that you may make an end of their complaining against me, that they not die.” [^10] Moses did so. As Yahweh commanded him, so he did. [^11] The children of Israel spoke to Moses, saying, “Behold, we perish! We are undone! We are all undone! [^12] Everyone who keeps approaching Yahweh’s tabernacle, dies! Will we all perish?” [^13] 

[[Numbers - 16|<--]] Numbers - 17 [[Numbers - 18|-->]]

---
# Notes
