---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/psalms"
  - "#bible/testament/old"
aliases:
  - "Psalms - 2 - World English Bible"
---
[[Psalms - 1|<--]] Psalms - 2 [[Psalms - 3|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Psalms]]

# Psalms - 2

Why do the nations rage,and the peoples plot a vain thing? [^1] The kings of the earth take a stand,and the rulers take counsel together,against Yahweh, and against his Anointed,#2:2 The word “Anointed” is the same as the word for “Messiah” or “Christ” saying, [^2] “Let’s break their bonds apart,and cast their cords from us.” [^3] He who sits in the heavens will laugh.The Lord#2:4 The word translated “Lord” is “Adonai.” will have them in derision. [^4] Then he will speak to them in his anger,and terrify them in his wrath: [^5] “Yet I have set my King on my holy hill of Zion.” [^6] I will tell of the decree:Yahweh said to me, “You are my son.Today I have become your father. [^7] Ask of me, and I will give the nations for your inheritance,the uttermost parts of the earth for your possession. [^8] You shall break them with a rod of iron.You shall dash them in pieces like a potter’s vessel.” [^9] Now therefore be wise, you kings.Be instructed, you judges of the earth. [^10] Serve Yahweh with fear,and rejoice with trembling. [^11] Give sincere homage to the Son,#2:12 or, Kiss the son lest he be angry, and you perish on the way,for his wrath will soon be kindled.Blessed are all those who take refuge in him. [^12] 

[[Psalms - 1|<--]] Psalms - 2 [[Psalms - 3|-->]]

---
# Notes
