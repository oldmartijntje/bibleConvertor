---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/psalms"
  - "#bible/testament/old"
aliases:
  - "Psalms - 1 - World English Bible"
---
Psalms - 1 [[Psalms - 2|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Psalms]]

# Psalms - 1

Blessed is the man who doesn’t walk in the counsel of the wicked,nor stand on the path of sinners,nor sit in the seat of scoffers; [^1] but his delight is in Yahweh’s#1:2 “Yahweh” is God’s proper Name, sometimes rendered “Lord” (all caps) in other translations. law.On his law he meditates day and night. [^2] He will be like a tree planted by the streams of water,that produces its fruit in its season,whose leaf also does not wither.Whatever he does shall prosper. [^3] The wicked are not so,but are like the chaff which the wind drives away. [^4] Therefore the wicked shall not stand in the judgment,nor sinners in the congregation of the righteous. [^5] For Yahweh knows the way of the righteous,but the way of the wicked shall perish. [^6] 

Psalms - 1 [[Psalms - 2|-->]]

---
# Notes
