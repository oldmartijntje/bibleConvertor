---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 5 - World English Bible"
---
[[Exodus - 4|<--]] Exodus - 5 [[Exodus - 6|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Exodus]]

# Exodus - 5

Afterward Moses and Aaron came, and said to Pharaoh, “This is what Yahweh, the God of Israel, says, ‘Let my people go, that they may hold a feast to me in the wilderness.’” [^1] Pharaoh said, “Who is Yahweh, that I should listen to his voice to let Israel go? I don’t know Yahweh, and moreover I will not let Israel go.” [^2] They said, “The God of the Hebrews has met with us. Please let us go three days’ journey into the wilderness, and sacrifice to Yahweh, our God, lest he fall on us with pestilence, or with the sword.” [^3] The king of Egypt said to them, “Why do you, Moses and Aaron, take the people from their work? Get back to your burdens!” [^4] Pharaoh said, “Behold, the people of the land are now many, and you make them rest from their burdens.” [^5] The same day Pharaoh commanded the taskmasters of the people and their officers, saying, [^6] “You shall no longer give the people straw to make brick, as before. Let them go and gather straw for themselves. [^7] You shall require from them the number of the bricks which they made before. You shall not diminish anything of it, for they are idle. Therefore they cry, saying, ‘Let’s go and sacrifice to our God.’ [^8] Let heavier work be laid on the men, that they may labor in it. Don’t let them pay any attention to lying words.” [^9] The taskmasters of the people went out with their officers, and they spoke to the people, saying, “This is what Pharaoh says: ‘I will not give you straw. [^10] Go yourselves, get straw where you can find it, for nothing of your work shall be diminished.’” [^11] So the people were scattered abroad throughout all the land of Egypt to gather stubble for straw. [^12] The taskmasters were urgent saying, “Fulfill your work quota daily, as when there was straw!” [^13] The officers of the children of Israel, whom Pharaoh’s taskmasters had set over them, were beaten, and were asked, “Why haven’t you fulfilled your quota both yesterday and today, in making brick as before?” [^14] Then the officers of the children of Israel came and cried to Pharaoh, saying, “Why do you deal this way with your servants? [^15] No straw is given to your servants, and they tell us, ‘Make brick!’ and behold, your servants are beaten; but the fault is in your own people.” [^16] But Pharaoh said, “You are idle! You are idle! Therefore you say, ‘Let’s go and sacrifice to Yahweh.’ [^17] Go therefore now, and work; for no straw shall be given to you; yet you shall deliver the same number of bricks!” [^18] The officers of the children of Israel saw that they were in trouble when it was said, “You shall not diminish anything from your daily quota of bricks!” [^19] They met Moses and Aaron, who stood along the way, as they came out from Pharaoh. [^20] They said to them, “May Yahweh look at you and judge, because you have made us a stench to be abhorred in the eyes of Pharaoh, and in the eyes of his servants, to put a sword in their hand to kill us!” [^21] Moses returned to Yahweh, and said, “Lord, why have you brought trouble on this people? Why is it that you have sent me? [^22] For since I came to Pharaoh to speak in your name, he has brought trouble on this people. You have not rescued your people at all!” [^23] 

[[Exodus - 4|<--]] Exodus - 5 [[Exodus - 6|-->]]

---
# Notes
