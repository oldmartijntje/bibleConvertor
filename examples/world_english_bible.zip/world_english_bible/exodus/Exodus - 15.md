---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 15 - World English Bible"
---
[[Exodus - 14|<--]] Exodus - 15 [[Exodus - 16|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Exodus]]

# Exodus - 15

Then Moses and the children of Israel sang this song to Yahweh, and said,“I will sing to Yahweh, for he has triumphed gloriously.He has thrown the horse and his rider into the sea. [^1] Yah is my strength and song.He has become my salvation.This is my God, and I will praise him;my father’s God, and I will exalt him. [^2] Yahweh is a man of war.Yahweh is his name. [^3] He has cast Pharaoh’s chariots and his army into the sea.His chosen captains are sunk in the Red Sea. [^4] The deeps cover them.They went down into the depths like a stone. [^5] Your right hand, Yahweh, is glorious in power.Your right hand, Yahweh, dashes the enemy in pieces. [^6] In the greatness of your excellency, you overthrow those who rise up against you.You send out your wrath. It consumes them as stubble. [^7] With the blast of your nostrils, the waters were piled up.The floods stood upright as a heap.The deeps were congealed in the heart of the sea. [^8] The enemy said, ‘I will pursue. I will overtake. I will divide the plunder.My desire will be satisfied on them.I will draw my sword. My hand will destroy them.’ [^9] You blew with your wind.The sea covered them.They sank like lead in the mighty waters. [^10] Who is like you, Yahweh, among the gods?Who is like you, glorious in holiness,fearful in praises, doing wonders? [^11] You stretched out your right hand.The earth swallowed them. [^12] “You, in your loving kindness, have led the people that you have redeemed.You have guided them in your strength to your holy habitation. [^13] The peoples have heard.They tremble.Pangs have taken hold of the inhabitants of Philistia. [^14] Then the chiefs of Edom were dismayed.Trembling takes hold of the mighty men of Moab.All the inhabitants of Canaan have melted away. [^15] Terror and dread falls on them.By the greatness of your arm they are as still as a stone,until your people pass over, Yahweh,until the people you have purchased pass over. [^16] You will bring them in, and plant them in the mountain of your inheritance,the place, Yahweh, which you have made for yourself to dwell in:the sanctuary, Lord, which your hands have established. [^17] Yahweh will reign forever and ever.” [^18] For the horses of Pharaoh went in with his chariots and with his horsemen into the sea, and Yahweh brought back the waters of the sea on them; but the children of Israel walked on dry land in the middle of the sea. [^19] Miriam the prophetess, the sister of Aaron, took a tambourine in her hand; and all the women went out after her with tambourines and with dances. [^20] Miriam answered them,“Sing to Yahweh, for he has triumphed gloriously.He has thrown the horse and his rider into the sea.” [^21] Moses led Israel onward from the Red Sea, and they went out into the wilderness of Shur; and they went three days in the wilderness, and found no water. [^22] When they came to Marah, they couldn’t drink from the waters of Marah, for they were bitter. Therefore its name was called Marah.#15:23 Marah means bitter. [^23] The people murmured against Moses, saying, “What shall we drink?” [^24] Then he cried to Yahweh. Yahweh showed him a tree, and he threw it into the waters, and the waters were made sweet. There he made a statute and an ordinance for them, and there he tested them. [^25] He said, “If you will diligently listen to Yahweh your God’s voice, and will do that which is right in his eyes, and will pay attention to his commandments, and keep all his statutes, I will put none of the diseases on you which I have put on the Egyptians; for I am Yahweh who heals you.” [^26] They came to Elim, where there were twelve springs of water and seventy palm trees. They encamped there by the waters. [^27] 

[[Exodus - 14|<--]] Exodus - 15 [[Exodus - 16|-->]]

---
# Notes
