---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 2 - World English Bible"
---
[[Exodus - 1|<--]] Exodus - 2 [[Exodus - 3|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Exodus]]

# Exodus - 2

A man of the house of Levi went and took a daughter of Levi as his wife. [^1] The woman conceived and bore a son. When she saw that he was a fine child, she hid him three months. [^2] When she could no longer hide him, she took a papyrus basket for him, and coated it with tar and with pitch. She put the child in it, and laid it in the reeds by the river’s bank. [^3] His sister stood far off, to see what would be done to him. [^4] Pharaoh’s daughter came down to bathe at the river. Her maidens walked along by the riverside. She saw the basket among the reeds, and sent her servant to get it. [^5] She opened it, and saw the child, and behold, the baby cried. She had compassion on him, and said, “This is one of the Hebrews’ children.” [^6] Then his sister said to Pharaoh’s daughter, “Should I go and call a nurse for you from the Hebrew women, that she may nurse the child for you?” [^7] Pharaoh’s daughter said to her, “Go.”The young woman went and called the child’s mother. [^8] Pharaoh’s daughter said to her, “Take this child away, and nurse him for me, and I will give you your wages.”The woman took the child, and nursed it. [^9] The child grew, and she brought him to Pharaoh’s daughter, and he became her son. She named him Moses,#2:10 “Moses” sounds like the Hebrew for “draw out”. and said, “Because I drew him out of the water.” [^10] In those days, when Moses had grown up, he went out to his brothers and saw their burdens. He saw an Egyptian striking a Hebrew, one of his brothers. [^11] He looked this way and that way, and when he saw that there was no one, he killed the Egyptian, and hid him in the sand. [^12] He went out the second day, and behold, two men of the Hebrews were fighting with each other. He said to him who did the wrong, “Why do you strike your fellow?” [^13] He said, “Who made you a prince and a judge over us? Do you plan to kill me, as you killed the Egyptian?”Moses was afraid, and said, “Surely this thing is known.” [^14] Now when Pharaoh heard this thing, he sought to kill Moses. But Moses fled from the face of Pharaoh, and lived in the land of Midian, and he sat down by a well. [^15] Now the priest of Midian had seven daughters. They came and drew water, and filled the troughs to water their father’s flock. [^16] The shepherds came and drove them away; but Moses stood up and helped them, and watered their flock. [^17] When they came to Reuel, their father, he said, “How is it that you have returned so early today?” [^18] They said, “An Egyptian delivered us out of the hand of the shepherds, and moreover he drew water for us, and watered the flock.” [^19] He said to his daughters, “Where is he? Why is it that you have left the man? Call him, that he may eat bread.” [^20] Moses was content to dwell with the man. He gave Moses Zipporah, his daughter. [^21] She bore a son, and he named him Gershom,#2:22 “Gershom” sounds like the Hebrew for “an alien there”. for he said, “I have lived as a foreigner in a foreign land.” [^22] In the course of those many days, the king of Egypt died, and the children of Israel sighed because of the bondage, and they cried, and their cry came up to God because of the bondage. [^23] God heard their groaning, and God remembered his covenant with Abraham, with Isaac, and with Jacob. [^24] God saw the children of Israel, and God understood. [^25] 

[[Exodus - 1|<--]] Exodus - 2 [[Exodus - 3|-->]]

---
# Notes
