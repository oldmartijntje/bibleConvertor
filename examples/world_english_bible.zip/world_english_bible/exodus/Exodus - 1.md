---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 1 - World English Bible"
---
Exodus - 1 [[Exodus - 2|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Exodus]]

# Exodus - 1

Now these are the names of the sons of Israel, who came into Egypt (every man and his household came with Jacob): [^1] Reuben, Simeon, Levi, and Judah, [^2] Issachar, Zebulun, and Benjamin, [^3] Dan and Naphtali, Gad and Asher. [^4] All the souls who came out of Jacob’s body were seventy souls, and Joseph was in Egypt already. [^5] Joseph died, as did all his brothers, and all that generation. [^6] The children of Israel were fruitful, and increased abundantly, and multiplied, and grew exceedingly mighty; and the land was filled with them. [^7] Now there arose a new king over Egypt, who didn’t know Joseph. [^8] He said to his people, “Behold,#1:9 “Behold”, from “הִנֵּה”, means look at, take notice, observe, see, or gaze at. It is often used as an interjection. the people of the children of Israel are more and mightier than we. [^9] Come, let’s deal wisely with them, lest they multiply, and it happen that when any war breaks out, they also join themselves to our enemies and fight against us, and escape out of the land.” [^10] Therefore they set taskmasters over them to afflict them with their burdens. They built storage cities for Pharaoh: Pithom and Raamses. [^11] But the more they afflicted them, the more they multiplied and the more they spread out. They started to dread the children of Israel. [^12] The Egyptians ruthlessly made the children of Israel serve, [^13] and they made their lives bitter with hard service in mortar and in brick, and in all kinds of service in the field, all their service, in which they ruthlessly made them serve. [^14] The king of Egypt spoke to the Hebrew midwives, of whom the name of the one was Shiphrah, and the name of the other Puah, [^15] and he said, “When you perform the duty of a midwife to the Hebrew women, and see them on the birth stool, if it is a son, then you shall kill him; but if it is a daughter, then she shall live.” [^16] But the midwives feared God,#1:17 The Hebrew word rendered “God” is “אֱלֹהִ֑ים” (Elohim). and didn’t do what the king of Egypt commanded them, but saved the baby boys alive. [^17] The king of Egypt called for the midwives, and said to them, “Why have you done this thing and saved the boys alive?” [^18] The midwives said to Pharaoh, “Because the Hebrew women aren’t like the Egyptian women; for they are vigorous and give birth before the midwife comes to them.” [^19] God dealt well with the midwives, and the people multiplied, and grew very mighty. [^20] Because the midwives feared God, he gave them families. [^21] Pharaoh commanded all his people, saying, “You shall cast every son who is born into the river, and every daughter you shall save alive.” [^22] 

Exodus - 1 [[Exodus - 2|-->]]

---
# Notes
