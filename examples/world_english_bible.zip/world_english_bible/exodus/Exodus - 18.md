---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 18 - World English Bible"
---
[[Exodus - 17|<--]] Exodus - 18 [[Exodus - 19|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Exodus]]

# Exodus - 18

Now Jethro, the priest of Midian, Moses’ father-in-law, heard of all that God had done for Moses and for Israel his people, how Yahweh had brought Israel out of Egypt. [^1] Jethro, Moses’ father-in-law, received Zipporah, Moses’ wife, after he had sent her away, [^2] and her two sons. The name of one son was Gershom,#18:3 “Gershom” sounds like the Hebrew for “an alien there”. for Moses said, “I have lived as a foreigner in a foreign land”. [^3] The name of the other was Eliezer,#18:4 Eliezer means “God is my helper”.  for he said, “My father’s God was my help and delivered me from Pharaoh’s sword.” [^4] Jethro, Moses’ father-in-law, came with Moses’ sons and his wife to Moses into the wilderness where he was encamped, at the Mountain of God. [^5] He said to Moses, “I, your father-in-law Jethro, have come to you with your wife, and her two sons with her.” [^6] Moses went out to meet his father-in-law, and bowed and kissed him. They asked each other of their welfare, and they came into the tent. [^7] Moses told his father-in-law all that Yahweh had done to Pharaoh and to the Egyptians for Israel’s sake, all the hardships that had come on them on the way, and how Yahweh delivered them. [^8] Jethro rejoiced for all the goodness which Yahweh had done to Israel, in that he had delivered them out of the hand of the Egyptians. [^9] Jethro said, “Blessed be Yahweh, who has delivered you out of the hand of the Egyptians, and out of the hand of Pharaoh; who has delivered the people from under the hand of the Egyptians. [^10] Now I know that Yahweh is greater than all gods because of the way that they treated people arrogantly.” [^11] Jethro, Moses’ father-in-law, took a burnt offering and sacrifices for God. Aaron came with all the elders of Israel, to eat bread with Moses’ father-in-law before God. [^12] On the next day, Moses sat to judge the people, and the people stood around Moses from the morning to the evening. [^13] When Moses’ father-in-law saw all that he did to the people, he said, “What is this thing that you do for the people? Why do you sit alone, and all the people stand around you from morning to evening?” [^14] Moses said to his father-in-law, “Because the people come to me to inquire of God. [^15] When they have a matter, they come to me, and I judge between a man and his neighbor, and I make them know the statutes of God, and his laws.” [^16] Moses’ father-in-law said to him, “The thing that you do is not good. [^17] You will surely wear away, both you, and this people that is with you; for the thing is too heavy for you. You are not able to perform it yourself alone. [^18] Listen now to my voice. I will give you counsel, and God be with you. You represent the people before God, and bring the causes to God. [^19] You shall teach them the statutes and the laws, and shall show them the way in which they must walk, and the work that they must do. [^20] Moreover you shall provide out of all the people able men which fear God: men of truth, hating unjust gain; and place such over them, to be rulers of thousands, rulers of hundreds, rulers of fifties, and rulers of tens. [^21] Let them judge the people at all times. It shall be that every great matter they shall bring to you, but every small matter they shall judge themselves. So shall it be easier for you, and they shall share the load with you. [^22] If you will do this thing, and God commands you so, then you will be able to endure, and all these people also will go to their place in peace.” [^23] So Moses listened to the voice of his father-in-law, and did all that he had said. [^24] Moses chose able men out of all Israel, and made them heads over the people, rulers of thousands, rulers of hundreds, rulers of fifties, and rulers of tens. [^25] They judged the people at all times. They brought the hard cases to Moses, but every small matter they judged themselves. [^26] Moses let his father-in-law depart, and he went his way into his own land. [^27] 

[[Exodus - 17|<--]] Exodus - 18 [[Exodus - 19|-->]]

---
# Notes
