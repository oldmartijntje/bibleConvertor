---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 19 - World English Bible"
---
[[Exodus - 18|<--]] Exodus - 19 [[Exodus - 20|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Exodus]]

# Exodus - 19

In the third month after the children of Israel had gone out of the land of Egypt, on that same day they came into the wilderness of Sinai. [^1] When they had departed from Rephidim, and had come to the wilderness of Sinai, they encamped in the wilderness; and there Israel encamped before the mountain. [^2] Moses went up to God, and Yahweh called to him out of the mountain, saying, “This is what you shall tell the house of Jacob, and tell the children of Israel: [^3] ‘You have seen what I did to the Egyptians, and how I bore you on eagles’ wings, and brought you to myself. [^4] Now therefore, if you will indeed obey my voice and keep my covenant, then you shall be my own possession from among all peoples; for all the earth is mine; [^5] and you shall be to me a kingdom of priests and a holy nation.’ These are the words which you shall speak to the children of Israel.” [^6] Moses came and called for the elders of the people, and set before them all these words which Yahweh commanded him. [^7] All the people answered together, and said, “All that Yahweh has spoken we will do.”Moses reported the words of the people to Yahweh. [^8] Yahweh said to Moses, “Behold, I come to you in a thick cloud, that the people may hear when I speak with you, and may also believe you forever.” Moses told the words of the people to Yahweh. [^9] Yahweh said to Moses, “Go to the people, and sanctify them today and tomorrow, and let them wash their garments, [^10] and be ready for the third day; for on the third day Yahweh will come down in the sight of all the people on Mount Sinai. [^11] You shall set bounds to the people all around, saying, ‘Be careful that you don’t go up onto the mountain, or touch its border. Whoever touches the mountain shall be surely put to death. [^12] No hand shall touch him, but he shall surely be stoned or shot through; whether it is animal or man, he shall not live.’ When the trumpet sounds long, they shall come up to the mountain.” [^13] Moses went down from the mountain to the people, and sanctified the people; and they washed their clothes. [^14] He said to the people, “Be ready by the third day. Don’t have sexual relations with a woman.” [^15] On the third day, when it was morning, there were thunders and lightnings, and a thick cloud on the mountain, and the sound of an exceedingly loud trumpet; and all the people who were in the camp trembled. [^16] Moses led the people out of the camp to meet God; and they stood at the lower part of the mountain. [^17] All of Mount Sinai smoked, because Yahweh descended on it in fire; and its smoke ascended like the smoke of a furnace, and the whole mountain quaked greatly. [^18] When the sound of the trumpet grew louder and louder, Moses spoke, and God answered him by a voice. [^19] Yahweh came down on Mount Sinai, to the top of the mountain. Yahweh called Moses to the top of the mountain, and Moses went up. [^20] Yahweh said to Moses, “Go down, warn the people, lest they break through to Yahweh to gaze, and many of them perish. [^21] Let the priests also, who come near to Yahweh, sanctify themselves, lest Yahweh break out on them.” [^22] Moses said to Yahweh, “The people can’t come up to Mount Sinai, for you warned us, saying, ‘Set bounds around the mountain, and sanctify it.’” [^23] Yahweh said to him, “Go down! You shall bring Aaron up with you, but don’t let the priests and the people break through to come up to Yahweh, lest he break out against them.” [^24] So Moses went down to the people, and told them. [^25] 

[[Exodus - 18|<--]] Exodus - 19 [[Exodus - 20|-->]]

---
# Notes
