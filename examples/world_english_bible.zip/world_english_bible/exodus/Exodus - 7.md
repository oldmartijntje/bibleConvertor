---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 7 - World English Bible"
---
[[Exodus - 6|<--]] Exodus - 7 [[Exodus - 8|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Exodus]]

# Exodus - 7

Yahweh said to Moses, “Behold, I have made you as God to Pharaoh; and Aaron your brother shall be your prophet. [^1] You shall speak all that I command you; and Aaron your brother shall speak to Pharaoh, that he let the children of Israel go out of his land. [^2] I will harden Pharaoh’s heart, and multiply my signs and my wonders in the land of Egypt. [^3] But Pharaoh will not listen to you, so I will lay my hand on Egypt, and bring out my armies, my people the children of Israel, out of the land of Egypt by great judgments. [^4] The Egyptians shall know that I am Yahweh when I stretch out my hand on Egypt, and bring the children of Israel out from among them.” [^5] Moses and Aaron did so. As Yahweh commanded them, so they did. [^6] Moses was eighty years old, and Aaron eighty-three years old, when they spoke to Pharaoh. [^7] Yahweh spoke to Moses and to Aaron, saying, [^8] “When Pharaoh speaks to you, saying, ‘Perform a miracle!’ then you shall tell Aaron, ‘Take your rod, and cast it down before Pharaoh, and it will become a serpent.’” [^9] Moses and Aaron went in to Pharaoh, and they did so, as Yahweh had commanded. Aaron cast down his rod before Pharaoh and before his servants, and it became a serpent. [^10] Then Pharaoh also called for the wise men and the sorcerers. They also, the magicians of Egypt, did the same thing with their enchantments. [^11] For they each cast down their rods, and they became serpents; but Aaron’s rod swallowed up their rods. [^12] Pharaoh’s heart was hardened, and he didn’t listen to them, as Yahweh had spoken. [^13] Yahweh said to Moses, “Pharaoh’s heart is stubborn. He refuses to let the people go. [^14] Go to Pharaoh in the morning. Behold, he is going out to the water. You shall stand by the river’s bank to meet him. You shall take the rod which was turned to a serpent in your hand. [^15] You shall tell him, ‘Yahweh, the God of the Hebrews, has sent me to you, saying, “Let my people go, that they may serve me in the wilderness. Behold, until now you haven’t listened.” [^16] Yahweh says, “In this you shall know that I am Yahweh. Behold: I will strike with the rod that is in my hand on the waters which are in the river, and they shall be turned to blood. [^17] The fish that are in the river will die and the river will become foul. The Egyptians will loathe to drink water from the river.”’” [^18] Yahweh said to Moses, “Tell Aaron, ‘Take your rod, and stretch out your hand over the waters of Egypt, over their rivers, over their streams, and over their pools, and over all their ponds of water, that they may become blood. There will be blood throughout all the land of Egypt, both in vessels of wood and in vessels of stone.’” [^19] Moses and Aaron did so, as Yahweh commanded; and he lifted up the rod, and struck the waters that were in the river, in the sight of Pharaoh, and in the sight of his servants; and all the waters that were in the river were turned to blood. [^20] The fish that were in the river died. The river became foul. The Egyptians couldn’t drink water from the river. The blood was throughout all the land of Egypt. [^21] The magicians of Egypt did the same thing with their enchantments. So Pharaoh’s heart was hardened, and he didn’t listen to them, as Yahweh had spoken. [^22] Pharaoh turned and went into his house, and he didn’t even take this to heart. [^23] All the Egyptians dug around the river for water to drink; for they couldn’t drink the river water. [^24] Seven days were fulfilled, after Yahweh had struck the river. [^25] 

[[Exodus - 6|<--]] Exodus - 7 [[Exodus - 8|-->]]

---
# Notes
