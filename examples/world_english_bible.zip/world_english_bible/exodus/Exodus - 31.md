---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 31 - World English Bible"
---
[[Exodus - 30|<--]] Exodus - 31 [[Exodus - 32|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Exodus]]

# Exodus - 31

Yahweh spoke to Moses, saying, [^1] “Behold, I have called by name Bezalel the son of Uri, the son of Hur, of the tribe of Judah. [^2] I have filled him with the Spirit of God, in wisdom, and in understanding, and in knowledge, and in all kinds of workmanship, [^3] to devise skillful works, to work in gold, and in silver, and in bronze, [^4] and in cutting of stones for setting, and in carving of wood, to work in all kinds of workmanship. [^5] Behold, I myself have appointed with him Oholiab, the son of Ahisamach, of the tribe of Dan; and in the heart of all who are wise-hearted I have put wisdom, that they may make all that I have commanded you: [^6] the Tent of Meeting, the ark of the covenant, the mercy seat that is on it, all the furniture of the Tent, [^7] the table and its vessels, the pure lamp stand with all its vessels, the altar of incense, [^8] the altar of burnt offering with all its vessels, the basin and its base, [^9] the finely worked garments—the holy garments for Aaron the priest, the garments of his sons to minister in the priest’s office— [^10] the anointing oil, and the incense of sweet spices for the holy place: according to all that I have commanded you they shall do.” [^11] Yahweh spoke to Moses, saying, [^12] “Speak also to the children of Israel, saying, ‘Most certainly you shall keep my Sabbaths; for it is a sign between me and you throughout your generations, that you may know that I am Yahweh who sanctifies you. [^13] You shall keep the Sabbath therefore, for it is holy to you. Everyone who profanes it shall surely be put to death; for whoever does any work therein, that soul shall be cut off from among his people. [^14] Six days shall work be done, but on the seventh day is a Sabbath of solemn rest, holy to Yahweh. Whoever does any work on the Sabbath day shall surely be put to death. [^15] Therefore the children of Israel shall keep the Sabbath, to observe the Sabbath throughout their generations, for a perpetual covenant. [^16] It is a sign between me and the children of Israel forever; for in six days Yahweh made heaven and earth, and on the seventh day he rested, and was refreshed.’” [^17] When he finished speaking with him on Mount Sinai, he gave Moses the two tablets of the covenant, stone tablets, written with God’s finger. [^18] 

[[Exodus - 30|<--]] Exodus - 31 [[Exodus - 32|-->]]

---
# Notes
