---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 3 - World English Bible"
---
[[Exodus - 2|<--]] Exodus - 3 [[Exodus - 4|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Exodus]]

# Exodus - 3

Now Moses was keeping the flock of Jethro, his father-in-law, the priest of Midian, and he led the flock to the back of the wilderness, and came to God’s mountain, to Horeb. [^1] Yahweh’s#3:2 “Yahweh” is God’s proper Name, sometimes rendered “Lord” (all caps) in other translations. angel appeared to him in a flame of fire out of the middle of a bush. He looked, and behold, the bush burned with fire, and the bush was not consumed. [^2] Moses said, “I will go now, and see this great sight, why the bush is not burned.” [^3] When Yahweh saw that he came over to see, God called to him out of the middle of the bush, and said, “Moses! Moses!”He said, “Here I am.” [^4] He said, “Don’t come close. Take off your sandals, for the place you are standing on is holy ground.” [^5] Moreover he said, “I am the God of your father, the God of Abraham, the God of Isaac, and the God of Jacob.”Moses hid his face because he was afraid to look at God. [^6] Yahweh said, “I have surely seen the affliction of my people who are in Egypt, and have heard their cry because of their taskmasters, for I know their sorrows. [^7] I have come down to deliver them out of the hand of the Egyptians, and to bring them up out of that land to a good and large land, to a land flowing with milk and honey; to the place of the Canaanite, the Hittite, the Amorite, the Perizzite, the Hivite, and the Jebusite. [^8] Now, behold, the cry of the children of Israel has come to me. Moreover I have seen the oppression with which the Egyptians oppress them. [^9] Come now therefore, and I will send you to Pharaoh, that you may bring my people, the children of Israel, out of Egypt.” [^10] Moses said to God, “Who am I, that I should go to Pharaoh, and that I should bring the children of Israel out of Egypt?” [^11] He said, “Certainly I will be with you. This will be the token to you, that I have sent you: when you have brought the people out of Egypt, you shall serve God on this mountain.” [^12] Moses said to God, “Behold, when I come to the children of Israel, and tell them, ‘The God of your fathers has sent me to you,’ and they ask me, ‘What is his name?’ what should I tell them?” [^13] God said to Moses, “I AM WHO I AM,” and he said, “You shall tell the children of Israel this: ‘I AM has sent me to you.’” [^14] God said moreover to Moses, “You shall tell the children of Israel this, ‘Yahweh, the God of your fathers, the God of Abraham, the God of Isaac, and the God of Jacob, has sent me to you.’ This is my name forever, and this is my memorial to all generations. [^15] Go and gather the elders of Israel together, and tell them, ‘Yahweh, the God of your fathers, the God of Abraham, of Isaac, and of Jacob, has appeared to me, saying, “I have surely visited you, and seen that which is done to you in Egypt. [^16] I have said, I will bring you up out of the affliction of Egypt to the land of the Canaanite, the Hittite, the Amorite, the Perizzite, the Hivite, and the Jebusite, to a land flowing with milk and honey.”’ [^17] They will listen to your voice. You shall come, you and the elders of Israel, to the king of Egypt, and you shall tell him, ‘Yahweh, the God of the Hebrews, has met with us. Now please let us go three days’ journey into the wilderness, that we may sacrifice to Yahweh, our God.’ [^18] I know that the king of Egypt won’t give you permission to go, no, not by a mighty hand. [^19] I will reach out my hand and strike Egypt with all my wonders which I will do among them, and after that he will let you go. [^20] I will give this people favor in the sight of the Egyptians, and it will happen that when you go, you shall not go empty-handed. [^21] But every woman shall ask of her neighbor, and of her who visits her house, jewels of silver, jewels of gold, and clothing. You shall put them on your sons, and on your daughters. You shall plunder the Egyptians.” [^22] 

[[Exodus - 2|<--]] Exodus - 3 [[Exodus - 4|-->]]

---
# Notes
