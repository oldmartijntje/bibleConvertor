---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 11 - World English Bible"
---
[[Exodus - 10|<--]] Exodus - 11 [[Exodus - 12|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Exodus]]

# Exodus - 11

Yahweh said to Moses, “I will bring yet one more plague on Pharaoh, and on Egypt; afterwards he will let you go. When he lets you go, he will surely thrust you out altogether. [^1] Speak now in the ears of the people, and let every man ask of his neighbor, and every woman of her neighbor, jewels of silver, and jewels of gold.” [^2] Yahweh gave the people favor in the sight of the Egyptians. Moreover, the man Moses was very great in the land of Egypt, in the sight of Pharaoh’s servants, and in the sight of the people. [^3] Moses said, “This is what Yahweh says: ‘About midnight I will go out into the middle of Egypt, [^4] and all the firstborn in the land of Egypt shall die, from the firstborn of Pharaoh who sits on his throne, even to the firstborn of the female servant who is behind the mill, and all the firstborn of livestock. [^5] There will be a great cry throughout all the land of Egypt, such as there has not been, nor will be any more. [^6] But against any of the children of Israel a dog won’t even bark or move its tongue, against man or animal, that you may know that Yahweh makes a distinction between the Egyptians and Israel. [^7] All these servants of yours will come down to me, and bow down themselves to me, saying, “Get out, with all the people who follow you;” and after that I will go out.’” He went out from Pharaoh in hot anger. [^8] Yahweh said to Moses, “Pharaoh won’t listen to you, that my wonders may be multiplied in the land of Egypt.” [^9] Moses and Aaron did all these wonders before Pharaoh, but Yahweh hardened Pharaoh’s heart, and he didn’t let the children of Israel go out of his land. [^10] 

[[Exodus - 10|<--]] Exodus - 11 [[Exodus - 12|-->]]

---
# Notes
