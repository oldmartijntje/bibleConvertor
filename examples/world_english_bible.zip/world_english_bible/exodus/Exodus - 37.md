---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 37 - World English Bible"
---
[[Exodus - 36|<--]] Exodus - 37 [[Exodus - 38|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Exodus]]

# Exodus - 37

Bezalel made the ark of acacia wood. Its length was two and a half cubits,#37:1 A cubit is the length from the tip of the middle finger to the elbow on a man’s arm, or about 18 inches or 46 centimeters. and its width a cubit and a half, and a cubit and a half its height. [^1] He overlaid it with pure gold inside and outside, and made a molding of gold for it around it. [^2] He cast four rings of gold for it in its four feet—two rings on its one side, and two rings on its other side. [^3] He made poles of acacia wood and overlaid them with gold. [^4] He put the poles into the rings on the sides of the ark, to bear the ark. [^5] He made a mercy seat of pure gold. Its length was two and a half cubits, and a cubit and a half its width. [^6] He made two cherubim of gold. He made them of beaten work, at the two ends of the mercy seat: [^7] one cherub at the one end, and one cherub at the other end. He made the cherubim of one piece with the mercy seat at its two ends. [^8] The cherubim spread out their wings above, covering the mercy seat with their wings, with their faces toward one another. The faces of the cherubim were toward the mercy seat. [^9] He made the table of acacia wood. Its length was two cubits, and its width was a cubit, and its height was a cubit and a half. [^10] He overlaid it with pure gold, and made a gold molding around it. [^11] He made a border of a hand’s width around it, and made a golden molding on its border around it. [^12] He cast four rings of gold for it, and put the rings in the four corners that were on its four feet. [^13] The rings were close by the border, the places for the poles to carry the table. [^14] He made the poles of acacia wood, and overlaid them with gold, to carry the table. [^15] He made the vessels which were on the table, its dishes, its spoons, its bowls, and its pitchers with which to pour out, of pure gold. [^16] He made the lamp stand of pure gold. He made the lamp stand of beaten work. Its base, its shaft, its cups, its buds, and its flowers were of one piece with it. [^17] There were six branches going out of its sides: three branches of the lamp stand out of its one side, and three branches of the lamp stand out of its other side: [^18] three cups made like almond blossoms in one branch, a bud and a flower, and three cups made like almond blossoms in the other branch, a bud and a flower; so for the six branches going out of the lamp stand. [^19] In the lamp stand were four cups made like almond blossoms, its buds and its flowers; [^20] and a bud under two branches of one piece with it, and a bud under two branches of one piece with it, and a bud under two branches of one piece with it, for the six branches going out of it. [^21] Their buds and their branches were of one piece with it. The whole thing was one beaten work of pure gold. [^22] He made its seven lamps, and its snuffers, and its snuff dishes, of pure gold. [^23] He made it of a talent#37:24 A talent is about 30 kilograms or 66 pounds or 965 Troy ounces of pure gold, with all its vessels. [^24] He made the altar of incense of acacia wood. It was square: its length was a cubit, and its width a cubit. Its height was two cubits. Its horns were of one piece with it. [^25] He overlaid it with pure gold: its top, its sides around it, and its horns. He made a gold molding around it. [^26] He made two golden rings for it under its molding crown, on its two ribs, on its two sides, for places for poles with which to carry it. [^27] He made the poles of acacia wood, and overlaid them with gold. [^28] He made the holy anointing oil and the pure incense of sweet spices, after the art of the perfumer. [^29] 

[[Exodus - 36|<--]] Exodus - 37 [[Exodus - 38|-->]]

---
# Notes
