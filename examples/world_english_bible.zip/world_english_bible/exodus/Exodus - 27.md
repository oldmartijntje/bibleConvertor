---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 27 - World English Bible"
---
[[Exodus - 26|<--]] Exodus - 27 [[Exodus - 28|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Exodus]]

# Exodus - 27

“You shall make the altar of acacia wood, five cubits#27:1 A cubit is the length from the tip of the middle finger to the elbow on a man’s arm, or about 18 inches or 46 centimeters. long, and five cubits wide. The altar shall be square. Its height shall be three cubits.#27:1 The altar was to be about 2.3×2.3×1.4 meters or about 7½×7½×4½ feet. [^1] You shall make its horns on its four corners. Its horns shall be of one piece with it. You shall overlay it with bronze. [^2] You shall make its pots to take away its ashes; and its shovels, its basins, its meat hooks, and its fire pans. You shall make all its vessels of bronze. [^3] You shall make a grating for it of network of bronze. On the net you shall make four bronze rings in its four corners. [^4] You shall put it under the ledge around the altar beneath, that the net may reach halfway up the altar. [^5] You shall make poles for the altar, poles of acacia wood, and overlay them with bronze. [^6] Its poles shall be put into the rings, and the poles shall be on the two sides of the altar when carrying it. [^7] You shall make it hollow with planks. They shall make it as it has been shown you on the mountain. [^8] “You shall make the court of the tabernacle: for the south side southward there shall be hangings for the court of fine twined linen one hundred cubits long for one side. [^9] Its pillars shall be twenty, and their sockets twenty, of bronze. The hooks of the pillars and their fillets shall be of silver. [^10] Likewise for the length of the north side, there shall be hangings one hundred cubits long, and its pillars twenty, and their sockets twenty, of bronze; the hooks of the pillars, and their fillets, of silver. [^11] For the width of the court on the west side shall be hangings of fifty cubits; their pillars ten, and their sockets ten. [^12] The width of the court on the east side eastward shall be fifty cubits. [^13] The hangings for the one side of the gate shall be fifteen cubits; their pillars three, and their sockets three. [^14] For the other side shall be hangings of fifteen cubits; their pillars three, and their sockets three. [^15] For the gate of the court shall be a screen of twenty cubits, of blue, and purple, and scarlet, and fine twined linen, the work of the embroiderer; their pillars four, and their sockets four. [^16] All the pillars of the court around shall be filleted with silver; their hooks of silver, and their sockets of bronze. [^17] The length of the court shall be one hundred cubits, and the width fifty throughout, and the height five cubits, of fine twined linen, and their sockets of bronze. [^18] All the instruments of the tabernacle in all its service, and all its pins, and all the pins of the court, shall be of bronze. [^19] “You shall command the children of Israel, that they bring to you pure olive oil beaten for the light, to cause a lamp to burn continually. [^20] In the Tent of Meeting, outside the veil which is before the covenant, Aaron and his sons shall keep it in order from evening to morning before Yahweh: it shall be a statute forever throughout their generations on the behalf of the children of Israel. [^21] 

[[Exodus - 26|<--]] Exodus - 27 [[Exodus - 28|-->]]

---
# Notes
