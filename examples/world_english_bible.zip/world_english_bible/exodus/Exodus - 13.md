---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 13 - World English Bible"
---
[[Exodus - 12|<--]] Exodus - 13 [[Exodus - 14|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Exodus]]

# Exodus - 13

Yahweh spoke to Moses, saying, [^1] “Sanctify to me all the firstborn, whatever opens the womb among the children of Israel, both of man and of animal. It is mine.” [^2] Moses said to the people, “Remember this day, in which you came out of Egypt, out of the house of bondage; for by strength of hand Yahweh brought you out from this place. No leavened bread shall be eaten. [^3] Today you go out in the month Abib. [^4] It shall be, when Yahweh brings you into the land of the Canaanite, and the Hittite, and the Amorite, and the Hivite, and the Jebusite, which he swore to your fathers to give you, a land flowing with milk and honey, that you shall keep this service in this month. [^5] Seven days you shall eat unleavened bread, and in the seventh day shall be a feast to Yahweh. [^6] Unleavened bread shall be eaten throughout the seven days; and no leavened bread shall be seen with you. No yeast shall be seen with you, within all your borders. [^7] You shall tell your son in that day, saying, ‘It is because of that which Yahweh did for me when I came out of Egypt.’ [^8] It shall be for a sign to you on your hand, and for a memorial between your eyes, that Yahweh’s law may be in your mouth; for with a strong hand Yahweh has brought you out of Egypt. [^9] You shall therefore keep this ordinance in its season from year to year. [^10] “It shall be, when Yahweh brings you into the land of the Canaanite, as he swore to you and to your fathers, and will give it to you, [^11] that you shall set apart to Yahweh all that opens the womb, and every firstborn that comes from an animal which you have. The males shall be Yahweh’s. [^12] Every firstborn of a donkey you shall redeem with a lamb; and if you will not redeem it, then you shall break its neck; and you shall redeem all the firstborn of man among your sons. [^13] It shall be, when your son asks you in time to come, saying, ‘What is this?’ that you shall tell him, ‘By strength of hand Yahweh brought us out from Egypt, from the house of bondage. [^14] When Pharaoh stubbornly refused to let us go, Yahweh killed all the firstborn in the land of Egypt, both the firstborn of man, and the firstborn of livestock. Therefore I sacrifice to Yahweh all that opens the womb, being males; but all the firstborn of my sons I redeem.’ [^15] It shall be for a sign on your hand, and for symbols between your eyes; for by strength of hand Yahweh brought us out of Egypt.” [^16] When Pharaoh had let the people go, God didn’t lead them by the way of the land of the Philistines, although that was near; for God said, “Lest perhaps the people change their minds when they see war, and they return to Egypt”; [^17] but God led the people around by the way of the wilderness by the Red Sea; and the children of Israel went up armed out of the land of Egypt. [^18] Moses took the bones of Joseph with him, for he had made the children of Israel swear, saying, “God will surely visit you, and you shall carry up my bones away from here with you.” [^19] They took their journey from Succoth, and encamped in Etham, in the edge of the wilderness. [^20] Yahweh went before them by day in a pillar of cloud, to lead them on their way, and by night in a pillar of fire, to give them light, that they might go by day and by night: [^21] the pillar of cloud by day, and the pillar of fire by night, didn’t depart from before the people. [^22] 

[[Exodus - 12|<--]] Exodus - 13 [[Exodus - 14|-->]]

---
# Notes
