---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 6 - World English Bible"
---
[[Exodus - 5|<--]] Exodus - 6 [[Exodus - 7|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Exodus]]

# Exodus - 6

Yahweh said to Moses, “Now you shall see what I will do to Pharaoh, for by a strong hand he shall let them go, and by a strong hand he shall drive them out of his land.” [^1] God spoke to Moses, and said to him, “I am Yahweh. [^2] I appeared to Abraham, to Isaac, and to Jacob, as God Almighty; but by my name Yahweh I was not known to them. [^3] I have also established my covenant with them, to give them the land of Canaan, the land of their travels, in which they lived as aliens. [^4] Moreover I have heard the groaning of the children of Israel, whom the Egyptians keep in bondage, and I have remembered my covenant. [^5] Therefore tell the children of Israel, ‘I am Yahweh, and I will bring you out from under the burdens of the Egyptians, and I will rid you out of their bondage, and I will redeem you with an outstretched arm, and with great judgments. [^6] I will take you to myself for a people. I will be your God; and you shall know that I am Yahweh your God, who brings you out from under the burdens of the Egyptians. [^7] I will bring you into the land which I swore to give to Abraham, to Isaac, and to Jacob; and I will give it to you for a heritage: I am Yahweh.’” [^8] Moses spoke so to the children of Israel, but they didn’t listen to Moses for anguish of spirit, and for cruel bondage. [^9] Yahweh spoke to Moses, saying, [^10] “Go in, speak to Pharaoh king of Egypt, that he let the children of Israel go out of his land.” [^11] Moses spoke before Yahweh, saying, “Behold, the children of Israel haven’t listened to me. How then shall Pharaoh listen to me, when I have uncircumcised lips?” [^12] Yahweh spoke to Moses and to Aaron, and gave them a command to the children of Israel, and to Pharaoh king of Egypt, to bring the children of Israel out of the land of Egypt. [^13] These are the heads of their fathers’ houses. The sons of Reuben the firstborn of Israel: Hanoch, and Pallu, Hezron, and Carmi; these are the families of Reuben. [^14] The sons of Simeon: Jemuel, and Jamin, and Ohad, and Jachin, and Zohar, and Shaul the son of a Canaanite woman; these are the families of Simeon. [^15] These are the names of the sons of Levi according to their generations: Gershon, and Kohath, and Merari; and the years of the life of Levi were one hundred thirty-seven years. [^16] The sons of Gershon: Libni and Shimei, according to their families. [^17] The sons of Kohath: Amram, and Izhar, and Hebron, and Uzziel; and the years of the life of Kohath were one hundred thirty-three years. [^18] The sons of Merari: Mahli and Mushi. These are the families of the Levites according to their generations. [^19] Amram took Jochebed his father’s sister to himself as wife; and she bore him Aaron and Moses. The years of the life of Amram were one hundred thirty-seven years. [^20] The sons of Izhar: Korah, and Nepheg, and Zichri. [^21] The sons of Uzziel: Mishael, Elzaphan, and Sithri. [^22] Aaron took Elisheba, the daughter of Amminadab, the sister of Nahshon, as his wife; and she bore him Nadab and Abihu, Eleazar and Ithamar. [^23] The sons of Korah: Assir, Elkanah, and Abiasaph; these are the families of the Korahites. [^24] Eleazar Aaron’s son took one of the daughters of Putiel as his wife; and she bore him Phinehas. These are the heads of the fathers’ houses of the Levites according to their families. [^25] These are that Aaron and Moses to whom Yahweh said, “Bring out the children of Israel from the land of Egypt according to their armies.” [^26] These are those who spoke to Pharaoh king of Egypt, to bring out the children of Israel from Egypt. These are that Moses and Aaron. [^27] On the day when Yahweh spoke to Moses in the land of Egypt, [^28] Yahweh said to Moses, “I am Yahweh. Tell Pharaoh king of Egypt all that I tell you.” [^29] Moses said before Yahweh, “Behold, I am of uncircumcised lips, and how shall Pharaoh listen to me?” [^30] 

[[Exodus - 5|<--]] Exodus - 6 [[Exodus - 7|-->]]

---
# Notes
