---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 33 - World English Bible"
---
[[Exodus - 32|<--]] Exodus - 33 [[Exodus - 34|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Exodus]]

# Exodus - 33

Yahweh spoke to Moses, “Depart, go up from here, you and the people that you have brought up out of the land of Egypt, to the land of which I swore to Abraham, to Isaac, and to Jacob, saying, ‘I will give it to your offspring.’ [^1] I will send an angel before you; and I will drive out the Canaanite, the Amorite, and the Hittite, and the Perizzite, the Hivite, and the Jebusite. [^2] Go to a land flowing with milk and honey; but I will not go up among you, for you are a stiff-necked people, lest I consume you on the way.” [^3] When the people heard this evil news, they mourned; and no one put on his jewelry. [^4] Yahweh had said to Moses, “Tell the children of Israel, ‘You are a stiff-necked people. If I were to go up among you for one moment, I would consume you. Therefore now take off your jewelry from you, that I may know what to do to you.’” [^5] The children of Israel stripped themselves of their jewelry from Mount Horeb onward. [^6] Now Moses used to take the tent and pitch it outside the camp, far away from the camp, and he called it “The Tent of Meeting.” Everyone who sought Yahweh went out to the Tent of Meeting, which was outside the camp. [^7] When Moses went out to the Tent, all the people rose up, and stood, everyone at their tent door, and watched Moses, until he had gone into the Tent. [^8] When Moses entered into the Tent, the pillar of cloud descended, stood at the door of the Tent, and Yahweh spoke with Moses. [^9] All the people saw the pillar of cloud stand at the door of the Tent, and all the people rose up and worshiped, everyone at their tent door. [^10] Yahweh spoke to Moses face to face, as a man speaks to his friend. He turned again into the camp, but his servant Joshua, the son of Nun, a young man, didn’t depart from the Tent. [^11] Moses said to Yahweh, “Behold, you tell me, ‘Bring up this people;’ and you haven’t let me know whom you will send with me. Yet you have said, ‘I know you by name, and you have also found favor in my sight.’ [^12] Now therefore, if I have found favor in your sight, please show me your way, now, that I may know you, so that I may find favor in your sight; and consider that this nation is your people.” [^13] He said, “My presence will go with you, and I will give you rest.” [^14] Moses said to him, “If your presence doesn’t go with me, don’t carry us up from here. [^15] For how would people know that I have found favor in your sight, I and your people? Isn’t it that you go with us, so that we are separated, I and your people, from all the people who are on the surface of the earth?” [^16] Yahweh said to Moses, “I will do this thing also that you have spoken; for you have found favor in my sight, and I know you by name.” [^17] Moses said, “Please show me your glory.” [^18] He said, “I will make all my goodness pass before you, and will proclaim Yahweh’s name before you. I will be gracious to whom I will be gracious, and will show mercy on whom I will show mercy.” [^19] He said, “You cannot see my face, for man may not see me and live.” [^20] Yahweh also said, “Behold, there is a place by me, and you shall stand on the rock. [^21] It will happen, while my glory passes by, that I will put you in a cleft of the rock, and will cover you with my hand until I have passed by; [^22] then I will take away my hand, and you will see my back; but my face shall not be seen.” [^23] 

[[Exodus - 32|<--]] Exodus - 33 [[Exodus - 34|-->]]

---
# Notes
