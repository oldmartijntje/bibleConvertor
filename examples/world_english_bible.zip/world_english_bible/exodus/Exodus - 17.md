---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 17 - World English Bible"
---
[[Exodus - 16|<--]] Exodus - 17 [[Exodus - 18|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Exodus]]

# Exodus - 17

All the congregation of the children of Israel traveled from the wilderness of Sin, starting according to Yahweh’s commandment, and encamped in Rephidim; but there was no water for the people to drink. [^1] Therefore the people quarreled with Moses, and said, “Give us water to drink.”Moses said to them, “Why do you quarrel with me? Why do you test Yahweh?” [^2] The people were thirsty for water there; so the people murmured against Moses, and said, “Why have you brought us up out of Egypt, to kill us, our children, and our livestock with thirst?” [^3] Moses cried to Yahweh, saying, “What shall I do with these people? They are almost ready to stone me.” [^4] Yahweh said to Moses, “Walk on before the people, and take the elders of Israel with you, and take the rod in your hand with which you struck the Nile, and go. [^5] Behold, I will stand before you there on the rock in Horeb. You shall strike the rock, and water will come out of it, that the people may drink.” Moses did so in the sight of the elders of Israel. [^6] He called the name of the place Massah,#17:7 Massah means testing.  and Meribah,#17:7 Meribah means quarreling. because the children of Israel quarreled, and because they tested Yahweh, saying, “Is Yahweh among us, or not?” [^7] Then Amalek came and fought with Israel in Rephidim. [^8] Moses said to Joshua, “Choose men for us, and go out to fight with Amalek. Tomorrow I will stand on the top of the hill with God’s rod in my hand.” [^9] So Joshua did as Moses had told him, and fought with Amalek; and Moses, Aaron, and Hur went up to the top of the hill. [^10] When Moses held up his hand, Israel prevailed. When he let down his hand, Amalek prevailed. [^11] But Moses’ hands were heavy; so they took a stone, and put it under him, and he sat on it. Aaron and Hur held up his hands, the one on the one side, and the other on the other side. His hands were steady until sunset. [^12] Joshua defeated Amalek and his people with the edge of the sword. [^13] Yahweh said to Moses, “Write this for a memorial in a book, and rehearse it in the ears of Joshua: that I will utterly blot out the memory of Amalek from under the sky.” [^14] Moses built an altar, and called its name “Yahweh our Banner”.#17:15 Hebrew, Yahweh Nissi [^15] He said, “Yah has sworn: ‘Yahweh will have war with Amalek from generation to generation.’” [^16] 

[[Exodus - 16|<--]] Exodus - 17 [[Exodus - 18|-->]]

---
# Notes
