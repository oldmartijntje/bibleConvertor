---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 24 - World English Bible"
---
[[Exodus - 23|<--]] Exodus - 24 [[Exodus - 25|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Exodus]]

# Exodus - 24

He said to Moses, “Come up to Yahweh, you, and Aaron, Nadab, and Abihu, and seventy of the elders of Israel; and worship from a distance. [^1] Moses alone shall come near to Yahweh, but they shall not come near. The people shall not go up with him.” [^2] Moses came and told the people all Yahweh’s words, and all the ordinances; and all the people answered with one voice, and said, “All the words which Yahweh has spoken will we do.” [^3] Moses wrote all Yahweh’s words, then rose up early in the morning and built an altar at the base of the mountain, with twelve pillars for the twelve tribes of Israel. [^4] He sent young men of the children of Israel, who offered burnt offerings and sacrificed peace offerings of cattle to Yahweh. [^5] Moses took half of the blood and put it in basins, and half of the blood he sprinkled on the altar. [^6] He took the book of the covenant and read it in the hearing of the people, and they said, “We will do all that Yahweh has said, and be obedient.” [^7] Moses took the blood, and sprinkled it on the people, and said, “Look, this is the blood of the covenant, which Yahweh has made with you concerning all these words.” [^8] Then Moses, Aaron, Nadab, Abihu, and seventy of the elders of Israel went up. [^9] They saw the God of Israel. Under his feet was like a paved work of sapphire#24:10 or, lapis lazuli stone, like the skies for clearness. [^10] He didn’t lay his hand on the nobles of the children of Israel. They saw God, and ate and drank. [^11] Yahweh said to Moses, “Come up to me on the mountain, and stay here, and I will give you the stone tablets with the law and the commands that I have written, that you may teach them.” [^12] Moses rose up with Joshua, his servant, and Moses went up onto God’s Mountain. [^13] He said to the elders, “Wait here for us, until we come again to you. Behold, Aaron and Hur are with you. Whoever is involved in a dispute can go to them.” [^14] Moses went up on the mountain, and the cloud covered the mountain. [^15] Yahweh’s glory settled on Mount Sinai, and the cloud covered it six days. The seventh day he called to Moses out of the middle of the cloud. [^16] The appearance of Yahweh’s glory was like devouring fire on the top of the mountain in the eyes of the children of Israel. [^17] Moses entered into the middle of the cloud, and went up on the mountain; and Moses was on the mountain forty days and forty nights. [^18] 

[[Exodus - 23|<--]] Exodus - 24 [[Exodus - 25|-->]]

---
# Notes
