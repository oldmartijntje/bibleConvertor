---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 39 - World English Bible"
---
[[Genesis - 38|<--]] Genesis - 39 [[Genesis - 40|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Genesis]]

# Genesis - 39

Joseph was brought down to Egypt. Potiphar, an officer of Pharaoh’s, the captain of the guard, an Egyptian, bought him from the hand of the Ishmaelites that had brought him down there. [^1] Yahweh was with Joseph, and he was a prosperous man. He was in the house of his master the Egyptian. [^2] His master saw that Yahweh was with him, and that Yahweh made all that he did prosper in his hand. [^3] Joseph found favor in his sight. He ministered to him, and Potiphar made him overseer over his house, and all that he had he put into his hand. [^4] From the time that he made him overseer in his house, and over all that he had, Yahweh blessed the Egyptian’s house for Joseph’s sake. Yahweh’s blessing was on all that he had, in the house and in the field. [^5] He left all that he had in Joseph’s hand. He didn’t concern himself with anything, except for the food which he ate.Joseph was well-built and handsome. [^6] After these things, his master’s wife set her eyes on Joseph; and she said, “Lie with me.” [^7] But he refused, and said to his master’s wife, “Behold, my master doesn’t know what is with me in the house, and he has put all that he has into my hand. [^8] No one is greater in this house than I am, and he has not kept back anything from me but you, because you are his wife. How then can I do this great wickedness, and sin against God?” [^9] As she spoke to Joseph day by day, he didn’t listen to her, to lie by her, or to be with her. [^10] About this time, he went into the house to do his work, and there were none of the men of the house inside. [^11] She caught him by his garment, saying, “Lie with me!”He left his garment in her hand, and ran outside. [^12] When she saw that he had left his garment in her hand, and had run outside, [^13] she called to the men of her house, and spoke to them, saying, “Behold, he has brought a Hebrew in to us to mock us. He came in to me to lie with me, and I cried with a loud voice. [^14] When he heard that I lifted up my voice and cried, he left his garment by me, and ran outside.” [^15] She laid up his garment by her, until his master came home. [^16] She spoke to him according to these words, saying, “The Hebrew servant, whom you have brought to us, came in to me to mock me, [^17] and as I lifted up my voice and cried, he left his garment by me, and ran outside.” [^18] When his master heard the words of his wife, which she spoke to him, saying, “This is what your servant did to me,” his wrath was kindled. [^19] Joseph’s master took him, and put him into the prison, the place where the king’s prisoners were bound, and he was there in custody. [^20] But Yahweh was with Joseph, and showed kindness to him, and gave him favor in the sight of the keeper of the prison. [^21] The keeper of the prison committed to Joseph’s hand all the prisoners who were in the prison. Whatever they did there, he was responsible for it. [^22] The keeper of the prison didn’t look after anything that was under his hand, because Yahweh was with him; and that which he did, Yahweh made it prosper. [^23] 

[[Genesis - 38|<--]] Genesis - 39 [[Genesis - 40|-->]]

---
# Notes
