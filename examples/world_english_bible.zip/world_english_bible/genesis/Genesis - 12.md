---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 12 - World English Bible"
---
[[Genesis - 11|<--]] Genesis - 12 [[Genesis - 13|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Genesis]]

# Genesis - 12

Now Yahweh said to Abram, “Leave your country, and your relatives, and your father’s house, and go to the land that I will show you. [^1] I will make of you a great nation. I will bless you and make your name great. You will be a blessing. [^2] I will bless those who bless you, and I will curse him who treats you with contempt. All the families of the earth will be blessed through you.” [^3] So Abram went, as Yahweh had told him. Lot went with him. Abram was seventy-five years old when he departed from Haran. [^4] Abram took Sarai his wife, Lot his brother’s son, all their possessions that they had gathered, and the people whom they had acquired in Haran, and they went to go into the land of Canaan. They entered into the land of Canaan. [^5] Abram passed through the land to the place of Shechem, to the oak of Moreh. At that time, Canaanites were in the land. [^6] Yahweh appeared to Abram and said, “I will give this land to your offspring.”#12:7 or, seedHe built an altar there to Yahweh, who had appeared to him. [^7] He left from there to go to the mountain on the east of Bethel and pitched his tent, having Bethel on the west, and Ai on the east. There he built an altar to Yahweh and called on Yahweh’s name. [^8] Abram traveled, still going on toward the South. [^9] There was a famine in the land. Abram went down into Egypt to live as a foreigner there, for the famine was severe in the land. [^10] When he had come near to enter Egypt, he said to Sarai his wife, “See now, I know that you are a beautiful woman to look at. [^11] It will happen that when the Egyptians see you, they will say, ‘This is his wife.’ They will kill me, but they will save you alive. [^12] Please say that you are my sister, that it may be well with me for your sake, and that my soul may live because of you.” [^13] When Abram had come into Egypt, some Egyptians saw that the woman was very beautiful. [^14] The princes of Pharaoh saw her, and praised her to Pharaoh; and the woman was taken into Pharaoh’s house. [^15] He dealt well with Abram for her sake. He had sheep, cattle, male donkeys, male servants, female servants, female donkeys, and camels. [^16] Yahweh afflicted Pharaoh and his house with great plagues because of Sarai, Abram’s wife. [^17] Pharaoh called Abram and said, “What is this that you have done to me? Why didn’t you tell me that she was your wife? [^18] Why did you say, ‘She is my sister,’ so that I took her to be my wife? Now therefore, see your wife, take her, and go your way.” [^19] Pharaoh commanded men concerning him, and they escorted him away with his wife and all that he had. [^20] 

[[Genesis - 11|<--]] Genesis - 12 [[Genesis - 13|-->]]

---
# Notes
