---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 7 - World English Bible"
---
[[Genesis - 6|<--]] Genesis - 7 [[Genesis - 8|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Genesis]]

# Genesis - 7

Yahweh said to Noah, “Come with all of your household into the ship, for I have seen your righteousness before me in this generation. [^1] You shall take seven pairs of every clean animal with you, the male and his female. Of the animals that are not clean, take two, the male and his female. [^2] Also of the birds of the sky, seven and seven, male and female, to keep seed alive on the surface of all the earth. [^3] In seven days, I will cause it to rain on the earth for forty days and forty nights. I will destroy every living thing that I have made from the surface of the ground.” [^4] Noah did everything that Yahweh commanded him. [^5] Noah was six hundred years old when the flood of waters came on the earth. [^6] Noah went into the ship with his sons, his wife, and his sons’ wives, because of the floodwaters. [^7] Clean animals, unclean animals, birds, and everything that creeps on the ground [^8] went by pairs to Noah into the ship, male and female, as God commanded Noah. [^9] After the seven days, the floodwaters came on the earth. [^10] In the six hundredth year of Noah’s life, in the second month, on the seventeenth day of the month, on that day all the fountains of the great deep burst open, and the sky’s windows opened. [^11] It rained on the earth forty days and forty nights. [^12] In the same day Noah, and Shem, Ham, and Japheth—the sons of Noah—and Noah’s wife and the three wives of his sons with them, entered into the ship— [^13] they, and every animal after its kind, all the livestock after their kind, every creeping thing that creeps on the earth after its kind, and every bird after its kind, every bird of every sort. [^14] Pairs from all flesh with the breath of life in them went into the ship to Noah. [^15] Those who went in, went in male and female of all flesh, as God commanded him; then Yahweh shut him in. [^16] The flood was forty days on the earth. The waters increased, and lifted up the ship, and it was lifted up above the earth. [^17] The waters rose, and increased greatly on the earth; and the ship floated on the surface of the waters. [^18] The waters rose very high on the earth. All the high mountains that were under the whole sky were covered. [^19] The waters rose fifteen cubits#7:20 A cubit is the length from the tip of the middle finger to the elbow on a man’s arm, or about 18 inches or 46 centimeters. higher, and the mountains were covered. [^20] All flesh died that moved on the earth, including birds, livestock, animals, every creeping thing that creeps on the earth, and every man. [^21] All on the dry land, in whose nostrils was the breath of the spirit of life, died. [^22] Every living thing was destroyed that was on the surface of the ground, including man, livestock, creeping things, and birds of the sky. They were destroyed from the earth. Only Noah was left, and those who were with him in the ship. [^23] The waters flooded the earth one hundred fifty days. [^24] 

[[Genesis - 6|<--]] Genesis - 7 [[Genesis - 8|-->]]

---
# Notes
