---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 25 - World English Bible"
---
[[Genesis - 24|<--]] Genesis - 25 [[Genesis - 26|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Genesis]]

# Genesis - 25

Abraham took another wife, and her name was Keturah. [^1] She bore him Zimran, Jokshan, Medan, Midian, Ishbak, and Shuah. [^2] Jokshan became the father of Sheba, and Dedan. The sons of Dedan were Asshurim, Letushim, and Leummim. [^3] The sons of Midian were Ephah, Epher, Hanoch, Abida, and Eldaah. All these were the children of Keturah. [^4] Abraham gave all that he had to Isaac, [^5] but Abraham gave gifts to the sons of Abraham’s concubines. While he still lived, he sent them away from Isaac his son, eastward, to the east country. [^6] These are the days of the years of Abraham’s life which he lived: one hundred seventy-five years. [^7] Abraham gave up his spirit, and died at a good old age, an old man, and full of years, and was gathered to his people. [^8] Isaac and Ishmael, his sons, buried him in the cave of Machpelah, in the field of Ephron, the son of Zohar the Hittite, which is near Mamre, [^9] the field which Abraham purchased from the children of Heth. Abraham was buried there with Sarah, his wife. [^10] After the death of Abraham, God blessed Isaac, his son. Isaac lived by Beer Lahai Roi. [^11] Now this is the history of the generations of Ishmael, Abraham’s son, whom Hagar the Egyptian, Sarah’s servant, bore to Abraham. [^12] These are the names of the sons of Ishmael, by their names, according to the order of their birth: the firstborn of Ishmael, Nebaioth, then Kedar, Adbeel, Mibsam, [^13] Mishma, Dumah, Massa, [^14] Hadad, Tema, Jetur, Naphish, and Kedemah. [^15] These are the sons of Ishmael, and these are their names, by their villages, and by their encampments: twelve princes, according to their nations. [^16] These are the years of the life of Ishmael: one hundred thirty-seven years. He gave up his spirit and died, and was gathered to his people. [^17] They lived from Havilah to Shur that is before Egypt, as you go toward Assyria. He lived opposite all his relatives. [^18] This is the history of the generations of Isaac, Abraham’s son. Abraham became the father of Isaac. [^19] Isaac was forty years old when he took Rebekah, the daughter of Bethuel the Syrian of Paddan Aram, the sister of Laban the Syrian, to be his wife. [^20] Isaac entreated Yahweh for his wife, because she was barren. Yahweh was entreated by him, and Rebekah his wife conceived. [^21] The children struggled together within her. She said, “If it is like this, why do I live?” She went to inquire of Yahweh. [^22] Yahweh said to her,“Two nations are in your womb.Two peoples will be separated from your body.The one people will be stronger than the other people.The elder will serve the younger.” [^23] When her days to be delivered were fulfilled, behold, there were twins in her womb. [^24] The first came out red all over, like a hairy garment. They named him Esau. [^25] After that, his brother came out, and his hand had hold on Esau’s heel. He was named Jacob. Isaac was sixty years old when she bore them. [^26] The boys grew. Esau was a skillful hunter, a man of the field. Jacob was a quiet man, living in tents. [^27] Now Isaac loved Esau, because he ate his venison. Rebekah loved Jacob. [^28] Jacob boiled stew. Esau came in from the field, and he was famished. [^29] Esau said to Jacob, “Please feed me with some of that red stew, for I am famished.” Therefore his name was called Edom.#25:30 “Edom” means “red”. [^30] Jacob said, “First, sell me your birthright.” [^31] Esau said, “Behold, I am about to die. What good is the birthright to me?” [^32] Jacob said, “Swear to me first.”He swore to him. He sold his birthright to Jacob. [^33] Jacob gave Esau bread and lentil stew. He ate and drank, rose up, and went his way. So Esau despised his birthright. [^34] 

[[Genesis - 24|<--]] Genesis - 25 [[Genesis - 26|-->]]

---
# Notes
