---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 3 - World English Bible"
---
[[Genesis - 2|<--]] Genesis - 3 [[Genesis - 4|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Genesis]]

# Genesis - 3

Now the serpent was more subtle than any animal of the field which Yahweh God had made. He said to the woman, “Has God really said, ‘You shall not eat of any tree of the garden’?” [^1] The woman said to the serpent, “We may eat fruit from the trees of the garden, [^2] but not the fruit of the tree which is in the middle of the garden. God has said, ‘You shall not eat of it. You shall not touch it, lest you die.’” [^3] The serpent said to the woman, “You won’t really die, [^4] for God knows that in the day you eat it, your eyes will be opened, and you will be like God, knowing good and evil.” [^5] When the woman saw that the tree was good for food, and that it was a delight to the eyes, and that the tree was to be desired to make one wise, she took some of its fruit, and ate. Then she gave some to her husband with her, and he ate it, too. [^6] Their eyes were opened, and they both knew that they were naked. They sewed fig leaves together, and made coverings for themselves. [^7] They heard Yahweh God’s voice walking in the garden in the cool of the day, and the man and his wife hid themselves from the presence of Yahweh God among the trees of the garden. [^8] Yahweh God called to the man, and said to him, “Where are you?” [^9] The man said, “I heard your voice in the garden, and I was afraid, because I was naked; so I hid myself.” [^10] God said, “Who told you that you were naked? Have you eaten from the tree that I commanded you not to eat from?” [^11] The man said, “The woman whom you gave to be with me, she gave me fruit from the tree, and I ate it.” [^12] Yahweh God said to the woman, “What have you done?”The woman said, “The serpent deceived me, and I ate.” [^13] Yahweh God said to the serpent,“Because you have done this,you are cursed above all livestock,and above every animal of the field.You shall go on your bellyand you shall eat dust all the days of your life. [^14] I will put hostility between you and the woman,and between your offspring and her offspring.He will bruise your head,and you will bruise his heel.” [^15] To the woman he said,“I will greatly multiply your pain in childbirth.You will bear children in pain.Your desire will be for your husband,and he will rule over you.” [^16] To Adam he said,“Because you have listened to your wife’s voice,and have eaten from the tree,about which I commanded you, saying, ‘You shall not eat of it,’the ground is cursed for your sake.You will eat from it with much labor all the days of your life. [^17] It will yield thorns and thistles to you;and you will eat the herb of the field. [^18] You will eat bread by the sweat of your face until you return to the ground,for you were taken out of it.For you are dust,and you shall return to dust.” [^19] The man called his wife Eve because she would be the mother of all the living. [^20] Yahweh God made garments of animal skins for Adam and for his wife, and clothed them. [^21] Yahweh God said, “Behold, the man has become like one of us, knowing good and evil. Now, lest he reach out his hand, and also take of the tree of life, and eat, and live forever—” [^22] Therefore Yahweh God sent him out from the garden of Eden, to till the ground from which he was taken. [^23] So he drove out the man; and he placed cherubim#3:24 cherubim are powerful angelic creatures, messengers of God with wings. See Ezekiel 10. at the east of the garden of Eden, and a flaming sword which turned every way, to guard the way to the tree of life. [^24] 

[[Genesis - 2|<--]] Genesis - 3 [[Genesis - 4|-->]]

---
# Notes
