---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 40 - World English Bible"
---
[[Genesis - 39|<--]] Genesis - 40 [[Genesis - 41|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Genesis]]

# Genesis - 40

After these things, the butler of the king of Egypt and his baker offended their lord, the king of Egypt. [^1] Pharaoh was angry with his two officers, the chief cup bearer and the chief baker. [^2] He put them in custody in the house of the captain of the guard, into the prison, the place where Joseph was bound. [^3] The captain of the guard assigned them to Joseph, and he took care of them. They stayed in prison many days. [^4] They both dreamed a dream, each man his dream, in one night, each man according to the interpretation of his dream, the cup bearer and the baker of the king of Egypt, who were bound in the prison. [^5] Joseph came in to them in the morning, and saw them, and saw that they were sad. [^6] He asked Pharaoh’s officers who were with him in custody in his master’s house, saying, “Why do you look so sad today?” [^7] They said to him, “We have dreamed a dream, and there is no one who can interpret it.”Joseph said to them, “Don’t interpretations belong to God? Please tell it to me.” [^8] The chief cup bearer told his dream to Joseph, and said to him, “In my dream, behold, a vine was in front of me, [^9] and in the vine were three branches. It was as though it budded, it blossomed, and its clusters produced ripe grapes. [^10] Pharaoh’s cup was in my hand; and I took the grapes, and pressed them into Pharaoh’s cup, and I gave the cup into Pharaoh’s hand.” [^11] Joseph said to him, “This is its interpretation: the three branches are three days. [^12] Within three more days, Pharaoh will lift up your head, and restore you to your office. You will give Pharaoh’s cup into his hand, the way you did when you were his cup bearer. [^13] But remember me when it is well with you. Please show kindness to me, and make mention of me to Pharaoh, and bring me out of this house. [^14] For indeed, I was stolen away out of the land of the Hebrews, and here also I have done nothing that they should put me into the dungeon.” [^15] When the chief baker saw that the interpretation was good, he said to Joseph, “I also was in my dream, and behold, three baskets of white bread were on my head. [^16] In the uppermost basket there were all kinds of baked food for Pharaoh, and the birds ate them out of the basket on my head.” [^17] Joseph answered, “This is its interpretation. The three baskets are three days. [^18] Within three more days, Pharaoh will lift up your head from off you, and will hang you on a tree; and the birds will eat your flesh from off you.” [^19] On the third day, which was Pharaoh’s birthday, he made a feast for all his servants, and he lifted up the head of the chief cup bearer and the head of the chief baker among his servants. [^20] He restored the chief cup bearer to his position again, and he gave the cup into Pharaoh’s hand; [^21] but he hanged the chief baker, as Joseph had interpreted to them. [^22] Yet the chief cup bearer didn’t remember Joseph, but forgot him. [^23] 

[[Genesis - 39|<--]] Genesis - 40 [[Genesis - 41|-->]]

---
# Notes
