---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 17 - World English Bible"
---
[[Genesis - 16|<--]] Genesis - 17 [[Genesis - 18|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Genesis]]

# Genesis - 17

When Abram was ninety-nine years old, Yahweh appeared to Abram and said to him, “I am God Almighty. Walk before me and be blameless. [^1] I will make my covenant between me and you, and will multiply you exceedingly.” [^2] Abram fell on his face. God talked with him, saying, [^3] “As for me, behold, my covenant is with you. You will be the father of a multitude of nations. [^4] Your name will no more be called Abram, but your name will be Abraham; for I have made you the father of a multitude of nations. [^5] I will make you exceedingly fruitful, and I will make nations of you. Kings will come out of you. [^6] I will establish my covenant between me and you and your offspring after you throughout their generations for an everlasting covenant, to be a God to you and to your offspring after you. [^7] I will give to you, and to your offspring after you, the land where you are traveling, all the land of Canaan, for an everlasting possession. I will be their God.” [^8] God said to Abraham, “As for you, you shall keep my covenant, you and your offspring after you throughout their generations. [^9] This is my covenant, which you shall keep, between me and you and your offspring after you. Every male among you shall be circumcised. [^10] You shall be circumcised in the flesh of your foreskin. It will be a token of the covenant between me and you. [^11] He who is eight days old shall be circumcised among you, every male throughout your generations, he who is born in the house, or bought with money from any foreigner who is not of your offspring. [^12] He who is born in your house, and he who is bought with your money, must be circumcised. My covenant shall be in your flesh for an everlasting covenant. [^13] The uncircumcised male who is not circumcised in the flesh of his foreskin, that soul shall be cut off from his people. He has broken my covenant.” [^14] God said to Abraham, “As for Sarai your wife, you shall not call her name Sarai, but her name shall be Sarah. [^15] I will bless her, and moreover I will give you a son by her. Yes, I will bless her, and she will be a mother of nations. Kings of peoples will come from her.” [^16] Then Abraham fell on his face, and laughed, and said in his heart, “Will a child be born to him who is one hundred years old? Will Sarah, who is ninety years old, give birth?” [^17] Abraham said to God, “Oh that Ishmael might live before you!” [^18] God said, “No, but Sarah, your wife, will bear you a son. You shall call his name Isaac.#17:19 Isaac means “he laughs”. I will establish my covenant with him for an everlasting covenant for his offspring after him. [^19] As for Ishmael, I have heard you. Behold, I have blessed him, and will make him fruitful, and will multiply him exceedingly. He will become the father of twelve princes, and I will make him a great nation. [^20] But I will establish my covenant with Isaac, whom Sarah will bear to you at this set time next year.” [^21] When he finished talking with him, God went up from Abraham. [^22] Abraham took Ishmael his son, all who were born in his house, and all who were bought with his money: every male among the men of Abraham’s house, and circumcised the flesh of their foreskin in the same day, as God had said to him. [^23] Abraham was ninety-nine years old when he was circumcised in the flesh of his foreskin. [^24] Ishmael, his son, was thirteen years old when he was circumcised in the flesh of his foreskin. [^25] In the same day both Abraham and Ishmael, his son, were circumcised. [^26] All the men of his house, those born in the house, and those bought with money from a foreigner, were circumcised with him. [^27] 

[[Genesis - 16|<--]] Genesis - 17 [[Genesis - 18|-->]]

---
# Notes
