---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 10 - World English Bible"
---
[[Genesis - 9|<--]] Genesis - 10 [[Genesis - 11|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Genesis]]

# Genesis - 10

Now this is the history of the generations of the sons of Noah and of Shem, Ham, and Japheth. Sons were born to them after the flood. [^1] The sons of Japheth were: Gomer, Magog, Madai, Javan, Tubal, Meshech, and Tiras. [^2] The sons of Gomer were: Ashkenaz, Riphath, and Togarmah. [^3] The sons of Javan were: Elishah, Tarshish, Kittim, and Dodanim. [^4] Of these were the islands of the nations divided in their lands, everyone after his language, after their families, in their nations. [^5] The sons of Ham were: Cush, Mizraim, Put, and Canaan. [^6] The sons of Cush were: Seba, Havilah, Sabtah, Raamah, and Sabteca. The sons of Raamah were: Sheba and Dedan. [^7] Cush became the father of Nimrod. He began to be a mighty one in the earth. [^8] He was a mighty hunter before Yahweh. Therefore it is said, “like Nimrod, a mighty hunter before Yahweh”. [^9] The beginning of his kingdom was Babel, Erech, Accad, and Calneh, in the land of Shinar. [^10] Out of that land he went into Assyria, and built Nineveh, Rehoboth Ir, Calah, [^11] and Resen between Nineveh and the great city Calah. [^12] Mizraim became the father of Ludim, Anamim, Lehabim, Naphtuhim, [^13] Pathrusim, Casluhim (which the Philistines descended from), and Caphtorim. [^14] Canaan became the father of Sidon (his firstborn), Heth, [^15] the Jebusites, the Amorites, the Girgashites, [^16] the Hivites, the Arkites, the Sinites, [^17] the Arvadites, the Zemarites, and the Hamathites. Afterward the families of the Canaanites were spread abroad. [^18] The border of the Canaanites was from Sidon—as you go toward Gerar—to Gaza—as you go toward Sodom, Gomorrah, Admah, and Zeboiim—to Lasha. [^19] These are the sons of Ham, after their families, according to their languages, in their lands and their nations. [^20] Children were also born to Shem (the elder brother of Japheth), the father of all the children of Eber. [^21] The sons of Shem were: Elam, Asshur, Arpachshad, Lud, and Aram. [^22] The sons of Aram were: Uz, Hul, Gether, and Mash. [^23] Arpachshad became the father of Shelah. Shelah became the father of Eber. [^24] To Eber were born two sons. The name of the one was Peleg, for in his days the earth was divided. His brother’s name was Joktan. [^25] Joktan became the father of Almodad, Sheleph, Hazarmaveth, Jerah, [^26] Hadoram, Uzal, Diklah, [^27] Obal, Abimael, Sheba, [^28] Ophir, Havilah, and Jobab. All these were the sons of Joktan. [^29] Their dwelling extended from Mesha, as you go toward Sephar, the mountain of the east. [^30] These are the sons of Shem, by their families, according to their languages, lands, and nations. [^31] These are the families of the sons of Noah, by their generations, according to their nations. The nations divided from these in the earth after the flood. [^32] 

[[Genesis - 9|<--]] Genesis - 10 [[Genesis - 11|-->]]

---
# Notes
