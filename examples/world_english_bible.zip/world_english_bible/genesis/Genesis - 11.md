---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 11 - World English Bible"
---
[[Genesis - 10|<--]] Genesis - 11 [[Genesis - 12|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Genesis]]

# Genesis - 11

The whole earth was of one language and of one speech. [^1] As they traveled east,#11:2 LXX reads “from the east”. they found a plain in the land of Shinar, and they lived there. [^2] They said to one another, “Come, let’s make bricks, and burn them thoroughly.” They had brick for stone, and they used tar for mortar. [^3] They said, “Come, let’s build ourselves a city, and a tower whose top reaches to the sky, and let’s make a name for ourselves, lest we be scattered abroad on the surface of the whole earth.” [^4] Yahweh came down to see the city and the tower, which the children of men built. [^5] Yahweh said, “Behold, they are one people, and they all have one language, and this is what they begin to do. Now nothing will be withheld from them, which they intend to do. [^6] Come, let’s go down, and there confuse their language, that they may not understand one another’s speech.” [^7] So Yahweh scattered them abroad from there on the surface of all the earth. They stopped building the city. [^8] Therefore its name was called Babel, because there Yahweh confused the language of all the earth. From there, Yahweh scattered them abroad on the surface of all the earth. [^9] This is the history of the generations of Shem: Shem was one hundred years old when he became the father of Arpachshad two years after the flood. [^10] Shem lived five hundred years after he became the father of Arpachshad, and became the father of more sons and daughters. [^11] Arpachshad lived thirty-five years and became the father of Shelah. [^12] Arpachshad lived four hundred three years after he became the father of Shelah, and became the father of more sons and daughters. [^13] Shelah lived thirty years, and became the father of Eber. [^14] Shelah lived four hundred three years after he became the father of Eber, and became the father of more sons and daughters. [^15] Eber lived thirty-four years, and became the father of Peleg. [^16] Eber lived four hundred thirty years after he became the father of Peleg, and became the father of more sons and daughters. [^17] Peleg lived thirty years, and became the father of Reu. [^18] Peleg lived two hundred nine years after he became the father of Reu, and became the father of more sons and daughters. [^19] Reu lived thirty-two years, and became the father of Serug. [^20] Reu lived two hundred seven years after he became the father of Serug, and became the father of more sons and daughters. [^21] Serug lived thirty years, and became the father of Nahor. [^22] Serug lived two hundred years after he became the father of Nahor, and became the father of more sons and daughters. [^23] Nahor lived twenty-nine years, and became the father of Terah. [^24] Nahor lived one hundred nineteen years after he became the father of Terah, and became the father of more sons and daughters. [^25] Terah lived seventy years, and became the father of Abram, Nahor, and Haran. [^26] Now this is the history of the generations of Terah. Terah became the father of Abram, Nahor, and Haran. Haran became the father of Lot. [^27] Haran died in the land of his birth, in Ur of the Chaldees, while his father Terah was still alive. [^28] Abram and Nahor married wives. The name of Abram’s wife was Sarai, and the name of Nahor’s wife was Milcah, the daughter of Haran, who was also the father of Iscah. [^29] Sarai was barren. She had no child. [^30] Terah took Abram his son, Lot the son of Haran, his son’s son, and Sarai his daughter-in-law, his son Abram’s wife. They went from Ur of the Chaldees, to go into the land of Canaan. They came to Haran and lived there. [^31] The days of Terah were two hundred five years. Terah died in Haran. [^32] 

[[Genesis - 10|<--]] Genesis - 11 [[Genesis - 12|-->]]

---
# Notes
