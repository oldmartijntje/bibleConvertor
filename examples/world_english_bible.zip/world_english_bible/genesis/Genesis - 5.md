---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 5 - World English Bible"
---
[[Genesis - 4|<--]] Genesis - 5 [[Genesis - 6|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Genesis]]

# Genesis - 5

This is the book of the generations of Adam. In the day that God created man, he made him in God’s likeness. [^1] He created them male and female, and blessed them. On the day they were created, he named them Adam.#5:2 “Adam” and “Man” are spelled with the exact same consonants in Hebrew, so this can be correctly translated either way. [^2] Adam lived one hundred thirty years, and became the father of a son in his own likeness, after his image, and named him Seth. [^3] The days of Adam after he became the father of Seth were eight hundred years, and he became the father of other sons and daughters. [^4] All the days that Adam lived were nine hundred thirty years, then he died. [^5] Seth lived one hundred five years, then became the father of Enosh. [^6] Seth lived after he became the father of Enosh eight hundred seven years, and became the father of other sons and daughters. [^7] All of the days of Seth were nine hundred twelve years, then he died. [^8] Enosh lived ninety years, and became the father of Kenan. [^9] Enosh lived after he became the father of Kenan eight hundred fifteen years, and became the father of other sons and daughters. [^10] All of the days of Enosh were nine hundred five years, then he died. [^11] Kenan lived seventy years, then became the father of Mahalalel. [^12] Kenan lived after he became the father of Mahalalel eight hundred forty years, and became the father of other sons and daughters [^13] and all of the days of Kenan were nine hundred ten years, then he died. [^14] Mahalalel lived sixty-five years, then became the father of Jared. [^15] Mahalalel lived after he became the father of Jared eight hundred thirty years, and became the father of other sons and daughters. [^16] All of the days of Mahalalel were eight hundred ninety-five years, then he died. [^17] Jared lived one hundred sixty-two years, then became the father of Enoch. [^18] Jared lived after he became the father of Enoch eight hundred years, and became the father of other sons and daughters. [^19] All of the days of Jared were nine hundred sixty-two years, then he died. [^20] Enoch lived sixty-five years, then became the father of Methuselah. [^21] After Methuselah’s birth, Enoch walked with God for three hundred years, and became the father of more sons and daughters. [^22] All the days of Enoch were three hundred sixty-five years. [^23] Enoch walked with God, and he was not found, for God took him. [^24] Methuselah lived one hundred eighty-seven years, then became the father of Lamech. [^25] Methuselah lived after he became the father of Lamech seven hundred eighty-two years, and became the father of other sons and daughters. [^26] All the days of Methuselah were nine hundred sixty-nine years, then he died. [^27] Lamech lived one hundred eighty-two years, then became the father of a son. [^28] He named him Noah, saying, “This one will comfort us in our work and in the toil of our hands, caused by the ground which Yahweh has cursed.” [^29] Lamech lived after he became the father of Noah five hundred ninety-five years, and became the father of other sons and daughters. [^30] All the days of Lamech were seven hundred seventy-seven years, then he died. [^31] Noah was five hundred years old, then Noah became the father of Shem, Ham, and Japheth. [^32] 

[[Genesis - 4|<--]] Genesis - 5 [[Genesis - 6|-->]]

---
# Notes
