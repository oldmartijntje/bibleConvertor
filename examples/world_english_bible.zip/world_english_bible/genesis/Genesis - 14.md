---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 14 - World English Bible"
---
[[Genesis - 13|<--]] Genesis - 14 [[Genesis - 15|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Genesis]]

# Genesis - 14

In the days of Amraphel, king of Shinar; Arioch, king of Ellasar; Chedorlaomer, king of Elam; and Tidal, king of Goiim, [^1] they made war with Bera, king of Sodom; Birsha, king of Gomorrah; Shinab, king of Admah; Shemeber, king of Zeboiim; and the king of Bela (also called Zoar). [^2] All these joined together in the valley of Siddim (also called the Salt Sea). [^3] They served Chedorlaomer for twelve years, and in the thirteenth year they rebelled. [^4] In the fourteenth year Chedorlaomer and the kings who were with him came and struck the Rephaim in Ashteroth Karnaim, the Zuzim in Ham, the Emim in Shaveh Kiriathaim, [^5] and the Horites in their Mount Seir, to El Paran, which is by the wilderness. [^6] They returned, and came to En Mishpat (also called Kadesh), and struck all the country of the Amalekites, and also the Amorites, that lived in Hazazon Tamar. [^7] The king of Sodom, and the king of Gomorrah, the king of Admah, the king of Zeboiim, and the king of Bela (also called Zoar) went out; and they set the battle in array against them in the valley of Siddim [^8] against Chedorlaomer king of Elam, Tidal king of Goiim, Amraphel king of Shinar, and Arioch king of Ellasar; four kings against the five. [^9] Now the valley of Siddim was full of tar pits; and the kings of Sodom and Gomorrah fled, and some fell there. Those who remained fled to the hills. [^10] They took all the goods of Sodom and Gomorrah, and all their food, and went their way. [^11] They took Lot, Abram’s brother’s son, who lived in Sodom, and his goods, and departed. [^12] One who had escaped came and told Abram, the Hebrew. At that time, he lived by the oaks of Mamre, the Amorite, brother of Eshcol and brother of Aner. They were allies of Abram. [^13] When Abram heard that his relative was taken captive, he led out his three hundred eighteen trained men, born in his house, and pursued as far as Dan. [^14] He divided himself against them by night, he and his servants, and struck them, and pursued them to Hobah, which is on the left hand of Damascus. [^15] He brought back all the goods, and also brought back his relative Lot and his goods, and the women also, and the other people. [^16] The king of Sodom went out to meet him after his return from the slaughter of Chedorlaomer and the kings who were with him, at the valley of Shaveh (that is, the King’s Valley). [^17] Melchizedek king of Salem brought out bread and wine. He was priest of God Most High. [^18] He blessed him, and said, “Blessed be Abram of God Most High, possessor of heaven and earth. [^19] Blessed be God Most High, who has delivered your enemies into your hand.”Abram gave him a tenth of all. [^20] The king of Sodom said to Abram, “Give me the people, and take the goods for yourself.” [^21] Abram said to the king of Sodom, “I have lifted up my hand to Yahweh, God Most High, possessor of heaven and earth, [^22] that I will not take a thread nor a sandal strap nor anything that is yours, lest you should say, ‘I have made Abram rich.’ [^23] I will accept nothing from you except that which the young men have eaten, and the portion of the men who went with me: Aner, Eshcol, and Mamre. Let them take their portion.” [^24] 

[[Genesis - 13|<--]] Genesis - 14 [[Genesis - 15|-->]]

---
# Notes
