---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 9 - World English Bible"
---
[[Genesis - 8|<--]] Genesis - 9 [[Genesis - 10|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Genesis]]

# Genesis - 9

God blessed Noah and his sons, and said to them, “Be fruitful, multiply, and replenish the earth. [^1] The fear of you and the dread of you will be on every animal of the earth, and on every bird of the sky. Everything that moves along the ground, and all the fish of the sea, are delivered into your hand. [^2] Every moving thing that lives will be food for you. As I gave you the green herb, I have given everything to you. [^3] But flesh with its life, that is, its blood, you shall not eat. [^4] I will surely require accounting for your life’s blood. At the hand of every animal I will require it. At the hand of man, even at the hand of every man’s brother, I will require the life of man. [^5] Whoever sheds man’s blood, his blood will be shed by man, for God made man in his own image. [^6] Be fruitful and multiply. Increase abundantly in the earth, and multiply in it.” [^7] God spoke to Noah and to his sons with him, saying, [^8] “As for me, behold, I establish my covenant with you, and with your offspring after you, [^9] and with every living creature that is with you: the birds, the livestock, and every animal of the earth with you, of all that go out of the ship, even every animal of the earth. [^10] I will establish my covenant with you: All flesh will not be cut off any more by the waters of the flood. There will never again be a flood to destroy the earth.” [^11] God said, “This is the token of the covenant which I make between me and you and every living creature that is with you, for perpetual generations: [^12] I set my rainbow in the cloud, and it will be a sign of a covenant between me and the earth. [^13] When I bring a cloud over the earth, that the rainbow will be seen in the cloud, [^14] I will remember my covenant, which is between me and you and every living creature of all flesh, and the waters will no more become a flood to destroy all flesh. [^15] The rainbow will be in the cloud. I will look at it, that I may remember the everlasting covenant between God and every living creature of all flesh that is on the earth.” [^16] God said to Noah, “This is the token of the covenant which I have established between me and all flesh that is on the earth.” [^17] The sons of Noah who went out from the ship were Shem, Ham, and Japheth. Ham is the father of Canaan. [^18] These three were the sons of Noah, and from these the whole earth was populated. [^19] Noah began to be a farmer, and planted a vineyard. [^20] He drank of the wine and got drunk. He was uncovered within his tent. [^21] Ham, the father of Canaan, saw the nakedness of his father, and told his two brothers outside. [^22] Shem and Japheth took a garment, and laid it on both their shoulders, went in backwards, and covered the nakedness of their father. Their faces were backwards, and they didn’t see their father’s nakedness. [^23] Noah awoke from his wine, and knew what his youngest son had done to him. [^24] He said,“Canaan is cursed.He will be a servant of servants to his brothers.” [^25] He said,“Blessed be Yahweh, the God of Shem.Let Canaan be his servant. [^26] May God enlarge Japheth.Let him dwell in the tents of Shem.Let Canaan be his servant.” [^27] Noah lived three hundred fifty years after the flood. [^28] All the days of Noah were nine hundred fifty years, and then he died. [^29] 

[[Genesis - 8|<--]] Genesis - 9 [[Genesis - 10|-->]]

---
# Notes
