---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 45 - World English Bible"
---
[[Genesis - 44|<--]] Genesis - 45 [[Genesis - 46|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Genesis]]

# Genesis - 45

Then Joseph couldn’t control himself before all those who stood before him, and he called out, “Cause everyone to go out from me!” No one else stood with him, while Joseph made himself known to his brothers. [^1] He wept aloud. The Egyptians heard, and the house of Pharaoh heard. [^2] Joseph said to his brothers, “I am Joseph! Does my father still live?”His brothers couldn’t answer him; for they were terrified at his presence. [^3] Joseph said to his brothers, “Come near to me, please.”They came near. He said, “I am Joseph, your brother, whom you sold into Egypt. [^4] Now don’t be grieved, nor angry with yourselves, that you sold me here, for God sent me before you to preserve life. [^5] For these two years the famine has been in the land, and there are yet five years, in which there will be no plowing and no harvest. [^6] God sent me before you to preserve for you a remnant in the earth, and to save you alive by a great deliverance. [^7] So now it wasn’t you who sent me here, but God, and he has made me a father to Pharaoh, lord of all his house, and ruler over all the land of Egypt. [^8] Hurry, and go up to my father, and tell him, ‘This is what your son Joseph says, “God has made me lord of all Egypt. Come down to me. Don’t wait. [^9] You shall dwell in the land of Goshen, and you will be near to me, you, your children, your children’s children, your flocks, your herds, and all that you have. [^10] There I will provide for you; for there are yet five years of famine; lest you come to poverty, you, and your household, and all that you have.”’ [^11] Behold, your eyes see, and the eyes of my brother Benjamin, that it is my mouth that speaks to you. [^12] You shall tell my father of all my glory in Egypt, and of all that you have seen. You shall hurry and bring my father down here.” [^13] He fell on his brother Benjamin’s neck and wept, and Benjamin wept on his neck. [^14] He kissed all his brothers, and wept on them. After that his brothers talked with him. [^15] The report of it was heard in Pharaoh’s house, saying, “Joseph’s brothers have come.” It pleased Pharaoh well, and his servants. [^16] Pharaoh said to Joseph, “Tell your brothers, ‘Do this: Load your animals, and go, travel to the land of Canaan. [^17] Take your father and your households, and come to me, and I will give you the good of the land of Egypt, and you will eat the fat of the land.’ [^18] Now you are commanded to do this: Take wagons out of the land of Egypt for your little ones, and for your wives, and bring your father, and come. [^19] Also, don’t concern yourselves about your belongings, for the good of all the land of Egypt is yours.” [^20] The sons of Israel did so. Joseph gave them wagons, according to the commandment of Pharaoh, and gave them provision for the way. [^21] He gave each one of them changes of clothing, but to Benjamin he gave three hundred pieces of silver and five changes of clothing. [^22] He sent the following to his father: ten donkeys loaded with the good things of Egypt, and ten female donkeys loaded with grain and bread and provision for his father by the way. [^23] So he sent his brothers away, and they departed. He said to them, “See that you don’t quarrel on the way.” [^24] They went up out of Egypt, and came into the land of Canaan, to Jacob their father. [^25] They told him, saying, “Joseph is still alive, and he is ruler over all the land of Egypt.” His heart fainted, for he didn’t believe them. [^26] They told him all the words of Joseph, which he had said to them. When he saw the wagons which Joseph had sent to carry him, the spirit of Jacob, their father, revived. [^27] Israel said, “It is enough. Joseph my son is still alive. I will go and see him before I die.” [^28] 

[[Genesis - 44|<--]] Genesis - 45 [[Genesis - 46|-->]]

---
# Notes
