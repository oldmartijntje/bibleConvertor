---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 4 - World English Bible"
---
[[Genesis - 3|<--]] Genesis - 4 [[Genesis - 5|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Genesis]]

# Genesis - 4

The man knew#4:1 or, lay with, or, had relations with Eve his wife. She conceived,#4:1 or, became pregnant and gave birth to Cain, and said, “I have gotten a man with Yahweh’s help.” [^1] Again she gave birth, to Cain’s brother Abel. Abel was a keeper of sheep, but Cain was a tiller of the ground. [^2] As time passed, Cain brought an offering to Yahweh from the fruit of the ground. [^3] Abel also brought some of the firstborn of his flock and of its fat. Yahweh respected Abel and his offering, [^4] but he didn’t respect Cain and his offering. Cain was very angry, and the expression on his face fell. [^5] Yahweh said to Cain, “Why are you angry? Why has the expression of your face fallen? [^6] If you do well, won’t it be lifted up? If you don’t do well, sin crouches at the door. Its desire is for you, but you are to rule over it.” [^7] Cain said to Abel, his brother, “Let’s go into the field.” While they were in the field, Cain rose up against Abel, his brother, and killed him. [^8] Yahweh said to Cain, “Where is Abel, your brother?”He said, “I don’t know. Am I my brother’s keeper?” [^9] Yahweh said, “What have you done? The voice of your brother’s blood cries to me from the ground. [^10] Now you are cursed because of the ground, which has opened its mouth to receive your brother’s blood from your hand. [^11] From now on, when you till the ground, it won’t yield its strength to you. You will be a fugitive and a wanderer in the earth.” [^12] Cain said to Yahweh, “My punishment is greater than I can bear. [^13] Behold, you have driven me out today from the surface of the ground. I will be hidden from your face, and I will be a fugitive and a wanderer in the earth. Whoever finds me will kill me.” [^14] Yahweh said to him, “Therefore whoever slays Cain, vengeance will be taken on him sevenfold.” Yahweh appointed a sign for Cain, so that anyone finding him would not strike him. [^15] Cain left Yahweh’s presence, and lived in the land of Nod, east of Eden. [^16] Cain knew his wife. She conceived, and gave birth to Enoch. He built a city, and named the city after the name of his son, Enoch. [^17] Irad was born to Enoch. Irad became the father of Mehujael. Mehujael became the father of Methushael. Methushael became the father of Lamech. [^18] Lamech took two wives: the name of the first one was Adah, and the name of the second one was Zillah. [^19] Adah gave birth to Jabal, who was the father of those who dwell in tents and have livestock. [^20] His brother’s name was Jubal, who was the father of all who handle the harp and pipe. [^21] Zillah also gave birth to Tubal Cain, the forger of every cutting instrument of bronze and iron. Tubal Cain’s sister was Naamah. [^22] Lamech said to his wives,“Adah and Zillah, hear my voice.You wives of Lamech, listen to my speech,for I have slain a man for wounding me,a young man for bruising me. [^23] If Cain will be avenged seven times,truly Lamech seventy-seven times.” [^24] Adam knew his wife again. She gave birth to a son, and named him Seth, saying, “for God has given me another child instead of Abel, for Cain killed him.” [^25] A son was also born to Seth, and he named him Enosh. At that time men began to call on Yahweh’s name. [^26] 

[[Genesis - 3|<--]] Genesis - 4 [[Genesis - 5|-->]]

---
# Notes
