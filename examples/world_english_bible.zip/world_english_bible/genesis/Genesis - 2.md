---
translation: World English Bible
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 2 - World English Bible"
---
[[Genesis - 1|<--]] Genesis - 2 [[Genesis - 3|-->]]

Translation: [[bible - World English Bible|World English Bible]]
Book: [[Genesis]]

# Genesis - 2

The heavens, the earth, and all their vast array were finished. [^1] On the seventh day God finished his work which he had done; and he rested on the seventh day from all his work which he had done. [^2] God blessed the seventh day, and made it holy, because he rested in it from all his work of creation which he had done. [^3] This is the history of the generations of the heavens and of the earth when they were created, in the day that Yahweh#2:4 “Yahweh” is God’s proper Name, sometimes rendered “Lord” (all caps) in other translations. God made the earth and the heavens. [^4] No plant of the field was yet in the earth, and no herb of the field had yet sprung up; for Yahweh God had not caused it to rain on the earth. There was not a man to till the ground, [^5] but a mist went up from the earth, and watered the whole surface of the ground. [^6] Yahweh God formed man from the dust of the ground, and breathed into his nostrils the breath of life; and man became a living soul. [^7] Yahweh God planted a garden eastward, in Eden, and there he put the man whom he had formed. [^8] Out of the ground Yahweh God made every tree to grow that is pleasant to the sight, and good for food, including the tree of life in the middle of the garden and the tree of the knowledge of good and evil. [^9] A river went out of Eden to water the garden; and from there it was parted, and became the source of four rivers. [^10] The name of the first is Pishon: it flows through the whole land of Havilah, where there is gold; [^11] and the gold of that land is good. Bdellium#2:12 or, aromatic resin and onyx stone are also there. [^12] The name of the second river is Gihon. It is the same river that flows through the whole land of Cush. [^13] The name of the third river is Hiddekel. This is the one which flows in front of Assyria. The fourth river is the Euphrates. [^14] Yahweh God took the man, and put him into the garden of Eden to cultivate and keep it. [^15] Yahweh God commanded the man, saying, “You may freely eat of every tree of the garden; [^16] but you shall not eat of the tree of the knowledge of good and evil; for in the day that you eat of it, you will surely die.” [^17] Yahweh God said, “It is not good for the man to be alone. I will make him a helper comparable to#2:18 or, suitable for, or appropriate for. him.” [^18] Out of the ground Yahweh God formed every animal of the field, and every bird of the sky, and brought them to the man to see what he would call them. Whatever the man called every living creature became its name. [^19] The man gave names to all livestock, and to the birds of the sky, and to every animal of the field; but for man there was not found a helper comparable to him. [^20] Yahweh God caused the man to fall into a deep sleep. As the man slept, he took one of his ribs, and closed up the flesh in its place. [^21] Yahweh God made a woman from the rib which he had taken from the man, and brought her to the man. [^22] The man said, “This is now bone of my bones, and flesh of my flesh. She will be called ‘woman,’ because she was taken out of Man.” [^23] Therefore a man will leave his father and his mother, and will join with his wife, and they will be one flesh. [^24] The man and his wife were both naked, and they were not ashamed. [^25] 

[[Genesis - 1|<--]] Genesis - 2 [[Genesis - 3|-->]]

---
# Notes
