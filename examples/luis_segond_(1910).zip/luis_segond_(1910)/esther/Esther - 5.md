---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 5 - Luis Segond (1910)"
---
[[Esther - 4|<--]] Esther - 5 [[Esther - 6|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Esther]]

# Esther - 5

Le troisième jour, Esther mit ses vêtements royaux et se présenta dans la cour intérieure de la maison du roi, devant la maison du roi. Le roi était assis sur son trône royal dans la maison royale, en face de l’entrée de la maison. [^1] Lorsque le roi vit la reine Esther debout dans la cour, elle trouva grâce à ses yeux; et le roi tendit à Esther le sceptre d’or qu’il tenait à la main. Esther s’approcha, et toucha le bout du sceptre. [^2] Le roi lui dit: Qu’as-tu, reine Esther, et que demandes-tu? Quand ce serait la moitié du royaume, elle te serait donnée. [^3] Esther répondit: Si le roi le trouve bon, que le roi vienne aujourd’hui avec Haman au festin que je lui ai préparé. [^4] Et le roi dit: Allez tout de suite chercher Haman, comme le désire Esther. Le roi se rendit avec Haman au festin qu’avait préparé Esther. [^5] Et pendant qu’on buvait le vin, le roi dit à Esther: Quelle est ta demande? Elle te sera accordée. Que désires-tu? Quand ce serait la moitié du royaume, tu l’obtiendras. [^6] Esther répondit: Voici ce que je demande et ce que je désire. [^7] Si j’ai trouvé grâce aux yeux du roi, et s’il plaît au roi d’accorder ma demande et de satisfaire mon désir, que le roi vienne avec Haman au festin que je leur préparerai, et demain je donnerai réponse au roi selon son ordre. [^8] Haman sortit ce jour-là, joyeux et le cœur content. Mais lorsqu’il vit, à la porte du roi, Mardochée qui ne se levait ni ne se remuait devant lui, il fut rempli de colère contre Mardochée. [^9] Il sut néanmoins se contenir, et il alla chez lui. Puis il envoya chercher ses amis et Zéresch, sa femme. [^10] Haman leur parla de la magnificence de ses richesses, du nombre de ses fils, de tout ce qu’avait fait le roi pour l’élever en dignité, et du rang qu’il lui avait donné au-dessus des chefs et des serviteurs du roi. [^11] Et il ajouta: Je suis même le seul que la reine Esther ait admis avec le roi au festin qu’elle a fait, et je suis encore invité pour demain chez elle avec le roi. [^12] Mais tout cela n’est d’aucun prix pour moi aussi longtemps que je verrai Mardochée, le Juif, assis à la porte du roi. [^13] Zéresch, sa femme, et tous ses amis lui dirent: Qu’on prépare un bois haut de cinquante coudées, et demain matin demande au roi qu’on y pende Mardochée; puis tu iras joyeux au festin avec le roi. Cet avis plut à Haman, et il fit préparer le bois. [^14] 

[[Esther - 4|<--]] Esther - 5 [[Esther - 6|-->]]

---
# Notes
