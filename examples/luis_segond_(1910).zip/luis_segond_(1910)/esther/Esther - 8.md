---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 8 - Luis Segond (1910)"
---
[[Esther - 7|<--]] Esther - 8 [[Esther - 9|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Esther]]

# Esther - 8

En ce même jour, le roi Assuérus donna à la reine Esther la maison d’Haman, l’ennemi des Juifs; et Mardochée parut devant le roi, car Esther avait fait connaître la parenté qui l’unissait à elle. [^1] Le roi ôta son anneau, qu’il avait repris à Haman, et le donna à Mardochée; Esther, de son côté, établit Mardochée sur la maison d’Haman. [^2] Puis Esther parla de nouveau en présence du roi. Elle se jeta à ses pieds, elle pleura, elle le supplia d’empêcher les effets de la méchanceté d’Haman, l’Agaguite, et la réussite de ses projets contre les Juifs. [^3] Le roi tendit le sceptre d’or à Esther, qui se releva et resta debout devant le roi. [^4] Elle dit alors: Si le roi le trouve bon et si j’ai trouvé grâce devant lui, si la chose paraît convenable au roi et si je suis agréable à ses yeux, qu’on écrive pour révoquer les lettres conçues par Haman, fils d’Hammedatha, l’Agaguite, et écrites par lui dans le but de faire périr les Juifs qui sont dans toutes les provinces du roi. [^5] Car comment pourrais-je voir le malheur qui atteindrait mon peuple, et comment pourrais-je voir la destruction de ma race? [^6] Le roi Assuérus dit à la reine Esther et au Juif Mardochée: Voici, j’ai donné à Esther la maison d’Haman, et il a été pendu au bois pour avoir étendu la main contre les Juifs. [^7] Écrivez donc en faveur des Juifs comme il vous plaira, au nom du roi, et scellez avec l’anneau du roi; car une lettre écrite au nom du roi et scellée avec l’anneau du roi ne peut être révoquée. [^8] Les secrétaires du roi furent appelés en ce temps, le vingt-troisième jour du troisième mois, qui est le mois de Sivan, et l’on écrivit, suivant tout ce qui fut ordonné par Mardochée, aux Juifs, aux satrapes, aux gouverneurs et aux chefs des cent vingt-sept provinces situées de l’Inde à l’Éthiopie, à chaque province selon son écriture, à chaque peuple selon sa langue, et aux Juifs selon leur écriture et selon leur langue. [^9] On écrivit au nom du roi Assuérus, et l’on scella avec l’anneau du roi. On envoya les lettres par des courriers ayant pour montures des chevaux et des mulets nés de juments. [^10] Par ces lettres, le roi donnait aux Juifs, en quelque ville qu’ils fussent, la permission de se rassembler et de défendre leur vie, de détruire, de tuer et de faire périr, avec leurs petits enfants et leurs femmes, tous ceux de chaque peuple et de chaque province qui prendraient les armes pour les attaquer, et de livrer leurs biens au pillage, [^11] et cela en un seul jour, dans toutes les provinces du roi Assuérus, le treizième du douzième mois, qui est le mois d’Adar. [^12] Ces lettres renfermaient une copie de l’édit qui devait être publié dans chaque province, et informaient tous les peuples que les Juifs se tiendraient prêts pour ce jour-là à se venger de leurs ennemis. [^13] Les courriers, montés sur des chevaux et des mulets, partirent aussitôt et en toute hâte, d’après l’ordre du roi. L’édit fut aussi publié dans Suse, la capitale. [^14] Mardochée sortit de chez le roi, avec un vêtement royal bleu et blanc, une grande couronne d’or, et un manteau de byssus et de pourpre. La ville de Suse poussait des cris et se réjouissait. [^15] Il n’y avait pour les Juifs que bonheur et joie, allégresse et gloire. [^16] Dans chaque province et dans chaque ville, partout où arrivaient l’ordre du roi et son édit, il y eut parmi les Juifs de la joie et de l’allégresse, des festins et des fêtes. Et beaucoup de gens d’entre les peuples du pays se firent Juifs, car la crainte des Juifs les avait saisis. [^17] 

[[Esther - 7|<--]] Esther - 8 [[Esther - 9|-->]]

---
# Notes
