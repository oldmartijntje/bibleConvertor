---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 3 - Luis Segond (1910)"
---
[[Esther - 2|<--]] Esther - 3 [[Esther - 4|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Esther]]

# Esther - 3

Après ces choses, le roi Assuérus fit monter au pouvoir Haman, fils d’Hammedatha, l’Agaguite; il l’éleva en dignité et plaça son siège au-dessus de ceux de tous les chefs qui étaient auprès de lui. [^1] Tous les serviteurs du roi, qui se tenaient à la porte du roi, fléchissaient le genou et se prosternaient devant Haman, car tel était l’ordre du roi à son égard. Mais Mardochée ne fléchissait point le genou et ne se prosternait point. [^2] Et les serviteurs du roi, qui se tenaient à la porte du roi, dirent à Mardochée: Pourquoi transgresses-tu l’ordre du roi? [^3] Comme ils le lui répétaient chaque jour et qu’il ne les écoutait pas, ils en firent rapport à Haman, pour voir si Mardochée persisterait dans sa résolution; car il leur avait dit qu’il était Juif. [^4] Et Haman vit que Mardochée ne fléchissait point le genou et ne se prosternait point devant lui. Il fut rempli de fureur; [^5] mais il dédaigna de porter la main sur Mardochée seul, car on lui avait dit de quel peuple était Mardochée, et il voulut détruire le peuple de Mardochée, tous les Juifs qui se trouvaient dans tout le royaume d’Assuérus. [^6] Au premier mois, qui est le mois de Nisan, la douzième année du roi Assuérus, on jeta le pur, c’est-à-dire le sort, devant Haman, pour chaque jour et pour chaque mois, jusqu’au douzième mois, qui est le mois d’Adar. [^7] Alors Haman dit au roi Assuérus: Il y a dans toutes les provinces de ton royaume un peuple dispersé et à part parmi les peuples, ayant des lois différentes de celles de tous les peuples et n’observant point les lois du roi. Il n’est pas dans l’intérêt du roi de le laisser en repos. [^8] Si le roi le trouve bon, qu’on écrive l’ordre de les faire périr; et je pèserai dix mille talents d’argent entre les mains des fonctionnaires, pour qu’on les porte dans le trésor du roi. [^9] Le roi ôta son anneau de la main, et le remit à Haman, fils d’Hammedatha, l’Agaguite, ennemi des Juifs. [^10] Et le roi dit à Haman: L’argent t’est donné, et ce peuple aussi; fais-en ce que tu voudras. [^11] Les secrétaires du roi furent appelés le treizième jour du premier mois, et l’on écrivit, suivant tout ce qui fut ordonné par Haman, aux satrapes du roi, aux gouverneurs de chaque province et aux chefs de chaque peuple, à chaque province selon son écriture et à chaque peuple selon sa langue. Ce fut au nom du roi Assuérus que l’on écrivit, et on scella avec l’anneau du roi. [^12] Les lettres furent envoyées par les courriers dans toutes les provinces du roi, pour qu’on détruisît, qu’on tuât et qu’on fît périr tous les Juifs, jeunes et vieux, petits enfants et femmes, en un seul jour, le treizième du douzième mois, qui est le mois d’Adar, et pour que leurs biens fussent livrés au pillage. [^13] Ces lettres renfermaient une copie de l’édit qui devait être publié dans chaque province, et invitaient tous les peuples à se tenir prêts pour ce jour-là. [^14] Les courriers partirent en toute hâte, d’après l’ordre du roi. L’édit fut aussi publié dans Suse, la capitale; et tandis que le roi et Haman étaient à boire, la ville de Suse était dans la consternation. [^15] 

[[Esther - 2|<--]] Esther - 3 [[Esther - 4|-->]]

---
# Notes
