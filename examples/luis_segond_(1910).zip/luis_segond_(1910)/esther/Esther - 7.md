---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 7 - Luis Segond (1910)"
---
[[Esther - 6|<--]] Esther - 7 [[Esther - 8|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Esther]]

# Esther - 7

Le roi et Haman allèrent au festin chez la reine Esther. [^1] Ce second jour, le roi dit encore à Esther, pendant qu’on buvait le vin: Quelle est ta demande, reine Esther? Elle te sera accordée. Que désires-tu? Quand ce serait la moitié du royaume, tu l’obtiendras. [^2] La reine Esther répondit: Si j’ai trouvé grâce à tes yeux, ô roi, et si le roi le trouve bon, accorde-moi la vie, voilà ma demande, et sauve mon peuple, voilà mon désir! [^3] Car nous sommes vendus, moi et mon peuple, pour être détruits, égorgés, anéantis. Encore si nous étions vendus pour devenir esclaves et servantes, je me tairais, mais l’ennemi ne saurait compenser le dommage fait au roi. [^4] Le roi Assuérus prit la parole et dit à la reine Esther: Qui est-il et où est-il celui qui se propose d’agir ainsi? [^5] Esther répondit: L’oppresseur, l’ennemi, c’est Haman, ce méchant-là! Haman fut saisi de terreur en présence du roi et de la reine. [^6] Et le roi, dans sa colère, se leva et quitta le festin, pour aller dans le jardin du palais. Haman resta pour demander grâce de la vie à la reine Esther, car il voyait bien que sa perte était arrêtée dans l’esprit du roi. [^7] Lorsque le roi revint du jardin du palais dans la salle du festin, il vit Haman qui s’était précipité vers le lit sur lequel était Esther, et il dit: Serait-ce encore pour faire violence à la reine, chez moi, dans le palais? Dès que cette parole fut sortie de la bouche du roi, on voila le visage d’Haman. [^8] Et Harbona, l’un des eunuques, dit en présence du roi: Voici, le bois préparé par Haman pour Mardochée, qui a parlé pour le bien du roi, est dressé dans la maison d’Haman, à une hauteur de cinquante coudées. Le roi dit: Qu’on y pende Haman! [^9] Et l’on pendit Haman au bois qu’il avait préparé pour Mardochée. Et la colère du roi s’apaisa. [^10] 

[[Esther - 6|<--]] Esther - 7 [[Esther - 8|-->]]

---
# Notes
