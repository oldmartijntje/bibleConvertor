---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 1 - Luis Segond (1910)"
---
Esther - 1 [[Esther - 2|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Esther]]

# Esther - 1

C’était du temps d’Assuérus, de cet Assuérus qui régnait depuis l’Inde jusqu’en Éthiopie sur cent vingt-sept provinces; [^1] et le roi Assuérus était alors assis sur son trône royal à Suse, dans la capitale. [^2] La troisième année de son règne, il fit un festin à tous ses princes et à ses serviteurs; les commandants de l’armée des Perses et des Mèdes, les grands et les chefs des provinces furent réunis en sa présence. [^3] Il montra la splendide richesse de son royaume et l’éclatante magnificence de sa grandeur pendant nombre de jours, pendant cent quatre-vingts jours. [^4] Lorsque ces jours furent écoulés, le roi fit pour tout le peuple qui se trouvait à Suse, la capitale, depuis le plus grand jusqu’au plus petit, un festin qui dura sept jours, dans la cour du jardin de la maison royale. [^5] Des tentures blanches, vertes et bleues, étaient attachées par des cordons de byssus et de pourpre à des anneaux d’argent et à des colonnes de marbre. Des lits d’or et d’argent reposaient sur un pavé de porphyre, de marbre, de nacre et de pierres noires. [^6] On servait à boire dans des vases d’or, de différentes espèces, et il y avait abondance de vin royal, grâce à la libéralité du roi. [^7] Mais on ne forçait personne à boire, car le roi avait ordonné à tous les gens de sa maison de se conformer à la volonté de chacun. [^8] La reine Vasthi fit aussi un festin pour les femmes dans la maison royale du roi Assuérus. [^9] Le septième jour, comme le cœur du roi était réjoui par le vin, il ordonna à Mehuman, Biztha, Harbona, Bigtha, Abagtha, Zéthar et Carcas, les sept eunuques qui servaient devant le roi Assuérus, [^10] d’amener en sa présence la reine Vasthi, avec la couronne royale, pour montrer sa beauté aux peuples et aux grands, car elle était belle de figure. [^11] Mais la reine Vasthi refusa de venir, quand elle reçut par les eunuques l’ordre du roi. Et le roi fut très irrité, il fut enflammé de colère. [^12] Alors le roi s’adressa aux sages qui avaient la connaissance des temps. Car ainsi se traitaient les affaires du roi, devant tous ceux qui connaissaient les lois et le droit. [^13] Il avait auprès de lui Carschena, Schéthar, Admatha, Tarsis, Mérès, Marsena, Memucan, sept princes de Perse et de Médie, qui voyaient la face du roi et qui occupaient le premier rang dans le royaume. [^14] Quelle loi, dit-il, faut-il appliquer à la reine Vasthi, pour n’avoir point exécuté ce que le roi Assuérus lui a ordonné par les eunuques? [^15] Memucan répondit devant le roi et les princes: Ce n’est pas seulement à l’égard du roi que la reine Vasthi a mal agi; c’est aussi envers tous les princes et tous les peuples qui sont dans toutes les provinces du roi Assuérus. [^16] Car l’action de la reine parviendra à la connaissance de toutes les femmes, et les portera à mépriser leurs maris; elles diront: Le roi Assuérus avait ordonné qu’on amenât en sa présence la reine Vasthi, et elle n’y est pas allée. [^17] Et dès ce jour les princesses de Perse et de Médie qui auront appris l’action de la reine la rapporteront à tous les chefs du roi; de là beaucoup de mépris et de colère. [^18] Si le roi le trouve bon, qu’on publie de sa part et qu’on inscrive parmi les lois des Perses et des Mèdes, avec défense de la transgresser, une ordonnance royale d’après laquelle Vasthi ne paraîtra plus devant le roi Assuérus et le roi donnera la dignité de reine à une autre qui soit meilleure qu’elle. [^19] L’édit du roi sera connu dans tout son royaume, quelque grand qu’il soit, et toutes les femmes rendront honneur à leurs maris, depuis le plus grand jusqu’au plus petit. [^20] Cet avis fut approuvé du roi et des princes, et le roi agit d’après la parole de Memucan. [^21] Il envoya des lettres à toutes les provinces du royaume, à chaque province selon son écriture et à chaque peuple selon sa langue; elles portaient que tout homme devait être le maître dans sa maison, et qu’il parlerait la langue de son peuple. [^22] 

Esther - 1 [[Esther - 2|-->]]

---
# Notes
