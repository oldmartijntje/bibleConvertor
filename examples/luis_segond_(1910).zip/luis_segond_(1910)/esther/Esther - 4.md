---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 4 - Luis Segond (1910)"
---
[[Esther - 3|<--]] Esther - 4 [[Esther - 5|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Esther]]

# Esther - 4

Mardochée, ayant appris tout ce qui se passait, déchira ses vêtements, s’enveloppa d’un sac et se couvrit de cendre. Puis il alla au milieu de la ville en poussant avec force des cris amers, [^1] et se rendit jusqu’à la porte du roi, dont l’entrée était interdite à toute personne revêtue d’un sac. [^2] Dans chaque province, partout où arrivaient l’ordre du roi et son édit, il y eut une grande désolation parmi les Juifs; ils jeûnaient, pleuraient et se lamentaient, et beaucoup se couchaient sur le sac et la cendre. [^3] Les servantes d’Esther et ses eunuques vinrent lui annoncer cela, et la reine fut très effrayée. Elle envoya des vêtements à Mardochée pour le couvrir et lui faire ôter son sac, mais il ne les accepta pas. [^4] Alors Esther appela Hathac, l’un des eunuques que le roi avait placés auprès d’elle, et elle le chargea d’aller demander à Mardochée ce que c’était et d’où cela venait. [^5] Hathac se rendit vers Mardochée sur la place de la ville, devant la porte du roi. [^6] Et Mardochée lui raconta tout ce qui lui était arrivé, et lui indiqua la somme d’argent qu’Haman avait promis de livrer au trésor du roi en retour du massacre des Juifs. [^7] Il lui donna aussi une copie de l’édit publié dans Suse en vue de leur destruction, afin qu’il le montrât à Esther et lui fît tout connaître; et il ordonna qu’Esther se rendît chez le roi pour lui demander grâce et l’implorer en faveur de son peuple. [^8] Hathac vint rapporter à Esther les paroles de Mardochée. [^9] Esther chargea Hathac d’aller dire à Mardochée: [^10] Tous les serviteurs du roi et le peuple des provinces du roi savent qu’il existe une loi portant peine de mort contre quiconque, homme ou femme, entre chez le roi, dans la cour intérieure, sans avoir été appelé; celui-là seul a la vie sauve, à qui le roi tend le sceptre d’or. Et moi, je n’ai point été appelée auprès du roi depuis trente jours. [^11] Lorsque les paroles d’Esther eurent été rapportées à Mardochée, [^12] Mardochée fit répondre à Esther: Ne t’imagine pas que tu échapperas seule d’entre tous les Juifs, parce que tu es dans la maison du roi; [^13] car, si tu te tais maintenant, le secours et la délivrance surgiront d’autre part pour les Juifs, et toi et la maison de ton père vous périrez. Et qui sait si ce n’est pas pour un temps comme celui-ci que tu es parvenue à la royauté? [^14] Esther envoya dire à Mardochée: [^15] Va, rassemble tous les Juifs qui se trouvent à Suse, et jeûnez pour moi, sans manger ni boire pendant trois jours, ni la nuit ni le jour. Moi aussi, je jeûnerai de même avec mes servantes, puis j’entrerai chez le roi, malgré la loi; et si je dois périr, je périrai. [^16] Mardochée s’en alla, et fit tout ce qu’Esther lui avait ordonné. [^17] 

[[Esther - 3|<--]] Esther - 4 [[Esther - 5|-->]]

---
# Notes
