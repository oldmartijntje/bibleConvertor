---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 6 - Luis Segond (1910)"
---
[[Esther - 5|<--]] Esther - 6 [[Esther - 7|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Esther]]

# Esther - 6

Cette nuit-là, le roi ne put pas dormir, et il se fit apporter le livre des annales, les Chroniques. On les lut devant le roi, [^1] et l’on trouva écrit ce que Mardochée avait révélé au sujet de Bigthan et de Théresch, les deux eunuques du roi, gardes du seuil, qui avaient voulu porter la main sur le roi Assuérus. [^2] Le roi dit: Quelle marque de distinction et d’honneur Mardochée a-t-il reçue pour cela? Il n’a rien reçu, répondirent ceux qui servaient le roi. [^3] Alors le roi dit: Qui est dans la cour? Haman était venu dans la cour extérieure de la maison du roi, pour demander au roi de faire pendre Mardochée au bois qu’il avait préparé pour lui. [^4] Les serviteurs du roi lui répondirent: C’est Haman qui se tient dans la cour. Et le roi dit: Qu’il entre. [^5] Haman entra, et le roi lui dit: Que faut-il faire pour un homme que le roi veut honorer? Haman se dit en lui-même: Quel autre que moi le roi voudrait-il honorer? [^6] Et Haman répondit au roi: Pour un homme que le roi veut honorer, [^7] il faut prendre le vêtement royal dont le roi se couvre et le cheval que le roi monte et sur la tête duquel se pose une couronne royale, [^8] remettre le vêtement et le cheval à l’un des principaux chefs du roi, puis revêtir l’homme que le roi veut honorer, le promener à cheval à travers la place de la ville, et crier devant lui: C’est ainsi que l’on fait à l’homme que le roi veut honorer! [^9] Le roi dit à Haman: Prends tout de suite le vêtement et le cheval, comme tu l’as dit, et fais ainsi pour Mardochée, le Juif, qui est assis à la porte du roi; ne néglige rien de tout ce que tu as mentionné. [^10] Et Haman prit le vêtement et le cheval, il revêtit Mardochée, il le promena à cheval à travers la place de la ville, et il cria devant lui: C’est ainsi que l’on fait à l’homme que le roi veut honorer! [^11] Mardochée retourna à la porte du roi, et Haman se rendit en hâte chez lui, désolé et la tête voilée. [^12] Haman raconta à Zéresch, sa femme, et à tous ses amis, tout ce qui lui était arrivé. Et ses sages, et Zéresch, sa femme, lui dirent: Si Mardochée, devant lequel tu as commencé de tomber, est de la race des Juifs, tu ne pourras rien contre lui, mais tu tomberas devant lui. [^13] Comme ils lui parlaient encore, les eunuques du roi arrivèrent et conduisirent aussitôt Haman au festin qu’Esther avait préparé. [^14] 

[[Esther - 5|<--]] Esther - 6 [[Esther - 7|-->]]

---
# Notes
