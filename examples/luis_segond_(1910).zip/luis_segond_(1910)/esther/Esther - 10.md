---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 10 - Luis Segond (1910)"
---
[[Esther - 9|<--]] Esther - 10

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Esther]]

# Esther - 10

Le roi Assuérus imposa un tribut au pays et aux îles de la mer. [^1] Tous les faits concernant sa puissance et ses exploits, et les détails sur la grandeur à laquelle le roi éleva Mardochée, ne sont-ils pas écrits dans le livre des Chroniques des rois des Mèdes et des Perses? [^2] Car le Juif Mardochée était le premier après le roi Assuérus; considéré parmi les Juifs et aimé de la multitude de ses frères, il rechercha le bien de son peuple et parla pour le bonheur de toute sa race. [^3] 

[[Esther - 9|<--]] Esther - 10

---
# Notes
