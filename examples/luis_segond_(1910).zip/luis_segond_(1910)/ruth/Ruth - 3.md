---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/ruth"
  - "#bible/testament/old"
aliases:
  - "Ruth - 3 - Luis Segond (1910)"
---
[[Ruth - 2|<--]] Ruth - 3 [[Ruth - 4|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Ruth]]

# Ruth - 3

Naomi, sa belle-mère, lui dit: Ma fille, je voudrais assurer ton repos, afin que tu fusses heureuse. [^1] Et maintenant Boaz, avec les servantes duquel tu as été, n’est-il pas notre parent? Voici, il doit vanner cette nuit les orges qui sont dans l’aire. [^2] Lave-toi et oins-toi, puis remets tes habits, et descends à l’aire. Tu ne te feras pas connaître à lui, jusqu’à ce qu’il ait achevé de manger et de boire. [^3] Et quand il ira se coucher, observe le lieu où il se couche. Ensuite va, découvre ses pieds, et couche-toi. Il te dira lui-même ce que tu as à faire. [^4] Elle lui répondit: Je ferai tout ce que tu as dit. [^5] Elle descendit à l’aire, et fit tout ce qu’avait ordonné sa belle-mère. [^6] Boaz mangea et but, et son cœur était joyeux. Il alla se coucher à l’extrémité d’un tas de gerbes. Ruth vint alors tout doucement, découvrit ses pieds, et se coucha. [^7] Au milieu de la nuit, cet homme eut une frayeur; il se pencha, et voici, une femme était couchée à ses pieds. [^8] Il dit: Qui es-tu? Elle répondit: Je suis Ruth, ta servante; étends ton aile sur ta servante, car tu as droit de rachat. [^9] Et il dit: Sois bénie de l’Éternel, ma fille! Ce dernier trait témoigne encore plus en ta faveur que le premier, car tu n’as pas recherché des jeunes gens, pauvres ou riches. [^10] Maintenant, ma fille, ne crains point; je ferai pour toi tout ce que tu diras; car toute la porte de mon peuple sait que tu es une femme vertueuse. [^11] Il est bien vrai que j’ai droit de rachat, mais il en existe un autre plus proche que moi. [^12] Passe ici la nuit. Et demain, s’il veut user envers toi du droit de rachat, à la bonne heure, qu’il le fasse; mais s’il ne lui plaît pas d’en user envers toi, j’en userai, moi, l’Éternel est vivant! Reste couchée jusqu’au matin. [^13] Elle resta couchée à ses pieds jusqu’au matin, et elle se leva avant qu’on pût se reconnaître l’un l’autre. Boaz dit: Qu’on ne sache pas qu’une femme est entrée dans l’aire. [^14] Et il ajouta: Donne le manteau qui est sur toi, et tiens-le. Elle le tint, et il mesura six mesures d’orge, qu’il chargea sur elle. Puis il rentra dans la ville. [^15] Ruth revint auprès de sa belle-mère, et Naomi dit: Est-ce toi, ma fille? Ruth lui raconta tout ce que cet homme avait fait pour elle. [^16] Elle dit: Il m’a donné ces six mesures d’orge, en disant: Tu ne retourneras pas à vide vers ta belle-mère. [^17] Et Naomi dit: Sois tranquille, ma fille, jusqu’à ce que tu saches comment finira la chose, car cet homme ne se donnera point de repos qu’il n’ait terminé cette affaire aujourd’hui. [^18] 

[[Ruth - 2|<--]] Ruth - 3 [[Ruth - 4|-->]]

---
# Notes
