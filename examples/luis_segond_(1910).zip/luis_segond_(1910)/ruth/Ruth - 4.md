---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/ruth"
  - "#bible/testament/old"
aliases:
  - "Ruth - 4 - Luis Segond (1910)"
---
[[Ruth - 3|<--]] Ruth - 4

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Ruth]]

# Ruth - 4

Boaz monta à la porte, et s’y arrêta. Or voici, celui qui avait droit de rachat, et dont Boaz avait parlé, vint à passer. Boaz lui dit: Approche, reste ici, toi un tel. Et il s’approcha, et s’arrêta. [^1] Boaz prit alors dix hommes parmi les anciens de la ville, et il dit: Asseyez-vous ici. Et ils s’assirent. [^2] Puis il dit à celui qui avait le droit de rachat: Naomi, revenue du pays de Moab, a vendu la pièce de terre qui appartenait à notre frère Élimélec. [^3] J’ai cru devoir t’en informer, et te dire: Acquiers-la, en présence des habitants et en présence des anciens de mon peuple. Si tu veux racheter, rachète; mais si tu ne veux pas, déclare-le-moi, afin que je le sache. Car il n’y a personne avant toi qui ait le droit de rachat, et je l’ai après toi. Et il répondit: je rachèterai. [^4] Boaz dit: Le jour où tu acquerras le champ de la main de Naomi, tu l’acquerras en même temps de Ruth la Moabite, femme du défunt, pour relever le nom du défunt dans son héritage. [^5] Et celui qui avait le droit de rachat répondit: Je ne puis pas racheter pour mon compte, crainte de détruire mon héritage; prends pour toi mon droit de rachat, car je ne puis pas racheter. [^6] #De 25:7.Autrefois en Israël, pour valider une affaire quelconque relative à un rachat ou à un échange, l’un ôtait son soulier et le donnait à l’autre: cela servait de témoignage en Israël. [^7] Celui qui avait le droit de rachat dit donc à Boaz: Acquiers pour ton compte! Et il ôta son soulier. [^8] Alors Boaz dit aux anciens et à tout le peuple: Vous êtes témoins aujourd’hui que j’ai acquis de la main de Naomi tout ce qui appartenait à Élimélec, à Kiljon et à Machlon, [^9] et que je me suis également acquis pour femme Ruth la Moabite, femme de Machlon, pour relever le nom du défunt dans son héritage, et afin que le nom du défunt ne soit point retranché d’entre ses frères et de la porte de son lieu. Vous en êtes témoins aujourd’hui! [^10] Tout le peuple qui était à la porte et les anciens dirent: Nous en sommes témoins! Que l’Éternel rende la femme qui entre dans ta maison semblable à #Ge 29:32, etc.; 30:24, 25; 35:17, 18.Rachel et à Léa, qui toutes les deux ont bâti la maison d’Israël! Manifeste ta force dans Éphrata, et fais-toi un nom dans Bethléhem! [^11] Puisse la postérité que l’Éternel te donnera par cette jeune femme rendre ta maison semblable à la maison de #Ge 38:29. 1 Ch 2:4. Mt 1:3.Pérets, qui fut enfanté à Juda par Tamar! [^12] Boaz prit Ruth, qui devint sa femme, et il alla vers elle. L’Éternel permit à Ruth de concevoir, et elle enfanta un fils. [^13] Les femmes dirent à Naomi: Béni soit l’Éternel, qui ne t’a point laissé manquer aujourd’hui d’un homme ayant droit de rachat, et dont le nom sera célébré en Israël! [^14] Cet enfant restaurera ton âme, et sera le soutien de ta vieillesse; car ta belle-fille, qui t’aime, l’a enfanté, elle qui vaut mieux pour toi que sept fils. [^15] Naomi prit l’enfant et le mit sur son sein, et elle fut sa garde. [^16] Les voisines lui donnèrent un nom, en disant: Un fils est né à Naomi! Et elles l’appelèrent Obed. Ce fut le père d’Isaï père de David. [^17] Voici la postérité de Pérets. #1 Ch 2:5. Mt 1:3.Pérets engendra Hetsron; [^18] Hetsron engendra Ram; Ram engendra Amminadab; [^19] Amminadab engendra Nachschon; Nachschon engendra Salmon; [^20] Salmon engendra Boaz; Boaz engendra Obed; [^21] Obed engendra Isaï; et Isaï engendra David. [^22] 

[[Ruth - 3|<--]] Ruth - 4

---
# Notes
