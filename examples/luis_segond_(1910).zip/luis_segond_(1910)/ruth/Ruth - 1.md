---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/ruth"
  - "#bible/testament/old"
aliases:
  - "Ruth - 1 - Luis Segond (1910)"
---
Ruth - 1 [[Ruth - 2|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Ruth]]

# Ruth - 1

Du temps des juges, il y eut une famine dans le pays. Un homme de Bethléhem de Juda partit, avec sa femme et ses deux fils, pour faire un séjour dans le pays de Moab. [^1] Le nom de cet homme était Élimélec, celui de sa femme Naomi, et ses deux fils s’appelaient Machlon et Kiljon; ils étaient Éphratiens, de Bethléhem de Juda. Arrivés au pays de Moab, ils y fixèrent leur demeure. [^2] Élimélec, mari de Naomi, mourut, et elle resta avec ses deux fils. [^3] Ils prirent des femmes Moabites, dont l’une se nommait Orpa, et l’autre Ruth, et ils habitèrent là environ dix ans. [^4] Machlon et Kiljon moururent aussi tous les deux, et Naomi resta privée de ses deux fils et de son mari. [^5] Puis elle se leva, elle et ses belles-filles, afin de quitter le pays de Moab, car elle apprit au pays de Moab que l’Éternel avait visité son peuple et lui avait donné du pain. [^6] Elle sortit du lieu qu’elle habitait, accompagnée de ses deux belles-filles, et elle se mit en route pour retourner dans le pays de Juda. [^7] Naomi dit alors à ses deux belles-filles: Allez, retournez chacune à la maison de sa mère! Que l’Éternel use de bonté envers vous, comme vous l’avez fait envers ceux qui sont morts et envers moi! [^8] Que l’Éternel vous fasse trouver à chacune du repos dans la maison d’un mari! Et elle les baisa. Elles élevèrent la voix, et pleurèrent; [^9] et elles lui dirent: Non, nous irons avec toi vers ton peuple. [^10] Naomi, dit: Retournez, mes filles! Pourquoi viendriez-vous avec moi? Ai-je encore dans mon sein des fils qui puissent devenir vos maris? [^11] Retournez, mes filles, allez! Je suis trop vieille pour me remarier. Et quand je dirais: J’ai de l’espérance; quand cette nuit même je serais avec un mari, et que j’enfanterais des fils, [^12] attendriez-vous pour cela qu’ils eussent grandi, refuseriez-vous pour cela de vous marier? Non, mes filles! Car à cause de vous je suis dans une grande affliction de ce que la main de l’Éternel s’est étendue contre moi. [^13] Et elles élevèrent la voix, et pleurèrent encore. Orpa baisa sa belle-mère, mais Ruth s’attacha à elle. [^14] Naomi dit à Ruth: Voici, ta belle-sœur est retournée vers son peuple et vers ses dieux; retourne, comme ta belle-sœur. [^15] Ruth répondit: Ne me presse pas de te laisser, de retourner loin de toi! Où tu iras j’irai, où tu demeureras je demeurerai; ton peuple sera mon peuple, et ton Dieu sera mon Dieu; [^16] où tu mourras je mourrai, et j’y serai enterrée. Que l’Éternel me traite dans toute sa rigueur, si autre chose que la mort vient à me séparer de toi! [^17] Naomi, la voyant décidée à aller avec elle, cessa ses instances. [^18] Elles firent ensemble le voyage jusqu’à leur arrivée à Bethléhem. Et lorsqu’elles entrèrent dans Bethléhem, toute la ville fut émue à cause d’elles, et les femmes disaient: Est-ce là Naomi? [^19] Elle leur dit: Ne m’appelez pas Naomi; appelez-moi Mara, car le Tout-Puissant m’a remplie d’amertume. [^20] J’étais dans l’abondance à mon départ, et l’Éternel me ramène les mains vides. Pourquoi m’appelleriez-vous Naomi, après que l’Éternel s’est prononcé contre moi, et que le Tout-Puissant m’a affligée? [^21] Ainsi revinrent du pays de Moab Naomi et sa belle-fille, Ruth la Moabite. Elles arrivèrent à Bethléhem au commencement de la moisson des orges. [^22] 

Ruth - 1 [[Ruth - 2|-->]]

---
# Notes
