---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/ruth"
  - "#bible/testament/old"
aliases:
  - "Ruth - 2 - Luis Segond (1910)"
---
[[Ruth - 1|<--]] Ruth - 2 [[Ruth - 3|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Ruth]]

# Ruth - 2

Naomi avait un parent de son mari. C’était un homme puissant et riche, de la famille d’Élimélec, et qui se nommait #Mt 1:5.Boaz. [^1] Ruth la Moabite dit à Naomi: Laisse-moi, je te prie, aller glaner des épis dans le champ de celui aux yeux duquel je trouverai grâce. Elle lui répondit: Va, ma fille. [^2] Elle alla glaner dans un champ, derrière les moissonneurs. Et il se trouva par hasard que la pièce de terre appartenait à Boaz, qui était de la famille d’Élimélec. [^3] Et voici, Boaz vint de Bethléhem, et il dit aux moissonneurs: Que l’Éternel soit avec vous! Ils lui répondirent: Que l’Éternel te bénisse! [^4] Et Boaz dit à son serviteur chargé de surveiller les moissonneurs: A qui est cette jeune femme? [^5] Le serviteur chargé de surveiller les moissonneurs répondit: C’est une jeune femme Moabite, qui est revenue avec Naomi du pays de Moab. [^6] Elle a dit: Permettez-moi de glaner et de ramasser des épis entre les gerbes, derrière les moissonneurs. Et depuis ce matin qu’elle est venue, elle a été debout jusqu’à présent, et ne s’est reposée qu’un moment dans la maison. [^7] Boaz dit à Ruth: Écoute, ma fille, ne va pas glaner dans un autre champ; ne t’éloigne pas d’ici, et reste avec mes servantes. [^8] Regarde où l’on moissonne dans le champ, et va après elles. J’ai défendu à mes serviteurs de te toucher. Et quand tu auras soif, tu iras aux vases, et tu boiras de ce que les serviteurs auront puisé. [^9] Alors elle tomba sur sa face et se prosterna contre terre, et elle lui dit: Comment ai-je trouvé grâce à tes yeux, pour que tu t’intéresses à moi, à moi qui suis une étrangère? [^10] Boaz lui répondit: On m’a rapporté tout ce que tu as fait pour ta belle-mère depuis la mort de ton mari, et comment tu as quitté ton père et ta mère et le pays de ta naissance, pour aller vers un peuple que tu ne connaissais point auparavant. [^11] Que l’Éternel te rende ce que tu as fait, et que ta récompense soit entière de la part de l’Éternel, le Dieu d’Israël, sous les ailes duquel tu es venue te réfugier! [^12] Et elle dit: Oh! Que je trouve grâce à tes yeux, mon seigneur! Car tu m’as consolée, et tu as parlé au cœur de ta servante. Et pourtant je ne suis pas, moi, comme l’une de tes servantes. [^13] Au moment du repas, Boaz dit à Ruth: Approche, mange du pain, et trempe ton morceau dans le vinaigre. Elle s’assit à côté des moissonneurs. On lui donna du grain rôti; elle mangea et se rassasia, et elle garda le reste. [^14] Puis elle se leva pour glaner. Boaz donna cet ordre à ses serviteurs: Qu’elle glane aussi entre les gerbes, et ne l’inquiétez pas, [^15] et même vous ôterez pour elle des gerbes quelques épis, que vous la laisserez glaner, sans lui faire de reproches. [^16] Elle glana dans le champ jusqu’au soir, et elle battit ce qu’elle avait glané. Il y eut environ un épha d’orge. [^17] Elle l’emporta et rentra dans la ville, et sa belle-mère vit ce qu’elle avait glané. Elle sortit aussi les restes de son repas, et les lui donna. [^18] Sa belle-mère lui dit: Où as-tu glané aujourd’hui, et où as-tu travaillé? Béni soit celui qui s’est intéressé à toi! Et Ruth fit connaître à sa belle-mère chez qui elle avait travaillé: L’homme chez qui j’ai travaillé aujourd’hui, dit-elle, s’appelle Boaz. [^19] Naomi dit à sa belle-fille: Qu’il soit béni de l’Éternel, qui se montre miséricordieux pour les vivants comme il le fut pour ceux qui sont morts! Cet homme est notre parent, lui dit encore Naomi, il est de ceux qui ont sur nous droit de rachat. [^20] Ruth la Moabite ajouta: Il m’a dit aussi: Reste avec mes serviteurs, jusqu’à ce qu’ils aient achevé toute ma moisson. [^21] Et Naomi dit à Ruth, sa belle-fille: Il est bon, ma fille, que tu sortes avec ses servantes, et qu’on ne te rencontre pas dans un autre champ. [^22] Elle resta donc avec les servantes de Boaz, pour glaner, jusqu’à la fin de la moisson des orges et de la moisson du froment. Et elle demeurait avec sa belle-mère. [^23] 

[[Ruth - 1|<--]] Ruth - 2 [[Ruth - 3|-->]]

---
# Notes
