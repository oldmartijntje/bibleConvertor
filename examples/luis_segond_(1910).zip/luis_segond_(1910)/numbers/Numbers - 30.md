---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 30 - Luis Segond (1910)"
---
[[Numbers - 29|<--]] Numbers - 30 [[Numbers - 31|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Numbers]]

# Numbers - 30

Moïse dit aux enfants d’Israël tout ce que l’Éternel lui avait ordonné. [^1] Moïse parla aux chefs des tribus des enfants d’Israël, et dit: Voici ce que l’Éternel ordonne. [^2] #De 23:21.Lorsqu’un homme fera un vœu à l’Éternel, ou un serment pour se lier par un engagement, il ne violera point sa parole, il agira selon tout ce qui est sorti de sa bouche. [^3] Lorsqu’une femme, dans sa jeunesse et à la maison de son père, fera un vœu à l’Éternel et se liera par un engagement, [^4] et que son père aura connaissance du vœu qu’elle a fait et de l’engagement par lequel elle s’est liée, si son père garde le silence envers elle, tout vœu qu’elle aura fait sera valable, et tout engagement par lequel elle se sera liée sera valable; [^5] mais si son père la désapprouve le jour où il en a connaissance, tous ses vœux et tous les engagements par lesquels elle se sera liée n’auront aucune valeur; et l’Éternel lui pardonnera, parce qu’elle a été désapprouvée de son père. [^6] Lorsqu’elle sera mariée, après avoir fait des vœux, ou s’être liée par une parole échappée de ses lèvres, [^7] et que son mari en aura connaissance, s’il garde le silence envers elle le jour où il en a connaissance, ses vœux seront valables, et les engagements par lesquels elle se sera liée seront valables; [^8] mais si son mari la désapprouve le jour où il en a connaissance, il annulera le vœu qu’elle a fait et la parole échappée de ses lèvres, par laquelle elle s’est liée; et l’Éternel lui pardonnera. [^9] Le vœu d’une femme veuve ou répudiée, l’engagement quelconque par lequel elle se sera liée, sera valable pour elle. [^10] Lorsqu’une femme, dans la maison de son mari, fera des vœux ou se liera par un serment, [^11] et que son mari en aura connaissance, s’il garde le silence envers elle et ne la désapprouve pas, tous ses vœux seront valables, et tous les engagements par lesquels elle se sera liée seront valables; [^12] mais si son mari les annule le jour où il en a connaissance, tout vœu et tout engagement sortis de ses lèvres n’auront aucune valeur, son mari les a annulés; et l’Éternel lui pardonnera. [^13] Son mari peut ratifier et son mari peut annuler tout vœu, tout serment par lequel elle s’engage à mortifier sa personne. [^14] S’il garde de jour en jour le silence envers elle, il ratifie ainsi tous les vœux ou tous les engagements par lesquels elle s’est liée; il les ratifie, parce qu’il a gardé le silence envers elle le jour où il en a eu connaissance. [^15] Mais s’il les annule après le jour où il en a eu connaissance, il sera coupable du péché de sa femme. [^16] Telles sont les lois que l’Éternel prescrivit à Moïse, entre un mari et sa femme, entre un père et sa fille, lorsqu’elle est dans sa jeunesse et à la maison de son père. [^17] 

[[Numbers - 29|<--]] Numbers - 30 [[Numbers - 31|-->]]

---
# Notes
