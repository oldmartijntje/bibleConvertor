---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 24 - Luis Segond (1910)"
---
[[Numbers - 23|<--]] Numbers - 24 [[Numbers - 25|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Numbers]]

# Numbers - 24

Balaam vit que l’Éternel trouvait bon de bénir Israël, et il n’alla point comme les autres fois, à la rencontre des enchantements; mais il tourna son visage du côté du désert. [^1] Balaam leva les yeux, et vit Israël campé selon ses tribus. Alors l’esprit de Dieu fut sur lui. [^2] Balaam prononça son oracle, et dit:Parole de Balaam, fils de Beor,Parole de l’homme qui a l’œil ouvert, [^3] Parole de celui qui entend les paroles de Dieu,De celui qui voit la vision du Tout-Puissant,De celui qui se prosterne et dont les yeux s’ouvrent. [^4] Qu’elles sont belles, tes tentes, ô Jacob!Tes demeures, ô Israël! [^5] Elles s’étendent comme des vallées,Comme des jardins près d’un fleuve,Comme des aloès que l’Éternel a plantés,Comme des cèdres le long des eaux. [^6] L’eau coule de ses seaux,Et sa semence est fécondée par d’abondantes eaux.Son roi s’élève au-dessus d’Agag,Et son royaume devient puissant. [^7] Dieu l’a fait sortir d’Égypte,Il est pour lui comme la vigueur #No 23:22.du buffle.Il dévore les nations qui s’élèvent contre lui,Il brise leurs os, et les abat de ses flèches. [^8] #    
        Ge 49:9. No 23:24.  Il ploie les genoux, il se couche comme un lion, comme une lionne:Qui le fera lever?Béni soit quiconque te bénira,Et maudit soit quiconque te maudira! [^9] La colère de Balak s’enflamma contre Balaam; il frappa des mains, et dit à Balaam: C’est pour maudire mes ennemis que je t’ai appelé, et voici, tu les as bénis déjà trois fois. [^10] Fuis maintenant, va-t’en chez toi! J’avais dit que je te rendrais des honneurs, mais l’Éternel t’empêche de les recevoir. [^11] Balaam répondit à Balak: Eh! N’ai-je pas dit aux messagers que tu m’as envoyés: [^12] #No 22:18.Quand Balak me donnerait sa maison pleine d’argent et d’or, je ne pourrais faire de moi-même ni bien ni mal contre l’ordre de l’Éternel; je répéterai ce que dira l’Éternel? [^13] Et maintenant voici, je m’en vais vers mon peuple. Viens, je t’annoncerai ce que ce peuple fera à ton peuple dans la suite des temps. [^14] Balaam prononça son oracle, et dit:Parole de Balaam, fils de Beor,Parole de l’homme qui a l’œil ouvert, [^15] Parole de celui qui entend les paroles de Dieu,De celui qui connaît les desseins du Très-Haut,De celui qui voit la vision du Tout-Puissant,De celui qui se prosterne et dont les yeux s’ouvrent. [^16] Je le vois, mais non maintenant,Je le contemple, mais non de près.Un astre sort de Jacob,Un sceptre s’élève d’Israël.Il perce les flancs de Moab,Et il abat tous les enfants de Seth. [^17] Il se rend maître d’Édom,Il se rend maître de Séir, ses ennemis.Israël manifeste sa force. [^18] #    
        2 S 8:14.  Celui qui sort de Jacob règne en souverain,Il fait périr ceux qui s’échappent des villes. [^19] Balaam vit Amalek. Il prononça son oracle, et dit:Amalek est la première des nations,Mais un jour il sera détruit. [^20] Balaam vit les Kéniens. Il prononça son oracle, et dit:Ta demeure est solide,Et ton nid posé sur le roc. [^21] Mais le Kénien sera chassé,Quand l’Assyrien t’emmènera captif. [^22] Balaam prononça son oracle, et dit:Hélas! Qui vivra après que Dieu l’aura établi? [^23] Mais des navires viendront de Kittim,Ils humilieront l’Assyrien, ils humilieront l’Hébreu;Et lui aussi sera détruit. [^24] Balaam se leva, partit, et retourna chez lui. Balak s’en alla aussi de son côté. [^25] 

[[Numbers - 23|<--]] Numbers - 24 [[Numbers - 25|-->]]

---
# Notes
