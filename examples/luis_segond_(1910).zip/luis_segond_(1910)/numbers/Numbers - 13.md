---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 13 - Luis Segond (1910)"
---
[[Numbers - 12|<--]] Numbers - 13 [[Numbers - 14|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Numbers]]

# Numbers - 13

L’Éternel parla à Moïse, et dit: [^1] Envoie des hommes pour explorer le pays de Canaan, que je donne aux enfants d’Israël. Tu enverras un homme de chacune des tribus de leurs pères; tous seront des principaux d’entre eux. [^2] Moïse les envoya du désert de Paran, d’après l’ordre de l’Éternel; tous ces hommes étaient chefs des enfants d’Israël. [^3] Voici leurs noms. Pour la tribu de Ruben: Schammua, fils de Zaccur; [^4] pour la tribu de Siméon: Schaphath, fils de Hori; [^5] pour la tribu de Juda: Caleb, fils de Jephunné; [^6] pour la tribu d’Issacar: Jigual, fils de Joseph; [^7] pour la tribu d’Éphraïm: Hosée, fils de Nun; [^8] pour la tribu de Benjamin: Palthi, fils de Raphu; [^9] pour la tribu de Zabulon: Gaddiel, fils de Sodi; [^10] pour la tribu de Joseph, la tribu de Manassé: Gaddi, fils de Susi; [^11] pour la tribu de Dan: Ammiel, fils de Guemalli; [^12] pour la tribu d’Aser: Sethur, fils de Micaël; [^13] pour la tribu de Nephthali: Nachbi, fils de Vophsi; [^14] pour la tribu de Gad: Guéuel, fils de Maki. [^15] Tels sont les noms des hommes que Moïse envoya pour explorer le pays. Moïse donna à Hosée, fils de Nun, le nom de Josué. [^16] Moïse les envoya pour explorer le pays de Canaan. Il leur dit: Montez ici, par le midi; et vous monterez sur la montagne. [^17] Vous verrez le pays, ce qu’il est, et le peuple qui l’habite, s’il est fort ou faible, s’il est en petit ou en grand nombre; [^18] ce qu’est le pays où il habite, s’il est bon ou mauvais; ce que sont les villes où il habite, si elles sont ouvertes ou fortifiées; [^19] ce qu’est le terrain, s’il est gras ou maigre, s’il y a des arbres ou s’il n’y en a point. Ayez bon courage, et prenez des fruits du pays. C’était le temps des premiers raisins. [^20] Ils montèrent, et ils explorèrent le pays, depuis le désert de Tsin jusqu’à Rehob, sur le chemin de Hamath. [^21] Ils montèrent, par le midi, et ils allèrent jusqu’à Hébron, où étaient Ahiman, Schéschaï et Talmaï, enfants d’Anak. Hébron avait été bâtie sept ans avant Tsoan en Égypte. [^22] Ils arrivèrent jusqu’à la vallée d’Eschcol, où ils coupèrent une branche de vigne avec une grappe de raisin, qu’ils portèrent à deux au moyen d’une perche; ils prirent aussi des grenades et des figues. [^23] On donna à ce lieu le nom de vallée d’Eschcol, à cause de la grappe que les enfants d’Israël y coupèrent. [^24] Ils furent de retour de l’exploration du pays au bout de quarante jours. [^25] A leur arrivée, ils se rendirent auprès de Moïse et d’Aaron, et de toute l’assemblée des enfants d’Israël, à Kadès dans le désert de Paran. Ils leur firent un rapport, ainsi qu’à toute l’assemblée, et ils leur montrèrent les fruits du pays. [^26] Voici ce qu’ils racontèrent à Moïse: Nous sommes allés dans le pays où tu nous as envoyés. A la vérité, #Ex 3:8; 33:3.c’est un pays où coulent le lait et le miel, et en voici les fruits. [^27] Mais le peuple qui habite ce pays est puissant, les villes sont fortifiées, très grandes; nous y avons vu des enfants d’Anak. [^28] Les Amalécites habitent la contrée du midi; les Héthiens, les Jébusiens et les Amoréens habitent la montagne; et les Cananéens habitent près de la mer et le long du Jourdain. [^29] Caleb fit taire le peuple, qui murmurait contre Moïse. Il dit: Montons, emparons-nous du pays, nous y serons vainqueurs! [^30] Mais les hommes qui y étaient allés avec lui dirent: Nous ne pouvons pas monter contre ce peuple, car il est plus fort que nous. [^31] Et ils décrièrent devant les enfants d’Israël le pays qu’ils avaient exploré. Ils dirent: Le pays que nous avons parcouru, pour l’explorer, est un pays qui dévore ses habitants; tous ceux que nous y avons vus sont des hommes d’une haute taille; [^32] et nous y avons vu les géants, enfants d’Anak, de la race des géants: nous étions à nos yeux et aux leurs comme des sauterelles. [^33] 

[[Numbers - 12|<--]] Numbers - 13 [[Numbers - 14|-->]]

---
# Notes
