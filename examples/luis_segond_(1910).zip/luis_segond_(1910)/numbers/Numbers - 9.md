---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 9 - Luis Segond (1910)"
---
[[Numbers - 8|<--]] Numbers - 9 [[Numbers - 10|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Numbers]]

# Numbers - 9

L’Éternel parla à Moïse, dans le désert de Sinaï, le premier mois de la seconde année après leur sortie du pays d’Égypte. [^1] Il dit: Que les enfants d’Israël célèbrent la #Ex 12:1, etc. Lé 23:5. No 28:16. De 16:2.Pâque au temps fixé. [^2] Vous la célébrerez au temps fixé, le quatorzième jour de ce mois, entre les deux soirs; vous la célébrerez selon toutes les lois et toutes les ordonnances qui s’y rapportent. [^3] Moïse parla aux enfants d’Israël, afin qu’ils célébrassent la Pâque. [^4] Et ils célébrèrent la Pâque le quatorzième jour du premier mois, entre les deux soirs, dans le désert de Sinaï; les enfants d’Israël se conformèrent à tous les ordres que l’Éternel avait donnés à Moïse. [^5] Il y eut des hommes qui, se trouvant impurs à cause d’un mort, ne pouvaient pas célébrer la Pâque ce jour-là. Ils se présentèrent le même jour devant Moïse et Aaron; [^6] et ces hommes dirent à Moïse: Nous sommes impurs à cause d’un mort; pourquoi serions-nous privés de présenter au temps fixé l’offrande de l’Éternel au milieu des enfants d’Israël? [^7] Moïse leur dit: Attendez que je sache ce que l’Éternel vous ordonne. [^8] Et l’Éternel parla à Moïse, et dit: [^9] Parle aux enfants d’Israël, et dis-leur: Si quelqu’un d’entre vous ou de vos descendants est impur à cause d’un mort, ou est en voyage dans le lointain, il célébrera la Pâque en l’honneur de l’Éternel. [^10] C’est au second mois qu’ils la célébreront, le quatorzième jour, entre les deux soirs; ils la mangeront avec des pains sans levain et des herbes amères. [^11] #Ex 12:46. Jn 19:33, 36.Ils n’en laisseront rien jusqu’au matin, et ils n’en briseront aucun os. Ils la célébreront selon toutes les ordonnances de la Pâque. [^12] Si celui qui est pur et qui n’est pas en voyage s’abstient de célébrer la Pâque, celui-là sera retranché de son peuple; parce qu’il n’a pas présenté l’offrande de l’Éternel au temps fixé, cet homme-là portera la peine de son péché. [^13] Si un étranger en séjour chez vous célèbre la Pâque de l’Éternel, il se conformera aux lois et aux ordonnances de la Pâque. #Ex 12:49.Il y aura une même loi parmi vous, pour l’étranger comme pour l’indigène. [^14] #    
        Ex 40:34.  Le jour où le tabernacle fut dressé, la nuée couvrit le tabernacle, la tente d’assignation; et, depuis le soir jusqu’au matin, elle eut sur le tabernacle l’apparence d’un feu. [^15] Il en fut continuellement ainsi: la nuée couvrait le tabernacle, et elle avait de nuit l’apparence d’un feu. [^16] Quand la nuée s’élevait de dessus la tente, les enfants d’Israël partaient; et les enfants d’Israël campaient dans le lieu où s’arrêtait la nuée. [^17] Les enfants d’Israël partaient sur l’ordre de l’Éternel, #1 Co 10:1.et ils campaient sur l’ordre de l’Éternel; ils campaient aussi longtemps que la nuée restait sur le tabernacle. [^18] Quand la nuée restait longtemps sur le tabernacle, les enfants d’Israël obéissaient au commandement de l’Éternel, et ne partaient point. [^19] Quand la nuée restait peu de jours sur le tabernacle, ils campaient sur l’ordre de l’Éternel, et ils partaient sur l’ordre de l’Éternel. [^20] Si la nuée s’arrêtait du soir au matin, et s’élevait le matin, ils partaient. Si la nuée s’élevait après un jour et une nuit, ils partaient. [^21] Si la nuée s’arrêtait sur le tabernacle deux jours, ou un mois, ou une année, #Ex 40:36, 37.les enfants d’Israël restaient campés, et ne partaient point; et quand elle s’élevait, ils partaient. [^22] Ils campaient sur l’ordre de l’Éternel, et ils partaient sur l’ordre de l’Éternel; ils obéissaient au commandement de l’Éternel, sur l’ordre de l’Éternel par Moïse. [^23] 

[[Numbers - 8|<--]] Numbers - 9 [[Numbers - 10|-->]]

---
# Notes
