---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 12 - Luis Segond (1910)"
---
[[Numbers - 11|<--]] Numbers - 12 [[Numbers - 13|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Numbers]]

# Numbers - 12

Marie et Aaron parlèrent contre Moïse au sujet de la femme éthiopienne qu’il avait prise, car il avait pris une femme éthiopienne. [^1] Ils dirent: Est-ce seulement par Moïse que l’Éternel parle? N’est-ce pas aussi par nous qu’il parle? [^2] Et l’Éternel l’entendit. Or, Moïse était un homme fort patient, plus qu’aucun homme sur la face de la terre. [^3] Soudain l’Éternel dit à Moïse, à Aaron et à Marie: Allez, vous trois, à la tente d’assignation. Et ils y allèrent tous les trois. [^4] L’Éternel descendit dans la colonne de nuée, et il se tint à l’entrée de la tente. Il appela Aaron et Marie, qui s’avancèrent tous les deux. [^5] Et il dit: Écoutez bien mes paroles! Lorsqu’il y aura parmi vous un prophète, c’est dans une vision que moi, l’Éternel, je me révélerai à lui, c’est dans un songe que je lui parlerai. [^6] Il n’en est pas ainsi de mon serviteur Moïse. #Hé 3:2.Il est fidèle dans toute ma maison. [^7] Je lui parle #Ex 33:11. De 34:10.bouche à bouche, je me révèle à lui sans énigmes, et il voit une représentation de l’Éternel. Pourquoi donc n’avez-vous pas craint de parler contre mon serviteur, contre Moïse? [^8] La colère de l’Éternel s’enflamma contre eux. Et il s’en alla. [^9] La nuée se retira de dessus la tente. Et voici, Marie était frappée d’une lèpre, blanche comme la neige. Aaron se tourna vers Marie; et voici, elle avait la lèpre. [^10] Alors Aaron dit à Moïse: De grâce, mon seigneur, ne nous fais pas porter la peine du péché que nous avons commis en insensés, et dont nous nous sommes rendus coupables! [^11] Oh! Qu’elle ne soit pas comme l’enfant mort-né, dont la chair est à moitié consumée quand il sort du sein de sa mère! [^12] Moïse cria à l’Éternel, en disant: O Dieu, je te prie, guéris-la! [^13] Et l’Éternel dit à Moïse: Si son père lui avait craché au visage, ne serait-elle pas pendant sept jours un objet de honte? #Lé 13:46.Qu’elle soit enfermée sept jours en dehors du camp; après quoi, elle y sera reçue. [^14] Marie fut enfermée sept jours en dehors du camp; et le peuple ne partit point, jusqu’à ce que Marie y fût rentrée. [^15] Après cela, le peuple partit de Hatséroth, et il campa dans le désert de Paran. [^16] 

[[Numbers - 11|<--]] Numbers - 12 [[Numbers - 13|-->]]

---
# Notes
