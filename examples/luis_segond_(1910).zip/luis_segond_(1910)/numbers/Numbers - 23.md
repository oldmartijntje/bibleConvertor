---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 23 - Luis Segond (1910)"
---
[[Numbers - 22|<--]] Numbers - 23 [[Numbers - 24|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Numbers]]

# Numbers - 23

Balaam dit à Balak: Bâtis-moi ici sept autels, et prépare-moi ici sept taureaux et sept béliers. [^1] Balak fit ce que Balaam avait dit; et Balak et Balaam offrirent un taureau et un bélier sur chaque autel. [^2] Balaam dit à Balak: Tiens-toi près de ton holocauste, et je m’éloignerai; peut-être que l’Éternel viendra à ma rencontre, et je te dirai ce qu’il me révélera. Et il alla sur un lieu élevé. [^3] Dieu vint au-devant de Balaam, et Balaam lui dit: J’ai dressé sept autels, et j’ai offert un taureau et un bélier sur chaque autel. [^4] L’Éternel mit des paroles dans la bouche de Balaam, et dit: Retourne vers Balak, et tu parleras ainsi. [^5] Il retourna vers lui; et voici, Balak se tenait près de son holocauste, lui et tous les chefs de Moab. [^6] Balaam prononça son oracle, et dit:Balak m’a fait descendre d’Aram,Le roi de Moab m’a fait descendre des montagnes de l’Orient.Viens, maudis-moi Jacob!Viens, sois irrité contre Israël! [^7] Comment maudirais-je celui que Dieu n’a point maudit?Comment serais-je irrité quand l’Éternel n’est point irrité? [^8] Je le vois du sommet des rochers, Je le contemple du haut des collines: #De 33:28.C’est un peuple qui a sa demeure à part,Et qui ne fait point partie des nations. [^9] Qui peut compter la poussière de Jacob,Et dire le nombre du quart d’Israël?Que je meure de la mort des justes,Et que ma fin soit semblable à la leur! [^10] Balak dit à Balaam: Que m’as-tu fait? Je t’ai pris pour maudire mon ennemi, et voici, tu le bénis! [^11] Il répondit, et dit: N’aurai-je pas soin de dire ce que l’Éternel met dans ma bouche? [^12] Balak lui dit: Viens donc avec moi dans un autre lieu, d’où tu le verras; tu n’en verras qu’une partie, tu n’en verras pas la totalité. Et de là maudis-le-moi. [^13] Il le mena au champ de Tsophim, sur le sommet du Pisga; il bâtit sept autels, et offrit un taureau et un bélier sur chaque autel. [^14] Balaam dit à Balak: Tiens-toi ici, près de ton holocauste, et j’irai à la rencontre de Dieu. [^15] L’Éternel vint au-devant de Balaam; #No 22:35.il mit des paroles dans sa bouche, et dit: Retourne vers Balak, et tu parleras ainsi. [^16] Il retourna vers lui; et voici, Balak se tenait près de son holocauste, avec les chefs de Moab. Balak lui dit: Qu’est-ce que l’Éternel a dit? [^17] Balaam prononça son oracle, et dit:Lève-toi, Balak, écoute!Prête-moi l’oreille, fils de Tsippor! [^18] #    
        1 S 15:29. Ja 1:17.  Dieu n’est point un homme pour mentir,Ni fils d’un homme pour se repentir.Ce qu’il a dit, ne le fera-t-il pas?Ce qu’il a déclaré, ne l’exécutera-t-il pas? [^19] Voici, j’ai reçu l’ordre de bénir:Il a béni, je ne le révoquerai point. [^20] #    
        Ps 32:1, 2; 51:11. Jé 50:20. Ro 4:7.  Il n’aperçoit point d’iniquité en Jacob,Il ne voit point d’injustice en Israël;L’Éternel, son Dieu, est avec lui,Il est son roi, l’objet de son allégresse. [^21] Dieu les a fait sortir d’Égypte,#    
        No 24:8.  Il est pour eux comme la vigueur du buffle. [^22] L’enchantement ne peut rien contre Jacob,Ni la divination contre Israël;Au temps marqué, il sera dit à Jacob et à Israël:Quelle est l’œuvre de Dieu. [^23] C’est un peuple qui se lève comme une lionne,Et qui se dresse comme un lion;Il ne se couche point jusqu’à ce qu’il ait dévoré la proie,Et qu’il ait bu le sang des blessés. [^24] Balak dit à Balaam: Ne le maudis pas, mais du moins ne le bénis pas. [^25] Balaam répondit, et dit à Balak: Ne t’ai-je pas parlé ainsi: Je ferai tout ce que l’Éternel dira? [^26] Balak dit à Balaam: Viens donc, je te mènerai dans un autre lieu; peut être Dieu trouvera-t-il bon que de là tu me maudisses ce peuple. [^27] Balak mena Balaam sur le sommet du Peor, en regard du désert. [^28] Balaam dit à Balak: Bâtis-moi ici sept autels, et prépare-moi ici sept taureaux et sept béliers. [^29] Balak fit ce que Balaam avait dit, et il offrit un taureau et un bélier sur chaque autel. [^30] 

[[Numbers - 22|<--]] Numbers - 23 [[Numbers - 24|-->]]

---
# Notes
