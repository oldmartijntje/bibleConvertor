---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 25 - Luis Segond (1910)"
---
[[Numbers - 24|<--]] Numbers - 25 [[Numbers - 26|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Numbers]]

# Numbers - 25

#    
        No 31:16; 33:49.  Israël demeurait à Sittim; et le peuple commença à se livrer à la débauche avec les filles de Moab. [^1] #Ps 106:28. Os 9:10.Elles invitèrent le peuple aux sacrifices de leurs dieux; et le peuple mangea, et se prosterna devant leurs dieux. [^2] Israël s’attacha à Baal-Peor, et #Ps 106:29.la colère de l’Éternel s’enflamma contre Israël. [^3] L’Éternel dit à Moïse: #De 4:3. Jos 22:17.Assemble tous les chefs du peuple, et fais pendre les coupables devant l’Éternel en face du soleil, afin que la colère ardente de l’Éternel se détourne d’Israël. [^4] Moïse dit aux juges d’Israël: Que chacun de vous tue ceux de ses gens qui se sont attachés à Baal-Peor. [^5] Et voici, un homme des enfants d’Israël vint et amena vers ses frères une Madianite, sous les yeux de Moïse et sous les yeux de toute l’assemblée des enfants d’Israël, tandis qu’ils pleuraient à l’entrée de la tente d’assignation. [^6] A cette vue, Phinées, fils d’Éléazar, fils du sacrificateur Aaron, #Ps 106:30.se leva du milieu de l’assemblée, et prit une lance, dans sa main. [^7] Il suivit l’homme d’Israël dans sa tente, et il les perça tous les deux, l’homme d’Israël, puis la femme, par le bas-ventre. Et la plaie s’arrêta parmi les enfants d’Israël. [^8] #1 Co 10:8.Il y en eut vingt-quatre mille qui moururent de la plaie. [^9] L’Éternel parla à Moïse, et dit: [^10] Phinées, fils d’Éléazar, fils du sacrificateur Aaron, a détourné ma fureur de dessus les enfants d’Israël, parce qu’il a été animé #2 Co 11:2.de mon zèle au milieu d’eux; et je n’ai point, dans ma colère, consumé les enfants d’Israël. [^11] C’est pourquoi tu diras que je #Ps 106:31.traite avec lui une alliance de paix. [^12] Ce sera pour lui et pour sa postérité après lui l’alliance d’un sacerdoce perpétuel, parce qu’il a été zélé pour son Dieu, et qu’il a fait l’expiation pour les enfants d’Israël. [^13] L’homme d’Israël, qui fut tué avec la Madianite, s’appelait Zimri, fils de Salu; il était chef d’une maison paternelle des Siméonites. [^14] La femme qui fut tuée, la Madianite, s’appelait Cozbi, fille de Tsur, chef des peuplades issues d’une maison paternelle en Madian. [^15] L’Éternel parla à Moïse, et dit: [^16] Traite les Madianites #No 31:2.en ennemis, et tuez-les; [^17] car ils se sont montrés #Ap 18:6.vos ennemis, en vous séduisant par leurs ruses, dans l’affaire de Peor, et dans l’affaire de Cozbi, fille d’un chef de Madian, leur sœur, tuée le jour de la plaie qui eut lieu à l’occasion de Peor. [^18] 

[[Numbers - 24|<--]] Numbers - 25 [[Numbers - 26|-->]]

---
# Notes
