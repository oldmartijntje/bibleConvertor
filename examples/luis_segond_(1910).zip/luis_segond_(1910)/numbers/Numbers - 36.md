---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 36 - Luis Segond (1910)"
---
[[Numbers - 35|<--]] Numbers - 36

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Numbers]]

# Numbers - 36

Les chefs de la famille de Galaad, fils de Makir, fils de Manassé, d’entre les familles des fils de Joseph, s’approchèrent et parlèrent devant Moïse et devant les princes, chefs de famille des enfants d’Israël. [^1] Ils dirent: #No 26:55, 56; 33:54.L’Éternel a ordonné à mon seigneur de donner le pays en héritage par le sort aux enfants d’Israël. #No 27:7. Jos 17:3, 4.Mon seigneur a aussi reçu de l’Éternel l’ordre de donner l’héritage de Tselophchad, notre frère, à ses filles. [^2] Si elles se marient à l’un des fils d’une autre tribu des enfants d’Israël, leur héritage sera retranché de l’héritage de nos pères et ajouté à celui de la tribu à laquelle elles appartiendront; ainsi sera diminué l’héritage qui nous est échu par le sort. [^3] Et quand viendra le jubilé pour les enfants d’Israël, leur héritage sera ajouté à celui de la tribu à laquelle elles appartiendront, et il sera retranché de celui de la tribu de nos pères. [^4] Moïse transmit aux enfants d’Israël les ordres de l’Éternel. Il dit: La tribu des fils de Joseph a raison. [^5] Voici ce que l’Éternel ordonne au sujet des filles de Tselophchad: elles se marieront à qui elles voudront, pourvu qu’elles se marient dans une famille de la tribu de leurs pères. [^6] Aucun héritage parmi les enfants d’Israël ne passera d’une tribu à une autre tribu, mais les enfants d’Israël s’attacheront chacun à l’héritage de la tribu de ses pères. [^7] Et toute fille, possédant un héritage dans les tribus des enfants d’Israël, se mariera à quelqu’un d’une famille de la tribu de son père, afin que les enfants d’Israël possèdent chacun l’héritage de leurs pères. [^8] Aucun héritage ne passera d’une tribu à une autre tribu, mais les tribus des enfants d’Israël s’attacheront chacune à son héritage. [^9] Les filles de Tselophchad se conformèrent à l’ordre que l’Éternel avait donné à Moïse. [^10] #No 27:1.Machla, Thirtsa, Hogla, Milca et Noa, filles de Tselophchad, se marièrent aux fils de leurs oncles; [^11] elles se marièrent dans les familles des fils de Manassé, fils de Joseph, et leur héritage resta dans la tribu de la famille de leur père. [^12] Tels sont les commandements et les lois que l’Éternel donna par Moïse aux enfants d’Israël, dans les plaines de Moab, près du Jourdain, vis-à-vis de Jéricho. [^13] 

[[Numbers - 35|<--]] Numbers - 36

---
# Notes
