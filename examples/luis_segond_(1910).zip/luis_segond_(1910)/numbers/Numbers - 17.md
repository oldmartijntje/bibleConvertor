---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 17 - Luis Segond (1910)"
---
[[Numbers - 16|<--]] Numbers - 17 [[Numbers - 18|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Numbers]]

# Numbers - 17

L’Éternel parla à Moïse, et dit: [^1] Parle aux enfants d’Israël, et prends d’eux une verge selon les maisons de leurs pères, soit douze verges de la part de tous leurs princes selon les maisons de leurs pères. [^2] Tu écriras le nom de chacun sur sa verge, et tu écriras le nom d’Aaron sur la verge de Lévi; car il y aura une verge pour chaque chef des maisons de leurs pères. [^3] Tu les déposeras dans la tente d’assignation, devant le témoignage, #Ex 25:22.où je me rencontre avec vous. [^4] L’homme que je choisirai sera celui dont la verge fleurira, et je ferai cesser de devant moi les murmures que profèrent contre vous les enfants d’Israël. [^5] Moïse parla aux enfants d’Israël; et tous leurs princes lui donnèrent une verge, chaque prince une verge, selon les maisons de leurs pères, soit douze verges; la verge d’Aaron était au milieu des leurs. [^6] Moïse déposa les verges devant l’Éternel, dans la tente du témoignage. [^7] Le lendemain, lorsque Moïse entra dans la tente du témoignage, voici, la verge d’Aaron, pour la maison de Lévi, avait fleuri, elle avait poussé des boutons, produit des fleurs, et mûri des amandes. [^8] Moïse ôta de devant l’Éternel toutes les verges, et les porta à tous les enfants d’Israël, afin qu’ils les vissent et qu’ils prissent chacun leur verge. [^9] L’Éternel dit à Moïse: #Hé 9:4.Reporte la verge d’Aaron devant le témoignage, pour être conservée comme un signe pour les enfants de rébellion, afin que tu fasses cesser de devant moi leurs murmures et qu’ils ne meurent point. [^10] Moïse fit ainsi; il se conforma à l’ordre que l’Éternel lui avait donné. [^11] Les enfants d’Israël dirent à Moïse: Voici, nous expirons, nous périssons, nous périssons tous! [^12] Quiconque s’approche du tabernacle de l’Éternel, meurt. Nous faudra-t-il tous expirer? [^13] 

[[Numbers - 16|<--]] Numbers - 17 [[Numbers - 18|-->]]

---
# Notes
