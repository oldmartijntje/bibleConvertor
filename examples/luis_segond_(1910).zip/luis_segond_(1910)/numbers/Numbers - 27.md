---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 27 - Luis Segond (1910)"
---
[[Numbers - 26|<--]] Numbers - 27 [[Numbers - 28|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Numbers]]

# Numbers - 27

#    
        No 26:33; 36:2. Jos 17:3.  Les filles de Tselophchad, fils de Hépher, fils de Galaad, fils de Makir, fils de Manassé, des familles de Manassé, fils de Joseph, et dont les noms étaient Machla, Noa, Hogla, Milca et Thirtsa, [^1] s’approchèrent et se présentèrent devant Moïse, devant le sacrificateur Éléazar, et devant les princes et toute l’assemblée, à l’entrée de la tente d’assignation. Elles dirent: [^2] Notre père #No 14:35; 26:64.est mort dans le désert; #No 16:1.il n’était pas au milieu de l’assemblée de ceux qui se révoltèrent contre l’Éternel, de l’assemblée de Koré, mais il est mort pour son péché, et il n’avait point de fils. [^3] Pourquoi le nom de notre père serait-il retranché du milieu de sa famille, parce qu’il n’avait point eu de fils? Donne-nous une possession parmi les frères de notre père. [^4] Moïse porta la cause devant l’Éternel. [^5] Et l’Éternel dit à Moïse: [^6] Les filles de Tselophchad ont raison. #No 36:2.Tu leur donneras en héritage une possession parmi les frères de leur père, et c’est à elles que tu feras passer l’héritage de leur père. [^7] Tu parleras aux enfants d’Israël, et tu diras: Lorsqu’un homme mourra sans laisser de fils, vous ferez passer son héritage à sa fille. [^8] S’il n’a point de fille, vous donnerez son héritage à ses frères. [^9] S’il n’a point de frères, vous donnerez son héritage aux frères de son père. [^10] S’il n’y a point de frères de son père, vous donnerez son héritage au plus proche parent dans sa famille, et c’est lui qui le possédera. Ce sera pour les enfants d’Israël une loi et un droit, comme l’Éternel l’a ordonné à Moïse. [^11] #    
        De 32:48, 49.  L’Éternel dit à Moïse: Monte sur cette montagne d’Abarim, et regarde le pays que je donne aux enfants d’Israël. [^12] Tu le regarderas; mais toi aussi, tu seras recueilli auprès de ton peuple, #No 20:24.comme Aaron, ton frère, a été recueilli; [^13] #No 20:12.parce que vous avez été rebelles à mon ordre, dans le désert de Tsin, lors de la contestation de l’assemblée, #No 20:12.et que vous ne m’avez point sanctifié à leurs yeux à l’occasion des eaux. Ce sont les eaux de contestation, à Kadès, dans le désert de Tsin. [^14] Moïse parla à l’Éternel, et dit: [^15] Que l’Éternel, #No 16:22. Hé 12:9.le Dieu des esprits de toute chair, établisse sur l’assemblée un homme [^16] qui sorte devant eux et qui entre devant eux, qui les fasse sortir et qui les fasse entrer, #1 R 22:17. Mt 9:36. Mc 6:34.afin que l’assemblée de l’Éternel ne soit pas comme des brebis qui n’ont point de berger. [^17] L’Éternel dit à Moïse: #De 3:21.Prends Josué, fils de Nun, #De 34:9.homme en qui réside l’esprit; et tu poseras ta main sur lui. [^18] Tu le placeras devant le sacrificateur Éléazar et devant toute l’assemblée, et tu lui donneras des ordres sous leurs yeux. [^19] Tu le rendras participant de ta dignité, afin que toute l’assemblée des enfants d’Israël l’écoute. [^20] Il se présentera devant le sacrificateur Éléazar, qui consultera pour lui le jugement #Ex 28:30. Lé 8:8.de l’urim devant l’Éternel; et Josué, tous les enfants d’Israël avec lui, et toute l’assemblée, sortiront sur l’ordre d’Éléazar et entreront sur son ordre. [^21] Moïse fit ce que l’Éternel lui avait ordonné. Il prit Josué, et il le plaça devant le sacrificateur Éléazar et devant toute l’assemblée. [^22] Il posa ses mains sur lui, et lui donna des ordres, comme l’Éternel l’avait dit par Moïse. [^23] 

[[Numbers - 26|<--]] Numbers - 27 [[Numbers - 28|-->]]

---
# Notes
