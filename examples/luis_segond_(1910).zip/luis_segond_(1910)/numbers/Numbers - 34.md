---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 34 - Luis Segond (1910)"
---
[[Numbers - 33|<--]] Numbers - 34 [[Numbers - 35|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Numbers]]

# Numbers - 34

L’Éternel parla à Moïse, et dit: [^1] Donne cet ordre aux enfants d’Israël, et dis-leur: Quand vous serez entrés dans le pays de Canaan, ce pays deviendra votre héritage, le pays de Canaan, dont voici les limites. [^2] #Jos 15:1.Le côté du midi commencera au désert de Tsin près d’Édom. Ainsi, votre limite méridionale partira de l’extrémité de la mer Salée, vers l’orient; [^3] elle tournera au sud de la montée d’Akrabbim, passera par Tsin, et s’étendra jusqu’au midi de Kadès-Barnéa; elle continuera par Hatsar-Addar, et passera vers Atsmon; [^4] depuis Atsmon, elle tournera jusqu’au torrent d’Égypte, pour aboutir à la mer. [^5] Votre limite occidentale sera la grande mer: ce sera votre limite à l’occident. [^6] Voici quelle sera votre limite septentrionale: à partir de la grande mer, vous la tracerez jusqu’à la montagne de Hor; [^7] depuis la montagne de Hor, vous la ferez passer par Hamath, et arriver à Tsedad; [^8] elle continuera par Ziphron, pour aboutir à Hatsar-Énan: ce sera votre limite au septentrion. [^9] Vous tracerez votre limite orientale de Hatsar-Énan à Schepham; [^10] elle descendra de Schepham vers Ribla, à l’orient d’Aïn; elle descendra, et s’étendra le long de la mer de Kinnéreth, à l’orient; [^11] elle descendra encore vers le Jourdain, pour aboutir à la mer Salée. Tel sera votre pays avec ses limites tout autour. [^12] Moïse transmit cet ordre aux enfants d’Israël, et dit: C’est là le pays que vous partagerez par le sort, et que l’Éternel a résolu de donner aux neuf tribus et à la demi-tribu. [^13] Car la tribu des fils de Ruben et la tribu des fils de Gad ont pris leur héritage, selon les maisons de leurs pères; la demi-tribu de Manassé a aussi pris son héritage. [^14] Ces deux tribus et la demi-tribu ont pris leur héritage en deçà du Jourdain, vis-à-vis de Jéricho, du côté de l’orient. [^15] L’Éternel parla à Moïse, et dit: [^16] #Jos 14:1.Voici les noms des hommes qui partageront entre vous le pays: le sacrificateur Éléazar, et Josué, fils de Nun. [^17] Vous prendrez encore un prince de chaque tribu, pour faire le partage du pays. [^18] Voici les noms de ces hommes. Pour la tribu de Juda: Caleb, fils de Jephunné; [^19] pour la tribu des fils de Siméon: Samuel, fils d’Ammihud; [^20] pour la tribu de Benjamin: Élidad, fils de Kislon; [^21] pour la tribu des fils de Dan: le prince Buki, fils de Jogli; [^22] pour les fils de Joseph, pour la tribu des fils de Manassé: le prince Hanniel, fils d’Éphod; [^23] et pour la tribu des fils d’Éphraïm: le prince Kemuel, fils de Schiphtan; [^24] pour la tribu des fils de Zabulon: le prince Élitsaphan, fils de Parnac; [^25] pour la tribu des fils d’Issacar: le prince Paltiel, fils d’Azzan; [^26] pour la tribu des fils d’Aser: le prince Ahihud, fils de Schelomi; [^27] pour la tribu des fils de Nephthali: le prince Pedahel, fils d’Ammihud. [^28] Tels sont ceux à qui l’Éternel ordonna de partager le pays de Canaan entre les enfants d’Israël. [^29] 

[[Numbers - 33|<--]] Numbers - 34 [[Numbers - 35|-->]]

---
# Notes
