---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 8 - Luis Segond (1910)"
---
[[Numbers - 7|<--]] Numbers - 8 [[Numbers - 9|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Numbers]]

# Numbers - 8

L’Éternel parla à Moïse, et dit: [^1] Parle à Aaron, et tu lui diras: Lorsque tu placeras les lampes sur le chandelier, #Ex 25:37.les sept lampes devront éclairer en face. [^2] Aaron fit ainsi; il plaça les lampes sur le devant du chandelier, comme l’Éternel l’avait ordonné à Moïse. [^3] Le chandelier était #Ex 25:37.d’or battu; jusqu’à son pied, jusqu’à ses fleurs, il était d’or battu; Moïse avait fait le chandelier d’après le modèle que l’Éternel lui avait montré. [^4] L’Éternel parla à Moïse, et dit: [^5] Prends les Lévites du milieu des enfants d’Israël, et purifie-les. [^6] Voici comment tu les purifieras. Fais sur eux une aspersion d’eau expiatoire; qu’ils fassent passer le rasoir sur tout leur corps, qu’ils lavent leurs vêtements, et qu’ils se purifient. [^7] Ils prendront ensuite un jeune taureau, avec l’offrande ordinaire de fleur de farine pétrie à l’huile; et tu prendras un autre jeune taureau pour le sacrifice d’expiation. [^8] Tu feras approcher les Lévites devant la tente d’assignation, et tu convoqueras toute l’assemblée des enfants d’Israël. [^9] Tu feras approcher les Lévites devant l’Éternel; et les enfants d’Israël poseront leurs mains sur les Lévites. [^10] Aaron fera tourner de côté et d’autre les Lévites devant l’Éternel, comme une offrande de la part des enfants d’Israël; et ils seront consacrés au service de l’Éternel. [^11] Les Lévites poseront leurs mains sur la tête des taureaux; et tu offriras l’un en sacrifice d’expiation, et l’autre en holocauste, afin de faire l’expiation pour les Lévites. [^12] Tu feras tenir les Lévites debout devant Aaron et devant ses fils, et tu les feras tourner de côté et d’autre comme une offrande à l’Éternel. [^13] Tu sépareras les Lévites du milieu des enfants d’Israël; et les Lévites #No 3:45.m’appartiendront. [^14] Après cela, les Lévites viendront faire le service dans la tente d’assignation. C’est ainsi que tu les purifieras, et que tu les feras tourner de côté et d’autre comme une offrande. [^15] Car ils me sont entièrement donnés du milieu des enfants d’Israël: je les ai pris pour moi à la place des premiers-nés, de tous les premiers-nés des enfants d’Israël. [^16] Car #No 3:13. Ex 13:2; 22:29; 34:19. Lé 27:26. Lu 2:23.tout premier-né des enfants d’Israël m’appartient, tant des hommes que des animaux; le jour où j’ai frappé tous les premiers-nés dans le pays d’Égypte, je me les suis consacrés. [^17] #No 3:12.Et j’ai pris les Lévites à la place de tous les premiers-nés des enfants d’Israël. [^18] J’ai donné les Lévites entièrement à Aaron et à ses fils, du milieu des enfants d’Israël, pour qu’ils fassent le service des enfants d’Israël dans la tente d’assignation, pour qu’ils fassent l’expiation pour les enfants d’Israël, et pour que les enfants d’Israël ne soient frappés d’aucune plaie, en s’approchant du sanctuaire. [^19] Moïse, Aaron et toute l’assemblée des enfants d’Israël, firent à l’égard des Lévites tout ce que l’Éternel avait ordonné à Moïse touchant les Lévites; ainsi firent à leur égard les enfants d’Israël. [^20] Les Lévites se purifièrent, et lavèrent leurs vêtements; Aaron les fit tourner de côté et d’autre comme une offrande devant l’Éternel, et il fit l’expiation pour eux, afin de les purifier. [^21] Après cela, les Lévites vinrent faire leur service dans la tente d’assignation, en présence d’Aaron et de ses fils, selon ce que l’Éternel avait ordonné à Moïse touchant les Lévites; ainsi fut-il fait à leur égard. [^22] L’Éternel parla à Moïse, et dit: [^23] Voici ce qui concerne les Lévites. Depuis l’âge de vingt-cinq ans et au-dessus, tout Lévite entrera au service de la tente d’assignation pour y exercer une fonction. [^24] Depuis l’âge de cinquante ans, il sortira de fonction, et ne servira plus. [^25] Il aidera ses frères dans la tente d’assignation, pour garder ce qui est remis à leurs soins; mais il ne fera plus de service. Tu agiras ainsi à l’égard des Lévites pour ce qui concerne leurs fonctions. [^26] 

[[Numbers - 7|<--]] Numbers - 8 [[Numbers - 9|-->]]

---
# Notes
