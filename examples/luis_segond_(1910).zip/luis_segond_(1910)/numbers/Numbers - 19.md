---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 19 - Luis Segond (1910)"
---
[[Numbers - 18|<--]] Numbers - 19 [[Numbers - 20|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Numbers]]

# Numbers - 19

L’Éternel parla à Moïse et à Aaron, et dit: [^1] Voici ce qui est ordonné par la loi que l’Éternel a prescrite, en disant: Parle aux enfants d’Israël, et qu’ils t’amènent une vache rousse, sans tache, sans défaut corporel, et qui n’ait point porté le joug. [^2] Vous la remettrez au sacrificateur Éléazar, qui la fera #Hé 13:11, 12.sortir du camp, et on l’égorgera devant lui. [^3] Le sacrificateur Éléazar prendra du #Hé 9:13.sang de la vache avec le doigt, et il en fera sept fois l’aspersion sur le devant de la tente d’assignation. [^4] On brûlera la vache sous ses yeux; on brûlera #Ex 29:14. Lé 4:11, 12.sa peau, sa chair et son sang, avec ses excréments. [^5] Le sacrificateur prendra du bois de cèdre, de l’hysope et du cramoisi, et il les jettera au milieu des flammes qui consumeront la vache. [^6] Le sacrificateur lavera ses vêtements, et lavera son corps dans l’eau; puis il rentrera dans le camp, et sera impur jusqu’au soir. [^7] Celui qui aura brûlé la vache lavera ses vêtements dans l’eau, et lavera son corps dans l’eau; et il sera impur jusqu’au soir. [^8] Un homme pur recueillera la cendre de la vache, et la déposera hors du camp, dans un lieu pur; on la conservera pour l’assemblée des enfants d’Israël, afin d’en faire l’eau de purification. C’est une eau expiatoire. [^9] Celui qui aura recueilli la cendre de la vache lavera ses vêtements, et sera impur jusqu’au soir. Ce sera une loi perpétuelle pour les enfants d’Israël et pour l’étranger en séjour au milieu d’eux. [^10] #No 31:19. Ag 2:14.Celui qui touchera un mort, un corps humain quelconque, sera impur pendant sept jours. [^11] Il se purifiera avec cette eau le troisième jour et le septième jour, et il sera pur; mais, s’il ne se purifie pas le troisième jour et le septième jour, il ne sera pas pur. [^12] Celui qui touchera un mort, le corps d’un homme qui sera mort, et qui ne se purifiera pas, souille le tabernacle de l’Éternel; celui-là sera retranché d’Israël. Comme l’eau de purification n’a pas été répandue sur lui, il est impur, et son impureté est encore sur lui. [^13] Voici la loi. Lorsqu’un homme mourra dans une tente, quiconque entrera dans la tente, et quiconque se trouvera dans la tente, sera impur pendant sept jours. [^14] Tout vase découvert, sur lequel il n’y aura point de couvercle attaché, sera impur. [^15] Quiconque touchera, dans les champs, un homme tué par l’épée, ou un mort, ou des ossements humains, ou un sépulcre, sera impur pendant sept jours. [^16] On prendra, pour celui qui est impur, de la cendre de la victime expiatoire qui a été brûlée, et on mettra dessus de l’eau vive dans un vase. [^17] Un homme pur prendra #Ps 51:9.de l’hysope, et la trempera dans l’eau; puis il en fera l’aspersion sur la tente, sur tous les ustensiles, sur les personnes qui sont là, sur celui qui a touché des ossements, ou un homme tué, ou un mort, ou un sépulcre. [^18] Celui qui est pur fera l’aspersion sur celui qui est impur, le troisième jour et le septième jour, et il le purifiera le septième jour. Il lavera ses vêtements, et se lavera dans l’eau; et le soir, il sera pur. [^19] Un homme qui sera impur, et qui ne se purifiera pas, sera retranché du milieu de l’assemblée, car il a souillé le sanctuaire de l’Éternel; comme l’eau de purification n’a pas été répandue sur lui, il est impur. [^20] Ce sera pour eux une loi perpétuelle. Celui qui fera l’aspersion de l’eau de purification lavera ses vêtements, et celui qui touchera l’eau de purification sera impur jusqu’au soir. [^21] Tout ce que touchera celui qui est impur sera souillé, et la personne qui le touchera sera impure jusqu’au soir. [^22] 

[[Numbers - 18|<--]] Numbers - 19 [[Numbers - 20|-->]]

---
# Notes
