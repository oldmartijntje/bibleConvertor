---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 28 - Luis Segond (1910)"
---
[[Numbers - 27|<--]] Numbers - 28 [[Numbers - 29|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Numbers]]

# Numbers - 28

L’Éternel parla à Moïse, et dit: Donne cet ordre aux enfants d’Israël, et dis-leur: [^1] Vous aurez soin de me présenter, au temps fixé, mon offrande, l’aliment de mes sacrifices consumés par le feu, et qui me sont d’une agréable odeur. [^2] Tu leur diras: Voici le sacrifice consumé par le feu que vous offrirez à l’Éternel: chaque jour, #Ex 29:38.deux agneaux d’un an sans défaut, comme holocauste perpétuel. [^3] Tu offriras l’un des agneaux le matin, et l’autre agneau entre les deux soirs, [^4] et, #Ex 16:36.pour l’offrande, #Lé 2:1.un dixième d’épha de fleur de farine pétrie dans un quart de #Ex 29:40.hin d’huile d’olives concassées. [^5] C’est l’holocauste perpétuel, qui a été offert à la montagne de Sinaï; c’est un sacrifice consumé par le feu, d’une agréable odeur à l’Éternel. [^6] La libation sera d’un quart de hin pour chaque agneau: c’est dans le lieu saint que tu feras la libation de vin à l’Éternel. [^7] Tu offriras le second agneau entre les deux soirs, avec une offrande et une libation semblables à celles du matin; c’est un sacrifice consumé par le feu, d’une agréable odeur à l’Éternel. [^8] Le jour du sabbat, vous offrirez deux agneaux d’un an sans défaut, et, pour l’offrande, deux dixièmes de fleur de farine pétrie à l’huile, avec la libation. [^9] C’est l’holocauste du sabbat, pour chaque sabbat, outre l’holocauste perpétuel et la libation. [^10] Au commencement de vos mois, vous offrirez en holocauste à l’Éternel deux jeunes taureaux, un bélier, et sept agneaux d’un an sans défaut; [^11] et, comme offrande pour chaque taureau, trois dixièmes de fleur de farine pétrie à l’huile; comme offrande pour le bélier, deux dixièmes de fleur de farine pétrie à l’huile; [^12] comme offrande pour chaque agneau, un dixième de fleur de farine pétrie à l’huile. C’est un holocauste, un sacrifice consumé par le feu, d’une agréable odeur à l’Éternel. [^13] Les libations seront d’un demi-hin de vin pour un taureau, d’un tiers de hin pour un bélier, et d’un quart de hin pour un agneau. C’est l’holocauste du commencement du mois, pour chaque mois, pour tous les mois de l’année. [^14] On offrira à l’Éternel un bouc, en sacrifice d’expiation, outre l’holocauste perpétuel et la libation. [^15] #    
        Ex 12:18; 23:15. Lé 23:5.  Le premier mois, le quatorzième jour du mois, ce sera la Pâque de l’Éternel. [^16] Le quinzième jour de ce mois sera un jour de fête. On mangera pendant sept jours des pains sans levain. [^17] #Lé 23:7.Le premier jour, il y aura une sainte convocation: vous ne ferez aucune œuvre servile. [^18] Vous offrirez en holocauste à l’Éternel un sacrifice consumé par le feu: deux jeunes taureaux, un bélier, et sept agneaux d’un an sans défaut. [^19] Vous y joindrez l’offrande de fleur de farine pétrie à l’huile, trois dixièmes pour un taureau, deux dixièmes pour un bélier, [^20] et un dixième pour chacun des sept agneaux. [^21] Vous offrirez un bouc en sacrifice d’expiation, afin de faire pour vous l’expiation. [^22] Vous offrirez ces sacrifices, outre l’holocauste du matin, qui est un holocauste perpétuel. [^23] Vous les offrirez chaque jour, pendant sept jours, comme l’aliment d’un sacrifice consumé par le feu, d’une agréable odeur à l’Éternel. On les offrira, outre l’holocauste perpétuel et la libation. [^24] Le septième jour, vous aurez une sainte convocation: vous ne ferez aucune œuvre servile. [^25] Le jour des prémices, où vous présenterez à l’Éternel une offrande, à votre fête des semaines, vous aurez une sainte convocation: vous ne ferez aucune œuvre servile. [^26] Vous offrirez en holocauste, d’une agréable odeur à l’Éternel, deux jeunes taureaux, un bélier, et sept agneaux d’un an. [^27] Vous y joindrez l’offrande de fleur de farine pétrie à l’huile, trois dixièmes pour chaque taureau, deux dixièmes pour le bélier, [^28] et un dixième pour chacun des sept agneaux. [^29] Vous offrirez un bouc, afin de faire pour vous l’expiation. [^30] Vous offrirez ces sacrifices, outre l’holocauste perpétuel et l’offrande. Vous aurez des agneaux sans défaut, et vous joindrez les libations. [^31] 

[[Numbers - 27|<--]] Numbers - 28 [[Numbers - 29|-->]]

---
# Notes
