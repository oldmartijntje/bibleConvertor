---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 4 - Luis Segond (1910)"
---
[[Joshua - 3|<--]] Joshua - 4 [[Joshua - 5|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Joshua]]

# Joshua - 4

Lorsque toute la nation eut achevé de passer le Jourdain, l’Éternel #Jos 3:12.dit à Josué: [^1] Prenez douze hommes parmi le peuple, un homme de chaque tribu. [^2] Donnez-leur cet ordre: Enlevez d’ici, du milieu du Jourdain, de la place où les sacrificateurs se sont arrêtés de pied ferme, douze pierres, que vous emporterez avec vous, et que vous déposerez dans le lieu où vous passerez cette nuit. [^3] Josué appela les douze hommes qu’il choisit parmi les enfants d’Israël, un homme de chaque tribu. [^4] Il leur dit: Passez devant l’arche de l’Éternel, votre Dieu, au milieu du Jourdain, et que chacun de vous charge une pierre sur son épaule, selon le nombre des tribus des enfants d’Israël, [^5] afin que cela soit un signe au milieu de vous. Lorsque vos enfants demanderont un jour: Que signifient pour vous ces pierres? [^6] vous leur direz: #Jos 3:13.Les eaux du Jourdain ont été coupées devant l’arche de l’alliance de l’Éternel; lorsqu’elle passa le Jourdain, les eaux du Jourdain ont été coupées, et ces pierres seront à jamais un souvenir pour les enfants d’Israël. [^7] Les enfants d’Israël firent ce que Josué leur avait ordonné. Ils enlevèrent douze pierres du milieu du Jourdain, comme l’Éternel l’avait dit à Josué, selon le nombre des tribus des enfants d’Israël, ils les emportèrent avec eux, et les déposèrent dans le lieu où ils devaient passer la nuit. [^8] Josué dressa aussi douze pierres au milieu du Jourdain, à la place où s’étaient arrêtés les pieds des sacrificateurs qui portaient l’arche de l’alliance; et elles y sont restées jusqu’à ce jour. [^9] Les sacrificateurs qui portaient l’arche se tinrent au milieu du Jourdain jusqu’à l’entière exécution de ce que l’Éternel avait ordonné à Josué de dire au peuple, selon tout ce que Moïse avait prescrit à Josué. Et le peuple se hâta de passer. [^10] Lorsque tout le peuple eut achevé de passer, l’arche de l’Éternel et les sacrificateurs passèrent devant le peuple. [^11] #No 32:20, 29.Les fils de Ruben, les fils de Gad, et la demi-tribu de Manassé, passèrent en armes devant les enfants d’Israël, comme Moïse le leur avait dit. [^12] Environ quarante mille hommes, équipés pour la guerre et prêts à combattre, passèrent devant l’Éternel dans les plaines de Jéricho. [^13] #Jos 3:7.En ce jour-là, l’Éternel éleva Josué aux yeux de tout Israël; et ils le craignirent, comme ils avaient craint Moïse, tous les jours de sa vie. [^14] L’Éternel dit à Josué: [^15] Ordonne aux sacrificateurs qui portent l’arche du témoignage de sortir du Jourdain. [^16] Et Josué donna cet ordre aux sacrificateurs: Sortez du Jourdain. [^17] Lorsque les sacrificateurs qui portaient l’arche de l’alliance de l’Éternel furent sortis du milieu du Jourdain, et que la plante de leurs pieds se posa sur le sec, les eaux du Jourdain retournèrent à leur place, et se répandirent comme auparavant sur tous ses bords. [^18] Le peuple sortit du Jourdain le dixième jour du premier mois, et il campa à Guilgal, à l’extrémité orientale de Jéricho. [^19] Josué dressa à Guilgal les douze pierres qu’ils avaient prises du Jourdain. [^20] Il dit aux enfants d’Israël: Lorsque vos enfants demanderont un jour à leurs pères: Que signifient ces pierres? [^21] vous en instruirez vos enfants, et vous direz: Israël a passé ce Jourdain à sec. [^22] Car l’Éternel, votre Dieu, a mis à sec devant vous les eaux du Jourdain jusqu’à ce que vous eussiez passé, #Ex 14:21.comme l’Éternel, votre Dieu, l’avait fait à la mer Rouge, qu’il mit à sec devant nous jusqu’à ce que nous eussions passé, [^23] afin que tous les peuples de la terre sachent que la main de l’Éternel est puissante, et afin que vous ayez toujours la crainte de l’Éternel, votre Dieu. [^24] 

[[Joshua - 3|<--]] Joshua - 4 [[Joshua - 5|-->]]

---
# Notes
