---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 20 - Luis Segond (1910)"
---
[[Joshua - 19|<--]] Joshua - 20 [[Joshua - 21|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Joshua]]

# Joshua - 20

L’Éternel parla à Josué, et dit: [^1] Parle aux enfants d’Israël, et dis: Établissez-vous, #Ex 21:13. No 35:6. De 19:1, 2.comme je vous l’ai ordonné par Moïse, des villes de refuge, [^2] où pourra s’enfuir le meurtrier qui aura tué quelqu’un involontairement, sans intention; elles vous serviront de refuge contre le vengeur du sang. [^3] #No 35:22, 23. De 19:4, 5.Le meurtrier s’enfuira vers l’une de ces villes, s’arrêtera à l’entrée de la porte de la ville, et exposera son cas aux anciens de cette ville; ils le recueilleront auprès d’eux dans la ville, et lui donneront une demeure, afin qu’il habite avec eux. [^4] Si le vengeur du sang le poursuit, ils ne livreront point le meurtrier entre ses mains; car c’est sans le vouloir qu’il a tué son prochain, et sans avoir été auparavant son ennemi. [^5] Il restera dans cette ville jusqu’à ce qu’il ait comparu devant l’assemblée pour être jugé, jusqu’à la mort du souverain sacrificateur alors en fonctions. A cette époque, le meurtrier s’en retournera et rentrera dans sa ville et dans sa maison, dans la ville d’où il s’était enfui. [^6] Ils consacrèrent Kédesch, en Galilée, dans la montagne de Nephthali; Sichem, dans la montagne d’Éphraïm; et Kirjath-Arba, qui est Hébron, dans la montagne de Juda. [^7] Et de l’autre côté du Jourdain, à l’orient de Jéricho, ils choisirent #De 4:43.Betser, dans le désert, dans la plaine, dans la tribu de Ruben; Ramoth, en Galaad, dans la tribu de Gad; et Golan, en Basan, dans la tribu de Manassé. [^8] Telles furent les villes désignées pour tous les enfants d’Israël et pour l’étranger en séjour au milieu d’eux, afin que celui qui aurait tué quelqu’un involontairement pût s’y réfugier, et qu’il ne mourût pas de la main du vengeur du sang avant d’avoir comparu devant l’assemblée. [^9] 

[[Joshua - 19|<--]] Joshua - 20 [[Joshua - 21|-->]]

---
# Notes
