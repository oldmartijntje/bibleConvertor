---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 16 - Luis Segond (1910)"
---
[[Joshua - 15|<--]] Joshua - 16 [[Joshua - 17|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Joshua]]

# Joshua - 16

La part échue par le sort aux fils de Joseph s’étendait depuis le Jourdain près de Jéricho, vers les eaux de Jéricho, à l’orient. La limite suivait le désert qui s’élève de Jéricho à Béthel par la montagne. [^1] Elle continuait de Béthel à Luz, et passait vers la frontière des Arkiens par Atharoth. [^2] Puis elle descendait à l’occident vers la frontière des Japhléthiens jusqu’à celle de Beth-Horon la basse et jusqu’à Guézer, pour aboutir à la mer. [^3] C’est là que reçurent leur héritage les fils de Joseph, Manassé et Éphraïm. [^4] Voici les limites des fils d’Éphraïm, selon leurs familles. La limite de leur héritage était, à l’orient, Atharoth-Addar jusqu’à Beth-Horon la haute. [^5] Elle continuait du côté de l’occident vers Micmethath au nord, tournait à l’orient vers Thaanath-Silo, et passait dans la direction de l’orient par Janoach. [^6] De Janoach elle descendait à Atharoth et à Naaratha, touchait à Jéricho, et se prolongeait jusqu’au Jourdain. [^7] De Tappuach elle allait vers l’occident au torrent de Kana, pour aboutir à la mer. Tel fut l’héritage de la tribu des fils d’Éphraïm, selon leurs familles. [^8] Les fils d’Éphraïm avaient aussi des villes séparées au milieu de l’héritage des fils de Manassé, toutes avec leurs villages. [^9] Ils ne chassèrent point les Cananéens qui habitaient à Guézer, et les Cananéens ont habité au milieu d’Éphraïm jusqu’à ce jour, mais ils furent assujettis à un tribut. [^10] 

[[Joshua - 15|<--]] Joshua - 16 [[Joshua - 17|-->]]

---
# Notes
