---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 11 - Luis Segond (1910)"
---
[[Joshua - 10|<--]] Joshua - 11 [[Joshua - 12|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Joshua]]

# Joshua - 11

Jabin, roi de Hatsor, ayant appris ces choses, envoya des messagers à Jobab, roi de Madon, au roi de Schimron, au roi d’Acschaph, [^1] aux rois qui étaient au nord dans la montagne, dans la plaine au midi de Kinnéreth, dans la vallée, et sur les hauteurs de Dor à l’occident, [^2] aux Cananéens de l’orient et de l’occident, aux Amoréens, aux Héthiens, aux Phéréziens, aux Jébusiens dans la montagne, et aux Héviens au pied de l’Hermon dans le pays de Mitspa. [^3] Ils sortirent, eux et toutes leurs armées avec eux, formant un peuple innombrable comme le sable qui est sur le bord de la mer, et ayant des chevaux et des chars en très grande quantité. [^4] Tous ces rois fixèrent un lieu de réunion, et vinrent camper ensemble près des eaux de Mérom, pour combattre contre Israël. [^5] L’Éternel dit à Josué: Ne les crains point, car demain, à ce moment-ci, je les livrerai tous frappés devant Israël. Tu couperas les jarrets à leurs chevaux, et tu brûleras au feu leurs chars. [^6] Josué, avec tous ses gens de guerre, arriva subitement sur eux près des eaux de Mérom, et ils se précipitèrent au milieu d’eux. [^7] L’Éternel les livra entre les mains d’Israël; ils les battirent et les poursuivirent jusqu’à Sidon la grande, jusqu’à Misrephoth-Maïm, et jusqu’à la vallée de Mitspa vers l’orient; ils les battirent, sans en laisser échapper aucun. [^8] Josué les traita comme l’Éternel lui avait dit; il coupa les jarrets à leurs chevaux, et il brûla leurs chars au feu. [^9] A son retour, et dans le même temps, Josué prit Hatsor, et frappa son roi avec l’épée: Hatsor était autrefois la principale ville de tous ces royaumes. [^10] On frappa du tranchant de l’épée et l’on dévoua par interdit tous ceux qui s’y trouvaient, il ne resta rien de ce qui respirait, et l’on mit le feu à Hatsor. [^11] Josué prit aussi toutes les villes de ces rois et tous leurs rois, et il les frappa du tranchant de l’épée, et il les dévoua par interdit, #De 20:16, 17. Jos 10:40.comme l’avait ordonné Moïse, serviteur de l’Éternel. [^12] Mais Israël ne brûla aucune des villes situées sur des collines, à l’exception seulement de Hatsor, qui fut brûlée par Josué. [^13] Les enfants d’Israël gardèrent pour eux tout le butin de ces villes et le bétail; mais ils frappèrent du tranchant de l’épée tous les hommes, jusqu’à ce qu’ils les eussent détruits, sans rien laisser de ce qui respirait. [^14] Josué exécuta #Ex 23:32, 33; 34:12. No 33:52.les ordres de l’Éternel à Moïse, son serviteur, et #De 7:2; 20:16.de Moïse à Josué; il ne négligea rien de tout ce que l’Éternel avait ordonné à Moïse. [^15] C’est ainsi que Josué s’empara de tout ce pays, de la montagne, de tout le midi, de tout le pays de Gosen, de la vallée, de la plaine, de la montagne d’Israël et de ses vallées, [^16] depuis la montagne nue qui s’élève vers Séir jusqu’à Baal-Gad, dans la vallée du Liban, au pied de la montagne d’Hermon. Il prit tous leurs rois, les frappa et les fit mourir. [^17] La guerre que soutint Josué contre tous ces rois fut de longue durée. [^18] Il n’y eut aucune ville qui fît la paix avec les enfants d’Israël, excepté Gabaon, habitée par les Héviens; ils les prirent toutes en combattant. [^19] Car l’Éternel permit que ces peuples s’obstinassent à faire la guerre contre Israël, afin qu’Israël les dévouât par interdit, sans qu’il y eût pour eux de miséricorde, et qu’il les détruisît, comme l’Éternel l’avait ordonné à Moïse. [^20] Dans le même temps, Josué se mit en marche, et il extermina les Anakim de la montagne d’Hébron, de Debir, d’Anab, de toute la montagne de Juda et de toute la montagne d’Israël; Josué les dévoua par interdit, avec leurs villes. [^21] Il ne resta point d’Anakim dans le pays des enfants d’Israël; il n’en resta qu’à Gaza, à Gath et à Asdod. [^22] Josué s’empara donc de tout le pays, selon tout ce que l’Éternel avait dit à Moïse. Et Josué le donna en héritage à Israël, à chacun sa portion, d’après leurs tribus. Puis, le pays fut en repos et sans guerre. [^23] 

[[Joshua - 10|<--]] Joshua - 11 [[Joshua - 12|-->]]

---
# Notes
