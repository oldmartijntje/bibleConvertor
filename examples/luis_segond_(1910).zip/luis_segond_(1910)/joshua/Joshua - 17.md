---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 17 - Luis Segond (1910)"
---
[[Joshua - 16|<--]] Joshua - 17 [[Joshua - 18|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Joshua]]

# Joshua - 17

Une part échut aussi par le sort à la tribu de Manassé, car il était le premier-né de Joseph. #Ge 46:20.Makir, premier-né de Manassé et père de Galaad, avait eu Galaad et Basan, parce qu’il était un homme de guerre. [^1] On donna par le sort une part aux autres fils de Manassé, selon leurs familles, aux fils d’Abiézer, aux fils de Hélek, aux fils d’Asriel, aux fils de Sichem, aux fils de Hépher, aux fils de Schemida: ce sont là les enfants mâles de Manassé, fils de Joseph, selon leurs familles. [^2] #No 26:33; 27:1.Tselophchad, fils de Hépher, fils de Galaad, fils de Makir, fils de Manassé, n’eut point de fils, mais il eut des filles #No 27:1.dont voici les noms: Machla, Noa, Hogla, Milca et Thirtsa. [^3] Elles se présentèrent devant le sacrificateur Éléazar, devant Josué, fils de Nun, et devant les princes, en disant: #No 27:7; 36:2.L’Éternel a commandé à Moïse de nous donner un héritage parmi nos frères. Et on leur donna, selon l’ordre de l’Éternel, un héritage parmi les frères de leur père. [^4] Il échut dix portions à Manassé, outre le pays de Galaad et de Basan, qui est de l’autre côté du Jourdain. [^5] Car les filles de Manassé eurent un héritage parmi ses fils, et le pays de Galaad fut pour les autres fils de Manassé. [^6] La limite de Manassé s’étendait d’Aser à Micmethath, qui est près de Sichem, et allait à Jamin vers les habitants d’En-Tappuach. [^7] Le pays de Tappuach était aux fils de Manassé, mais Tappuach sur la frontière de Manassé était aux fils d’Éphraïm. [^8] La limite descendait au torrent de Kana, au midi du torrent. Ces villes étaient à Éphraïm, au milieu des villes de Manassé. La limite de Manassé au nord du torrent aboutissait à la mer. [^9] Le territoire du midi était à Éphraïm, celui du nord à Manassé, et la mer leur servait de limite; ils touchaient à Aser vers le nord, et à Issacar vers l’orient. [^10] Manassé possédait dans Issacar et dans Aser: Beth-Schean et les villes de son ressort, Jibleam et les villes de son ressort, les habitants de Dor et les villes de son ressort, les habitants d’En-Dor et les villes de son ressort, les habitants de Thaanac et les villes de son ressort, et les habitants de Meguiddo et les villes de son ressort, trois contrées. [^11] #Jg 1:27.Les fils de Manassé ne purent pas prendre possession de ces villes, et les Cananéens voulurent rester dans ce pays. [^12] Lorsque les enfants d’Israël furent assez forts, ils assujettirent les Cananéens à un tribut, mais ils ne les chassèrent point. [^13] Les fils de Joseph parlèrent à Josué, et dirent: Pourquoi nous as-tu donné en héritage un seul lot, une seule part, tandis que nous formons un peuple nombreux et que l’Éternel nous a bénis jusqu’à présent? [^14] Josué leur dit: Si vous êtes un peuple nombreux, montez à la forêt, et vous l’abattrez pour vous y faire de la place dans le pays des Phéréziens et des Rephaïm, puisque la montagne d’Éphraïm est trop étroite pour vous. [^15] Les fils de Joseph dirent: La montagne ne nous suffira pas, et il y a des chars de fer chez tous les Cananéens qui habitent la vallée, chez ceux qui sont à Beth-Schean et dans les villes de son ressort, et chez ceux qui sont dans la vallée de Jizreel. [^16] Josué dit à la maison de Joseph, à Éphraïm et à Manassé: Vous êtes un peuple nombreux, et votre force est grande, vous n’aurez pas un simple lot. [^17] Mais vous aurez la montagne, car c’est une forêt que vous abattrez et dont les issues seront à vous, et vous chasserez les Cananéens, malgré leurs chars de fer et malgré leur force. [^18] 

[[Joshua - 16|<--]] Joshua - 17 [[Joshua - 18|-->]]

---
# Notes
