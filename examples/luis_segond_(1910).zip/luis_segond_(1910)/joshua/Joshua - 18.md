---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 18 - Luis Segond (1910)"
---
[[Joshua - 17|<--]] Joshua - 18 [[Joshua - 19|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Joshua]]

# Joshua - 18

Toute l’assemblée des enfants d’Israël se réunit à Silo, et ils y placèrent la tente d’assignation. Le pays était soumis devant eux. [^1] Il restait sept tribus des enfants d’Israël qui n’avaient pas encore reçu leur héritage. [^2] Josué dit aux enfants d’Israël: Jusques à quand négligerez-vous de prendre possession du pays que l’Éternel, le Dieu de vos pères, vous a donné? [^3] Choisissez trois hommes par tribu, et je les ferai partir. Ils se lèveront, parcourront le pays, traceront un plan en vue du partage, et reviendront auprès de moi. [^4] Ils le diviseront en sept parts; Juda restera dans ses limites au midi, et la maison de Joseph restera dans ses limites au nord. [^5] Vous donc, vous tracerez un plan du pays en sept parts, et vous me l’apporterez ici. Je jetterai pour vous le sort devant l’Éternel, notre Dieu. [^6] Mais il n’y aura point de part pour les Lévites au milieu de vous, car le sacerdoce de l’Éternel est leur héritage; et Gad, Ruben et la demi-tribu de Manassé ont reçu leur héritage, que Moïse, serviteur de l’Éternel, leur a donné de l’autre côté du Jourdain, à l’orient. [^7] Lorsque ces hommes se levèrent et partirent pour tracer un plan du pays, Josué leur donna cet ordre: Allez, parcourez le pays, tracez-en un plan, et revenez auprès de moi; puis je jetterai pour vous le sort devant l’Éternel, à Silo. [^8] Ces hommes partirent, parcoururent le pays, et en tracèrent d’après les villes un plan en sept parts, dans un livre; et ils revinrent auprès de Josué dans le camp à Silo. [^9] Josué jeta pour eux le sort à Silo devant l’Éternel, et il fit le partage du pays entre les enfants d’Israël, en donnant à chacun sa portion. [^10] Le sort tomba sur la tribu des fils de Benjamin, selon leurs familles, et la part qui leur échut par le sort avait ses limites entre les fils de Juda et les fils de Joseph. [^11] Du côté septentrional, leur limite partait du Jourdain. Elle montait au nord de Jéricho, s’élevait dans la montagne vers l’occident, et #Jos 7:2.aboutissait au désert de Beth-Aven. [^12] Elle passait de là par Luz, au midi de Luz, qui est Béthel, et elle descendait à Atharoth-Addar par-dessus la montagne qui est au midi de Beth-Horon la basse. [^13] Du côté occidental, la limite se prolongeait et tournait au midi depuis la montagne qui est vis-à-vis de Beth-Horon; elle continuait vers le midi, et aboutissait à Kirjath-Baal, qui est Kirjath-Jearim, ville des fils de Juda. C’était le côté occidental. [^14] Le côté méridional commençait à l’extrémité de Kirjath-Jearim. La limite se prolongeait vers l’occident jusqu’à la source des eaux de Nephthoach. [^15] Elle descendait à l’extrémité de la montagne qui est vis-à-vis de la vallée de Ben-Hinnom, dans la vallée des Rephaïm au nord. #Jos 15:8.Elle descendait par la vallée de Hinnom, sur le côté méridional des Jébusiens, #Jos 15:7.jusqu’à En-Roguel. [^16] Elle se dirigeait vers le nord à En-Schémesch, puis à Gueliloth, qui est vis-à-vis de la montée d’Adummim, et #Jos 15:6.elle descendait à la pierre de Bohan, fils de Ruben. [^17] Elle passait sur le côté septentrional en face d’Araba, descendait à Araba, [^18] et continuait sur le côté septentrional de Beth-Hogla, pour aboutir à la langue septentrionale de la mer Salée, vers l’embouchure du Jourdain au midi. C’était la limite méridionale. [^19] Du côté oriental, le Jourdain formait la limite. Tel fut l’héritage des fils de Benjamin, selon leurs familles, avec ses limites de tous les côtés. [^20] Les villes de la tribu des fils de Benjamin, selon leurs familles, étaient: Jéricho, Beth-Hogla, Émek-Ketsits, [^21] Beth-Araba, Tsemaraïm, Béthel, [^22] Avvim, Para, Ophra, [^23] Kephar-Ammonaï, Ophni et Guéba; douze villes, et leurs villages. [^24] Gabaon, Rama, Beéroth, [^25] Mitspé, Kephira, Motsa, [^26] Rékem, Jirpeel, Thareala, [^27] Tséla, Éleph, Jebus, qui est Jérusalem, Guibeath, et Kirjath; quatorze villes, et leurs villages. Tel fut l’héritage des fils de Benjamin, selon leurs familles. [^28] 

[[Joshua - 17|<--]] Joshua - 18 [[Joshua - 19|-->]]

---
# Notes
