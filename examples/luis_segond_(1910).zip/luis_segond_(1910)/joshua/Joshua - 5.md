---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 5 - Luis Segond (1910)"
---
[[Joshua - 4|<--]] Joshua - 5 [[Joshua - 6|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Joshua]]

# Joshua - 5

Lorsque tous les rois des Amoréens à l’occident du Jourdain et tous les rois des Cananéens près de la mer apprirent que l’Éternel avait mis à sec les eaux du Jourdain devant les enfants d’Israël jusqu’à ce que nous eussions passé, ils perdirent courage et furent consternés à l’aspect des enfants d’Israël. [^1] En ce temps-là, l’Éternel dit à Josué: #Ex 4:25.Fais-toi des couteaux de pierre, et circoncis de nouveau les enfants d’Israël, une seconde fois. [^2] Josué se fit des couteaux de pierre, et il circoncit les enfants d’Israël sur la colline d’Araloth. [^3] Voici la raison pour laquelle Josué les circoncit. Tout le peuple sorti d’Égypte, les mâles, tous les hommes de guerre, étaient morts dans le désert, pendant la route, après leur sortie d’Égypte. [^4] Tout ce peuple sorti d’Égypte était circoncis; mais tout le peuple né dans le désert, pendant la route, après la sortie d’Égypte, n’avait point été circoncis. [^5] Car les enfants d’Israël avaient marché quarante ans dans le désert jusqu’à la destruction de toute la nation des hommes de guerre qui étaient sortis d’Égypte et qui n’avaient point écouté la voix de l’Éternel; l’Éternel leur jura de ne pas #No 14:23.leur faire voir le pays qu’il avait juré à leurs pères de nous donner, pays où coulent le lait et le miel. [^6] Ce sont leurs enfants qu’il établit à leur place; et Josué les circoncit, car ils étaient incirconcis, parce qu’on ne les avait point circoncis pendant la route. [^7] Lorsqu’on eut achevé de circoncire toute la nation, ils restèrent à leur place dans le camp jusqu’à leur guérison. [^8] L’Éternel dit à Josué: Aujourd’hui, j’ai roulé de dessus vous l’opprobre de l’Égypte. Et ce lieu fut appelé du nom de Guilgal jusqu’à ce jour. [^9] Les enfants d’Israël campèrent à Guilgal; et ils célébrèrent la Pâque #Ex 12:6.le quatorzième jour du mois, sur le soir, dans les plaines de Jéricho. [^10] Ils mangèrent du blé du pays le lendemain de la Pâque, #Ex 12:39. Lé 2:14.des pains sans levain et du grain rôti; ils en mangèrent ce même jour. [^11] La manne cessa le lendemain de la Pâque, quand ils mangèrent du blé du pays; les enfants d’Israël n’eurent plus de manne, et ils mangèrent des produits du pays de Canaan cette année-là. [^12] Comme Josué était près de Jéricho, il leva les yeux, et regarda. Voici, #És 23:23.un homme se tenait debout devant lui, son épée nue dans la main. Il alla vers lui, et lui dit: Es-tu des nôtres ou de nos ennemis? [^13] Il répondit: Non, mais je suis le chef de l’armée de l’Éternel, j’arrive maintenant. Josué tomba le visage contre terre, se prosterna, et lui dit: Qu’est-ce que mon seigneur dit à son serviteur? [^14] Et le chef de l’armée de l’Éternel dit à Josué: Ote tes souliers de tes pieds, car le lieu sur lequel tu te tiens est saint. Et Josué fit ainsi. [^15] 

[[Joshua - 4|<--]] Joshua - 5 [[Joshua - 6|-->]]

---
# Notes
