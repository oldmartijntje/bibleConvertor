---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 1 - Luis Segond (1910)"
---
Joshua - 1 [[Joshua - 2|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Joshua]]

# Joshua - 1

Après #De 34:5.la mort de Moïse, serviteur de l’Éternel, l’Éternel dit à Josué, fils de Nun, #De 1:38.serviteur de Moïse: [^1] Moïse, mon serviteur, est mort; maintenant, lève-toi, passe ce Jourdain, toi et tout ce peuple, pour entrer dans le pays que je donne aux enfants d’Israël. [^2] #De 11:24. Jos 14:9.Tout lieu que foulera la plante de votre pied, je vous le donne, comme je l’ai dit à Moïse. [^3] Vous aurez pour territoire depuis le désert et le Liban jusqu’au grand fleuve, le fleuve de l’Euphrate, tout le pays des Héthiens, et jusqu’à la grande mer vers le soleil couchant. [^4] Nul ne tiendra devant toi, tant que tu vivras. Je serai avec toi, comme j’ai été avec Moïse; #De 31:6, 8. Hé 13:5, 6.je ne te délaisserai point, je ne t’abandonnerai point. [^5] #De 31:23.Fortifie-toi et prends courage, car c’est toi qui mettras ce peuple en possession du pays que j’ai juré à leurs pères de leur donner. [^6] Fortifie-toi seulement et aie bon courage, en agissant fidèlement selon toute la loi que Moïse, mon serviteur, t’a prescrite; #De 5:32; 28:14.ne t’en détourne ni à droite ni à gauche, afin de réussir dans tout ce que tu entreprendras. [^7] Que ce livre de la loi ne s’éloigne point de ta bouche; #Ps 1:2.médite-le jour et nuit, pour agir fidèlement selon tout ce qui y est écrit; car c’est alors que tu auras du succès dans tes entreprises, c’est alors que tu réussiras. [^8] Ne t’ai-je pas donné cet ordre: Fortifie-toi et prends courage? Ne t’effraie point et ne t’épouvante point, car l’Éternel, ton Dieu, est avec toi dans tout ce que tu entreprendras. [^9] Josué donna cet ordre aux officiers du peuple: [^10] Parcourez le camp, et voici ce que vous commanderez au peuple: Préparez-vous des provisions, car dans trois jours vous passerez ce Jourdain pour aller conquérir le pays dont l’Éternel, votre Dieu, vous donne la possession. [^11] Josué dit aux Rubénites, aux Gadites et à la demi-tribu de Manassé: [^12] Rappelez-vous ce que vous a prescrit Moïse, serviteur de l’Éternel, quand il a dit: L’Éternel, votre Dieu, vous a accordé du repos, et vous a donné ce pays. [^13] Vos femmes, vos petits enfants et vos troupeaux resteront dans le pays que vous a donné Moïse de ce côté-ci du Jourdain; mais vous tous, hommes vaillants, vous passerez en armes devant vos frères, et vous les aiderez, [^14] jusqu’à ce que l’Éternel ait accordé du repos à vos frères comme à vous, et qu’ils soient aussi en possession du pays que l’Éternel, votre Dieu, leur donne. Puis vous reviendrez prendre possession du pays qui est votre propriété, et que vous a donné Moïse, serviteur de l’Éternel, de ce côté-ci du Jourdain, vers le soleil levant. [^15] Ils répondirent à Josué, en disant: Nous ferons tout ce que tu nous as ordonné, et nous irons partout où tu nous enverras. [^16] Nous t’obéirons entièrement, comme nous avons obéi à Moïse. Veuille seulement l’Éternel, ton Dieu, être avec toi, comme il a été avec Moïse! [^17] Tout homme qui sera rebelle à ton ordre, et qui n’obéira pas à tout ce que tu lui commanderas, sera puni de mort. Fortifie-toi seulement, et prends courage! [^18] 

Joshua - 1 [[Joshua - 2|-->]]

---
# Notes
