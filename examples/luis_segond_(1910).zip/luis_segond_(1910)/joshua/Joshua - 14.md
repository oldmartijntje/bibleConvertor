---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 14 - Luis Segond (1910)"
---
[[Joshua - 13|<--]] Joshua - 14 [[Joshua - 15|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Joshua]]

# Joshua - 14

Voici ce que les enfants d’Israël reçurent en héritage dans le pays de Canaan, #No 34:17.ce que partagèrent entre eux le sacrificateur Éléazar, Josué, fils de Nun, et les chefs de famille des tribus des enfants d’Israël. [^1] Le partage eut lieu d’après le sort, comme l’Éternel l’avait ordonné par Moïse, #No 26:55.pour les neuf tribus et pour la demi-tribu. [^2] Car Moïse avait donné un héritage aux deux tribus et à la demi-tribu de l’autre côté du Jourdain; mais il n’avait point donné aux Lévites d’héritage parmi eux. [^3] Les fils de Joseph formaient deux tribus, Manassé et Éphraïm; et l’on ne donna point de part aux Lévites dans le pays, si ce n’est des villes pour habitation, et les banlieues pour leurs troupeaux et pour leurs biens. [^4] Les enfants d’Israël se conformèrent aux ordres que l’Éternel avait donnés à Moïse, et ils partagèrent le pays. [^5] Les fils de Juda s’approchèrent de Josué, à Guilgal; et Caleb, fils de Jephunné, le Kenizien, lui dit: Tu sais #No 12:24. De 1:36.ce que l’Éternel a déclaré à Moïse, homme de Dieu, au sujet de moi et au sujet de toi, à Kadès-Barnéa. [^6] J’étais âgé de quarante ans lorsque Moïse, serviteur de l’Éternel, m’envoya de Kadès-Barnéa pour explorer le pays, et je lui fis un rapport avec droiture de cœur. [^7] Mes frères qui étaient montés avec moi découragèrent le peuple, #No 14:24.mais moi je suivis pleinement la voie de l’Éternel, mon Dieu. [^8] Et ce jour-là Moïse jura, en disant: Le pays que ton pied a foulé sera ton héritage à perpétuité, pour toi et pour tes enfants, parce que tu as pleinement suivi la voie de l’Éternel, mon Dieu. [^9] Maintenant voici, l’Éternel m’a fait vivre, comme il l’a dit. Il y a quarante-cinq ans que l’Éternel parlait ainsi à Moïse, lorsqu’Israël marchait dans le désert; et maintenant voici, je suis âgé aujourd’hui de quatre-vingt-cinq ans. [^10] Je suis encore vigoureux comme au jour où Moïse m’envoya; j’ai autant de force que j’en avais alors, soit pour combattre, #No 27:17. De 31:2.soit pour sortir et pour entrer. [^11] Donne-moi donc cette montagne dont l’Éternel a parlé dans ce temps-là; car tu as appris alors qu’il s’y trouve des Anakim, et qu’il y a des villes grandes et fortifiées. L’Éternel sera peut-être avec moi, et je les chasserai, comme l’Éternel a dit. [^12] Josué bénit Caleb, fils de Jephunné, et il lui donna Hébron pour héritage. [^13] C’est ainsi que Caleb, fils de Jephunné, le Kenizien, a eu jusqu’à ce jour Hébron pour héritage, parce qu’il avait pleinement suivi la voie de l’Éternel, le Dieu d’Israël. [^14] Hébron s’appelait autrefois Kirjath-Arba: Arba avait été l’homme le plus grand parmi les Anakim. Le pays fut dès lors en repos et sans guerre. [^15] 

[[Joshua - 13|<--]] Joshua - 14 [[Joshua - 15|-->]]

---
# Notes
