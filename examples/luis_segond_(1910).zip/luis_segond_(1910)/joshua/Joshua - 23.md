---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 23 - Luis Segond (1910)"
---
[[Joshua - 22|<--]] Joshua - 23 [[Joshua - 24|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Joshua]]

# Joshua - 23

Depuis longtemps l’Éternel avait donné du repos à Israël, en le délivrant de tous les ennemis qui l’entouraient. Josué était vieux, avancé en âge. [^1] Alors Josué convoqua tout Israël, ses anciens, ses chefs, ses juges et ses officiers. Il leur dit: Je suis vieux, je suis avancé en âge. [^2] Vous avez vu tout ce que l’Éternel, votre Dieu, a fait à toutes ces nations devant vous; car c’est l’Éternel, votre Dieu, qui a combattu pour vous. [^3] Voyez, je vous ai donné en héritage par le sort, selon vos tribus, ces nations qui sont restées, à partir du Jourdain, et toutes les nations que j’ai exterminées, jusqu’à la grande mer vers le soleil couchant. [^4] L’Éternel, votre Dieu, les repoussera devant vous et les chassera devant vous; et vous posséderez leur pays, #Ex 14:14; 23:27. No 33:53. De 6:19. Jos 13:6.comme l’Éternel, votre Dieu, vous l’a dit. [^5] Appliquez-vous avec force à observer et à mettre en pratique tout ce qui est écrit dans le livre de la loi de Moïse, #De 5:32; 28:14.sans vous en détourner ni à droite ni à gauche. [^6] Ne vous mêlez point avec ces nations qui sont restées parmi vous; #Ex 23:13. Ps 6:4. Jé 5:7. So 1:5. Ép 5:3.ne prononcez point le nom de leurs dieux, et ne l’employez point en jurant; ne les servez point, et ne vous prosternez point devant eux. [^7] #De 11:22.Mais attachez-vous à l’Éternel, votre Dieu, comme vous l’avez fait jusqu’à ce jour. [^8] L’Éternel a chassé devant vous des nations grandes et puissantes; et personne, jusqu’à ce jour, n’a pu vous résister. [^9] #Lé 26:8. De 32:30.Un seul d’entre vous en poursuivait mille; car l’Éternel, votre Dieu, combattait pour vous, comme il vous l’a dit. [^10] Veillez donc attentivement sur vos âmes, afin d’aimer l’Éternel, votre Dieu. [^11] Si vous vous détournez et que vous vous attachiez au reste de ces nations qui sont demeurées parmi vous, si vous vous unissez avec elles par des mariages, et si vous formez ensemble des relations, [^12] soyez certains que l’Éternel, votre Dieu, ne continuera pas à chasser ces nations devant vous; mais elles seront pour vous un filet et un piège, un fouet dans vos côtés et des épines dans vos yeux, jusqu’à ce que vous ayez péri de dessus ce bon pays que l’Éternel, votre Dieu, vous a donné. [^13] Voici, je m’en vais maintenant par le chemin de toute la terre. Reconnaissez de tout votre cœur et de toute votre âme qu’aucune de toutes les bonnes paroles prononcées sur vous par l’Éternel, votre Dieu, n’est restée sans effet; toutes se sont accomplies pour vous, aucune n’est restée sans effet. [^14] Et comme toutes les bonnes paroles que l’Éternel, votre Dieu, vous avait dites se sont accomplies pour vous, de même l’Éternel accomplira sur vous toutes les paroles mauvaises, jusqu’à ce qu’il vous ait détruits de dessus ce bon pays que l’Éternel, votre Dieu, vous a donné. [^15] Si vous transgressez l’alliance que l’Éternel, votre Dieu, vous a prescrite, et si vous allez servir d’autres dieux et vous prosterner devant eux, la colère de l’Éternel s’enflammera contre vous, et vous périrez promptement dans le bon pays qu’il vous a donné. [^16] 

[[Joshua - 22|<--]] Joshua - 23 [[Joshua - 24|-->]]

---
# Notes
