---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 3 - Luis Segond (1910)"
---
[[Joshua - 2|<--]] Joshua - 3 [[Joshua - 4|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Joshua]]

# Joshua - 3

Josué, s’étant levé de bon matin, partit de Sittim avec tous les enfants d’Israël. Ils arrivèrent au Jourdain; et là, ils passèrent la nuit, avant de le traverser. [^1] Au bout de trois jours, les officiers parcoururent le camp, [^2] et donnèrent cet ordre au peuple: Lorsque vous verrez l’arche de l’alliance de l’Éternel, votre Dieu, portée par les sacrificateurs, les Lévites, vous partirez du lieu où vous êtes, et vous vous mettrez en marche après elle. [^3] Mais il y aura entre vous et elle une distance d’environ deux mille coudées: n’en approchez pas. Elle vous montrera le chemin que vous devez suivre, car vous n’avez point encore passé par ce chemin. [^4] Josué dit au peuple: Sanctifiez-vous, car demain l’Éternel fera des prodiges au milieu de vous. [^5] Et Josué dit aux sacrificateurs: Portez l’arche de l’alliance, et passez devant le peuple. Ils portèrent l’arche de l’alliance, et ils marchèrent devant le peuple. [^6] L’Éternel dit à Josué: Aujourd’hui, je commencerai à t’élever aux yeux de tout Israël, afin qu’ils sachent #Jos 1:5.que je serai avec toi comme j’ai été avec Moïse. [^7] Tu donneras cet ordre aux sacrificateurs qui portent l’arche de l’alliance: Lorsque vous arriverez au bord des eaux du Jourdain, vous vous arrêterez dans le Jourdain. [^8] Josué dit aux enfants d’Israël: Approchez, et écoutez les paroles de l’Éternel, votre Dieu. [^9] Josué dit: A ceci vous reconnaîtrez que le Dieu vivant est au milieu de vous, et qu’il chassera devant vous les Cananéens, les Héthiens, les Héviens, les Phéréziens, les Guirgasiens, les Amoréens et les Jébusiens: [^10] voici, l’arche de l’alliance du Seigneur de toute la terre va passer devant vous dans le Jourdain. [^11] Maintenant, prenez douze hommes parmi les tribus d’Israël, un homme de chaque tribu. [^12] Et dès que les sacrificateurs qui portent l’arche de l’Éternel, le Seigneur de toute la terre, poseront la plante des pieds dans les eaux du Jourdain, les eaux du Jourdain seront coupées, les eaux qui descendent d’en haut, #Ps 114:3.et elles s’arrêteront en un monceau. [^13] Le peuple sortit de ses tentes pour passer le Jourdain, et #Ac 7:45.les sacrificateurs qui portaient l’arche de l’alliance marchèrent devant le peuple. [^14] Quand les sacrificateurs qui portaient l’arche furent arrivés au Jourdain, et que leurs pieds se furent mouillés au bord de l’eau, le Jourdain #1 Ch 12:15.regorge par-dessus toutes ses rives tout le temps de la moisson, [^15] les eaux qui descendent d’en haut s’arrêtèrent, et s’élevèrent en un monceau, à une très grande distance, près de la ville d’Adam, qui est à côté de Tsarthan; et celles qui descendaient vers la mer de la plaine, la mer Salée, furent complètement coupées. Le peuple passa vis-à-vis de Jéricho. [^16] Les sacrificateurs qui portaient l’arche de l’alliance de l’Éternel s’arrêtèrent de pied ferme sur le sec, au milieu du Jourdain, pendant que tout Israël passait à sec, jusqu’à ce que toute la nation eût achevé de passer le Jourdain. [^17] 

[[Joshua - 2|<--]] Joshua - 3 [[Joshua - 4|-->]]

---
# Notes
