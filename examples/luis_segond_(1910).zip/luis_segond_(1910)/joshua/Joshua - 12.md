---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 12 - Luis Segond (1910)"
---
[[Joshua - 11|<--]] Joshua - 12 [[Joshua - 13|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Joshua]]

# Joshua - 12

Voici les rois que les enfants d’Israël battirent, et dont ils possédèrent le pays de l’autre côté du Jourdain, vers le soleil levant, depuis le torrent de l’Arnon jusqu’à la montagne de l’Hermon, avec toute la plaine à l’orient. [^1] Sihon, roi des Amoréens, qui habitait à Hesbon. Sa domination s’étendait depuis Aroër, qui est au bord du torrent de l’Arnon, #De 3:8, 16.et, depuis le milieu du torrent, sur la moitié de Galaad, jusqu’au torrent de Jabbok, frontière des enfants d’Ammon; [^2] sur la plaine, jusqu’à la mer de Kinnéreth à l’orient, et jusqu’à la mer de la plaine, la mer Salée, à l’orient vers Beth-Jeschimoth; et du côté du midi, sur le pied du Pisga. [^3] #De 1:4.Og, roi de Basan, seul reste des Rephaïm, qui habitait à Aschtaroth et à Édréï. [^4] Sa domination s’étendait sur la montagne de l’Hermon, sur Salca, sur tout Basan jusqu’à la frontière des Gueschuriens et des Maacathiens, et sur la moitié de Galaad, frontière de Sihon, roi de Hesbon. [^5] Moïse, serviteur de l’Éternel, et les enfants d’Israël, les battirent; #No 21:24; 32:33.et Moïse, serviteur de l’Éternel, donna leur pays en possession aux Rubénites, aux Gadites, et à la moitié de la tribu de Manassé. [^6] Voici les rois que Josué et les enfants d’Israël battirent #Jos 10:40.de ce côté-ci du Jourdain, à l’occident, depuis Baal-Gad dans la vallée du Liban jusqu’à la montagne nue qui s’élève vers Séir. Josué donna leur pays en possession aux tribus d’Israël, à chacune sa portion, [^7] dans la montagne, dans la vallée, dans la plaine, sur les coteaux, dans le désert, et dans le midi; pays des Héthiens, des Amoréens, des Cananéens, des Phéréziens, des Héviens et des Jébusiens. [^8] Le roi de Jéricho, un; le roi d’Aï, près de Béthel, un; [^9] le roi de Jérusalem, un; le roi d’Hébron, un; [^10] le roi de Jarmuth, un; le roi de Lakis, un; [^11] le roi d’Églon, un; le roi de Guézer, un; [^12] le roi de Debir, un; le roi de Guéder, un; [^13] le roi de Horma, un; le roi d’Arad, un; [^14] le roi de Libna, un; le roi d’Adullam, un; [^15] le roi de Makkéda, un; le roi de Béthel, un; [^16] le roi de Tappuach, un; le roi de Hépher, un; [^17] le roi d’Aphek, un; le roi de Lascharon, un; [^18] le roi de Madon, un; le roi de Hatsor, un; [^19] le roi de Schimron-Meron, un; le roi d’Acschaph, un; [^20] le roi de Taanac, un; le roi de Meguiddo, un; [^21] le roi de Kédesch, un; le roi de Jokneam, au Carmel, un; [^22] le roi de Dor, sur les hauteurs de Dor, un; le roi de Gojim, près de Guilgal, un; [^23] le roi de Thirtsa, un. Total des rois: trente et un. [^24] 

[[Joshua - 11|<--]] Joshua - 12 [[Joshua - 13|-->]]

---
# Notes
