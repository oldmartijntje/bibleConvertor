---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/psalms"
  - "#bible/testament/old"
aliases:
  - "Psalms - 1 - Luis Segond (1910)"
---
Psalms - 1 [[Psalms - 2|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Psalms]]

# Psalms - 1

Heureux l’homme qui ne marche pas selon le conseil des méchants,Qui ne s’arrête pas sur la voie des pécheurs,Et #Ps 26:4. Pr 1:10, 15; 4:14, 15. 1 Co 15:33. Ép 5:11.qui ne s’assied pas en compagnie des moqueurs, [^1] #    De 6:6, etc.; 17:19. Jos 1:8. Ps 119:1, etc.  Mais qui trouve son plaisir dans la loi de l’Éternel,Et qui la médite jour et nuit! [^2] Il est comme un #Jé 17:8.arbre planté près d’un courant d’eau,Qui donne son fruit en sa saison,Et dont le feuillage ne se flétrit point:Tout ce qu’il fait lui réussit. [^3] Il n’en est pas ainsi des méchants:Ils sont comme #Job 21:18. Ps 35:5. És 17:13; 29:5. Os 13:3.la paille que le vent dissipe. [^4] C’est pourquoi les méchants ne résistent pas au jour du jugement,Ni les pécheurs dans l’assemblée des justes; [^5] Car l’Éternel connaît la voie des justes,Et la voie des pécheurs mène à la ruine. [^6] 

Psalms - 1 [[Psalms - 2|-->]]

---
# Notes
