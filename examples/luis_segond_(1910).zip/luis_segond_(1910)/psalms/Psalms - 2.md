---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/psalms"
  - "#bible/testament/old"
aliases:
  - "Psalms - 2 - Luis Segond (1910)"
---
[[Psalms - 1|<--]] Psalms - 2 [[Psalms - 3|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Psalms]]

# Psalms - 2

Pourquoi #Ac 4:25.ce tumulte parmi les nations,Ces vaines pensées parmi les peuples? [^1] Pourquoi les rois de la terre se soulèvent-ilsEt les princes se liguent-ils avec euxContre l’Éternel et contre son oint? [^2] Brisons leurs liens,Délivrons-nous de leurs chaînes! [^3] Celui qui siège dans les cieux rit,Le Seigneur se moque d’eux. [^4] Puis il leur parle dans sa colère,Il les épouvante dans sa fureur: [^5] C’est moi qui ai oint mon roiSur Sion, ma montagne sainte! [^6] Je publierai le décret;L’Éternel m’a dit: #Ac 13:33. Hé 1:5; 5:5.Tu es mon fils!Je t’ai engendré aujourd’hui. [^7] Demande-moi #Ps 22:28; 72:8.et je te donnerai les nations pour héritage,Les extrémités de la terre pour possession; [^8] #    
        Ap 2:27; 19:15.  Tu les briseras avec une verge de fer,Tu les briseras comme le vase d’un potier. [^9] Et maintenant, rois, conduisez-vous avec sagesse!Juges de la terre, recevez instruction! [^10] Servez l’Éternel avec crainte,Et réjouissez-vous avec tremblement. [^11] Baisez le fils, de peur qu’il ne s’irrite,Et que vous ne périssiez dans votre voie,Car sa colère est prompte à s’enflammer.#    
        Ps 34:9. Pr 16:20. És 30:18. Jé 17:7. Ro 9:33; 10:11. 1 Pi 2:6.  Heureux tous ceux qui se confient en lui! [^12] 

[[Psalms - 1|<--]] Psalms - 2 [[Psalms - 3|-->]]

---
# Notes
