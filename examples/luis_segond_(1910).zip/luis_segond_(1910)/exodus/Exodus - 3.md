---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 3 - Luis Segond (1910)"
---
[[Exodus - 2|<--]] Exodus - 3 [[Exodus - 4|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Exodus]]

# Exodus - 3

Moïse faisait paître le troupeau de Jéthro, son beau-père, sacrificateur de Madian; et il mena le troupeau derrière le désert, et vint à la montagne de Dieu, à Horeb. [^1] L’ange de l’Éternel lui apparut dans une flamme de feu, au milieu d’un buisson. Moïse regarda; et voici, le buisson était tout en feu, et le buisson ne se consumait point. [^2] Moïse dit: Je veux me détourner pour voir quelle est cette grande vision, et pourquoi le buisson ne se consume point. [^3] L’Éternel vit qu’il se détournait pour voir; et Dieu l’appela du milieu du buisson, et dit: Moïse! Moïse! Et il répondit: Me voici! [^4] #Jos 5:15.Dieu dit: N’approche pas d’ici, ôte tes souliers de tes pieds, car le lieu sur lequel tu te tiens est une terre sainte. [^5] Et il ajouta: #Mt 22:32. Mc 12:26. Lu 20:37. Ac 7:32.Je suis le Dieu de ton père, le Dieu d’Abraham, le Dieu d’Isaac et le Dieu de Jacob. Moïse se cacha le visage, car il craignait de regarder Dieu. [^6] #Ac 7:34.L’Éternel dit: J’ai vu la souffrance de mon peuple qui est en Égypte, et j’ai entendu les cris que lui font pousser ses oppresseurs, car je connais ses douleurs. [^7] Je suis descendu pour le délivrer de la main des Égyptiens, et pour le faire monter de ce pays dans un bon et vaste pays, dans un pays où coulent le lait et le miel, dans les lieux qu’habitent les Cananéens, les Héthiens, les Amoréens, les Phéréziens, les Héviens et les Jébusiens. [^8] Voici, les cris d’Israël sont venus jusqu’à moi, et j’ai vu l’oppression que leur font souffrir les Égyptiens. [^9] Maintenant, va, #Ps 105:26. Os 12:14. Mi 6:4. Ac 7:35.je t’enverrai auprès de Pharaon, et tu feras sortir d’Égypte mon peuple, les enfants d’Israël. [^10] Moïse dit à Dieu: Qui suis-je, pour aller vers Pharaon, et pour faire sortir d’Égypte les enfants d’Israël? [^11] Dieu dit: #Jos 1:5.Je serai avec toi; et ceci sera pour toi le signe que c’est moi qui t’envoie: quand tu auras fait sortir d’Égypte le peuple, vous servirez Dieu sur cette montagne. [^12] Moïse dit à Dieu: J’irai donc vers les enfants d’Israël, et je leur dirai: Le Dieu de vos pères m’envoie vers vous. Mais, s’ils me demandent quel est son nom, que leur répondrai-je? [^13] Dieu dit à Moïse: Je suis celui qui suis. Et il ajouta: C’est ainsi que tu répondras aux enfants d’Israël: Celui qui s’appelle “je suis” m’a envoyé vers vous. [^14] Dieu dit encore à Moïse: Tu parleras ainsi aux enfants d’Israël: L’Éternel, le Dieu de vos pères, le Dieu d’Abraham, le Dieu d’Isaac et le Dieu de Jacob, m’envoie vers vous. Voilà mon nom pour l’éternité, voilà mon nom de génération en génération. [^15] Va, rassemble les anciens d’Israël, et dis-leur: L’Éternel, le Dieu de vos pères, m’est apparu, le Dieu d’Abraham, d’Isaac et de Jacob. Il a dit: Je vous ai vus, et j’ai vu ce qu’on vous fait en Égypte, [^16] et j’ai dit: Je vous ferai monter de l’Égypte, où vous souffrez, dans le pays des Cananéens, des Héthiens, des Amoréens, des Phéréziens, des Héviens et des Jébusiens, dans un pays où coulent le lait et le miel. [^17] Ils écouteront ta voix; et tu iras, toi et les anciens d’Israël, auprès du roi d’Égypte, et vous lui direz: L’Éternel, le Dieu des Hébreux, nous est apparu. Permets-nous de faire trois journées de marche dans le désert, pour offrir des sacrifices à l’Éternel, notre Dieu. [^18] Je sais que le roi d’Égypte ne vous laissera point aller, si ce n’est par une main puissante. [^19] J’étendrai ma main, et je frapperai l’Égypte par toutes sortes de prodiges que je ferai au milieu d’elle. Après quoi, il vous laissera aller. [^20] Je ferai même trouver grâce à ce peuple aux yeux des Égyptiens, et quand vous partirez, vous ne partirez point à vide. [^21] #Ex 11:2; 12:35.Chaque femme demandera à sa voisine et à celle qui demeure dans sa maison des vases d’argent, des vases d’or, et des vêtements, que vous mettrez sur vos fils et vos filles. Et vous #Éz 39:10.dépouillerez les Égyptiens. [^22] 

[[Exodus - 2|<--]] Exodus - 3 [[Exodus - 4|-->]]

---
# Notes
