---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 33 - Luis Segond (1910)"
---
[[Exodus - 32|<--]] Exodus - 33 [[Exodus - 34|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Exodus]]

# Exodus - 33

L’Éternel dit à Moïse: Va, pars d’ici, toi et le peuple que tu as fait sortir du pays d’Égypte; monte vers le pays que j’ai juré de donner à Abraham, à Isaac et à Jacob, en disant: #Ge 12:7; 26:4; 28:13.Je le donnerai à ta postérité. [^1] J’enverrai devant toi un ange, et je chasserai les Cananéens, les Amoréens, les Héthiens, les Phéréziens, les Héviens et les Jébusiens. [^2] Monte vers ce pays où coulent le lait et le miel. Mais je ne monterai point au milieu de toi, de peur que je ne te consume en chemin, #Ex 32:9. De 9:13.car tu es un peuple au cou roide. [^3] Lorsque le peuple eut entendu ces sinistres paroles, il fut dans la désolation, et personne ne mit ses ornements. [^4] Et l’Éternel dit à Moïse: Dis aux enfants d’Israël: Vous êtes un peuple au cou roide; si je montais un seul instant au milieu de toi, je te consumerais. Ote maintenant tes ornements de dessus toi, et je verrai ce que je te ferai. [^5] Les enfants d’Israël se dépouillèrent de leurs ornements, en s’éloignant du mont Horeb. [^6] Moïse prit la tente et la dressa hors du camp, à quelque distance; il l’appela tente d’assignation; et tous ceux qui consultaient l’Éternel allaient vers la tente d’assignation, qui était hors du camp. [^7] Lorsque Moïse se rendait à la tente, tout le peuple se levait; chacun se tenait à l’entrée de sa tente, et suivait des yeux Moïse, jusqu’à ce qu’il fût entré dans la tente. [^8] Et lorsque Moïse était entré dans la tente, la colonne de nuée descendait et s’arrêtait à l’entrée de la tente, et l’Éternel parlait avec Moïse. [^9] Tout le peuple voyait la colonne de nuée qui s’arrêtait à l’entrée de la tente, tout le peuple se levait et se prosternait à l’entrée de sa tente. [^10] L’Éternel parlait avec Moïse face à face, comme un homme parle à son ami. Puis Moïse retournait au camp; mais son jeune serviteur, Josué, fils de Nun, ne sortait pas du milieu de la tente. [^11] Moïse dit à l’Éternel: Voici, tu me dis: Fais monter ce peuple! Et tu ne me fais pas connaître qui tu enverras avec moi. Cependant, tu as dit: Je te connais par ton nom, et tu as trouvé grâce à mes yeux. [^12] Maintenant, si j’ai trouvé grâce à tes yeux, fais-moi connaître tes voies; alors je te connaîtrai, et je trouverai encore grâce à tes yeux. Considère que cette nation est ton peuple. [^13] L’Éternel répondit: Je marcherai moi-même avec toi, et je te donnerai du repos. [^14] Moïse lui dit: Si tu ne marches pas toi-même avec nous, ne nous fais point partir d’ici. [^15] Comment sera-t-il donc certain que j’ai trouvé grâce à tes yeux, moi et ton peuple? Ne sera-ce pas quand tu marcheras avec nous, et #De 4:7.quand nous serons distingués, moi et ton peuple, de tous les peuples qui sont sur la face de la terre? [^16] L’Éternel dit à Moïse: Je ferai ce que tu me demandes, car tu as trouvé grâce à mes yeux, et je te connais par ton nom. [^17] Moïse dit: Fais-moi voir ta gloire! [^18] L’Éternel répondit: Je ferai passer devant toi toute ma bonté, et je proclamerai devant toi le nom de l’Éternel; #Ro 9:15.je fais grâce à qui je fais grâce, et miséricorde à qui je fais miséricorde. [^19] L’Éternel dit: Tu ne pourras pas voir ma face, car l’homme ne peut me voir et vivre. [^20] L’Éternel dit: Voici un lieu près de moi; tu te tiendras sur le rocher. [^21] Quand ma gloire passera, je te mettrai dans un creux du rocher, et je te couvrirai de ma main jusqu’à ce que j’aie passé. [^22] Et lorsque je retournerai ma main, tu me verras par derrière, mais ma face ne pourra pas être vue. [^23] 

[[Exodus - 32|<--]] Exodus - 33 [[Exodus - 34|-->]]

---
# Notes
