---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 2 - Luis Segond (1910)"
---
[[Exodus - 1|<--]] Exodus - 2 [[Exodus - 3|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Exodus]]

# Exodus - 2

#    
        Ex 6:19. No 26:59.  Un homme de la maison de Lévi avait pris pour femme une fille de Lévi. [^1] #1 Ch 23:13. Ac 7:20.Cette femme devint enceinte et enfanta un fils. Elle vit #Hé 11:23.qu’il était beau, et elle le cacha pendant trois mois. [^2] Ne pouvant plus le cacher, elle prit une caisse de jonc, qu’elle enduisit de bitume et de poix; elle y mit l’enfant, et le déposa parmi les roseaux, sur le bord du fleuve. [^3] La sœur de l’enfant se tint à quelque distance, pour savoir ce qui lui arriverait. [^4] La fille de Pharaon descendit au fleuve pour se baigner, et ses compagnes se promenèrent le long du fleuve. #Ac 7:21. Hé 11:23.Elle aperçut la caisse au milieu des roseaux, et elle envoya sa servante pour la prendre. [^5] Elle l’ouvrit, et vit l’enfant: c’était un petit garçon qui pleurait. Elle en eut pitié, et elle dit: C’est un enfant des Hébreux! [^6] Alors la sœur de l’enfant dit à la fille de Pharaon: Veux-tu que j’aille te chercher une nourrice parmi les femmes des Hébreux, pour allaiter cet enfant? [^7] Va, lui répondit la fille de Pharaon. Et la jeune fille alla chercher la mère de l’enfant. [^8] La fille de Pharaon lui dit: Emporte cet enfant, et allaite-le-moi; je te donnerai ton salaire. La femme prit l’enfant, et l’allaita. [^9] Quand il eut grandi, elle l’amena à la fille de Pharaon, et il fut pour elle comme un fils. Elle lui donna le nom de Moïse, car, dit-elle, je l’ai retiré des eaux. [^10] #    
        Ac 7:23. Hé 11:24, 25.  En ce temps-là, Moïse, devenu grand, se rendit vers ses frères, et fut témoin de leurs pénibles travaux. Il vit un Égyptien qui frappait un Hébreu d’entre ses frères. [^11] Il regarda de côté et d’autre, et, voyant qu’il n’y avait personne, il tua l’Égyptien, et le cacha dans le sable. [^12] Il sortit le jour suivant; et voici, deux Hébreux se querellaient. Il dit à celui qui avait tort: Pourquoi frappes-tu ton prochain? [^13] Et cet homme répondit: #Ac 7:27.Qui t’a établi chef et juge sur nous? Penses-tu me tuer, comme tu as tué l’Égyptien? Moïse eut peur, et dit: Certainement la chose est connue. [^14] Pharaon apprit ce qui s’était passé, et il cherchait à faire mourir Moïse. #Ac 7:29.Mais Moïse s’enfuit de devant Pharaon, et il se retira dans le pays de Madian, où il s’arrêta près d’un puits. [^15] Le sacrificateur de Madian avait sept filles. Elles vinrent puiser de l’eau, et elles remplirent les auges pour abreuver le troupeau de leur père. [^16] Les bergers arrivèrent, et les chassèrent. Alors Moïse se leva, prit leur défense, et fit boire leur troupeau. [^17] Quand elles furent de retour auprès de Réuel, leur père, il dit: Pourquoi revenez-vous si tôt aujourd’hui? [^18] Elles répondirent: Un Égyptien nous a délivrées de la main des bergers, et même il nous a puisé de l’eau, et a fait boire le troupeau. [^19] Et il dit à ses filles: Où est-il? Pourquoi avez-vous laissé cet homme? Appelez-le, pour qu’il prenne quelque nourriture. [^20] Moïse se décida à demeurer chez cet homme, qui lui donna pour femme Séphora, sa fille. [^21] #Ex 18:2, 3.Elle enfanta un fils, qu’il appela du nom de Guerschom, car, dit-il, j’habite un pays étranger. [^22] Longtemps après, le roi d’Égypte mourut, et les enfants d’Israël gémissaient encore sous la servitude, et poussaient des cris. Ces cris, que leur arrachait la servitude, montèrent jusqu’à Dieu. [^23] Dieu entendit leurs gémissements, et #Ge 15:14.se souvint de son alliance avec Abraham, Isaac et Jacob. [^24] Dieu regarda les enfants d’Israël, et il en eut compassion. [^25] 

[[Exodus - 1|<--]] Exodus - 2 [[Exodus - 3|-->]]

---
# Notes
