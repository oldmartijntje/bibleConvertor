---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 27 - Luis Segond (1910)"
---
[[Exodus - 26|<--]] Exodus - 27 [[Exodus - 28|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Exodus]]

# Exodus - 27

Tu feras #Ex 38:1.l’autel de bois d’acacia; sa longueur sera de cinq coudées, et sa largeur de cinq coudées. L’autel sera carré, et sa hauteur sera de trois coudées. [^1] Tu feras, aux quatre coins, des cornes qui sortiront de l’autel; et tu le couvriras d’airain. [^2] Tu feras pour l’autel des cendriers, des pelles, des bassins, des fourchettes et des brasiers; tu feras d’airain tous ses ustensiles. [^3] Tu feras à l’autel une grille d’airain, en forme de treillis, et tu mettras quatre anneaux d’airain aux quatre coins du treillis. [^4] Tu le placeras au-dessous du rebord de l’autel, à partir du bas, jusqu’à la moitié de la hauteur de l’autel. [^5] Tu feras des barres pour l’autel, des barres de bois d’acacia, et tu les couvriras d’airain. [^6] On passera les barres dans les anneaux; et les barres seront aux deux côtés de l’autel, quand on le portera. [^7] Tu le feras creux, avec des planches; il sera fait tel qu’il t’est montré sur la montagne. [^8] #    
        Ex 38:9.  Tu feras le parvis du tabernacle. Du côté du midi, il y aura, pour former le parvis, des toiles de fin lin retors, sur une longueur de cent coudées pour ce premier côté, [^9] avec vingt colonnes posant sur vingt bases d’airain; les crochets des colonnes et leurs tringles seront d’argent. [^10] Du côté du nord, il y aura également des toiles sur une longueur de cent coudées, avec vingt colonnes et leurs vingt bases d’airain; les crochets des colonnes et leurs tringles seront d’argent. [^11] Du côté de l’occident, il y aura pour la largeur du parvis cinquante coudées de toiles, avec dix colonnes et leurs dix bases. [^12] Du côté de l’orient, sur les cinquante coudées de largeur du parvis, [^13] il y aura quinze coudées de toiles pour une aile, avec trois colonnes et leurs trois bases, [^14] et quinze coudées de toiles pour la seconde aile, avec trois colonnes et leurs trois bases. [^15] Pour la porte du parvis il y aura un rideau de vingt coudées, bleu, pourpre et cramoisi, et de fin lin retors, en ouvrage de broderie, avec quatre colonnes et leurs quatre bases. [^16] Toutes les colonnes formant l’enceinte du parvis auront des tringles d’argent, des crochets d’argent, et des bases d’airain. [^17] La longueur du parvis sera de cent coudées, sa largeur de cinquante de chaque côté, et sa hauteur de cinq coudées; les toiles seront de fin lin retors, et les bases d’airain. [^18] Tous les ustensiles destinés au service du tabernacle, tous ses pieux, et tous les pieux du parvis, seront d’airain. [^19] #    
        Lé 24:2.  Tu ordonneras aux enfants d’Israël de t’apporter pour le chandelier de l’huile pure d’olives concassées, afin d’entretenir les lampes continuellement. [^20] C’est dans la tente d’assignation, en dehors du voile qui est devant le témoignage, qu’Aaron et ses fils la prépareront, pour que les lampes brûlent du soir au matin en présence de l’Éternel. C’est une loi perpétuelle pour leurs descendants, et que devront observer les enfants d’Israël. [^21] 

[[Exodus - 26|<--]] Exodus - 27 [[Exodus - 28|-->]]

---
# Notes
