---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 11 - Luis Segond (1910)"
---
[[Exodus - 10|<--]] Exodus - 11 [[Exodus - 12|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Exodus]]

# Exodus - 11

L’Éternel dit à Moïse: Je ferai venir encore une plaie sur Pharaon et sur l’Égypte. Après cela, il vous laissera partir d’ici. Lorsqu’il vous laissera tout à fait aller, il vous chassera même d’ici. [^1] Parle au peuple, #Ex 3:22; 12:35.pour que chacun demande à son voisin et chacune à sa voisine des vases d’argent et des vases d’or. [^2] L’Éternel #Ex 12:36.fit trouver grâce au peuple aux yeux des Égyptiens; Moïse lui-même était très considéré dans le pays d’Égypte, aux yeux des serviteurs de Pharaon et aux yeux du peuple. [^3] Moïse dit: Ainsi parle l’Éternel: Vers le milieu de la nuit, #Ex 12:29.je passerai au travers de l’Égypte; [^4] et #Ex 12:12.tous les premiers-nés mourront dans le pays d’Égypte, depuis le premier-né de Pharaon assis sur son trône, jusqu’au premier-né de la servante qui est derrière la meule, et jusqu’à tous les premiers-nés des animaux. [^5] Il y aura dans tout le pays d’Égypte de grands cris, tels qu’il n’y en a point eu et qu’il n’y en aura plus de semblables. [^6] Mais parmi tous les enfants d’Israël, depuis les hommes jusqu’aux animaux, pas même un chien ne remuera sa langue, afin que vous sachiez quelle différence l’Éternel fait entre l’Égypte et Israël. [^7] #Ex 12:30.Alors tous tes serviteurs que voici descendront vers moi et se prosterneront devant moi, en disant: Sors, toi et tout le peuple qui s’attache à tes pas! Après cela, je sortirai. Moïse sortit de chez Pharaon, dans une ardente colère. [^8] L’Éternel dit à Moïse: Pharaon ne vous écoutera point, afin que mes miracles se multiplient dans le pays d’Égypte. [^9] Moïse et Aaron firent tous ces miracles devant Pharaon, #Ex 9:16. Ro 9:17.l’Éternel endurcit le cœur de Pharaon, et Pharaon ne laissa point aller les enfants d’Israël hors de son pays. [^10] 

[[Exodus - 10|<--]] Exodus - 11 [[Exodus - 12|-->]]

---
# Notes
