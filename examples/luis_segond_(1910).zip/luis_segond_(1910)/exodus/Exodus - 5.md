---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 5 - Luis Segond (1910)"
---
[[Exodus - 4|<--]] Exodus - 5 [[Exodus - 6|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Exodus]]

# Exodus - 5

Moïse et Aaron se rendirent ensuite auprès de Pharaon, et lui dirent: Ainsi parle l’Éternel, le Dieu d’Israël: Laisse aller mon peuple, pour qu’il célèbre au désert une fête en mon honneur. [^1] Pharaon répondit: #Job 21:15.Qui est l’Éternel, pour que j’obéisse à sa voix, en laissant aller Israël? #Ex 3:19.Je ne connais point l’Éternel, et je ne laisserai point aller Israël. [^2] Ils dirent: #Ex 3:18.Le Dieu des Hébreux nous est apparu. Permets-nous de faire trois journées de marche dans le désert, pour offrir des sacrifices à l’Éternel, afin qu’il ne nous frappe pas de la peste ou de l’épée. [^3] Et le roi d’Égypte leur dit: Moïse et Aaron, pourquoi détournez-vous le peuple de son ouvrage? Allez à vos travaux. [^4] Pharaon dit: Voici, ce peuple est maintenant nombreux dans le pays, et vous lui feriez interrompre ses travaux! [^5] Et ce jour même, Pharaon donna cet ordre aux inspecteurs du peuple et aux commissaires: [^6] Vous ne donnerez plus comme auparavant de la paille au peuple pour faire des briques; qu’ils aillent eux-mêmes se ramasser de la paille. [^7] Vous leur imposerez néanmoins la quantité de briques qu’ils faisaient auparavant, vous n’en retrancherez rien; car ce sont des paresseux; voilà pourquoi ils crient, en disant: Allons offrir des sacrifices à notre Dieu! [^8] Que l’on charge de travail ces gens, qu’ils s’en occupent, et ils ne prendront plus garde à des paroles de mensonge. [^9] Les inspecteurs du peuple et les commissaires vinrent dire au peuple: Ainsi parle Pharaon: Je ne vous donne plus de paille; [^10] allez vous-mêmes vous procurer de la paille où vous en trouverez, car l’on ne retranche rien de votre travail. [^11] Le peuple se répandit dans tout le pays d’Égypte, pour ramasser du chaume au lieu de paille. [^12] Les inspecteurs les pressaient, en disant: Achevez votre tâche, jour par jour, comme quand il y avait de la paille. [^13] On battit même les commissaires des enfants d’Israël, établis sur eux par les inspecteurs de Pharaon: Pourquoi, disait-on, n’avez-vous pas achevé hier et aujourd’hui, comme auparavant, la quantité de briques qui vous avait été fixée? [^14] Les commissaires des enfants d’Israël allèrent se plaindre à Pharaon, et lui dirent: Pourquoi traites-tu ainsi tes serviteurs? [^15] On ne donne point de paille à tes serviteurs, et l’on nous dit: Faites des briques! Et voici, tes serviteurs sont battus, comme si ton peuple était coupable. [^16] Pharaon répondit: Vous êtes des paresseux, des paresseux! Voilà pourquoi vous dites: Allons offrir des sacrifices à l’Éternel! [^17] Maintenant, allez travailler; on ne vous donnera point de paille, et vous livrerez la même quantité de briques. [^18] Les commissaires des enfants d’Israël virent qu’on les rendait malheureux, en disant: Vous ne retrancherez rien de vos briques; chaque jour la tâche du jour. [^19] En sortant de chez Pharaon, ils rencontrèrent Moïse et Aaron qui les attendaient. [^20] Ils leur dirent: Que l’Éternel vous regarde, et qu’il juge! Vous nous avez rendus odieux à Pharaon et à ses serviteurs, vous avez mis une épée dans leurs mains pour nous faire périr. [^21] Moïse retourna vers l’Éternel, et dit: Seigneur, pourquoi as-tu fait du mal à ce peuple? Pourquoi m’as-tu envoyé? [^22] Depuis que je suis allé vers Pharaon pour parler en ton nom, il fait du mal à ce peuple, et tu n’as point délivré ton peuple. [^23] 

[[Exodus - 4|<--]] Exodus - 5 [[Exodus - 6|-->]]

---
# Notes
