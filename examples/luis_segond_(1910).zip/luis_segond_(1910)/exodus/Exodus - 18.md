---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 18 - Luis Segond (1910)"
---
[[Exodus - 17|<--]] Exodus - 18 [[Exodus - 19|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Exodus]]

# Exodus - 18

#    
        Ex 2:16; 3:1.  Jéthro, sacrificateur de Madian, beau-père de Moïse, apprit tout ce que Dieu avait fait en faveur de Moïse et d’Israël, son peuple; il apprit que l’Éternel avait fait sortir Israël d’Égypte. [^1] Jéthro, beau-père de Moïse, prit Séphora, femme de Moïse, qui avait été renvoyée. [^2] Il prit aussi les deux fils de Séphora; #Ex 2:22.l’un se nommait Guerschom, car Moïse avait dit: J’habite un pays étranger; [^3] l’autre se nommait Éliézer, car il avait dit: Le Dieu de mon père m’a secouru, et il m’a délivré de l’épée de Pharaon. [^4] Jéthro, beau-père de Moïse, avec les fils et la femme de Moïse, vint au désert où il campait, à la montagne de Dieu. [^5] Il fit dire à Moïse: Moi, ton beau-père Jéthro, je viens vers toi, avec ta femme et ses deux fils. [^6] Moïse sortit au-devant de son beau-père, il se prosterna, et il le baisa. Ils s’informèrent réciproquement de leur santé, et ils entrèrent dans la tente de Moïse. [^7] Moïse raconta à son beau-père tout ce que l’Éternel avait fait à Pharaon et à l’Égypte à cause d’Israël, toutes les souffrances qui leur étaient survenues en chemin, et comment l’Éternel les avait délivrés. [^8] Jéthro se réjouit de tout le bien que l’Éternel avait fait à Israël, et de ce qu’il l’avait délivré de la main des Égyptiens. [^9] Et Jéthro dit: Béni soit l’Éternel, qui vous a délivrés de la main des Égyptiens et de la main de Pharaon; qui a délivré le peuple de la main des Égyptiens! [^10] Je reconnais maintenant que l’Éternel est plus grand que tous les dieux; #Ex 1:10, 16, 22; 5:7; 14:18.car la méchanceté des Égyptiens est retombée sur eux. [^11] Jéthro, beau-père de Moïse, offrit à Dieu un holocauste et des sacrifices. Aaron et tous les anciens d’Israël vinrent participer au repas avec le beau-père de Moïse, en présence de Dieu. [^12] Le lendemain, Moïse s’assit pour juger le peuple, et le peuple se tint devant lui depuis le matin jusqu’au soir. [^13] Le beau-père de Moïse vit tout ce qu’il faisait pour le peuple, et il dit: Que fais-tu là avec ce peuple? Pourquoi sièges-tu seul, et tout le peuple se tient-il devant toi, depuis le matin jusqu’au soir? [^14] Moïse répondit à son beau-père: C’est que le peuple vient à moi pour consulter Dieu. [^15] Quand ils ont quelque affaire, ils viennent à moi; je prononce entre eux, et je fais connaître les ordonnances de Dieu et ses lois. [^16] Le beau-père de Moïse lui dit: Ce que tu fais n’est pas bien. [^17] Tu t’épuiseras toi-même, et tu épuiseras ce peuple qui est avec toi; car la chose est au-dessus de tes forces, tu ne pourras pas y suffire seul. [^18] Maintenant écoute ma voix; je vais te donner un conseil, et que Dieu soit avec toi! Sois l’interprète du peuple auprès de Dieu, et porte les affaires devant Dieu. [^19] Enseigne-leur les ordonnances et les lois; et fais-leur connaître le chemin qu’ils doivent suivre, et ce qu’ils doivent faire. [^20] Choisis parmi tout le peuple des hommes capables, craignant Dieu, des hommes intègres, ennemis de la cupidité; établis-les sur eux comme chefs de mille, chefs de cent, chefs de cinquante et chefs de dix. [^21] Qu’ils jugent le peuple en tout temps; qu’ils portent devant toi toutes les affaires importantes, et qu’ils prononcent eux-mêmes sur les petites causes. Allège ta charge, et qu’ils la portent avec toi. [^22] Si tu fais cela, et que Dieu te donne des ordres, tu pourras y suffire, et tout ce peuple parviendra heureusement à sa destination. [^23] #De 1:9.Moïse écouta la voix de son beau-père, et fit tout ce qu’il avait dit. [^24] Moïse choisit des hommes capables parmi tout Israël, et il les établit chefs du peuple, chefs de mille, chefs de cent, chefs de cinquante et chefs de dix. [^25] Ils jugeaient le peuple en tout temps; ils portaient devant Moïse les affaires difficiles, et ils prononçaient eux-mêmes sur toutes les petites causes. [^26] Moïse laissa partir son beau-père, et Jéthro s’en alla dans son pays. [^27] 

[[Exodus - 17|<--]] Exodus - 18 [[Exodus - 19|-->]]

---
# Notes
