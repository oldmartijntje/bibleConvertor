---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 13 - Luis Segond (1910)"
---
[[Exodus - 12|<--]] Exodus - 13 [[Exodus - 14|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Exodus]]

# Exodus - 13

L’Éternel parla à Moïse, et dit: [^1] #Ex 22:29; 34:19. Lé 27:26. No 3:13; 8:17. Lu 2:23.Consacre-moi tout premier-né, tout premier-né parmi les enfants d’Israël, tant des hommes que des animaux: il m’appartient. [^2] Moïse dit au peuple: Souvenez-vous de ce jour, où vous êtes sortis d’Égypte, de la maison de servitude; car c’est par sa main puissante que l’Éternel vous en a fait sortir. On ne mangera point de pain levé. [^3] #Ex 23:15.Vous sortez aujourd’hui, dans le mois des épis. [^4] Quand l’Éternel t’aura fait entrer dans le pays des Cananéens, des Héthiens, des Amoréens, des Héviens et des Jébusiens, qu’il a juré à tes pères de te donner, pays où coulent le lait et le miel, tu rendras ce culte à l’Éternel dans ce même mois. [^5] Pendant sept jours, tu mangeras des pains sans levain; et le septième jour, il y aura une fête en l’honneur de l’Éternel. [^6] On mangera des pains sans levain pendant les sept jours; on ne verra point chez toi de pain levé, et l’on ne verra point chez toi de levain, dans toute l’étendue de ton pays. [^7] Tu diras alors à ton fils: C’est en mémoire de ce que l’Éternel a fait pour moi, lorsque je suis sorti d’Égypte. [^8] Ce sera pour toi comme un signe sur ta main et comme un souvenir entre tes yeux, afin que la loi de l’Éternel soit dans ta bouche; car c’est par sa main puissante que l’Éternel t’a fait sortir d’Égypte. [^9] Tu observeras cette ordonnance au temps fixé d’année en année. [^10] Quand l’Éternel t’aura fait entrer dans le pays des Cananéens, comme il l’a juré à toi et à tes pères, et qu’il te l’aura donné, [^11] #Ex 22:30; 34:19. Lé 27:26. No 8:17. Éz 44:30.tu consacreras à l’Éternel tout premier-né, même tout premier-né des animaux que tu auras: les mâles appartiennent à l’Éternel. [^12] Tu rachèteras avec un agneau tout premier-né de l’âne; et, si tu ne le rachètes pas, tu lui briseras la nuque. Tu rachèteras aussi tout premier-né de l’homme parmi tes fils. [^13] Et lorsque ton fils te demandera un jour: Que signifie cela? Tu lui répondras: Par sa main puissante, l’Éternel nous a fait sortir d’Égypte, de la maison de servitude; [^14] et, comme Pharaon s’obstinait à ne point nous laisser aller, l’Éternel fit mourir tous les premiers-nés dans le pays d’Égypte, depuis les premiers-nés des hommes jusqu’aux premiers-nés des animaux. Voilà pourquoi j’offre en sacrifice à l’Éternel tout premier-né des mâles, et je rachète tout premier-né de mes fils. [^15] Ce sera comme un signe sur ta main et comme des fronteaux entre tes yeux; car c’est par sa main puissante que l’Éternel nous a fait sortir d’Égypte. [^16] Lorsque Pharaon laissa aller le peuple, Dieu ne le conduisit point par le chemin du pays des Philistins, quoique le plus proche; car Dieu dit: Le peuple pourrait se repentir en voyant la guerre, et retourner en Égypte. [^17] Mais Dieu fit faire au peuple un détour par le chemin du désert, vers la mer Rouge. Les enfants d’Israël montèrent en armes hors du pays d’Égypte. [^18] Moïse prit avec lui les os de Joseph; #Ge 50:25. Jos 24:32.car Joseph avait fait jurer les fils d’Israël, en disant: Dieu vous visitera, et vous ferez remonter avec vous mes os loin d’ici. [^19] #No 33:6.Ils partirent de Succoth, et ils campèrent à Étham, à l’extrémité du désert. [^20] #Ex 40:38. No 14:14. De 1:33. Né 9:12, 19. Ps 78:14; 105:39. 1 Co 10:1.L’Éternel allait devant eux, le jour dans une colonne de nuée pour les guider dans leur chemin, et la nuit dans une colonne de feu pour les éclairer, afin qu’ils marchassent jour et nuit. [^21] La colonne de nuée ne se retirait point de devant le peuple pendant le jour, ni la colonne de feu pendant la nuit. [^22] 

[[Exodus - 12|<--]] Exodus - 13 [[Exodus - 14|-->]]

---
# Notes
