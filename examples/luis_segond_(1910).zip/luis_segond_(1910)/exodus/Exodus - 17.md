---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 17 - Luis Segond (1910)"
---
[[Exodus - 16|<--]] Exodus - 17 [[Exodus - 18|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Exodus]]

# Exodus - 17

Toute l’assemblée des enfants d’Israël partit du désert de Sin, selon les marches que l’Éternel leur avait ordonnées; et ils campèrent à Rephidim, où le peuple ne trouva point d’eau à boire. [^1] Alors le peuple chercha querelle à Moïse. Ils dirent: Donnez-nous de l’eau à boire. #No 20:3, 4.Moïse leur répondit: Pourquoi me cherchez-vous querelle? Pourquoi tentez-vous l’Éternel? [^2] Le peuple était là, pressé par la soif, et murmurait contre Moïse. Il disait: Pourquoi nous as-tu fait monter hors d’Égypte, pour me faire mourir de soif avec mes enfants et mes troupeaux? [^3] Moïse cria à l’Éternel, en disant: Que ferai-je à ce peuple? Encore un peu, et ils me lapideront. [^4] L’Éternel dit à Moïse: Passe devant le peuple, et prends avec toi des anciens d’Israël; prends aussi dans ta main ta verge #Ex 7:20.avec laquelle tu as frappé le fleuve, et marche! [^5] Voici, je me tiendrai devant toi sur le rocher d’Horeb; #No 20:9. Ps 78:15; 114:8. 1 Co 10:4.tu frapperas le rocher, et il en sortira de l’eau, et le peuple boira. Et Moïse fit ainsi, aux yeux des anciens d’Israël. [^6] Il donna à ce lieu le nom de Massa et Meriba, parce que les enfants d’Israël avaient contesté, et parce qu’ils avaient tenté l’Éternel, en disant: L’Éternel est-il au milieu de nous, ou n’y est-il pas? [^7] #    
        De 25:17, 18.  Amalek vint combattre Israël à Rephidim. [^8] Alors Moïse dit à Josué: Choisis-nous des hommes, sors, et combats Amalek; demain je me tiendrai sur le sommet de la colline, la verge de Dieu dans ma main. [^9] Josué fit ce que lui avait dit Moïse, pour combattre Amalek. Et Moïse, Aaron et Hur montèrent au sommet de la colline. [^10] Lorsque Moïse élevait sa main, Israël était le plus fort; et lorsqu’il baissait sa main, Amalek était le plus fort. [^11] Les mains de Moïse étant fatiguées, ils prirent une pierre qu’ils placèrent sous lui, et il s’assit dessus. Aaron et Hur soutenaient ses mains, l’un d’un côté, l’autre de l’autre; et ses mains restèrent fermes jusqu’au coucher du soleil. [^12] Et Josué vainquit Amalek et son peuple, au tranchant de l’épée. [^13] L’Éternel dit à Moïse: Écris cela dans le livre, pour que le souvenir s’en conserve, et déclare à Josué #No 24:20. 1 S 15:2, 3. De 25:17, 18, 19.que j’effacerai la mémoire d’Amalek de dessous les cieux. [^14] Moïse bâtit un autel, et lui donna pour nom: l’Éternel ma bannière. [^15] Il dit: Parce que la main a été levée sur le trône de l’Éternel, #1 S 15:2.il y aura guerre de l’Éternel contre Amalek, de génération en génération. [^16] 

[[Exodus - 16|<--]] Exodus - 17 [[Exodus - 18|-->]]

---
# Notes
