---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 15 - Luis Segond (1910)"
---
[[Exodus - 14|<--]] Exodus - 15 [[Exodus - 16|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Exodus]]

# Exodus - 15

Alors Moïse et les enfants d’Israël chantèrent ce cantique à l’Éternel. Ils dirent:#    
        Ps 106:12.  Je chanterai à l’Éternel, car il a fait éclater sa gloire;Il a précipité dans la mer le cheval et son cavalier. [^1] #    
        Ps 18:2; 118:14. És 12:2.  L’Éternel est ma force et le sujet de mes louanges;C’est lui qui m’a sauvé.Il est mon Dieu: je le célèbrerai;Il est le Dieu de mon père: je l’exalterai. [^2] L’Éternel est un vaillant guerrier;L’Éternel est son nom. [^3] Il a lancé dans la mer les chars de Pharaon et son armée;Ses combattants d’élite ont été engloutis dans la mer Rouge. [^4] #    
        Né 9:11.  Les flots les ont couverts:Ils sont descendus au fond des eaux, comme une pierre. [^5] #    
        Ps 118:15, 16.  Ta droite, ô Éternel! A signalé sa force;Ta droite, ô Éternel! A écrasé l’ennemi. [^6] Par la grandeur de ta majestéTu renverses tes adversaires;Tu déchaînes ta colère:Elle les consume comme du chaume. [^7] #    
        És 63:12, 13. Ha 3:10.  Au souffle de tes narines, les eaux se sont amoncelées,Les courants se sont dressés comme une muraille,Les flots se sont durcis au milieu de la mer. [^8] L’ennemi disait:Je poursuivrai, j’atteindrai,Je partagerai le butin;Ma vengeance sera assouvie,Je tirerai l’épée, ma main les détruira. [^9] #    
        Ps 74:13; 106:11.  Tu as soufflé de ton haleine:La mer les a couverts;Ils se sont enfoncés comme du plomb,Dans la profondeur des eaux. [^10] Qui est comme toi parmi les dieux, ô Éternel?Qui est comme toi magnifique en sainteté,Digne de louanges,Opérant des prodiges? [^11] Tu as étendu ta droite:La terre les a engloutis. [^12] Par ta miséricorde tu as conduit, Tu as délivré ce peuple; #Ps 77:21.Par ta puissance tu le diriges Vers la demeure de ta sainteté. [^13] Les peuples l’apprennent, et ils tremblent:La terreur s’empare des Philistins; [^14] #    
        De 2:4.  Les chefs d’Édom s’épouvantent;Un tremblement saisit les guerriers de Moab;Tous les habitants de Canaan tombent en défaillance. [^15] #    
        De 2:25; 11:25. Jos 2:9.  La crainte et la frayeur les surprendront;Par la grandeur de ton brasIls deviendront muets comme une pierre,Jusqu’à ce que ton peuple soit passé, ô Éternel!Jusqu’à ce qu’il soit passé,Le peuple que tu as acquis. [^16] Tu les amèneras et tu les établiras sur la montagne de ton héritage,Au lieu que tu as préparé pour ta demeure, ô Éternel!Au sanctuaire, Seigneur! Que tes mains ont fondé. [^17] L’Éternel régnera éternellement et à toujours. [^18] Car les chevaux de Pharaon, ses chars et ses cavaliers sont entrés dans la mer,Et l’Éternel a ramené sur eux les eaux de la mer;Mais les enfants d’Israël ont marché à sec au milieu de la mer. [^19] Marie, la prophétesse, sœur d’Aaron, #1 S 18:6.prit à sa main un tambourin, et toutes les femmes vinrent après elle, avec des tambourins et en dansant. [^20] Marie répondait aux enfants d’Israël:Chantez à l’Éternel, car il a fait éclater sa gloire;Il a précipité dans la mer le cheval et son cavalier. [^21] Moïse fit partir Israël de la mer Rouge. Ils prirent la direction du désert de Schur; et, après trois journées de marche dans le désert, ils ne trouvèrent point d’eau. [^22] #No 33:8.Ils arrivèrent à Mara; mais ils ne purent pas boire l’eau de Mara parce qu’elle était amère. C’est pourquoi ce lieu fut appelé Mara. [^23] Le peuple murmura contre Moïse, en disant: Que boirons-nous? [^24] Moïse cria à l’Éternel; et l’Éternel lui indiqua un bois, qu’il jeta dans l’eau. Et l’eau devint douce. Ce fut là que l’Éternel donna au peuple des lois et des ordonnances, et ce fut là qu’il le mit à l’épreuve. [^25] Il dit: Si tu écoutes attentivement la voix de l’Éternel, ton Dieu, si tu fais ce qui est droit à ses yeux, si tu prêtes l’oreille à ses commandements, et si tu observes toutes ses lois, je ne te frapperai d’aucune des maladies dont j’ai frappé les Égyptiens; car je suis l’Éternel, qui te guérit. [^26] Ils arrivèrent à Élim, où il y avait douze sources d’eau et soixante-dix palmiers. Ils campèrent là, près de l’eau. [^27] 

[[Exodus - 14|<--]] Exodus - 15 [[Exodus - 16|-->]]

---
# Notes
