---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 31 - Luis Segond (1910)"
---
[[Exodus - 30|<--]] Exodus - 31 [[Exodus - 32|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Exodus]]

# Exodus - 31

L’Éternel parla à Moïse, et dit: [^1] #Ex 35:30. 1 Ch 2:20.Sache que j’ai choisi Betsaleel, fils d’Uri, fils de Hur, de la tribu de Juda. [^2] Je l’ai rempli de l’Esprit de Dieu, de sagesse, d’intelligence, et de savoir pour toutes sortes d’ouvrages, [^3] je l’ai rendu capable de faire des inventions, de travailler l’or, l’argent et l’airain, [^4] de graver les pierres à enchâsser, de travailler le bois, et d’exécuter toutes sortes d’ouvrages. [^5] Et voici, je lui ai donné pour aide Oholiab, fils d’Ahisamac, de la tribu de Dan. J’ai mis de l’intelligence dans l’esprit de tous ceux qui sont habiles, pour qu’ils fassent tout ce que je t’ai ordonné: [^6] la tente d’assignation, l’arche du témoignage, le propitiatoire qui sera dessus, et tous les ustensiles de la tente; [^7] la table et ses ustensiles, le chandelier d’or pur et tous ses ustensiles, [^8] l’autel des parfums; l’autel des holocaustes et tous ses ustensiles, la cuve avec sa base; [^9] les vêtements d’office, les vêtements sacrés pour le sacrificateur Aaron, les vêtements de ses fils pour les fonctions du sacerdoce; [^10] l’huile d’onction, et le parfum odoriférant pour le sanctuaire. Ils se conformeront à tous les ordres que j’ai donnés. [^11] L’Éternel parla à Moïse, et dit: [^12] Parle aux enfants d’Israël, et dis-leur: Vous ne manquerez pas d’observer mes sabbats, car ce sera entre moi et vous, et parmi vos descendants, un signe auquel on connaîtra que je suis l’Éternel qui vous sanctifie. [^13] #Ex 20:8. De 5:12. Éz 20:12.Vous observerez le sabbat, car il sera pour vous une chose sainte. Celui qui le profanera, sera puni de mort; celui qui fera quelque ouvrage ce jour-là, sera retranché du milieu de son peuple. [^14] On travaillera six jours; mais le septième jour est le sabbat, le jour du repos, consacré à l’Éternel. Celui qui fera quelque ouvrage le jour du sabbat, sera puni de mort. [^15] Les enfants d’Israël observeront le sabbat, en le célébrant, eux et leurs descendants, comme une alliance perpétuelle. [^16] Ce sera entre moi et les enfants d’Israël un signe qui devra durer à perpétuité; #Ge 1:31; 2:2, 3. Ex 20:11.car en six jours l’Éternel a fait les cieux et la terre, et le septième jour il a cessé son œuvre et il s’est reposé. [^17] Lorsque l’Éternel eut achevé de parler à Moïse sur la montagne de Sinaï, il lui donna #Ex 32:16.les deux tables du témoignage, tables de pierre, écrites du doigt de Dieu. [^18] 

[[Exodus - 30|<--]] Exodus - 31 [[Exodus - 32|-->]]

---
# Notes
