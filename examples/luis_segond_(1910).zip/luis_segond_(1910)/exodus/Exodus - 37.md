---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 37 - Luis Segond (1910)"
---
[[Exodus - 36|<--]] Exodus - 37 [[Exodus - 38|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Exodus]]

# Exodus - 37

#    
        Ex 25:10.  Betsaleel fit l’arche de bois d’acacia; sa longueur était de deux coudées et demie, sa largeur d’une coudée et demie, et sa hauteur d’une coudée et demie. [^1] Il la couvrit d’or pur en dedans et en dehors, et il y fit une bordure d’or tout autour. [^2] Il fondit pour elle quatre anneaux d’or, qu’il mit à ses quatre coins, deux anneaux d’un côté et deux anneaux de l’autre côté. [^3] Il fit des barres de bois d’acacia, et les couvrit d’or. [^4] Il passa les barres dans les anneaux sur les côtés de l’arche, pour porter l’arche. [^5] Il fit un propitiatoire d’or pur; sa longueur était de deux coudées et demie, et sa largeur d’une coudée et demie. [^6] Il fit deux chérubins d’or; il les fit d’or battu, aux deux extrémités du propitiatoire, [^7] #Ex 25:19.un chérubin à l’une des extrémités, et un chérubin à l’autre extrémité; il fit les chérubins sortant du propitiatoire à ses deux extrémités. [^8] #Ex 25:20.Les chérubins étendaient les ailes par-dessus, couvrant de leurs ailes le propitiatoire, et se regardant l’un l’autre; les chérubins avaient la face tournée vers le propitiatoire. [^9] #    
        Ex 25:23.  Il fit la table de bois d’acacia, sa longueur était de deux coudées, sa largeur d’une coudée, et sa hauteur d’une coudée et demie. [^10] #Ex 25:24.Il la couvrit d’or pur, et il y fit une bordure d’or tout autour. [^11] #Ex 25:25.Il y fit à l’entour un rebord de quatre doigts, sur lequel il mit une bordure d’or tout autour. [^12] #Ex 25:26.Il fondit pour la table quatre anneaux d’or, et mit les anneaux aux quatre coins, qui étaient à ses quatre pieds. [^13] #Ex 25:27.Les anneaux étaient près du rebord, et recevaient les barres pour porter la table. [^14] Il fit les barres de bois d’acacia, et les couvrit d’or; et elles servaient à porter la table. [^15] #Ex 25:29.Il fit les ustensiles qu’on devait mettre sur la table, ses plats, ses coupes, ses calices et ses tasses pour servir aux libations; il les fit d’or pur. [^16] #    
        Ex 25:31.  Il fit le chandelier d’or pur; il fit le chandelier d’or battu; son pied, sa tige, ses calices, ses pommes et ses fleurs, étaient d’une même pièce. [^17] #Ex 25:32.Six branches sortaient de ses côtés, trois branches du chandelier de l’un des côtés, et trois branches du chandelier de l’autre côté. [^18] #Ex 25:33.Il y avait sur une branche trois calices en forme d’amande, avec pommes et fleurs, et sur une autre branche trois calices en forme d’amande, avec pommes et fleurs; il en était de même pour les six branches sortant du chandelier. [^19] #Ex 25:34.A la tige du chandelier il y avait quatre calices en forme d’amande, avec leurs pommes et leurs fleurs. [^20] Il y avait une pomme sous deux des branches sortant du chandelier, une pomme sous deux autres branches, et une pomme sous deux autres branches; il en était de même pour les six branches sortant du chandelier. [^21] #Ex 25:36.Les pommes et les branches du chandelier étaient d’une même pièce; il était tout entier d’or battu, d’or pur. [^22] #Ex 25:37, 38.Il fit ses sept lampes, ses mouchettes et ses vases à cendre d’or pur. [^23] #Ex 25:39.Il employa un talent d’or pur, pour faire le chandelier avec tous ses ustensiles. [^24] #    
        Ex 30:1, 2.  Il fit l’autel des parfums de bois d’acacia; sa longueur était d’une coudée et sa largeur d’une coudée; il était carré, et sa hauteur était de deux coudées. Des cornes sortaient de l’autel. [^25] #Ex 30:3.Il le couvrit d’or pur, le dessus, les côtés tout autour et les cornes, et il y fit une bordure d’or tout autour. [^26] #Ex 30:4.Il fit au-dessous de la bordure deux anneaux d’or aux deux côtés; il en mit aux deux côtés, pour recevoir les barres qui servaient à le porter. [^27] #Ex 30:5.Il fit des barres de bois d’acacia, et les couvrit d’or. [^28] #Ex 30:22, 34.Il fit l’huile pour l’onction sainte, et le parfum odoriférant, pur, composé selon l’art du parfumeur. [^29] 

[[Exodus - 36|<--]] Exodus - 37 [[Exodus - 38|-->]]

---
# Notes
