---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 20 - Luis Segond (1910)"
---
[[Exodus - 19|<--]] Exodus - 20 [[Exodus - 21|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Exodus]]

# Exodus - 20

Alors Dieu prononça toutes ces paroles, en disant: [^1] Je suis l’Éternel, ton Dieu, qui t’ai fait sortir du pays d’Égypte, #Ex 13:3. De 5:6. Ps 81:11.de la maison de servitude. [^2] Tu n’auras pas d’autres dieux devant ma face. [^3] #Lé 26:1. Ps 97:7.Tu ne te feras point d’image taillée, ni de représentation quelconque des choses qui sont en haut dans les cieux, qui sont en bas sur la terre, et qui sont dans les eaux plus bas que la terre. [^4] Tu ne te prosterneras point devant elles, et tu ne les serviras point; car moi, l’Éternel, ton Dieu, je suis un Dieu jaloux, qui punis l’iniquité des pères sur les enfants jusqu’à la troisième et la quatrième génération de ceux qui me haïssent, [^5] et qui fais miséricorde jusqu’en mille générations à ceux qui m’aiment et qui gardent mes commandements. [^6] #Lé 19:12. Mt 5:33.Tu ne prendras point le nom de l’Éternel, ton Dieu, en vain; car l’Éternel ne laissera point impuni celui qui prendra son nom en vain. [^7] #Éz 20:12.Souviens-toi du jour du repos, pour le sanctifier. [^8] #Ex 23:12; 34:21. Lu 13:14.Tu travailleras six jours, et tu feras tout ton ouvrage. [^9] Mais le septième jour est le jour du repos de l’Éternel, ton Dieu: tu ne feras aucun ouvrage, ni toi, ni ton fils, ni ta fille, ni ton serviteur, ni ta servante, ni ton bétail, ni l’étranger qui est dans tes portes. [^10] Car #Ge 2:2.en six jours l’Éternel a fait les cieux, la terre et la mer, et tout ce qui y est contenu, et il s’est reposé le septième jour: c’est pourquoi l’Éternel a béni le jour du repos et l’a sanctifié. [^11] #Mt 15:4. Ép 6:2.Honore ton père et ta mère, afin que tes jours se prolongent dans le pays que l’Éternel, ton Dieu, te donne. [^12] #Mt 5:21.Tu ne tueras point. [^13] #Mt 5:27.Tu ne commettras point d’adultère. [^14] Tu ne déroberas point. [^15] Tu ne porteras point de faux témoignage contre ton prochain. [^16] #Ro 7:7.Tu ne convoiteras point la maison de ton prochain; tu ne convoiteras point la femme de ton prochain, ni son serviteur, ni sa servante, ni son bœuf, ni son âne, ni aucune chose qui appartienne à ton prochain. [^17] Tout le peuple entendait les tonnerres et le son de la trompette; il voyait les flammes de la montagne fumante. A ce spectacle, le peuple tremblait, et se tenait dans l’éloignement. [^18] #De 5:25. Hé 12:19.Ils dirent à Moïse: Parle-nous toi-même, et nous écouterons; mais que Dieu ne nous parle point, de peur que nous ne mourions. [^19] Moïse dit au peuple: Ne vous effrayez pas; car c’est pour vous mettre à l’épreuve que Dieu est venu, et c’est pour que vous ayez sa crainte devant les yeux, afin que vous ne péchiez point. [^20] #Ex 18:17. Hé 12:18.Le peuple restait dans l’éloignement; mais Moïse s’approcha de la nuée où était Dieu. [^21] L’Éternel dit à Moïse: Tu parleras ainsi aux enfants d’Israël: Vous avez vu que je vous ai parlé depuis les cieux. [^22] Vous ne ferez point des dieux d’argent et des dieux d’or, pour me les associer; vous ne vous en ferez point. [^23] #Ex 27:1; 38:1.Tu m’élèveras un autel de terre, sur lequel tu offriras tes holocaustes et tes sacrifices d’actions de grâces, tes brebis et tes bœufs. Partout où je rappellerai mon nom, je viendrai à toi, et je te bénirai. [^24] #De 27:5. Jos 8:30, 31.Si tu m’élèves un autel de pierre, tu ne le bâtiras point en pierres taillées; car en passant ton ciseau sur la pierre, tu la profanerais. [^25] Tu ne monteras point à mon autel par des degrés, afin que ta nudité ne soit pas découverte. [^26] 

[[Exodus - 19|<--]] Exodus - 20 [[Exodus - 21|-->]]

---
# Notes
