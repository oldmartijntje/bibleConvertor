---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 6 - Luis Segond (1910)"
---
[[Exodus - 5|<--]] Exodus - 6 [[Exodus - 7|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Exodus]]

# Exodus - 6

L’Éternel dit à Moïse: Tu verras maintenant ce que je ferai à Pharaon; une main puissante le forcera à les laisser aller, une main puissante le forcera à les chasser de son pays. [^1] Dieu parla encore à Moïse, et lui dit: Je suis l’Éternel. [^2] Je suis apparu à Abraham, à Isaac et à Jacob, comme le Dieu tout-puissant; mais je n’ai pas été connu d’eux sous mon nom, l’Éternel. [^3] J’ai aussi établi mon alliance avec eux, pour leur donner le pays de Canaan, le pays de leurs pèlerinages, dans lequel ils ont séjourné. [^4] J’ai entendu les gémissements des enfants d’Israël, que les Égyptiens tiennent dans la servitude, et je me suis souvenu de mon alliance. [^5] C’est pourquoi dis aux enfants d’Israël: Je suis l’Éternel, je vous affranchirai des travaux dont vous chargent les Égyptiens, je vous délivrerai de leur servitude, et je vous sauverai à bras étendu et par de grands jugements. [^6] Je vous prendrai pour mon peuple, je serai votre Dieu, et vous saurez que c’est moi, l’Éternel, votre Dieu, qui vous affranchis des travaux dont vous chargent les Égyptiens. [^7] Je vous ferai entrer dans le pays que j’ai juré de donner à Abraham, à Isaac et à Jacob; je vous le donnerai en possession, moi l’Éternel. [^8] Ainsi parla Moïse aux enfants d’Israël. Mais l’angoisse et la dure servitude les empêchèrent d’écouter Moïse. [^9] L’Éternel parla à Moïse, et dit: [^10] Va, parle à Pharaon, roi d’Égypte, pour qu’il laisse aller les enfants d’Israël hors de son pays. [^11] Moïse répondit en présence de l’Éternel: Voici, les enfants d’Israël ne m’ont point écouté; comment Pharaon m’écouterait-il, #Ex 4:10; 6:29.moi qui n’ai pas la parole facile? [^12] L’Éternel parla à Moïse et à Aaron, et leur donna des ordres au sujet des enfants d’Israël et au sujet de Pharaon, roi d’Égypte, pour faire sortir du pays d’Égypte les enfants d’Israël. [^13] Voici les chefs de leurs familles. #Ge 46:9. No 26:5. 1 Ch 5:3.Fils de Ruben, premier-né d’Israël: Hénoc, Pallu, Hetsron et Carmi. Ce sont là les familles de Ruben. [^14] #Ge 46:10. No 26:12. 1 Ch 4:24.Fils de Siméon: Jemuel, Jamin, Ohad, Jakin et Tsochar; et Saül, fils de la Cananéenne. Ce sont là les familles de Siméon. [^15] #Ge 46:11. No 3:17; 26:57. 1 Ch 6:1, 16; 23:6.Voici les noms des fils de Lévi, avec leur postérité: Guerschon, Kehath et Merari. Les années de la vie de Lévi furent de cent trente-sept ans. [^16] #1 Ch 6:17; 23:6.Fils de Guerschon: Libni et Schimeï, et leurs familles. [^17] #1 Ch 6:18; 23:12.Fils de Kehath: Amram, Jitsehar, Hébron et Uziel. Les années de la vie de Kehath furent de cent trente-trois ans. [^18] #1 Ch 6:19; 23:21.Fils de Merari: Machli et Muschi. Ce sont là les familles de Lévi, avec leur postérité. [^19] #Ex 2:1. No 26:59.Amram prit pour femme Jokébed, sa tante; et elle lui enfanta Aaron, et Moïse. Les années de la vie d’Amram furent de cent trente-sept ans. [^20] Fils de Jitsehar: Koré, Népheg et Zicri. [^21] Fils d’Uziel: Mischaël, Eltsaphan et Sithri. [^22] #No 3:2; 26:60.Aaron prit pour femme Élischéba, fille d’Amminadab, sœur de Nachschon; et #1 Ch 6:3; 24:1.elle lui enfanta Nadab, Abihu, Éléazar et Ithamar. [^23] Fils de Koré: Assir, Elkana et Abiasaph. Ce sont là les familles des Korites. [^24] Éléazar, fils d’Aaron, prit pour femme une des filles de Puthiel; et elle lui enfanta Phinées. Tels sont les chefs de famille des Lévites, avec leurs familles. [^25] Ce sont là cet Aaron et ce Moïse, à qui l’Éternel dit: Faites sortir du pays d’Égypte les enfants d’Israël, selon leurs armées. [^26] Ce sont eux qui parlèrent à Pharaon, roi d’Égypte, pour faire sortir d’Égypte les enfants d’Israël. Ce sont là ce Moïse et cet Aaron. [^27] Lorsque l’Éternel parla à Moïse dans le pays d’Égypte, [^28] l’Éternel dit à Moïse: Je suis l’Éternel. Dis à Pharaon, roi d’Égypte, tout ce que je te dis. [^29] Et Moïse répondit en présence de l’Éternel: Voici, #Ex 4:10; 6:11.je n’ai pas la parole facile; comment Pharaon m’écouterait-il? [^30] 

[[Exodus - 5|<--]] Exodus - 6 [[Exodus - 7|-->]]

---
# Notes
