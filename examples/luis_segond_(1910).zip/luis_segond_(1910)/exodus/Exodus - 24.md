---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 24 - Luis Segond (1910)"
---
[[Exodus - 23|<--]] Exodus - 24 [[Exodus - 25|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Exodus]]

# Exodus - 24

Dieu dit à Moïse: Monte vers l’Éternel, toi et Aaron, Nadab et Abihu, et soixante-dix des anciens d’Israël, et vous vous prosternerez de loin. [^1] Moïse s’approchera seul de l’Éternel; les autres ne s’approcheront pas, et le peuple ne montera point avec lui. [^2] Moïse vint rapporter au peuple toutes les paroles de l’Éternel et toutes les lois. #Ex 19:8; 24:7. De 5:27.Le peuple entier répondit d’une même voix: Nous ferons tout ce que l’Éternel a dit. [^3] Moïse écrivit toutes les paroles de l’Éternel. Puis il se leva de bon matin; il bâtit un autel au pied de la montagne, et dressa douze pierres pour les douze tribus d’Israël. [^4] Il envoya des jeunes hommes, enfants d’Israël, pour offrir à l’Éternel des holocaustes, et immoler des taureaux en sacrifices d’actions de grâces. [^5] Moïse prit la moitié du sang, qu’il mit dans des bassins, et il répandit l’autre moitié sur l’autel. [^6] Il prit le livre de l’alliance, et le lut en présence du peuple; ils dirent: Nous ferons tout ce que l’Éternel a dit, et nous obéirons. [^7] Moïse prit le sang, et il le répandit sur le peuple, en disant: #Hé 9:20. 1 Pi 1:2.Voici le sang de l’alliance que l’Éternel a faite avec vous selon toutes ces paroles. [^8] Moïse monta avec Aaron, Nadab et Abihu, et soixante-dix anciens d’Israël. [^9] Ils virent le Dieu d’Israël; sous ses pieds, c’était comme un ouvrage de saphir transparent, comme le ciel lui-même dans sa pureté. [^10] Il n’étendit point sa main sur l’élite des enfants d’Israël. Ils virent Dieu, et ils mangèrent et burent. [^11] L’Éternel dit à Moïse: Monte vers moi sur la montagne, et reste là; je te donnerai des tables de pierre, la loi et les ordonnances que j’ai écrites pour leur instruction. [^12] Moïse se leva, avec Josué qui le servait, et Moïse monta sur la montagne de Dieu. [^13] Il dit aux anciens: Attendez-nous ici, jusqu’à ce que nous revenions auprès de vous. Voici, Aaron et Hur resteront avec vous; si quelqu’un a un différend, c’est à eux qu’il s’adressera. [^14] Moïse monta sur la montagne, et la nuée couvrit la montagne. [^15] La gloire de l’Éternel reposa sur la montagne de Sinaï, et la nuée la couvrit pendant six jours. Le septième jour, l’Éternel appela Moïse du milieu de la nuée. [^16] #Hé 12:29.L’aspect de la gloire de l’Éternel était comme un feu dévorant sur le sommet de la montagne, aux yeux des enfants d’Israël. [^17] Moïse entra au milieu de la nuée, et il monta sur la montagne. Moïse demeura sur la montagne quarante jours et quarante nuits. [^18] 

[[Exodus - 23|<--]] Exodus - 24 [[Exodus - 25|-->]]

---
# Notes
