---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 19 - Luis Segond (1910)"
---
[[Exodus - 18|<--]] Exodus - 19 [[Exodus - 20|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Exodus]]

# Exodus - 19

Le troisième mois après leur sortie du pays d’Égypte, les enfants d’Israël arrivèrent ce jour-là au désert de Sinaï. [^1] Étant partis de Rephidim, ils arrivèrent au désert de Sinaï, et ils campèrent dans le désert; Israël campa là, vis-à-vis de la montagne. [^2] #Ac 7:38.Moïse monta vers Dieu: et l’Éternel l’appela du haut de la montagne, en disant: Tu parleras ainsi à la maison de Jacob, et tu diras aux enfants d’Israël: [^3] #De 29:2; 32:11.Vous avez vu ce que j’ai fait à l’Égypte, et comment je vous ai portés sur des ailes d’aigle et amenés vers moi. [^4] Maintenant, si vous écoutez ma voix, et si vous gardez mon alliance, #De 7:6; 10:14, 15; 14:2; 26:18. Ps 135:4. És 41:8. Tit 2:14.vous m’appartiendrez entre tous les peuples, car #Ps 24:1.toute la terre est à moi; [^5] #1 Pi 2:9.vous serez pour moi un royaume de sacrificateurs et une nation sainte. Voilà les paroles que tu diras aux enfants d’Israël. [^6] Moïse vint appeler les anciens du peuple, et il mit devant eux toutes ces paroles, comme l’Éternel le lui avait ordonné. [^7] Le peuple tout entier répondit: #Ex 24:3.Nous ferons tout ce que l’Éternel a dit. Moïse rapporta les paroles du peuple à l’Éternel. [^8] Et l’Éternel dit à Moïse: Voici, je viendrai vers toi dans une épaisse nuée, afin que le peuple entende quand je te parlerai, et qu’il ait toujours confiance en toi. Moïse rapporta les paroles du peuple à l’Éternel. [^9] Et l’Éternel dit à Moïse: Va vers le peuple; sanctifie-les aujourd’hui et demain, qu’ils lavent leurs vêtements. [^10] Qu’ils soient prêts pour le troisième jour; car le troisième jour l’Éternel descendra, aux yeux de tout le peuple, sur la montagne de Sinaï. [^11] Tu fixeras au peuple des limites tout à l’entour, et tu diras: #Hé 12:18.Gardez-vous de monter sur la montagne, ou d’en toucher le bord. Quiconque touchera la montagne sera puni de mort. [^12] On ne mettra pas la main sur lui, mais on le lapidera, ou on le percera de flèches: animal ou homme, il ne vivra point. Quand la trompette sonnera, ils s’avanceront près de la montagne. [^13] Moïse descendit de la montagne vers le peuple; il sanctifia le peuple, et ils lavèrent leurs vêtements. [^14] Et il dit au peuple: Soyez prêts dans trois jours; #1 S 21:4. 1 Co 7:5.ne vous approchez d’aucune femme. [^15] Le troisième jour au matin, #Hé 12:18.il y eut des tonnerres, des éclairs, et une épaisse nuée sur la montagne; le son de la trompette retentit fortement; et tout le peuple qui était dans le camp fut saisi d’épouvante. [^16] Moïse fit sortir le peuple du camp, à la rencontre de Dieu; #De 4:10, 11.et ils se placèrent au bas de la montagne. [^17] #Jg 5:4. Ps 68:9; 114:4. Ha 3:10.La montagne de Sinaï était toute en fumée, parce que l’Éternel y était descendu au milieu du feu; cette fumée s’élevait comme la fumée d’une fournaise, et toute la montagne tremblait avec violence. [^18] Le son de la trompette retentissait de plus en plus fortement. Moïse parlait, et Dieu lui répondait à haute voix. [^19] Ainsi l’Éternel descendit sur la montagne de Sinaï, sur le sommet de la montagne; l’Éternel appela Moïse sur le sommet de la montagne. Et Moïse monta. [^20] L’Éternel dit à Moïse: Descends, fais au peuple la défense expresse de se précipiter vers l’Éternel, pour regarder, de peur qu’un grand nombre d’entre eux ne périssent. [^21] Que les sacrificateurs, qui s’approchent de l’Éternel, se sanctifient aussi, de peur que l’Éternel ne les frappe de mort. [^22] Moïse dit à l’Éternel: Le peuple ne pourra pas monter sur la montagne de Sinaï, car tu nous en as fait la défense expresse, en disant: Fixe des limites autour de la montagne, et sanctifie-la. [^23] L’Éternel lui dit: Va, descends; tu monteras ensuite avec Aaron; mais que les sacrificateurs et le peuple ne se précipitent point pour monter vers l’Éternel, de peur qu’il ne les frappe de mort. [^24] Moïse descendit vers le peuple, et lui dit ces choses. [^25] 

[[Exodus - 18|<--]] Exodus - 19 [[Exodus - 20|-->]]

---
# Notes
