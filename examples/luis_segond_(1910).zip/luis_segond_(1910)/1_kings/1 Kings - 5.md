---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_kings"
  - "#bible/testament/old"
aliases:
  - "1 Kings - 5 - Luis Segond (1910)"
---
[[1 Kings - 4|<--]] 1 Kings - 5 [[1 Kings - 6|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[1 Kings]]

# 1 Kings - 5

Hiram, roi de Tyr, envoya ses serviteurs vers Salomon, car il apprit qu’on l’avait oint pour roi à la place de son père, et #2 S 5:11. 1 Ch 14:1.il avait toujours aimé David. [^1] Salomon fit dire à Hiram: [^2] #1 Ch 28:3.Tu sais que David, mon père, n’a pas pu bâtir une maison à l’Éternel, son Dieu, à cause des guerres dont ses ennemis l’ont enveloppé jusqu’à ce que l’Éternel les eût mis sous la plante de ses pieds. [^3] Maintenant l’Éternel, mon Dieu, m’a donné du repos de toutes parts; plus d’adversaires, plus de calamités! [^4] Voici, #2 Ch 2:1.j’ai l’intention de bâtir une maison au nom de l’Éternel, mon Dieu, comme l’Éternel l’a déclaré à David, mon père, en disant: #2 S 7:13. 1 Ch 22:10.Ton fils que je mettrai à ta place sur ton trône, ce sera lui qui bâtira une maison à mon nom. [^5] Ordonne maintenant que l’on coupe pour moi des cèdres du Liban. Mes serviteurs seront avec les tiens, et je te paierai le salaire de tes serviteurs tel que tu l’auras fixé; car tu sais qu’il n’y a personne parmi nous qui s’entende à couper les bois comme les Sidoniens. [^6] Lorsqu’il entendit les paroles de Salomon, Hiram eut une grande joie, et il dit: Béni soit aujourd’hui l’Éternel, qui a donné à David un fils sage pour chef de ce grand peuple! [^7] Et Hiram fit répondre à Salomon: J’ai entendu ce que tu m’as envoyé dire. Je ferai tout ce qui te plaira au sujet des bois de cèdre et des bois de cyprès. [^8] Mes serviteurs les descendront du Liban à la mer, et je les expédierai par mer en radeaux jusqu’au lieu que tu m’indiqueras; là, je les ferai délier, et tu les prendras. Ce que je désire en retour, c’est que tu fournisses des vivres à ma maison. [^9] Hiram donna à Salomon des bois de cèdre et des bois de cyprès autant qu’il en voulut. [^10] Et Salomon donna à Hiram vingt mille cors de froment pour l’entretien de sa maison et vingt cors d’huile d’olives concassées; c’est ce que Salomon donna chaque année à Hiram. [^11] L’Éternel donna de la sagesse à Salomon, #1 R 3:12.comme il le lui avait promis. Et il y eut paix entre Hiram et Salomon, et ils firent alliance ensemble. [^12] Le roi Salomon leva sur tout Israël des hommes de corvée; ils étaient au nombre de trente mille. [^13] Il les envoya au Liban, dix mille par mois alternativement; ils étaient un mois au Liban, et deux mois chez eux. Adoniram était préposé sur les hommes de corvée. [^14] Salomon avait encore soixante-dix mille hommes qui portaient les fardeaux et quatre-vingt mille qui taillaient les pierres dans la montagne, [^15] sans compter les chefs, au nombre de trois mille trois cents, préposés par Salomon sur les travaux et chargés de surveiller les ouvriers. [^16] Le roi ordonna d’extraire de grandes et magnifiques pierres de taille pour les fondements de la maison. [^17] Les ouvriers de Salomon, ceux de Hiram, et les Guibliens, les taillèrent, et ils préparèrent les bois et les pierres pour bâtir la maison. [^18] 

[[1 Kings - 4|<--]] 1 Kings - 5 [[1 Kings - 6|-->]]

---
# Notes
