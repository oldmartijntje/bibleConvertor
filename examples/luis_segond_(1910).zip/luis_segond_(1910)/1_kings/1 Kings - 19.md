---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_kings"
  - "#bible/testament/old"
aliases:
  - "1 Kings - 19 - Luis Segond (1910)"
---
[[1 Kings - 18|<--]] 1 Kings - 19 [[1 Kings - 20|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[1 Kings]]

# 1 Kings - 19

Achab rapporta à Jézabel tout ce qu’avait fait Élie, et comment il avait tué par l’épée tous les prophètes. [^1] Jézabel envoya un messager à Élie, pour lui dire: Que les dieux me traitent dans toute leur rigueur, si demain, à cette heure, je ne fais de ta vie ce que tu as fait de la vie de chacun d’eux! [^2] Élie, voyant cela, se leva et s’en alla, pour sauver sa vie. Il arriva à Beer-Schéba, qui appartient à Juda, et il y laissa son serviteur. [^3] Pour lui, il alla dans le désert où, après une journée de marche, il s’assit sous un genêt, et demanda la mort, en disant: C’est assez! Maintenant, Éternel, prends mon âme, car je ne suis pas meilleur que mes pères. [^4] Il se coucha et s’endormit sous un genêt. Et voici, un ange le toucha, et lui dit: Lève-toi, mange. [^5] Il regarda, et il y avait à son chevet un gâteau cuit sur des pierres chauffées et une cruche d’eau. Il mangea et but, puis se recoucha. [^6] L’ange de l’Éternel vint une seconde fois, le toucha, et dit: Lève-toi, mange, car le chemin est trop long pour toi. [^7] Il se leva, mangea et but; et avec la force que lui donna cette nourriture, il marcha #Ex 34:28. Mt 4:2.quarante jours et quarante nuits jusqu’à la montagne de Dieu, à Horeb. [^8] Et là, il entra dans la caverne, et il y passa la nuit. Et voici, la parole de l’Éternel lui fut adressée, en ces mots: Que fais-tu ici, Élie? [^9] Il répondit: J’ai déployé mon zèle pour l’Éternel, le Dieu des armées; car les enfants d’Israël ont abandonné ton alliance, ils ont renversé tes autels, et ils ont tué par l’épée tes prophètes; #Ro 11:3.je suis resté, moi seul, et ils cherchent à m’ôter la vie. [^10] L’Éternel dit: Sors, et tiens-toi dans la montagne devant l’Éternel! Et voici, l’Éternel passa. Et devant l’Éternel, il y eut un vent fort et violent qui déchirait les montagnes et brisait les rochers: l’Éternel n’était pas dans le vent. Et après le vent, ce fut un tremblement de terre: l’Éternel n’était pas dans le tremblement de terre. [^11] Et après le tremblement de terre, un feu: l’Éternel n’était pas dans le feu. Et après le feu, un murmure doux et léger. [^12] Quand Élie l’entendit, il s’enveloppa le visage de son manteau, il sortit et se tint à l’entrée de la caverne. Et voici, une voix lui fit entendre ces paroles: Que fais-tu ici, Élie? [^13] Il répondit: J’ai déployé mon zèle pour l’Éternel, le Dieu des armées; car les enfants d’Israël ont abandonné ton alliance, ils ont renversé tes autels, et ils ont tué par l’épée tes prophètes; je suis resté, moi seul, et ils cherchent à m’ôter la vie. [^14] L’Éternel lui dit: Va, reprends ton chemin par le désert jusqu’à Damas; et quand tu seras arrivé, tu oindras Hazaël pour roi de Syrie. [^15] Tu oindras aussi Jéhu, fils de Nimschi, pour roi d’Israël; et tu oindras Élisée, fils de Schaphath, d’Abel-Mehola, pour prophète à ta place. [^16] #2 R 9:14, 15, etc.Et il arrivera que celui qui échappera à l’épée de Hazaël, Jéhu le fera mourir; et celui qui échappera à l’épée de Jéhu, Élisée le fera mourir. [^17] #Ro 11:4.Mais je laisserai en Israël sept mille hommes, tous ceux qui n’ont point fléchi les genoux devant Baal, et dont la bouche ne l’a point baisé. [^18] Élie partit de là, et il trouva Élisée, fils de Schaphath, qui labourait. Il y avait devant lui douze paires de bœufs, et il était avec la douzième. Élie s’approcha de lui, et il jeta sur lui son manteau. [^19] Élisée, quittant ses bœufs, courut après Élie, et dit: Laisse-moi embrasser mon père et ma mère, et je te suivrai. Élie lui répondit: Va, et reviens; car pense à ce que je t’ai fait. [^20] Après s’être éloigné d’Élie, il revint prendre une paire de bœufs, qu’il offrit en sacrifice; avec l’attelage des bœufs, il fit cuire leur chair, et la donna à manger au peuple. Puis il se leva, suivit Élie, et fut à son service. [^21] 

[[1 Kings - 18|<--]] 1 Kings - 19 [[1 Kings - 20|-->]]

---
# Notes
