---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_kings"
  - "#bible/testament/old"
aliases:
  - "1 Kings - 17 - Luis Segond (1910)"
---
[[1 Kings - 16|<--]] 1 Kings - 17 [[1 Kings - 18|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[1 Kings]]

# 1 Kings - 17

Élie, le Thischbite, l’un des habitants de Galaad, dit à Achab: L’Éternel est vivant, le Dieu d’Israël, dont je suis le serviteur! #Ja 5:17.il n’y aura ces années-ci ni rosée ni pluie, sinon à ma parole. [^1] Et la parole de l’Éternel fut adressée à Élie, en ces mots: [^2] Pars d’ici, dirige-toi vers l’orient, et cache-toi près du torrent de Kerith, qui est en face du Jourdain. [^3] Tu boiras de l’eau du torrent, et j’ai ordonné aux corbeaux de te nourrir là. [^4] Il partit et fit selon la parole de l’Éternel, et il alla s’établir près du torrent de Kerith, qui est en face du Jourdain. [^5] Les corbeaux lui apportaient du pain et de la viande le matin, et du pain et de la viande le soir, et il buvait de l’eau du torrent. [^6] Mais au bout d’un certain temps le torrent fut à sec, car il n’était point tombé de pluie dans le pays. [^7] Alors la parole de l’Éternel lui fut adressée en ces mots: [^8] Lève-toi, va #Lu 4:25, 26.à Sarepta, qui appartient à Sidon, et demeure là. Voici, j’y ai ordonné à une femme veuve de te nourrir. [^9] Il se leva, et il alla à Sarepta. Comme il arrivait à l’entrée de la ville, voici, il y avait là une femme veuve qui ramassait du bois. Il l’appela, et dit: Va me chercher, je te prie, un peu d’eau dans un vase, afin que je boive. [^10] Et elle alla en chercher. Il l’appela de nouveau, et dit: Apporte-moi, je te prie, un morceau de pain dans ta main. [^11] Et elle répondit: L’Éternel, ton Dieu, est vivant! Je n’ai rien de cuit, je n’ai qu’une poignée de farine dans un pot et un peu d’huile dans une cruche. Et voici, je ramasse deux morceaux de bois, puis je rentrerai et je préparerai cela pour moi et pour mon fils; nous mangerons, après quoi nous mourrons. [^12] Élie lui dit: Ne crains point, rentre, fais comme tu as dit. Seulement, prépare-moi d’abord avec cela un petit gâteau, et tu me l’apporteras; tu en feras ensuite pour toi et pour ton fils. [^13] Car ainsi parle l’Éternel, le Dieu d’Israël: La farine qui est dans le pot ne manquera point et l’huile qui est dans la cruche ne diminuera point, jusqu’au jour où l’Éternel fera tomber de la pluie sur la face du sol. [^14] Elle alla, et elle fit selon la parole d’Élie. Et pendant longtemps elle eut de quoi manger, elle et sa famille, aussi bien qu’Élie. [^15] La farine qui était dans le pot ne manqua point, et l’huile qui était dans la cruche ne diminua point, selon la parole que l’Éternel avait prononcée par Élie. [^16] Après ces choses, le fils de la femme, maîtresse de la maison, devint malade, et sa maladie fut si violente qu’il ne resta plus en lui de respiration. [^17] Cette femme dit alors à Élie: Qu’y a-t-il entre moi et toi, homme de Dieu? Es-tu venu chez moi pour rappeler le souvenir de mon iniquité, et pour faire mourir mon fils? [^18] Il lui répondit: Donne-moi ton fils. Et il le prit du sein de la femme, le monta dans la chambre haute où il demeurait, et le coucha sur son lit. [^19] Puis il invoqua l’Éternel, et dit: Éternel, mon Dieu, est-ce que tu affligerais, au point de faire mourir son fils, même cette veuve chez qui j’ai été reçu comme un hôte? [^20] Et il s’étendit trois fois sur l’enfant, invoqua l’Éternel, et dit: Éternel, mon Dieu, je t’en prie, que l’âme de cet enfant revienne au-dedans de lui! [^21] L’Éternel écouta la voix d’Élie, et l’âme de l’enfant revint au-dedans de lui, et il fut rendu à la vie. [^22] Élie prit l’enfant, le descendit de la chambre haute dans la maison, et le donna à sa mère. Et Élie dit: Vois, ton fils est vivant. [^23] Et la femme dit à Élie: Je reconnais maintenant que tu es un homme de Dieu, et que la parole de l’Éternel dans ta bouche est vérité. [^24] 

[[1 Kings - 16|<--]] 1 Kings - 17 [[1 Kings - 18|-->]]

---
# Notes
