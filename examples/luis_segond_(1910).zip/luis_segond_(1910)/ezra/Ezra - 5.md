---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/ezra"
  - "#bible/testament/old"
aliases:
  - "Ezra - 5 - Luis Segond (1910)"
---
[[Ezra - 4|<--]] Ezra - 5 [[Ezra - 6|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Ezra]]

# Ezra - 5

#    
        Ag 1:1. Za 1:1.  Aggée, le prophète, et Zacharie, fils d’Iddo, le prophète, prophétisèrent aux Juifs qui étaient en Juda et à Jérusalem, au nom du Dieu d’Israël. [^1] Alors Zorobabel, fils de Schealthiel, et Josué, fils de Jotsadak, se levèrent et commencèrent à bâtir la maison de Dieu à Jérusalem. Et avec eux étaient les prophètes de Dieu, qui les assistaient. [^2] Dans ce même temps, Thathnaï, gouverneur de ce côté du fleuve, Schethar-Boznaï, et leurs collègues, vinrent auprès d’eux et leur parlèrent ainsi: Qui vous a donné l’autorisation de bâtir cette maison et de relever ces murs? [^3] Ils leur dirent encore: Quels sont les noms des hommes qui construisent cet édifice? [^4] Mais l’œil de Dieu veillait sur les anciens des Juifs. Et on laissa continuer les travaux pendant l’envoi d’un rapport à Darius et jusqu’à la réception d’une lettre sur cet objet. [^5] Copie de la lettre envoyée au roi Darius par Thathnaï, gouverneur de ce côté du fleuve. Schethar-Boznaï, et leurs collègues d’Apharsac, demeurant de ce côté du fleuve. [^6] Ils lui adressèrent un rapport ainsi conçu:Au roi Darius, salut! [^7] Que le roi sache que nous sommes allés dans la province de Juda, à la maison du grand Dieu. Elle se construit en pierres de taille, et le bois se pose dans les murs; le travail marche rapidement et réussit entre leurs mains. [^8] Nous avons interrogé les anciens, et nous leur avons ainsi parlé: Qui vous a donné l’autorisation de bâtir cette maison et de relever ces murs? [^9] Nous leur avons aussi demandé leurs noms pour te les faire connaître, et nous avons mis par écrit les noms des hommes qui sont à leur tête. [^10] Voici la réponse qu’ils nous ont faite: Nous sommes les serviteurs du Dieu des cieux et de la terre, et nous rebâtissons la maison qui avait été construite il y a bien des années; un grand roi d’Israël l’avait bâtie et achevée. [^11] Mais  #2 Ch 36:16, 17, etc.après que nos pères eurent irrité le Dieu des cieux, il les livra entre les mains de Nebucadnetsar, roi de Babylone, le Chaldéen, qui détruisit cette maison et emmena le peuple captif à Babylone. [^12] #2 Ch 36:22, etc. Esd 1, etc.Toutefois, la première année de Cyrus, roi de Babylone, le roi Cyrus donna l’ordre de rebâtir cette maison de Dieu. [^13] Et même le roi Cyrus ôta du temple de Babylone les ustensiles d’or et d’argent de la maison de Dieu, que Nebucadnetsar avait enlevés du temple de Jérusalem et transportés dans le temple de Babylone, il les fit  #Esd 1:8.remettre au nommé Scheschbatsar, qu’il établit gouverneur, [^14] et il lui dit: Prends ces ustensiles, va les déposer dans le temple de Jérusalem, et que la maison de Dieu soit rebâtie sur le lieu où elle était. [^15] Ce Scheschbatsar est donc venu, et il a posé les fondements de la maison de Dieu à Jérusalem; depuis lors jusqu’à présent elle se construit, et elle n’est pas achevée. [^16] Maintenant, si le roi le trouve bon, que l’on fasse des recherches dans la maison des trésors du roi à Babylone, pour voir s’il y a eu de la part du roi Cyrus un ordre donné pour la construction de cette maison de Dieu à Jérusalem. Puis, que le roi nous transmette sa volonté sur cet objet. [^17] 

[[Ezra - 4|<--]] Ezra - 5 [[Ezra - 6|-->]]

---
# Notes
