---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/ezra"
  - "#bible/testament/old"
aliases:
  - "Ezra - 9 - Luis Segond (1910)"
---
[[Ezra - 8|<--]] Ezra - 9 [[Ezra - 10|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Ezra]]

# Ezra - 9

Après que cela fut terminé, les chefs s’approchèrent de moi, en disant: Le peuple d’Israël, les sacrificateurs et les Lévites ne se sont point séparés des peuples de ces pays, et ils imitent leurs abominations, celles des Cananéens, des Héthiens, des Phéréziens, des Jébusiens, des Ammonites, des Moabites, des Égyptiens et des Amoréens. [^1] Car ils ont pris de leurs filles pour eux et pour leurs fils, et ont mêlé la race sainte avec les peuples de ces pays; et les chefs et les magistrats ont été les premiers à commettre ce péché. [^2] Lorsque j’entendis cela, je déchirai mes vêtements et mon manteau, je m’arrachai les cheveux de la tête et les poils de la barbe, et je m’assis désolé. [^3] Auprès de moi s’assemblèrent tous ceux que faisaient trembler les paroles du Dieu d’Israël, à cause du péché des fils de la captivité; et moi, je restai assis et désolé, jusqu’à l’offrande du soir. [^4] Puis, au moment de l’offrande du soir, je me levai du sein de mon humiliation, avec mes vêtements et mon manteau déchirés, je tombai à genoux, j’étendis les mains vers l’Éternel, mon Dieu, [^5] et je dis: Mon Dieu, je suis dans la confusion, et j’ai honte, ô mon Dieu, de lever ma face vers toi; car nos iniquités se sont #Ps 38:5.multipliées par-dessus nos têtes, et nos fautes ont atteint jusqu’aux cieux. [^6] Depuis les jours de nos pères nous avons été grandement coupables jusqu’à ce jour, et c’est à cause de nos iniquités que nous avons été livrés, nous, nos rois et nos sacrificateurs, aux mains des rois étrangers, à l’épée, à la captivité, au pillage, et à la honte qui couvre aujourd’hui notre visage. [^7] Et cependant l’Éternel, notre Dieu, vient de nous faire grâce en nous laissant quelques réchappés et en nous accordant un abri dans son saint lieu, afin d’éclaircir nos yeux et de nous donner un peu de vie au milieu de notre servitude. [^8] Car nous sommes esclaves, mais Dieu ne nous a pas abandonnés dans notre servitude. Il nous a rendus les objets de la bienveillance des rois de Perse, pour nous conserver la vie afin que nous puissions bâtir la maison de notre Dieu et en relever les ruines, et pour nous donner une retraite en Juda et à Jérusalem. [^9] Maintenant, que dirons-nous après cela, ô notre Dieu? Car nous avons abandonné tes commandements, [^10] que tu nous avais prescrits par tes serviteurs les prophètes, en disant: Le pays dans #Lé 18:25, 27. De 7:3.lequel vous entrez pour le posséder est un pays souillé par les impuretés des peuples de ces contrées, par les abominations dont ils l’ont rempli d’un bout à l’autre avec leurs impuretés; [^11] ne donnez donc point vos filles à leurs fils et ne prenez point leurs filles pour vos fils, et n’ayez jamais souci ni de leur prospérité ni de leur bien-être, et ainsi vous deviendrez forts, vous mangerez les meilleures productions du pays, et vous le laisserez pour toujours en héritage à vos fils. [^12] Après tout ce qui nous est arrivé à cause des mauvaises actions et des grandes fautes que nous avons commises, quoique tu ne nous aies pas, ô notre Dieu, punis en proportion de nos iniquités, et maintenant que tu nous as conservé ces réchappés, [^13] recommencerions-nous à violer tes commandements et à nous allier avec ces peuples abominables? Ta colère n’éclaterait-elle pas encore contre nous jusqu’à nous détruire, sans laisser ni reste ni réchappés? [^14] Éternel, Dieu d’Israël, tu es juste, car nous sommes aujourd’hui un reste de réchappés. Nous voici devant toi comme des coupables, et nous ne saurions ainsi subsister devant ta face. [^15] 

[[Ezra - 8|<--]] Ezra - 9 [[Ezra - 10|-->]]

---
# Notes
