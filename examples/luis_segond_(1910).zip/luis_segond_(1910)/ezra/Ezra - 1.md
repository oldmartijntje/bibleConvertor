---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/ezra"
  - "#bible/testament/old"
aliases:
  - "Ezra - 1 - Luis Segond (1910)"
---
Ezra - 1 [[Ezra - 2|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Ezra]]

# Ezra - 1

#    
        2 Ch 36:22.  La première année de Cyrus, roi de Perse, afin que s’accomplît #Jé 25:12; 29:10.la parole de l’Éternel prononcée par la bouche de Jérémie, l’Éternel réveilla l’esprit de Cyrus, roi de Perse, qui fit faire de vive voix et par écrit cette publication dans tout son royaume: [^1] Ainsi parle Cyrus, roi des Perses: L’Éternel, le Dieu des cieux, m’a donné tous les royaumes de la terre, et il m’a commandé de lui bâtir une maison à Jérusalem en Juda. [^2] Qui d’entre vous est de son peuple? Que son Dieu soit avec lui, et qu’il monte à Jérusalem en Juda et bâtisse la maison de l’Éternel, le Dieu d’Israël! C’est le Dieu qui est à Jérusalem. [^3] Dans tout lieu où séjournent des restes du peuple de l’Éternel, les gens du lieu leur donneront de l’argent, de l’or, des effets, et du bétail, avec des offrandes volontaires pour la maison de Dieu qui est à Jérusalem. [^4] Les chefs de famille de Juda et de Benjamin, les sacrificateurs et les Lévites, tous ceux dont Dieu réveilla l’esprit, se levèrent pour aller bâtir la maison de l’Éternel à Jérusalem. [^5] Tous leurs alentours leur donnèrent des objets d’argent, de l’or, des effets, du bétail, et des choses précieuses, outre toutes les offrandes volontaires. [^6] Le roi Cyrus rendit les ustensiles de la maison de l’Éternel, que #2 R 24:13. 2 Ch 36:7.Nebucadnetsar avait emportés de Jérusalem et placés dans la maison de son dieu. [^7] Cyrus, roi de Perse, les fit sortir par Mithredath, le trésorier, qui les #Esd 5:1.remit à Scheschbatsar, prince de Juda. [^8] En voici le nombre: trente bassins d’or, mille bassins d’argent, vingt-neuf couteaux, [^9] trente coupes d’or, quatre cent dix coupes d’argent de second ordre, mille autres ustensiles. [^10] Tous les objets d’or et d’argent étaient au nombre de cinq mille quatre cents. Scheschbatsar emporta le tout de Babylone à Jérusalem, au retour de la captivité. [^11] 

Ezra - 1 [[Ezra - 2|-->]]

---
# Notes
