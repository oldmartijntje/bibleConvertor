---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/ezra"
  - "#bible/testament/old"
aliases:
  - "Ezra - 3 - Luis Segond (1910)"
---
[[Ezra - 2|<--]] Ezra - 3 [[Ezra - 4|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Ezra]]

# Ezra - 3

Le septième mois arriva, et les enfants d’Israël étaient dans leurs villes. Alors le peuple s’assembla comme un seul homme à Jérusalem. [^1] Josué, fils de Jotsadak, avec ses frères les sacrificateurs, et Zorobabel, fils de Schealthiel, avec ses frères, se levèrent et bâtirent l’autel du Dieu d’Israël, pour y offrir des holocaustes, selon #De 12:5, 6.ce qui est écrit dans la loi de Moïse, homme de Dieu. [^2] Ils rétablirent l’autel sur ses fondements, quoiqu’ils eussent à craindre les peuples du pays, et ils y offrirent des holocaustes à l’Éternel, les holocaustes #No 28:3.du matin et du soir. [^3] Ils célébrèrent la fête des tabernacles, comme il est écrit, et ils offrirent jour par jour des holocaustes, selon le nombre #Lé 23:24. No 29:12.ordonné pour chaque jour. [^4] Après cela, ils offrirent l’holocauste perpétuel, les holocaustes #No 28:11, etc. Né 10:33.des nouvelles lunes et de toutes les solennités consacrées à l’Éternel, et ceux de quiconque faisait des offrandes volontaires à l’Éternel. [^5] Dès le premier jour du septième mois, ils commencèrent à offrir à l’Éternel des holocaustes. Cependant les fondements du temple de l’Éternel n’étaient pas encore posés. [^6] On donna de l’argent aux tailleurs de pierres et aux charpentiers, et des vivres, des boissons et de l’huile aux Sidoniens et aux Tyriens, pour qu’ils amenassent par mer jusqu’à Japho des bois de cèdre du Liban, suivant l’autorisation qu’on avait eue de Cyrus, roi de Perse. [^7] La seconde année depuis leur arrivée à la maison de Dieu à Jérusalem, au second mois, Zorobabel, fils de Schealthiel, Josué, fils de Jotsadak, avec le reste de leurs frères les sacrificateurs et les Lévites, et tous ceux qui étaient revenus de la captivité à Jérusalem, se mirent à l’œuvre et chargèrent les Lévites de vingt ans et au-dessus de surveiller les travaux de la maison de l’Éternel. [^8] Et Josué, avec ses fils et ses frères, Kadmiel, avec ses fils, fils de Juda, les fils de Hénadad, avec leurs fils et leurs frères les Lévites, se préparèrent tous ensemble à surveiller ceux qui travaillaient à la maison de Dieu. [^9] Lorsque les ouvriers posèrent les fondements du temple de l’Éternel, on fit assister les sacrificateurs en costume, avec les trompettes, et les Lévites, fils d’Asaph, avec les cymbales, afin qu’ils célébrassent l’Éternel, d’après les ordonnances de David, roi d’Israël. [^10] Ils chantaient, célébrant et louant l’Éternel par ces paroles: Car il est bon, car sa miséricorde pour Israël dure à toujours! Et tout le peuple poussait de grands cris de joie en célébrant l’Éternel, parce qu’on posait les fondements de la maison de l’Éternel. [^11] Mais plusieurs des sacrificateurs et des Lévites, et des chefs de famille âgés, qui avaient vu la première maison, pleuraient à grand bruit pendant qu’on posait sous leurs yeux les fondements de cette maison. Beaucoup d’autres faisaient éclater leur joie par des cris, [^12] en sorte qu’on ne pouvait distinguer le bruit des cris de joie d’avec le bruit des pleurs parmi le peuple, car le peuple poussait de grands cris dont le son s’entendait au loin. [^13] 

[[Ezra - 2|<--]] Ezra - 3 [[Ezra - 4|-->]]

---
# Notes
