---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 16 - Luis Segond (1910)"
---
[[1 Samuel - 15|<--]] 1 Samuel - 16 [[1 Samuel - 17|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[1 Samuel]]

# 1 Samuel - 16

L’Éternel dit à Samuel: Quand cesseras-tu de pleurer sur Saül? Je l’ai rejeté, afin qu’il ne règne plus sur Israël. Remplis ta corne d’huile, et va; je t’enverrai chez Isaï, Bethléhémite, car j’ai vu parmi ses fils celui que je désire pour roi. [^1] Samuel dit: Comment irai-je? Saül l’apprendra, et il me tuera. Et l’Éternel dit: Tu emmèneras avec toi une génisse, et tu diras: Je viens pour offrir un sacrifice à l’Éternel. [^2] Tu inviteras Isaï au sacrifice; je te ferai connaître ce que tu dois faire, et tu oindras pour moi celui que je te dirai. [^3] Samuel fit ce que l’Éternel avait dit, et il alla à Bethléhem. Les anciens de la ville accoururent effrayés au-devant de lui et dirent: Ton arrivée annonce-t-elle quelque chose d’heureux? [^4] Il répondit: Oui; je viens pour offrir un sacrifice à l’Éternel. Sanctifiez-vous, et venez avec moi au sacrifice. Il fit aussi sanctifier Isaï et ses fils, et il les invita au sacrifice. [^5] Lorsqu’ils entrèrent, il se dit, en voyant Éliab: Certainement, l’oint de l’Éternel est ici devant lui. [^6] Et l’Éternel dit à Samuel: Ne prends point garde à son apparence et à la hauteur de sa taille, car je l’ai rejeté. L’Éternel ne considère pas ce que l’homme considère; l’homme regarde à ce qui frappe les yeux, mais #1 Ch 28:9. Ps 7:10. Jé 11:20; 17:10; 20:12.l’Éternel regarde au cœur. [^7] Isaï appela Abinadab, et le fit passer devant Samuel; et Samuel dit: L’Éternel n’a pas non plus choisi celui-ci. [^8] Isaï fit passer Schamma; et Samuel dit: L’Éternel n’a pas non plus choisi celui-ci. [^9] Isaï fit passer ses sept fils devant Samuel; et Samuel dit à Isaï: L’Éternel n’a choisi aucun d’eux. [^10] Puis Samuel dit à Isaï: Sont-ce là tous tes fils? Et il répondit: Il reste encore le plus jeune, mais #2 S 7:8. Ps 78:70.il fait paître les brebis. Alors Samuel dit à Isaï: Envoie-le chercher, car nous ne nous placerons pas avant qu’il ne soit venu ici. [^11] Isaï l’envoya chercher. Or il était blond, avec de beaux yeux et une belle figure. L’Éternel dit à Samuel: Lève-toi, oins-le, car c’est lui! [^12] #Ps 89:21.Samuel prit la corne d’huile, et l’oignit au milieu de ses frères. #Ac 7:46; 13:22.L’esprit de l’Éternel saisit David, à partir de ce jour et dans la suite. Samuel se leva, et s’en alla à Rama. [^13] L’esprit de l’Éternel se retira de Saül, qui fut agité par un mauvais esprit venant de l’Éternel. [^14] Les serviteurs de Saül lui dirent: Voici, un mauvais esprit de Dieu t’agite. [^15] Que notre seigneur parle! Tes serviteurs sont devant toi. Ils chercheront un homme qui sache jouer de la harpe; et, quand le mauvais esprit de Dieu sera sur toi, il jouera de sa main, et tu seras soulagé. [^16] Saül répondit à ses serviteurs: Trouvez-moi donc un homme qui joue bien, et amenez-le-moi. [^17] L’un des serviteurs prit la parole, et dit: Voici, j’ai vu un fils d’Isaï, Bethléhémite, qui sait jouer; c’est aussi un homme fort et vaillant, un guerrier, parlant bien et d’une belle figure, et l’Éternel est avec lui. [^18] Saül envoya des messagers à Isaï, pour lui dire: Envoie-moi David, ton fils, qui est avec les brebis. [^19] Isaï prit un âne, qu’il chargea de pain, d’une outre de vin et d’un chevreau, et il envoya ces choses à Saül par David, son fils. [^20] David arriva auprès de Saül, et se présenta devant lui; il plut beaucoup à Saül, et il fut désigné pour porter ses armes. [^21] Saül fit dire à Isaï: Je te prie de laisser David à mon service, car il a trouvé grâce à mes yeux. [^22] Et lorsque l’esprit de Dieu était sur Saül, David prenait la harpe et jouait de sa main; Saül respirait alors plus à l’aise et se trouvait soulagé, et le mauvais esprit se retirait de lui. [^23] 

[[1 Samuel - 15|<--]] 1 Samuel - 16 [[1 Samuel - 17|-->]]

---
# Notes
