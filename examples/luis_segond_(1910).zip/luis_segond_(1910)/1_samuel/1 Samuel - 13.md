---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 13 - Luis Segond (1910)"
---
[[1 Samuel - 12|<--]] 1 Samuel - 13 [[1 Samuel - 14|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[1 Samuel]]

# 1 Samuel - 13

Saül était âgé de… ans, lorsqu’il devint roi, et il avait déjà régné deux ans sur Israël. [^1] Saül choisit trois mille hommes d’Israël: deux mille étaient avec lui à Micmasch et sur la montagne de Béthel, et mille étaient avec Jonathan à Guibea de Benjamin. Il renvoya le reste du peuple, chacun à sa tente. [^2] Jonathan battit le poste des Philistins qui était à Guéba, et les Philistins l’apprirent. Saül fit sonner de la trompette dans tout le pays, en disant: Que les Hébreux écoutent! [^3] Tout Israël entendit que l’on disait: Saül a battu le poste des Philistins, et Israël se rend odieux aux Philistins. Et le peuple fut convoqué auprès de Saül à Guilgal. [^4] Les Philistins s’assemblèrent pour combattre Israël. Ils avaient mille chars et six mille cavaliers, et ce peuple était innombrable comme le sable qui est sur le bord de la mer. Ils vinrent camper à Micmasch, à l’orient de Beth-Aven. [^5] Les hommes d’Israël se virent à l’extrémité, car ils étaient serrés de près, et ils se cachèrent dans les cavernes, dans les buissons, dans les rochers, dans les tours et dans les citernes. [^6] Il y eut aussi des Hébreux qui passèrent le Jourdain, pour aller au pays de Gad et de Galaad. Saül était encore à Guilgal, et tout le peuple qui se trouvait auprès de lui tremblait. [^7] Il attendit sept jours, selon le terme fixé par Samuel. Mais Samuel n’arrivait pas à Guilgal, et le peuple se dispersait loin de Saül. [^8] Alors Saül dit: Amenez-moi l’holocauste et les sacrifices d’actions de grâces. Et il offrit l’holocauste. [^9] Comme il achevait d’offrir l’holocauste, voici, Samuel arriva, et Saül sortit au-devant de lui pour le saluer. [^10] Samuel dit: Qu’as-tu fait? Saül répondit: Lorsque j’ai vu que le peuple se dispersait loin de moi, que tu n’arrivais pas au terme fixé, et que les Philistins étaient assemblés à Micmasch, [^11] je me suis dit: Les Philistins vont descendre contre moi à Guilgal, et je n’ai pas imploré l’Éternel! C’est alors que je me suis fait violence et que j’ai offert l’holocauste. [^12] Samuel dit à Saül: Tu as agi en insensé, tu n’as pas observé le commandement que l’Éternel, ton Dieu, t’avait donné. L’Éternel aurait affermi pour toujours ton règne sur Israël; [^13] et maintenant ton règne ne durera point. L’Éternel s’est choisi un homme selon son cœur, et l’Éternel l’a destiné à être le chef de son peuple, parce que tu n’as pas observé ce que l’Éternel t’avait commandé. [^14] Puis Samuel se leva, et monta de Guilgal à Guibea de Benjamin. Saül fit la revue du peuple qui se trouvait avec lui: il y avait environ six cents hommes. [^15] Saül, son fils Jonathan, et le peuple qui se trouvait avec eux, avaient pris position à Guéba de Benjamin, et les Philistins campaient à Micmasch. [^16] Il sortit du camp des Philistins trois corps pour ravager: l’un prit le chemin d’Ophra, vers le pays de Schual; [^17] l’autre prit le chemin de Beth-Horon; et le troisième prit le chemin de la frontière qui regarde la vallée de Tseboïm, du côté du désert. [^18] #Jg 5:8.On ne trouvait point de forgeron dans tout le pays d’Israël; car les Philistins avaient dit: Empêchons les Hébreux de fabriquer des épées ou des lances. [^19] Et chaque homme en Israël descendait chez les Philistins pour aiguiser son soc, son hoyau, sa hache et sa bêche, [^20] quand le tranchant des bêches, des hoyaux, des tridents et des haches, était émoussé, et pour redresser les aiguillons. [^21] Il arriva qu’au jour du combat il ne se trouvait ni épée ni lance entre les mains de tout le peuple qui était avec Saül et Jonathan; il ne s’en trouvait qu’auprès de Saül et de Jonathan, son fils. [^22] Un poste de Philistins vint s’établir au passage de Micmasch. [^23] 

[[1 Samuel - 12|<--]] 1 Samuel - 13 [[1 Samuel - 14|-->]]

---
# Notes
