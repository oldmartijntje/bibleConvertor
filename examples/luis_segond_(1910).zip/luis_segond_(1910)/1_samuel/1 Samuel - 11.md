---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 11 - Luis Segond (1910)"
---
[[1 Samuel - 10|<--]] 1 Samuel - 11 [[1 Samuel - 12|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[1 Samuel]]

# 1 Samuel - 11

Nachasch, l’Ammonite, vint assiéger Jabès en Galaad. Tous les habitants de Jabès dirent à Nachasch: Traite alliance avec nous, et nous te servirons. [^1] Mais Nachasch, l’Ammonite, leur répondit: Je traiterai avec vous à la condition que je vous crève à tous l’œil droit, et que j’imprime ainsi un opprobre sur tout Israël. [^2] Les anciens de Jabès lui dirent: Accorde-nous une trêve de sept jours, afin que nous envoyions des messagers dans tout le territoire d’Israël; et s’il n’y a personne qui nous secoure, nous nous rendrons à toi. [^3] Les messagers arrivèrent à Guibea de Saül, et dirent ces choses aux oreilles du peuple. Et tout le peuple éleva la voix, et pleura. [^4] Et voici, Saül revenait des champs, derrière ses bœufs, et il dit: Qu’a donc le peuple pour pleurer? On lui raconta ce qu’avaient dit ceux de Jabès. [^5] Dès que Saül eut entendu ces choses, il fut saisi par l’esprit de Dieu, et sa colère s’enflamma fortement. [^6] Il prit une paire de bœufs, et les coupa en morceaux, qu’il envoya par les messagers dans tout le territoire d’Israël, en disant: Quiconque ne marchera pas à la suite de Saül et de Samuel, aura ses bœufs traités de la même manière. La terreur de l’Éternel s’empara du peuple, qui #Jg 20:1.se mit en marche comme un seul homme. [^7] Saül en fit la revue à Bézek; les enfants d’Israël étaient trois cent mille, et les hommes de Juda trente mille. [^8] Ils dirent aux messagers qui étaient venus: Vous parlerez ainsi aux habitants de Jabès en Galaad: Demain vous aurez du secours, quand le soleil sera dans sa chaleur. Les messagers portèrent cette nouvelle à ceux de Jabès, qui furent remplis de joie; [^9] et qui dirent aux Ammonites: Demain nous nous rendrons à vous, et vous nous traiterez comme bon vous semblera. [^10] Le lendemain, Saül divisa le peuple en trois corps. Ils pénétrèrent dans le camp des Ammonites à la veille du matin, et ils les battirent jusqu’à la chaleur du jour. Ceux qui échappèrent furent dispersés, et il n’en resta pas deux ensemble. [^11] Le peuple dit à Samuel: #1 S 10:27.Qui est-ce qui disait: Saül régnera-t-il sur nous? Livrez ces gens, et nous les ferons mourir. [^12] Mais Saül dit: Personne ne sera mis à mort en ce jour, car aujourd’hui l’Éternel a opéré une délivrance en Israël. [^13] Et Samuel dit au peuple: Venez, et allons à Guilgal, pour y confirmer la royauté. [^14] Tout le peuple se rendit à Guilgal, et ils établirent Saül pour roi, devant l’Éternel, à Guilgal. Là, ils offrirent des sacrifices d’actions de grâces devant l’Éternel; et là, Saül et tous les hommes d’Israël se livrèrent à de grandes réjouissances. [^15] 

[[1 Samuel - 10|<--]] 1 Samuel - 11 [[1 Samuel - 12|-->]]

---
# Notes
