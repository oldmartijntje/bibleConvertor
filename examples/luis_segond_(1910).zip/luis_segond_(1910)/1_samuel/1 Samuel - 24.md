---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 24 - Luis Segond (1910)"
---
[[1 Samuel - 23|<--]] 1 Samuel - 24 [[1 Samuel - 25|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[1 Samuel]]

# 1 Samuel - 24

De là David monta vers les lieux forts d’En-Guédi, où il demeura. [^1] Lorsque Saül fut revenu de la poursuite des Philistins, on vint lui dire: Voici, David est dans le désert d’En-Guédi. [^2] Saül prit trois mille hommes d’élite sur tout Israël, et il alla chercher David et ses gens jusque sur les rochers des boucs sauvages. [^3] Il arriva à des parcs de brebis, qui étaient près du chemin; et là se trouvait une caverne, où il entra pour se couvrir les pieds. David et ses gens étaient au fond de la caverne. [^4] Les gens de David lui dirent: Voici le jour où l’Éternel te dit: Je livre ton ennemi entre tes mains; traite-le comme bon te semblera. David se leva, et coupa doucement le pan du manteau de Saül. [^5] Après cela le cœur lui battit, parce qu’il avait coupé le pan du manteau de Saül. [^6] Et il dit à ses gens: Que l’Éternel me garde de commettre contre mon seigneur, l’oint de l’Éternel, une action telle que de porter ma main sur lui! Car il est l’oint de l’Éternel. [^7] Par ces paroles David arrêta ses gens, et les empêcha de se jeter sur Saül. Puis Saül se leva pour sortir de la caverne, et continua son chemin. [^8] Après cela, David se leva et sortit de la caverne. Il se mit alors à crier après Saül: O roi, mon seigneur! Saül regarda derrière lui, et David s’inclina le visage contre terre et se prosterna. [^9] David dit à Saül: Pourquoi écoutes-tu les propos des gens qui disent: Voici, David cherche ton malheur? [^10] Tu vois maintenant de tes propres yeux que l’Éternel t’avait livré aujourd’hui entre mes mains dans la caverne. On m’excitait à te tuer; mais je t’ai épargné, et j’ai dit: Je ne porterai pas la main sur mon seigneur, car il est l’oint de l’Éternel. [^11] Vois, mon père, vois donc le pan de ton manteau dans ma main. Puisque j’ai coupé le pan de ton manteau et que je ne t’ai pas tué, sache et reconnais qu’il n’y a dans ma conduite ni méchanceté ni révolte, et que je n’ai point péché contre toi. Et toi, tu me dresses des embûches, pour m’ôter la vie! [^12] L’Éternel sera juge entre moi et toi, et l’Éternel me vengera de toi; mais je ne porterai point la main sur toi. [^13] Des méchants vient la méchanceté, dit l’ancien proverbe. Aussi je ne porterai point la main sur toi. [^14] Contre qui le roi d’Israël s’est-il mis en marche? Qui poursuis-tu? Un chien mort, une puce. [^15] L’Éternel jugera et prononcera entre moi et toi; il regardera, il défendra ma cause, il me rendra justice en me délivrant de ta main. [^16] Lorsque David eut fini d’adresser à Saül ces paroles, Saül dit: Est-ce bien ta voix, mon fils David? Et Saül éleva la voix et pleura. [^17] Et il dit à David: Tu es plus juste que moi; car tu m’as fait du bien, et moi je t’ai fait du mal. [^18] Tu manifestes aujourd’hui la bonté avec laquelle tu agis envers moi, puisque l’Éternel m’avait livré entre tes mains et que tu ne m’as pas tué. [^19] Si quelqu’un rencontre son ennemi, le laisse-t-il poursuivre tranquillement son chemin? Que l’Éternel te récompense pour ce que tu m’as fait en ce jour! [^20] Maintenant voici, je sais que tu régneras, et que la royauté d’Israël restera entre tes mains. [^21] Jure-moi donc par l’Éternel que tu ne détruiras pas ma postérité après moi, et que tu ne retrancheras pas mon nom de la maison de mon père. [^22] David le jura à Saül. Puis Saül s’en alla dans sa maison, et David et ses gens montèrent au lieu fort. [^23] 

[[1 Samuel - 23|<--]] 1 Samuel - 24 [[1 Samuel - 25|-->]]

---
# Notes
