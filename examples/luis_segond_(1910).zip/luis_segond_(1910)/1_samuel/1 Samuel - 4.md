---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 4 - Luis Segond (1910)"
---
[[1 Samuel - 3|<--]] 1 Samuel - 4 [[1 Samuel - 5|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[1 Samuel]]

# 1 Samuel - 4

La parole de Samuel s’adressait à tout Israël. Israël sortit à la rencontre des Philistins, pour combattre. Ils campèrent près d’Ében-Ézer, et les Philistins étaient campés à Aphek. [^1] Les Philistins se rangèrent en bataille contre Israël, et le combat s’engagea. Israël fut battu par les Philistins, qui tuèrent sur le champ de bataille environ quatre mille hommes. [^2] Le peuple rentra au camp, et les anciens d’Israël dirent: Pourquoi l’Éternel nous a-t-il laissé battre aujourd’hui par les Philistins? Allons chercher à Silo l’arche de l’alliance de l’Éternel; qu’elle vienne au milieu de nous, et qu’elle nous délivre de la main de nos ennemis. [^3] Le peuple envoya à Silo, d’où l’on apporta l’arche de l’alliance de l’Éternel des armées #2 S 6:2. Ps 80:2; 99:1.qui siège entre les chérubins. Les deux fils d’Éli, Hophni et Phinées, étaient là, avec l’arche de l’alliance de Dieu. [^4] Lorsque l’arche de l’alliance de l’Éternel entra dans le camp, tout Israël poussa de grands cris de joie, et la terre en fut ébranlée. [^5] Le retentissement de ces cris fut entendu des Philistins, et ils dirent: Que signifient ces grands cris qui retentissent dans le camp des Hébreux? Et ils apprirent que l’arche de l’Éternel était arrivée au camp. [^6] Les Philistins eurent peur, parce qu’ils crurent que Dieu était venu dans le camp. Malheur à nous! Dirent-ils, car il n’en a pas été ainsi jusqu’à présent. [^7] Malheur à nous! Qui nous délivrera de la main de ces dieux puissants? Ce sont ces dieux qui ont frappé les Égyptiens de toutes sortes de plaies dans le désert. [^8] Fortifiez-vous et soyez des hommes, Philistins, de peur que vous ne soyez asservis aux Hébreux #Jg 13:1.comme ils vous ont été asservis; soyez des hommes et combattez! [^9] Les Philistins livrèrent bataille, et Israël fut battu. Chacun s’enfuit dans sa tente. La défaite fut très grande, et il tomba d’Israël trente mille hommes de pied. [^10] #1 S 2:32, 34. Ps 78:61.L’arche de Dieu fut prise, et les deux fils d’Éli, Hophni et Phinées, moururent. [^11] Un homme de Benjamin accourut du champ de bataille et vint à Silo le même jour, les vêtements déchirés et #Jos 7:6.la tête couverte de terre. [^12] Lorsqu’il arriva, Éli était dans l’attente, assis sur un siège près du chemin, car son cœur était inquiet pour l’arche de Dieu. A son entrée dans la ville, cet homme donna la nouvelle, et toute la ville poussa des cris. [^13] Éli, entendant ces cris, dit: Que signifie ce tumulte? Et aussitôt l’homme vint apporter la nouvelle à Éli. [^14] Or Éli était âgé de quatre-vingt-dix-huit ans, il avait les yeux #1 S 3:2.fixes et ne pouvait plus voir. [^15] L’homme dit à Éli: J’arrive du champ de bataille, et c’est du champ de bataille que je me suis enfui aujourd’hui. Éli dit: Que s’est-il passé, mon fils? [^16] Celui qui apportait la nouvelle dit en réponse: Israël a fui devant les Philistins, et le peuple a éprouvé une grande défaite; et même tes deux fils, Hophni et Phinées, sont morts, et l’arche de Dieu a été prise. [^17] A peine eut-il fait mention de l’arche de Dieu, qu’Éli tomba de son siège à la renverse, à côté de la porte; il se rompit la nuque et mourut, car c’était un homme vieux et pesant. Il avait été juge en Israël pendant quarante ans. [^18] Sa belle-fille, femme de Phinées, était enceinte et sur le point d’accoucher. Lorsqu’elle entendit la nouvelle de la prise de l’arche de Dieu, de la mort de son beau-père et de celle de son mari, elle se courba et accoucha, car les douleurs la surprirent. [^19] Comme elle allait mourir, les femmes qui étaient auprès d’elle lui dirent: Ne crains point, car tu as enfanté un fils! Mais elle ne répondit pas et n’y fit pas attention. [^20] Elle appela l’enfant I-Kabod, en disant: La gloire est bannie d’Israël! C’était à cause de la prise de l’arche de Dieu, et à cause de son beau-père et de son mari. [^21] Elle dit: La gloire est bannie d’Israël, car l’arche de Dieu est prise! [^22] 

[[1 Samuel - 3|<--]] 1 Samuel - 4 [[1 Samuel - 5|-->]]

---
# Notes
