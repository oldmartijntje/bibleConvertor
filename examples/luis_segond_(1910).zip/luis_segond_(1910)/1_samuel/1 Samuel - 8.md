---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 8 - Luis Segond (1910)"
---
[[1 Samuel - 7|<--]] 1 Samuel - 8 [[1 Samuel - 9|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[1 Samuel]]

# 1 Samuel - 8

Lorsque Samuel devint vieux, il établit ses fils juges sur Israël. [^1] Son fils premier-né se nommait Joël, et le second Abija; ils étaient juges à Beer-Schéba. [^2] Les fils de Samuel ne marchèrent point sur ses traces; ils se livraient à la #Ex 18:21. De 16:19.cupidité, recevaient des présents, et violaient la justice. [^3] Tous les anciens d’Israël s’assemblèrent, et vinrent auprès de Samuel à Rama. [^4] Ils lui dirent: Voici, tu es vieux, et tes fils ne marchent point sur tes traces; maintenant, #Os 13:10. Ac 16:19.établis sur nous un roi pour nous juger, comme il y en a chez toutes les nations. [^5] #1 S 12:17.Samuel vit avec déplaisir qu’ils disaient: Donne-nous un roi pour nous juger. Et Samuel pria l’Éternel. [^6] L’Éternel dit à Samuel: Écoute la voix du peuple dans tout ce qu’il te dira; car ce n’est pas toi qu’ils rejettent, c’est moi qu’ils rejettent, afin que je ne règne plus sur eux. [^7] Ils agissent à ton égard comme ils ont toujours agi depuis que je les ai fait monter d’Égypte jusqu’à ce jour; ils m’ont abandonné, pour servir d’autres dieux. [^8] Écoute donc leur voix; mais donne-leur des avertissements, et fais-leur connaître le droit du roi qui régnera sur eux. [^9] Samuel rapporta toutes les paroles de l’Éternel au peuple qui lui demandait un roi. [^10] Il dit: Voici quel sera le droit du roi qui régnera sur vous. Il prendra vos fils, et il les mettra sur ses chars et parmi ses cavaliers, afin qu’ils courent devant son char; [^11] il s’en fera des chefs de mille et des chefs de cinquante, et il les emploiera à labourer ses terres, à récolter ses moissons, à fabriquer ses armes de guerre et l’attirail de ses chars. [^12] Il prendra vos filles, pour en faire des parfumeuses, des cuisinières et des boulangères. [^13] Il prendra la meilleure partie de vos champs, de vos vignes et de vos oliviers, et la donnera à ses serviteurs. [^14] Il prendra la dîme du produit de vos semences et de vos vignes, et la donnera à ses serviteurs. [^15] Il prendra vos serviteurs et vos servantes, vos meilleurs bœufs et vos ânes, et s’en servira pour ses travaux. [^16] Il prendra la dîme de vos troupeaux, et vous-mêmes serez ses esclaves. [^17] Et alors vous crierez contre votre roi que vous vous serez choisi, mais l’Éternel ne vous exaucera point. [^18] Le peuple refusa d’écouter la voix de Samuel. Non! Dirent-ils, mais il y aura un roi sur nous, [^19] et nous aussi nous serons comme toutes les nations; notre roi nous jugera il marchera à notre tête et conduira nos guerres. [^20] Samuel, après avoir entendu toutes les paroles du peuple, les redit aux oreilles de l’Éternel. [^21] Et l’Éternel dit à Samuel: Écoute leur voix, et établis un roi sur eux. Et Samuel dit aux hommes d’Israël: Allez-vous-en chacun dans sa ville. [^22] 

[[1 Samuel - 7|<--]] 1 Samuel - 8 [[1 Samuel - 9|-->]]

---
# Notes
