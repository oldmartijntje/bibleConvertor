---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 5 - Luis Segond (1910)"
---
[[1 Samuel - 4|<--]] 1 Samuel - 5 [[1 Samuel - 6|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[1 Samuel]]

# 1 Samuel - 5

Les Philistins prirent l’arche de Dieu, et ils la transportèrent d’Ében-Ézer à Asdod. [^1] Après s’être emparés de l’arche de Dieu, les Philistins la firent entrer dans la maison de Dagon et la placèrent à côté de Dagon. [^2] Le lendemain, les Asdodiens, qui s’étaient levés de bon matin, trouvèrent Dagon étendu la face contre terre, devant l’arche de l’Éternel. Ils prirent Dagon, et le remirent à sa place. [^3] Le lendemain encore, s’étant levés de bon matin, ils trouvèrent Dagon étendu la face contre terre, devant l’arche de l’Éternel; la tête de Dagon et ses deux mains étaient abattues sur le seuil, et il ne lui restait que le tronc. [^4] C’est pourquoi jusqu’à ce jour, les prêtres de Dagon et tous ceux qui entrent dans la maison de Dagon à Asdod ne marchent point sur le seuil. [^5] La main de l’Éternel s’appesantit sur les Asdodiens, et il mit la désolation parmi eux; il les frappa d’hémorroïdes à #Ps 78:66.Asdod et dans son territoire. [^6] Voyant qu’il en était ainsi, les gens d’Asdod dirent: L’arche du Dieu d’Israël ne restera pas chez nous, car il appesantit sa main sur nous et sur Dagon, notre dieu. [^7] Et ils firent chercher et assemblèrent auprès d’eux tous les princes des Philistins, et ils dirent: Que ferons-nous de l’arche du Dieu d’Israël? Les princes répondirent: Que l’on transporte à Gath l’arche du Dieu d’Israël. Et l’on y transporta l’arche du Dieu d’Israël. [^8] Mais après qu’elle eut été transportée, la main de l’Éternel fut sur la ville, et il y eut une très grande consternation; il frappa les gens de la ville depuis le petit jusqu’au grand, et ils eurent une éruption d’hémorroïdes. [^9] Alors ils envoyèrent l’arche de Dieu à Ékron. Lorsque l’arche de Dieu entra dans Ékron, les Ékroniens poussèrent des cris, en disant: On a transporté chez nous l’arche du Dieu d’Israël, pour nous faire mourir, nous et notre peuple! [^10] Et ils firent chercher et assemblèrent tous les princes des Philistins, et ils dirent: Renvoyez l’arche du Dieu d’Israël; qu’elle retourne en son lieu, et qu’elle ne nous fasse pas mourir, nous et notre peuple. Car il y avait dans toute la ville une terreur mortelle; la main de Dieu s’y appesantissait fortement. [^11] Les gens qui ne mouraient pas étaient frappés d’hémorroïdes, et les cris de la ville montaient jusqu’au ciel. [^12] 

[[1 Samuel - 4|<--]] 1 Samuel - 5 [[1 Samuel - 6|-->]]

---
# Notes
