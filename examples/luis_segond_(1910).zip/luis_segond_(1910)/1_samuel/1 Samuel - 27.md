---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 27 - Luis Segond (1910)"
---
[[1 Samuel - 26|<--]] 1 Samuel - 27 [[1 Samuel - 28|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[1 Samuel]]

# 1 Samuel - 27

David dit en lui-même: je périrai un jour par la main de Saül; il n’y a rien de mieux pour moi que de me réfugier au pays des Philistins, afin que Saül renonce à me chercher encore dans tout le territoire d’Israël; ainsi j’échapperai à sa main. [^1] Et David se leva, lui et les six cents hommes qui étaient avec lui, et ils passèrent chez Akisch, fils de Maoc, roi de Gath. [^2] David et ses gens restèrent à Gath auprès d’Akisch; ils avaient chacun leur famille, et David avait ses deux femmes, Achinoam de Jizreel, et Abigaïl de Carmel, femme de Nabal. [^3] Saül, informé que David s’était enfui à Gath, cessa de le chercher. [^4] David dit à Akisch: Si j’ai trouvé grâce à tes yeux, qu’on me donne dans l’une des villes du pays un lieu où je puisse demeurer; car pourquoi ton serviteur habiterait-il avec toi dans la ville royale? [^5] Et ce même jour Akisch lui donna Tsiklag. C’est pourquoi Tsiklag a appartenu aux rois de Juda jusqu’à ce jour. [^6] Le temps que David demeura dans le pays des Philistins fut d’un an et quatre mois. [^7] David et ses gens montaient et faisaient des incursions chez les Gueschuriens, les Guirziens et les Amalécites; car ces nations habitaient dès les temps anciens la contrée, du côté de Schur et jusqu’au pays d’Égypte. [^8] David ravageait cette contrée; il ne laissait en vie ni homme ni femme, et il enlevait les brebis, les bœufs, les ânes, les chameaux, les vêtements, puis s’en retournait et allait chez Akisch. [^9] Akisch disait: Où avez-vous fait aujourd’hui vos courses? Et David répondait: Vers le midi de Juda, vers le midi des Jerachmeélites et vers le midi des Kéniens. [^10] David ne laissait en vie ni homme ni femme, pour les amener à Gath; car, pensait-il, ils pourraient parler contre nous et dire: Ainsi a fait David. Et ce fut là sa manière d’agir tout le temps qu’il demeura dans le pays des Philistins. [^11] Akisch se fiait à David, et il disait: Il se rend odieux à Israël, son peuple, et il sera mon serviteur à jamais. [^12] 

[[1 Samuel - 26|<--]] 1 Samuel - 27 [[1 Samuel - 28|-->]]

---
# Notes
