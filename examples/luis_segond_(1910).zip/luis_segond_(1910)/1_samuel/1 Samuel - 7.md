---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 7 - Luis Segond (1910)"
---
[[1 Samuel - 6|<--]] 1 Samuel - 7 [[1 Samuel - 8|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[1 Samuel]]

# 1 Samuel - 7

Les gens de Kirjath-Jearim vinrent, et firent monter l’arche de l’Éternel; #2 S 6:4.ils la conduisirent dans la maison d’Abinadab, sur la colline, et ils consacrèrent son fils Éléazar pour garder l’arche de l’Éternel. [^1] Il s’était passé bien du temps depuis le jour où l’arche avait été déposée à Kirjath-Jearim. Vingt années s’étaient écoulées. Alors toute la maison d’Israël poussa des gémissements vers l’Éternel. [^2] Samuel dit à toute la maison d’Israël: Si c’est de tout votre cœur que vous revenez à l’Éternel, ôtez du milieu de vous les dieux étrangers et les Astartés, #De 6:13; 10:20. Mt 4:10. Lu 4:8.dirigez votre cœur vers l’Éternel, et servez-le lui seul; et il vous délivrera de la main des Philistins. [^3] Et les enfants d’Israël ôtèrent du milieu d’eux les Baals et les Astartés, et ils servirent l’Éternel seul. [^4] Samuel dit: Assemblez tout Israël à Mitspa, et je prierai l’Éternel pour vous. [^5] Et ils s’assemblèrent à Mitspa. Ils puisèrent de l’eau et la répandirent devant l’Éternel, et ils jeûnèrent ce jour-là, en disant: Nous avons péché contre l’Éternel! Samuel jugea les enfants d’Israël à Mitspa. [^6] Les Philistins apprirent que les enfants d’Israël s’étaient assemblés à Mitspa, et les princes des Philistins montèrent contre Israël. A cette nouvelle, les enfants d’Israël eurent peur des Philistins, [^7] et ils dirent à Samuel: Ne cesse point de crier pour nous à l’Éternel, notre Dieu, afin qu’il nous sauve de la main des Philistins. [^8] Samuel prit un agneau de lait, et l’offrit tout entier en holocauste à l’Éternel. Il cria à l’Éternel pour Israël, et l’Éternel l’exauça. [^9] Pendant que Samuel offrait l’holocauste, les Philistins s’approchèrent pour attaquer Israël. L’Éternel fit retentir en ce jour son tonnerre sur les Philistins, et #Jos 10:10.les mit en déroute. Ils furent battus devant Israël. [^10] Les hommes d’Israël sortirent de Mitspa, poursuivirent les Philistins, et les battirent jusqu’au-dessous de Beth-Car. [^11] Samuel prit une pierre, qu’il plaça entre Mitspa et Schen, et il l’appela du nom #1 S 4:1.d’Ében-Ézer, en disant: Jusqu’ici l’Éternel nous a secourus. [^12] Ainsi les Philistins furent humiliés, et ils ne vinrent plus sur le territoire d’Israël. La main de l’Éternel fut contre les Philistins pendant toute la vie de Samuel. [^13] Les villes que les Philistins avaient prises sur Israël retournèrent à Israël, depuis Ékron jusqu’à Gath, avec leur territoire; Israël les arracha de la main des Philistins. Et il y eut paix entre Israël et les Amoréens. [^14] Samuel fut juge en Israël pendant toute sa vie. [^15] Il allait chaque année faire le tour de Béthel, de Guilgal et de Mitspa, et il jugeait Israël dans tous ces lieux. [^16] Puis il revenait à Rama, #1 S 8:4.où était sa maison; et là il jugeait Israël, et il y bâtit un autel à l’Éternel. [^17] 

[[1 Samuel - 6|<--]] 1 Samuel - 7 [[1 Samuel - 8|-->]]

---
# Notes
