---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 31 - Luis Segond (1910)"
---
[[1 Samuel - 30|<--]] 1 Samuel - 31

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[1 Samuel]]

# 1 Samuel - 31

Les Philistins livrèrent bataille à Israël, et les hommes d’Israël prirent la fuite devant les Philistins et tombèrent morts sur la montagne de Guilboa. [^1] Les Philistins poursuivirent Saül et ses fils, et tuèrent Jonathan, Abinadab et Malkischua, fils de Saül. [^2] L’effort du combat porta sur Saül; les archers l’atteignirent, et le blessèrent grièvement. [^3] Saül dit alors à celui qui portait ses armes: Tire ton épée, et m’en transperce, de peur que ces incirconcis ne viennent me percer et me faire subir leurs outrages. Celui qui portait ses armes ne voulut pas, car il était saisi de crainte. Et Saül prit son épée, et se jeta dessus. [^4] Celui qui portait les armes de Saül, le voyant mort, se jeta aussi sur son épée, et mourut avec lui. [^5] Ainsi périrent en même temps, dans cette journée, Saül et ses trois fils, celui qui portait ses armes, et tous ses gens. [^6] Ceux d’Israël qui étaient de ce côté de la vallée et de ce côté du Jourdain, ayant vu que les hommes d’Israël s’enfuyaient et que Saül et ses fils étaient morts, abandonnèrent leurs villes pour prendre aussi la fuite. Et les Philistins allèrent s’y établir. [^7] Le lendemain, les Philistins vinrent pour dépouiller les morts, et ils trouvèrent Saül et ses trois fils tombés sur la montagne de Guilboa. [^8] Ils coupèrent la tête de Saül, et enlevèrent ses armes. Puis ils firent #1 Ch 10:9.annoncer ces bonnes nouvelles par tout le pays des Philistins dans les maisons de leurs idoles et parmi le peuple. [^9] Ils mirent les armes de Saül dans la maison des Astartés, et ils attachèrent son cadavre sur les murs de Beth-Schan. [^10] Lorsque les habitants de Jabès en Galaad apprirent comment les Philistins avaient traité Saül, [^11] tous les vaillants hommes se levèrent, et, après avoir marché toute la nuit, ils arrachèrent des murs de Beth-Schan le cadavre de Saül et ceux de ses fils. Puis ils revinrent à Jabès, où ils les brûlèrent; [^12] ils prirent leurs os, et les enterrèrent sous le tamaris à Jabès. Et ils jeûnèrent sept jours. [^13] 

[[1 Samuel - 30|<--]] 1 Samuel - 31

---
# Notes
