---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 3 - Luis Segond (1910)"
---
[[1 Samuel - 2|<--]] 1 Samuel - 3 [[1 Samuel - 4|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[1 Samuel]]

# 1 Samuel - 3

Le jeune Samuel était au service de l’Éternel devant Éli. La parole de l’Éternel était rare en ce temps-là, les visions n’étaient pas fréquentes. [^1] En ce même temps, Éli, #1 S 4:15.qui commençait à avoir les yeux troubles et ne pouvait plus voir, était couché à sa place, [^2] la lampe de Dieu n’était pas encore éteinte, et Samuel était couché dans le temple de l’Éternel, où était l’arche de Dieu. [^3] Alors l’Éternel appela Samuel. Il répondit: Me voici! [^4] Et il courut vers Éli, et dit: Me voici, car tu m’as appelé. Éli répondit: Je n’ai point appelé; retourne te coucher. Et il alla se coucher. [^5] L’Éternel appela de nouveau Samuel. Et Samuel se leva, alla vers Éli, et dit: Me voici, car tu m’as appelé. Éli répondit: Je n’ai point appelé, mon fils, retourne te coucher. [^6] Samuel ne connaissait pas encore l’Éternel, et la parole de l’Éternel ne lui avait pas encore été révélée. [^7] L’Éternel appela de nouveau Samuel, pour la troisième fois. Et Samuel se leva, alla vers Éli, et dit: Me voici, car tu m’as appelé. Éli comprit que c’était l’Éternel qui appelait l’enfant, [^8] et il dit à Samuel: Va, couche-toi; et si l’on t’appelle, tu diras: Parle, Éternel, car ton serviteur écoute. Et Samuel alla se coucher à sa place. [^9] L’Éternel vint et se présenta, et il appela comme les autres fois: Samuel, Samuel! Et Samuel répondit: Parle, car ton serviteur écoute. [^10] Alors l’Éternel dit à Samuel: Voici, je vais faire en Israël une chose qui #2 R 21:12. Jé 19:3.étourdira les oreilles de quiconque l’entendra. [^11] En ce jour j’accomplirai sur Éli tout ce que #1 S 2:31.j’ai prononcé contre sa maison; je commencerai et j’achèverai. [^12] Je lui ai déclaré que je veux punir sa maison à perpétuité, à cause du crime dont il a connaissance, et par lequel ses fils se sont rendus méprisables, sans qu’il les ait réprimés. [^13] C’est pourquoi je jure à la maison d’Éli que jamais le crime de la maison d’Éli ne sera expié, ni par des sacrifices ni par des offrandes. [^14] Samuel resta couché jusqu’au matin, puis il ouvrit les portes de la maison de l’Éternel. Samuel craignait de raconter la vision à Éli. [^15] Mais Éli appela Samuel, et dit: Samuel, mon fils! Il répondit: Me voici! [^16] Et Éli dit: Quelle est la parole que t’a adressée l’Éternel? Ne me cache rien. Que Dieu te traite dans toute sa rigueur, si tu me caches quelque chose de tout ce qu’il t’a dit! [^17] Samuel lui raconta tout, sans lui rien cacher. Et Éli dit: C’est l’Éternel, qu’il fasse ce qui lui semblera bon! [^18] Samuel grandissait. L’Éternel était avec lui, et il ne laissa tomber à terre aucune de ses paroles. [^19] Tout Israël, depuis Dan jusqu’à Beer-Schéba, reconnut que Samuel était établi prophète de l’Éternel. [^20] L’Éternel continuait à apparaître dans Silo; car l’Éternel se révélait à Samuel, dans Silo, par la parole de l’Éternel. [^21] 

[[1 Samuel - 2|<--]] 1 Samuel - 3 [[1 Samuel - 4|-->]]

---
# Notes
