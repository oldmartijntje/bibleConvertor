---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 29 - Luis Segond (1910)"
---
[[1 Samuel - 28|<--]] 1 Samuel - 29 [[1 Samuel - 30|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[1 Samuel]]

# 1 Samuel - 29

Les Philistins rassemblèrent toutes leurs troupes à Aphek, et Israël campa près de la source de Jizreel. [^1] Les princes des Philistins s’avancèrent avec leurs centaines et leurs milliers, et David et ses gens marchaient à l’arrière-garde avec Akisch. [^2] Les princes des Philistins dirent: Que font ici ces Hébreux? Et Akisch répondit aux princes des Philistins: N’est-ce pas David, serviteur de Saül, roi d’Israël? Il y a longtemps qu’il est avec moi, et je n’ai pas trouvé la moindre chose à lui reprocher depuis son arrivée jusqu’à ce jour. [^3] Mais les princes des Philistins s’irritèrent contre Akisch, et lui dirent: #1 Ch 12:19.Renvoie cet homme, et qu’il retourne dans le lieu où tu l’as établi; qu’il ne descende pas avec nous sur le champ de bataille, afin qu’il ne soit pas pour nous un ennemi pendant le combat. Et comment cet homme rentrerait-il en grâce auprès de son maître, si ce n’est au moyen des têtes de nos gens? [^4] N’est-ce pas ce David pour qui l’on #1 S 18:7.chantait en dansant:Saül a frappé ses mille,Et David ses dix mille? [^5] Akisch appela David, et lui dit: L’Éternel est vivant! Tu es un homme droit, et j’aime à te voir aller et venir avec moi dans le camp, car je n’ai rien trouvé de mauvais en toi depuis ton arrivée auprès de moi jusqu’à ce jour; mais tu ne plais pas aux princes. [^6] Retourne donc et va-t’en en paix, pour ne rien faire de désagréable aux yeux des princes des Philistins. [^7] David dit à Akisch: Mais qu’ai-je fait, et qu’as-tu trouvé en ton serviteur depuis que je suis auprès de toi jusqu’à ce jour, pour que je n’aille pas combattre les ennemis de mon seigneur le roi? [^8] Akisch répondit à David: Je le sais, car tu es agréable à mes yeux comme un ange de Dieu; mais les princes des Philistins disent: Il ne montera point avec nous pour combattre. [^9] Ainsi lève-toi de bon matin, toi et les serviteurs de ton maître qui sont venus avec toi; levez-vous de bon matin, et partez dès que vous verrez la lumière. [^10] David et ses gens se levèrent de bonne heure, pour partir dès le matin, et retourner dans le pays des Philistins. Et les Philistins montèrent à Jizreel. [^11] 

[[1 Samuel - 28|<--]] 1 Samuel - 29 [[1 Samuel - 30|-->]]

---
# Notes
