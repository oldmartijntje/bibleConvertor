---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 19 - Luis Segond (1910)"
---
[[1 Samuel - 18|<--]] 1 Samuel - 19 [[1 Samuel - 20|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[1 Samuel]]

# 1 Samuel - 19

Saül parla à Jonathan, son fils, et à tous ses serviteurs, de faire mourir David. Mais Jonathan, fils de Saül, qui avait une grande affection pour David, [^1] l’en informa et lui dit: Saül, mon père, cherche à te faire mourir. Sois donc sur tes gardes demain matin, reste dans un lieu retiré, et cache-toi. [^2] Je sortirai et je me tiendrai à côté de mon père dans le champ où tu seras; je parlerai de toi à mon père, je verrai ce qu’il dira, et je te le rapporterai. [^3] Jonathan parla favorablement de David à Saül, son père: Que le roi, dit-il, ne commette pas un péché à l’égard de son serviteur David, car il n’en a point commis envers toi. Au contraire, il a agi pour ton bien; [^4] il a exposé sa vie, il a tué le Philistin, et l’Éternel a opéré une grande délivrance pour tout Israël. Tu l’as vu, et tu t’en es réjoui. Pourquoi pécherais-tu contre le sang innocent, et ferais-tu sans raison mourir David? [^5] Saül écouta la voix de Jonathan, et il jura, disant: L’Éternel est vivant! David ne mourra pas. [^6] Jonathan appela David, et lui rapporta toutes ces paroles; puis il l’amena auprès de Saül, en présence de qui David fut comme auparavant. [^7] La guerre continuait. David marcha contre les Philistins, et se battit avec eux; il leur fit éprouver une grande défaite, et ils s’enfuirent devant lui. [^8] #1 S 16:14; 18:10.Alors le mauvais esprit de l’Éternel fut sur Saül, qui était assis dans sa maison, sa lance à la main. [^9] David jouait, et Saül voulut le frapper avec sa lance contre la paroi. Mais David se détourna de lui, et Saül frappa de sa lance la paroi. David prit la fuite et s’échappa pendant la nuit. [^10] Saül envoya des gens vers la maison de David, pour le garder et le faire mourir au matin. Mais Mical, femme de David, l’en informa et lui dit: Si tu ne te sauves pas cette nuit, demain tu es mort. [^11] Elle le fit descendre par la fenêtre, et David s’en alla et s’enfuit. C’est ainsi qu’il échappa. [^12] Ensuite Mical prit le théraphim, qu’elle plaça dans le lit; elle mit une peau de chèvre à son chevet, et elle l’enveloppa d’une couverture. [^13] Lorsque Saül envoya des gens pour prendre David, elle dit: Il est malade. [^14] Saül les renvoya pour qu’ils le vissent, et il dit: Apportez-le-moi dans son lit, afin que je le fasse mourir. [^15] Ces gens revinrent, et voici, le théraphim était dans le lit, et une peau de chèvre à son chevet. [^16] Saül dit à Mical: Pourquoi m’as-tu trompé de la sorte, et as-tu laissé partir mon ennemi qui s’est échappé? Mical répondit à Saül: Il m’a dit: Laisse moi aller, ou je te tue! [^17] C’est ainsi que David prit la fuite et qu’il échappa. Il se rendit auprès de Samuel à Rama, et lui raconta tout ce que Saül lui avait fait. Puis il alla avec Samuel demeurer à Najoth. [^18] On le rapporta à Saül, en disant: Voici, David est à Najoth, près de Rama. [^19] Saül envoya des gens pour prendre David. Ils virent une assemblée de prophètes qui prophétisaient, ayant Samuel à leur tête. L’esprit de Dieu saisit les envoyés de Saül, et ils se mirent aussi à prophétiser eux-mêmes. [^20] On en fit rapport à Saül, qui envoya d’autres gens, et eux aussi prophétisèrent. Il en envoya encore pour la troisième fois, et ils prophétisèrent également. [^21] Alors Saül alla lui-même à Rama. Arrivé à la grande citerne qui est à Sécou, il demanda: Où sont Samuel et David? On lui répondit: Ils sont à Najoth, près de Rama. [^22] Et il se dirigea vers Najoth, près de Rama. L’esprit de Dieu fut aussi sur lui; et Saül continua son chemin en prophétisant, jusqu’à son arrivée à Najoth, près de Rama. [^23] Il ôta ses vêtements, et il prophétisa aussi devant Samuel; et il se jeta nu par terre tout ce jour-là et toute la nuit. C’est pourquoi l’on dit: Saül est-il aussi parmi les prophètes? [^24] 

[[1 Samuel - 18|<--]] 1 Samuel - 19 [[1 Samuel - 20|-->]]

---
# Notes
