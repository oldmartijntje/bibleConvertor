---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 21 - Luis Segond (1910)"
---
[[1 Samuel - 20|<--]] 1 Samuel - 21 [[1 Samuel - 22|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[1 Samuel]]

# 1 Samuel - 21

David se rendit à Nob, vers le sacrificateur Achimélec, qui accourut effrayé au-devant de lui et lui dit: Pourquoi es-tu seul et n’y a-t-il personne avec toi? [^1] David répondit au sacrificateur Achimélec: Le roi m’a donné un ordre et m’a dit: Que personne ne sache rien de l’affaire pour laquelle je t’envoie et de l’ordre que je t’ai donné. J’ai fixé un rendez-vous à mes gens. [^2] Maintenant qu’as-tu sous la main? Donne-moi cinq pains, ou ce qui se trouvera. [^3] Le sacrificateur répondit à David: Je n’ai pas de pain ordinaire sous la main, mais il y a du pain consacré; si du moins tes gens se sont abstenus de femmes! [^4] David répondit au sacrificateur: Nous nous sommes abstenus de femmes depuis trois jours que je suis parti, et tous mes gens sont purs: d’ailleurs, si c’est là un acte profane, il sera certainement aujourd’hui sanctifié par celui qui en sera l’instrument. [^5] Alors le sacrificateur lui #Mt 12:3. Mc 2:25. Lu 6:3.donna du pain consacré, car il n’y avait là d’autre pain que du pain de proposition, qu’on avait ôté de devant l’Éternel pour le remplacer par du pain chaud au moment où on l’avait pris. [^6] Là, ce même jour, un homme d’entre les serviteurs de Saül se trouvait enfermé devant l’Éternel; c’était un Édomite, nommé Doëg, chef des bergers de Saül. [^7] David dit à Achimélec: N’as-tu pas sous la main une lance ou une épée? Car je n’ai pris avec moi ni mon épée ni mes armes, parce que l’ordre du roi était pressant. [^8] Le sacrificateur répondit: Voici l’épée de Goliath, le Philistin, que tu as tué dans la vallée des térébinthes; elle est enveloppée dans un drap, derrière l’éphod; si tu veux la prendre, prends-la, car il n’y en a pas d’autre ici. Et David dit: Il n’y en a point de pareille; donne-la-moi. [^9] David se leva et s’enfuit le même jour loin de Saül. Il arriva chez Akisch, roi de Gath. [^10] Les serviteurs d’Akisch lui dirent: N’est-ce pas là David, roi du pays? N’est-ce pas celui pour qui l’on chantait en dansant:#    
        1 S 18:7.  Saül a frappé ses mille,Et David ses dix mille? [^11] David prit à cœur ces paroles, et il eut une grande crainte d’Akisch, roi de Gath. [^12] Il se montra comme fou à leurs yeux, et fit devant eux des extravagances; il faisait des marques sur les battants des portes, et il laissait couler sa salive sur sa barbe. [^13] Akisch dit à ses serviteurs: Vous voyez bien que cet homme a perdu la raison; pourquoi me l’amenez-vous? [^14] Est-ce que je manque de fous, pour que vous m’ameniez celui-ci et me rendiez témoin de ses extravagances? Faut-il qu’il entre dans ma maison? [^15] 

[[1 Samuel - 20|<--]] 1 Samuel - 21 [[1 Samuel - 22|-->]]

---
# Notes
