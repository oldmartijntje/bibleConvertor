---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 24 - Luis Segond (1910)"
---
[[Job - 23|<--]] Job - 24 [[Job - 25|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 24

Pourquoi le Tout-Puissant ne met-il pas des temps en réserve,Et pourquoi ceux qui le connaissent ne voient-ils pas ses jours? [^1] #    
        De 19:14; 27:17. Pr 22:28; 23:10.  On déplace les bornes,On vole des troupeaux, et on les fait paître; [^2] On enlève l’âne de l’orphelin,On prend pour gage le bœuf de la veuve; [^3] On repousse du chemin les indigents,#    
        Pr 28:28.  On force tous les malheureux du pays à se cacher. [^4] Et voici, comme les ânes sauvages du désert,Ils sortent le matin pour chercher de la nourriture,Ils n’ont que le désert pour trouver le pain de leurs enfants; [^5] Ils coupent le fourrage qui reste dans les champs,Ils grappillent dans la vigne de l’impie; [^6] Ils passent la nuit dans la nudité, sans vêtement,Sans couverture contre le froid; [^7] Ils sont percés par la pluie des montagnes,Et ils embrassent les rochers comme unique refuge. [^8] On arrache l’orphelin à la mamelle,On prend des gages sur le pauvre. [^9] #    
        Lé 19:13.  Ils vont tout nus, sans vêtement,Ils sont affamés, et ils portent les gerbes; [^10] Dans les enclos de l’impie ils font de l’huile,Ils foulent le pressoir, et ils ont #De 25:4. Ja 5:4.soif; [^11] Dans les villes s’exhalent les soupirs des mourants,L’âme des blessés jette des cris…Et Dieu ne prend pas garde à ces infamies! [^12] D’autres sont ennemis de la lumière,Ils n’en connaissent pas les voies,Ils n’en pratiquent pas les sentiers. [^13] L’assassin se lève au point du jour,#    
        Ps 10:8, 9.  Tue le pauvre et l’indigent,Et il dérobe pendant la nuit. [^14] #    
        Pr 7:8, 9.  L’œil de l’adultère épie le crépuscule;#    
        Ps 10:11.  Personne ne me verra, dit-il,Et il met un voile sur sa figure. [^15] La nuit ils forcent les maisons,Le jour ils se tiennent enfermés;#    
        Job 38:15. Jn 3:20.  Ils ne connaissent pas la lumière. [^16] Pour eux, le matin c’est l’ombre de la mort, ils en éprouvent toutes les terreurs. [^17] Eh quoi! L’impie est d’un poids léger sur la face des eaux,Il n’a sur la terre qu’une part maudite,Il ne prend jamais le chemin des vignes! [^18] Comme la sécheresse et la chaleur absorbent les eaux de la neige,Ainsi le séjour des morts engloutit ceux qui pèchent! [^19] Quoi! Le sein maternel l’oublie,Les vers en font leurs délices,On ne se souvient plus de lui!L’impie est brisé comme un arbre, [^20] Lui qui dépouille la femme stérile et sans enfants,Lui qui ne répand aucun bienfait sur la veuve!… [^21] Non! Dieu par sa force prolonge les jours des violents,Et les voilà debout quand ils désespéraient de la vie; [^22] Il leur donne de la sécurité et de la confiance,Il a les regards sur leurs voies. [^23] Ils se sont élevés; et en un instant ils ne sont plus,Ils tombent, ils meurent comme tous les hommes,Ils sont coupés comme la tête des épis. [^24] S’il n’en est pas ainsi, qui me démentira,Qui réduira mes paroles à néant? [^25] 

[[Job - 23|<--]] Job - 24 [[Job - 25|-->]]

---
# Notes
