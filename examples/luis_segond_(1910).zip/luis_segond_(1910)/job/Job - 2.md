---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 2 - Luis Segond (1910)"
---
[[Job - 1|<--]] Job - 2 [[Job - 3|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 2

Or, les fils de Dieu vinrent un jour se présenter devant l’Éternel, et Satan vint aussi au milieu d’eux se présenter devant l’Éternel. [^1] L’Éternel dit à Satan: D’où viens-tu? Et Satan répondit à l’Éternel: De parcourir la terre et de m’y promener. [^2] L’Éternel dit à Satan: As-tu remarqué mon serviteur Job? Il n’y a personne comme lui sur la terre; c’est un homme intègre et droit, craignant Dieu, et se détournant du mal. Il demeure ferme dans son intégrité, et tu m’excites à le perdre sans motif. [^3] Et Satan répondit à l’Éternel: Peau pour peau! Tout ce que possède un homme, il le donne pour sa vie. [^4] Mais étends ta main, touche à ses os et à sa chair, et je suis sûr qu’il te maudit en face. [^5] L’Éternel dit à Satan: Voici, je te le livre: seulement, épargne sa vie. [^6] Et Satan se retira de devant la face de l’Éternel. Puis il frappa Job d’un ulcère malin, depuis la plante du pied jusqu’au sommet de la tête. [^7] Et Job prit un tesson pour se gratter et s’assit sur la cendre. [^8] Sa femme lui dit: Tu demeures ferme dans ton intégrité! Maudis Dieu, et meurs! [^9] Mais Job lui répondit: Tu parles comme une femme insensée. Quoi! Nous recevons de Dieu le bien, et nous ne recevrions pas aussi le mal!En tout cela Job ne pécha point par ses lèvres. [^10] Trois amis de Job, Éliphaz de Théman, Bildad de Schuach, et Tsophar de Naama, apprirent tous les malheurs qui lui étaient arrivés. Ils se concertèrent et partirent de chez eux pour aller le plaindre et le consoler! [^11] Ayant de loin porté les regards sur lui, ils ne le reconnurent pas, et ils élevèrent la voix et pleurèrent. Ils déchirèrent leurs manteaux, et ils jetèrent de la poussière en l’air au-dessus de leur tête. [^12] Et ils se tinrent assis à terre auprès de lui sept jours et sept nuits, sans lui dire une parole, car ils voyaient combien sa douleur était grande. [^13] 

[[Job - 1|<--]] Job - 2 [[Job - 3|-->]]

---
# Notes
