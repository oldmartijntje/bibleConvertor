---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 14 - Luis Segond (1910)"
---
[[Job - 13|<--]] Job - 14 [[Job - 15|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 14

L’homme né de la femme!#    
        Ps 90:5, 6, 9; 102:12; 103:15; 144:4. Ja 4:14.  Sa vie est courte, sans cesse agitée. [^1] Il naît, il est coupé comme #Ps 103:15. És 40:6. 1 Pi 1:24.une fleur;#    
        Job 8:9. Ps 90:6, 10; 102:12; 144:4.  Il fuit et disparaît comme une ombre. [^2] #    
        Job 7:17, 18; 10:20.  Et c’est sur lui que tu as l’œil ouvert!Et tu me fais aller en justice avec toi! [^3] #    
        Ge 5:3. Ps 51:7. Jn 3:6. Ro 5:12. Ép 2:3.  Comment d’un être souillé sortira-t-il un homme pur?Il n’en peut sortir aucun. [^4] #    
        Job 7:1.  Si ses jours sont fixés, si tu as compté ses mois,Si tu en as marqué le terme qu’il ne saurait franchir, [^5] #    
        Job 7:16, 19; 10:20.  Détourne de lui les regards, et donne-lui du relâche,Pour qu’il ait au moins la joie du #Job 7:1, 2.mercenaire à la fin de sa journée. [^6] Un arbre a de l’espérance:Quand on le coupe, il repousse,Il produit encore des rejetons; [^7] Quand sa racine a vieilli dans la terre,Quand son tronc meurt dans la poussière, [^8] Il reverdit à l’approche de l’eau,Il pousse des branches comme une jeune plante. [^9] Mais l’homme meurt, et il perd sa force;L’homme expire, et où est-il? [^10] Les eaux des lacs s’évanouissent,Les fleuves tarissent et se dessèchent; [^11] Ainsi l’homme se couche et ne se relèvera plus,Il ne se réveillera pas tant que les cieux subsisteront,Il ne sortira pas de son sommeil. [^12] Oh! Si tu voulais me cacher dans le séjour des morts,M’y tenir à couvert jusqu’à ce que ta colère fût passée,Et me fixer un terme auquel tu te souviendras de moi! [^13] Si l’homme une fois mort pouvait revivre,J’aurais de l’espoir tout le temps de mes souffrances,Jusqu’à ce que mon état vînt à changer. [^14] Tu appellerais alors, et je te répondrais,Tu languirais après l’ouvrage de tes mains. [^15] #    
        Job 31:4; 34:21. Ps 56:9; 139:2, 3, 4. Pr 5:21. Jé 32:19.  Mais aujourd’hui tu comptes mes pas,Tu as l’œil sur mes péchés; [^16] Mes transgressions sont scellées en un faisceau,Et tu imagines des iniquités à ma charge. [^17] La montagne s’écroule et périt,Le rocher disparaît de sa place, [^18] La pierre est broyée par les eaux,Et la terre emportée par leur courant;Ainsi tu détruis l’espérance de l’homme. [^19] Tu es sans cesse à l’assaillir, et il s’en va;Tu le défigures, puis tu le renvoies. [^20] Que ses fils soient honorés, il n’en sait rien;Qu’ils soient dans l’abaissement, il l’ignore. [^21] C’est pour lui seul qu’il éprouve de la douleur en son corps,C’est pour lui seul qu’il ressent de la tristesse en son âme. [^22] 

[[Job - 13|<--]] Job - 14 [[Job - 15|-->]]

---
# Notes
