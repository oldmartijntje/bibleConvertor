---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 33 - Luis Segond (1910)"
---
[[Job - 32|<--]] Job - 33 [[Job - 34|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 33

Maintenant donc, Job, écoute mes discours,Prête l’oreille à toutes mes paroles! [^1] Voici, j’ouvre la bouche,Ma langue se remue dans mon palais. [^2] C’est avec droiture de cœur que je vais parler,C’est la vérité pure qu’exprimeront mes lèvres: [^3] L’esprit de Dieu m’a créé,Et le souffle du Tout-Puissant m’anime. [^4] Si tu le peux, réponds-moi,Défends ta cause, tiens-toi prêt! [^5] #    
        Job 9:35; 23:10.  Devant Dieu je suis ton semblable,J’ai été comme toi formé de la boue; [^6] Ainsi mes terreurs ne te troubleront pas,Et mon poids ne saurait t’accabler. [^7] #    
        Job 10:7; 16:17; 23:10, 11; 27:5.  Mais tu as dit à mes oreilles,Et j’ai entendu le son de tes paroles: [^8] Je suis pur, je suis sans péché,Je suis net, il n’y a point en moi d’iniquité. [^9] Et Dieu trouve contre moi des motifs de haine,#    
        Job 13:24; 16:9; 19:11.  Il me traite comme son ennemi; [^10] #    
        Job 13:27.  Il met mes pieds dans les ceps,#    
        Job 14:16.  Il surveille tous mes mouvements. [^11] Je te répondrai qu’en cela tu n’as pas raison,Car Dieu est plus grand que l’homme. [^12] Veux-tu donc disputer avec lui,Parce qu’il ne rend aucun compte de ses actes? [^13] Dieu parle cependant, tantôt d’une manière,Tantôt d’une autre, et l’on n’y prend point garde. [^14] Il parle par des songes, par des visions nocturnes,Quand les hommes sont livrés à un profond sommeil,Quand ils sont endormis sur leur couche. [^15] Alors il leur donne des avertissementsEt met le sceau à ses instructions, [^16] Afin de détourner l’homme du malEt de le préserver de l’orgueil, [^17] Afin de garantir son âme de la fosseEt sa vie des coups du glaive. [^18] Par la douleur aussi l’homme est repris sur sa couche,Quand une lutte continue vient agiter ses os. [^19] #    
        Ps 107:18.  Alors il prend en dégoût le pain,Même les aliments les plus exquis; [^20] Sa chair se consume et disparaît,Ses os qu’on ne voyait pas sont mis à nu; [^21] Son âme s’approche de la fosse,Et sa vie des messagers de la mort. [^22] Mais s’il se trouve pour lui un ange intercesseur,Un d’entre les milleQui annoncent à l’homme la voie qu’il doit suivre, [^23] Dieu a compassion de lui et dit à l’ange:Délivre-le, afin qu’il ne descende pas dans la fosse;J’ai trouvé une rançon! [^24] Et sa chair a plus de fraîcheur qu’au premier âge,Il revient aux jours de sa jeunesse. [^25] Il adresse à Dieu sa prière; #Ps 50:15. És 58:9.et Dieu lui est propice,Lui laisse voir sa face avec joie,Et lui rend son innocence. [^26] Il chante devant les hommes et dit:J’ai péché, j’ai violé la justice,Et je n’ai pas été puni comme je le méritais; [^27] Dieu a délivré mon âme pour qu’elle n’entrât pas dans la fosse,Et ma vie s’épanouit à la lumière! [^28] Voilà tout ce que Dieu fait,Deux fois, trois fois, avec l’homme, [^29] #    
        Ps 56:14.  Pour ramener son âme de la fosse,Pour l’éclairer de la lumière des vivants. [^30] Sois attentif, Job, écoute-moi!Tais-toi, et je parlerai! [^31] Si tu as quelque chose à dire, réponds-moi!Parle, car je voudrais te donner raison. [^32] Si tu n’as rien à dire, écoute-moi!Tais-toi, et je t’enseignerai la sagesse. [^33] 

[[Job - 32|<--]] Job - 33 [[Job - 34|-->]]

---
# Notes
