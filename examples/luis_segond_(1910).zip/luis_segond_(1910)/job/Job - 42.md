---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 42 - Luis Segond (1910)"
---
[[Job - 41|<--]] Job - 42

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 42

Job répondit à l’Éternel et dit: [^1] Je reconnais que tu peux tout,Et que rien ne s’oppose à tes pensées. [^2] #    
        Job 38:2.  Quel est celui qui a la folie d’obscurcir mes desseins?Oui, j’ai parlé, sans les comprendre,#    
        Ps 40:6; 131:1; 139:6.  De merveilles qui me dépassent et que je ne conçois pas. [^3] Écoute-moi, et je parlerai;Je t’interrogerai, et tu m’instruiras. [^4] Mon oreille avait entendu parler de toi;Mais maintenant mon œil t’a vu. [^5] C’est pourquoi je me condamne et je me repensSur la poussière et sur la cendre. [^6] Après que l’Éternel eut adressé ces paroles à Job, il dit à Éliphaz de Théman: Ma colère est enflammée contre toi et contre tes deux amis, parce que vous n’avez pas parlé de moi avec droiture comme l’a fait mon serviteur Job. [^7] Prenez maintenant sept taureaux et sept béliers, allez auprès de mon serviteur Job, et offrez pour vous un holocauste. Job, mon serviteur, priera pour vous, et c’est par égard pour lui seul que je ne vous traiterai pas selon votre folie; car vous n’avez pas parlé de moi avec droiture, comme l’a fait mon serviteur Job. [^8] Éliphaz de Théman, Bildad de Schuach, et Tsophar de Naama allèrent et firent comme l’Éternel leur avait dit: et l’Éternel eut égard à la prière de Job. [^9] L’Éternel rétablit Job dans son premier état, quand Job eut prié pour ses amis; et l’Éternel lui accorda le double de tout ce qu’il avait possédé. [^10] Les frères, les sœurs, et les anciens amis de Job vinrent tous le visiter, et ils mangèrent avec lui dans sa maison. Ils le plaignirent et le consolèrent de tous les malheurs que l’Éternel avait fait venir sur lui, et chacun lui donna un kesita et un anneau d’or. [^11] Pendant ses dernières années, Job reçut de l’Éternel plus de bénédictions qu’il n’en avait reçu dans les premières. Il posséda quatorze mille brebis, six mille chameaux, mille paires de bœufs, et mille ânesses. [^12] Il eut sept fils et trois filles: [^13] il donna à la première le nom de Jemima, à la seconde celui de Ketsia, et à la troisième celui de Kéren-Happuc. [^14] Il n’y avait pas dans tout le pays d’aussi belles femmes que les filles de Job. Leur père leur accorda une part d’héritage parmi leurs frères. [^15] Job vécut après cela cent quarante ans, et il vit ses fils et les fils de ses fils jusqu’à la quatrième génération. [^16] Et Job mourut âgé et rassasié de jours. [^17] 

[[Job - 41|<--]] Job - 42

---
# Notes
