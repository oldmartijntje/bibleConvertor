---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 35 - Luis Segond (1910)"
---
[[Job - 34|<--]] Job - 35 [[Job - 36|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 35

Élihu reprit et dit: [^1] Imagines-tu avoir raison,Penses-tu te justifier devant Dieu, [^2] #    
        Job 34:9.  Quand tu dis: Que me sert-il,Que me revient-il de ne pas pécher? [^3] C’est à toi que je vais répondre,Et à tes amis en même temps. [^4] Considère les cieux, et regarde!Vois les nuées, comme elles sont au-dessus de toi! [^5] Si tu pèches, quel tort lui causes-tu?Et quand tes péchés se multiplient, que lui fais-tu? [^6] #    
        Job 22:2. Ps 16:2. Ro 11:35.  Si tu es juste, que lui donnes-tu?Que reçoit-il de ta main? [^7] Ta méchanceté ne peut nuire qu’à ton semblable,Ta justice n’est utile qu’au fils de l’homme. [^8] On crie contre la multitude des oppresseurs,On se plaint de la violence d’un grand nombre; [^9] Mais nul ne dit: Où est Dieu, mon créateur,Qui inspire des chants d’allégresse pendant la nuit, [^10] Qui nous instruit plus que les bêtes de la terre,Et nous donne l’intelligence plus qu’aux oiseaux du ciel? [^11] On a beau crier alors, #Job 27:9. Pr 1:28; 15:29. És 1:15. Jé 11:11. Jn 9:31.Dieu ne répond pas,A cause de l’orgueil des méchants. [^12] C’est en vain que l’on crie, Dieu n’écoute pas,Le Tout-Puissant n’y a point égard. [^13] Bien que tu dises que tu ne le vois pas,Ta cause est devant lui: attends-le! [^14] #    
        Job 11:6.  Mais, parce que sa colère ne sévit point encore,Ce n’est pas à dire qu’il ait peu souci du crime. [^15] Ainsi Job ouvre vainement la bouche,Il multiplie les paroles sans intelligence. [^16] 

[[Job - 34|<--]] Job - 35 [[Job - 36|-->]]

---
# Notes
