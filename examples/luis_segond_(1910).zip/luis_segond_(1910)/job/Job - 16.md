---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 16 - Luis Segond (1910)"
---
[[Job - 15|<--]] Job - 16 [[Job - 17|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 16

Job prit la parole et dit: [^1] J’ai souvent entendu pareilles choses;#    
        Job 13:4.  Vous êtes tous des consolateurs fâcheux. [^2] Quand finiront ces discours en l’air?Pourquoi cette irritation dans tes réponses? [^3] Moi aussi, je pourrais parler comme vous,Si vous étiez à ma place:Je vous accablerais de paroles,Je secouerais sur vous la tête, [^4] Je vous fortifierais de la bouche,Je remuerais les lèvres pour vous soulager. [^5] Si je parle, mes souffrances ne seront point calmées,Si je me tais, en quoi seront-elles moindres? [^6] Maintenant, hélas! Il m’a épuisé…Tu as ravagé toute ma maison; [^7] Tu m’as saisi, pour témoigner contre moi;Ma maigreur se lève, et m’accuse en face. [^8] #    
        Job 10:16, 17.  Il me déchire et me poursuit dans sa fureur,Il grince des dents contre moi,Il m’attaque #Job 13:24.et me perce de son regard. [^9] Ils ouvrent la bouche pour me dévorer,Ils m’insultent et me frappent les joues,Ils s’acharnent tous après moi. [^10] Dieu me livre à la merci des impies,Il me précipite entre les mains des méchants. [^11] J’étais tranquille, et il m’a secoué,Il m’a saisi par la nuque et m’a brisé,#    
        Job 7:20. La 3:12.  Il a tiré sur moi comme à un but. [^12] Ses traits m’environnent de toutes parts;Il me perce les reins sans pitié,Il répand ma bile sur la terre. [^13] Il me fait brèche sur brèche,Il fond sur moi comme un guerrier. [^14] J’ai cousu un sac sur ma peau;#    
        Job 30:19.  J’ai roulé ma tête dans la poussière. [^15] Les pleurs ont altéré mon visage;L’ombre de la mort est sur mes paupières. [^16] Je n’ai pourtant commis aucune violence,Et ma prière fut toujours pure. [^17] O terre, ne couvre point mon sang,Et que mes cris prennent librement leur essor! [^18] Déjà maintenant, mon témoin est dans le ciel,Mon témoin est dans les lieux élevés. [^19] Mes amis se jouent de moi;C’est Dieu que j’implore avec larmes. [^20] #    
        Job 31:35. Ec 6:10. És 45:9. Ro 9:20.  Puisse-t-il donner à l’homme raison contre Dieu,Et au fils de l’homme contre ses amis! [^21] Car le nombre de mes années touche à son terme,Et je m’en irai par un sentier d’où je ne reviendrai pas. [^22] 

[[Job - 15|<--]] Job - 16 [[Job - 17|-->]]

---
# Notes
