---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 9 - Luis Segond (1910)"
---
[[Job - 8|<--]] Job - 9 [[Job - 10|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 9

Job prit la parole et dit: [^1] Je sais bien qu’il en est ainsi;Comment #Ps 143:2.l’homme serait-il juste devant Dieu? [^2] S’il voulait contester avec lui,Sur mille choses il ne pourrait répondre à une seule. [^3] A lui la sagesse et la toute-puissance:Qui lui résisterait impunément? [^4] Il transporte soudain les montagnes,Il les renverse dans sa colère. [^5] Il secoue la terre sur sa base,Et ses colonnes sont ébranlées. [^6] Il commande au soleil, et le soleil ne paraît pas;Il met un sceau sur les étoiles. [^7] Seul, il étend #Ge 1:6.les cieux,Il marche sur les hauteurs de la mer. [^8] Il a créé la Grande Ourse, l’Orion et les Pléiades,Et les étoiles des régions australes. [^9] #    
        Job 5:9. Ps 72:18; 77:15; 86:10. Ro 11:33.  Il fait des choses grandes et insondables,Des merveilles sans nombre. [^10] Voici, il passe près de moi, et je ne le vois pas,Il s’en va, et je ne l’aperçois pas. [^11] S’il enlève, qui s’y opposera?Qui lui dira: Que fais-tu? [^12] Dieu ne retire point sa colère;Sous lui s’inclinent les appuis de l’orgueil. [^13] Et moi, comment lui répondre?Quelles paroles choisir? [^14] Quand je serais juste, je ne répondrais pas;Je ne puis qu’implorer mon juge. [^15] Et quand il m’exaucerait, si je l’invoque,Je ne croirais pas qu’il eût écouté ma voix, [^16] Lui qui m’assaille comme par une tempête,Qui multiplie sans raison mes blessures, [^17] Qui ne me laisse pas respirer,Qui me rassasie d’amertume. [^18] Recourir à la force?Il est tout-puissant.A la justice? Qui me fera comparaître? [^19] Suis-je juste, ma bouche me condamnera;Suis-je innocent, il me déclarera coupable. [^20] Innocent! Je le suis; mais je ne tiens pas à la vie,Je méprise mon existence. [^21] Qu’importe après tout? Car, j’ose le dire,#    
        Ec 9:2, 3. Mal 3:14.  Il détruit l’innocent comme le coupable. [^22] Si du moins le fléau donnait soudain la mort!…Mais il se rit des épreuves de l’innocent. [^23] La terre est livrée aux mains de l’impie;Il voile la face des juges.Si ce n’est pas lui, qui est-ce donc? [^24] #    
        Job 7:6, 7.  Mes jours sont plus rapides qu’un courrier;Ils fuient sans avoir vu le bonheur; [^25] Ils passent comme les navires de jonc,Comme l’aigle qui fond sur sa proie. [^26] Si je dis: Je veux oublier mes souffrances,Laisser ma tristesse, reprendre courage, [^27] Je suis effrayé de toutes mes douleurs.Je sais que tu ne me tiendras pas pour innocent. [^28] Je serai jugé coupable;Pourquoi me fatiguer en vain? [^29] #    
        Jé 2:22.  Quand je me laverais dans la neige,Quand je purifierais mes mains avec du savon, [^30] Tu me plongerais dans la fange,Et mes vêtements m’auraient en horreur. [^31] #    
        Ec 6:10. Jé 49:19.  Il n’est pas un homme comme moi, pour que je lui réponde,Pour que nous allions ensemble en justice. [^32] Il n’y a pas entre nous d’arbitre,Qui pose sa main sur nous deux. [^33] #    
        Job 13:20; 33:7.  Qu’il retire sa verge de dessus moi,Que ses terreurs ne me troublent plus; [^34] Alors je parlerai et je ne le craindrai pas.Autrement, je ne suis point à moi-même. [^35] 

[[Job - 8|<--]] Job - 9 [[Job - 10|-->]]

---
# Notes
