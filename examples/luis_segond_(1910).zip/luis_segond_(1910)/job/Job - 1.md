---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 1 - Luis Segond (1910)"
---
Job - 1 [[Job - 2|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 1

Il y avait dans le pays d’Uts un homme qui s’appelait Job. Et cet homme était #Job 2:3.intègre et droit; il craignait Dieu, et se détournait du mal. [^1] Il lui naquit sept fils et trois filles. [^2] Il possédait sept mille brebis, trois mille chameaux, cinq cents paires de bœufs, cinq cents ânesses, et un très grand nombre de serviteurs. Et cet homme était le plus considérable de tous les fils de l’Orient. [^3] Ses fils allaient les uns chez les autres et donnaient tour à tour un festin, et ils invitaient leurs trois sœurs à manger et à boire avec eux. [^4] Et quand les jours de festin étaient passés, Job appelait et sanctifiait ses fils, puis il se levait de bon matin et offrait pour chacun d’eux un holocauste; car Job disait: Peut-être mes fils ont-ils péché et ont-ils offensé Dieu dans leur cœur. C’est ainsi que Job avait coutume d’agir. [^5] Or, les fils de Dieu vinrent un jour se présenter devant l’Éternel, et Satan vint aussi au milieu d’eux. [^6] L’Éternel dit à Satan: D’où viens-tu? Et Satan répondit à l’Éternel: De parcourir #1 Pi 5:8.la terre et de m’y promener. [^7] L’Éternel dit à Satan: As-tu remarqué mon serviteur Job? Il n’y a personne comme lui sur la terre; c’est un homme intègre et droit, craignant Dieu, et se détournant du mal. [^8] Et Satan répondit à l’Éternel: Est-ce d’une manière désintéressée que Job craint Dieu? [^9] Ne l’as-tu pas protégé, lui, sa maison, et tout ce qui est à lui? Tu as béni l’œuvre de ses mains, et ses troupeaux couvrent le pays. [^10] Mais étends ta main, touche à tout ce qui lui appartient, et je suis sûr qu’il te maudit en face. [^11] L’Éternel dit à Satan: Voici, tout ce qui lui appartient, je te le livre; seulement, ne porte pas la main sur lui. Et Satan se retira de devant la face de l’Éternel. [^12] Un jour que les fils et les filles de Job mangeaient et buvaient du vin dans la maison de leur frère aîné, [^13] il arriva auprès de Job un messager qui dit: Les bœufs labouraient et les ânesses paissaient à côté d’eux; [^14] des Sabéens se sont jetés dessus, les ont enlevés, et ont passé les serviteurs au fil de l’épée. Et je me suis échappé moi seul, pour t’en apporter la nouvelle. [^15] Il parlait encore, lorsqu’un autre vint et dit: Le feu de Dieu est tombé du ciel, a embrasé les brebis et les serviteurs, et les a consumés. Et je me suis échappé moi seul, pour t’en apporter la nouvelle. [^16] Il parlait encore, lorsqu’un autre vint et dit: Des Chaldéens, formés en trois bandes, se sont jetés sur les chameaux, les ont enlevés, et ont passé les serviteurs au fil de l’épée. Et je me suis échappé moi seul, pour t’en apporter la nouvelle. [^17] Il parlait encore, lorsqu’un autre vint et dit: Tes fils et tes filles mangeaient et buvaient du vin dans la maison de leur frère aîné; [^18] et voici, un grand vent est venu de l’autre côté du désert, et a frappé contre les quatre coins de la maison; elle s’est écroulée sur les jeunes gens, et ils sont morts. Et je me suis échappé moi seul, pour t’en apporter la nouvelle. [^19] Alors Job se leva, déchira son manteau, et se rasa la tête; puis, se jetant par terre, il se prosterna, [^20] et dit: #Ec 5:14. 1 Ti 6:7.Je suis sorti nu du sein de ma mère, et nu je retournerai dans le sein de la terre. L’Éternel a donné, et l’Éternel a ôté; que le nom de l’Éternel soit béni! [^21] En tout cela, Job ne pécha point et n’attribua rien d’injuste à Dieu. [^22] 

Job - 1 [[Job - 2|-->]]

---
# Notes
