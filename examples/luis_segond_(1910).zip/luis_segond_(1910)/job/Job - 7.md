---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 7 - Luis Segond (1910)"
---
[[Job - 6|<--]] Job - 7 [[Job - 8|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 7

Le sort de l’homme sur la terre est celui d’un soldat,Et ses jours sont ceux d’un mercenaire. [^1] Comme l’esclave soupire après l’ombre,Comme l’ouvrier attend son salaire, [^2] Ainsi j’ai pour partage des mois de douleur,J’ai pour mon lot des nuits de souffrance. [^3] Je me couche, et je dis: Quand me lèverai-je? Quand finira la nuit?Et je suis rassasié d’agitations jusqu’au point du jour. [^4] Mon corps se couvre de vers et d’une croûte terreuse,Ma peau se crevasse et se dissout. [^5] Mes jours sont plus rapides que la navette du tisserand,Ils s’évanouissent: plus d’espérance! [^6] Souviens-toi que ma vie est #Job 8:9; 14:1, 2, 3; 16:22. Ps 90:5, 6, 9; 102:12; 103:15; 144:4; És 40:6. Ja 4:14. 1 Pi 1:24.un souffle!Mes yeux ne reverront pas le bonheur. [^7] L’œil qui me regarde ne me regardera plus;Ton œil me cherchera, et je ne serai plus. [^8] Comme la nuée se dissipe et s’en va,Celui qui descend au séjour des morts ne remontera pas; [^9] Il ne reviendra plus dans sa maison,Et le lieu qu’il habitait ne le connaîtra plus. [^10] C’est pourquoi je ne retiendrai point ma bouche,Je parlerai dans l’angoisse de mon cœur,Je me plaindrai dans l’amertume de mon âme. [^11] Suis-je une mer, ou un monstre marin,Pour que tu établisses des gardes autour de moi? [^12] Quand je dis: Mon lit me soulagera,Ma couche calmera mes douleurs, [^13] C’est alors que tu m’effraies par des songes,Que tu m’épouvantes par des visions. [^14] Ah! Je voudrais être étranglé!Je voudrais la mort plutôt que ces os! [^15] Je les méprise!… je ne vivrai pas toujours…Laisse-moi, #Ps 62:10; 144:4.car ma vie n’est qu’un souffle. [^16] #    
        Ps 8:5; 144:3. Hé 2:6.  Qu’est-ce que l’homme, pour que tu en fasses tant de cas,Pour que tu daignes prendre garde à lui, [^17] Pour que tu le visites tous les matins,Pour que tu l’éprouves à tous les instants? [^18] Quand cesseras-tu d’avoir le regard sur moi?Quand me laisseras-tu le temps d’avaler ma salive? [^19] Si j’ai péché, qu’ai-je pu te faire, gardien des hommes?Pourquoi me mettre en butte à tes traits?Pourquoi me rendre à charge à moi-même? [^20] Que ne pardonnes-tu mon péché,Et que n’oublies-tu mon iniquité?Car je vais me coucher dans la poussière;Tu me chercheras, et je ne serai plus. [^21] 

[[Job - 6|<--]] Job - 7 [[Job - 8|-->]]

---
# Notes
