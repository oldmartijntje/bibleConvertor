---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 8 - Luis Segond (1910)"
---
[[Job - 7|<--]] Job - 8 [[Job - 9|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 8

Bildad de Schuach prit la parole et dit: [^1] Jusqu’à quand veux-tu discourir de la sorte,Et les paroles de ta bouche seront-elles un vent impétueux? [^2] #    
        De 32:4. 2 Ch 19:7. Da 9:14.  Dieu renverserait-il le droit?Le Tout-Puissant renverserait-il la justice? [^3] Si tes fils ont péché contre lui,Il les a livrés à leur péché. [^4] #    
        Job 22:23.  Mais toi, si tu as recours à Dieu,Si tu implores le Tout-Puissant; [^5] Si tu es juste et droit,Certainement alors il veillera sur toi,Et rendra le bonheur à ton innocente demeure; [^6] Ton ancienne prospérité semblera peu de chose,Celle qui t’est réservée sera bien plus grande. [^7] #    
        De 4:32.  Interroge ceux des générations passées,Sois attentif à l’expérience de leurs pères. [^8] #    
        Ge 47:9. 1 Ch 29:15. Job 7:5, 6, 7. Ps 39:13; 144:4.  Car nous sommes d’hier, et nous ne savons rien,Nos jours sur la terre ne sont qu’une #Ps 102:12; 144:4.ombre. [^9] Ils t’instruiront, ils te parleront,Ils tireront de leur cœur ces sentences: [^10] Le jonc croît-il sans marais?Le roseau croît-il sans humidité? [^11] #    
        Ps 129:6. Jé 17:6.  Encore vert et sans qu’on le coupe,Il sèche plus vite que toutes les herbes. [^12] Ainsi arrive-t-il à tous ceux qui oublient Dieu,#    
        Job 11:20; 18:14. Ps 112:10. Pr 10:28.  Et l’espérance de l’impie périra. [^13] Son assurance est brisée,Son soutien est une toile d’araignée. [^14] Il s’appuie sur sa maison, et elle n’est pas ferme;Il s’y cramponne, et elle ne résiste pas. [^15] Dans toute sa vigueur, en plein soleil,Il étend ses rameaux sur son jardin, [^16] Il entrelace ses racines parmi les pierres,Il pénètre jusque dans les murailles; [^17] L’arrache-t-on du lieu qu’il occupe,Ce lieu le renie: Je ne t’ai point connu! [^18] Telles sont les délices que ses voies lui procurent.Puis sur le même sol d’autres s’élèvent après lui. [^19] Non, Dieu ne rejette point l’homme intègre,Et il ne protège point les méchants. [^20] Il remplira ta bouche de cris de joie,Et tes lèvres de chants d’allégresse. [^21] Tes ennemis seront couverts de honte;La tente des méchants disparaîtra. [^22] 

[[Job - 7|<--]] Job - 8 [[Job - 9|-->]]

---
# Notes
