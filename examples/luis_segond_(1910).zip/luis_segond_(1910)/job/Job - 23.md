---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 23 - Luis Segond (1910)"
---
[[Job - 22|<--]] Job - 23 [[Job - 24|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 23

Job prit la parole et dit: [^1] Maintenant encore ma plainte est une révolte,Mais la souffrance étouffe mes soupirs. [^2] Oh! Si je savais où le trouver,Si je pouvais arriver jusqu’à son trône, [^3] Je plaiderais ma cause devant lui,Je remplirais ma bouche d’arguments, [^4] Je connaîtrais ce qu’il peut avoir à répondre,Je verrais ce qu’il peut avoir à me dire. [^5] Emploierait-il toute sa force à me combattre?Ne daignerait-il pas au moins m’écouter? [^6] Ce serait un homme droit qui plaiderait avec lui,Et je serais pour toujours absous par mon juge. [^7] Mais, si je vais à l’orient, il n’y est pas;Si je vais à l’occident, je ne le trouve pas; [^8] Est-il occupé au nord, je ne puis le voir;Se cache-t-il au midi, je ne puis le découvrir. [^9] Il sait néanmoins quelle voie j’ai suivie;Et, s’il m’éprouvait, je sortirais pur comme l’or. [^10] Mon pied s’est attaché à ses pas;#    Job 31:4, etc.  J’ai gardé sa voie, et je ne m’en suis point détourné. [^11] Je n’ai pas abandonné les commandements de ses lèvres;J’ai fait plier ma volonté aux paroles de sa bouche. [^12] Mais sa résolution est arrêtée; qui s’y opposera?#    
        Ps 115:3.  Ce que son âme désire, il l’exécute. [^13] Il accomplira donc ses desseins à mon égard,Et il en concevra bien d’autres encore. [^14] Voilà pourquoi sa présence m’épouvante;Quand j’y pense, j’ai peur de lui. [^15] Dieu a brisé mon courage,Le Tout-Puissant m’a rempli d’effroi. [^16] Car ce ne sont pas les ténèbres qui m’anéantissent,Ce n’est pas l’obscurité dont je suis couvert. [^17] 

[[Job - 22|<--]] Job - 23 [[Job - 24|-->]]

---
# Notes
