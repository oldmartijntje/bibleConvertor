---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 34 - Luis Segond (1910)"
---
[[Job - 33|<--]] Job - 34 [[Job - 35|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 34

Élihu reprit et dit: [^1] Sages, écoutez mes discours!Vous qui êtes intelligents, prêtez-moi l’oreille! [^2] #    
        Job 12:11.  Car l’oreille discerne les paroles,Comme le palais savoure les aliments. [^3] Choisissons ce qui est juste,Voyons entre nous ce qui est bon. [^4] Job dit: Je suis innocent,#    
        Job 27:2.  Et Dieu me refuse justice; [^5] J’ai raison, et je passe pour menteur;#    
        Job 6:4.  Ma plaie est douloureuse, et je suis sans péché. [^6] Y a-t-il un homme semblable à Job,Buvant la raillerie comme l’eau, [^7] Marchant en société de ceux qui font le mal,Cheminant de pair avec les impies? [^8] Car il a dit: Il est inutile à l’hommeDe mettre son plaisir en Dieu. [^9] Écoutez-moi donc, hommes de sens!#    
        De 32:4. 2 Ch 19:7. Job 8:3; 36:23. Ps 92:16. Ro 9:14.  Loin de Dieu l’injustice,Loin du Tout-Puissant l’iniquité! [^10] #    
        Ps 62:13. Pr 24:12. Jé 17:10; 32:19. Éz 7:27; 33:20. Mt 16:27. Ro 2:6. 1 Co 3:8. 2 Co 5:10. Ép 6:8. Col 3:25. 1 Pi 1:17. Ap 22:12.  Il rend à l’homme selon ses œuvres,Il rétribue chacun selon ses voies. [^11] Non certes, Dieu ne commet pas l’iniquité;Le Tout-Puissant ne viole pas la justice. [^12] Qui l’a chargé de gouverner la terre?Qui a confié l’univers à ses soins? [^13] #    
        Ps 104:29. Ec 12:7.  S’il ne pensait qu’à lui-même,S’il retirait à lui son esprit et son souffle, [^14] Toute chair périrait soudain,Et l’homme #Ge 3:19. Ec 12:7.rentrerait dans la poussière. [^15] Si tu as de l’intelligence, écoute ceci,Prête l’oreille au son de mes paroles! [^16] #    
        Ge 18:25. Job 8:3; 21:22. Ro 3:5.  Un ennemi de la justice régnerait-il?Et condamneras-tu le juste, le puissant, [^17] Qui proclame la méchanceté des roisEt l’iniquité des princes, [^18] Qui n’a point égard à l’apparence des grandsEt ne #De 10:17. 2 Ch 19:7. Job 37:24. Ac 10:34. Ro 2:11. Ga 2:6. Ép 6:9. Col 3:25. 1 Pi 1:17.distingue pas le riche du pauvre,Parce que tous sont l’ouvrage de ses mains? [^19] En un instant, ils perdent la vie;Au milieu de la nuit, un peuple chancelle et périt;Le puissant disparaît, sans la main d’aucun homme. [^20] #    
        2 Ch 16:9. Job 31:4. Ps 34:16. Pr 5:21; 15:3. Jé 16:17; 32:19.  Car Dieu voit la conduite de tous,Il a les regards sur les pas de chacun. [^21] #    
        Ps 139:12. Am 9:2, 3. Hé 4:13.  Il n’y a ni ténèbres ni ombre de la mort,Où puissent se cacher ceux qui commettent l’iniquité. [^22] Dieu n’a pas besoin d’observer longtemps,Pour qu’un homme entre en jugement avec lui; [^23] Il brise les grands sans information,Et il met d’autres à leur place; [^24] Car il connaît leurs œuvres.Il les renverse de nuit, et ils sont écrasés; [^25] Il les frappe comme des impies,A la face de tous les regards. [^26] En se détournant de lui,#    
        Ps 28:5. És 5:12.  En abandonnant toutes ses voies, [^27] Ils ont fait monter à Dieu le cri du pauvre,Ils l’ont rendu attentif aux cris des malheureux. [^28] S’il donne le repos, qui répandra le trouble?S’il cache sa face, qui pourra le voir?Il traite à l’égal soit une nation, soit un homme, [^29] Afin que l’impie ne domine plus,Et qu’il ne soit plus un piège pour le peuple. [^30] Car a-t-il jamais dit à Dieu:J’ai été châtié, je ne pécherai plus; [^31] Montre-moi ce que je ne vois pas;Si j’ai commis des injustices, je n’en commettrai plus? [^32] Est-ce d’après toi que Dieu rendra la justice?C’est toi qui rejettes, qui choisis, mais non pas moi;Ce que tu sais, dis-le donc! [^33] Les hommes de sens seront de mon avis,Le sage qui m’écoute pensera comme moi. [^34] Job parle sans intelligence,Et ses discours manquent de raison. [^35] Qu’il continue donc à être éprouvé,Puisqu’il répond comme font les méchants!Car il ajoute à ses fautes de nouveaux péchés;Il bat des mains au milieu de nous,Il multiplie ses paroles contre Dieu. [^36] 

[[Job - 33|<--]] Job - 34 [[Job - 35|-->]]

---
# Notes
