---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 20 - Luis Segond (1910)"
---
[[Job - 19|<--]] Job - 20 [[Job - 21|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 20

Tsophar de Naama prit la parole et dit: [^1] Mes pensées me forcent à répondre,Et mon agitation ne peut se contenir. [^2] J’ai entendu des reproches qui m’outragent;Le souffle de mon intelligence donnera la réplique. [^3] Ne sais-tu pas que, de tout temps,Depuis que l’homme a été placé sur la terre, [^4] #    
        Ps 37:35, 36.  Le triomphe des méchants a été court,Et la joie de l’impie momentanée? [^5] Quand il s’élèverait jusqu’aux cieux,Et que sa tête toucherait aux nues, [^6] Il périra pour toujours comme son ordure,Et ceux qui le voyaient diront: Où est-il? [^7] Il s’envolera comme un songe, et on ne le trouvera plus;Il disparaîtra comme une vision nocturne; [^8] L’œil qui le regardait ne le regardera plus,Le lieu qu’il habitait ne l’apercevra plus. [^9] Ses fils seront assaillis par les pauvres,Et ses mains restitueront ce qu’il a pris par violence. [^10] La vigueur de la jeunesse, qui remplissait ses membres,Aura sa couche avec lui dans la poussière. [^11] Le mal était doux à sa bouche,Il le cachait sous sa langue, [^12] Il le savourait sans l’abandonner,Il le retenait au milieu de son palais; [^13] Mais sa nourriture se transformera dans ses entrailles,Elle deviendra dans son corps un venin d’aspic. [^14] Il a englouti des richesses, il les vomira;Dieu les chassera de son ventre. [^15] Il a sucé du venin d’aspic,La langue de la vipère le tuera. [^16] Il ne reposera plus ses regards sur les ruisseaux,Sur les torrents, sur les fleuves de miel et de lait. [^17] Il rendra ce qu’il a gagné, et n’en profitera plus;Il restituera tout ce qu’il a pris, et n’en jouira plus. [^18] Car il a opprimé, délaissé les pauvres,#    
        Ec 5:12.  Il a ruiné des maisons et ne les a pas rétablies. [^19] Son avidité n’a point connu de bornes;Mais il ne sauvera pas ce qu’il avait de plus cher. [^20] Rien n’échappait à sa voracité;Mais son bien-être ne durera pas. [^21] Au milieu de l’abondance il sera dans la détresse;La main de tous les misérables se lèvera sur lui. [^22] Et voici, pour lui remplir le ventre,Dieu enverra sur lui le feu de sa colère,Et le rassasiera par une pluie de traits. [^23] S’il échappe aux armes de fer,L’arc d’airain le transpercera. [^24] Il arrache de son corps le trait,Qui étincelle au sortir de ses entrailles,Et il est en proie aux terreurs de la mort. [^25] Toutes les calamités sont réservées à ses trésors;Il sera consumé par un feu que n’allumera point l’homme,Et ce qui restera dans sa tente en deviendra la pâture. [^26] Les cieux dévoileront son iniquité,Et la terre s’élèvera contre lui. [^27] Les revenus de sa maison seront emportés,Ils disparaîtront au jour de la colère de Dieu. [^28] Telle est la part que Dieu réserve au méchant,Tel est l’héritage que Dieu lui destine. [^29] 

[[Job - 19|<--]] Job - 20 [[Job - 21|-->]]

---
# Notes
