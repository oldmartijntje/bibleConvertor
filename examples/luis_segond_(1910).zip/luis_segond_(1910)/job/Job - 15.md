---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 15 - Luis Segond (1910)"
---
[[Job - 14|<--]] Job - 15 [[Job - 16|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 15

Éliphaz de Théman prit la parole et dit: [^1] Le sage répond-il par un vain savoir?Se gonfle-t-il la poitrine du vent d’orient? [^2] Est-ce par d’inutiles propos qu’il se défend?Est-ce par des discours qui ne servent à rien? [^3] Toi, tu détruis même la crainte de Dieu,Tu anéantis tout mouvement de piété devant Dieu. [^4] Ton iniquité dirige ta bouche,Et tu prends le langage des hommes rusés. [^5] Ce n’est pas moi, c’est ta bouche qui te condamne.Ce sont tes lèvres qui déposent contre toi. [^6] Es-tu né le premier des hommes?As-tu été enfanté avant les collines? [^7] #    
        Ro 11:34.  As-tu reçu les confidences de Dieu?As-tu dérobé la sagesse à ton profit? [^8] Que sais-tu que nous ne sachions pas?Quelle connaissance as-tu que nous n’ayons pas? [^9] #    
        Job 32:7.  Il y a parmi nous des cheveux blancs, des vieillards,Plus riches de jours que ton père. [^10] Tiens-tu pour peu de chose les consolations de Dieu,Et les paroles qui doucement se font entendre à toi?… [^11] Où ton cœur t’entraîne-t-il,Et que signifie ce roulement de tes yeux? [^12] Quoi! C’est contre Dieu que tu tournes ta colèreEt que ta bouche exhale de pareils discours! [^13] #    
        1 R 8:46. 2 Ch 6:36. Job 14:4. Ps 14:3. Pr 20:9. Ec 7:20. 1 Jn 1:8, 10.  Qu’est-ce que l’homme, pour qu’il soit pur?Celui qui est né de la femme peut-il être juste? [^14] #    
        Job 4:18.  Si Dieu n’a pas confiance en ses saints,#    
        Job 4:18; 25:5.  Si les cieux ne sont pas purs devant lui, [^15] Combien moins l’être abominable et pervers,L’homme qui boit l’iniquité comme l’eau! [^16] Je vais te parler, écoute-moi!Je raconterai ce que j’ai vu, [^17] Ce que les sages ont fait connaître,Ce qu’ils ont révélé, l’ayant appris de leurs pères. [^18] A eux seuls appartenait le pays,Et parmi eux nul étranger n’était encore venu. [^19] Le méchant passe dans l’angoisse tous les jours de sa vie,Toutes les années qui sont le partage de l’impie. [^20] La voix de la terreur retentit à ses oreilles;#    
        1 Th 5:3.  Au sein de la paix, le dévastateur va fondre sur lui; [^21] Il n’espère pas échapper aux ténèbres,Il voit l’épée qui le menace; [^22] Il court çà et là pour chercher du pain,Il sait #Job 18:12. Ps 109:10.que le jour des ténèbres l’attend. [^23] La détresse et l’angoisse l’épouvantent,Elles l’assaillent comme un roi prêt à combattre; [^24] Car il a levé la main contre Dieu,Il a bravé le Tout-Puissant, [^25] Il a eu l’audace de courir à luiSous le dos épais de ses boucliers. [^26] Il avait le visage couvert de graisse,Les flancs chargés d’embonpoint; [^27] Et il habite des villes détruites,Des maisons abandonnées,Sur le point de tomber en ruines. [^28] Il ne s’enrichira plus, sa fortune ne se relèvera pas,Sa prospérité ne s’étendra plus sur la terre. [^29] Il ne pourra se dérober aux ténèbres,La flamme consumera ses rejetons,#    
        Job 4:9.  Et Dieu le fera périr par le souffle de sa bouche. [^30] S’il a confiance dans le mal, il se trompe,Car le mal sera sa récompense. [^31] #    
        Job 22:16. Ps 55:24.  Elle arrivera avant le terme de ses jours,Et son rameau ne verdira plus. [^32] Il sera comme une vigne dépouillée de ses fruits encore verts,Comme un olivier dont on a fait tomber les fleurs. [^33] La maison de l’impie deviendra stérile,Et le feu dévorera la tente de l’homme corrompu. [^34] #    
        Ps 7:15. És 59:4. Os 10:13.  Il conçoit le mal et il enfante le mal,Il mûrit dans son sein des fruits qui le trompent. [^35] 

[[Job - 14|<--]] Job - 15 [[Job - 16|-->]]

---
# Notes
