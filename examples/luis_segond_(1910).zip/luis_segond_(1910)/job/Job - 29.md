---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 29 - Luis Segond (1910)"
---
[[Job - 28|<--]] Job - 29 [[Job - 30|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 29

Job prit de nouveau la parole sous forme sentencieuse et dit: [^1] Oh! Que ne puis-je être comme aux mois du passé,Comme aux jours où Dieu me gardait, [^2] Quand sa lampe brillait sur ma tête,Et que sa lumière me guidait dans les ténèbres! [^3] Que ne suis-je comme aux jours de ma vigueur,Où Dieu veillait en ami sur ma tente, [^4] Quand le Tout-Puissant était encore avec moi,Et que mes enfants m’entouraient; [^5] Quand mes pieds se baignaient dans la crèmeEt que le rocher répandait près de moi des ruisseaux d’huile! [^6] Si je sortais pour aller à la porte de la ville,Et si je me faisais préparer un siège dans la place, [^7] Les jeunes gens se retiraient à mon approche,Les vieillards se levaient et se tenaient debout. [^8] Les princes arrêtaient leurs discours,Et mettaient la main sur leur bouche; [^9] La voix des chefs se taisait,Et leur langue s’attachait à leur palais. [^10] L’oreille qui m’entendait me disait heureux,L’œil qui me voyait me rendait témoignage; [^11] #    
        Ps 72:12. Pr 21:13.  Car je sauvais le pauvre qui implorait du secours,Et l’orphelin qui manquait d’appui. [^12] La bénédiction du malheureux venait sur moi;Je remplissais de joie le cœur de la veuve. [^13] #    
        És 59:17. Ép 6:14, etc. 1 Th 5:8.  Je me revêtais de la justice et je lui servais de vêtement,J’avais ma droiture pour manteau et pour turban. [^14] J’étais l’œil de l’aveugleEt le pied du boiteux. [^15] J’étais le père des misérables,J’examinais la cause de l’inconnu; [^16] Je brisais la mâchoire de l’injuste,Et j’arrachais de ses dents la proie. [^17] Alors je disais: Je mourrai dans mon nid,Mes jours seront abondants comme le sable; [^18] L’eau pénétrera dans mes racines,La rosée passera la nuit sur mes branches; [^19] Ma gloire reverdira sans cesse,Et mon arc rajeunira dans ma main. [^20] On m’écoutait et l’on restait dans l’attente,On gardait le silence devant mes conseils. [^21] Après mes discours, nul ne répliquait,Et ma parole était pour tous une bienfaisante rosée; [^22] Ils comptaient sur moi comme sur la pluie,Ils ouvraient la bouche comme pour une pluie du printemps. [^23] Je leur souriais quand ils perdaient courage,Et l’on ne pouvait chasser la sérénité de mon front. [^24] J’aimais à aller vers eux, et je m’asseyais à leur tête;J’étais comme un roi au milieu d’une troupe,Comme un consolateur auprès des affligés. [^25] 

[[Job - 28|<--]] Job - 29 [[Job - 30|-->]]

---
# Notes
