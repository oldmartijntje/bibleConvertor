---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 19 - Luis Segond (1910)"
---
[[Job - 18|<--]] Job - 19 [[Job - 20|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 19

Job prit la parole et dit: [^1] Jusques à quand affligerez-vous mon âme,Et m’écraserez-vous de vos discours? [^2] Voilà dix fois que vous m’outragez;N’avez-vous pas honte de m’étourdir ainsi? [^3] Si réellement j’ai péché,Seul j’en suis responsable. [^4] Pensez-vous me traiter avec hauteur?Pensez-vous démontrer que je suis coupable? [^5] Sachez alors que c’est Dieu qui me poursuit,Et qui m’enveloppe de son filet. [^6] Voici, je crie à la violence, et nul ne répond;J’implore justice, et point de justice! [^7] Il m’a fermé toute issue, et je ne puis passer;Il a répandu des ténèbres sur mes sentiers. [^8] Il m’a dépouillé de ma gloire,Il a enlevé la couronne de ma tête. [^9] Il m’a brisé de toutes parts, et je m’en vais;Il a arraché mon espérance comme un arbre. [^10] Il s’est enflammé de colère contre moi,#    
        Job 13:24; 16:9; 33:10. La 2:5.  Il m’a traité comme l’un de ses ennemis. [^11] Ses troupes se sont de concert mises en marche,Elles se sont frayées leur chemin jusqu’à moi,Elles ont campé autour de ma tente. [^12] #    
        Ps 31:12; 38:12; 69:9; 88:9.  Il a éloigné de moi mes frères,Et mes amis se sont détournés de moi; [^13] Je suis abandonné de mes proches,Je suis oublié de mes intimes. [^14] Je suis un étranger pour mes serviteurs et mes servantes,Je ne suis plus à leurs yeux qu’un inconnu. [^15] J’appelle mon serviteur, et il ne répond pas;Je le supplie de ma bouche, et c’est en vain. [^16] Mon humeur est à charge à ma femme,Et ma plainte aux fils de mes entrailles. [^17] #    
        Job 30:1.  Je suis méprisé même par des enfants;Si je me lève, je reçois leurs insultes. [^18] #    
        Ps 41:10; 55:14, 15.  Ceux que j’avais pour confidents m’ont en horreur,Ceux que j’aimais se sont tournés contre moi. [^19] #    
        Job 30:30. Ps 102:6. La 4:8.  Mes os sont attachés à ma peau et à ma chair;Il ne me reste que la peau des dents. [^20] Ayez pitié, ayez pitié de moi, vous, mes amis!Car la main de Dieu m’a frappé. [^21] Pourquoi me poursuivre comme Dieu me poursuit?Pourquoi vous montrer insatiables de ma chair? [^22] Oh! Je voudrais que mes paroles fussent écrites,Qu’elles fussent écrites dans un livre; [^23] Je voudrais qu’avec un burin de fer et avec du plombElles fussent pour toujours gravées dans le roc… [^24] Mais je sais que mon rédempteur est vivant,Et qu’il se lèvera le dernier sur la terre. [^25] Quand ma peau sera détruite, il se lèvera;Quand je n’aurai plus de chair, je verrai Dieu. [^26] Je le verrai, et il me sera favorable;Mes yeux le verront, et non ceux d’un autre;Mon âme languit d’attente au-dedans de moi. [^27] Vous direz alors: Pourquoi le poursuivions-nous?Car la justice de ma cause sera reconnue. [^28] Craignez pour vous le glaive:Les châtiments par le glaive sont terribles!Et sachez qu’il y a un jugement. [^29] 

[[Job - 18|<--]] Job - 19 [[Job - 20|-->]]

---
# Notes
