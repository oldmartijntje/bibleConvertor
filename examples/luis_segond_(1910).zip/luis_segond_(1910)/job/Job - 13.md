---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 13 - Luis Segond (1910)"
---
[[Job - 12|<--]] Job - 13 [[Job - 14|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 13

Voici, mon œil a vu tout cela,Mon oreille l’a entendu et y a pris garde. [^1] Ce que vous savez, je le sais aussi,Je ne vous suis point inférieur. [^2] Mais je veux parler au Tout-Puissant,Je veux plaider ma cause devant Dieu; [^3] Car vous, vous n’imaginez que des faussetés,Vous êtes tous #Job 16:2.des médecins de néant. [^4] #    
        Pr 17:28.  Que n’avez-vous gardé le silence?Vous auriez passé pour avoir de la sagesse. [^5] Écoutez, je vous prie, ma défense,Et soyez attentifs à la réplique de mes lèvres. [^6] #    
        Job 17:5; 32:21; 36:4.  Direz-vous en faveur de Dieu ce qui est injuste,Et pour le soutenir alléguerez-vous des faussetés? [^7] Voulez-vous avoir égard à sa personne?Voulez-vous plaider pour Dieu? [^8] S’il vous sonde, vous approuvera-t-il?Ou le tromperez-vous comme on trompe un homme? [^9] Certainement il vous condamnera,Si vous n’agissez en secret que par égard pour sa personne. [^10] Sa majesté ne vous épouvantera-t-elle pas?Sa terreur ne tombera-t-elle pas sur vous? [^11] Vos sentences sont des sentences de cendre,Vos retranchements sont des retranchements de boue. [^12] Taisez-vous, laissez-moi, je veux parler!Il m’en arrivera ce qu’il pourra. [^13] Pourquoi saisirais-je ma chair entre les dents?J’exposerai plutôt ma vie. [^14] Voici, il me tuera; #Ps 23:4. Pr 14:32.je n’ai rien à espérer;Mais devant lui je défendrai ma conduite. [^15] Cela même peut servir à mon salut,Car un impie n’ose paraître en sa présence. [^16] Écoutez, écoutez mes paroles,Prêtez l’oreille à ce que je vais dire. [^17] Me voici prêt à plaider ma cause;Je sais que j’ai raison. [^18] Quelqu’un disputera-t-il contre moi?Alors je me tais, et je veux mourir. [^19] Seulement, #Job 9:34; 33:7.accorde-moi deux chosesEt je ne me cacherai pas loin de ta face: [^20] Retire ta main de dessus moi,Et que tes terreurs ne me troublent plus. [^21] Puis appelle, et je répondrai,Ou si je parle, réponds-moi! [^22] Quel est le nombre de mes iniquités et de mes péchés?Fais-moi connaître mes transgressions et mes péchés. [^23] Pourquoi caches-tu ton visage,Et me prends-tu #Job 16:9; 19:11; 33:10. La 2:5.pour ton ennemi? [^24] Veux-tu frapper une feuille agitée?Veux-tu poursuivre une paille desséchée? [^25] Pourquoi m’infliger d’amères souffrances,Me punir pour des fautes #Ps 25:7.de jeunesse? [^26] #    
        Job 33:11.  Pourquoi mettre mes pieds dans les ceps,Surveiller tous mes mouvements,Tracer une limite à mes pas, [^27] Quand mon corps tombe en pourriture,Comme un vêtement que dévore la teigne? [^28] 

[[Job - 12|<--]] Job - 13 [[Job - 14|-->]]

---
# Notes
