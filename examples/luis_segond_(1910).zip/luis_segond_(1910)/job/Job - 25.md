---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 25 - Luis Segond (1910)"
---
[[Job - 24|<--]] Job - 25 [[Job - 26|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 25

Bildad de Schuach prit la parole et dit: [^1] La puissance et la terreur appartiennent à Dieu;Il fait régner la paix dans ses hautes régions. [^2] Ses armées ne sont-elles pas innombrables?Sur qui sa lumière ne se lève-t-elle pas? [^3] Comment l’homme serait-il #Job 4:17, 18, 19; 15:14, 15, 16.juste devant Dieu?Comment celui qui est né de la femme #Job 15:14.serait-il pur? [^4] Voici, #Job 15:15.la lune même n’est pas brillante,Et les étoiles ne sont pas pures à ses yeux; [^5] #    
        Job 4:19. Ps 22:7.  Combien moins l’homme, qui n’est qu’un ver,Le fils de l’homme, qui n’est qu’un vermisseau! [^6] 

[[Job - 24|<--]] Job - 25 [[Job - 26|-->]]

---
# Notes
