---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 31 - Luis Segond (1910)"
---
[[Job - 30|<--]] Job - 31 [[Job - 32|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 31

J’avais fait un pacte avec mes yeux,Et je n’aurais pas arrêté mes regards sur une vierge. [^1] Quelle part Dieu m’eût-il réservée d’en haut?Quel héritage le Tout-Puissant m’eût-il envoyé des cieux? [^2] La ruine n’est-elle pas pour le méchant,Et le malheur pour ceux qui commettent l’iniquité? [^3] #    
        2 Ch 16:9. Job 34:21. Pr 5:21; 15:3. Jé 32:19.  Dieu n’a-t-il pas connu mes voies?N’a-t-il pas compté tous mes pas? [^4] Si j’ai marché dans le mensonge,Si mon pied a couru vers la fraude, [^5] Que Dieu me pèse dans des balances justes,Et il reconnaîtra mon intégrité! [^6] Si mon pas s’est détourné du droit chemin,Si mon cœur a suivi mes yeux,Si quelque souillure s’est attachée à mes mains, [^7] Que je sème et qu’un autre moissonne,Et que mes rejetons soient déracinés! [^8] #    
        Job 24:15. Pr 7:25.  Si mon cœur a été séduit par une femme,Si j’ai fait le guet à la porte de mon prochain, [^9] Que ma femme tourne la meule pour un autre,Et que d’autres la déshonorent! [^10] Car c’est un crime,Un forfait que punissent les juges; [^11] C’est un feu qui dévore jusqu’à la ruine,Et qui aurait détruit toute ma richesse. [^12] Si j’ai méprisé le droit de mon serviteur ou de ma servanteLorsqu’ils étaient en contestation avec moi, [^13] Qu’ai-je à faire, #Ps 44:22.quand Dieu se lève?Qu’ai-je à répondre, quand il châtie? [^14] #    
        Job 34:19. Pr 14:31; 17:5.  Celui qui m’a créé dans le ventre de ma mère ne l’a-t-il pas créé?Le même Dieu ne nous a-t-il pas formés dans le sein maternel? [^15] Si j’ai refusé aux pauvres ce qu’ils demandaient,Si j’ai fait languir les yeux de la veuve, [^16] Si j’ai mangé seul mon pain,Sans que l’orphelin en ait eu sa part, [^17] Moi qui l’ai dès ma jeunesse élevé comme un père,Moi qui dès ma naissance ai soutenu la veuve; [^18] Si j’ai vu le malheureux manquer de vêtements,L’indigent n’avoir point de couverture, [^19] Sans que ses reins m’aient béni,Sans qu’il ait été réchauffé par la toison de mes agneaux; [^20] Si j’ai levé la main contre l’orphelin,Parce que je me sentais un appui dans les juges; [^21] Que mon épaule se détache de sa jointure,Que mon bras tombe et qu’il se brise! [^22] Car les châtiments de Dieu m’épouvantent,Et je ne puis rien devant sa majesté. [^23] #    
        Mc 10:24. 1 Ti 6:17.  Si j’ai mis dans l’or ma confiance,Si j’ai dit à l’or: Tu es mon espoir; [^24] #    
        Ps 62:11.  Si je me suis réjoui de la grandeur de mes biens,De la quantité des richesses que j’avais acquises; [^25] #    
        De 4:19.  Si j’ai regardé le soleil quand il brillait,La lune quand elle s’avançait majestueuse, [^26] Et si mon cœur s’est laissé séduire en secret,Si ma main s’est portée sur ma bouche; [^27] C’est encore un crime que doivent punir les juges,Et j’aurais renié le Dieu d’en haut! [^28] #    
        Pr 17:5.  Si j’ai été joyeux du malheur de mon ennemi,Si j’ai sauté d’allégresse quand les revers l’ont atteint, [^29] Moi qui n’ai pas permis à ma langue de pécher,#    
        Mt 5:44. Ro 12:14.  De demander sa mort avec imprécation; [^30] Si les gens de ma tente ne disaient pas:Où est celui qui n’a pas été rassasié de sa viande? [^31] #    
        Hé 13:2. 1 Pi 4:9.  Si l’étranger passait la nuit dehors,Si je n’ouvrais pas ma porte au voyageur; [^32] Si, comme les hommes, j’ai caché mes transgressions,Et renfermé mes iniquités dans mon sein, [^33] Parce que j’avais peur de la multitude,Parce que je craignais le mépris des familles,Me tenant à l’écart et n’osant franchir ma porte… [^34] Oh! Qui me fera trouver quelqu’un qui m’écoute?Voilà ma défense toute signée:Que le Tout-Puissant me réponde!Qui me donnera la plainte écrite par mon adversaire? [^35] Je porterai son écrit sur mon épaule,Je l’attacherai sur mon front comme une couronne; [^36] Je lui rendrai compte de tous mes pas,Je m’approcherai de lui comme un prince. [^37] Si ma terre crie contre moi,Et que ses sillons versent des larmes; [^38] Si j’en ai mangé le produit sans l’avoir payée,Et que j’aie attristé l’âme de ses anciens maîtres; [^39] Qu’il y croisse des épines au lieu de froment,Et de l’ivraie au lieu d’orge!Fin des paroles de Job. [^40] 

[[Job - 30|<--]] Job - 31 [[Job - 32|-->]]

---
# Notes
