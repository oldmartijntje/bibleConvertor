---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 6 - Luis Segond (1910)"
---
[[Job - 5|<--]] Job - 6 [[Job - 7|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 6

Job prit la parole et dit: [^1] Oh! S’il était possible de peser ma douleur,Et si toutes mes calamités étaient sur la balance, [^2] Elles seraient plus pesantes que #Pr 27:3.le sable de la mer;Voilà pourquoi mes paroles vont jusqu’à la folie! [^3] #    
        Ps 38:2, 3.  Car les flèches du Tout-Puissant m’ont percé,Et mon âme en suce le venin;Les terreurs de Dieu se rangent en bataille contre moi. [^4] L’âne sauvage crie-t-il auprès de l’herbe tendre?Le bœuf mugit-il auprès de son fourrage? [^5] Peut-on manger ce qui est fade et sans sel?Y a-t-il de la saveur dans le blanc d’un œuf? [^6] Ce que je voudrais ne pas toucher,C’est là ma nourriture, si dégoûtante soit-elle! [^7] Puisse mon vœu s’accomplir,Et Dieu veuille réaliser mon espérance! [^8] Qu’il plaise à Dieu de m’écraser,Qu’il étende sa main et qu’il m’achève! [^9] Il me restera du moins une consolation,Une joie dans les maux dont il m’accable:Jamais je n’ai transgressé les ordres du Saint. [^10] Pourquoi espérer quand je n’ai plus de force?Pourquoi attendre quand ma fin est certaine? [^11] Ma force est-elle une force de pierre?Mon corps est-il d’airain? [^12] Ne suis-je pas sans ressource,Et le salut n’est-il pas loin de moi? [^13] Celui qui souffre a droit à la compassion de son ami,Même quand il abandonnerait la crainte du Tout-Puissant. [^14] Mes frères sont perfides comme un torrent,Comme le lit des torrents qui disparaissent. [^15] Les glaçons en troublent le cours,La neige s’y précipite; [^16] Viennent les chaleurs, et ils tarissent,Les feux du soleil, et leur lit demeure à sec. [^17] Les caravanes se détournent de leur chemin,S’enfoncent dans le désert, et périssent. [^18] Les caravanes de Théma fixent le regard,Les voyageurs de Séba sont pleins d’espoir; [^19] Ils sont honteux d’avoir eu confiance,Ils restent confondus quand ils arrivent. [^20] Ainsi, vous êtes comme si vous n’existiez pas;Vous voyez mon angoisse, et vous en avez horreur! [^21] Vous ai-je dit: Donnez-moi quelque chose,Faites en ma faveur des présents avec vos biens, [^22] Délivrez-moi de la main de l’ennemi,Rachetez-moi de la main des méchants? [^23] Instruisez-moi, et je me tairai;Faites-moi comprendre en quoi j’ai péché. [^24] Que les paroles vraies sont persuasives!Mais que prouvent vos remontrances? [^25] Voulez-vous donc blâmer ce que j’ai dit,Et ne voir que du vent dans les discours d’un désespéré? [^26] Vous accablez un orphelin,Vous persécutez votre ami. [^27] Regardez-moi, je vous prie!Vous mentirais-je en face? [^28] Revenez, ne soyez pas injustes;Revenez, et reconnaissez mon innocence. [^29] Y a-t-il de l’iniquité sur ma langue,Et ma bouche ne discerne-t-elle pas le mal? [^30] 

[[Job - 5|<--]] Job - 6 [[Job - 7|-->]]

---
# Notes
