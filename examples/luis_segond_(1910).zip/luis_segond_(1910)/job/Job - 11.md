---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 11 - Luis Segond (1910)"
---
[[Job - 10|<--]] Job - 11 [[Job - 12|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 11

Tsophar de Naama prit la parole et dit: [^1] Cette multitude de paroles ne trouvera-t-elle point de réponse,Et suffira-t-il d’être un discoureur pour avoir raison? [^2] Tes vains propos feront-ils taire les gens?Te moqueras-tu, sans que personne te confonde? [^3] Tu dis: Ma manière de voir est juste,Et je suis pur à tes yeux. [^4] Oh! Si Dieu voulait parler,S’il ouvrait les lèvres pour te répondre, [^5] Et s’il te révélait les secrets de sa sagesse,De son immense sagesse,Tu verrais alors qu’il ne te traite pas selon ton iniquité. [^6] Prétends-tu sonder les pensées de Dieu,Parvenir à la connaissance parfaite du Tout-Puissant? [^7] Elle est aussi haute que les cieux: que feras-tu?Plus profonde que le séjour des morts: que sauras-tu? [^8] La mesure en est plus longue que la terre,Elle est plus large que la mer. [^9] S’il passe, s’il saisit,S’il traîne à son tribunal, qui s’y opposera? [^10] #    
        Ps 10:11, 14; 35:22.  Car il connaît les vicieux,Il voit facilement les coupables. [^11] #    
        Job 5:8; 22:21. Ec 3:18.  L’homme, au contraire, a l’intelligence d’un fou,Il est né comme le petit d’un âne sauvage. [^12] Pour toi, dirige ton cœur vers Dieu,Étends vers lui tes mains, [^13] Éloigne-toi de l’iniquité,Et ne laisse pas habiter l’injustice sous ta tente. [^14] Alors tu lèveras ton front sans tache,Tu seras ferme et sans crainte; [^15] Tu oublieras tes souffrances,Tu t’en souviendras comme des eaux écoulées. [^16] Tes jours auront plus d’éclat que le soleil à son midi,Tes ténèbres seront comme #Ps 37:6; 112:4.la lumière du matin, [^17] Tu seras plein de confiance, et ton attente ne sera plus vaine;Tu regarderas autour de toi, et tu reposeras #Lé 26:5.en sûreté. [^18] #    
        Lé 26:6. Ps 3:6; 4:9. Pr 3:24.  Tu te coucheras sans que personne ne te trouble,Et plusieurs caresseront ton visage. [^19] Mais #Job 8:13, 14; 18:14.les yeux des méchants seront consumés;Pour eux point de refuge;La mort, voilà leur espérance! [^20] 

[[Job - 10|<--]] Job - 11 [[Job - 12|-->]]

---
# Notes
