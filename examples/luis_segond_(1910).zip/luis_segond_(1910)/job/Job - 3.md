---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 3 - Luis Segond (1910)"
---
[[Job - 2|<--]] Job - 3 [[Job - 4|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 3

Après cela, Job ouvrit la bouche et #Jé 15:10; 20:14.maudit le jour de sa naissance. [^1] Il prit la parole et dit: [^2] Périsse le jour où je suis né,Et la nuit qui dit: Un enfant mâle est conçu! [^3] Ce jour! Qu’il se change en ténèbres,Que Dieu n’en ait point souci dans le ciel,Et que la lumière ne rayonne plus sur lui! [^4] Que l’obscurité et l’ombre de la mort s’en emparent,Que des nuées établissent leur demeure au-dessus de lui,Et que de noirs phénomènes l’épouvantent! [^5] Cette nuit! Que les ténèbres en fassent leur proie,Qu’elle disparaisse de l’année,Qu’elle ne soit plus comptée parmi les mois! [^6] Que cette nuit devienne stérile,Que l’allégresse en soit bannie! [^7] Qu’elle soit maudite par ceux qui maudissent les jours,Par ceux qui savent exciter le léviathan! [^8] Que les étoiles de son crépuscule s’obscurcissent,Qu’elle attende en vain la lumière,Et qu’elle ne voie point les paupières de l’aurore! [^9] Car elle n’a pas fermé le sein qui me conçut,Ni dérobé la souffrance à mes regards. [^10] #    
        Job 10:18.  Pourquoi ne suis-je pas mort dans le ventre de ma mère?Pourquoi n’ai-je pas expiré au sortir de ses entrailles? [^11] Pourquoi ai-je trouvé des genoux pour me recevoir,Et des mamelles pour m’allaiter? [^12] Je serais couché maintenant, je serais tranquille,Je dormirais, je reposerais, [^13] Avec les rois et les grands de la terre,Qui se bâtirent des mausolées, [^14] Avec les princes qui avaient de l’or,Et qui remplirent d’argent leurs demeures. [^15] Ou je n’existerais pas, je serais comme un avorton caché,Comme des enfants qui n’ont pas vu la lumière. [^16] Là ne s’agitent plus les méchants,Et là se reposent ceux qui sont fatigués et sans force; [^17] Les captifs sont tous en paix,Ils n’entendent pas la voix de l’oppresseur; [^18] Le petit et le grand sont là,Et l’esclave n’est plus soumis à son maître. [^19] Pourquoi donne-t-il la lumière à celui qui souffre,Et la vie à ceux qui ont l’amertume dans l’âme, [^20] Qui espèrent en vain la mort,Et qui la convoitent plus qu’un trésor, [^21] Qui seraient transportés de joieEt saisis d’allégresse, s’ils trouvaient le tombeau? [^22] A l’homme qui ne sait où aller,#    
        Job 19:8.  Et que Dieu cerne de toutes parts? [^23] Mes soupirs sont ma nourriture,Et mes cris se répandent comme l’eau. [^24] Ce que je crains, c’est ce qui m’arrive;Ce que je redoute, c’est ce qui m’atteint. [^25] Je n’ai ni tranquillité, ni paix, ni repos,Et le trouble s’est emparé de moi. [^26] 

[[Job - 2|<--]] Job - 3 [[Job - 4|-->]]

---
# Notes
