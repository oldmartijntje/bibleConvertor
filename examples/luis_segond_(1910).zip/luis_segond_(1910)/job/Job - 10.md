---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 10 - Luis Segond (1910)"
---
[[Job - 9|<--]] Job - 10 [[Job - 11|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 10

Mon âme est dégoûtée de la vie!Je donnerai cours à ma plainte,Je parlerai dans l’amertume de mon âme. [^1] Je dis à Dieu: Ne me condamne pas!Fais-moi savoir pourquoi tu me prends à partie! [^2] Te paraît-il bien de maltraiter,De repousser l’ouvrage de tes mains,Et de faire briller ta faveur sur le conseil des méchants? [^3] As-tu des yeux de chair,Vois-tu comme voit un homme? [^4] Tes jours sont-ils comme les jours de l’homme,Et tes années comme ses années, [^5] Pour que tu recherches mon iniquité,Pour que tu t’enquières de mon péché, [^6] Sachant bien que je ne suis pas coupable,Et que nul ne peut me délivrer de ta main? [^7] Tes mains m’ont formé, elles m’ont créé,Elles m’ont fait tout entier… Et tu me détruirais! [^8] Souviens-toi que tu m’as façonné comme #Ge 2:7; 3:19.de l’argile;Voudrais-tu de nouveau me réduire en poussière? [^9] #    
        Ps 139:15, 16.  Ne m’as-tu pas coulé comme du lait?Ne m’as-tu pas caillé comme du fromage? [^10] Tu m’as revêtu de peau et de chair,Tu m’as tissé d’os et de nerfs; [^11] Tu m’as accordé ta grâce avec la vie,Tu m’as conservé par tes soins et sous ta garde. [^12] Voici néanmoins ce que tu cachais dans ton cœur,Voici, je le sais, ce que tu as résolu en toi-même. [^13] Si je pèche, tu m’observes,Tu ne pardonnes pas mon iniquité. [^14] Suis-je coupable, malheur à moi!Suis-je innocent, je n’ose lever la tête,Rassasié de honte et absorbé dans ma misère. [^15] Et si j’ose la lever, tu me poursuis comme un lion,#    
        És 38:13. La 3:10.  Tu me frappes encore par des prodiges. [^16] Tu m’opposes de nouveaux témoins,Tu multiplies tes fureurs contre moi,Tu m’assailles d’une succession de calamités. [^17] #    
        Job 3:11.  Pourquoi m’as-tu fait sortir du sein de ma mère?Je serais mort, et aucun œil ne m’aurait vu; [^18] Je serais comme si je n’eusse pas existé,Et j’aurais passé du ventre de ma mère au sépulcre. [^19] Mes jours ne sont-ils pas en petit nombre? Qu’il me laisse,Qu’il se retire de moi, et que je respire un peu, [^20] Avant que je m’en aille, pour ne plus revenir,Dans le pays des ténèbres et de l’ombre de la mort, [^21] Pays d’une obscurité profonde,Où règnent l’ombre de la mort et la confusion,Et où la lumière est semblable aux ténèbres. [^22] 

[[Job - 9|<--]] Job - 10 [[Job - 11|-->]]

---
# Notes
