---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 22 - Luis Segond (1910)"
---
[[Job - 21|<--]] Job - 22 [[Job - 23|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 22

Éliphaz de Théman prit la parole et dit: [^1] Un homme peut-il être utile à Dieu?Non; le sage n’est utile qu’à lui-même. [^2] Si tu es juste, est-ce à l’avantage du Tout-Puissant?Si tu es intègre dans tes voies, qu’y gagne-t-il? [^3] Est-ce par crainte de toi qu’il te châtie,Qu’il entre en jugement avec toi? [^4] Ta méchanceté n’est-elle pas grande?Tes iniquités ne sont-elles pas infinies? [^5] #    
        Ex 22:26, 27. De 24:6, 10, etc.  Tu enlevais sans motif des gages à tes frères,Tu privais de leurs vêtements ceux qui étaient nus; [^6] Tu ne donnais point d’eau à l’homme altéré,Tu refusais du pain à l’homme affamé. [^7] Le pays était au plus fort,Et le puissant s’y établissait. [^8] Tu renvoyais les veuves à vide;Les bras des orphelins étaient brisés. [^9] C’est pour cela que tu es entouré de pièges,Et que la terreur t’a saisi tout à coup. [^10] Ne vois-tu donc pas ces ténèbres,Ces eaux débordées qui t’envahissent? [^11] Dieu n’est-il pas en haut dans les cieux?Regarde le sommet des étoiles, comme il est élevé! [^12] Et tu dis: Qu’est-ce que Dieu sait?Peut-il juger à travers l’obscurité? [^13] Les nuées l’enveloppent, et il ne voit rien;Il ne parcourt que la voûte des cieux. [^14] Eh quoi! Tu voudrais prendre l’ancienne routeQu’ont suivie les hommes d’iniquité? [^15] Ils ont été emportés avant le temps,Ils ont eu la durée d’un torrent qui s’écoule. [^16] #    
        Job 21:14.  Ils disaient à Dieu: Retire-toi de nous;Que peut faire pour nous le Tout-Puissant? [^17] Dieu cependant avait rempli de biens leurs maisons.#    
        Job 21:16.  Loin de moi le conseil des méchants! [^18] #    
        Ps 107:42.  Les justes, témoins de leur chute, se réjouiront,Et l’innocent se moquera d’eux: [^19] Voilà nos adversaires anéantis!Voilà leurs richesses dévorées par le feu! [^20] Attache-toi donc à Dieu, et tu auras la paix;Tu jouiras ainsi du bonheur. [^21] Reçois de sa bouche l’instruction,Et mets dans ton cœur ses paroles. [^22] Tu seras rétabli, si tu #Job 8:5, 6.reviens au Tout-Puissant,Si tu éloignes l’iniquité de ta tente. [^23] Jette l’or dans la poussière,L’or d’Ophir parmi les cailloux des torrents; [^24] Et le Tout-Puissant sera ton or,Ton argent, ta richesse. [^25] Alors tu feras du Tout-Puissant tes délices,Tu élèveras vers Dieu ta face; [^26] Tu le prieras, et il t’exaucera,Et tu accompliras tes vœux. [^27] A tes résolutions répondra le succès;Sur tes sentiers brillera la lumière. [^28] Vienne l’humiliation, tu prieras pour ton relèvement:Dieu #Pr 29:23.secourt celui dont le regard est abattu. [^29] Il délivrera même le coupable,Qui devra son salut à la pureté de tes mains. [^30] 

[[Job - 21|<--]] Job - 22 [[Job - 23|-->]]

---
# Notes
