---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 41 - Luis Segond (1910)"
---
[[Job - 40|<--]] Job - 41 [[Job - 42|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 41

Nul n’est assez hardi pour l’exciter;Qui donc me résisterait en face? [^1] #    
        Ro 11:35.  De qui suis-je le débiteur? Je le paierai.#    
        Ex 19:5. De 10:14. Ps 24:1; 50:12. 1 Co 10:26, 28.  Sous le ciel tout m’appartient. [^2] Je veux encore parler de ses membres,Et de sa force, et de la beauté de sa structure. [^3] Qui soulèvera son vêtement?Qui pénétrera entre ses mâchoires? [^4] Qui ouvrira les portes de sa gueule?Autour de ses dents habite la terreur. [^5] Ses magnifiques et puissants boucliersSont unis ensemble comme par un sceau; [^6] Ils se serrent l’un contre l’autre,Et l’air ne passerait pas entre eux; [^7] Ce sont des frères qui s’embrassent,Se saisissent, demeurent inséparables. [^8] Ses éternuements font briller la lumière;Ses yeux sont comme les paupières de l’aurore. [^9] Des flammes jaillissent de sa bouche,Des étincelles de feu s’en échappent. [^10] Une fumée sort de ses narines,Comme d’un vase qui bout, d’une chaudière ardente. [^11] Son souffle allume les charbons,Sa gueule lance la flamme. [^12] La force a son cou pour demeure,Et l’effroi bondit au-devant de lui. [^13] Ses parties charnues tiennent ensemble,Fondues sur lui, inébranlables. [^14] Son cœur est dur comme la pierre,Dur comme la meule inférieure. [^15] Quand il se lève, les plus vaillants ont peur,Et l’épouvante les fait fuir. [^16] C’est en vain qu’on l’attaque avec l’épée;La lance, le javelot, la cuirasse, ne servent à rien. [^17] Il regarde le fer comme de la paille,L’airain comme du bois pourri. [^18] La flèche ne le met pas en fuite,Les pierres de la fronde sont pour lui du chaume. [^19] Il ne voit dans la massue qu’un brin de paille,Il rit au sifflement des dards. [^20] Sous son ventre sont des pointes aiguës:On dirait une herse qu’il étend sur le limon. [^21] Il fait bouillir le fond de la mer comme une chaudière,Il l’agite comme un vase rempli de parfums. [^22] Il laisse après lui un sentier lumineux;L’abîme prend la chevelure d’un vieillard. [^23] Sur la terre nul n’est son maître;Il a été créé pour ne rien craindre. [^24] Il regarde avec dédain tout ce qui est élevé,Il est le roi des plus fiers animaux. [^25] 

[[Job - 40|<--]] Job - 41 [[Job - 42|-->]]

---
# Notes
