---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 4 - Luis Segond (1910)"
---
[[Job - 3|<--]] Job - 4 [[Job - 5|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 4

Éliphaz de Théman prit la parole et dit: [^1] Si nous osons ouvrir la bouche, en seras-tu peiné?Mais qui pourrait garder le silence? [^2] Voici, tu as souvent enseigné les autres,Tu as fortifié les mains languissantes, [^3] Tes paroles ont relevé ceux qui chancelaient,Tu as affermi les genoux qui pliaient. [^4] Et maintenant qu’il s’agit de toi, tu faiblis!Maintenant que tu es atteint, tu te troubles! [^5] Ta crainte de Dieu n’est-elle pas ton soutien?Ton espérance, n’est-ce pas ton intégrité? [^6] Cherche dans ton souvenir: quel est l’innocent qui a péri?Quels sont les justes qui ont été exterminés? [^7] Pour moi, je l’ai vu, #Job 15:35. Ps 7:15. Pr 22:8. És 59:4. Os 10:13. Ga 6:7, 8.ceux qui labourent l’iniquitéEt qui sèment l’injustice en moissonnent les fruits; [^8] #    
        És 11:4.  Ils périssent par le souffle de Dieu,Ils sont consumés par le vent de sa colère, [^9] Le rugissement des lions prend fin,Les dents des lionceaux sont brisées; [^10] Le lion périt faute de proie,Et les petits de la lionne se dispersent. [^11] Une parole est arrivée furtivement jusqu’à moi,Et mon oreille en a recueilli les sons légers. [^12] Au moment où les visions de la nuit agitent la pensée,Quand les hommes sont livrés à un profond sommeil, [^13] Je fus saisi de frayeur et d’épouvante,Et tous mes os tremblèrent. [^14] Un esprit passa près de moi…Tous mes cheveux se hérissèrent… [^15] Une figure d’un aspect inconnu était devant mes yeux,Et j’entendis une voix qui murmurait doucement: [^16] L’homme serait-il juste devant Dieu?Serait-il pur devant celui qui l’a fait? [^17] #    
        Job 15:15. 2 Pi 2:4.  Si Dieu n’a pas confiance en ses serviteurs,S’il trouve de la folie chez ses anges, [^18] Combien plus chez ceux qui habitent des maisons d’argile,Qui tirent leur origine de la poussière,Et qui peuvent être écrasés comme un vermisseau! [^19] Du matin au soir ils sont brisés,Ils périssent pour toujours, et nul n’y prend garde; [^20] Le fil de leur vie est coupé,Ils meurent, et ils n’ont pas acquis la sagesse. [^21] 

[[Job - 3|<--]] Job - 4 [[Job - 5|-->]]

---
# Notes
