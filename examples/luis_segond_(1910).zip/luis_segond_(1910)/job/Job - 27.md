---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 27 - Luis Segond (1910)"
---
[[Job - 26|<--]] Job - 27 [[Job - 28|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 27

Job prit de nouveau la parole sous forme sentencieuse et dit: [^1] Dieu qui me refuse justice est vivant!Le Tout-Puissant qui remplit mon âme d’amertume est vivant! [^2] Aussi longtemps que j’aurai ma respiration,Et que le souffle de Dieu sera dans mes narines, [^3] Mes lèvres ne prononceront rien d’injuste,Ma langue ne dira rien de faux. [^4] Loin de moi la pensée de vous donner raison!Jusqu’à mon dernier soupir je défendrai mon innocence; [^5] Je tiens à me justifier, et je ne faiblirai pas;Mon cœur ne me fait de reproche sur aucun de mes jours. [^6] Que mon ennemi soit comme le méchant,Et mon adversaire comme l’impie! [^7] #    
        Mt 16:26. Lu 12:20.  Quelle espérance reste-t-il à l’impie,Quand Dieu coupe le fil de sa vie,Quand il lui retire son âme? [^8] #    
        Job 35:12. Ps 18:42; 109:7. Pr 1:28; 28:9. És 1:15. Jé 14:12. Éz 8:18. Mi 3:4. Jn 9:31. Ja 4:3.  Est-ce que Dieu écoute ses cris,Quand l’angoisse vient l’assaillir? [^9] Fait-il du Tout-Puissant ses délices?Adresse-t-il en tout temps ses prières à Dieu? [^10] Je vous enseignerai les voies de Dieu,Je ne vous cacherai pas les desseins du Tout-Puissant. [^11] Mais vous les connaissez, et vous êtes d’accord;Pourquoi donc vous laisser aller à de vaines pensées? [^12] #    
        Job 20:29.  Voici la part que Dieu réserve au méchant,L’héritage que le Tout-Puissant destine à l’impie. [^13] S’il a des fils en grand nombre, #De 28:41. Os 9:13.c’est pour le glaive,Et ses rejetons manquent de pain; [^14] Ceux qui échappent sont enterrés par la peste,#    
        Ps 78:64.  Et leurs veuves ne les pleurent pas. [^15] S’il amasse l’argent comme la poussière,S’il entasse les vêtements comme la boue, [^16] C’est lui qui entasse, #Pr 28:8. Ec 2:26.mais c’est le juste qui se revêt,C’est l’homme intègre qui a l’argent en partage. [^17] Sa maison est comme celle que bâtit la teigne,Comme la cabane que fait un gardien. [^18] #    
        Ps 49:18.  Il se couche riche, et il meurt dépouillé;Il ouvre les yeux, et tout a disparu. [^19] #    
        Job 15:21; 18:11.  Les terreurs le surprennent comme des eaux;Un tourbillon l’enlève au milieu de la nuit. [^20] Le vent d’orient l’emporte, et il s’en va;Il l’arrache violemment de sa demeure. [^21] Dieu lance sans pitié des traits contre lui,Et le méchant voudrait fuir pour les éviter. [^22] On bat des mains à sa chute,Et on le siffle à son départ. [^23] 

[[Job - 26|<--]] Job - 27 [[Job - 28|-->]]

---
# Notes
