---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 17 - Luis Segond (1910)"
---
[[Job - 16|<--]] Job - 17 [[Job - 18|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 17

Mon souffle se perd,Mes jours s’éteignent,Le sépulcre m’attend. [^1] Je suis environné de moqueurs,Et mon œil doit contempler leurs insultes. [^2] Sois auprès de toi-même ma caution;Autrement, qui répondrait pour moi? [^3] Car tu as fermé leur cœur à l’intelligence;Aussi ne les laisseras-tu pas triompher. [^4] On invite ses amis au partage du butin,Et l’on a des enfants dont les yeux se consument. [^5] #    
        Job 30:5.  Il m’a rendu la fable des peuples,Et ma personne est un objet de mépris. [^6] Mon œil est obscurci par la douleur;Tous mes membres sont comme une ombre. [^7] Les hommes droits en sont stupéfaits,Et l’innocent se soulève contre l’impie. [^8] Le juste néanmoins demeure ferme dans sa voie,Celui qui a les mains pures se fortifie de plus en plus. [^9] #    
        Job 6:29.  Mais vous tous, revenez à vos mêmes discours,Et je ne trouverai pas un sage parmi vous. [^10] #    
        Job 7:6; 9:25.  Quoi! Mes jours sont passés, mes projets sont anéantis,Les projets qui remplissaient mon cœur… [^11] Et ils prétendent que la nuit c’est le jour,Que la lumière est proche quand les ténèbres sont là! [^12] C’est le séjour des morts que j’attends pour demeure,C’est dans les ténèbres que je dresserai ma couche; [^13] Je crie à la fosse: Tu es mon père!Et aux vers: Vous êtes ma mère et ma sœur! [^14] Mon espérance, où donc est-elle?Mon espérance, qui peut la voir? [^15] Elle descendra vers les portes du séjour des morts,Quand nous irons ensemble reposer #Job 3:17, 18, 19; 30:23, 24.dans la poussière. [^16] 

[[Job - 16|<--]] Job - 17 [[Job - 18|-->]]

---
# Notes
