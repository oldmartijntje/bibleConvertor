---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 30 - Luis Segond (1910)"
---
[[Job - 29|<--]] Job - 30 [[Job - 31|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 30

Et maintenant!… je suis la risée de plus jeunes que moi,De ceux dont je dédaignais de mettre les pèresParmi les chiens de mon troupeau. [^1] Mais à quoi me servirait la force de leurs mains?Ils sont incapables d’atteindre la vieillesse. [^2] Desséchés par la misère et la faim,Ils fuient dans les lieux arides,Depuis longtemps abandonnés et déserts; [^3] Ils arrachent près des arbrisseaux les herbes sauvages,Et ils n’ont pour pain que la racine des genêts. [^4] On les chasse du milieu des hommes,On crie après eux comme après des voleurs. [^5] Ils habitent dans d’affreuses vallées,Dans les cavernes de la terre et dans les rochers; [^6] Ils hurlent parmi les buissons,Ils se rassemblent sous les ronces. [^7] Êtres vils et méprisés,On les repousse du pays. [^8] #    
        Job 17:6. Ps 69:13. La 3:14, 63.  Et maintenant, je suis l’objet de leurs chansons,Je suis en butte à leurs propos. [^9] #    
        Job 19:19.  Ils ont horreur de moi, ils se détournent,Ils me crachent au visage. [^10] Ils n’ont plus de retenue et ils m’humilient,Ils rejettent tout frein devant moi. [^11] Ces misérables se lèvent à ma droite et me poussent les pieds,Ils se fraient contre moi des sentiers pour ma ruine; [^12] Ils détruisent mon propre sentier et travaillent à ma perte,Eux à qui personne ne viendrait en aide; [^13] Ils arrivent comme par une large brèche,Ils se précipitent sous les craquements. [^14] Les terreurs m’assiègent;Ma gloire est emportée comme par le vent,Mon bonheur a passé comme un nuage. [^15] Et maintenant, mon âme s’épanche en mon sein,Les jours de la souffrance m’ont saisi. [^16] La nuit me perce et m’arrache les os,La douleur qui me ronge ne se donne aucun repos, [^17] Par la violence du mal mon vêtement perd sa forme,Il se colle à mon corps comme ma tunique. [^18] Dieu m’a jeté dans la boue,Et je ressemble à la poussière et à la cendre. [^19] Je crie vers toi, et tu ne me réponds pas;Je me tiens debout, et tu me lances ton regard. [^20] Tu deviens cruel contre moi,Tu me combats avec la force de ta main. [^21] Tu me soulèves, tu me fais voler au-dessus du vent,Et tu m’anéantis au bruit de la tempête. [^22] Car, je le sais, #Hé 9:27.tu me mènes à la mort,Au rendez-vous de tous les vivants. [^23] Mais celui qui va périr n’étend-il pas les mains?Celui qui est dans le malheur n’implore-t-il pas du secours? [^24] #    
        Ps 35:13, 14. Ro 12:15.  N’avais-je pas des larmes pour l’infortuné?Mon cœur n’avait-il pas pitié de l’indigent? [^25] J’attendais le bonheur, et le malheur est arrivé;J’espérais la lumière, et les ténèbres sont venues. [^26] Mes entrailles bouillonnent sans relâche,Les jours de la calamité m’ont surpris. [^27] Je marche noirci, mais non par le soleil;Je me lève en pleine assemblée, et je crie. [^28] #    
        Ps 102:7.  Je suis devenu le frère des chacals,Le compagnon des autruches. [^29] #    
        Ps 119:83. La 4:8; 5:10.  Ma peau noircit et tombe,Mes os brûlent et se dessèchent. [^30] Ma harpe n’est plus qu’un instrument de deuil,Et mon chalumeau ne peut rendre que des sons plaintifs. [^31] 

[[Job - 29|<--]] Job - 30 [[Job - 31|-->]]

---
# Notes
