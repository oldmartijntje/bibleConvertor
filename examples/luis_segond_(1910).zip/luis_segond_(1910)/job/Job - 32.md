---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 32 - Luis Segond (1910)"
---
[[Job - 31|<--]] Job - 32 [[Job - 33|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 32

Ces trois hommes cessèrent de répondre à Job, parce qu’il se regardait comme juste. [^1] Alors s’enflamma de colère Élihu, fils de Barakeel de Buz, de la famille de Ram. Sa colère s’enflamma contre Job, parce qu’il se disait juste devant Dieu. [^2] Et sa colère s’enflamma contre ses trois amis, parce qu’ils ne trouvaient rien à répondre et que néanmoins ils condamnaient Job. [^3] Comme ils étaient plus âgés que lui, Élihu avait attendu jusqu’à ce moment pour parler à Job. [^4] Mais, voyant qu’il n’y avait plus de réponse dans la bouche de ces trois hommes, Élihu s’enflamma de colère. [^5] Et Élihu, fils de Barakeel de Buz, prit la parole et dit:Je suis jeune, et vous êtes #Job 15:10.des vieillards;C’est pourquoi j’ai craint, j’ai redoutéDe vous faire connaître mon sentiment. [^6] Je disais en moi-même: Les jours parleront,Le grand nombre des années enseignera la sagesse. [^7] #    
        Job 12:13; 38:36. Pr 2:6. Ec 2:26. Da 1:17; 2:21.  Mais en réalité, dans l’homme, c’est l’esprit,Le souffle du Tout-Puissant, qui donne l’intelligence; [^8] #    
        Job 12:12.  Ce n’est pas l’âge qui procure la sagesse,Ce n’est pas la vieillesse qui rend capable de juger. [^9] Voilà pourquoi je dis: Écoute!Moi aussi, j’exposerai ma pensée. [^10] J’ai attendu la fin de vos discours,J’ai suivi vos raisonnements,Votre examen des paroles de Job. [^11] Je vous ai donné toute mon attention;Et voici, aucun de vous ne l’a convaincu,Aucun n’a réfuté ses paroles. [^12] Ne dites pas cependant:En lui nous avons trouvé la sagesse;C’est Dieu qui peut le confondre, ce n’est pas un homme! [^13] Il ne s’est pas adressé directement à moi:Aussi lui répondrai-je tout autrement que vous. [^14] Ils ont peur, ils ne répondent plus!Ils ont la parole coupée! [^15] J’ai attendu qu’ils eussent fini leurs discours,Qu’ils s’arrêtassent et ne sussent que répliquer. [^16] A mon tour, je veux répondre aussi,Je veux dire aussi ce que je pense. [^17] Car je suis plein de paroles,L’esprit me presse au-dedans de moi; [^18] Mon intérieur est comme un vin qui n’a pas d’issue,Comme des outres neuves qui vont éclater. [^19] Je parlerai pour respirer à l’aise,J’ouvrirai mes lèvres et je répondrai. [^20] Je n’aurai point égard à l’apparence,Et je ne flatterai personne; [^21] Car je ne sais pas flatter:Mon créateur m’enlèverait bien vite. [^22] 

[[Job - 31|<--]] Job - 32 [[Job - 33|-->]]

---
# Notes
