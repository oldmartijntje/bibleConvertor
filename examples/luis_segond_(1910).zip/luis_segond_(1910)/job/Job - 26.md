---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 26 - Luis Segond (1910)"
---
[[Job - 25|<--]] Job - 26 [[Job - 27|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 26

Job prit la parole et dit: [^1] Comme tu sais bien venir en aide à la faiblesse!Comme tu prêtes secours au bras sans force! [^2] Quels bons conseils tu donnes à celui qui manque d’intelligence!Quelle abondance de sagesse tu fais paraître! [^3] A qui s’adressent tes paroles?Et qui est-ce qui t’inspire? [^4] Devant Dieu les ombres tremblentAu-dessous des eaux et de leurs habitants; [^5] #    
        Ps 139:8, 11. Pr 15:11. Hé 4:13.  Devant lui le séjour des morts est nu,L’abîme n’a point de voile. [^6] Il étend le septentrion sur le vide,#    
        Ps 104:2.  Il suspend la terre sur le néant. [^7] Il renferme les eaux dans ses nuages,Et les nuages n’éclatent pas sous leur poids. [^8] #    
        Job 9:8. Ps 104:2, 3.  Il couvre la face de son trône,Il répand sur lui sa nuée. [^9] #    
        Job 38:8. Ps 33:7; 104:9. Jé 5:22.  Il a tracé un cercle à la surface des eaux,#    
        Ge 1:9. Job 38:8. Ps 33:7; 104:9. Pr 8:29. Jé 5:22.  Comme limite entre la lumière et les ténèbres. [^10] Les colonnes du ciel s’ébranlent,Et s’étonnent à sa menace. [^11] Par sa force #És 51:15.il soulève la mer,Par son intelligence il en brise l’orgueil. [^12] #    
        Ps 33:6.  Son souffle donne au ciel la sérénité,Sa main transperce le serpent fuyard. [^13] Ce sont là les bords de ses voies,C’est le bruit léger qui nous en parvient;Mais qui entendra le tonnerre de sa puissance? [^14] 

[[Job - 25|<--]] Job - 26 [[Job - 27|-->]]

---
# Notes
