---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 38 - Luis Segond (1910)"
---
[[Job - 37|<--]] Job - 38 [[Job - 39|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 38

L’Éternel répondit à Job du milieu de la tempête et dit: [^1] #    
        Job 42:3.  Qui est celui qui obscurcit mes desseinsPar des discours sans intelligence? [^2] Ceins tes reins comme un vaillant homme;Je t’interrogerai, et tu m’instruiras. [^3] Où étais-tu #Pr 8:29.quand je fondais la terre?Dis-le, si tu as de l’intelligence. [^4] Qui en a fixé les dimensions, le sais-tu?Ou qui a étendu sur elle le cordeau? [^5] Sur quoi ses bases sont-elles appuyées?Ou qui en a posé la pierre angulaire, [^6] Alors que les étoiles du matin éclataient en chants d’allégresse,Et que tous les fils de Dieu poussaient des cris de joie? [^7] #    
        Ge 1:9. Job 26:10. Ps 33:7; 104:7. Pr 8:29. Jé 5:22.  Qui a fermé la mer avec des portes,Quand elle s’élança du sein maternel; [^8] Quand je fis de la nuée son vêtement,Et de l’obscurité ses langes; [^9] Quand je lui imposai ma loi,Et que je lui mis des barrières et des portes; [^10] Quand je dis:Tu viendras jusqu’ici, tu n’iras pas au-delà;Ici s’arrêtera l’orgueil de tes flots? [^11] Depuis que tu existes, as-tu commandé au matin?As-tu montré sa place à l’aurore, [^12] Pour qu’elle saisisse les extrémités de la terre,Et que les méchants en soient secoués; [^13] Pour que la terre se transforme comme l’argile qui reçoit une empreinte,Et qu’elle soit parée comme d’un vêtement; [^14] Pour que les méchants soient privés de leur lumière,Et que le bras qui se lève soit brisé? [^15] As-tu pénétré jusqu’aux sources de la mer?T’es-tu promené dans les profondeurs de l’abîme? [^16] Les portes de la mort t’ont-elles été ouvertes?As-tu vu les portes de l’ombre de la mort? [^17] As-tu embrassé du regard l’étendue de la terre?Parle, si tu sais toutes ces choses. [^18] Où est le chemin qui conduit au séjour de la lumière?Et les ténèbres, où ont-elles leur demeure? [^19] Peux-tu les saisir à leur limite,Et connaître les sentiers de leur habitation? [^20] Tu le sais, car alors tu étais né,Et le nombre de tes jours est grand! [^21] Es-tu parvenu jusqu’aux amas de neige?As-tu vu les dépôts de grêle, [^22] Que je tiens en réserve pour les temps de détresse,Pour les jours de guerre et de bataille? [^23] Par quel chemin la lumière se divise-t-elle,Et le vent d’orient se répand-il sur la terre? [^24] Qui a ouvert un passage à la pluie,Et tracé la route de l’éclair et du tonnerre, [^25] Pour que la pluie tombe sur une terre sans habitants,Sur un désert où il n’y a point d’hommes; [^26] #    
        Ps 107:35.  Pour qu’elle abreuve les lieux solitaires et arides,Et qu’elle fasse germer et sortir l’herbe? [^27] La pluie a-t-elle un père?Qui fait naître les gouttes de la rosée? [^28] Du sein de qui sort la glace,Et qui enfante le frimas du ciel, [^29] Pour que les eaux se cachent comme une pierre,Et que la surface de l’abîme soit enchaînée? [^30] Noues-tu les liens #Job 9:9. Am 5:8.des Pléiades,Ou détaches-tu les cordages de l’Orion? [^31] Fais-tu paraître en leur temps les signes du zodiaque,Et conduis-tu la Grande Ourse avec ses petits? [^32] #    
        Jé 31:35.  Connais-tu les lois du ciel?Règles-tu son pouvoir sur la terre? [^33] Élèves-tu la voix jusqu’aux nuées,Pour appeler à toi des torrents d’eaux? [^34] Lances-tu les éclairs?Partent-ils?Te disent-ils: Nous voici? [^35] #    
        Job 32:8. Ec 2:26. Da 1:17.  Qui a mis la sagesse dans le cœur,Ou qui a donné l’intelligence à l’esprit? [^36] Qui peut avec sagesse compter les nuages,Et verser les outres des cieux, [^37] Pour que la poussière se mette à ruisseler,Et que les mottes de terre se collent ensemble? [^38] 

[[Job - 37|<--]] Job - 38 [[Job - 39|-->]]

---
# Notes
