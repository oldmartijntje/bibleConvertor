---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 18 - Luis Segond (1910)"
---
[[Job - 17|<--]] Job - 18 [[Job - 19|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 18

Bildad de Schuach prit la parole et dit: [^1] Quand mettrez-vous un terme à ces discours?Ayez de l’intelligence, puis nous parlerons. [^2] Pourquoi sommes-nous regardés comme des bêtes?Pourquoi ne sommes-nous à vos yeux que des brutes? [^3] #    
        Job 13:14.  O toi qui te déchires dans ta fureur,Faut-il, à cause de toi, que la terre devienne déserte?Faut-il que les rochers disparaissent de leur place? [^4] La lumière du méchant s’éteindra,Et la flamme qui en jaillit cessera de briller. [^5] La lumière s’obscurcira sous sa tente,Et sa lampe au-dessus de lui s’éteindra. [^6] Ses pas assurés seront à l’étroit;Malgré ses efforts, il tombera. [^7] Car il met les pieds sur un filet,Il marche dans les mailles, [^8] Il est saisi au piège par le talon,#    
        Job 5:5.  Et le filet s’empare de lui; [^9] Le cordeau est caché dans la terre,Et la trappe est sur son sentier. [^10] #    
        Job 15:21. Jé 6:25; 46:5; 49:29.  Des terreurs l’assiègent, l’entourent,Le poursuivent par derrière. [^11] #    
        Job 15:23.  La faim consume ses forces,La misère est à ses côtés. [^12] Les parties de sa peau sont l’une après l’autre dévorées,Ses membres sont dévorés par le premier-né de la mort. [^13] #    
        Job 8:13, 14; 11:20. Pr 10:28.  Il est arraché de sa tente où il se croyait en sûreté,Il se traîne vers le roi des épouvantements. [^14] Nul des siens n’habite sa tente,Le soufre est répandu sur sa demeure. [^15] En bas, ses racines se dessèchent;En haut, ses branches sont coupées. [^16] #    
        Ps 109:13. Pr 10:7.  Sa mémoire disparaît de la terre,Son nom n’est plus sur la face des champs. [^17] Il est poussé de la lumière dans les ténèbres,Il est chassé du monde. [^18] #    
        És 14:22. Jé 22:30.  Il ne laisse ni descendants ni postérité parmi son peuple,Ni survivant dans les lieux qu’il habitait. [^19] Les générations à venir seront étonnées de sa ruine,Et la génération présente sera saisie d’effroi. [^20] Point d’autre destinée pour le méchant,Point d’autre sort pour qui ne connaît pas Dieu! [^21] 

[[Job - 17|<--]] Job - 18 [[Job - 19|-->]]

---
# Notes
