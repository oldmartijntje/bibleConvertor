---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 12 - Luis Segond (1910)"
---
[[Job - 11|<--]] Job - 12 [[Job - 13|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 12

Job prit la parole et dit: [^1] On dirait, en vérité, que le genre humain c’est vous,Et qu’avec vous doit mourir la sagesse. [^2] J’ai tout aussi bien que vous de l’intelligence, moi,Je ne vous suis point inférieur;Et qui ne sait les choses que vous dites? [^3] #    
        Job 16:10; 17:2; 21:3; 30:1.  Je suis pour mes amis un objet de raillerie,Quand j’implore le secours de Dieu;#    
        Pr 14:2.  Le juste, l’innocent, un objet de raillerie! [^4] Au malheur le mépris! C’est la devise des heureux;A celui dont le pied chancelle est réservé le mépris. [^5] #    
        Job 21:7. Ps 73:11, 12. Jé 12:1. Ha 1:3, 4.  Il y a paix sous la tente des pillards,Sécurité pour ceux qui offensent Dieu,Pour quiconque se fait un dieu de sa force. [^6] Interroge les bêtes, elles t’instruiront,Les oiseaux du ciel, ils te l’apprendront; [^7] Parle à la terre, elle t’instruira;Et les poissons de la mer te le raconteront. [^8] Qui ne reconnaît chez eux la preuveQue la main de l’Éternel a fait toutes choses? [^9] Il tient dans sa main l’âme de tout ce qui vit,Le souffle de toute chair d’homme. [^10] #    
        Job 6:30; 34:3.  L’oreille ne discerne-t-elle pas les paroles,Comme le palais savoure les aliments? [^11] Dans les vieillards se trouve la sagesse,Et dans une longue vie l’intelligence. [^12] En Dieu résident la sagesse et la puissance.Le conseil et l’intelligence lui appartiennent. [^13] Ce qu’il renverse ne sera point rebâti,#    
        Job 9:12; 11:10. Ap 3:7.  Celui qu’il enferme ne sera point délivré. [^14] Il retient les eaux et tout se dessèche;Il les lâche, et la terre en est dévastée. [^15] Il possède la force et la prudence;Il maîtrise celui qui s’égare ou fait égarer les autres. [^16] #    
        2 S 15:31; 17:14, 23. És 19:12; 29:14. 1 Co 1:19.  Il emmène captifs les conseillers;#    
        2 S 15:31.  Il trouble la raison des juges. [^17] Il délie la ceinture des rois,Il met une corde autour de leurs reins. [^18] Il emmène captifs les sacrificateurs;Il fait tomber les puissants. [^19] #    
        Job 32:9. És 3:2, 3.  Il ôte la parole à ceux qui ont de l’assurance;Il prive de jugement les vieillards. [^20] #    
        Ps 107:40.  Il verse le mépris sur les grands;Il relâche la ceinture des forts. [^21] Il met à découvert ce qui est caché dans les ténèbres,#    
        Mt 10:26. 1 Co 4:5.  Il produit à la lumière l’ombre de la mort. [^22] #    
        Ps 107:38.  Il donne de l’accroissement aux nations, et il les anéantit;Il les étend au loin, et il les ramène dans leurs limites. [^23] Il enlève l’intelligence aux chefs des peuples,#    
        Ps 107:4, 40.  Il les fait errer dans les déserts sans chemin; [^24] Ils tâtonnent dans les ténèbres, et ne voient pas clair;Il les fait errer comme des gens ivres. [^25] 

[[Job - 11|<--]] Job - 12 [[Job - 13|-->]]

---
# Notes
