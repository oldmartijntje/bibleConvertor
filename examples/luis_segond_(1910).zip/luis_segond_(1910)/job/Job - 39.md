---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 39 - Luis Segond (1910)"
---
[[Job - 38|<--]] Job - 39 [[Job - 40|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 39

#    
        Ps 104:21.  Chasses-tu la proie pour la lionne,Et apaises-tu la faim des lionceaux, [^1] Quand ils sont couchés dans leur tanière,Quand ils sont en embuscade dans leur repaire? [^2] #    
        Ps 147:9. Mt 6:26.  Qui prépare au corbeau sa pâture,Quand ses petits crient vers Dieu,Quand ils sont errants et affamés? [^3] Sais-tu quand les chèvres sauvages font leurs petits?#    
        Ps 29:9.  Observes-tu les biches quand elles mettent bas? [^4] Comptes-tu les mois pendant lesquels elles portent,Et connais-tu l’époque où elles enfantent? [^5] Elles se courbent, laissent échapper leur progéniture,Et sont délivrées de leurs douleurs. [^6] Leurs petits prennent de la vigueur et grandissent en plein air,Ils s’éloignent et ne reviennent plus auprès d’elles. [^7] Qui met en liberté l’âne sauvage,Et l’affranchit de tout lien? [^8] #    
        Job 24:5. Jé 2:24.  J’ai fait du désert son habitation,De la terre salée sa demeure. [^9] Il se rit du tumulte des villes,Il n’entend pas les cris d’un maître. [^10] Il parcourt les montagnes pour trouver sa pâture,Il est à la recherche de tout ce qui est vert. [^11] Le buffle veut-il être à ton service?Passe-t-il la nuit vers ta crèche? [^12] L’attaches-tu par une corde pour qu’il trace un sillon?Va-t-il après toi briser les mottes des vallées? [^13] Te reposes-tu sur lui, parce que sa force est grande?Lui abandonnes-tu le soin de tes travaux? [^14] Te fies-tu à lui pour la rentrée de ta récolte?Est-ce lui qui doit l’amasser dans ton aire? [^15] L’aile de l’autruche se déploie joyeuse;On dirait l’aile, le plumage de la cigogne. [^16] Mais l’autruche abandonne ses œufs à la terre,Et les fait chauffer sur la poussière; [^17] Elle oublie que le pied peut les écraser,Qu’une bête des champs peut les fouler. [^18] Elle est dure envers ses petits comme s’ils n’étaient point à elle;Elle ne s’inquiète pas de l’inutilité de son enfantement. [^19] Car Dieu lui a refusé la sagesse,Il ne lui a pas donné l’intelligence en partage. [^20] Quand elle se lève et prend sa course,Elle se rit du cheval et de son cavalier. [^21] Est-ce toi qui donnes la vigueur au cheval,Et qui revêts son cou d’une crinière flottante? [^22] Le fais-tu bondir comme la sauterelle?Son fier hennissement répand la terreur. [^23] Il creuse le sol et se réjouit de sa force,Il s’élance au-devant des armes; [^24] Il se rit de la crainte, il n’a pas peur,Il ne recule pas en face de l’épée. [^25] Sur lui retentit le carquois,Brillent la lance et le javelot. [^26] Bouillonnant d’ardeur, il dévore la terre,Il ne peut se contenir au bruit de la trompette. [^27] Quand la trompette sonne, il dit: En avant!Et de loin il flaire la bataille,La voix tonnante des chefs et les cris de guerre. [^28] Est-ce par ton intelligence que l’épervier prend son vol,Et qu’il étend ses ailes vers le midi? [^29] Est-ce par ton ordre que l’aigle s’élève,#    
        Jé 49:16. Ab v. 4.  Et qu’il place son nid sur les hauteurs? [^30] C’est dans les rochers qu’il habite, qu’il a sa demeure,Sur la cime des rochers, sur le sommet des monts. [^31] De là il épie sa proie,Il plonge au loin les regards. [^32] Ses petits boivent le sang;#    
        Mt 24:28. Lu 17:37.  Et là où sont des cadavres, l’aigle se trouve. [^33] L’Éternel, s’adressant à Job, dit: [^34] Celui qui dispute contre le Tout-Puissant est-il convaincu?Celui qui conteste avec Dieu a-t-il une réplique à faire? [^35] Job répondit à l’Éternel et dit: [^36] Voici, je suis trop peu de chose; que te répliquerais-je?#    
        Ps 39:10.  Je mets la main sur ma bouche. [^37] J’ai parlé une fois, je ne répondrai plus;Deux fois, je n’ajouterai rien. [^38] 

[[Job - 38|<--]] Job - 39 [[Job - 40|-->]]

---
# Notes
