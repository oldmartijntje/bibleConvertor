---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 5 - Luis Segond (1910)"
---
[[Job - 4|<--]] Job - 5 [[Job - 6|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 5

Crie maintenant! Qui te répondra?Auquel des saints t’adresseras-tu? [^1] L’insensé périt dans sa colère,Le fou meurt dans ses emportements. [^2] #    
        Ps 37:36.  J’ai vu l’insensé prendre racine;Puis soudain j’ai maudit sa demeure. [^3] Plus de prospérité pour ses fils;Ils sont foulés à la porte, et personne qui les délivre! [^4] Sa moisson est dévorée par des affamés,Qui viennent l’enlever jusque dans les épines,Et ses biens sont engloutis par des hommes altérés. [^5] Le malheur ne sort pas de la poussière,Et la souffrance ne germe pas du sol; [^6] L’homme naît pour souffrir,Comme l’étincelle pour voler. [^7] Pour moi, j’aurais recours à Dieu,Et c’est à Dieu que j’exposerais ma cause. [^8] #    
        Job 9:10. Ps 72:18. Ro 11:33.  Il fait des choses grandes et insondables,Des merveilles sans nombre; [^9] Il répand la pluie sur la terre,Et envoie l’eau sur les campagnes; [^10] #    
        1 S 2:7. Ps 113:7, 8.  Il relève les humbles,Et délivre les affligés; [^11] #    
        Né 4:15. Ps 33:10. És 8:10.  Il anéantit les projets des hommes rusés,Et leurs mains ne peuvent les accomplir; [^12] #    
        1 Co 3:19.  Il prend les sages dans leur propre ruse,Et les desseins des hommes artificieux sont renversés: [^13] #    
        De 28:29.  Ils rencontrent les ténèbres au milieu du jour,Ils tâtonnent en plein midi comme dans la nuit. [^14] Ainsi Dieu protège le faible contre leurs menaces,Et le sauve de la main des puissants; [^15] #    
        Ps 107:42.  Et l’espérance soutient le malheureux,Mais l’iniquité ferme la bouche. [^16] #    
        Pr 3:11, 12. Hé 12:5. Ja 1:12. Ap 3:19.  Heureux l’homme que Dieu châtie!Ne méprise pas la correction du Tout-Puissant. [^17] #    
        De 32:39. 1 S 2:6. Os 6:1.  Il fait la plaie, et il la bande;Il blesse, et sa main guérit. [^18] #    Ps 91:3, etc.  Six fois il te délivrera de l’angoisse,Et sept fois le mal ne t’atteindra pas. [^19] Il te sauvera de la mort pendant la famine,Et des coups du glaive pendant la guerre. [^20] Tu seras à l’abri du fléau de la langue,Tu seras sans crainte quand viendra la dévastation. [^21] Tu te riras de la dévastation comme de la famine,Et tu n’auras pas à redouter les bêtes de la terre; [^22] Car tu feras alliance avec les pierres des champs,#    
        Os 2:17.  Et les bêtes de la terre seront en paix avec toi. [^23] Tu jouiras du bonheur sous ta tente,Tu retrouveras tes troupeaux au complet, [^24] Tu verras ta postérité s’accroître,Et tes rejetons se multiplier comme l’herbe des champs. [^25] Tu entreras au sépulcre dans la vieillesse,Comme on emporte une gerbe en son temps. [^26] Voilà ce que nous avons reconnu, voilà ce qui est;A toi d’entendre et de mettre à profit. [^27] 

[[Job - 4|<--]] Job - 5 [[Job - 6|-->]]

---
# Notes
