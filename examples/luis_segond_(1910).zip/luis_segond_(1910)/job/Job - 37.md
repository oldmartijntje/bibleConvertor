---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 37 - Luis Segond (1910)"
---
[[Job - 36|<--]] Job - 37 [[Job - 38|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 37

Mon cœur est tout tremblant,Il bondit hors de sa place. [^1] Écoutez, écoutez le frémissement de sa voix,#    
        Ps 29:3.  Le grondement qui sort de sa bouche! [^2] Il le fait rouler dans toute l’étendue des cieux,Et son éclair brille jusqu’aux extrémités de la terre. [^3] Puis éclate un rugissement: il tonne de sa voix majestueuse;Il ne retient plus l’éclair, dès que sa voix retentit. [^4] Dieu tonne avec sa voix d’une manière merveilleuse;#    
        Job 5:9; 9:10; 36:26.  Il fait de grandes choses que nous ne comprenons pas. [^5] #    
        Ps 147:16.  Il dit à la neige: Tombe sur la terre!Il le dit à la pluie, même aux plus fortes pluies. [^6] Il met un sceau sur la main de tous les hommes,Afin que tous se reconnaissent comme ses créatures. [^7] L’animal sauvage se retire dans une caverne,Et se couche dans sa tanière. [^8] L’ouragan vient du midi,Et le froid, des vents du nord. [^9] #    
        Job 38:29, 30. Ps 147:17, 18.  Par son souffle Dieu produit la glace,Il réduit l’espace où se répandaient les eaux. [^10] Il charge de vapeurs les nuages,Il les disperse étincelants; [^11] Leurs évolutions varient selon ses desseins,Pour l’accomplissement de tout ce qu’il leur ordonne,Sur la face de la terre habitée; [^12] C’est comme une verge dont il frappe sa terre,Ou comme #Ex 9:18, 23. 1 S 12:18, 19. Esd 10:9. Job 36:31.un signe de son amour, qu’il les fait apparaître. [^13] Job, sois attentif à ces choses!Considère encore les merveilles de Dieu! [^14] Sais-tu comment Dieu les dirige,Et fait briller son nuage étincelant? [^15] Comprends-tu le balancement des nuées,Les merveilles de celui dont la science est parfaite? [^16] Sais-tu pourquoi tes vêtements sont chaudsQuand la terre se repose par le vent du midi? [^17] #    
        Ge 1:6.  Peux-tu comme lui étendre les cieux,Aussi solides qu’un miroir de fonte? [^18] Fais-nous connaître ce que nous devons lui dire;Nous sommes trop ignorants pour nous adresser à lui. [^19] Lui annoncera-t-on que je parlerai?Mais quel est l’homme qui désire sa perte? [^20] On ne peut fixer le soleil qui resplendit dans les cieux,Lorsqu’un vent passe et en ramène la pureté; [^21] Le septentrion le rend éclatant comme l’or.Oh! Que la majesté de Dieu est redoutable! [^22] Nous ne saurions parvenir jusqu’au Tout-Puissant,#    
        Job 9:4; 12:13, 16; 36:5. Ps 99:4.  Grand par la force,Par la justice, par le droit souverain:Il ne répond pas! [^23] C’est pourquoi les hommes doivent le craindre;Il ne porte les regards sur aucun sage. [^24] 

[[Job - 36|<--]] Job - 37 [[Job - 38|-->]]

---
# Notes
