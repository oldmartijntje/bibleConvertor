---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 21 - Luis Segond (1910)"
---
[[Job - 20|<--]] Job - 21 [[Job - 22|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 21

Job prit la parole et dit: [^1] Écoutez, écoutez mes paroles,Donnez-moi seulement cette consolation. [^2] Laissez-moi parler, je vous prie;Et, quand j’aurai parlé, tu pourras te moquer. [^3] Est-ce contre un homme que se dirige ma plainte?Et pourquoi mon âme ne serait-elle pas impatiente? [^4] Regardez-moi, soyez étonnés,Et mettez la main sur la bouche. [^5] Quand j’y pense, cela m’épouvante,Et un tremblement saisit mon corps. [^6] #    
        Ps 17:10; 73:12. Jé 12:1. Ha 1:16.  Pourquoi les méchants vivent-ils?Pourquoi les voit-on vieillir et accroître leur force? [^7] Leur postérité s’affermit avec eux et en leur présence,Leurs rejetons prospèrent sous leurs yeux. [^8] Dans leurs maisons règne la paix, sans mélange de crainte;La verge de Dieu ne vient pas les frapper. [^9] Leurs taureaux sont vigoureux et féconds,Leurs génisses conçoivent et n’avortent point. [^10] Ils laissent courir leurs enfants comme des brebis,Et les enfants prennent leurs ébats. [^11] Ils chantent au son du tambourin et de la harpe,Ils se réjouissent au son du chalumeau. [^12] Ils passent leurs jours dans le bonheur,Et ils descendent en un instant au séjour des morts. [^13] #    
        Job 22:17.  Ils disaient pourtant à Dieu: Retire-toi de nous;Nous ne voulons pas connaître tes voies. [^14] #    
        Ex 5:2. Mal 3:14.  Qu’est-ce que le Tout-Puissant, pour que nous le servions?Que gagnerons-nous à lui adresser nos prières? [^15] Quoi donc! Ne sont-ils pas en possession du bonheur?#    
        Job 22:18.  Loin de moi le conseil des méchants! [^16] Mais arrive-t-il souvent que leur lampe s’éteigne,Que la misère fonde sur eux,#    
        Job 20:29. Ps 11:6, 7.  Que Dieu leur distribue leur part dans sa colère, [^17] Qu’ils soient comme la paille emportée par le vent,Comme la balle enlevée par le tourbillon? [^18] Est-ce pour les fils que Dieu réserve le châtiment du père?Mais c’est lui que Dieu devrait punir, pour qu’il le sente; [^19] C’est lui qui devrait contempler sa propre ruine,C’est lui qui devrait boire la colère du Tout-Puissant. [^20] Car, que lui importe sa maison après lui,Quand le nombre de ses mois est achevé? [^21] #    
        És 40:13. Ro 11:34. 1 Co 2:16.  Est-ce à Dieu qu’on donnera de la science,A lui qui gouverne les esprits célestes? [^22] L’un meurt au sein du bien-être,De la paix et du bonheur, [^23] Les flancs chargés de graisseEt la mœlle des os remplie de sève; [^24] L’autre meurt, l’amertume dans l’âme,Sans avoir joui d’aucun bien. [^25] Et tous deux se couchent dans la poussière,#    
        Job 17:14.  Tous deux deviennent la pâture des vers. [^26] Je sais bien quelles sont vos pensées,Quels jugements iniques vous portez sur moi. [^27] Vous dites: Où est la maison de l’homme puissant?Où est la tente qu’habitaient les impies? [^28] Mais quoi! N’avez-vous point interrogé les voyageurs,Et voulez-vous méconnaître ce qu’ils prouvent? [^29] #    
        Pr 16:4.  Au jour du malheur, le méchant est épargné;Au jour de la colère, il échappe. [^30] Qui lui reproche en face sa conduite?Qui lui rend ce qu’il a fait? [^31] Il est porté dans un sépulcre,Et il veille encore sur sa tombe. [^32] Les mottes de la vallée lui sont légères;Et tous après lui suivront la même voie,Comme une multitude l’a déjà suivie. [^33] Pourquoi donc m’offrir de vaines consolations?Ce qui reste de vos réponses n’est que perfidie. [^34] 

[[Job - 20|<--]] Job - 21 [[Job - 22|-->]]

---
# Notes
