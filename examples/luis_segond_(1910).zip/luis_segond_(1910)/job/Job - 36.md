---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 36 - Luis Segond (1910)"
---
[[Job - 35|<--]] Job - 36 [[Job - 37|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 36

Élihu continua et dit: [^1] Attends un peu, et je vais poursuivre,Car j’ai des paroles encore pour la cause de Dieu. [^2] Je prendrai mes raisons de haut,Et je prouverai la justice de mon créateur. [^3] Sois-en sûr, mes discours ne sont pas des mensonges,Mes sentiments devant toi sont sincères. [^4] #    
        Job 9:4; 12:13, 16; 37:23; 38:23.  Dieu est puissant, mais il ne rejette personne;Il est puissant par la force de son intelligence. [^5] Il ne laisse pas vivre le méchant,Et il fait droit aux malheureux. [^6] #    
        Ps 33:18; 34:16.  Il ne détourne pas les yeux de dessus les justes,Il les place sur le trône avec les rois,#    
        Ps 113:8.  Il les y fait asseoir pour toujours, afin qu’ils soient élevés. [^7] Viennent-ils à tomber dans les chaînes,Sont-ils pris dans les liens de l’adversité, [^8] Il leur dénonce leurs œuvres,Leurs transgressions, leur orgueil; [^9] Il les avertit pour leur instruction,Il les exhorte à se détourner de l’iniquité. [^10] S’ils écoutent et se soumettent,Ils achèvent leurs jours dans le bonheur,Leurs années dans la joie. [^11] S’ils n’écoutent pas, ils périssent par le glaive,Ils expirent dans leur aveuglement. [^12] Les impies se livrent à la colère,Ils ne crient pas à Dieu quand il les enchaîne; [^13] #    
        Job 22:16.  Ils perdent la vie dans leur jeunesse,Ils meurent comme les débauchés. [^14] Mais Dieu sauve le malheureux dans sa misère,Et c’est par la souffrance qu’il l’avertit. [^15] Il te retirera aussi de la détresse,Pour te mettre au large, en pleine liberté,#    
        Ps 23:5.  Et ta table sera chargée de mets succulents. [^16] Mais si tu défends ta cause comme un impie,Le châtiment est inséparable de ta cause. [^17] Que l’irritation ne t’entraîne pas à la moquerie,Et que la grandeur de la rançon ne te fasse pas dévier! [^18] Tes cris suffiraient-ils pour te sortir d’angoisse,Et même toutes les forces que tu pourrais déployer? [^19] Ne soupire pas après la nuit,Qui enlève les peuples de leur place. [^20] Garde-toi de te livrer au mal,Car la souffrance t’y dispose. [^21] Dieu est grand par sa puissance;Qui saurait enseigner comme lui? [^22] #    
        Job 34:13.  Qui lui prescrit ses voies?Qui ose dire: #De 32:4. 2 Ch 19:7. Job 8:3; 34:10. Ro 9:14.Tu fais mal? [^23] Souviens-toi d’exalter ses œuvres,Que célèbrent tous les hommes. [^24] Tout homme les contemple,Chacun les voit de loin. [^25] Dieu est grand, mais sa grandeur nous échappe,#    
        Ps 90:2; 92:9; 93:2; 102:13. És 63:16. La 5:19. Da 6:27. Hé 1:12.  Le nombre de ses années est impénétrable. [^26] Il attire à lui les gouttes d’eau,Il les réduit en vapeur et forme la pluie; [^27] Les nuages la laissent couler,Ils la répandent sur la foule des hommes. [^28] Et qui comprendra le déchirement de la nuée,Le fracas de sa tente? [^29] Voici, il étend autour de lui sa lumière,Et il se cache jusque dans les profondeurs de la mer. [^30] #    
        Job 37:13.  Par ces moyens il juge les peuples,Et il donne la nourriture avec abondance. [^31] Il prend la lumière dans sa main,Il la dirige sur ses adversaires. [^32] Il s’annonce par un grondement;Les troupeaux pressentent son approche. [^33] 

[[Job - 35|<--]] Job - 36 [[Job - 37|-->]]

---
# Notes
