---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 28 - Luis Segond (1910)"
---
[[Job - 27|<--]] Job - 28 [[Job - 29|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 28

Il y a pour l’argent une mine d’où on le fait sortir,Et pour l’or un lieu d’où on l’extrait pour l’affiner; [^1] Le fer se tire de la poussière,Et la pierre se fond pour produire l’airain. [^2] L’homme fait cesser les ténèbres;Il explore, jusque dans les endroits les plus profonds,Les pierres cachées dans l’obscurité et dans l’ombre de la mort. [^3] Il creuse un puits loin des lieux habités;Ses pieds ne lui sont plus en aide,Et il est suspendu, balancé, loin des humains. [^4] La terre, d’où sort le pain,Est bouleversée dans ses entrailles comme par le feu. [^5] Ses pierres contiennent du saphir,Et l’on y trouve de la poudre d’or. [^6] L’oiseau de proie n’en connaît pas le sentier,L’œil du vautour ne l’a point aperçu; [^7] Les plus fiers animaux ne l’ont point foulé,Le lion n’y a jamais passé. [^8] L’homme porte sa main sur le roc,Il renverse les montagnes depuis la racine; [^9] Il ouvre des tranchées dans les rochers,Et son œil contemple tout ce qu’il y a de précieux; [^10] Il arrête l’écoulement des eaux,Et il produit à la lumière ce qui est caché. [^11] Mais la sagesse, où se trouve-t-elle?Où est la demeure de l’intelligence? [^12] L’homme n’en connaît point le prix;Elle ne se trouve pas dans la terre des vivants. [^13] #    
        Job 28:22.  L’abîme dit: Elle n’est point en moi;Et la mer dit: Elle n’est point avec moi. [^14] #    
        Pr 3:14; 8:11, 19; 16:16.  Elle ne se donne pas contre de l’or pur,Elle ne s’achète pas au poids de l’argent; [^15] Elle ne se pèse pas contre l’or d’Ophir,Ni contre le précieux onyx, ni contre le saphir; [^16] Elle ne peut se comparer à l’or ni au verre,Elle ne peut s’échanger pour un vase d’or fin. [^17] Le corail et le cristal ne sont rien auprès d’elle:La sagesse vaut plus que les perles. [^18] La topaze d’Éthiopie n’est point son égale,Et l’or pur n’entre pas en balance avec elle. [^19] #    
        Job 28:12.  D’où vient donc la sagesse?Où est la demeure de l’intelligence? [^20] Elle est cachée aux yeux de tout vivant,Elle est cachée aux oiseaux du ciel. [^21] #    
        Job 28:14.  Le gouffre et la mort disent:Nous en avons entendu parler. [^22] C’est Dieu qui en sait le chemin,C’est lui qui en connaît la demeure; [^23] Car il voit jusqu’aux extrémités de la terre,Il aperçoit tout sous les cieux. [^24] Quand il régla le poids du vent,#    
        Pr 8:29.  Et qu’il fixa la mesure des eaux, [^25] Quand il donna des lois à la pluie,Et qu’il traça la route de l’éclair et du tonnerre, [^26] Alors il vit la sagesse et la manifesta,Il en posa les fondements et la mit à l’épreuve. [^27] Puis il dit à l’homme:Voici, #Ps 111:10. Pr 1:7; 9:10.la crainte du Seigneur, c’est la sagesse;S’éloigner du mal, c’est l’intelligence. [^28] 

[[Job - 27|<--]] Job - 28 [[Job - 29|-->]]

---
# Notes
