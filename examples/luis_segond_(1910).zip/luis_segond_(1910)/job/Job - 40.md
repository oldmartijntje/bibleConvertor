---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 40 - Luis Segond (1910)"
---
[[Job - 39|<--]] Job - 40 [[Job - 41|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Job]]

# Job - 40

L’Éternel répondit à Job du milieu de la tempête et dit: [^1] Ceins tes reins comme un vaillant homme;Je t’interrogerai, et tu m’instruiras. [^2] #    
        Ps 51:6. Ro 3:4.  Anéantiras-tu jusqu’à ma justice?Me condamneras-tu pour te donner droit? [^3] As-tu un bras comme celui de Dieu,Une voix tonnante comme la sienne? [^4] Orne-toi de magnificence et de grandeur,Revêts-toi de splendeur et de gloire! [^5] Répands les flots de ta colère,Et d’un regard abaisse les hautains! [^6] D’un regard humilie les hautains,Écrase sur place les méchants, [^7] Cache-les tous ensemble dans la poussière,Enferme leur front dans les ténèbres! [^8] Alors je rends hommageA la puissance de ta droite. [^9] Voici l’hippopotame, à qui j’ai donné la vie comme à toi!Il mange de l’herbe comme le bœuf. [^10] Le voici! Sa force est dans ses reins,Et sa vigueur dans les muscles de son ventre; [^11] Il plie sa queue aussi ferme qu’un cèdre;Les nerfs de ses cuisses sont entrelacés; [^12] Ses os sont des tubes d’airain,Ses membres sont comme des barres de fer. [^13] Il est la première des œuvres de Dieu;Celui qui l’a fait l’a pourvu d’un glaive. [^14] Il trouve sa pâture dans les montagnes,Où se jouent toutes les bêtes des champs. [^15] Il se couche sous les lotus,Au milieu des roseaux et des marécages; [^16] Les lotus le couvrent de leur ombre,Les saules du torrent l’environnent. [^17] Que le fleuve vienne à déborder, il ne s’enfuit pas:Que le Jourdain se précipite dans sa gueule, il reste calme. [^18] Est-ce à force ouverte qu’on pourra le saisir?Est-ce au moyen de filets qu’on lui percera le nez? [^19] Prendras-tu le crocodile à l’hameçon?Saisiras-tu sa langue avec une corde? [^20] Mettras-tu un jonc dans ses narines?Lui perceras-tu la mâchoire avec un crochet? [^21] Te pressera-t-il de supplication?Te parlera-t-il d’une voix douce? [^22] Fera-t-il une alliance avec toi,Pour devenir à toujours ton esclave? [^23] Joueras-tu avec lui comme avec un oiseau?L’attacheras-tu pour amuser tes jeunes filles? [^24] Les pêcheurs en trafiquent-ils?Le partagent-ils entre les marchands? [^25] Couvriras-tu sa peau de dards,Et sa tête de harpons? [^26] Dresse ta main contre lui,Et tu ne t’aviseras plus de l’attaquer. [^27] Voici, on est trompé dans son attente;A son seul aspect n’est-on pas terrassé? [^28] 

[[Job - 39|<--]] Job - 40 [[Job - 41|-->]]

---
# Notes
