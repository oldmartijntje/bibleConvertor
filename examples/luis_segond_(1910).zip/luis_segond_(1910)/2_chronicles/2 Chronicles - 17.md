---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 17 - Luis Segond (1910)"
---
[[2 Chronicles - 16|<--]] 2 Chronicles - 17 [[2 Chronicles - 18|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 17

#    
        1 R 15:24.  Josaphat, son fils, régna à sa place. [^1] Il se fortifia contre Israël: il mit des troupes dans toutes les villes fortes de Juda, et des garnisons dans le pays de Juda et #2 Ch 15:8.dans les villes d’Éphraïm dont Asa, son père, s’était emparé. [^2] L’Éternel fut avec Josaphat, parce qu’il marcha dans les premières voies de David, son père, et qu’il ne rechercha point les Baals; [^3] car il eut recours au Dieu de son père, et il suivit ses commandements, sans imiter ce que faisait Israël. [^4] L’Éternel affermit la royauté entre les mains de Josaphat, à qui tout Juda apportait des présents, et qui eut en abondance des richesses et de la gloire. [^5] Son cœur grandit dans les voies de l’Éternel, et il fit encore disparaître de Juda les hauts lieux et les idoles. [^6] La troisième année de son règne, il chargea ses chefs Ben-Haïl, Abdias, Zacharie, Nethaneel et Michée, d’aller enseigner dans les villes de Juda. [^7] Il envoya avec eux les Lévites Schemaeja, Nethania, Zebadia, Asaël, Schemiramoth, Jonathan, Adonija, Tobija et Tob-Adonija, Lévites, et les sacrificateurs Élischama et Joram. [^8] Ils enseignèrent dans Juda, ayant avec eux le livre de la loi de l’Éternel. Ils parcoururent toutes les villes de Juda, et ils enseignèrent parmi le peuple. [^9] La terreur de l’Éternel s’empara de tous les royaumes des pays qui environnaient Juda, et ils ne firent point la guerre à Josaphat. [^10] Des Philistins apportèrent à Josaphat des présents et un tribut en argent; et les Arabes lui amenèrent aussi du bétail, sept mille sept cents béliers et sept mille sept cents boucs. [^11] Josaphat s’élevait au plus haut degré de grandeur. Il bâtit en Juda des châteaux et des villes pour servir de magasins. [^12] Il fit exécuter beaucoup de travaux dans les villes de Juda, et il avait à Jérusalem de vaillants hommes pour soldats. [^13] Voici leur dénombrement, selon les maisons de leurs pères. De Juda, chefs de milliers: Adna, le chef, avec trois cent mille vaillants hommes; [^14] et à ses côtés, Jochanan, le chef, avec deux cent quatre-vingt mille hommes; [^15] et à ses côtés, Amasia, fils de Zicri, qui s’était volontairement consacré à l’Éternel, avec deux cent mille vaillants hommes. [^16] De Benjamin: Éliada, vaillant homme, avec deux cent mille hommes armés de l’arc et du bouclier, [^17] et à ses côtés, Zozabad, avec cent quatre-vingt mille hommes armés pour la guerre. [^18] Tels sont ceux qui étaient au service du roi, outre ceux que le roi avait placés dans toutes les villes fortes de Juda. [^19] 

[[2 Chronicles - 16|<--]] 2 Chronicles - 17 [[2 Chronicles - 18|-->]]

---
# Notes
