---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 2 - Luis Segond (1910)"
---
[[2 Chronicles - 1|<--]] 2 Chronicles - 2 [[2 Chronicles - 3|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 2

Salomon ordonna que l’on bâtît une maison au nom de l’Éternel et une maison royale pour lui. [^1] Salomon compta soixante-dix mille hommes pour porter les fardeaux, quatre-vingt mille pour tailler les pierres dans la montagne, et #1 R 5:16.trois mille six cents pour les surveiller. [^2] Salomon #1 R 5:2.envoya dire à Huram, roi de Tyr: Fais pour moi comme tu as fait pour David, mon père, à qui tu as envoyé des cèdres afin qu’il se bâtît une maison d’habitation. [^3] Voici, j’élève une maison au nom de l’Éternel, mon Dieu, pour la lui consacrer, pour brûler devant lui le parfum odoriférant, pour présenter continuellement les pains de proposition, et #No 28:9, 10, 11.pour offrir les holocaustes du matin et du soir, des sabbats, des nouvelles lunes, et des fêtes de l’Éternel, notre Dieu, suivant une loi perpétuelle pour Israël. [^4] La maison que je vais bâtir doit être grande, car notre Dieu est plus grand que tous les dieux. [^5] Mais qui a le pouvoir de lui bâtir une maison, #1 R 8:27. 2 Ch 6:18. Job 11:7, 8, 9. És 66:1. Jé 23:24. Mt 5:34, 35. Ac 7:49; 17:24.puisque les cieux et les cieux des cieux ne peuvent le contenir? Et qui suis-je pour lui bâtir une maison, si ce n’est pour faire brûler des parfums devant lui? [^6] Envoie-moi donc un homme habile pour les ouvrages en or, en argent, en airain et en fer, en étoffes teintes en pourpre, en cramoisi et en bleu, et connaissant la sculpture, afin qu’il travaille avec les hommes habiles qui sont auprès de moi en Juda et à Jérusalem et que David, mon père, a choisis. [^7] Envoie-moi aussi du Liban des bois de cèdre, de cyprès et de sandal; car je sais que tes serviteurs s’entendent à couper les bois du Liban. Voici, mes serviteurs seront avec les tiens. [^8] Que l’on me prépare du bois en abondance, car la maison que je vais bâtir sera grande et magnifique. [^9] Je donnerai à tes serviteurs qui couperont, qui abattront les bois, vingt mille cors de froment foulé, vingt mille cors d’orge, vingt mille baths de vin, et vingt mille baths d’huile. [^10] Huram, roi de Tyr, répondit dans une lettre qu’il envoya à Salomon: C’est parce que l’Éternel aime son peuple qu’il t’a établi roi sur eux. [^11] Huram dit encore: Béni soit l’Éternel, le Dieu d’Israël, #Ge 1:2. Ex 20:11. Ps 33:6; 96:5; 102:26; 124:8; 136:5, 6. Ac 4:24; 14:15. Ac 10:6.qui a fait les cieux et la terre, de ce qu’il a donné au roi David un fils sage, prudent et intelligent, qui va bâtir une maison à l’Éternel et une maison royale pour lui! [^12] Je t’envoie donc un homme habile et intelligent, [^13] Huram-Abi, fils d’une femme d’entre les filles de Dan, et d’un père Tyrien. Il est habile pour les ouvrages en or, en argent, en airain et en fer, en pierre et en bois, en étoffes teintes en pourpre et en bleu, en étoffes de byssus et de carmin, et pour toute espèce de sculptures et d’objets d’art qu’on lui donne à exécuter. Il travaillera avec tes hommes habiles et avec les hommes habiles de mon seigneur David, ton père. [^14] Maintenant, que mon seigneur envoie à ses serviteurs le froment, l’orge, l’huile et le vin #v. 10.dont il a parlé. [^15] Et nous, nous couperons des bois du Liban autant que tu en auras besoin; nous te les expédierons par mer en radeaux jusqu’à Japho, et tu les feras monter à Jérusalem. [^16] #1 R 5:15.Salomon compta tous les étrangers qui étaient dans le pays d’Israël, et dont le dénombrement avait #1 Ch 22:2.été fait par David, son père. On en trouva cent cinquante-trois mille six cents. [^17] Et il en prit soixante-dix mille pour porter les fardeaux, quatre-vingt mille pour tailler les pierres dans la montagne, et trois mille six cents pour surveiller et faire travailler le peuple. [^18] 

[[2 Chronicles - 1|<--]] 2 Chronicles - 2 [[2 Chronicles - 3|-->]]

---
# Notes
