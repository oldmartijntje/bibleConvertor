---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 22 - Luis Segond (1910)"
---
[[2 Chronicles - 21|<--]] 2 Chronicles - 22 [[2 Chronicles - 23|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 22

#    2 R 8:24, 25, etc.  Les habitants de Jérusalem firent régner à sa place Achazia, son plus jeune fils; car la troupe venue au camp avec les Arabes avait tué tous les plus âgés. Ainsi régna Achazia, fils de Joram, roi de Juda. [^1] Achazia avait quarante-deux ans lorsqu’il devint roi, et il régna un an à Jérusalem. Sa mère s’appelait Athalie, fille d’Omri. [^2] Il marcha dans les voies de la maison d’Achab, car sa mère lui donnait des conseils impies. [^3] Il fit ce qui est mal aux yeux de l’Éternel, comme la maison d’Achab, où il eut après la mort de son père des conseillers pour sa perte. [^4] Entraîné par leur conseil, #2 R 8:26.il alla avec Joram, fils d’Achab, roi d’Israël, à la guerre contre Hazaël, roi de Syrie, à Ramoth en Galaad. Et les Syriens blessèrent Joram. [^5] Joram s’en retourna pour se faire guérir à Jizreel des blessures que les Syriens lui avaient faites à Rama, lorsqu’il se battait contre Hazaël, roi de Syrie. Azaria, fils de Joram, roi de Juda, descendit pour voir Joram, fils d’Achab, à Jizreel, parce qu’il était malade. [^6] Par la volonté de Dieu, ce fut pour sa ruine qu’Achazia se rendit auprès de Joram. Lorsqu’il fut arrivé, il sortit avec Joram pour aller au-devant de Jéhu, fils de Nimschi, que l’Éternel avait oint pour exterminer la maison d’Achab. [^7] Et comme Jéhu faisait justice de la maison d’Achab, il trouva les chefs de Juda et les fils des frères d’Achazia, qui étaient au service d’Achazia, #2 R 10:14.et il les tua. [^8] #2 R 9:27.Il chercha Achazia, et on le saisit dans Samarie, où il s’était caché. On l’amena auprès de Jéhu, et on le fit mourir. Puis ils l’enterrèrent, car ils disaient: C’est le fils de Josaphat, qui cherchait l’Éternel de tout son cœur. Et il ne resta personne de la maison d’Achazia qui fût en état de régner. [^9] Athalie, mère d’Achazia, voyant que son fils était mort, se leva et fit périr toute la race royale de la maison de Juda. [^10] Mais Joschabeath, fille du roi, prit Joas, fils d’Achazia, et l’enleva du milieu des fils du roi, quand on les fit mourir: elle le mit avec sa nourrice dans la chambre des lits. Ainsi Joschabeath, fille du roi Joram, femme du sacrificateur Jehojada, et sœur d’Achazia, le déroba aux regards d’Athalie, qui ne le fit point mourir. [^11] Il resta six ans caché avec eux dans la maison de Dieu. Et c’était Athalie qui régnait dans le pays. [^12] 

[[2 Chronicles - 21|<--]] 2 Chronicles - 22 [[2 Chronicles - 23|-->]]

---
# Notes
