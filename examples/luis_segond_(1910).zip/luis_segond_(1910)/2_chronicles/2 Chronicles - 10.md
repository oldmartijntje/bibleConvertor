---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 10 - Luis Segond (1910)"
---
[[2 Chronicles - 9|<--]] 2 Chronicles - 10 [[2 Chronicles - 11|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 10

#    1 R 12:1, etc.  Roboam se rendit à Sichem, car tout Israël était venu à Sichem pour le faire roi. [^1] Lorsque Jéroboam, fils de Nebath, eut des nouvelles, #1 R 11:40.il était en Égypte, où il s’était enfui loin du roi Salomon, et il revint d’Égypte. [^2] On l’envoya appeler. Alors Jéroboam et tout Israël vinrent vers Roboam et lui parlèrent ainsi: [^3] Ton père a rendu notre joug dur; maintenant allège cette rude servitude et le joug pesant que nous a imposé ton père. Et nous te servirons. [^4] Il leur dit: Revenez vers moi dans trois jours. Et le peuple s’en alla. [^5] Le roi Roboam consulta les vieillards qui avaient été auprès de Salomon, son père, pendant sa vie, et il dit: Que conseillez-vous de répondre à ce peuple? [^6] Et voici ce qu’ils lui dirent: Si tu es bon envers ce peuple, si tu les reçois favorablement, et si tu leur parles avec bienveillance, ils seront pour toujours tes serviteurs. [^7] Mais Roboam laissa le conseil que lui donnaient les vieillards, et il consulta les jeunes gens qui avaient grandi avec lui et qui l’entouraient. [^8] Il leur dit: Que conseillez-vous de répondre à ce peuple qui me tient ce langage: Allège le joug que nous a imposé ton père? [^9] Et voici ce que lui dirent les jeunes gens qui avaient grandi avec lui: Tu parleras ainsi à ce peuple qui t’a tenu ce langage: Ton père a rendu notre joug pesant, et toi, allège-le-nous! Tu leur parleras ainsi: Mon petit doigt est plus gros que les reins de mon père. [^10] Maintenant, mon père vous a chargés d’un joug pesant, et moi je vous le rendrai plus pesant; mon père vous a châtiés avec des fouets, et moi je vous châtierai avec des scorpions. [^11] Jéroboam et tout le peuple vinrent à Roboam le troisième jour, suivant ce qu’avait dit le roi: Revenez vers moi dans trois jours. [^12] Le roi leur répondit durement. Le roi Roboam laissa le conseil des vieillards, [^13] et leur parla ainsi d’après le conseil des jeunes gens: Mon père a rendu votre joug pesant, et moi je le rendrai plus pesant; mon père vous a châtiés avec des fouets, et moi je vous châtierai avec des scorpions. [^14] Ainsi le roi n’écouta point le peuple; car cela fut dirigé par Dieu, en vue de l’accomplissement de la parole #1 R 11:31.que l’Éternel avait dite par Achija de Silo à Jéroboam, fils de Nebath. [^15] Lorsque tout Israël vit que le roi ne l’écoutait pas, le peuple répondit au roi: Quelle part avons-nous avec David? Nous n’avons point d’héritage avec le fils d’Isaï! A tes tentes, Israël! Maintenant, pourvois à ta maison, David! Et tout Israël s’en alla dans ses tentes. [^16] Les enfants d’Israël qui habitaient les villes de Juda furent les seuls sur qui régna Roboam. [^17] Alors le roi Roboam envoya Hadoram, qui était préposé aux impôts. Mais Hadoram fut lapidé par les enfants d’Israël, et il mourut. Et le roi Roboam se hâta de monter sur un char, pour s’enfuir à Jérusalem. [^18] C’est ainsi qu’Israël s’est détaché de la maison de David jusqu’à ce jour. [^19] 

[[2 Chronicles - 9|<--]] 2 Chronicles - 10 [[2 Chronicles - 11|-->]]

---
# Notes
