---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 8 - Luis Segond (1910)"
---
[[2 Chronicles - 7|<--]] 2 Chronicles - 8 [[2 Chronicles - 9|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 8

#    
        1 R 9:10.  Au bout de vingt ans, pendant lesquels Salomon bâtit la maison de l’Éternel et sa propre maison, [^1] il reconstruisit les villes que lui donna Huram et y établit des enfants d’Israël. [^2] Salomon marcha contre Hamath, vers Tsoba, et s’en empara. [^3] Il bâtit Thadmor au désert, et toutes les villes servant de magasins en Hamath. [^4] Il bâtit Beth-Horon la haute et Beth-Horon la basse, villes fortes, ayant des murs, des portes et des barres; [^5] Baalath, et toutes les villes servant de magasins et lui appartenant, toutes les villes pour les chars, les villes pour la cavalerie, #1 R 9:1.et tout ce qu’il plut à Salomon de bâtir à Jérusalem, au Liban, et dans tout le pays dont il était le souverain. [^6] Tout le peuple qui était resté des Héthiens, des Amoréens, des Phéréziens, des Héviens et des Jébusiens, ne faisant point partie d’Israël, [^7] leurs descendants qui étaient restés après eux dans le pays et que les enfants d’Israël n’avaient pas détruits, Salomon les leva comme gens de corvée, ce qu’ils ont été jusqu’à ce jour. [^8] #1 R 9:22.Salomon n’employa comme esclave pour ses travaux aucun des enfants d’Israël; car ils étaient des hommes de guerre, ses chefs, ses officiers, les commandants de ses chars et de sa cavalerie. [^9] Les chefs placés par le roi Salomon à la tête du peuple, et chargés de le surveiller, étaient au nombre de deux cent cinquante. [^10] #1 R 3:1; 7:8; 9:24.Salomon fit monter la fille de Pharaon de la cité de David dans la maison qu’il lui avait bâtie; car il dit: Ma femme n’habitera pas dans la maison de David, roi d’Israël, parce que les lieux où est entrée l’arche de l’Éternel sont saints. [^11] Alors Salomon offrit des holocaustes à l’Éternel sur l’autel de l’Éternel, qu’il avait construit devant le portique. [^12] Il offrait ce qui était prescrit par Moïse pour chaque jour, pour les sabbats, pour les nouvelles lunes, et pour les fêtes, #Ex 23:14, 15. De 16:16.trois fois l’année, à la fête des pains sans levain, à la fête des semaines, et à la fête des tabernacles. [^13] Il établit dans leurs fonctions, telles que les avait réglées David, son père, les classes des sacrificateurs selon leur office, les Lévites selon leur charge, consistant à célébrer l’Éternel et à faire jour par jour le service en présence des sacrificateurs, et les #1 Ch 9:17.portiers distribués à chaque porte d’après leurs classes; car ainsi l’avait ordonné David, homme de Dieu. [^14] On ne s’écarta point de l’ordre du roi pour les sacrificateurs et les Lévites, ni pour aucune chose, ni pour ce qui concernait les trésors. [^15] Ainsi fut dirigée toute l’œuvre de Salomon, jusqu’au jour où la maison de l’Éternel fut fondée et jusqu’à celui où elle fut terminée. La maison de l’Éternel fut donc achevée. [^16] Salomon partit alors pour Étsjon-Guéber et pour Éloth, sur les bords de la mer, dans le pays d’Édom. [^17] Et Huram lui envoya par ses serviteurs des navires et des serviteurs connaissant la mer. Ils allèrent avec les serviteurs de Salomon à Ophir, et ils y prirent quatre cent cinquante talents d’or, qu’ils apportèrent au roi Salomon. [^18] 

[[2 Chronicles - 7|<--]] 2 Chronicles - 8 [[2 Chronicles - 9|-->]]

---
# Notes
