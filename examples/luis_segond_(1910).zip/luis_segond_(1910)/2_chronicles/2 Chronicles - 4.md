---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 4 - Luis Segond (1910)"
---
[[2 Chronicles - 3|<--]] 2 Chronicles - 4 [[2 Chronicles - 5|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 4

Il fit un autel d’airain, long de vingt coudées, large de vingt coudées, et haut de dix coudées. [^1] Il fit la mer de fonte. Elle avait dix coudées d’un bord à l’autre, une forme entièrement ronde, cinq coudées de hauteur, et une circonférence que mesurait un cordon de trente coudées. [^2] Des figures de bœufs l’entouraient au-dessous de son bord, dix par coudée, faisant tout le tour de la mer; les bœufs, disposés sur deux rangs, étaient fondus avec elle en une seule pièce. [^3] Elle était posée sur douze bœufs, dont trois tournés vers le nord, trois tournés vers l’occident, trois tournés vers le midi, et trois tournés vers l’orient; la mer était sur eux, et toute la partie postérieure de leur corps était en dedans. [^4] Son épaisseur était d’un palme; et son bord, semblable au bord d’une coupe, était façonné en fleur de lis. Elle pouvait contenir trois mille baths. [^5] Il fit dix bassins, et il en plaça cinq à droite et cinq à gauche, pour qu’ils servissent aux purifications: on y lavait les diverses parties des holocaustes. La mer était destinée aux ablutions des sacrificateurs. [^6] Il fit #1 R 7:48, 49.dix chandeliers d’or, selon l’ordonnance qui les concernait, et il les plaça dans le temple, cinq à droite et cinq à gauche. [^7] Il fit dix tables, et il les plaça dans le temple, cinq à droite et cinq à gauche. Il fit cent coupes d’or. [^8] Il fit le parvis des sacrificateurs, et le grand parvis avec ses portes, dont il couvrit d’airain les battants. [^9] Il plaça la mer du côté droit, au sud-est. [^10] Huram fit les cendriers, les pelles et les coupes. Ainsi Huram acheva l’ouvrage que le roi Salomon lui fit faire pour la maison de Dieu: [^11] deux colonnes, avec les deux chapiteaux et leurs bourrelets sur le sommet des colonnes; les deux treillis, pour couvrir les deux bourrelets des chapiteaux sur le sommet des colonnes; [^12] les quatre cents grenades pour les deux treillis, deux rangées de grenades par treillis, pour couvrir les deux bourrelets des chapiteaux sur le sommet des colonnes; [^13] les dix bases, et les dix bassins sur les bases; [^14] la mer, et les douze bœufs sous elle; [^15] les cendriers, les pelles et les fourchettes. Tous ces ustensiles que le roi Salomon fit faire à Huram-Abi pour la maison de l’Éternel étaient d’airain poli. [^16] Le roi les fit fondre dans la plaine du Jourdain, dans un sol argileux, entre Succoth et Tseréda. [^17] Salomon fit tous ces ustensiles en si grande quantité que l’on ne vérifia pas le poids de l’airain. [^18] #1 R 7:48.Salomon fit encore tous les autres ustensiles pour la maison de Dieu: l’autel d’or; les tables sur lesquelles on mettait les pains de proposition; [^19] les chandeliers et leurs lampes d’or pur, qu’on devait allumer selon l’ordonnance devant le sanctuaire, [^20] les fleurs, les lampes et les mouchettes d’or, d’or très pur; [^21] les couteaux, les coupes, les tasses et les brasiers d’or pur; et les battants d’or pour la porte de l’intérieur de la maison à l’entrée du lieu très saint, et pour la porte de la maison à l’entrée du temple. [^22] 

[[2 Chronicles - 3|<--]] 2 Chronicles - 4 [[2 Chronicles - 5|-->]]

---
# Notes
