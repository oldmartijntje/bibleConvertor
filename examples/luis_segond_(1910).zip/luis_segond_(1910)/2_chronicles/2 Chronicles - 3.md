---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 3 - Luis Segond (1910)"
---
[[2 Chronicles - 2|<--]] 2 Chronicles - 3 [[2 Chronicles - 4|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 3

Salomon commença à bâtir la maison de l’Éternel à Jérusalem, sur la montagne de Morija, qui #1 Ch 21:24, 26.avait été indiquée à David, son père, dans le lieu préparé par David sur l’aire d’Ornan, le Jébusien. [^1] Il #1 R 6:1.commença à bâtir le second jour du second mois de la quatrième année de son règne. [^2] Voici sur quels fondements Salomon bâtit la maison de Dieu. La longueur en coudées de l’ancienne mesure était de soixante coudées, et la largeur de vingt coudées. [^3] Le portique sur le devant avait vingt coudées de longueur, répondant à la largeur de la maison, et cent vingt de hauteur; Salomon le couvrit intérieurement d’or pur. [^4] Il revêtit de bois de cyprès la grande maison, la couvrit d’or pur, et y fit sculpter des palmes et des chaînettes. [^5] Il couvrit la maison de pierres précieuses comme ornement; et l’or était de l’or de Parvaïm. [^6] Il couvrit d’or la maison, les poutres, les seuils, les parois et les battants des portes, et il fit sculpter des chérubins sur les parois. [^7] Il fit la maison du lieu très saint; elle avait vingt coudées de longueur répondant à la largeur de la maison, et vingt coudées de largeur. Il la couvrit d’or pur, pour une valeur de six cents talents; [^8] et le poids de l’or pour les clous montait à cinquante sicles. Il couvrit aussi d’or les chambres hautes. [^9] Il fit dans la maison du lieu très saint deux chérubins sculptés, et on les couvrit d’or. [^10] Les ailes des chérubins avaient vingt coudées de longueur. L’aile du premier, longue de cinq coudées, touchait au mur de la maison; et l’autre aile, longue de cinq coudées, touchait à l’aile du second chérubin. [^11] L’aile du second chérubin, longue de cinq coudées, touchait au mur de la maison; et l’autre aile, longue de cinq coudées, joignait l’aile du premier chérubin. [^12] Les ailes de ces chérubins, déployées, avaient vingt coudées. Ils étaient debout sur leurs pieds, la face tournée vers la maison. [^13] Il fit #Mt 27:51.le voile bleu, pourpre et cramoisi, et de byssus, et il y représenta des chérubins. [^14] Il fit devant la maison #1 R 7:15. Jé 52:21.deux colonnes de trente-cinq coudées de hauteur, avec un chapiteau de cinq coudées sur leur sommet. [^15] Il fit des chaînettes comme celles qui étaient dans le sanctuaire, et les plaça sur le sommet des colonnes, et il fit cent grenades qu’il mit dans les chaînettes. [^16] Il dressa les colonnes sur le devant du temple, l’une à droite et l’autre à gauche; il nomma celle de droite Jakin, et celle de gauche Boaz. [^17] 

[[2 Chronicles - 2|<--]] 2 Chronicles - 3 [[2 Chronicles - 4|-->]]

---
# Notes
