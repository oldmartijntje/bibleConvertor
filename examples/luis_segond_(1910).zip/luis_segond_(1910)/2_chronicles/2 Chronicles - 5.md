---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 5 - Luis Segond (1910)"
---
[[2 Chronicles - 4|<--]] 2 Chronicles - 5 [[2 Chronicles - 6|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 5

Ainsi fut achevé tout l’ouvrage que Salomon fit pour la maison de l’Éternel. Puis il apporta l’argent, l’or et tous les ustensiles que David, son père, avait consacrés, et il les mit dans les trésors de la maison de Dieu. [^1] Alors Salomon assembla à Jérusalem les anciens d’Israël et tous les chefs des tribus, les chefs de famille des enfants d’Israël, pour transporter de la cité de David, qui est Sion, l’arche de l’alliance de l’Éternel. [^2] Tous les hommes d’Israël se réunirent auprès du roi pour la fête, qui se célébra le septième mois. [^3] Lorsque tous les anciens d’Israël furent arrivés, les Lévites portèrent l’arche. [^4] Ils transportèrent l’arche, la tente d’assignation, et tous les ustensiles sacrés qui étaient dans la tente: ce furent les sacrificateurs et les Lévites qui les transportèrent. [^5] Le roi Salomon et toute l’assemblée d’Israël convoquée auprès de lui se tinrent devant l’arche. Ils sacrifièrent des brebis et des bœufs, qui ne purent être ni comptés, ni nombrés, à cause de leur multitude. [^6] Les sacrificateurs portèrent l’arche de l’alliance de l’Éternel à sa place, dans le sanctuaire de la maison, dans le lieu très saint, sous les ailes des chérubins. [^7] Les chérubins avaient les ailes étendues sur la place de l’arche, et ils couvraient l’arche et ses barres par-dessus. [^8] On avait donné aux barres une longueur telle que leurs extrémités se voyaient à distance de l’arche devant le sanctuaire, mais ne se voyaient point du dehors. L’arche a été là jusqu’à ce jour. [^9] Il n’y avait dans l’arche que les deux tables que Moïse y plaça en Horeb, lorsque l’Éternel fit alliance avec les enfants d’Israël, à leur sortie d’Égypte. [^10] Au moment où les sacrificateurs sortirent du lieu saint, car tous les sacrificateurs présents s’étaient sanctifiés sans observer l’ordre des classes, [^11] et tous les Lévites qui étaient chantres, Asaph, Héman, Jeduthun, leurs fils et leurs frères, revêtus de byssus, se tenaient à l’orient de l’autel avec des cymbales, des luths et des harpes, et avaient auprès d’eux cent vingt sacrificateurs sonnant des trompettes, [^12] et lorsque ceux qui sonnaient des trompettes et ceux qui chantaient, s’unissant d’un même accord pour célébrer et pour louer l’Éternel, firent retentir les trompettes, les cymbales et les autres instruments, et célébrèrent l’Éternel par ces paroles: Car il est bon, car sa miséricorde dure à toujours! En ce moment, la maison, la maison de l’Éternel fut remplie d’une nuée. [^13] Les sacrificateurs ne purent pas y rester pour faire le service, à cause de la nuée; car la gloire de l’Éternel remplissait la maison de Dieu. [^14] 

[[2 Chronicles - 4|<--]] 2 Chronicles - 5 [[2 Chronicles - 6|-->]]

---
# Notes
