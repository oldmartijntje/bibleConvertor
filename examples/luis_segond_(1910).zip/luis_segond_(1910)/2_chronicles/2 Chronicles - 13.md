---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 13 - Luis Segond (1910)"
---
[[2 Chronicles - 12|<--]] 2 Chronicles - 13 [[2 Chronicles - 14|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 13

#    1 R 15:1, etc.  La dix-huitième année du règne de Jéroboam, Abija régna sur Juda. [^1] Il régna trois ans à Jérusalem. Sa mère s’appelait Micaja, fille d’Uriel, de Guibea. Il y eut guerre entre Abija et Jéroboam. [^2] Abija engagea les hostilités avec une armée de vaillants guerriers, quatre cent mille hommes d’élite; et Jéroboam se rangea en bataille contre lui avec huit cent mille hommes d’élite, vaillants guerriers. [^3] Du haut du mont Tsemaraïm, qui fait partie de la montagne d’Éphraïm, Abija se leva et dit: Écoutez-moi, Jéroboam, et tout Israël! [^4] Ne devez-vous pas savoir que l’Éternel, le Dieu d’Israël, a donné pour toujours à David la royauté sur Israël, à lui et à ses fils, par une alliance inviolable? [^5] #1 R 11:26.Mais Jéroboam, fils de Nebath, serviteur de Salomon, fils de David, s’est levé et s’est révolté contre son maître. [^6] Des gens de rien, des hommes pervers, se sont rassemblés auprès de lui et l’ont emporté sur Roboam, fils de Salomon. Roboam était jeune et craintif, et il manqua de force devant eux. [^7] Et maintenant, vous pensez triompher du royaume de l’Éternel, qui est entre les mains des fils de David; et vous êtes une multitude nombreuse, et vous avez avec vous les veaux d’or #1 R 12:28, etc.que Jéroboam vous a faits pour dieux. [^8] #1 R 12:31. 2 Ch 11:14, 15.N’avez-vous pas repoussé les sacrificateurs de l’Éternel, les fils d’Aaron et les Lévites, et ne vous êtes-vous pas fait des sacrificateurs, comme les peuples des autres pays? Quiconque venait avec un jeune taureau et sept béliers, afin d’être consacré, devenait sacrificateur de ce qui n’est point Dieu. [^9] Mais pour nous, l’Éternel est notre Dieu, et nous ne l’avons point abandonné, les sacrificateurs au service de l’Éternel sont fils d’Aaron, et les Lévites remplissent leurs fonctions. [^10] #2 Ch 2:4.Nous offrons chaque matin et chaque soir des holocaustes à l’Éternel, nous brûlons le parfum odoriférant, nous mettons les pains de proposition sur la table pure, et nous allumons chaque soir le chandelier d’or et ses lampes; car nous observons les commandements de l’Éternel, notre Dieu. Et vous, vous l’avez abandonné. [^11] Voici, Dieu et ses sacrificateurs sont avec nous, à notre tête, et nous avons les trompettes retentissantes pour les faire résonner contre vous. Enfants d’Israël! Ne faites pas la guerre à l’Éternel, le Dieu de vos pères, car vous n’auriez aucun succès. [^12] Jéroboam les prit par derrière au moyen d’une embuscade, et ses troupes étaient en face de Juda, qui avait l’embuscade par derrière. [^13] Ceux de Juda s’étant retournés eurent à combattre devant et derrière. Ils crièrent à l’Éternel, et les sacrificateurs sonnèrent des trompettes. [^14] Les hommes de Juda poussèrent un cri de guerre et, au cri de guerre des hommes de Juda, l’Éternel frappa Jéroboam et tout Israël devant Abija et Juda. [^15] Les enfants d’Israël s’enfuirent devant Juda, et Dieu les livra entre ses mains. [^16] Abija et son peuple leur firent éprouver une grande défaite, et cinq cent mille hommes d’élite tombèrent morts parmi ceux d’Israël. [^17] Les enfants d’Israël furent humiliés en ce temps, et les enfants de Juda remportèrent la victoire, parce qu’ils s’étaient appuyés sur l’Éternel, le Dieu de leurs pères. [^18] Abija poursuivit Jéroboam et lui prit des villes, Béthel et les villes de son ressort, Jeschana et les villes de son ressort, et Éphron et les villes de son ressort. [^19] Jéroboam n’eut plus de force du temps d’Abija; et l’Éternel le frappa, et il mourut. [^20] Mais Abija devint puissant; il eut quatorze femmes, et engendra vingt-deux fils et seize filles. [^21] Le reste des actions d’Abija, ce qu’il a fait et ce qu’il a dit, cela est écrit dans les mémoires du prophète Iddo. [^22] Abija se coucha avec ses pères, et on l’enterra dans la ville de David. Et #1 R 15:8, etc.Asa, son fils, régna à sa place. De son temps, le pays fut en repos pendant dix ans. [^23] 

[[2 Chronicles - 12|<--]] 2 Chronicles - 13 [[2 Chronicles - 14|-->]]

---
# Notes
