---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 12 - Luis Segond (1910)"
---
[[2 Chronicles - 11|<--]] 2 Chronicles - 12 [[2 Chronicles - 13|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 12

#    
        1 R 14:22.  Lorsque Roboam se fut affermi dans son royaume et qu’il eut acquis de la force, il abandonna la loi de l’Éternel, et tout Israël l’abandonna avec lui. [^1] #1 R 14:25.La cinquième année du règne de Roboam, Schischak, roi d’Égypte, monta contre Jérusalem, parce qu’ils avaient péché contre l’Éternel. [^2] Il avait mille deux cents chars et soixante mille cavaliers; et il vint d’Égypte avec lui un peuple innombrable, des Libyens, des Sukkiens et des Éthiopiens. [^3] Il prit les villes fortes qui appartenaient à Juda, et arriva jusqu’à Jérusalem. [^4] Alors Schemaeja, le prophète, se rendit auprès de Roboam et des chefs de Juda qui s’étaient retirés dans Jérusalem à l’approche de Schischak, et il leur dit: Ainsi parle l’Éternel: Vous m’avez abandonné; je vous abandonne aussi, et je vous livre entre les mains de Schischak. [^5] Les chefs d’Israël et le roi s’humilièrent et dirent: L’Éternel est juste! [^6] Et quand l’Éternel vit qu’ils s’humiliaient, la parole de l’Éternel fut ainsi adressée à Schemaeja: Ils se sont humiliés, je ne les détruirai pas, je ne tarderai pas à les secourir, et ma colère ne se répandra pas sur Jérusalem par Schischak; [^7] mais ils lui seront assujettis, et ils sauront ce que c’est que me servir ou servir les royaumes des autres pays. [^8] Schischak, roi d’Égypte, monta contre Jérusalem. Il prit les trésors de la maison de l’Éternel et les trésors de la maison du roi, il prit tout. Il prit les boucliers d’or que Salomon #1 R 10:16. 2 Ch 9:15.avait faits. [^9] Le roi Roboam fit à leur place des boucliers d’airain, et il les remit aux soins des chefs des coureurs, qui gardaient l’entrée de la maison du roi. [^10] Toutes les fois que le roi allait à la maison de l’Éternel, les coureurs venaient et les portaient; puis ils les rapportaient dans la chambre des coureurs. [^11] Comme Roboam s’était humilié, l’Éternel détourna de lui sa colère et ne le détruisit pas entièrement. Et il y avait encore de bonnes choses en Juda. [^12] Le roi Roboam s’affermit dans Jérusalem et régna. #1 R 14:21.Il avait quarante et un ans lorsqu’il devint roi, et il régna dix-sept ans à Jérusalem, la ville que l’Éternel avait #2 Ch 6:6.choisie sur toutes les tribus d’Israël pour y mettre son nom. Sa mère s’appelait Naama, l’Ammonite. [^13] Il fit le mal, parce qu’il n’appliqua pas son cœur à chercher l’Éternel. [^14] Les actions de Roboam, les premières et les dernières, ne sont-elles pas écrites dans les livres de Schemaeja, le prophète et d’Iddo, le prophète, parmi les registres généalogiques? Il y eut toujours guerre entre Roboam et Jéroboam. [^15] Roboam se coucha avec ses pères, et il fut enterré dans la ville de David. Et Abija, son fils, régna à sa place. [^16] 

[[2 Chronicles - 11|<--]] 2 Chronicles - 12 [[2 Chronicles - 13|-->]]

---
# Notes
