---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 21 - Luis Segond (1910)"
---
[[2 Chronicles - 20|<--]] 2 Chronicles - 21 [[2 Chronicles - 22|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 21

#    
        1 R 22:51. 2 R 8:16.  Josaphat se coucha avec ses pères, et il fut enterré avec ses pères dans la ville de David. Et Joram, son fils, régna à sa place. [^1] Joram avait des frères, fils de Josaphat: Azaria, Jehiel, Zacharie, Azaria, Micaël et Schephathia, tous fils de Josaphat, roi d’Israël. [^2] Leur père leur avait donné des présents considérables en argent, en or, et en objets précieux, avec des villes fortes en Juda; mais il laissa le royaume à Joram, parce qu’il était le premier-né. [^3] Lorsque Joram eut pris possession du royaume de son père et qu’il se fut fortifié, il fit mourir par l’épée tous ses frères et quelques-uns aussi des chefs d’Israël. [^4] #2 R 8:17.Joram avait trente-deux ans lorsqu’il devint roi, et il régna huit ans à Jérusalem. [^5] Il marcha dans la voie des rois d’Israël, comme avait fait la maison d’Achab, car il avait pour femme une fille d’Achab, et il fit ce qui est mal aux yeux de l’Éternel. [^6] Mais l’Éternel ne voulut point détruire la maison de David, à cause de l’alliance #2 S 7:12. 1 R 11:36. Ps 132:11, 17.qu’il avait traitée avec David et de la #1 R 11:36.promesse qu’il avait faite de lui donner toujours une lampe, à lui et à ses fils. [^7] #2 R 8:20.De son temps, Édom se révolta contre l’autorité de Juda, et se donna un roi. [^8] Joram partit avec ses chefs et tous ses chars; s’étant levé de nuit, #2 R 8:21.il battit les Édomites qui l’entouraient et les chefs des chars. [^9] #2 R 8:22.La rébellion d’Édom contre l’autorité de Juda a duré jusqu’à ce jour. Libna se révolta dans le même temps contre son autorité, parce qu’il avait abandonné l’Éternel, le Dieu de ses pères. [^10] Joram fit même des hauts lieux dans les montagnes de Juda; il poussa les habitants de Jérusalem à la prostitution, et il séduisit Juda. [^11] Il lui vint un écrit du prophète Élie, disant: Ainsi parle l’Éternel, le Dieu de David, ton père: Parce que tu n’as pas marché dans les voies de Josaphat, ton père, et dans les voies d’Asa, roi de Juda, [^12] mais que tu as marché dans la voie des rois d’Israël; parce que tu as entraîné à la prostitution Juda et les habitants de Jérusalem, comme l’a fait la maison d’Achab à l’égard d’Israël; et parce que tu as fait mourir tes frères, meilleurs que toi, la maison même de ton père; [^13] voici, l’Éternel frappera ton peuple d’une grande plaie, tes fils, tes femmes, et tout ce qui t’appartient; [^14] et toi, il te frappera d’une maladie violente, d’une maladie d’entrailles, qui augmentera de jour en jour jusqu’à ce que tes entrailles sortent par la force du mal. [^15] Et l’Éternel excita contre Joram l’esprit des Philistins et des Arabes qui sont dans le voisinage des Éthiopiens. [^16] Ils montèrent contre Juda, y firent une invasion, pillèrent toutes les richesses qui se trouvaient dans la maison du roi, et emmenèrent ses fils et ses femmes, de sorte qu’il ne lui resta d’autre fils que Joachaz, le plus jeune de ses fils. [^17] Après tout cela, l’Éternel le frappa d’une maladie d’entrailles qui était sans remède; [^18] elle augmenta de jour en jour, et sur la fin de la seconde année les entrailles de Joram sortirent par la force de son mal. Il mourut dans de violentes souffrances; et son peuple ne brûla point de parfums en son honneur, comme il l’avait fait pour ses pères. [^19] Il avait trente-deux ans lorsqu’il devint roi, et il régna huit ans à Jérusalem. Il s’en alla sans être regretté, et on l’enterra dans la ville de David, mais non dans les sépulcres des rois. [^20] 

[[2 Chronicles - 20|<--]] 2 Chronicles - 21 [[2 Chronicles - 22|-->]]

---
# Notes
