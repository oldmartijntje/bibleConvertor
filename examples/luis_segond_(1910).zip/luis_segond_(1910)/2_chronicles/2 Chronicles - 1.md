---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 1 - Luis Segond (1910)"
---
2 Chronicles - 1 [[2 Chronicles - 2|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 1

Salomon, fils de David, #1 R 2:46.s’affermit dans son règne; l’Éternel, son Dieu, fut avec lui, et l’éleva à un haut degré. [^1] Salomon donna des ordres à tout Israël, aux chefs de milliers et de centaines, aux juges, aux princes de tout Israël, aux chefs des maisons paternelles; [^2] et #1 R 3:4.Salomon se rendit avec toute l’assemblée au haut lieu qui était à Gabaon. #1 Ch 16:39; 21:29.Là se trouvait la tente d’assignation de Dieu, faite dans le désert par Moïse, serviteur de l’Éternel; [^3] mais #2 S 6:2, 17. 1 Ch 16:1.l’arche de Dieu avait été transportée par David de Kirjath-Jearim à la place qu’il lui avait préparée, car il avait dressé pour elle une tente à Jérusalem. [^4] Là se trouvait aussi, devant le tabernacle de l’Éternel, l’autel d’airain qu’avait fait #Ex 38:1.Betsaleel, fils d’Uri, fils de Hur. Salomon et l’assemblée cherchèrent l’Éternel. [^5] Et ce fut là, sur l’autel d’airain qui était devant la tente d’assignation, que Salomon offrit à l’Éternel mille holocaustes. [^6] Pendant la nuit, Dieu apparut à Salomon et lui dit: Demande ce que tu veux que je te donne. [^7] Salomon répondit à Dieu: Tu as traité David, mon père, avec une grande bienveillance, #1 Ch 28:5.et tu m’as fait régner à sa place. [^8] Maintenant, Éternel Dieu, que ta promesse à David, mon père, s’accomplisse, #1 R 3:7.puisque tu m’as fait régner sur un peuple nombreux comme la poussière de la terre! [^9] #1 R 3:9, 11, 12.Accorde-moi donc de la sagesse et de l’intelligence, afin que je sache me conduire à la tête de ce peuple! Car qui pourrait juger ton peuple, ce peuple si grand? [^10] Dieu dit à Salomon: Puisque c’est là ce qui est dans ton cœur, puisque tu ne demandes ni des richesses, ni des biens, ni de la gloire, ni la mort de tes ennemis, ni même une longue vie, et que tu demandes pour toi de la sagesse et de l’intelligence afin de juger mon peuple sur lequel je t’ai fait régner, [^11] la sagesse et l’intelligence te sont accordées. Je te donnerai, en outre, des richesses, des biens et de la gloire, comme n’en a jamais eu #1 R 3:13. 1 Ch 29:25. 2 Ch 9:22.aucun roi avant toi et comme n’en aura aucun après toi. [^12] Salomon revint à Jérusalem, après avoir quitté le haut lieu qui était à Gabaon et la tente d’assignation. Et il régna sur Israël. [^13] Salomon #1 R 4:26; 10:26. 2 Ch 9:25.rassembla des chars et de la cavalerie; il avait quatorze cents chars et douze mille cavaliers, qu’il plaça dans les villes où il tenait ses chars et à Jérusalem près du roi. [^14] Le roi rendit l’argent et l’or aussi communs à Jérusalem que les pierres, et les cèdres aussi communs que les sycomores qui croissent dans la plaine. [^15] #1 R 10:28. 2 Ch 9:28.C’était de l’Égypte que Salomon tirait ses chevaux; une caravane de marchands du roi allait les chercher par troupes à un prix fixe; [^16] on faisait monter et sortir d’Égypte un char pour six cents sicles d’argent, et un cheval pour cent cinquante sicles. Ils en amenaient de même avec eux pour tous les rois des Héthiens et pour les rois de Syrie. [^17] 

2 Chronicles - 1 [[2 Chronicles - 2|-->]]

---
# Notes
