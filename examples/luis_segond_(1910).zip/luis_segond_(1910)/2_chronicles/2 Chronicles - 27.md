---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 27 - Luis Segond (1910)"
---
[[2 Chronicles - 26|<--]] 2 Chronicles - 27 [[2 Chronicles - 28|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 27

Jotham #2 R 15:33, etc.avait vingt-cinq ans lorsqu’il devint roi, et il régna seize ans à Jérusalem. Sa mère s’appelait Jeruscha, fille de Tsadok. [^1] Il fit ce qui est droit aux yeux de l’Éternel, entièrement comme avait fait Ozias, son père. Seulement, il n’entra point dans le temple de l’Éternel. Toutefois, le peuple se corrompait encore. [^2] Jotham bâtit la porte supérieure de la maison de l’Éternel, et il fit beaucoup de constructions sur les murs de la colline. [^3] Il bâtit des villes dans la montagne de Juda, et des châteaux et des tours dans les bois. [^4] Il fut en guerre avec le roi des fils d’Ammon, et il l’emporta sur eux. Les fils d’Ammon lui donnèrent cette année-là cent talents d’argent, dix mille cors de froment, et dix mille d’orge; et ils lui en payèrent autant la seconde année et la troisième. [^5] Jotham devint puissant, parce qu’il affermit ses voies devant l’Éternel, son Dieu. [^6] Le reste des actions de Jotham, toutes ses guerres, et tout ce qu’il a fait, cela est écrit dans le livre des rois d’Israël et de Juda. [^7] Il avait vingt-cinq ans lorsqu’il devint roi, et il régna seize ans à Jérusalem. [^8] Jotham se coucha avec ses pères, et on l’enterra dans la ville de David. Et Achaz, son fils, régna à sa place. [^9] 

[[2 Chronicles - 26|<--]] 2 Chronicles - 27 [[2 Chronicles - 28|-->]]

---
# Notes
