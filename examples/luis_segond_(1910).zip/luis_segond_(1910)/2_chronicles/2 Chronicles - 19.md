---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 19 - Luis Segond (1910)"
---
[[2 Chronicles - 18|<--]] 2 Chronicles - 19 [[2 Chronicles - 20|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 19

Josaphat, roi de Juda, revint en paix dans sa maison à Jérusalem. [^1] Jéhu, fils de Hanani, le prophète, alla au-devant de lui. Et il dit au roi Josaphat: Doit-on secourir le méchant, et aimes-tu ceux qui haïssent l’Éternel? A cause de cela, l’Éternel est irrité contre toi. [^2] Mais il s’est trouvé de bonnes choses en toi, #2 Ch 17:4, 6.car tu as fait disparaître du pays les idoles, et tu as appliqué ton cœur à chercher Dieu. [^3] Josaphat resta à Jérusalem. Puis il fit encore une tournée parmi le peuple, depuis Beer-Schéba jusqu’à la montagne d’Éphraïm, et il les ramena à l’Éternel, le Dieu de leurs pères. [^4] Il établit des juges dans toutes les villes fortes du pays de Juda, dans chaque ville. [^5] Et il dit aux juges: Prenez garde à ce que vous ferez, car ce n’est pas pour les hommes que vous prononcerez des jugements; c’est pour l’Éternel, qui sera près de vous quand vous les prononcerez. [^6] Maintenant, que la crainte de l’Éternel soit sur vous; veillez sur vos actes, #De 32:4. Ro 9:14.car il n’y a chez l’Éternel, notre Dieu, #De 10:17. Job 34:19. Ac 10:34. Ro 2:11. Ga 2:6. Ép 6:9. Col 3:25. 1 Pi 1:17.ni iniquité, ni égards pour l’apparence des personnes, ni acceptation de présents. [^7] Quand on fut de retour à Jérusalem, Josaphat y établit aussi, pour les jugements de l’Éternel et pour les contestations, des Lévites, des sacrificateurs et des chefs de maisons paternelles d’Israël. [^8] Et voici les ordres qu’il leur donna: Vous agirez de la manière suivante dans la crainte de l’Éternel, avec fidélité et avec intégrité de cœur. [^9] Dans toute contestation qui vous sera soumise par vos frères, établis dans leurs villes, relativement à un meurtre, à une loi, à un commandement, à des préceptes et à des ordonnances, vous les éclairerez, afin qu’ils ne se rendent pas coupables envers l’Éternel, et que sa colère n’éclate pas sur vous et sur vos frères. C’est ainsi que vous agirez, et vous ne serez point coupables. [^10] Et voici, vous avez à votre tête Amaria, le souverain sacrificateur, pour toutes les affaires de l’Éternel, et Zebadia, fils d’Ismaël, chef de la maison de Juda, pour toutes les affaires du roi, et vous avez devant vous des Lévites comme magistrats. Fortifiez-vous et agissez, et que l’Éternel soit avec celui qui fera le bien! [^11] 

[[2 Chronicles - 18|<--]] 2 Chronicles - 19 [[2 Chronicles - 20|-->]]

---
# Notes
