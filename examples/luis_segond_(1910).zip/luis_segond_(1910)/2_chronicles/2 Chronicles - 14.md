---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 14 - Luis Segond (1910)"
---
[[2 Chronicles - 13|<--]] 2 Chronicles - 14 [[2 Chronicles - 15|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 14

Asa fit ce qui est bien et droit aux yeux de l’Éternel, son Dieu. [^1] #1 R 15:13.Il fit disparaître les autels de l’étranger et les hauts lieux, il brisa les statues et abattit les idoles. [^2] Il ordonna à Juda de rechercher l’Éternel, le Dieu de ses pères, et de pratiquer la loi et les commandements. [^3] Il fit disparaître de toutes les villes de Juda les hauts lieux et les statues consacrées au soleil. Et le royaume fut en repos devant lui. [^4] Il bâtit des villes fortes en Juda; car le pays fut tranquille et il n’y eut pas de guerre contre lui pendant ces années-là, parce que l’Éternel lui donna du repos. [^5] Il dit à Juda: Bâtissons ces villes, et entourons-les de murs, de tours, de portes et de barres; le pays est encore devant nous, car nous avons recherché l’Éternel, notre Dieu, nous l’avons recherché, et il nous a donné du repos de tous côtés. Ils bâtirent donc, et réussirent. [^6] Asa avait une armée de trois cent mille hommes de Juda, portant le bouclier et la lance, et de deux cent quatre-vingt mille de Benjamin, portant le bouclier et tirant de l’arc, tous vaillants hommes. [^7] #    
        2 Ch 16:8.  Zérach, l’Éthiopien, sortit contre eux avec une armée d’un million d’hommes et trois cents chars, et il s’avança jusqu’à Maréscha. [^8] Asa marcha au-devant de lui, et ils se rangèrent en bataille dans la vallée de Tsephata, près de Maréscha. [^9] Asa invoqua l’Éternel, son Dieu, et dit: Éternel, toi seul peux venir en aide #1 S 14:6.au faible comme au fort: viens à notre aide, Éternel, notre Dieu! Car c’est sur toi que nous nous appuyons, et nous sommes venus en ton nom contre cette multitude. Éternel, tu es notre Dieu: que ce ne soit pas l’homme qui l’emporte sur toi! [^10] L’Éternel frappa les Éthiopiens devant Asa et devant Juda, et les Éthiopiens prirent la fuite. [^11] Asa et le peuple qui était avec lui les poursuivirent jusqu’à Guérar, et les Éthiopiens tombèrent sans pouvoir sauver leur vie, car ils furent détruits par l’Éternel et par son armée. Asa et son peuple firent un très grand butin; [^12] ils frappèrent toutes les villes des environs de Guérar, car la terreur de l’Éternel s’était emparée d’elles, et ils pillèrent toutes les villes, dont les dépouilles furent considérables. [^13] Ils frappèrent aussi les tentes des troupeaux, et ils emmenèrent une grande quantité de brebis et de chameaux. Puis ils retournèrent à Jérusalem. [^14] 

[[2 Chronicles - 13|<--]] 2 Chronicles - 14 [[2 Chronicles - 15|-->]]

---
# Notes
