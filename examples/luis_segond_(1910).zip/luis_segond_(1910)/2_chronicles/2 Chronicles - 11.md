---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 11 - Luis Segond (1910)"
---
[[2 Chronicles - 10|<--]] 2 Chronicles - 11 [[2 Chronicles - 12|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 11

#    
        1 R 12:21.  Roboam, arrivé à Jérusalem, rassembla la maison de Juda et de Benjamin, cent quatre-vingt mille hommes d’élite propres à la guerre, pour qu’ils combattissent contre Israël afin de le ramener sous la domination de Roboam. [^1] Mais la parole de l’Éternel fut ainsi adressée à Schemaeja, homme de Dieu: [^2] Parle à Roboam, fils de Salomon, roi de Juda, et à tout Israël en Juda et en Benjamin. Et dis-leur: [^3] Ainsi parle l’Éternel: #1 R 12:24.Ne montez point, et ne faites pas la guerre à vos frères! Que chacun de vous retourne dans sa maison, car c’est de par moi que cette chose est arrivée. Ils obéirent aux paroles de l’Éternel, et ils s’en retournèrent, renonçant à marcher contre Jéroboam. [^4] Roboam demeura à Jérusalem, et il bâtit des villes fortes en Juda. [^5] Il bâtit Bethléhem, Étham, Tekoa, [^6] Beth-Tsur, Soco, Adullam, [^7] Gath, Maréscha, Ziph, [^8] Adoraïm, Lakis, Azéka, [^9] Tsorea, Ajalon et Hébron, qui étaient en Juda et en Benjamin, et il en fit des villes fortes. [^10] Il les fortifia, et y établit des commandants, et des magasins de vivres, d’huile et de vin. [^11] Il mit dans chacune de ces villes des boucliers et des lances, et il les rendit très fortes. Juda et Benjamin étaient à lui. [^12] Les sacrificateurs et les Lévites qui se trouvaient dans tout Israël quittèrent leurs demeures pour se rendre auprès de lui; [^13] car les Lévites abandonnèrent leurs banlieues et leurs propriétés et vinrent en Juda et à Jérusalem, parce que #2 Ch 13:9.Jéroboam et ses fils les empêchèrent de remplir leurs fonctions comme sacrificateurs de l’Éternel. [^14] Jéroboam #1 R 12:31.établit des sacrificateurs pour les hauts lieux, pour les boucs, et pour les veaux qu’il avait faits. [^15] Ceux de toutes les tribus d’Israël qui avaient à cœur de chercher l’Éternel, le Dieu d’Israël, suivirent les Lévites à Jérusalem pour sacrifier à l’Éternel, le Dieu de leurs pères. [^16] Ils donnèrent ainsi de la force au royaume de Juda, et affermirent Roboam, fils de Salomon, pendant trois ans; car ils marchèrent pendant trois ans dans la voie de David et de Salomon. [^17] Roboam prit pour femme Mahalath, fille de Jerimoth, fils de David et d’Abichaïl, fille d’Éliab, fils d’Isaï. [^18] Elle lui enfanta des fils: Jeusch, Schemaria et Zaham. [^19] Après elle, il prit #1 R 15:2.Maaca, fille d’Absalom. Elle lui enfanta Abija, Attaï, Ziza et Schelomith. [^20] Roboam aimait Maaca, fille d’Absalom, plus que toutes ses femmes et ses concubines; car il eut dix-huit femmes et soixante concubines, et il engendra vingt-huit fils et soixante filles. [^21] Roboam donna le premier rang à Abija, fils de Maaca, et l’établit chef parmi ses frères, car il voulait le faire roi. [^22] Il agit avec habileté en dispersant tous ses fils dans toutes les contrées de Juda et de Benjamin, dans toutes les villes fortes; il leur fournit des vivres en abondance, et demanda pour eux une multitude de femmes. [^23] 

[[2 Chronicles - 10|<--]] 2 Chronicles - 11 [[2 Chronicles - 12|-->]]

---
# Notes
