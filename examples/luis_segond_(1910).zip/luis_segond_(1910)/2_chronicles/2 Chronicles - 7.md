---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 7 - Luis Segond (1910)"
---
[[2 Chronicles - 6|<--]] 2 Chronicles - 7 [[2 Chronicles - 8|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 7

Lorsque Salomon eut achevé de prier, le feu descendit du ciel et consuma l’holocauste et les sacrifices, #1 R 8:10, 11. 2 Ch 5:13, 14.et la gloire de l’Éternel remplit la maison. [^1] Les sacrificateurs ne pouvaient entrer dans la maison de l’Éternel, car la gloire de l’Éternel remplissait la maison de l’Éternel. [^2] Tous les enfants d’Israël virent descendre le feu et la gloire de l’Éternel sur la maison; ils s’inclinèrent le visage contre terre sur le pavé, se prosternèrent et louèrent l’Éternel, en disant: Car il est bon, car sa miséricorde dure à toujours! [^3] Le roi et tout le peuple offrirent des sacrifices devant l’Éternel. [^4] Le roi Salomon immola vingt-deux mille bœufs et cent vingt mille brebis. Ainsi le roi et tout le peuple firent la dédicace de la maison de Dieu. [^5] Les sacrificateurs se tenaient à leur poste, et les Lévites aussi avec les instruments faits en l’honneur de l’Éternel par le roi David pour le chant des louanges de l’Éternel, lorsque David les chargea de célébrer l’Éternel en disant: Car sa miséricorde dure à toujours! Les sacrificateurs sonnaient des trompettes vis-à-vis d’eux. Et tout Israël était là. [^6] Salomon consacra le milieu du parvis, qui est devant la maison de l’Éternel; car il offrit là les holocaustes et les graisses des sacrifices d’actions de grâces, parce que l’autel d’airain qu’avait fait Salomon ne pouvait contenir les holocaustes, les offrandes et les graisses. [^7] Salomon célébra la fête en ce temps-là pendant sept jours, et tout Israël avec lui; une grande multitude était venue depuis les environs de Hamath jusqu’au torrent d’Égypte. [^8] Le huitième jour, ils eurent une assemblée solennelle; #1 R 8:65.car ils firent la dédicace de l’autel pendant sept jours, et la fête pendant sept jours. [^9] Le vingt-troisième jour du septième mois, #1 R 8:66.Salomon renvoya dans ses tentes le peuple joyeux et content pour le bien que l’Éternel avait fait à David, à Salomon, et à Israël, son peuple. [^10] #    
        1 R 9:1.  Lorsque Salomon eut achevé la maison de l’Éternel et la maison du roi, et qu’il eut réussi dans tout ce qu’il s’était proposé de faire dans la maison de l’Éternel et dans la maison du roi, [^11] l’Éternel apparut à Salomon pendant la nuit, et lui dit: J’exauce ta prière, et je choisis ce lieu comme la maison où l’on devra m’offrir des sacrifices. [^12] Quand je fermerai le ciel et qu’il n’y aura point de pluie, quand j’ordonnerai aux sauterelles de consumer le pays, quand j’enverrai la peste parmi mon peuple; [^13] si mon peuple sur qui est invoqué mon nom s’humilie, prie, et cherche ma face, et s’il se détourne de ses mauvaises voies, je l’exaucerai des cieux, je lui pardonnerai son péché, et je guérirai son pays. [^14] #2 Ch 6:40.Mes yeux seront ouverts désormais, et mes oreilles seront attentives à la prière faite en ce lieu. [^15] Maintenant, je choisis et je sanctifie cette maison pour que mon nom y réside à jamais, et j’aurai toujours là mes yeux et mon cœur. [^16] Et toi, si tu marches en ma présence comme a marché David, ton père, faisant tout ce que je t’ai commandé, et si tu observes mes lois et mes ordonnances, [^17] j’affermirai le trône de ton royaume, comme je l’ai promis à David, ton père, en disant: Tu ne manqueras jamais d’un successeur qui règne en Israël. [^18] Mais si vous vous détournez, si vous abandonnez mes lois et mes commandements que je vous ai prescrits, et si vous allez servir d’autres dieux et vous prosterner devant eux, [^19] je vous arracherai de mon pays que je vous ai donné, je rejetterai loin de moi cette maison que j’ai consacrée à mon nom, et j’en ferai un sujet de sarcasme et de raillerie parmi tous les peuples. [^20] Et si haut placée qu’ait été cette maison, quiconque passera près d’elle sera dans l’étonnement, et dira: Pourquoi l’Éternel a-t-il ainsi traité ce pays et cette maison? [^21] Et l’on répondra: Parce qu’ils ont abandonné l’Éternel, le Dieu de leurs pères, qui les a fait sortir du pays d’Égypte, parce qu’ils se sont attachés à d’autres dieux, se sont prosternés devant eux et les ont servis; voilà pourquoi il a fait venir sur eux tous ces maux. [^22] 

[[2 Chronicles - 6|<--]] 2 Chronicles - 7 [[2 Chronicles - 8|-->]]

---
# Notes
