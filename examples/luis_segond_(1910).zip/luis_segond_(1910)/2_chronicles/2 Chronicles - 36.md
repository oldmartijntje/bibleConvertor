---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 36 - Luis Segond (1910)"
---
[[2 Chronicles - 35|<--]] 2 Chronicles - 36

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 36

#    
        2 R 23:30.  Le peuple du pays prit Joachaz, fils de Josias, et l’établit roi à la place de son père à Jérusalem. [^1] Joachaz avait vingt-trois ans lorsqu’il devint roi, et il régna trois mois à Jérusalem. [^2] Le roi d’Égypte le destitua à Jérusalem, et frappa le pays d’une contribution de cent talents d’argent et d’un talent d’or. [^3] Et le roi d’Égypte établit roi sur Juda et sur Jérusalem Éliakim, frère de Joachaz; et il changea son nom en celui de Jojakim. Néco prit son frère Joachaz, et l’emmena en Égypte. [^4] Jojakim avait vingt-cinq ans lorsqu’il devint roi, et il régna onze ans à Jérusalem. Il fit ce qui est mal aux yeux de l’Éternel, son Dieu. [^5] #2 R 24:1.Nebucadnetsar, roi de Babylone, monta contre lui, et le lia avec des chaînes d’airain pour le conduire à Babylone. [^6] Nebucadnetsar emporta à Babylone des ustensiles de la maison de l’Éternel, et il les mit dans son palais à Babylone. [^7] Le reste des actions de Jojakim, les abominations qu’il commit, et ce qui se trouvait en lui, cela est écrit dans le livre des rois d’Israël et de Juda. Et Jojakin, son fils, régna à sa place. [^8] #    
        2 R 24:8.  Jojakin avait huit ans lorsqu’il devint roi, et il régna trois mois et dix jours à Jérusalem. Il fit ce qui est mal aux yeux de l’Éternel. [^9] #Da 1:1, 2.L’année suivante, le roi Nebucadnetsar le fit emmener à Babylone avec les ustensiles précieux de la maison de l’Éternel. #2 R 24:17. Jé 37:1.Et il établit roi sur Juda et sur Jérusalem Sédécias, frère de Jojakin. [^10] Sédécias avait vingt et un ans lorsqu’il devint roi, et il régna onze ans à Jérusalem. [^11] #Jé 52:2, 3.Il fit ce qui est mal aux yeux de l’Éternel, son Dieu; et il ne s’humilia point devant Jérémie, le prophète, qui lui parlait de la part de l’Éternel. [^12] Il se révolta même contre le roi Nebucadnetsar, qui l’avait fait jurer par le nom de Dieu; et il raidit son cou et endurcit son cœur, au point de ne pas retourner à l’Éternel, le Dieu d’Israël. [^13] Tous les chefs des sacrificateurs et le peuple multiplièrent aussi les transgressions, selon toutes les abominations des nations; et ils profanèrent la maison de l’Éternel, qu’il avait sanctifiée à Jérusalem. [^14] L’Éternel, le Dieu de leurs pères, donna de bonne heure à ses envoyés la mission de les avertir, car il voulait épargner son peuple et sa propre demeure. [^15] Mais ils se moquèrent des envoyés de Dieu, ils méprisèrent ses paroles, et ils se raillèrent de ses prophètes, jusqu’à ce que la colère de l’Éternel contre son peuple devînt sans remède. [^16] Alors l’Éternel fit monter contre eux le roi des Chaldéens, et tua par l’épée leurs jeunes gens dans la maison de leur sanctuaire; il n’épargna ni le jeune homme, ni la jeune fille, ni le vieillard, ni l’homme aux cheveux blancs, il livra tout entre ses mains. [^17] Nebucadnetsar emporta à Babylone tous les ustensiles de la maison de Dieu, grands et petits, les trésors de la maison de l’Éternel, et les trésors du roi et de ses chefs. [^18] Ils brûlèrent la maison de Dieu, ils démolirent les murailles de Jérusalem, ils livrèrent au feu tous ses palais et détruisirent tous les objets précieux. [^19] Nebucadnetsar emmena captifs à Babylone ceux qui échappèrent à l’épée; et ils lui furent assujettis, à lui et à ses fils, jusqu’à la domination du royaume de Perse, [^20] afin que s’accomplît la parole de l’Éternel prononcée par la bouche de Jérémie; jusqu’à ce que le pays eût joui de ses sabbats, il se reposa tout le temps qu’il fut dévasté, jusqu’à l’accomplissement de #Jé 25:12; 29:10.soixante-dix ans. [^21] La première année de Cyrus, roi de Perse, afin que s’accomplît #Esd 1:1. Jé 25:12; 29:10.la parole de l’Éternel prononcée par la bouche de Jérémie, l’Éternel réveilla l’esprit de Cyrus, roi de Perse, qui fit faire de vive voix et par écrit cette publication dans tout son royaume: [^22] Ainsi parle Cyrus, roi de Perse: L’Éternel, le Dieu des cieux, m’a donné tous les royaumes de la terre, et il m’a commandé de lui bâtir une maison à Jérusalem en Juda. Qui d’entre vous est de son peuple? Que l’Éternel, son Dieu, soit avec lui, et qu’il monte! [^23] 

[[2 Chronicles - 35|<--]] 2 Chronicles - 36

---
# Notes
