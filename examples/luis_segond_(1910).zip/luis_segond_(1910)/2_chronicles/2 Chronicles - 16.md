---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 16 - Luis Segond (1910)"
---
[[2 Chronicles - 15|<--]] 2 Chronicles - 16 [[2 Chronicles - 17|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 16

#    
        1 R 15:17.  La trente-sixième année du règne d’Asa, Baescha, roi d’Israël, monta contre Juda; et il bâtit Rama, pour empêcher ceux d’Asa, roi de Juda, de sortir et d’entrer. [^1] Asa sortit de l’argent et de l’or des trésors de la maison de l’Éternel et de la maison du roi, et il envoya des messagers vers Ben-Hadad, roi de Syrie, qui habitait à Damas. [^2] Il lui fit dire: Qu’il y ait une alliance entre moi et toi, comme il y en eut une entre mon père et ton père. Voici, je t’envoie de l’argent et de l’or. Va, romps ton alliance avec Baescha, roi d’Israël, afin qu’il s’éloigne de moi. [^3] Ben-Hadad écouta le roi Asa; il envoya les chefs de son armée contre les villes d’Israël, et ils frappèrent Ijjon, Dan, Abel-Maïm, et tous les magasins des villes de Nephthali. [^4] Lorsque Baescha l’apprit, il cessa de bâtir Rama et interrompit ses travaux. [^5] Le roi Asa occupa tout Juda à emporter les pierres et le bois que Baescha employait à la construction de Rama, et il s’en servit pour bâtir Guéba et Mitspa. [^6] Dans ce temps-là, Hanani, le voyant, alla auprès d’Asa, roi de Juda, et lui dit: Parce que tu t’es appuyé sur le roi de Syrie et que tu ne t’es pas appuyé sur l’Éternel, ton Dieu, l’armée du roi de Syrie s’est échappée de tes mains. [^7] Les Éthiopiens et les Libyens ne formaient-ils pas une grande armée, avec des chars et une multitude de cavaliers? Et cependant l’Éternel les a livrés entre tes mains, parce que tu t’étais appuyé sur lui. [^8] Car l’Éternel #Job 34:21. Pr 5:21; 15:3. Jé 16:17; 32:19.étend ses regards sur toute la terre, pour soutenir ceux dont le cœur est tout entier à lui. Tu as agi en insensé dans cette affaire, car dès à présent tu auras des guerres. [^9] Asa fut irrité contre le voyant, et il le fit mettre en prison, parce qu’il était en colère contre lui. Et dans le même temps Asa opprima aussi quelques-uns du peuple. [^10] Les actions d’Asa, les premières et les dernières, sont écrites dans le livre des rois de Juda et d’Israël. [^11] La trente-neuvième année de son règne, Asa eut les pieds malades au point d’éprouver de grandes souffrances; même pendant sa maladie, il ne chercha pas l’Éternel, mais il consulta les médecins. [^12] Asa se coucha avec ses pères, et il mourut la quarante et unième année de son règne; [^13] on l’enterra dans le sépulcre qu’il s’était creusé dans la ville de David. On le coucha sur un lit qu’on avait garni d’aromates et de parfums préparés selon l’art du parfumeur, et l’on en brûla en son honneur une quantité très considérable. [^14] 

[[2 Chronicles - 15|<--]] 2 Chronicles - 16 [[2 Chronicles - 17|-->]]

---
# Notes
