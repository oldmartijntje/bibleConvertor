---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 26 - Luis Segond (1910)"
---
[[2 Chronicles - 25|<--]] 2 Chronicles - 26 [[2 Chronicles - 27|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 26

#    
        2 R 14:21.  Tout le peuple de Juda prit Ozias, âgé de seize ans, et l’établit roi à la place de son père Amatsia. [^1] #2 R 14:22.Ozias rebâtit Éloth et la fit rentrer sous la puissance de Juda, après que le roi fut couché avec ses pères. [^2] #2 R 15:2.Ozias avait seize ans lorsqu’il devint roi, et il régna cinquante-deux ans à Jérusalem. Sa mère s’appelait Jecolia, de Jérusalem. [^3] Il fit ce qui est droit aux yeux de l’Éternel, entièrement comme avait fait Amatsia, son père. [^4] Il s’appliqua à rechercher Dieu pendant la vie de Zacharie, qui avait l’intelligence des visions de Dieu; et dans le temps où il rechercha l’Éternel, Dieu le fit prospérer. [^5] Il se mit en guerre contre les Philistins; et il abattit les murs de Gath, les murs de Jabné, et les murs d’Asdod, et construisit des villes dans le territoire d’Asdod, et parmi les Philistins. [^6] Dieu l’aida contre les Philistins, contre les Arabes qui habitaient à Gur-Baal, et contre les Maonites. [^7] Les Ammonites faisaient des présents à Ozias, et sa renommée s’étendit jusqu’aux frontières de l’Égypte, car il devint très puissant. [^8] Ozias bâtit des tours à Jérusalem sur la porte de l’angle, sur la porte de la vallée, et sur l’angle, et il les fortifia. [^9] Il bâtit des tours dans le désert, et il creusa beaucoup de citernes, parce qu’il avait de nombreux troupeaux dans les vallées et dans la plaine, et des laboureurs et des vignerons dans les montagnes et au Carmel, car il aimait l’agriculture. [^10] Ozias avait une armée de soldats qui allaient à la guerre par bandes, comptées d’après le dénombrement qu’en firent le secrétaire Jeïel et le commissaire Maaséja, et placées sous les ordres de Hanania, l’un des chefs du roi. [^11] Le nombre total des chefs de maisons paternelles, des vaillants guerriers, était de deux mille six cents. [^12] Ils commandaient à une armée de trois cent sept mille cinq cents soldats capables de soutenir le roi contre l’ennemi. [^13] Ozias leur procura pour toute l’armée des boucliers, des lances, des casques, des cuirasses, des arcs et des frondes. [^14] Il fit faire à Jérusalem des machines inventées par un ingénieur, et destinées à être placées sur les tours et sur les angles, pour lancer des flèches et de grosses pierres. Sa renommée s’étendit au loin, car il fut merveilleusement soutenu jusqu’à ce qu’il devînt puissant. [^15] Mais lorsqu’il fut puissant, son cœur s’éleva pour le perdre. Il pécha contre l’Éternel, son Dieu: il entra dans le temple de l’Éternel pour brûler des parfums sur l’autel des parfums. [^16] Le sacrificateur Azaria entra après lui, avec quatre-vingts sacrificateurs de l’Éternel, [^17] hommes courageux, qui s’opposèrent au roi Ozias et lui dirent: Tu n’as pas le droit, Ozias, d’offrir des parfums à l’Éternel! Ce droit appartient aux sacrificateurs, fils d’Aaron, qui ont été consacrés pour les offrir. Sors du sanctuaire, car tu commets un péché! Et cela ne tournera pas à ton honneur devant l’Éternel Dieu. [^18] La colère s’empara d’Ozias, qui tenait un encensoir à la main. Et comme il s’irritait contre les sacrificateurs, la lèpre éclata sur son front, en présence des sacrificateurs, dans la maison de l’Éternel, près de l’autel des parfums. [^19] Le souverain sacrificateur Azaria et tous les sacrificateurs portèrent les regards sur lui, et voici, il avait la lèpre au front. Ils le mirent précipitamment dehors, et lui-même se hâta de sortir, parce que l’Éternel l’avait frappé. [^20] #2 R 15:5.Le roi Ozias fut lépreux jusqu’au jour de sa mort, et il demeura dans une maison écartée comme lépreux, car il fut exclu de la maison de l’Éternel. Et Jotham, son fils, était à la tête de la maison du roi et jugeait le peuple du pays. [^21] Le reste des actions d’Ozias, les premières et les dernières, a été écrit par Ésaïe, fils d’Amots, le prophète. [^22] Ozias se coucha avec ses pères, et on l’enterra avec ses pères dans le champ de la sépulture des rois, car on disait: Il est lépreux. Et Jotham, son fils, régna à sa place. [^23] 

[[2 Chronicles - 25|<--]] 2 Chronicles - 26 [[2 Chronicles - 27|-->]]

---
# Notes
