---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 15 - Luis Segond (1910)"
---
[[2 Chronicles - 14|<--]] 2 Chronicles - 15 [[2 Chronicles - 16|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Chronicles]]

# 2 Chronicles - 15

L’esprit de Dieu fut sur Azaria, fils d’Obed, [^1] et Azaria alla au-devant d’Asa et lui dit: Écoutez-moi, Asa, et tout Juda et Benjamin! L’Éternel est avec vous quand vous êtes avec lui; #1 Ch 28:9. 2 Ch 33:12. Mt 7:7.si vous le cherchez, vous le trouverez; #2 Ch 24:20.mais si vous l’abandonnez, il vous abandonnera. [^2] #Os 3:4.Pendant longtemps il n’y a eu pour Israël ni vrai Dieu, ni sacrificateur qui enseignât, ni loi. [^3] #De 4:29.Mais au sein de leur détresse ils sont retournés à l’Éternel, le Dieu d’Israël, ils l’ont cherché, et ils l’ont trouvé. [^4] Dans ces temps-là, point de sécurité pour ceux qui allaient et venaient, car il y avait de grands troubles parmi tous les habitants du pays; [^5] on se heurtait peuple contre peuple, ville contre ville, parce que Dieu les agitait par toutes sortes d’angoisses. [^6] Vous donc, fortifiez-vous, et ne laissez pas vos mains s’affaiblir, car il y aura un salaire pour vos œuvres. [^7] Après avoir entendu ces paroles et la prophétie d’Obed le prophète, Asa se fortifia et fit disparaître les abominations de tout le pays de Juda et de Benjamin et des villes qu’il avait prises dans la montagne d’Éphraïm, et il restaura l’autel de l’Éternel qui était devant le portique de l’Éternel. [^8] Il rassembla tout Juda et Benjamin, et ceux d’Éphraïm, de Manassé et de Siméon qui habitaient parmi eux, car un grand nombre de gens d’Israël se joignirent à lui lorsqu’ils virent que l’Éternel, son Dieu, était avec lui. [^9] Ils s’assemblèrent à Jérusalem le troisième mois de la quinzième année du règne d’Asa. [^10] Ce jour-là, ils sacrifièrent à l’Éternel, sur le butin qu’ils avaient amené, sept cents bœufs et sept mille brebis. [^11] Ils #Jos 24:14. Né 10:29.prirent l’engagement de chercher l’Éternel, le Dieu de leurs pères, de tout leur cœur et de toute leur âme; [^12] et quiconque ne chercherait pas l’Éternel, le Dieu d’Israël, #De 13:9.devait être mis à mort, petit ou grand, homme ou femme. [^13] Ils jurèrent fidélité à l’Éternel à voix haute, avec des cris de joie, et au son des trompettes et des cors; [^14] tout Juda se réjouit de ce serment, car ils avaient juré de tout leur cœur, ils avaient cherché l’Éternel de plein gré, et ils l’avaient trouvé, et l’Éternel leur donna du repos de tous côtés. [^15] Le roi Asa enleva même à Maaca, sa mère, #1 R 15:13.la dignité de reine, parce qu’elle avait fait une idole pour Astarté. Asa abattit son idole, qu’il réduisit en poussière, et la brûla au torrent de Cédron. [^16] Mais les hauts lieux ne disparurent point d’Israël, quoique le cœur d’Asa fût en entier à l’Éternel pendant toute sa vie. [^17] Il mit dans la maison de Dieu les choses consacrées par son père et par lui-même, de l’argent, de l’or et des vases. [^18] Il n’y eut point de guerre jusqu’à la trente-cinquième année du règne d’Asa. [^19] 

[[2 Chronicles - 14|<--]] 2 Chronicles - 15 [[2 Chronicles - 16|-->]]

---
# Notes
