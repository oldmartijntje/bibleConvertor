---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 17 - Luis Segond (1910)"
---
[[Deuteronomy - 16|<--]] Deuteronomy - 17 [[Deuteronomy - 18|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Deuteronomy]]

# Deuteronomy - 17

Tu n’offriras en sacrifice à l’Éternel, ton Dieu, ni bœuf, ni agneau qui ait #Lé 22:20, etc. De 15:21.quelque défaut ou difformité; car ce serait en abomination à l’Éternel, ton Dieu. [^1] #    
        De 13:6.  Il se trouvera peut-être au milieu de toi dans l’une des villes que l’Éternel, ton Dieu, te donne, un homme ou une femme faisant ce qui est mal aux yeux de l’Éternel, ton Dieu, et transgressant son alliance; [^2] allant après d’autres dieux pour les servir et se prosterner devant eux, après le soleil, la lune, ou toute l’armée des cieux. Ce n’est point là ce que j’ai commandé. [^3] Dès que tu en auras connaissance, dès que tu l’auras appris, tu feras avec soin des recherches. La chose est-elle vraie, le fait est-il établi, cette abomination a-t-elle été commise en Israël, [^4] alors tu feras venir à tes portes l’homme ou la femme qui sera coupable de cette mauvaise action, et tu lapideras ou puniras de mort cet homme ou cette femme. [^5] Celui qui mérite la mort sera exécuté #No 35:30. De 19:15. Mt 18:16. 2 Co 13:1. Hé 10:28.sur la déposition de deux ou de trois témoins; il ne sera pas mis à mort sur la déposition d’un seul témoin. [^6] #De 13:9.La main des témoins se lèvera la première sur lui pour le faire mourir, et la main de tout le peuple ensuite. Tu ôteras ainsi le mal du milieu de toi. [^7] Si une cause relative à un meurtre, à un différend, à une blessure, #2 Ch 19:10. Mal 2:7.te paraît trop difficile à juger et fournit matière à contestation dans tes portes, tu te lèveras et tu monteras au lieu que l’Éternel, ton Dieu, choisira. [^8] Tu iras vers les sacrificateurs, les Lévites, et vers celui qui remplira alors les fonctions de juge; tu les consulteras, et ils te feront connaître la sentence. [^9] Tu te conformeras à ce qu’ils te diront dans le lieu que choisira l’Éternel, et tu auras soin d’agir d’après tout ce qu’ils t’enseigneront. [^10] Tu te conformeras à la loi qu’ils t’enseigneront et à la sentence qu’ils auront prononcée; tu ne te détourneras de ce qu’ils te diront ni à droite ni à gauche. [^11] L’homme qui, par orgueil, n’écoutera pas le sacrificateur placé là pour servir l’Éternel, ton Dieu, ou qui n’écoutera pas le juge, cet homme sera puni de mort. Tu ôteras ainsi le mal du milieu d’Israël, [^12] afin que tout le peuple entende et craigne, et qu’il ne se livre plus à l’orgueil. [^13] Lorsque tu seras entré dans le pays que l’Éternel, ton Dieu, te donne, lorsque tu le posséderas, que tu y auras établi ta demeure, et que tu diras: Je veux mettre un roi sur moi, comme toutes les nations qui m’entourent, [^14] tu mettras sur toi un roi que choisira l’Éternel, ton Dieu, tu prendras un roi du milieu de tes frères, tu ne pourras pas te donner un étranger, qui ne soit pas ton frère. [^15] Mais qu’il n’ait pas un grand nombre de chevaux; et qu’il ne ramène pas le peuple en Égypte pour avoir beaucoup de chevaux; car l’Éternel vous a dit: Vous ne retournerez plus par ce chemin-là. [^16] Qu’il n’ait pas un grand nombre de femmes, afin que son cœur ne se détourne point; et qu’il ne fasse pas de grands amas d’argent et d’or. [^17] Quand il s’assiéra sur le trône de son royaume, il écrira pour lui, dans un livre, une copie de cette loi, qu’il prendra auprès des sacrificateurs, les Lévites. [^18] Il devra l’avoir avec lui et y lire tous les jours de sa vie, afin qu’il apprenne à craindre l’Éternel, son Dieu, à observer et à mettre en pratique toutes les paroles de cette loi et toutes ces ordonnances; [^19] afin que son cœur ne s’élève point au-dessus de ses frères, et qu’il ne se détourne de ces commandements ni à droite ni à gauche; afin qu’il prolonge ses jours dans son royaume, lui et ses enfants, au milieu d’Israël. [^20] 

[[Deuteronomy - 16|<--]] Deuteronomy - 17 [[Deuteronomy - 18|-->]]

---
# Notes
