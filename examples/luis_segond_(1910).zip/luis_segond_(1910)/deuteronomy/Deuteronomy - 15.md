---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 15 - Luis Segond (1910)"
---
[[Deuteronomy - 14|<--]] Deuteronomy - 15 [[Deuteronomy - 16|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Deuteronomy]]

# Deuteronomy - 15

#    
        Ex 21:2. Jé 34:14.  Tous les sept ans, tu feras relâche. [^1] Et voici comment s’observera le relâche. Quand on aura publié le relâche en l’honneur de l’Éternel, tout créancier qui aura fait un prêt à son prochain se relâchera de son droit, il ne pressera pas son prochain et son frère pour le paiement de sa dette. [^2] Tu pourras presser l’étranger; mais tu te relâcheras de ton droit pour ce qui t’appartiendra chez ton frère. [^3] Toutefois, il n’y aura point d’indigent chez toi, car l’Éternel te bénira dans le pays que l’Éternel, ton Dieu, te fera posséder en héritage, [^4] pourvu seulement que tu obéisses à la voix de l’Éternel, ton Dieu, en mettant soigneusement en pratique tous ces commandements que je te prescris aujourd’hui. [^5] L’Éternel, ton Dieu, te bénira comme il te l’a dit, #De 28:12.tu prêteras à beaucoup de nations, et tu n’emprunteras point; tu domineras sur beaucoup de nations, et elles ne domineront point sur toi. [^6] S’il y a chez toi quelque indigent d’entre tes frères, dans l’une de tes portes, au pays que l’Éternel, ton Dieu, te donne, tu n’endurciras point ton cœur et tu ne fermeras point ta main devant ton frère indigent. [^7] Mais tu lui ouvriras ta main, et tu lui prêteras de quoi pourvoir à ses besoins. [^8] Garde-toi d’être assez méchant pour dire en ton cœur: La septième année, l’année du relâche, approche! Garde-toi d’avoir un œil sans pitié pour ton frère indigent et de lui faire un refus. Il crierait à l’Éternel contre toi, et tu te chargerais d’un péché. [^9] #Mt 5:42. Lu 6:35.Donne-lui, et que ton cœur ne lui donne point à regret; car, à cause de cela, l’Éternel, ton Dieu, te bénira dans tous tes travaux et dans toutes tes entreprises. [^10] Il y aura toujours #Mt 26:11. Jn 12:8.des indigents dans le pays; c’est pourquoi je te donne ce commandement: Tu ouvriras ta main à ton frère, au pauvre et à l’indigent dans ton pays. [^11] #    
        Ex 21:2. Jé 34:14.  Si l’un de tes frères hébreux, homme ou femme, se vend à toi, il te servira six années; mais la septième année, tu le renverras libre de chez toi. [^12] Et lorsque tu le renverras libre de chez toi, tu ne le renverras point à vide; [^13] tu lui feras des présents de ton menu bétail, de ton aire, de ton pressoir, de ce que tu auras par la bénédiction de l’Éternel, ton Dieu. [^14] Tu te souviendras que tu as été esclave au pays d’Égypte, et que l’Éternel, ton Dieu, t’a racheté; c’est pourquoi je te donne aujourd’hui ce commandement. [^15] Si ton esclave te dit: Je ne veux pas sortir de chez toi, parce qu’il t’aime, toi et ta maison, et qu’il se trouve bien chez toi, [^16] alors tu prendras #Ex 21:6.un poinçon et tu lui perceras l’oreille contre la porte, et il sera pour toujours ton esclave. Tu feras de même pour ta servante. [^17] Tu ne trouveras point dur de le renvoyer libre de chez toi, car il t’a servi six ans, ce qui vaut le double du salaire d’un mercenaire; et l’Éternel, ton Dieu, te bénira dans tout ce que tu feras. [^18] #    
        Ex 13:2; 22:29; 34:19. Lé 27:26. No 3:13.  Tu consacreras à l’Éternel, ton Dieu, tout premier-né mâle qui naîtra dans ton gros et dans ton menu bétail. Tu ne travailleras point avec le premier-né de ton bœuf, et tu ne tondras point le premier-né de tes brebis. [^19] Tu le mangeras chaque année, toi et ta famille, devant l’Éternel, ton Dieu, dans le lieu qu’il choisira. [^20] #Lé 22:10. De 17:1.S’il a quelque défaut, s’il est boiteux ou aveugle, ou s’il a quelque autre difformité, tu ne l’offriras point en sacrifice à l’Éternel, ton Dieu. [^21] Tu le mangeras dans tes portes; celui qui sera impur et celui qui sera pur en mangeront l’un et l’autre, comme on mange de la gazelle et du cerf. [^22] #De 12:16, 23.Seulement, tu n’en mangeras pas le sang; tu le répandras sur la terre comme de l’eau. [^23] 

[[Deuteronomy - 14|<--]] Deuteronomy - 15 [[Deuteronomy - 16|-->]]

---
# Notes
