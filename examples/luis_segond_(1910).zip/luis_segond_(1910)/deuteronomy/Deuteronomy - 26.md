---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 26 - Luis Segond (1910)"
---
[[Deuteronomy - 25|<--]] Deuteronomy - 26 [[Deuteronomy - 27|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Deuteronomy]]

# Deuteronomy - 26

Lorsque tu seras entré dans le pays que l’Éternel, ton Dieu, te donne pour héritage, lorsque tu le posséderas et y seras établi, [^1] tu prendras #Ex 23:19; 34:26. Lé 2:14; 23:10. No 15:17.des prémices de tous les fruits que tu retireras du sol dans le pays que l’Éternel, ton Dieu, te donne, tu les mettras dans une corbeille, et tu iras au lieu que choisira l’Éternel, ton Dieu, pour y faire résider son nom. [^2] Tu te présenteras au sacrificateur alors en fonction, et tu lui diras: Je déclare aujourd’hui à l’Éternel, ton Dieu, que je suis entré dans le pays que l’Éternel a juré à nos pères de nous donner. [^3] Le sacrificateur recevra la corbeille de ta main, et la déposera devant l’autel de l’Éternel, ton Dieu. [^4] Tu prendras encore la parole, et tu diras devant l’Éternel, ton Dieu: Mon père était un Araméen nomade; il #Ge 46:1.descendit en Égypte avec peu de gens, et il y fixa son séjour; là, il devint une nation grande, puissante et nombreuse. [^5] Les Égyptiens nous maltraitèrent et nous opprimèrent, et ils nous soumirent à une dure servitude. [^6] Nous criâmes à l’Éternel, le Dieu de nos pères. L’Éternel #Ex 2:23.entendit notre voix, et il vit notre oppression, nos peines et nos misères. [^7] Et l’Éternel nous fit sortir d’Égypte, à main forte et à bras étendu, avec des prodiges de terreur, avec des signes et des miracles. [^8] Il nous a conduits dans ce lieu, et il nous a donné ce pays, pays où coulent le lait et le miel. [^9] Maintenant voici, j’apporte les prémices des fruits du sol que tu m’as donné, ô Éternel! Tu les déposeras devant l’Éternel, ton Dieu, et tu te prosterneras devant l’Éternel, ton Dieu. [^10] Puis tu te réjouiras, avec le Lévite et avec l’étranger qui sera au milieu de toi, pour tous les biens que l’Éternel, ton Dieu, t’a donnés, à toi et à ta maison. [^11] Lorsque tu auras achevé de lever #Lé 27:30. No 18:24.toute la dîme de tes produits, la troisième année, l’année de la dîme, tu la donneras au Lévite, à l’étranger, à l’orphelin et à la veuve; et ils mangeront et se rassasieront, dans tes portes. [^12] Tu diras devant l’Éternel, ton Dieu: J’ai ôté de ma maison ce qui est consacré, et je l’ai donné au Lévite, à l’étranger, à l’orphelin et à la veuve, #De 14:27.selon tous les ordres que tu m’as prescrits; je n’ai transgressé ni oublié aucun de tes commandements. [^13] Je n’ai rien mangé de ces choses pendant mon deuil, je n’en ai rien fait disparaître pour un usage impur, et je n’en ai rien donné à l’occasion d’un mort; j’ai obéi à la voix de l’Éternel, mon Dieu, j’ai agi selon tous les ordres que tu m’as prescrits. [^14] Regarde de ta demeure sainte, des cieux, et bénis ton peuple d’Israël et le pays que tu nous as donné, comme tu l’avais juré à nos pères, ce pays où coulent le lait et le miel. [^15] Aujourd’hui, l’Éternel, ton Dieu, te commande de mettre en pratique ces lois et ces ordonnances; tu les observeras et tu les mettras en pratique de tout ton cœur et de toute ton âme. [^16] Aujourd’hui, #Ge 17:7.tu as fait promettre à l’Éternel qu’il sera ton Dieu, afin que tu marches dans ses voies, que tu observes ses lois, ses commandements et ses ordonnances, et que tu obéisses à sa voix. [^17] Et aujourd’hui, l’Éternel t’a fait promettre que tu seras #Ex 19:5. De 7:6; 14:2.un peuple qui lui appartiendra, comme il te l’a dit, et que tu observeras tous ses commandements, [^18] #De 4:7.afin qu’il te donne sur toutes les nations qu’il a créées la supériorité en gloire, en renom et en magnificence, et afin que tu sois un peuple saint pour l’Éternel, ton Dieu, comme il te l’a dit. [^19] 

[[Deuteronomy - 25|<--]] Deuteronomy - 26 [[Deuteronomy - 27|-->]]

---
# Notes
