---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 18 - Luis Segond (1910)"
---
[[Deuteronomy - 17|<--]] Deuteronomy - 18 [[Deuteronomy - 19|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Deuteronomy]]

# Deuteronomy - 18

Les sacrificateurs, les Lévites, la tribu entière de Lévi, n’auront ni part ni héritage avec Israël; #No 18:20. De 10:9. 1 Co 9:13.ils se nourriront des sacrifices consumés par le feu en l’honneur de l’Éternel et de l’héritage de l’Éternel. [^1] Ils n’auront point d’héritage au milieu de leurs frères: #No 18:20, etc. De 10:9. Éz 44:28.l’Éternel sera leur héritage, comme il le leur a dit. [^2] Voici quel sera le droit des sacrificateurs sur le peuple, sur ceux qui offriront un sacrifice, un bœuf ou un agneau: on donnera au sacrificateur l’épaule, les mâchoires et l’estomac. [^3] Tu lui donneras les prémices de ton blé, de ton moût et de ton huile, et les prémices de la toison de tes brebis; [^4] car c’est lui que l’Éternel, ton Dieu, a choisi entre toutes les tribus, pour qu’il fasse le service au nom de l’Éternel, lui et ses fils, à toujours. [^5] Lorsque le Lévite quittera l’une de tes portes, le lieu quelconque où il demeure en Israël, pour se rendre, selon la plénitude de son désir, au lieu que choisira l’Éternel, [^6] et qu’il fera le service au nom de l’Éternel, ton Dieu, comme tous ses frères les Lévites qui se tiennent là devant l’Éternel, [^7] il recevra pour sa nourriture une portion égale à la leur, et jouira, en outre, des revenus de la vente de son patrimoine. [^8] Lorsque tu seras entré dans le pays que l’Éternel, ton Dieu, te donne, tu n’apprendras point à imiter les abominations de ces nations-là. [^9] Qu’on ne trouve chez toi personne #Lé 18:21.qui fasse passer son fils ou sa fille par le feu, #Lé 20:27. 1 S 28:7. És 8:19.personne qui exerce le métier de devin, d’astrologue, d’augure, de magicien, [^10] d’enchanteur, personne qui consulte ceux qui évoquent les esprits ou disent la bonne aventure, personne qui interroge les morts. [^11] Car quiconque fait ces choses est en abomination à l’Éternel; et c’est à cause de ces abominations que l’Éternel, ton Dieu, va chasser ces nations devant toi. [^12] Tu seras entièrement à l’Éternel, ton Dieu. [^13] Car ces nations que tu chasseras écoutent les astrologues et les devins; mais à toi, l’Éternel, ton Dieu, ne le permet pas. [^14] #    
        Jn 1:46. Ac 3:22; 7:37.  L’Éternel, ton Dieu, te suscitera du milieu de toi, d’entre tes frères, un prophète comme moi: vous l’écouterez! [^15] Il répondra ainsi à la demande que tu fis à l’Éternel, ton Dieu, à Horeb, le jour de l’assemblée, quand tu disais: #Ex 20:19. De 5:25. Hé 12:19.Que je n’entende plus la voix de l’Éternel, mon Dieu, et que je ne voie plus ce grand feu, afin de ne pas mourir. [^16] L’Éternel me dit: Ce qu’ils ont dit est bien. [^17] Je leur susciterai du milieu de leurs frères un prophète comme toi, je mettrai mes paroles dans sa bouche, #Jn 4:25.et il leur dira tout ce que je lui commanderai. [^18] Et si quelqu’un n’écoute pas mes paroles qu’il dira en mon nom, c’est moi qui lui en demanderai compte. [^19] Mais #De 13:5. Jé 14:14.le prophète qui aura l’audace de dire en mon nom une parole que je ne lui aurai point commandé de dire, ou qui parlera au nom d’autres dieux, ce prophète-là sera puni de mort. [^20] Peut-être diras-tu dans ton cœur: Comment connaîtrons-nous la parole que l’Éternel n’aura point dite? [^21] Quand ce que dira le prophète n’aura pas lieu et n’arrivera pas, ce sera une parole que l’Éternel n’aura point dite. C’est par audace que le prophète l’aura dite: n’aie pas peur de lui. [^22] 

[[Deuteronomy - 17|<--]] Deuteronomy - 18 [[Deuteronomy - 19|-->]]

---
# Notes
