---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 21 - Luis Segond (1910)"
---
[[Deuteronomy - 20|<--]] Deuteronomy - 21 [[Deuteronomy - 22|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Deuteronomy]]

# Deuteronomy - 21

Si, dans le pays dont l’Éternel, ton Dieu, te donne la possession, l’on trouve étendu au milieu d’un champ un homme tué, sans que l’on sache qui l’a frappé, [^1] tes anciens et tes juges iront mesurer les distances à partir du cadavre jusqu’aux villes des environs. [^2] Quand on aura déterminé la ville la plus rapprochée du cadavre, les anciens de cette ville prendront une génisse qui n’ait point servi au travail et qui n’ait point tiré au joug. [^3] Ils feront descendre cette génisse vers un torrent qui jamais ne tarisse et où il n’y ait ni culture ni semence; et là, ils briseront la nuque à la génisse, dans le torrent. [^4] Alors s’approcheront les sacrificateurs, fils de Lévi; car l’Éternel, ton Dieu, les a choisis pour qu’ils le servent et qu’ils bénissent au nom de l’Éternel, et ce sont eux qui doivent prononcer sur toute contestation et sur toute blessure. [^5] Tous les anciens de cette ville la plus rapprochée du cadavre laveront leurs mains sur la génisse à laquelle on a brisé la nuque dans le torrent. [^6] Et prenant la parole, ils diront: Nos mains n’ont point répandu ce sang et nos yeux ne l’ont point vu répandre. [^7] Pardonne, ô Éternel! À ton peuple d’Israël, que tu as racheté; n’impute pas le sang innocent à ton peuple d’Israël, et ce sang ne lui sera point imputé. [^8] Ainsi, tu dois faire disparaître du milieu de toi le sang innocent, en faisant ce qui est droit aux yeux de l’Éternel. [^9] Lorsque tu iras à la guerre contre tes ennemis, si l’Éternel les livre entre tes mains, et que tu leur fasses des prisonniers, [^10] peut-être verras-tu parmi les captives une femme belle de figure, et auras-tu le désir de la prendre pour femme. [^11] Alors tu l’amèneras dans l’intérieur de ta maison. Elle se rasera la tête et se fera les ongles, [^12] elle quittera les vêtements qu’elle portait quand elle a été prise, elle demeurera dans ta maison, et elle pleurera son père et sa mère pendant un mois. Après cela, tu iras vers elle, tu l’auras en ta possession, et elle sera ta femme. [^13] Si elle cesse de te plaire, tu la laisseras aller où elle voudra, tu ne pourras pas la vendre pour de l’argent ni la traiter comme esclave, parce que tu l’auras humiliée. [^14] Si un homme, qui a deux femmes, aime l’une et n’aime pas l’autre, et s’il en a des fils dont le premier-né soit de la femme qu’il n’aime pas, [^15] il ne pourra point, quand il partagera son bien entre ses fils, reconnaître comme premier-né le fils de celle qu’il aime, à la place du fils de celle qu’il n’aime pas, et qui est le premier-né. [^16] Mais il reconnaîtra pour premier-né le fils de celle qu’il n’aime pas, et #1 Ch 5:1.lui donnera sur son bien une portion double; car ce fils est #Ge 49:3.les prémices de sa vigueur, le droit d’aînesse lui appartient. [^17] Si un homme a un fils indocile et rebelle, n’écoutant ni la voix de son père, ni la voix de sa mère, et ne leur obéissant pas même après qu’ils l’ont châtié, [^18] le père et la mère le prendront, et le mèneront vers les anciens de sa ville et à la porte du lieu qu’il habite. [^19] Ils diront aux anciens de sa ville: Voici notre fils qui est indocile et rebelle, qui n’écoute pas notre voix, et qui se livre à des excès et à l’ivrognerie. [^20] Et tous les hommes de sa ville le lapideront, et il mourra. Tu ôteras ainsi le mal du milieu de toi, afin que tout Israël entende et craigne. [^21] Si l’on fait mourir un homme qui a commis un crime digne de mort, et que tu l’aies pendu à un bois, [^22] son cadavre ne passera point la nuit sur le bois; mais tu l’enterreras le jour même, car celui qui est pendu est un objet de malédiction auprès de #Ga 3:13.Dieu, et tu ne souilleras point le pays que l’Éternel, ton Dieu, te donne pour héritage. [^23] 

[[Deuteronomy - 20|<--]] Deuteronomy - 21 [[Deuteronomy - 22|-->]]

---
# Notes
