---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 16 - Luis Segond (1910)"
---
[[Deuteronomy - 15|<--]] Deuteronomy - 16 [[Deuteronomy - 17|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Deuteronomy]]

# Deuteronomy - 16

Observe le mois des épis, et célèbre la #Ex 12:2. Lé 23:5. No 9:1; 28:16.Pâque en l’honneur de l’Éternel, ton Dieu; car c’est dans le mois des épis que l’Éternel, ton Dieu, t’a fait sortir d’Égypte, pendant la nuit. [^1] Tu sacrifieras la Pâque à l’Éternel, ton Dieu, tes victimes de menu et de gros bétail, dans le lieu que l’Éternel choisira pour y faire résider son nom. [^2] Pendant la fête, tu #Ex 12:19; 34:18.ne mangeras pas du pain levé, mais tu mangeras sept jours des pains sans levain, du pain d’affliction, car c’est avec précipitation que tu es sorti du pays d’Égypte: il en sera ainsi, afin que tu te souviennes toute ta vie du jour où tu es sorti du pays d’Égypte. [^3] On ne verra point chez toi de levain, dans toute l’étendue de ton pays, pendant sept jours; et #Ex 12:10.aucune partie des victimes que tu sacrifieras le soir du premier jour ne sera gardée pendant la nuit jusqu’au matin. [^4] Tu ne pourras point sacrifier la Pâque dans l’un quelconque des lieux que l’Éternel, ton Dieu, te donne pour demeure; [^5] mais c’est dans le lieu que choisira l’Éternel, ton Dieu, pour y faire résider son nom, que tu sacrifieras la Pâque, le soir, au coucher du soleil, à l’époque de ta sortie d’Égypte. [^6] Tu feras cuire la victime, et tu la mangeras dans le lieu que choisira l’Éternel, ton Dieu. Et le matin, tu pourras t’en retourner et t’en aller vers tes tentes. [^7] Pendant six jours, tu mangeras des pains sans levain; et le septième jour, il y aura une assemblée solennelle en l’honneur de l’Éternel, ton Dieu: tu ne feras aucun ouvrage. [^8] #    
        Ex 23:16. Lé 23:15. No 28:26.  Tu compteras sept semaines; dès que la faucille sera mise dans les blés, tu commenceras à compter sept semaines. [^9] Puis tu célébreras la fête des semaines, et tu feras des offrandes volontaires, selon les bénédictions que l’Éternel, ton Dieu, t’aura accordées. [^10] Tu te réjouiras devant l’Éternel, ton Dieu, dans le lieu que l’Éternel, ton Dieu, choisira pour y faire résider son nom, toi, ton fils et ta fille, ton serviteur et ta servante, le Lévite qui sera dans tes portes, et l’étranger, l’orphelin et la veuve qui seront au milieu de toi. [^11] Tu te souviendras que tu as été esclave en Égypte, et tu observeras et mettras ces lois en pratique. [^12] #    
        Ex 23:16. Lé 23:34.  Tu célébreras la fête des tabernacles pendant sept jours, quand tu recueilleras le produit de ton aire et de ton pressoir. [^13] Tu te réjouiras à cette fête, toi, ton fils et ta fille, ton serviteur et ta servante, et le Lévite, l’étranger, l’orphelin et la veuve qui seront dans tes portes. [^14] Tu célébreras la fête pendant sept jours en l’honneur de l’Éternel, ton Dieu, dans le lieu que choisira l’Éternel; car l’Éternel, ton Dieu, te bénira dans toutes tes récoltes et dans tout le travail de tes mains, et tu te livreras entièrement à la joie. [^15] #Ex 23:17; 34:23.Trois fois par année, tous les mâles d’entre vous se présenteront devant l’Éternel, ton Dieu, dans le lieu qu’il choisira: à la fête des pains sans levain, à la fête des semaines, et à la fête des tabernacles. #Ex 23:15.On ne paraîtra point devant l’Éternel les mains vides. [^16] Chacun donnera ce qu’il pourra, selon les bénédictions que l’Éternel, ton Dieu, lui aura accordées. [^17] Tu établiras des juges et des magistrats dans toutes les villes que l’Éternel, ton Dieu, te donne, selon tes tribus; et ils jugeront le peuple avec justice. [^18] Tu ne porteras atteinte à aucun droit, #Lé 19:15. De 1:17.tu n’auras point égard à l’apparence des personnes, et #Ex 23:8.tu ne recevras point de présent, car les présents aveuglent les yeux des sages et corrompent les paroles des justes. [^19] Tu suivras ponctuellement la justice, afin que tu vives et que tu possèdes le pays que l’Éternel, ton Dieu, te donne. [^20] Tu ne fixeras aucune idole de bois à côté de l’autel que tu élèveras à l’Éternel, ton Dieu. [^21] Tu ne dresseras point des statues, qui sont en aversion à l’Éternel, ton Dieu. [^22] 

[[Deuteronomy - 15|<--]] Deuteronomy - 16 [[Deuteronomy - 17|-->]]

---
# Notes
