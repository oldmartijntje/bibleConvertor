---
translation: Luis Segond (1910)
aliases:
  - "Deuteronomy - Luis Segond (1910)"
tags:
  - "#bible/type/book"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
---
[[Numbers|<--]] Deuteronomy [[Joshua|-->]]

# Deuteronomy - Luis Segond (1910)

The Deuteronomy book has 34 chapters. It is part of the old testament.

## Chapters

- Deuteronomy [[Deuteronomy - 1|chapter 1]]
- Deuteronomy [[Deuteronomy - 2|chapter 2]]
- Deuteronomy [[Deuteronomy - 3|chapter 3]]
- Deuteronomy [[Deuteronomy - 4|chapter 4]]
- Deuteronomy [[Deuteronomy - 5|chapter 5]]
- Deuteronomy [[Deuteronomy - 6|chapter 6]]
- Deuteronomy [[Deuteronomy - 7|chapter 7]]
- Deuteronomy [[Deuteronomy - 8|chapter 8]]
- Deuteronomy [[Deuteronomy - 9|chapter 9]]
- Deuteronomy [[Deuteronomy - 10|chapter 10]]
- Deuteronomy [[Deuteronomy - 11|chapter 11]]
- Deuteronomy [[Deuteronomy - 12|chapter 12]]
- Deuteronomy [[Deuteronomy - 13|chapter 13]]
- Deuteronomy [[Deuteronomy - 14|chapter 14]]
- Deuteronomy [[Deuteronomy - 15|chapter 15]]
- Deuteronomy [[Deuteronomy - 16|chapter 16]]
- Deuteronomy [[Deuteronomy - 17|chapter 17]]
- Deuteronomy [[Deuteronomy - 18|chapter 18]]
- Deuteronomy [[Deuteronomy - 19|chapter 19]]
- Deuteronomy [[Deuteronomy - 20|chapter 20]]
- Deuteronomy [[Deuteronomy - 21|chapter 21]]
- Deuteronomy [[Deuteronomy - 22|chapter 22]]
- Deuteronomy [[Deuteronomy - 23|chapter 23]]
- Deuteronomy [[Deuteronomy - 24|chapter 24]]
- Deuteronomy [[Deuteronomy - 25|chapter 25]]
- Deuteronomy [[Deuteronomy - 26|chapter 26]]
- Deuteronomy [[Deuteronomy - 27|chapter 27]]
- Deuteronomy [[Deuteronomy - 28|chapter 28]]
- Deuteronomy [[Deuteronomy - 29|chapter 29]]
- Deuteronomy [[Deuteronomy - 30|chapter 30]]
- Deuteronomy [[Deuteronomy - 31|chapter 31]]
- Deuteronomy [[Deuteronomy - 32|chapter 32]]
- Deuteronomy [[Deuteronomy - 33|chapter 33]]
- Deuteronomy [[Deuteronomy - 34|chapter 34]]

[[Numbers|<--]] Deuteronomy [[Joshua|-->]]

---
# Notes
