---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 20 - Luis Segond (1910)"
---
[[Deuteronomy - 19|<--]] Deuteronomy - 20 [[Deuteronomy - 21|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Deuteronomy]]

# Deuteronomy - 20

Lorsque tu iras à la guerre contre tes ennemis, et que tu verras des chevaux et des chars, et un peuple plus nombreux que toi, tu ne les craindras point; car l’Éternel, ton Dieu, qui t’a fait monter du pays d’Égypte, est avec toi. [^1] A l’approche du combat, le sacrificateur s’avancera et parlera au peuple. [^2] Il leur dira: Écoute, Israël! Vous allez aujourd’hui livrer bataille à vos ennemis. Que votre cœur ne se trouble point; soyez sans crainte, ne vous effrayez pas, ne vous épouvantez pas devant eux. [^3] Car l’Éternel, votre Dieu, marche avec vous, pour combattre vos ennemis, pour vous sauver. [^4] Les officiers parleront ensuite au peuple et diront: Qui est-ce qui a bâti une maison neuve, et ne s’y est point encore établi? Qu’il s’en aille et retourne chez lui, de peur qu’il ne meure dans la bataille et qu’un autre ne s’y établisse. [^5] Qui est-ce qui a planté une vigne, et #Lé 19:23, 24, 25.n’en a point encore joui? Qu’il s’en aille et retourne chez lui, de peur qu’il ne meure dans la bataille et qu’un autre n’en jouisse. [^6] Qui est-ce qui #De 24:5.a fiancé une femme, et ne l’a point encore prise? Qu’il s’en aille et retourne chez lui, de peur qu’il ne meure dans la bataille et qu’un autre ne la prenne. [^7] Les officiers continueront à parler au peuple, et diront: #Jg 7:3.Qui est-ce qui a peur et manque de courage? Qu’il s’en aille et retourne chez lui, afin que ses frères ne se découragent pas comme lui. [^8] Quand les officiers auront achevé de parler au peuple, ils placeront les chefs des troupes à la tête du peuple. [^9] Quand tu t’approcheras d’une ville pour l’attaquer, tu lui offriras la paix. [^10] Si elle accepte la paix et t’ouvre ses portes, tout le peuple qui s’y trouvera te sera tributaire et asservi. [^11] Si elle n’accepte pas la paix avec toi et qu’elle veuille te faire la guerre, alors tu l’assiégeras. [^12] Et après que l’Éternel, ton Dieu, l’aura livrée entre tes mains, tu en feras passer tous les mâles au fil de l’épée. [^13] Mais tu prendras pour toi les femmes, les enfants, le bétail, tout ce qui sera dans la ville, tout son butin, et tu mangeras les dépouilles de tes ennemis que l’Éternel, ton Dieu, t’aura livrés. [^14] C’est ainsi que tu agiras à l’égard de toutes les villes qui sont très éloignées de toi, et qui ne font point partie des villes de ces nations-ci. [^15] Mais dans les villes de ces peuples dont l’Éternel, ton Dieu, te donne le pays pour héritage, #No 33:52. De 7:1, 2.tu ne laisseras la vie à rien de ce qui respire. [^16] Car tu dévoueras ces peuples par interdit, les Héthiens, les Amoréens, les Cananéens, les Phéréziens, les Héviens, et les Jébusiens, comme l’Éternel, ton Dieu, te l’a ordonné, [^17] afin qu’ils ne vous apprennent pas à imiter toutes les abominations qu’ils font pour leurs dieux, et que vous ne péchiez point contre l’Éternel, votre Dieu. [^18] Si tu fais un long siège pour t’emparer d’une ville avec laquelle tu es en guerre, tu ne détruiras point les arbres en y portant la hache, tu t’en nourriras et tu ne les abattras point; car l’arbre des champs est-il un homme pour être assiégé par toi? [^19] Mais tu pourras détruire et abattre les arbres que tu sauras ne pas être des arbres servant à la nourriture, et en construire des retranchements contre la ville qui te fait la guerre, jusqu’à ce qu’elle succombe. [^20] 

[[Deuteronomy - 19|<--]] Deuteronomy - 20 [[Deuteronomy - 21|-->]]

---
# Notes
