---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 30 - Luis Segond (1910)"
---
[[Deuteronomy - 29|<--]] Deuteronomy - 30 [[Deuteronomy - 31|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Deuteronomy]]

# Deuteronomy - 30

Lorsque toutes ces choses t’arriveront, la bénédiction et la malédiction que je mets devant toi, si tu les prends à cœur au milieu de toutes les nations chez lesquelles l’Éternel, ton Dieu, t’aura chassé, [^1] si tu reviens à l’Éternel, ton Dieu, et si tu obéis à sa voix de tout ton cœur et de toute ton âme, toi et tes enfants, selon tout ce que je te prescris aujourd’hui, [^2] alors l’Éternel, ton Dieu, ramènera #Né 1:8. Ps 106:45. Jé 32:37.tes captifs et aura compassion de toi, il te rassemblera encore du milieu de tous les peuples chez lesquels l’Éternel, ton Dieu, t’aura dispersé. [^3] #Né 1:9.Quand tu serais exilé à l’autre extrémité du ciel, l’Éternel, ton Dieu, te rassemblera de là, et c’est là qu’il t’ira chercher. [^4] L’Éternel, ton Dieu, te ramènera dans le pays que possédaient tes pères, et tu le posséderas; il te fera du bien, et te rendra plus nombreux que tes pères. [^5] L’Éternel, ton Dieu, #Jé 32:39. Éz 11:19; 39:26.circoncira ton cœur et le cœur de ta postérité, et tu aimeras l’Éternel, ton Dieu, de tout ton cœur et de toute ton âme, afin que tu vives. [^6] L’Éternel, ton Dieu, fera tomber toutes ces malédictions sur tes ennemis, sur ceux qui t’auront haï et persécuté. [^7] Et toi, tu reviendras à l’Éternel, tu obéiras à sa voix, et tu mettras en pratique tous ces commandements que je te prescris aujourd’hui. [^8] #De 28:11.L’Éternel, ton Dieu, te comblera de biens en faisant prospérer tout le travail de tes mains, le fruit de tes entrailles, le fruit de tes troupeaux et le fruit de ton sol; car l’Éternel prendra de nouveau plaisir à ton bonheur, comme il prenait plaisir à celui de tes pères, [^9] lorsque tu obéiras à la voix de l’Éternel, ton Dieu, en observant ses commandements et ses ordres écrits dans ce livre de la loi, lorsque tu reviendras à l’Éternel, ton Dieu, de tout ton cœur et de toute ton âme. [^10] Ce commandement que je te prescris aujourd’hui n’est certainement point #És 45:19.au-dessus de tes forces et hors de ta portée. [^11] Il n’est pas dans le ciel, pour que tu dises: #Ro 10:6, etc.Qui montera pour nous au ciel et nous l’ira chercher, qui nous le fera entendre, afin que nous le mettions en pratique? [^12] Il n’est pas de l’autre côté de la mer, pour que tu dises: Qui passera pour nous de l’autre côté de la mer et nous l’ira chercher, qui nous le fera entendre, afin que nous le mettions en pratique? [^13] C’est une chose, au contraire, qui est tout près de toi, dans ta bouche et dans ton cœur, afin que tu la mettes en pratique. [^14] Vois, je mets aujourd’hui devant toi la vie et le bien, la mort et le mal. [^15] Car je te prescris aujourd’hui d’aimer l’Éternel, ton Dieu, de marcher dans ses voies, et d’observer ses commandements, ses lois et ses ordonnances, afin que tu vives et que tu multiplies, et que l’Éternel, ton Dieu, te bénisse dans le pays dont tu vas entrer en possession. [^16] Mais si ton cœur se détourne, si tu n’obéis point, et si tu te laisses entraîner à te prosterner devant d’autres dieux et à les servir, [^17] je vous déclare aujourd’hui que vous périrez, que vous ne prolongerez point vos jours dans le pays dont vous allez entrer en possession, après avoir passé le Jourdain. [^18] #De 4:26.J’en prends aujourd’hui à témoin contre vous le ciel et la terre: j’ai mis devant toi la vie et la mort, la bénédiction et la malédiction. Choisis la vie, afin que tu vives, toi et ta postérité, [^19] pour aimer l’Éternel, ton Dieu, pour obéir à sa voix, et pour t’attacher à lui: car de cela dépendent ta vie et la prolongation de tes jours, et c’est ainsi que tu pourras demeurer dans le pays que l’Éternel a juré de donner à tes pères, Abraham, Isaac et Jacob. [^20] 

[[Deuteronomy - 29|<--]] Deuteronomy - 30 [[Deuteronomy - 31|-->]]

---
# Notes
