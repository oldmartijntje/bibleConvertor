---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 25 - Luis Segond (1910)"
---
[[Deuteronomy - 24|<--]] Deuteronomy - 25 [[Deuteronomy - 26|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Deuteronomy]]

# Deuteronomy - 25

Lorsque des hommes, ayant entre eux une querelle, se présenteront en justice pour être jugés, on absoudra l’innocent, et l’on condamnera le coupable. [^1] Si le coupable mérite d’être battu, le juge le fera étendre par terre et frapper en sa présence d’un nombre de coups proportionné à la gravité de sa faute. [^2] Il ne lui fera pas donner plus de #2 Co 11:24.quarante coups, de peur que, si l’on continuait à le frapper en allant beaucoup au-delà, ton frère ne fût avili à tes yeux. [^3] Tu #1 Co 9:9. 1 Ti 5:18.n’emmuselleras point le bœuf, quand il foulera le grain. [^4] Lorsque des frères demeureront ensemble, et que l’un d’eux mourra sans laisser de fils, la femme du défunt ne se mariera point au-dehors avec un étranger, mais #Mt 22:24. Mc 12:19. Lu 20:28.son beau-frère ira vers elle, la prendra pour femme, et l’épousera comme beau-frère. [^5] Le premier-né qu’elle enfantera succédera au frère mort et portera son nom, afin que ce nom ne soit pas effacé d’Israël. [^6] Si cet homme ne veut pas prendre sa belle-sœur, elle montera à la porte vers les anciens, et dira: #Ru 4:7.Mon beau-frère refuse de relever en Israël le nom de son frère, il ne veut pas m’épouser par droit de beau-frère. [^7] Les anciens de la ville l’appelleront, et lui parleront. S’il persiste, et dit: Je ne veux pas la prendre, [^8] alors sa belle-sœur s’approchera de lui en présence des anciens, lui ôtera son soulier du pied, et lui crachera au visage. Et prenant la parole, elle dira: Ainsi sera fait à l’homme qui ne relève pas la maison de son frère. [^9] Et sa maison sera appelée en Israël la maison du déchaussé. [^10] Lorsque des hommes se querelleront ensemble, l’un avec l’autre, si la femme de l’un s’approche pour délivrer son mari de la main de celui qui le frappe, si elle avance la main et saisit ce dernier par les parties honteuses, [^11] tu lui couperas la main, tu ne jetteras sur elle aucun regard de pitié. [^12] Tu n’auras point dans ton sac deux sortes de poids, un gros et un petit. [^13] Tu n’auras point dans ta maison deux sortes d’épha, un grand et un petit. [^14] Tu auras un poids exact et juste, tu auras un épha exact et juste, afin que tes jours se prolongent dans le pays que l’Éternel, ton Dieu, te donne. [^15] Car quiconque fait ces choses, quiconque commet une iniquité, est en #Pr 11:1.abomination à l’Éternel, ton Dieu. [^16] Souviens-toi de ce que te fit #Ex 17:8.Amalek pendant la route, lors de votre sortie d’Égypte, [^17] comment il te rencontra dans le chemin, et, sans aucune crainte de Dieu, tomba sur toi par derrière, sur tous ceux qui se traînaient les derniers, pendant que tu étais las et épuisé toi-même. [^18] Lorsque l’Éternel, ton Dieu, après t’avoir délivré de tous les ennemis qui t’entourent, t’accordera du repos dans le pays que l’Éternel, ton Dieu, te donne en héritage et en propriété, tu effaceras la mémoire d’Amalek de dessous les cieux: ne l’oublie point. [^19] 

[[Deuteronomy - 24|<--]] Deuteronomy - 25 [[Deuteronomy - 26|-->]]

---
# Notes
