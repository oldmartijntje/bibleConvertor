---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 33 - Luis Segond (1910)"
---
[[Deuteronomy - 32|<--]] Deuteronomy - 33 [[Deuteronomy - 34|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Deuteronomy]]

# Deuteronomy - 33

Voici la bénédiction par laquelle Moïse, homme de Dieu, bénit les enfants d’Israël, avant sa mort. [^1] Il dit:L’Éternel est venu du Sinaï,Il s’est levé sur eux de Séir,Il a resplendi de la montagne de Paran,Et il est sorti du milieu des saintes myriades:Il leur a de sa droite envoyé le feu de la loi. [^2] Oui, il aime les peuples;Tous ses saints sont dans ta main.Ils se sont tenus à tes pieds,Ils ont reçu tes paroles. [^3] Moïse nous a donné la loi,Héritage de l’assemblée de Jacob. [^4] Il était roi en Israël,Quand s’assemblaient les chefs du peupleEt les tribus d’Israël. [^5] Que Ruben vive et qu’il ne meure point,Et que ses hommes soient nombreux! [^6] Voici sur Juda ce qu’il dit:Écoute, ô Éternel! La voix de Juda,Et ramène-le vers son peuple.Que ses mains soient puissantes,Et que tu lui sois en aide contre ses ennemis! [^7] Sur Lévi il dit:Les thummim et les urim ont été confiés à l’homme saint,Que tu as tenté à Massa,Et avec qui tu as contesté aux eaux de Meriba. [^8] Lévi dit de son père et de sa mère:Je ne les ai point vus!Il ne distingue point ses frères,Il ne connaît point ses enfants.Car ils observent ta parole,Et ils gardent ton alliance; [^9] Ils enseignent tes ordonnances à Jacob,Et ta loi à Israël;Ils mettent l’encens sous tes narines,Et l’holocauste sur ton autel. [^10] Bénis sa force, ô Éternel!Agrée l’œuvre de ses mains!Brise les reins de ses adversaires,Et que ses ennemis ne se relèvent plus! [^11] Sur Benjamin il dit:C’est le bien-aimé de l’Éternel,Il habitera en sécurité auprès de lui;L’Éternel le couvrira toujours,Et résidera entre ses épaules. [^12] Sur Joseph il dit:#    
        Ge 49:25.  Son pays recevra de l’Éternel, en signe de bénédiction,Le meilleur don du ciel, la rosée,Les meilleures eaux qui sont en bas, [^13] Les meilleurs fruits du soleil,Les meilleurs fruits de chaque mois, [^14] Les meilleurs produits des antiques montagnes,Les meilleurs produits des collines Éternelles, [^15] Les meilleurs produits de la terre et de ce qu’elle renferme.Que la grâce de celui qui apparut dans le buissonVienne sur la tête de Joseph,Sur le sommet de la tête #Ge 49:26.du prince de ses frères! [^16] De son taureau premier-né il a la majesté;Ses cornes sont les cornes du buffle;Avec elles il frappera tous les peuples,Jusqu’aux extrémités de la terre:Elles sont les myriades d’Éphraïm,Elles sont les milliers de Manassé. [^17] Sur Zabulon il dit:Réjouis-toi, Zabulon, dans tes courses,Et toi, Issacar, dans tes tentes! [^18] Ils appelleront les peuples sur la montagne;Là, ils offriront des sacrifices de justice,Car ils suceront l’abondance de la mer,Et les trésors cachés dans le sable. [^19] Sur Gad il dit:Béni soit celui qui met Gad au large!Gad repose comme une lionne, Il déchire le bras et la tête. [^20] Il a choisi les prémices du pays,Car là est caché l’héritage du législateur;Il a marché en tête du peuple,Il a exécuté la justice de l’Éternel,Et ses ordonnances envers Israël. [^21] Sur Dan il dit:Dan est un jeune lion,Qui s’élance de Basan. [^22] Sur Nephthali il dit:Nephthali, rassasié de faveursEt comblé des bénédictions de l’Éternel,Prends possession de l’occident et du midi! [^23] Sur Aser il dit:Béni soit Aser entre les enfants d’Israël!Qu’il soit agréable à ses frères,Et qu’il plonge son pied dans l’huile! [^24] Que tes verrous soient de fer et d’airain,Et que ta vigueur dure autant que tes jours! [^25] Nul n’est semblable au Dieu d’Israël,Il est porté sur les cieux pour venir à ton aide,Il est avec majesté porté sur les nuées. [^26] Le Dieu d’éternité est un refuge,Et sous ses bras Éternels est une retraite.Devant toi il a chassé l’ennemi,Et il a dit: Extermine. [^27] #    
        Jé 23:6; 33:16.  Israël est en sécurité dans sa demeure,La source de Jacob est à partDans un pays de blé et de moût,Et son ciel distille la rosée. [^28] Que tu es heureux, Israël!Qui est comme toi,Un peuple sauvé par l’Éternel,Le bouclier de ton secoursEt l’épée de ta gloire?Tes ennemis feront défaut devant toi,Et tu fouleras leurs lieux élevés. [^29] 

[[Deuteronomy - 32|<--]] Deuteronomy - 33 [[Deuteronomy - 34|-->]]

---
# Notes
