---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 6 - Luis Segond (1910)"
---
[[Deuteronomy - 5|<--]] Deuteronomy - 6 [[Deuteronomy - 7|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Deuteronomy]]

# Deuteronomy - 6

Voici les commandements, les lois et les ordonnances que l’Éternel, votre Dieu, a commandé de vous enseigner, afin que vous les mettiez en pratique dans le pays dont vous allez prendre possession; [^1] afin que tu craignes l’Éternel, ton Dieu, en observant, tous les jours de ta vie, toi, ton fils, et le fils de ton fils, toutes ses lois et tous ses commandements que je te prescris, et afin que tes jours soient prolongés. [^2] Tu les écouteras donc, Israël, et tu auras soin de les mettre en pratique, afin que tu sois heureux et que vous multipliiez beaucoup, comme te l’a dit l’Éternel, le Dieu de tes pères, en te promettant un pays où coulent le lait et le miel. [^3] #De 4:35. Mc 12:29. Jn 17:3. 1 Co 8:4, 6.Écoute, Israël! L’Éternel, notre Dieu, est le seul Éternel. [^4] Tu #De 10:12. Mt 22:37. Lu 10:27.aimeras l’Éternel, ton Dieu, de tout ton cœur, de toute ton âme et de toute ta force. [^5] Et ces commandements, que je te donne aujourd’hui, seront dans ton cœur. [^6] Tu les inculqueras à #De 4:9; 11:19.tes enfants, et tu en parleras quand tu seras dans ta maison, quand tu iras en voyage, quand tu te coucheras et quand tu te lèveras. [^7] Tu les lieras comme un signe sur tes mains, et ils seront comme des fronteaux entre tes yeux. [^8] Tu les écriras sur les poteaux de ta maison et sur tes portes. [^9] L’Éternel, ton Dieu, te fera entrer dans le pays qu’il a juré à tes pères, à Abraham, à Isaac et à Jacob, de te donner. Tu posséderas de grandes et bonnes villes que tu n’as point bâties, [^10] des maisons qui sont pleines de toutes sortes de biens et que tu n’as point remplies, des citernes creusées que tu n’as point creusées, des vignes et des oliviers que tu n’as point plantés. [^11] #De 8:9, 10.Lorsque tu mangeras et te rassasieras, garde-toi d’oublier l’Éternel, qui t’a fait sortir du pays d’Égypte, de la maison de servitude. [^12] Tu #De 10:20. Mt 4:10. Lu 4:8.craindras l’Éternel, ton Dieu, tu le serviras, et tu jureras par son nom. [^13] Vous n’irez point après d’autres dieux, d’entre les dieux des peuples qui sont autour de vous; [^14] car l’Éternel, ton Dieu, est un Dieu jaloux au milieu de toi. La colère de l’Éternel, ton Dieu, s’enflammerait contre toi, et il t’exterminerait de dessus la terre. [^15] Vous #Mt 4:7. Lu 4:12.ne tenterez point l’Éternel, votre Dieu, comme vous l’avez tenté à #Ex 17:2. No 20:3.Massa. [^16] Mais vous observerez les commandements de l’Éternel, votre Dieu, ses ordonnances et ses lois qu’il vous a prescrites. [^17] Tu feras ce qui est droit et ce qui est bien aux yeux de l’Éternel, afin que tu sois heureux, et que tu entres en possession du bon pays que l’Éternel a juré à tes pères de te donner, [^18] après qu’il aura chassé tous tes ennemis devant toi, comme l’Éternel l’a dit. [^19] Lorsque ton fils te demandera un jour: Que signifient ces préceptes, ces lois et ces ordonnances, que l’Éternel, notre Dieu, vous a prescrits? [^20] tu diras à ton fils: Nous étions esclaves de Pharaon en Égypte, et l’Éternel nous a fait sortir de l’Égypte par sa main puissante. [^21] L’Éternel a opéré, sous nos yeux, des miracles et des prodiges, grands et désastreux, contre l’Égypte, contre Pharaon et contre toute sa maison; [^22] et il nous a fait sortir de là, pour nous amener dans le pays qu’il avait juré à nos pères de nous donner. [^23] L’Éternel nous a commandé de mettre en pratique toutes ces lois, et de craindre l’Éternel, notre Dieu, afin que nous fussions toujours heureux, et qu’il nous conservât la vie, comme il le fait aujourd’hui. [^24] Nous aurons la justice en partage, si nous mettons soigneusement en pratique tous ces commandements devant l’Éternel, notre Dieu, comme il nous l’a ordonné. [^25] 

[[Deuteronomy - 5|<--]] Deuteronomy - 6 [[Deuteronomy - 7|-->]]

---
# Notes
