---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 13 - Luis Segond (1910)"
---
[[Deuteronomy - 12|<--]] Deuteronomy - 13 [[Deuteronomy - 14|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Deuteronomy]]

# Deuteronomy - 13

S’il s’élève au milieu de toi un prophète ou un songeur qui t’annonce un signe ou un prodige, [^1] et qu’il y ait accomplissement du signe ou du prodige dont il t’a parlé en disant: Allons après d’autres dieux, des dieux que tu ne connais point, et servons-les! [^2] tu n’écouteras pas les paroles de ce prophète ou de ce songeur, car c’est l’Éternel, votre Dieu, qui vous met à l’épreuve pour savoir si vous aimez l’Éternel, votre Dieu, de tout votre cœur et de toute votre âme. [^3] Vous irez après l’Éternel, votre Dieu, et vous le craindrez; vous observerez ses commandements, vous obéirez à sa voix, #De 10:20.vous le servirez, et vous vous attacherez à lui. [^4] Ce prophète ou ce songeur #De 18:20. Jé 14:15.sera puni de mort, car il a parlé de révolte contre l’Éternel, votre Dieu, qui vous a fait sortir du pays d’Égypte et vous a délivrés de la maison de servitude, et il a voulu te détourner de la voie dans laquelle l’Éternel, ton Dieu, t’a ordonné de marcher. Tu ôteras ainsi le mal du milieu de toi. [^5] Si ton #De 17:2.frère, fils de ta mère, ou ton fils, ou ta fille, ou la femme qui repose sur ton sein, ou ton ami que tu aimes comme toi-même, t’incite secrètement en disant: Allons, et servons d’autres dieux! Des dieux que ni toi ni tes pères n’avez connus, [^6] d’entre les dieux des peuples qui vous entourent, près de toi ou loin de toi, d’une extrémité de la terre à l’autre, [^7] tu n’y consentiras pas, et tu ne l’écouteras pas; tu ne jetteras pas sur lui un regard de pitié, tu ne l’épargneras pas, et tu ne le couvriras pas. [^8] Mais tu le feras mourir; #De 17:7.ta main se lèvera la première sur lui pour le mettre à mort, et la main de tout le peuple ensuite; [^9] tu le lapideras, et il mourra, parce qu’il a cherché à te détourner de l’Éternel, ton Dieu, qui t’a fait sortir du pays d’Égypte, de la maison de servitude. [^10] Il en sera ainsi, afin que #De 17:13.tout Israël entende et craigne, et que l’on ne commette plus un acte aussi criminel au milieu de toi. [^11] Si tu entends dire au sujet de l’une des villes que t’a données pour demeure l’Éternel, ton Dieu: [^12] Des gens pervers sont sortis du milieu de toi, et ont séduit les habitants de leur ville en disant: Allons, et servons d’autres dieux! Des dieux que tu ne connais point [^13] tu feras des recherches, tu examineras, tu interrogeras avec soin. La chose est-elle vraie, le fait est-il établi, cette abomination a-t-elle été commise au milieu de toi, [^14] alors tu frapperas du tranchant de l’épée les habitants de cette ville, tu la dévoueras par interdit avec tout ce qui s’y trouvera, et tu en passeras le bétail au fil de l’épée. [^15] Tu amasseras tout le butin au milieu de la place, et tu brûleras entièrement au feu la ville avec tout son butin, devant l’Éternel, ton Dieu: elle sera pour toujours un monceau de ruines, elle ne sera jamais rebâtie. [^16] Rien de ce qui sera dévoué par interdit ne s’attachera à ta main, afin que l’Éternel revienne de l’ardeur de sa colère, qu’il te fasse miséricorde et grâce, et qu’il te multiplie, comme il l’a juré à tes pères, [^17] si tu obéis à la voix de l’Éternel, ton Dieu, en observant tous ses commandements que je te prescris aujourd’hui, et en faisant ce qui est droit aux yeux de l’Éternel, ton Dieu. [^18] 

[[Deuteronomy - 12|<--]] Deuteronomy - 13 [[Deuteronomy - 14|-->]]

---
# Notes
