---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 8 - Luis Segond (1910)"
---
[[Deuteronomy - 7|<--]] Deuteronomy - 8 [[Deuteronomy - 9|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Deuteronomy]]

# Deuteronomy - 8

Vous observerez et vous mettrez en pratique tous les commandements que je vous prescris aujourd’hui, afin que vous viviez, que vous multipliiez, et que vous entriez en possession du pays que l’Éternel a juré de donner à vos pères. [^1] Souviens-toi de tout le chemin que l’Éternel, ton Dieu, t’a fait faire pendant ces quarante années dans le désert, afin de t’humilier et de t’éprouver, pour savoir quelles étaient les dispositions de ton cœur et si tu garderais ou non ses commandements. [^2] Il t’a humilié, il t’a fait souffrir de la faim, et il t’a nourri de #Ex 16:14, 15.la manne, que tu ne connaissais pas et que n’avaient pas connue tes pères, afin de t’apprendre #Mt 4:4. Lu 4:4.que l’homme ne vit pas de pain seulement, mais que l’homme vit de tout ce qui sort de la bouche de l’Éternel. [^3] #De 29:5. Né 9:21.Ton vêtement ne s’est point usé sur toi, et ton pied ne s’est point enflé, pendant ces quarante années. [^4] Reconnais en ton cœur que l’Éternel, ton Dieu, te châtie comme un homme châtie son enfant. [^5] Tu observeras les commandements de l’Éternel, ton Dieu, pour marcher dans ses voies et pour le craindre. [^6] Car l’Éternel, ton Dieu, va te faire entrer dans un bon pays, pays de cours d’eaux, de sources et de lacs, qui jaillissent dans les vallées et dans les montagnes; [^7] pays de froment, d’orge, de vignes, de figuiers et de grenadiers; pays d’oliviers et de miel; [^8] pays où tu mangeras du pain avec abondance, où tu ne manqueras de rien; pays dont les pierres sont du fer, et des montagnes duquel tu tailleras l’airain. [^9] #De 6:11, 12.Lorsque tu mangeras et te rassasieras, tu béniras l’Éternel, ton Dieu, pour le bon pays qu’il t’a donné. [^10] Garde-toi d’oublier l’Éternel, ton Dieu, au point de ne pas observer ses commandements, ses ordonnances et ses lois, que je te prescris aujourd’hui. [^11] Lorsque tu mangeras et te rassasieras, lorsque tu bâtiras et habiteras de belles maisons, [^12] lorsque tu verras multiplier ton gros et ton menu bétail, s’augmenter ton argent et ton or, et s’accroître tout ce qui est à toi, [^13] prends garde que ton cœur ne s’enfle, et que tu n’oublies l’Éternel, ton Dieu, qui t’a fait sortir du pays d’Égypte, de la maison de servitude, [^14] qui t’a fait marcher dans ce grand et affreux désert, où il y a des serpents brûlants et des scorpions, dans des lieux arides et sans eau, et #Ex 17:6. No 20:11. Ps 78:15; 114:8.qui a fait jaillir pour toi de l’eau du rocher le plus dur, [^15] qui t’a fait manger dans le désert #Ex 16:14, 15.la manne inconnue à tes pères, afin de t’humilier et de t’éprouver, pour te faire ensuite du bien. [^16] Garde-toi de dire en ton cœur: Ma force et la puissance de ma main m’ont acquis ces richesses. [^17] Souviens-toi de l’Éternel, ton Dieu, car c’est lui qui te donnera de la force pour les acquérir, afin de confirmer, comme il le fait aujourd’hui, son alliance qu’il a jurée à tes pères. [^18] Si tu oublies l’Éternel, ton Dieu, et que tu ailles après d’autres dieux, si tu les sers et te prosternes devant eux, je vous déclare formellement aujourd’hui que vous périrez. [^19] Vous périrez comme les nations que l’Éternel fait périr devant vous, parce que vous n’aurez point écouté la voix de l’Éternel, votre Dieu. [^20] 

[[Deuteronomy - 7|<--]] Deuteronomy - 8 [[Deuteronomy - 9|-->]]

---
# Notes
