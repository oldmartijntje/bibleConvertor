---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 27 - Luis Segond (1910)"
---
[[Deuteronomy - 26|<--]] Deuteronomy - 27 [[Deuteronomy - 28|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Deuteronomy]]

# Deuteronomy - 27

Moïse et les anciens d’Israël donnèrent cet ordre au peuple: Observez tous les commandements que je vous prescris aujourd’hui. [^1] #Jos 4:1.Lorsque vous aurez passé le Jourdain, pour entrer dans le pays que l’Éternel, ton Dieu, te donne, tu dresseras de grandes pierres, et tu les enduiras de chaux. [^2] Tu écriras sur ces pierres toutes les paroles de cette loi, lorsque tu auras passé le Jourdain, pour entrer dans le pays que l’Éternel, ton Dieu, te donne, pays où coulent le lait et le miel, comme te l’a dit l’Éternel, le Dieu de tes pères. [^3] Lorsque vous aurez passé le Jourdain, vous dresserez sur le mont Ébal ces pierres que je vous ordonne aujourd’hui de dresser, et tu les enduiras de chaux. [^4] #Ex 20:25. Jos 8:31.Là, tu bâtiras un autel à l’Éternel, ton Dieu, un autel de pierres, sur lesquelles tu ne porteras point le fer; [^5] tu bâtiras en pierres brutes l’autel de l’Éternel, ton Dieu. Tu offriras sur cet autel des holocaustes à l’Éternel, ton Dieu; [^6] tu offriras des sacrifices d’actions de grâces, et tu mangeras là et te réjouiras devant l’Éternel, ton Dieu. [^7] Tu écriras sur ces pierres toutes les paroles de cette loi, en les gravant bien nettement. [^8] Moïse et les sacrificateurs, les Lévites, parlèrent à tout Israël, et dirent: Israël, sois attentif et écoute! Aujourd’hui, tu es devenu le peuple de l’Éternel, ton Dieu. [^9] Tu obéiras à la voix de l’Éternel, ton Dieu, et tu mettras en pratique ses commandements et ses lois que je te prescris aujourd’hui. [^10] Le même jour, Moïse donna cet ordre au peuple: [^11] Lorsque vous aurez passé le Jourdain, Siméon, Lévi, Juda, Issacar, Joseph et Benjamin, se tiendront sur le mont Garizim, pour bénir le peuple; [^12] et Ruben, Gad, Aser, Zabulon, Dan et Nephthali, se tiendront sur le mont Ébal, pour prononcer la malédiction. [^13] Et les Lévites prendront la parole, et diront d’une voix haute à tout Israël: [^14] Maudit soit l’homme qui fait une image taillée ou une image en fonte, abomination de l’Éternel, œuvre des mains d’un artisan, et qui la place dans un lieu secret! Et tout le peuple répondra, et dira: Amen! [^15] Maudit soit celui qui méprise son père et sa mère! Et tout le peuple dira: Amen! [^16] Maudit soit celui qui déplace les bornes de son prochain! Et tout le peuple dira: Amen! [^17] Maudit soit celui qui fait égarer un aveugle dans le chemin! Et tout le peuple dira: Amen! [^18] Maudit soit celui qui porte atteinte au droit de l’étranger, de l’orphelin et de la veuve! Et tout le peuple dira: Amen! [^19] Maudit soit celui qui couche avec la femme de son père, car il soulève la couverture de son père! Et tout le peuple dira: Amen! [^20] Maudit soit celui qui couche avec une bête quelconque! Et tout le peuple dira: Amen! [^21] Maudit soit celui qui couche avec sa sœur, fille de son père ou fille de sa mère! Et tout le peuple dira: Amen! [^22] Maudit soit celui qui couche avec sa belle-mère! Et tout le peuple dira: Amen! [^23] Maudit soit celui qui frappe son prochain en secret! Et tout le peuple dira: Amen! [^24] Maudit soit celui qui reçoit un présent pour répandre le sang de l’innocent! Et tout le peuple dira: Amen! [^25] #Ga 3:10.Maudit soit celui qui n’accomplit point les paroles de cette loi, et qui ne les met point en pratique! Et tout le peuple dira: Amen! [^26] 

[[Deuteronomy - 26|<--]] Deuteronomy - 27 [[Deuteronomy - 28|-->]]

---
# Notes
