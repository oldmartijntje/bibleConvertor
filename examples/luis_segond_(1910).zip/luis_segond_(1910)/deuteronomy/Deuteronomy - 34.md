---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 34 - Luis Segond (1910)"
---
[[Deuteronomy - 33|<--]] Deuteronomy - 34

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Deuteronomy]]

# Deuteronomy - 34

Moïse monta des plaines de Moab sur le mont Nebo, au sommet du Pisga, vis-à-vis de Jéricho. Et l’Éternel lui #De 3:17.fit voir tout le pays: [^1] Galaad jusqu’à Dan, tout Nephthali, le pays d’Éphraïm et de Manassé, tout le pays de Juda jusqu’à la mer occidentale, [^2] le midi, les environs du Jourdain, la vallée de Jéricho, la ville des palmiers, jusqu’à Tsoar. [^3] L’Éternel lui dit: C’est là le pays que j’ai juré de donner à #Ge 12:7; 13:5; 15:18; 26:4; 28:13.Abraham, à Isaac et à Jacob, en disant: Je le donnerai à ta postérité. Je te l’ai fait voir de tes yeux; mais tu n’y entreras point. [^4] Moïse, serviteur de l’Éternel, mourut là, dans le pays de Moab, selon l’ordre de l’Éternel. [^5] Et l’Éternel l’enterra dans la vallée, au pays de Moab, vis-à-vis de Beth-Peor. #Jud v. 9.Personne n’a connu son sépulcre jusqu’à ce jour. [^6] Moïse était âgé de cent vingt ans lorsqu’il mourut; sa vue n’était point affaiblie, et sa vigueur n’était point passée. [^7] Les enfants d’Israël pleurèrent Moïse pendant trente jours, dans les plaines de Moab; et ces jours de pleurs et de deuil sur Moïse arrivèrent à leur terme. [^8] Josué, fils de Nun, était rempli de l’esprit de sagesse, #No 27:18.car Moïse avait posé ses mains sur lui. Les enfants d’Israël lui obéirent, et se conformèrent aux ordres que l’Éternel avait donnés à Moïse. [^9] Il n’a plus paru en Israël de prophète semblable à Moïse, que l’Éternel connaissait face à face. [^10] Nul ne peut lui être comparé pour tous les signes et les miracles que Dieu l’envoya faire au pays d’Égypte contre Pharaon, contre ses serviteurs et contre tout son pays, [^11] et pour tous les prodiges de terreur que Moïse accomplit à main forte sous les yeux de tout Israël. [^12] 

[[Deuteronomy - 33|<--]] Deuteronomy - 34

---
# Notes
