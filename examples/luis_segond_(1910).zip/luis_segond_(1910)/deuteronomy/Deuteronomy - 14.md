---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 14 - Luis Segond (1910)"
---
[[Deuteronomy - 13|<--]] Deuteronomy - 14 [[Deuteronomy - 15|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Deuteronomy]]

# Deuteronomy - 14

Vous êtes les enfants de l’Éternel, votre Dieu. Vous ne vous ferez point #Lé 19:27, 28; 21:5.d’incisions et vous ne vous ferez point de place chauve entre les yeux pour un mort. [^1] Car tu es #De 7:6; 26:18.un peuple saint pour l’Éternel, ton Dieu; et l’Éternel, ton Dieu, t’a choisi, pour que tu fusses un peuple qui lui appartînt entre tous les peuples qui sont sur la face de la terre. [^2] Tu ne mangeras aucune chose abominable. [^3] #Lé 11:2, etc.Voici les animaux que vous mangerez: le bœuf, la brebis et la chèvre; [^4] le cerf, la gazelle et le daim; le bouquetin, le chevreuil, la chèvre sauvage et la girafe. [^5] Vous mangerez de tout animal qui a la corne fendue, le pied fourchu, et qui rumine. [^6] Mais vous ne mangerez pas de ceux qui ruminent seulement, ou qui ont la corne fendue et le pied fourchu seulement. Ainsi, vous ne mangerez pas le chameau, le lièvre et le daman, qui ruminent, mais qui n’ont pas la corne fendue: vous les regarderez comme impurs. [^7] Vous ne mangerez pas le porc, qui a la corne fendue, mais qui ne rumine pas: vous le regarderez comme impur. Vous ne mangerez pas de leur chair, et vous ne toucherez pas leurs corps morts. [^8] Voici les animaux dont vous mangerez parmi tous ceux qui sont dans les eaux: vous mangerez de tous ceux qui ont des nageoires et des écailles. [^9] Mais vous ne mangerez d’aucun de ceux qui n’ont pas des nageoires et des écailles: vous les regarderez comme impurs. [^10] Vous mangerez tout oiseau pur. [^11] Mais voici ceux dont vous ne mangerez pas: l’aigle, l’orfraie et l’aigle de mer; [^12] le milan, l’autour, le vautour et ce qui est de son espèce; [^13] le corbeau et toutes ses espèces; [^14] l’autruche, le hibou, la mouette, l’épervier et ce qui est de son espèce; [^15] le chat-huant, la chouette et le cygne; [^16] le pélican, le cormoran et le plongeon; [^17] la cigogne, le héron et ce qui est de son espèce, la huppe et la chauve-souris. [^18] Vous regarderez comme impur tout reptile qui vole: on n’en mangera point. [^19] Vous mangerez tout oiseau pur. [^20] Vous ne mangerez d’aucune bête morte; tu la donneras à l’étranger qui sera dans tes portes, afin qu’il la mange, ou tu la vendras à un étranger; car tu es un peuple saint pour l’Éternel, ton Dieu. Tu ne feras point cuire un #Ex 23:19; 34:26.chevreau dans le lait de sa mère. [^21] Tu lèveras la dîme de tout ce que produira ta semence, de ce que rapportera ton champ chaque année. [^22] #De 12:17, 18.Et tu mangeras devant l’Éternel, ton Dieu, dans le lieu qu’il choisira pour y faire résider son nom, la dîme de ton blé, de ton moût et de ton huile, et les premiers-nés de ton gros et de ton menu bétail, afin que tu apprennes à craindre toujours l’Éternel, ton Dieu. [^23] Peut-être lorsque l’Éternel, ton Dieu, t’aura béni, le chemin sera-t-il trop long pour que tu puisses transporter ta dîme, à cause de ton éloignement du lieu qu’aura choisi l’Éternel, ton Dieu, pour y faire résider son nom. [^24] Alors, tu échangeras ta dîme contre de l’argent, tu serreras cet argent dans ta main, et tu iras au lieu que l’Éternel, ton Dieu, aura choisi. [^25] Là, tu achèteras avec #Mt 21:12.l’argent tout ce que tu désireras, des bœufs, des brebis, du vin et des liqueurs fortes, tout ce qui te fera plaisir, tu mangeras devant l’Éternel, ton Dieu, et tu te réjouiras, toi et ta famille. [^26] Tu ne délaisseras point le Lévite qui sera dans tes portes, car il n’a ni #No 18:20, 24. De 10:9; 12:12; 18:1, 2; 26:12.part ni héritage avec toi. [^27] Au bout de trois ans, tu sortiras toute la dîme de tes produits pendant la troisième année, et tu la déposeras dans tes portes. [^28] Alors viendront le Lévite, qui n’a ni part ni héritage avec toi, l’étranger, l’orphelin et la veuve, qui seront dans tes portes, et ils mangeront et se rassasieront, afin que l’Éternel, ton Dieu, te bénisse dans tous les travaux que tu entreprendras de tes mains. [^29] 

[[Deuteronomy - 13|<--]] Deuteronomy - 14 [[Deuteronomy - 15|-->]]

---
# Notes
