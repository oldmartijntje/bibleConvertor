---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 24 - Luis Segond (1910)"
---
[[Deuteronomy - 23|<--]] Deuteronomy - 24 [[Deuteronomy - 25|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Deuteronomy]]

# Deuteronomy - 24

Lorsqu’un homme aura pris et épousé une femme qui viendrait à ne pas trouver grâce à ses yeux, parce qu’il a découvert en elle quelque chose de honteux, il écrira pour elle #Mt 5:31; 19:7. Mc 10:4.une lettre de divorce, et, après la lui avoir remise en main, il la renverra de sa maison. [^1] Elle sortira de chez lui, s’en ira, et pourra devenir la femme d’un autre homme. [^2] Si ce dernier homme la prend en aversion, écrit pour elle une lettre de divorce, et, après la lui avoir remise en main, la renvoie de sa maison; ou bien, si ce dernier homme qui l’a prise pour femme vient à mourir, [^3] alors le premier mari qui l’avait renvoyée ne pourra pas la reprendre pour femme après qu’elle a été souillée, car c’est une abomination devant l’Éternel, et tu ne chargeras point de péché le pays que l’Éternel, ton Dieu, te donne pour héritage. [^4] Lorsqu’un homme sera nouvellement #De 20:7.marié, il n’ira point à l’armée, et on ne lui imposera aucune charge; il sera exempté par raison de famille pendant un an, et il réjouira la femme qu’il a prise. [^5] On ne prendra point pour gage les deux meules, ni la meule de dessus; car ce serait prendre pour gage la vie même. [^6] Si l’on trouve un homme qui ait #Ex 21:16.dérobé l’un de ses frères, l’un des enfants d’Israël, qui en ait fait son esclave ou qui l’ait vendu, ce voleur sera puni de mort. Tu ôteras ainsi le mal du milieu de toi. [^7] Prends garde à la plaie de la lèpre, afin de bien observer et de faire tout ce que vous enseigneront les sacrificateurs, les Lévites; vous aurez soin d’agir d’après les ordres #Lé 13:2.que je leur ai donnés. [^8] Souviens-toi de ce que l’Éternel, ton Dieu, fit à #No 12:10.Marie pendant la route, lors de votre sortie d’Égypte. [^9] Si tu fais à ton prochain un prêt quelconque, tu n’entreras point dans sa maison pour te saisir de son gage; [^10] tu resteras dehors, et celui à qui tu fais le prêt t’apportera le gage dehors. [^11] Si cet homme est pauvre, tu ne te coucheras point, en retenant son gage; [^12] tu le lui #Ex 22:26.rendras au coucher du soleil, afin qu’il couche dans son vêtement et qu’il te bénisse; et cela te sera imputé à justice devant l’Éternel, ton Dieu. [^13] Tu #Lé 19:13. Ja 5:4.n’opprimeras point le mercenaire, pauvre et indigent, qu’il soit l’un de tes frères, ou l’un des étrangers demeurant dans ton pays, dans tes portes. [^14] Tu lui donneras le salaire de sa journée avant le coucher du soleil; car il est pauvre, et il lui tarde de le recevoir. Sans cela, il crierait à l’Éternel contre toi, et tu te chargerais d’un péché. [^15] On ne fera point mourir les pères #2 Ch 14:6. 2 Ch 25:4. Jé 31:30. Éz 18:20.pour les enfants, et l’on ne fera point mourir les enfants pour les pères; on fera mourir chacun pour son péché. [^16] Tu ne porteras point atteinte au droit de #Ex 22:21, 22. Pr 22:22. És 1:23. Jé 5:28; 22:3. Éz 22:29. Za 7:10.l’étranger et de l’orphelin, et tu ne prendras point en gage le vêtement de la veuve. [^17] Tu te souviendras que tu as été esclave en Égypte, et que l’Éternel, ton Dieu, t’a racheté; c’est pourquoi je te donne ces commandements à mettre en pratique. [^18] Quand tu #Lé 19:9; 23:22.moissonneras ton champ, et que tu auras oublié une gerbe dans le champ, tu ne retourneras point la prendre: elle sera pour l’étranger, pour l’orphelin et pour la veuve, afin que l’Éternel, ton Dieu, te bénisse dans tout le travail de tes mains. [^19] Quand tu secoueras tes oliviers, tu ne cueilleras point ensuite les fruits restés aux branches: ils seront pour l’étranger, pour l’orphelin et pour la veuve. [^20] Quand tu vendangeras ta vigne, tu ne cueilleras point ensuite les grappes qui y seront restées: elles seront pour l’étranger, pour l’orphelin et pour la veuve. [^21] Tu te souviendras que tu as été esclave dans le pays d’Égypte; c’est pourquoi je te donne ces commandements à mettre en pratique. [^22] 

[[Deuteronomy - 23|<--]] Deuteronomy - 24 [[Deuteronomy - 25|-->]]

---
# Notes
