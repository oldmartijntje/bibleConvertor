---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 23 - Luis Segond (1910)"
---
[[Deuteronomy - 22|<--]] Deuteronomy - 23 [[Deuteronomy - 24|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Deuteronomy]]

# Deuteronomy - 23

Celui dont les testicules ont été écrasés ou l’urètre coupé n’entrera point dans l’assemblée de l’Éternel. [^1] Celui qui est issu d’une union illicite n’entrera point dans l’assemblée de l’Éternel; même sa dixième génération n’entrera point dans l’assemblée de l’Éternel. [^2] #Né 13:1.L’Ammonite et le Moabite n’entreront point dans l’assemblée de l’Éternel, même à la dixième génération et à perpétuité, [^3] parce qu’ils ne sont pas venus au-devant de vous avec du pain et de l’eau, sur le chemin, lors de votre sortie d’Égypte, et parce qu’ils ont fait venir contre toi à prix d’argent #No 22:3, 4, 5, etc.Balaam, fils de Beor, de Pethor en Mésopotamie, pour qu’il te maudisse. [^4] Mais l’Éternel, ton Dieu, n’a point voulu écouter Balaam; et l’Éternel, ton Dieu, a changé pour toi la malédiction en bénédiction, parce que tu es aimé de l’Éternel, ton Dieu. [^5] Tu n’auras souci ni de leur prospérité ni de leur bien-être, tant que tu vivras, à perpétuité. [^6] Tu n’auras point en abomination l’Édomite, car il est ton frère; tu n’auras point en abomination l’Égyptien, car tu as été étranger dans son pays: [^7] les fils qui leur naîtront à la troisième génération entreront dans l’assemblée de l’Éternel. [^8] Lorsque tu camperas contre tes ennemis, garde-toi de toute chose mauvaise. [^9] S’il y a chez toi un homme qui ne soit pas pur, par suite d’un accident nocturne, il sortira du camp, et n’entrera point dans le camp; [^10] sur le soir il se lavera dans l’eau, et après le coucher du soleil il pourra rentrer au camp. [^11] Tu auras un lieu hors du camp, et c’est là dehors que tu iras. [^12] Tu auras parmi ton bagage un instrument, dont tu te serviras pour faire un creux et recouvrir tes excréments, quand tu voudras aller dehors. [^13] Car l’Éternel, ton Dieu, marche au milieu de ton camp pour te protéger et pour livrer tes ennemis devant toi; ton camp devra donc être saint, afin que l’Éternel ne voie chez toi rien d’impur, et qu’il ne se détourne point de toi. [^14] Tu ne livreras point à son maître un esclave qui se réfugiera chez toi, après l’avoir quitté. [^15] Il demeurera chez toi, au milieu de toi, dans le lieu qu’il choisira, dans l’une de tes villes, où bon lui semblera: tu ne l’opprimeras point. [^16] Il n’y aura aucune prostituée parmi les filles d’Israël, et il n’y aura aucun prostitué parmi les fils d’Israël. [^17] Tu n’apporteras point dans la maison de l’Éternel, ton Dieu, le salaire d’une prostituée ni le prix d’un chien, pour l’accomplissement d’un vœu quelconque; car l’un et l’autre sont en abomination à l’Éternel, ton Dieu. [^18] Tu n’exigeras de ton frère aucun #Ex 22:25. Lé 25:36. Né 5:2, etc. Lu 6:34, 35.intérêt ni pour argent, ni pour vivres, ni pour rien de ce qui se prête à intérêt. [^19] Tu pourras tirer un intérêt de l’étranger, mais tu n’en tireras point de ton frère, afin que l’Éternel, ton Dieu, te bénisse dans tout ce que tu entreprendras au pays dont tu vas entrer en possession. [^20] Si tu fais #No 30:2.un vœu à l’Éternel, ton Dieu, tu ne tarderas point à l’accomplir: car l’Éternel, ton Dieu, t’en demanderait compte, et tu te chargerais d’un péché. [^21] Si tu t’abstiens de faire un vœu, tu ne commettras pas un péché. [^22] Mais tu observeras et tu accompliras ce qui sortira de tes lèvres, par conséquent les vœux que tu feras volontairement à l’Éternel, ton Dieu, et que ta bouche aura prononcés. [^23] Si tu entres dans la vigne de ton prochain, tu pourras à ton gré manger des raisins et t’en rassasier; mais tu n’en mettras point dans ton vase. [^24] Si tu entres dans #Mt 12:1.les blés de ton prochain, tu pourras cueillir des épis avec la main, mais tu n’agiteras point la faucille sur les blés de ton prochain. [^25] 

[[Deuteronomy - 22|<--]] Deuteronomy - 23 [[Deuteronomy - 24|-->]]

---
# Notes
