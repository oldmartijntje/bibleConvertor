---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 10 - Luis Segond (1910)"
---
[[Deuteronomy - 9|<--]] Deuteronomy - 10 [[Deuteronomy - 11|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Deuteronomy]]

# Deuteronomy - 10

En ce temps-là, l’Éternel me dit: #Ex 34:1.Taille deux tables de pierre comme les premières, et monte vers moi sur la montagne; tu feras aussi une arche de bois. [^1] J’écrirai sur ces tables les paroles qui étaient sur les premières tables que tu as brisées, et tu les mettras dans l’arche. [^2] Je fis une arche de bois d’acacia, je taillai deux tables de pierre comme les premières, et je montai sur la montagne, les deux tables dans ma main. [^3] L’Éternel écrivit sur les tables ce qui avait été écrit sur les premières, les dix paroles qu’il vous avait dites sur la montagne, du milieu du feu, le jour de l’assemblée; et l’Éternel me les donna. [^4] Je retournai et je descendis de la montagne, je mis les tables dans l’arche que j’avais faite, et elles restèrent là, comme l’Éternel me l’avait ordonné. [^5] Les enfants d’Israël #No 33:30.partirent de Beéroth-Bené Jaakan pour Moséra. C’est là que #No 20:28; 33:38.mourut Aaron, et qu’il fut enterré; Éléazar, son fils, lui succéda dans le sacerdoce. [^6] Ils partirent de là pour Gudgoda, et de #No 33:32, 33.Gudgoda pour Jothbatha, pays où il y a des cours d’eaux. [^7] En ce temps-là, l’Éternel sépara la tribu de Lévi, et lui ordonna de porter l’arche de l’alliance de l’Éternel, de se tenir devant l’Éternel pour le servir, et de bénir le peuple en son nom: ce qu’elle a fait jusqu’à ce jour. [^8] C’est pourquoi Lévi #No 18:20, 21, etc. De 18:1. Éz 44:28.n’a ni part ni héritage avec ses frères: l’Éternel est son héritage, comme l’Éternel, ton Dieu, le lui a dit. [^9] Je restai sur la montagne, comme précédemment, #De 9:18.quarante jours et quarante nuits. L’Éternel #De 9:19.m’exauça encore cette fois; l’Éternel ne voulut pas te détruire. [^10] L’Éternel me dit: Lève-toi, va, marche à la tête du peuple. Qu’ils aillent prendre possession du pays que j’ai juré à leurs pères de leur donner. [^11] Maintenant, Israël, que demande de toi l’Éternel, ton Dieu, si ce n’est que tu craignes l’Éternel, ton Dieu, afin de marcher dans toutes ses voies, d’aimer et de #De 6:5. Mt 22:37. Lu 10:27.servir l’Éternel, ton Dieu, de tout ton cœur et de toute ton âme; [^12] si ce n’est que tu observes les commandements de l’Éternel et ses lois que je te prescris aujourd’hui, afin que tu sois heureux? [^13] Voici, à l’Éternel, ton Dieu, appartiennent les cieux et les cieux des cieux, #Ge 14:19. Ps 24:1; 115:16.la terre et tout ce qu’elle renferme. [^14] Et c’est à tes pères seulement que l’Éternel s’est attaché pour les aimer; et, après eux, c’est leur postérité, c’est vous qu’il a choisis d’entre tous les peuples, comme vous le voyez aujourd’hui. [^15] Vous circoncirez donc #Jé 4:4.votre cœur, et vous ne roidirez plus #Ex 32:9; 33:3; 34:9. De 9:13.votre cou. [^16] Car l’Éternel, votre Dieu, est le Dieu des dieux, #Ap 17:14.le Seigneur des seigneurs, le Dieu grand, fort et terrible, qui #2 Ch 19:6, 7. Job 34:19. Ac 10:34. Ro 2:11. Ga 2:6. Ép 6:9. Col 3:25. 1 Pi 1:17.ne fait point acception des personnes et qui ne reçoit point de présent, [^17] qui fait droit à l’orphelin et à la veuve, qui aime l’étranger et lui donne de la nourriture et des vêtements. [^18] Vous aimerez l’étranger, car vous avez été étrangers dans le pays d’Égypte. [^19] Tu #De 6:13. Mt 4:10. Lu 4:8.craindras l’Éternel, ton Dieu, tu le serviras, tu #De 13:4.t’attacheras à lui, et tu jureras par son nom. [^20] Il est ta gloire, il est ton Dieu: c’est lui qui a fait au milieu de toi ces choses grandes et terribles que tes yeux ont vues. [^21] Tes pères descendirent en Égypte au nombre de #Ge 46:27. Ex 1:5. Ac 7:14.soixante-dix personnes; et maintenant l’Éternel, ton Dieu, a fait de toi une multitude #Ge 15:5.pareille aux étoiles des cieux. [^22] 

[[Deuteronomy - 9|<--]] Deuteronomy - 10 [[Deuteronomy - 11|-->]]

---
# Notes
