---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 19 - Luis Segond (1910)"
---
[[Deuteronomy - 18|<--]] Deuteronomy - 19 [[Deuteronomy - 20|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Deuteronomy]]

# Deuteronomy - 19

Lorsque l’Éternel, ton Dieu, aura exterminé les nations dont l’Éternel, ton Dieu, te donne le pays, lorsque tu les auras chassées et que tu habiteras dans leurs villes et dans leurs maisons, [^1] #Ex 21:13. No 35:9, etc. Jos 20:2.tu sépareras trois villes au milieu du pays dont l’Éternel, ton Dieu, te donne la possession. [^2] Tu établiras des routes, et tu diviseras en trois parties le territoire du pays que l’Éternel, ton Dieu, va te donner en héritage. Il en sera ainsi afin que tout meurtrier puisse s’enfuir dans ces villes. [^3] Cette loi s’appliquera au meurtrier qui s’enfuira là pour sauver sa vie, #Ex 21:13. De 4:41, 42.lorsqu’il aura involontairement tué son prochain, sans avoir été auparavant son ennemi. [^4] Un homme, par exemple, va couper du bois dans la forêt avec un autre homme; la hache en main, il s’élance pour abattre un arbre; le fer échappe du manche, atteint le compagnon de cet homme, et lui donne la mort. Alors il s’enfuira dans l’une de ces villes pour sauver sa vie, [^5] de peur que le vengeur du sang, échauffé par la colère et poursuivant le meurtrier, ne finisse par l’atteindre s’il y avait à faire beaucoup de chemin, et ne frappe mortellement celui qui ne mérite pas la mort, puisqu’il n’était point auparavant l’ennemi de son prochain. [^6] C’est pourquoi je te donne cet ordre: Tu sépareras trois villes. [^7] Lorsque l’Éternel, ton Dieu, aura élargi tes frontières, comme il l’a juré à tes pères, et qu’il t’aura donné tout le pays qu’il a #Ge 28:13. De 12:20.promis à tes pères de te donner, [^8] pourvu que tu observes et mettes en pratique tous ces commandements que je te prescris aujourd’hui, en sorte que tu aimes l’Éternel, ton Dieu, et que tu marches toujours dans ses voies, tu ajouteras #Jos 20:7.encore trois villes à ces trois-là, [^9] afin que le sang innocent ne soit pas répandu au milieu du pays que l’Éternel, ton Dieu, te donne pour héritage, et que tu ne sois pas coupable de meurtre. [^10] Mais #Ge 9:6. Ex 21:12, 14. Lé 24:17. No 35:16.si un homme s’enfuit dans une de ces villes, après avoir dressé des embûches à son prochain par inimitié contre lui, après l’avoir attaqué et frappé de manière à causer sa mort, [^11] les anciens de sa ville l’enverront saisir et le livreront entre les mains du vengeur du sang, afin qu’il meure. [^12] Tu ne jetteras pas sur lui un regard de pitié, tu feras disparaître d’Israël le sang innocent, et tu seras heureux. [^13] #    
        Pr 22:28.  Tu ne reculeras point les bornes de ton prochain, posées par tes ancêtres, dans l’héritage que tu auras au pays dont l’Éternel, ton Dieu, te donne la possession. [^14] #No 35:50. De 17:6. Mt 18:16.Un seul témoin ne suffira pas contre un homme pour constater un crime ou un péché, quel qu’il soit; un fait ne pourra s’établir que #De 17:5. Jn 8:17. 2 Co 13:1. Hé 10:28.sur la déposition de deux ou de trois témoins. [^15] Lorsqu’un faux témoin s’élèvera contre quelqu’un pour l’accuser d’un crime, [^16] les deux hommes en contestation comparaîtront devant l’Éternel, devant les sacrificateurs et les juges alors en fonction. [^17] Les juges feront avec soin des recherches. Le témoin est-il un faux témoin, a-t-il fait contre son frère une fausse déposition, [^18] #Pr 19:5.alors vous le traiterez comme il avait dessein de traiter son frère. Tu ôteras ainsi le mal du milieu de toi. [^19] Les autres entendront et craindront, et l’on ne commettra plus un acte aussi criminel au milieu de toi. [^20] Tu ne jetteras aucun regard de pitié: #Ex 21:23. Lé 24:20. Mt 5:38.œil pour œil, dent pour dent, main pour main, pied pour pied. [^21] 

[[Deuteronomy - 18|<--]] Deuteronomy - 19 [[Deuteronomy - 20|-->]]

---
# Notes
