---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 12 - Luis Segond (1910)"
---
[[Leviticus - 11|<--]] Leviticus - 12 [[Leviticus - 13|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Leviticus]]

# Leviticus - 12

L’Éternel parla à Moïse, et dit: [^1] Parle aux enfants d’Israël, et dis: Lorsqu’une femme deviendra enceinte, et qu’elle enfantera un mâle, elle sera impure pendant sept jours; elle sera impure comme au temps de son indisposition menstruelle. [^2] #Ge 17:12. Lu 1:59; 2:21. Jn 7:22.Le huitième jour, l’enfant sera circoncis. [^3] Elle restera encore trente-trois jours à se purifier de son sang; elle ne touchera aucune chose sainte, et elle n’ira point au sanctuaire, jusqu’à ce que les jours de sa purification soient accomplis. [^4] Si elle enfante une fille, elle sera impure pendant deux semaines, comme au temps de son indisposition menstruelle; elle restera soixante-six jours à se purifier de son sang. [^5] Lorsque les jours de sa purification seront accomplis, pour un fils ou pour une fille, elle apportera au sacrificateur, à l’entrée de la tente d’assignation, un agneau d’un an pour l’holocauste, et un jeune pigeon ou une tourterelle pour le sacrifice d’expiation. [^6] Le sacrificateur les sacrifiera devant l’Éternel, et fera pour elle l’expiation; et elle sera purifiée du flux de son sang. Telle est la loi pour la femme qui enfante un fils ou une fille. [^7] Si elle n’a pas de quoi se procurer un agneau, elle prendra deux tourterelles ou deux jeunes pigeons, l’un pour l’holocauste, l’autre pour le sacrifice d’expiation. Le sacrificateur fera pour elle l’expiation, et elle sera pure. [^8] 

[[Leviticus - 11|<--]] Leviticus - 12 [[Leviticus - 13|-->]]

---
# Notes
