---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 2 - Luis Segond (1910)"
---
[[Leviticus - 1|<--]] Leviticus - 2 [[Leviticus - 3|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Leviticus]]

# Leviticus - 2

Lorsque quelqu’un fera à l’Éternel une offrande #Ex 6:14; 9:17. No 15:4.en don, son offrande sera de fleur de farine; il versera de l’huile dessus, et il y ajoutera de l’encens. [^1] Il l’apportera aux sacrificateurs, fils d’Aaron; le sacrificateur prendra une poignée de cette fleur de farine, arrosée d’huile, avec tout l’encens, et #Lé 6:15.il brûlera cela sur l’autel comme souvenir. C’est une offrande d’une agréable odeur à l’Éternel. [^2] Ce qui restera #Lé 10:12.de l’offrande sera pour Aaron et pour ses fils; c’est une chose très sainte parmi les offrandes consumées par le feu devant l’Éternel. [^3] Si tu fais une offrande de ce qui est cuit au four, qu’on se serve de fleur de farine, et que ce soient des gâteaux sans levain pétris à l’huile et des galettes sans levain arrosées d’huile. [^4] Si ton offrande est un gâteau cuit à la poêle, il sera de fleur de farine pétrie à l’huile, sans levain. [^5] Tu le rompras en morceaux, et tu verseras de l’huile dessus; c’est une offrande. [^6] Si ton offrande est un gâteau cuit sur le gril, il sera fait de fleur de farine pétrie à l’huile. [^7] Tu apporteras l’offrande qui sera faite à l’Éternel avec ces choses-là; elle sera remise au sacrificateur, qui la présentera sur l’autel. [^8] Le sacrificateur en prélèvera ce qui doit être offert comme souvenir, et le brûlera sur l’autel. C’est une offrande d’une agréable odeur à l’Éternel. [^9] Ce qui restera de l’offrande sera pour Aaron et pour ses fils; c’est une chose très sainte parmi les offrandes consumées par le feu devant l’Éternel. [^10] Aucune des offrandes que vous présenterez à l’Éternel ne sera faite avec du levain; car vous ne brûlerez rien qui contienne du levain ou du miel parmi les offrandes consumées par le feu devant l’Éternel. [^11] Vous pourrez en offrir à l’Éternel comme offrande des prémices; mais il n’en sera point présenté sur l’autel comme offrande d’une agréable odeur. [^12] Tu mettras du sel sur toutes tes offrandes; tu ne laisseras point ton offrande manquer de sel, signe de l’alliance de ton Dieu; #Mc 9:49.sur toutes tes offrandes tu mettras du sel. [^13] Si tu fais à l’Éternel une offrande des prémices, tu présenteras des épis nouveaux, rôtis au feu et broyés, comme offrande de tes prémices. [^14] Tu verseras de l’huile dessus, et tu y ajouteras de l’encens; c’est une offrande. [^15] Le sacrificateur brûlera comme souvenir une portion des épis broyés et de l’huile, avec tout l’encens. C’est une offrande consumée par le feu devant l’Éternel. [^16] 

[[Leviticus - 1|<--]] Leviticus - 2 [[Leviticus - 3|-->]]

---
# Notes
