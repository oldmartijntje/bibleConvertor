---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 9 - Luis Segond (1910)"
---
[[Leviticus - 8|<--]] Leviticus - 9 [[Leviticus - 10|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Leviticus]]

# Leviticus - 9

Le huitième jour, Moïse appela Aaron et ses fils, et les anciens d’Israël. [^1] Il dit à Aaron: #Ex 29:1.Prends un jeune veau pour le sacrifice d’expiation, et un bélier pour l’holocauste, l’un et l’autre sans défaut, et sacrifie-les devant l’Éternel. [^2] Tu parleras aux enfants d’Israël, et tu diras: Prenez un bouc, pour le sacrifice d’expiation, un veau et un agneau, âgés d’un an et sans défaut, pour l’holocauste; [^3] un bœuf et un bélier, pour le sacrifice d’actions de grâces, afin de les sacrifier devant l’Éternel; et une offrande pétrie à l’huile. Car aujourd’hui l’Éternel vous apparaîtra. [^4] Ils amenèrent devant la tente d’assignation ce que Moïse avait ordonné; et toute l’assemblée s’approcha, et se tint devant l’Éternel. [^5] Moïse dit: Vous ferez ce que l’Éternel a ordonné; et la gloire de l’Éternel vous apparaîtra. [^6] Moïse dit à Aaron: Approche-toi de l’autel; offre ton #Lé 16:6. Hé 7:27.sacrifice d’expiation et ton holocauste, et fais l’expiation pour toi et pour le peuple; offre aussi le sacrifice du peuple, et fais l’expiation pour lui, comme l’Éternel l’a ordonné. [^7] Aaron s’approcha de l’autel, et il égorgea le veau pour son sacrifice d’expiation. [^8] Les fils d’Aaron lui présentèrent le sang; il trempa son doigt dans le sang, en mit sur les cornes de l’autel, et répandit le sang au pied de l’autel. [^9] Il brûla sur l’autel la graisse, les rognons, et le grand lobe du foie de la victime expiatoire, comme l’Éternel l’avait ordonné à Moïse. [^10] Mais il brûla au feu hors du camp la chair et la peau. [^11] Il égorgea l’holocauste. Les fils d’Aaron lui présentèrent le sang, et il le répandit sur l’autel tout autour. [^12] Ils lui présentèrent l’holocauste coupé par morceaux, avec la tête, et il les brûla sur l’autel. [^13] Il lava les entrailles et les jambes, et il les brûla sur l’autel, par dessus l’holocauste. [^14] Ensuite, il offrit le sacrifice #Lé 4:13.du peuple. Il prit le bouc pour le sacrifice expiatoire du peuple, il l’égorgea, et l’offrit en expiation, comme la première victime. [^15] Il offrit l’holocauste, et le sacrifia, d’après les règles établies. [^16] Il présenta #Lé 2:1.l’offrande, en prit une poignée, et la brûla sur l’autel, outre #Ex 29:38, etc.l’holocauste du matin. [^17] Il égorgea le bœuf et le bélier, en sacrifice d’actions de grâces pour le peuple. Les fils d’Aaron lui présentèrent le sang, et il le répandit sur l’autel tout autour. [^18] Ils lui présentèrent la graisse du bœuf et du bélier, la queue, la graisse qui couvre les entrailles, les rognons, et le grand lobe du foie; [^19] ils mirent les graisses sur les poitrines, et il brûla les graisses sur l’autel. [^20] Aaron agita de côté et d’autre devant l’Éternel les poitrines et #Lé 7:32.l’épaule droite, comme Moïse l’avait ordonné. [^21] Aaron leva ses mains vers le peuple, et il le bénit. Puis il descendit, après avoir offert le sacrifice d’expiation, l’holocauste et le sacrifice d’actions de grâces. [^22] Moïse et Aaron entrèrent dans la tente d’assignation. Lorsqu’ils en sortirent, ils bénirent le peuple. Et la gloire de l’Éternel apparut à tout le peuple. [^23] #1 R 18:38. 2 R 7:1.Le feu sortit de devant l’Éternel, et consuma sur l’autel l’holocauste et les graisses. Tout le peuple le vit; et ils poussèrent des cris de joie, et se jetèrent sur leur face. [^24] 

[[Leviticus - 8|<--]] Leviticus - 9 [[Leviticus - 10|-->]]

---
# Notes
