---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 18 - Luis Segond (1910)"
---
[[Leviticus - 17|<--]] Leviticus - 18 [[Leviticus - 19|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Leviticus]]

# Leviticus - 18

L’Éternel parla à Moïse, et dit: [^1] Parle aux enfants d’Israël, et tu leur diras: Je suis l’Éternel, votre Dieu. [^2] Vous ne ferez point ce qui se fait dans le pays d’Égypte où vous avez habité, et vous ne ferez point ce qui se fait dans le pays de Canaan où je vous mène: vous ne suivrez point leurs usages. [^3] Vous pratiquerez mes ordonnances, et vous observerez mes lois: vous les suivrez. Je suis l’Éternel, votre Dieu. [^4] Vous observerez mes lois et mes ordonnances: #Éz 20:11, 13. Ro 10:5. Ga 3:12.l’homme qui les mettra en pratique vivra par elles. Je suis l’Éternel. [^5] Nul de vous ne s’approchera de sa parente, pour découvrir sa nudité. Je suis l’Éternel. [^6] Tu ne découvriras point la nudité de ton père, ni la nudité de ta mère. C’est ta mère: tu ne découvriras point sa nudité. [^7] #Lé 20:11. 1 Co 5:1.Tu ne découvriras point la nudité de la femme de ton père. C’est la nudité de ton père. [^8] Tu ne découvriras point la nudité de ta sœur, fille de ton père ou fille de ta mère, née dans la maison ou née hors de la maison. [^9] Tu ne découvriras point la nudité de la fille de ton fils ou de la fille de ta fille. Car c’est ta nudité. [^10] #Lé 20:17.Tu ne découvriras point la nudité de la fille de la femme de ton père, née de ton père. C’est ta sœur. [^11] #Lé 20:19.Tu ne découvriras point la nudité de la sœur de ton père. C’est la proche parente de ton père. [^12] Tu ne découvriras point la nudité de la sœur de ta mère. Car c’est la proche parente de ta mère. [^13] #Lé 20:20. Éz 22:11.Tu ne découvriras point la nudité du frère de ton père. Tu ne t’approcheras point de sa femme. C’est ta tante. [^14] #Lé 20:12.Tu ne découvriras point la nudité de ta belle-fille. C’est la femme de ton fils: tu ne découvriras point sa nudité. [^15] #Lé 20:21.Tu ne découvriras point la nudité de la femme de ton frère. C’est la nudité de ton frère. [^16] #Lé 20:14.Tu ne découvriras point la nudité d’une femme et de sa fille. Tu ne prendras point la fille de son fils, ni la fille de sa fille, pour découvrir leur nudité. Ce sont tes proches parentes: c’est un crime. [^17] Tu ne prendras point la sœur de ta femme, pour exciter une rivalité, en découvrant sa nudité à côté de ta femme pendant sa vie. [^18] #Lé 20:18.Tu ne t’approcheras point d’une femme pendant son impureté menstruelle, pour découvrir sa nudité. [^19] #Lé 20:10.Tu n’auras point commerce avec la femme de ton prochain, pour te souiller avec elle. [^20] #Lé 20:2. De 18:10. 2 R 17:17; 23:10.Tu ne livreras aucun de tes enfants pour le faire passer à Moloc, et tu ne profaneras point le nom de ton Dieu. Je suis l’Éternel. [^21] #Lé 20:13.Tu ne coucheras point avec un homme comme on couche avec une femme. C’est une abomination. [^22] #Lé 20:15, 16.Tu ne coucheras point avec une bête, pour te souiller avec elle. La femme ne s’approchera point d’une bête, pour se prostituer à elle. C’est une confusion. [^23] Ne vous souillez par aucune de ces choses, car c’est par toutes ces choses que se sont souillées les nations que je vais chasser devant vous. [^24] Le pays en a été souillé; je punirai son iniquité, et le pays vomira ses habitants. [^25] #Lé 20:22.Vous observerez donc mes lois et mes ordonnances, et vous ne commettrez aucune de ces abominations, ni l’indigène, ni l’étranger qui séjourne au milieu de vous. [^26] Car ce sont là toutes les abominations qu’ont commises les hommes du pays, qui y ont été avant vous; et le pays en a été souillé. [^27] Prenez garde que le pays ne vous vomisse, si vous le souillez, comme il aura vomi les nations qui y étaient avant vous. [^28] Car tous ceux qui commettront quelqu’une de ces abominations seront retranchés du milieu de leur peuple. [^29] Vous observerez mes commandements, et vous ne pratiquerez aucun des usages abominables qui se pratiquaient avant vous, vous ne vous en souillerez pas. Je suis l’Éternel, votre Dieu. [^30] 

[[Leviticus - 17|<--]] Leviticus - 18 [[Leviticus - 19|-->]]

---
# Notes
