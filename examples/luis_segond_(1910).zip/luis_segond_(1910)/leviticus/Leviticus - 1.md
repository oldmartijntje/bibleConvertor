---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 1 - Luis Segond (1910)"
---
Leviticus - 1 [[Leviticus - 2|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Leviticus]]

# Leviticus - 1

L’Éternel appela Moïse; de la tente d’assignation, il lui parla et dit: [^1] Parle aux enfants d’Israël, et dis-leur: Lorsque quelqu’un d’entre vous fera une offrande à l’Éternel, il offrira du bétail, du gros ou du menu bétail. [^2] Si son offrande est un holocauste de gros bétail, il offrira un mâle sans défaut; #Ex 29:10.il l’offrira à l’entrée de la tente d’assignation, devant l’Éternel, pour obtenir sa faveur. [^3] Il posera sa main sur la tête de l’holocauste, qui sera agréé de l’Éternel, pour lui servir d’expiation. [^4] Il égorgera le veau devant l’Éternel; et les sacrificateurs, fils d’Aaron, offriront le sang, et le répandront tout autour sur l’autel qui est à l’entrée de la tente d’assignation. [^5] Il dépouillera l’holocauste, et le coupera par morceaux. [^6] Les fils du sacrificateur Aaron mettront du feu sur l’autel, et arrangeront du bois sur le feu. [^7] Les sacrificateurs, fils d’Aaron, poseront les morceaux, la tête et la graisse, sur le bois mis au feu sur l’autel. [^8] Il lavera avec de l’eau les entrailles et les jambes; et le sacrificateur brûlera le tout sur l’autel. C’est un holocauste, un sacrifice consumé par le feu, d’une agréable odeur à l’Éternel. [^9] Si son offrande est un holocauste de menu bétail, d’agneaux ou de chèvres, il offrira un mâle sans défaut. [^10] Il l’égorgera au côté septentrional de l’autel, devant l’Éternel; et les sacrificateurs, fils d’Aaron, en répandront le sang sur l’autel tout autour. [^11] Il le coupera par morceaux; et le sacrificateur les posera, avec la tête et la graisse, sur le bois mis au feu sur l’autel. [^12] Il lavera avec de l’eau les entrailles et les jambes; et le sacrificateur sacrifiera le tout, et le brûlera sur l’autel. C’est un holocauste, un sacrifice consumé par le feu, d’une agréable odeur à l’Éternel. [^13] Si son offrande à l’Éternel est un holocauste d’oiseaux, il offrira des tourterelles ou de jeunes pigeons. [^14] Le sacrificateur sacrifiera l’oiseau sur l’autel; il lui ouvrira la tête avec l’ongle, et la brûlera sur l’autel, et il exprimera le sang contre un côté de l’autel. [^15] Il ôtera le jabot avec ses plumes, et le jettera près de l’autel, vers l’orient, dans le lieu où l’on met les cendres. [^16] Il déchirera les ailes, sans les détacher; et le sacrificateur brûlera l’oiseau sur l’autel, sur le bois mis au feu. C’est un holocauste, un sacrifice consumé par le feu, d’une agréable odeur à l’Éternel. [^17] 

Leviticus - 1 [[Leviticus - 2|-->]]

---
# Notes
