---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 3 - Luis Segond (1910)"
---
[[Leviticus - 2|<--]] Leviticus - 3 [[Leviticus - 4|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Leviticus]]

# Leviticus - 3

Lorsque quelqu’un offrira à l’Éternel un sacrifice d’actions de grâces: S’il offre du gros bétail, mâle ou femelle, il l’offrira sans défaut, devant l’Éternel. [^1] Il posera sa main sur la tête de la victime, qu’il égorgera à l’entrée de la tente d’assignation; et les sacrificateurs, fils d’Aaron, répandront le sang sur l’autel tout autour. [^2] De ce sacrifice d’actions de grâces, il offrira en sacrifice consumé par le feu devant l’Éternel: #Ex 29:13, 22.la graisse qui couvre les entrailles et toute celle qui y est attachée; [^3] les deux rognons, et la graisse qui les entoure, qui couvre les flancs, et le grand lobe du foie, qu’il détachera près des rognons. [^4] Les fils d’Aaron brûleront cela #Ex 29:25. Lé 6:12.sur l’autel, par-dessus l’holocauste qui sera sur le bois mis au feu. C’est un sacrifice consumé par le feu, d’une agréable odeur à l’Éternel. [^5] S’il offre du menu bétail, mâle ou femelle, en sacrifice d’actions de grâces à l’Éternel, il l’offrira sans défaut. [^6] S’il offre en sacrifice un agneau, il le présentera devant l’Éternel. [^7] Il posera sa main sur la tête de la victime, qu’il égorgera devant la tente d’assignation; et les fils d’Aaron en répandront le sang sur l’autel tout autour. [^8] De ce sacrifice d’actions de grâces, il offrira en sacrifice consumé par le feu devant l’Éternel: la graisse, la queue entière, qu’il séparera près de l’échine, la graisse qui couvre les entrailles et toute celle qui y est attachée, [^9] les deux rognons, et la graisse qui les entoure, qui couvre les flancs, et le grand lobe du foie, qu’il détachera près des rognons. [^10] Le sacrificateur brûlera cela sur l’autel. C’est #Lé 21:6, 8, 17, 21, 22; 22:25. Éz 44:7. Mal 1:12.l’aliment d’un sacrifice consumé par le feu devant l’Éternel. [^11] Si son offrande est une chèvre, il la présentera devant l’Éternel. [^12] Il posera sa main sur la tête de sa victime, qu’il égorgera devant la tente d’assignation; et les fils d’Aaron en répandront le sang sur l’autel tout autour. [^13] De la victime, il offrira en sacrifice consumé par le feu devant l’Éternel: la graisse qui couvre les entrailles et toute celle qui y est attachée, [^14] les deux rognons, et la graisse qui les entoure, qui couvre les flancs, et le grand lobe du foie, qu’il détachera près des rognons. [^15] Le sacrificateur brûlera cela sur l’autel. Toute la graisse est l’aliment d’un sacrifice consumé par le feu, d’une agréable odeur à l’Éternel. [^16] C’est ici une loi perpétuelle pour vos descendants, dans tous les lieux où vous habiterez: vous ne mangerez ni graisse #Ge 9:4. Lé 7:26; 17:10, 14.ni sang. [^17] 

[[Leviticus - 2|<--]] Leviticus - 3 [[Leviticus - 4|-->]]

---
# Notes
