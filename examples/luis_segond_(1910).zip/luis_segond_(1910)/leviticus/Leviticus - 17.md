---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 17 - Luis Segond (1910)"
---
[[Leviticus - 16|<--]] Leviticus - 17 [[Leviticus - 18|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Leviticus]]

# Leviticus - 17

L’Éternel parla à Moïse, et dit: [^1] Parle à Aaron et à ses fils, et à tous les enfants d’Israël, et tu leur diras: Voici ce que l’Éternel a ordonné. [^2] Si un homme de la maison d’Israël égorge dans le camp ou hors du camp un bœuf, un agneau ou une chèvre, [^3] et ne l’amène pas à l’entrée de la tente d’assignation, pour en faire une offrande à l’Éternel devant le tabernacle de l’Éternel, le sang sera imputé à cet homme; il a répandu le sang, cet homme-là sera retranché du milieu de son peuple. [^4] C’est afin que les enfants d’Israël, au lieu de sacrifier leurs victimes dans les champs, les amènent au sacrificateur, devant l’Éternel, à l’entrée de la tente d’assignation, et qu’ils les offrent à l’Éternel en sacrifices d’actions de grâces. [^5] Le sacrificateur en répandra le sang sur l’autel de l’Éternel, à l’entrée de la tente d’assignation; et il brûlera la graisse, qui sera #Ex 29:18. Lé 4:31.d’une agréable odeur à l’Éternel. [^6] Ils n’offriront plus leurs sacrifices aux boucs, avec lesquels ils se prostituent. Ce sera une loi perpétuelle pour eux et pour leurs descendants. [^7] Tu leur diras donc: Si un homme de la maison d’Israël ou des étrangers qui séjournent au milieu d’eux offre un holocauste ou une victime, [^8] et ne l’amène pas à l’entrée de la tente d’assignation, pour l’offrir en sacrifice à l’Éternel, cet homme-là sera retranché de son peuple. [^9] Si un homme de la maison d’Israël ou des étrangers qui séjournent au milieu d’eux #Ge 9:4. Lé 3:17; 7:27; 19:26. De 12:16, 23. 1 S 14:33.mange du sang d’une espèce quelconque, je tournerai ma face contre celui qui mange le sang, et je le retrancherai du milieu de son peuple. [^10] Car l’âme de la chair est dans le sang. Je vous l’ai donné sur l’autel, afin qu’il servît d’expiation pour vos âmes, car c’est par l’âme que le sang fait l’expiation. [^11] C’est pourquoi j’ai dit aux enfants d’Israël: Personne d’entre vous ne mangera du sang, et l’étranger qui séjourne au milieu de vous ne mangera pas du sang. [^12] Si quelqu’un des enfants d’Israël ou des étrangers qui séjournent au milieu d’eux prend à la chasse un animal ou un oiseau qui se mange, il en versera le sang et le couvrira de poussière. [^13] Car l’âme de toute chair, c’est son sang, qui est en elle. C’est pourquoi j’ai dit aux enfants d’Israël: Vous ne mangerez le sang d’aucune chair; car l’âme de toute chair, c’est son sang: quiconque en mangera sera retranché. [^14] #Ex 22:31. Lé 11:40. Éz 44:31.Toute personne, indigène ou étrangère, qui mangera d’une bête morte ou déchirée, lavera ses vêtements, se lavera dans l’eau, et sera impure jusqu’au soir; puis elle sera pure. [^15] Si elle ne lave pas ses vêtements, et ne lave pas son corps, elle portera la peine de sa faute. [^16] 

[[Leviticus - 16|<--]] Leviticus - 17 [[Leviticus - 18|-->]]

---
# Notes
