---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 24 - Luis Segond (1910)"
---
[[Leviticus - 23|<--]] Leviticus - 24 [[Leviticus - 25|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Leviticus]]

# Leviticus - 24

L’Éternel parla à Moïse, et dit: [^1] Ordonne aux enfants d’Israël de t’apporter pour le chandelier de l’huile pure d’olives concassées, afin d’entretenir les lampes continuellement. [^2] C’est en dehors du voile qui est devant le témoignage, dans la tente d’assignation, qu’Aaron la préparera, pour que les lampes brûlent continuellement du soir au matin en présence de l’Éternel. C’est une loi perpétuelle pour vos descendants. [^3] Il arrangera les lampes sur le chandelier d’or pur, pour qu’elles brûlent continuellement devant l’Éternel. [^4] Tu prendras de la fleur de farine, et tu en feras douze gâteaux; chaque gâteau sera de deux dixièmes. [^5] Tu les placeras en deux piles, six par pile, sur la table d’or pur devant l’Éternel. [^6] Tu mettras de l’encens pur sur chaque pile, et il sera sur le pain comme souvenir, comme une offrande consumée par le feu devant l’Éternel. [^7] Chaque jour de sabbat, on rangera ces pains devant l’Éternel, continuellement: c’est une alliance perpétuelle qu’observeront les enfants d’Israël. [^8] #Ex 29:32. Lé 8:31. 1 S 21:6. Mt 12:4.Ils appartiendront à Aaron et à ses fils, et ils les mangeront dans un lieu saint; car ce sera pour eux une chose très sainte, une part des offrandes consumées par le feu devant l’Éternel. C’est une loi perpétuelle. [^9] Le fils d’une femme israélite et d’un homme égyptien, étant venu au milieu des enfants d’Israël, se querella dans le camp avec un homme israélite. [^10] Le fils de la femme israélite blasphéma et maudit le nom de Dieu. On l’amena à Moïse. Sa mère s’appelait Schelomith, fille de Dibri, de la tribu de Dan. [^11] On le mit en prison, jusqu’à ce que Moïse eût déclaré ce que l’Éternel ordonnerait. [^12] L’Éternel parla à Moïse, et dit: [^13] Fais sortir du camp le blasphémateur; tous ceux qui l’ont entendu poseront leurs mains sur sa tête, et toute l’assemblée le lapidera. [^14] Tu parleras aux enfants d’Israël, et tu diras: Quiconque maudira son Dieu portera la peine de son péché. [^15] Celui qui blasphémera le nom de l’Éternel sera puni de mort: toute l’assemblée le lapidera. Qu’il soit étranger ou indigène, il mourra, pour avoir blasphémé le nom de Dieu. [^16] Celui qui frappera un homme mortellement sera puni de mort. [^17] Celui qui frappera un animal mortellement le remplacera: vie pour vie. [^18] Si quelqu’un blesse son prochain, il lui sera fait comme il a fait: [^19] fracture pour fracture, #Ex 21:24. De 19:21. Mt 5:38.œil pour œil, dent pour dent; il lui sera fait la même blessure qu’il a faite à son prochain. [^20] Celui qui tuera un animal le remplacera, mais celui qui tuera un homme sera puni de mort. [^21] Vous aurez la même loi, l’étranger comme l’indigène; car je suis l’Éternel, votre Dieu. [^22] Moïse parla aux enfants d’Israël; ils firent sortir du camp le blasphémateur, et ils le lapidèrent. Les enfants d’Israël se conformèrent à l’ordre que l’Éternel avait donné à Moïse. [^23] 

[[Leviticus - 23|<--]] Leviticus - 24 [[Leviticus - 25|-->]]

---
# Notes
