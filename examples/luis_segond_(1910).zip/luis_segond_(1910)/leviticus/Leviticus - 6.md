---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 6 - Luis Segond (1910)"
---
[[Leviticus - 5|<--]] Leviticus - 6 [[Leviticus - 7|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Leviticus]]

# Leviticus - 6

L’Éternel parla à Moïse, et dit: [^1] Donne cet ordre à Aaron et à ses fils, et dis: Voici la loi de l’holocauste. L’holocauste restera sur le foyer de l’autel toute la nuit jusqu’au matin, et le feu brûlera sur l’autel. [^2] Le sacrificateur revêtira sa tunique de lin, et mettra des caleçons sur sa chair, il enlèvera la cendre faite par le feu qui aura consumé l’holocauste sur l’autel, et il la déposera près de l’autel. [^3] Puis il quittera ses vêtements et en mettra d’autres, pour porter la cendre hors du camp, dans un lieu pur. [^4] Le feu brûlera sur l’autel, il ne s’éteindra point; chaque matin, le sacrificateur y allumera du bois, arrangera l’holocauste, et brûlera la graisse des sacrifices d’actions de grâces. [^5] Le feu brûlera continuellement sur l’autel, il ne s’éteindra point. [^6] Voici la loi #No 15:4, etc.de l’offrande. Les fils d’Aaron la présenteront devant l’Éternel, devant l’autel. [^7] Le sacrificateur prélèvera une poignée de la fleur de farine et de l’huile, avec tout l’encens ajouté à l’offrande, et il brûlera cela sur l’autel #Lé 2:9.comme souvenir d’une agréable odeur à l’Éternel. [^8] Aaron et ses fils mangeront ce qui restera de l’offrande; ils le mangeront sans levain, dans un lieu saint, dans le parvis de la tente d’assignation. [^9] On ne le cuira pas avec du levain. C’est la part que je leur ai donnée de mes offrandes consumées par le feu. C’est une chose très sainte, comme le sacrifice d’expiation et comme le sacrifice de culpabilité. [^10] Tout mâle d’entre les enfants d’Aaron en mangera. C’est une loi perpétuelle pour vos descendants, au sujet des offrandes consumées par le feu devant l’Éternel: #Ex 29:37.quiconque y touchera sera sanctifié. [^11] L’Éternel parla à Moïse, et dit: [^12] Voici l’offrande qu’Aaron et ses fils feront à l’Éternel, le jour où ils recevront l’onction: un dixième d’épha de fleur de farine, comme offrande perpétuelle, moitié le matin et moitié le soir. [^13] Elle sera préparée à la poêle avec de l’huile, et tu l’apporteras frite; tu la présenteras aussi cuite et en morceaux comme une offrande d’une agréable odeur à l’Éternel. [^14] Le sacrificateur qui, parmi les fils d’Aaron, sera oint pour lui succéder, fera aussi cette offrande. C’est une loi perpétuelle devant l’Éternel: elle sera brûlée en entier. [^15] Toute offrande d’un sacrificateur sera brûlée en entier; elle ne sera point mangée. [^16] L’Éternel parla à Moïse, et dit: [^17] Parle à Aaron et à ses fils, et dis: Voici la loi du sacrifice d’expiation. C’est dans le lieu où l’on égorge l’holocauste que sera égorgée devant l’Éternel la victime pour le sacrifice d’expiation: c’est une chose très sainte. [^18] #Os 4:8.Le sacrificateur qui offrira la victime expiatoire la mangera; elle sera mangée dans un lieu saint, dans le parvis de la tente d’assignation. [^19] Quiconque en touchera la chair sera sanctifié. S’il en rejaillit du sang sur un vêtement, la place sur laquelle il aura rejailli sera lavée dans un lieu saint. [^20] Le vase de terre dans lequel elle aura cuit sera brisé; si c’est dans un vase d’airain qu’elle a cuit, il sera nettoyé et lavé dans l’eau. [^21] Tout mâle parmi les sacrificateurs en mangera: c’est une chose très sainte. [^22] Mais on ne mangera aucune victime expiatoire #Lé 4:5. Hé 13:11.dont on apportera du sang dans la tente d’assignation, pour faire l’expiation dans le sanctuaire: elle sera brûlée au feu. [^23] 

[[Leviticus - 5|<--]] Leviticus - 6 [[Leviticus - 7|-->]]

---
# Notes
