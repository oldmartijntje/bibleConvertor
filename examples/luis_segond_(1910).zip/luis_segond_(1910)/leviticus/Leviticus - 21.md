---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 21 - Luis Segond (1910)"
---
[[Leviticus - 20|<--]] Leviticus - 21 [[Leviticus - 22|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Leviticus]]

# Leviticus - 21

L’Éternel dit à Moïse: Parle aux sacrificateurs, fils d’Aaron, et tu leur diras: Un sacrificateur ne se rendra point impur parmi son peuple pour un mort, [^1] excepté pour ses plus proches parents, pour sa mère, pour son père, pour son fils, pour son frère, [^2] et aussi pour sa sœur encore vierge, qui le touche de près lorsqu’elle n’est pas mariée. [^3] Chef parmi son peuple, il ne se rendra point impur en se profanant. [^4] Les sacrificateurs ne se feront point de place chauve sur la tête, ils ne raseront point les coins de leur barbe, et ils ne feront point d’incisions dans leur chair. [^5] Ils seront saints pour leur Dieu, et ils ne profaneront pas le nom de leur Dieu; car ils offrent à l’Éternel les sacrifices consumés par le feu, l’aliment de leur Dieu: ils seront saints. [^6] Ils ne prendront point une femme prostituée ou déshonorée, ils ne prendront point une femme répudiée par son mari, car ils sont saints pour leur Dieu. [^7] Tu regarderas un sacrificateur comme saint, car il offre l’aliment de ton Dieu; il sera saint pour toi, car je suis saint, moi, l’Éternel, qui vous sanctifie. [^8] Si la fille d’un sacrificateur se déshonore en se prostituant, elle déshonore son père: elle sera brûlée au feu. [^9] Le sacrificateur qui a la supériorité sur ses frères, sur la tête duquel a été répandue l’huile d’onction, et qui a été consacré et revêtu des vêtements sacrés, ne découvrira point sa tête et ne déchirera point ses vêtements. [^10] Il n’ira vers aucun mort, il ne se rendra point impur, ni pour son père, ni pour sa mère. [^11] Il ne sortira point du sanctuaire, et ne profanera point le sanctuaire de son Dieu; car l’huile d’onction de son Dieu est une couronne sur lui. Je suis l’Éternel. [^12] Il prendra pour femme une vierge. [^13] Il ne prendra ni une veuve, ni une femme répudiée, ni une femme déshonorée ou prostituée; mais il prendra pour femme une vierge parmi son peuple. [^14] Il ne déshonorera point sa postérité parmi son peuple; car je suis l’Éternel, qui le sanctifie. [^15] L’Éternel parla à Moïse, et dit: [^16] Parle à Aaron, et dis: Tout homme de ta race et parmi tes descendants, qui aura un défaut corporel, ne s’approchera point pour offrir l’aliment de son Dieu. [^17] Tout homme qui aura un défaut corporel ne pourra s’approcher: un homme aveugle, boiteux, ayant le nez camus ou un membre allongé; [^18] un homme ayant une fracture au pied ou à la main; [^19] un homme bossu ou grêle, ayant une tache à l’œil, la gale, une dartre, ou les testicules écrasés. [^20] Tout homme de la race du sacrificateur Aaron, qui aura un défaut corporel, ne s’approchera point pour offrir à l’Éternel les sacrifices consumés par le feu; il a un défaut corporel: il ne s’approchera point pour offrir l’aliment de son Dieu. [^21] Il pourra manger l’aliment de son Dieu, des choses très saintes et des choses saintes. [^22] Mais il n’ira point vers le voile, et il ne s’approchera point de l’autel, car il a un défaut corporel; il ne profanera point mes sanctuaires, car je suis l’Éternel, qui les sanctifie. [^23] C’est ainsi que parla Moïse à Aaron et à ses fils, et à tous les enfants d’Israël. [^24] 

[[Leviticus - 20|<--]] Leviticus - 21 [[Leviticus - 22|-->]]

---
# Notes
