---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 10 - Luis Segond (1910)"
---
[[Leviticus - 9|<--]] Leviticus - 10 [[Leviticus - 11|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Leviticus]]

# Leviticus - 10

Les fils d’Aaron, Nadab et Abihu, prirent chacun un brasier, y mirent du feu, et posèrent du parfum dessus; ils apportèrent devant l’Éternel du feu étranger, ce qu’il ne leur avait point ordonné. [^1] Alors le feu sortit de devant l’Éternel, et les consuma: #No 3:4; 26:61. 1 Ch 24:2.ils moururent devant l’Éternel. [^2] Moïse dit à Aaron: C’est ce que l’Éternel a déclaré, lorsqu’il a dit: #Lé 8:35.Je serai sanctifié par ceux qui s’approchent de moi, et je serai glorifié en présence de tout le peuple. Aaron garda le silence. [^3] Et Moïse appela Mischaël et Eltsaphan, fils d’Uziel, oncle d’Aaron, et il leur dit: Approchez-vous, emportez vos frères loin du sanctuaire, hors du camp. [^4] Ils s’approchèrent, et ils les emportèrent dans leurs tuniques hors du camp, comme Moïse l’avait dit. [^5] Moïse dit à Aaron, à Éléazar et à Ithamar, fils d’Aaron: Vous ne découvrirez point vos têtes, et vous ne déchirerez point vos vêtements, de peur que vous ne mouriez, et que l’Éternel ne s’irrite contre toute l’assemblée. Laissez vos frères, toute la maison d’Israël, pleurer sur l’embrasement que l’Éternel a allumé. [^6] #Lé 21:12.Vous ne sortirez point de l’entrée de la tente d’assignation, de peur que vous ne mouriez; car l’huile de l’onction de l’Éternel est sur vous. Ils firent ce que Moïse avait dit. [^7] L’Éternel parla à Aaron, et dit: [^8] Tu ne boiras ni vin, ni boisson enivrante, toi et tes fils avec toi, lorsque vous entrerez dans la tente d’assignation, de peur que vous ne mouriez: ce sera une loi perpétuelle parmi vos descendants, [^9] afin que vous puissiez distinguer ce qui est saint de ce qui est profane, ce qui est impur de ce qui est pur, [^10] et enseigner aux enfants d’Israël toutes les lois que l’Éternel leur a données par Moïse. [^11] Moïse dit à Aaron, à Éléazar et à Ithamar, les deux fils qui restaient à Aaron: Prenez ce qui reste de l’offrande parmi les sacrifices consumés par le feu devant l’Éternel, et mangez-le sans levain près de l’autel: car c’est une chose très sainte. [^12] Vous le mangerez dans un lieu saint; c’est ton droit et le droit de tes fils sur les offrandes consumées par le feu devant l’Éternel; #Lé 2:3; 6:16.car c’est là ce qui m’a été ordonné. [^13] Vous mangerez aussi dans un lieu pur, toi, tes fils et tes filles avec toi, la poitrine qu’on a agitée de côté et d’autre et l’épaule qui a été présentée par élévation; car elles vous sont données, comme ton droit et le droit de tes fils, dans les sacrifices d’actions de grâces des enfants d’Israël. [^14] Ils apporteront, avec les graisses destinées à être consumées par le feu, l’épaule que l’on présente par élévation et la poitrine que l’on agite de côté et d’autre devant l’Éternel: elles seront pour toi et pour tes fils avec toi, par une loi perpétuelle, comme l’Éternel l’a ordonné. [^15] Moïse chercha le bouc expiatoire; et voici, il avait été brûlé. Alors il s’irrita contre Éléazar et Ithamar, les fils qui restaient à Aaron, et il dit: [^16] Pourquoi n’avez-vous pas mangé la victime expiatoire dans le lieu saint? C’est une chose très sainte; et l’Éternel vous l’a donnée, afin que vous portiez l’iniquité de l’assemblée, afin que vous fassiez pour elle l’expiation devant l’Éternel. [^17] Voici, le sang de la victime n’a point été porté dans l’intérieur du sanctuaire; vous deviez la manger dans le sanctuaire, #Lé 4:5; 6:26; 16:27.comme cela m’avait été ordonné. [^18] Aaron dit à Moïse: Voici, ils ont offert aujourd’hui leur sacrifice d’expiation et leur holocauste devant l’Éternel; et, après ce qui m’est arrivé, si j’eusse mangé aujourd’hui la victime expiatoire, cela aurait-il été bien aux yeux de l’Éternel? [^19] Moïse entendit et approuva ces paroles. [^20] 

[[Leviticus - 9|<--]] Leviticus - 10 [[Leviticus - 11|-->]]

---
# Notes
