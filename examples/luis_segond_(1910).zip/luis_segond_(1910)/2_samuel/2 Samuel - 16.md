---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 16 - Luis Segond (1910)"
---
[[2 Samuel - 15|<--]] 2 Samuel - 16 [[2 Samuel - 17|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Samuel]]

# 2 Samuel - 16

Lorsque David eut un peu dépassé le sommet, voici, Tsiba, serviteur de Mephiboscheth, vint au-devant de lui avec deux ânes bâtés, sur lesquels il y avait deux cents pains, cent masses de raisins secs, cent de fruits d’été, et une outre de vin. [^1] Le roi dit à Tsiba: Que veux-tu faire de cela? #2 S 19:27.Et Tsiba répondit: Les ânes serviront de monture à la maison du roi, le pain et les fruits d’été sont pour nourrir les jeunes gens, et le vin pour désaltérer ceux qui seront fatigués dans le désert. [^2] Le roi dit: Où est le fils de ton maître? Et Tsiba répondit au roi: Voici, il est resté à Jérusalem, car il a dit: Aujourd’hui la maison d’Israël me rendra le royaume de mon père. [^3] Le roi dit à Tsiba: Voici, tout ce qui appartient à Mephiboscheth est à toi. Et Tsiba dit: Je me prosterne! Que je trouve grâce à tes yeux, ô roi mon seigneur! [^4] David était arrivé jusqu’à Bachurim. Et voici, il sortit de là un homme de la famille et de la maison de Saül, nommé #1 R 2:8.Schimeï, fils de Guéra. Il s’avança en prononçant des malédictions, [^5] et il jeta des pierres à David et à tous les serviteurs du roi David, tandis que tout le peuple et tous les hommes vaillants étaient à la droite et à la gauche du roi. [^6] Schimeï parlait ainsi en le maudissant: Va-t’en, va-t’en, homme de sang, méchant homme! [^7] L’Éternel fait retomber sur toi tout le sang de la maison de Saül, dont tu occupais le trône, et l’Éternel a livré le royaume entre les mains d’Absalom, ton fils; et te voilà malheureux comme tu le mérites, car tu es un homme de sang! [^8] Alors Abischaï, fils de Tseruja, dit au roi: Pourquoi ce #1 S 24:15. 2 S 9:8.chien mort maudit-il le roi mon seigneur? Laisse-moi, je te prie, aller lui couper la tête. [^9] Mais le roi dit: Qu’ai-je affaire avec vous, fils de Tseruja? S’il maudit, c’est que l’Éternel lui a dit: Maudis David! Qui donc lui dira: Pourquoi agis-tu ainsi? [^10] Et David dit à Abischaï et à tous ses serviteurs: Voici, mon fils, qui est sorti de mes entrailles, en veut à ma vie; à plus forte raison ce Benjamite! Laissez-le, et qu’il maudisse, car l’Éternel le lui a dit. [^11] Peut-être l’Éternel regardera-t-il mon affliction, et me fera-t-il du bien en retour des malédictions d’aujourd’hui. [^12] David et ses gens continuèrent leur chemin. Et Schimeï marchait sur le flanc de la montagne près de David, et, en marchant, il maudissait, il jetait des pierres contre lui, il faisait voler la poussière. [^13] Le roi et tout le peuple qui était avec lui arrivèrent à Ajephim, et là ils se reposèrent. [^14] Absalom et tout le peuple, les hommes d’Israël, étaient entrés dans Jérusalem; et Achitophel était avec Absalom. [^15] Lorsque Huschaï, l’Arkien, ami de David, fut arrivé auprès d’Absalom, il lui dit: Vive le roi! Vive le roi! [^16] Et Absalom dit à Huschaï: Voilà donc l’attachement que tu as pour ton ami! Pourquoi n’es-tu pas allé avec ton ami? [^17] Huschaï répondit à Absalom: C’est que je veux être à celui qu’ont choisi l’Éternel et tout ce peuple et tous les hommes d’Israël, et c’est avec lui que je veux rester. [^18] D’ailleurs, qui servirai-je? Ne sera-ce pas son fils? Comme j’ai servi ton père, ainsi je te servirai. [^19] Absalom dit à Achitophel: Consultez ensemble; qu’avons-nous à faire? [^20] Et Achitophel dit à Absalom: Va vers les concubines que ton père a laissées pour garder la maison; ainsi tout Israël saura que tu t’es rendu odieux à ton père, et les mains de tous ceux qui sont avec toi se fortifieront. [^21] On dressa pour Absalom une tente sur le toit, et Absalom alla vers les concubines de son père, aux yeux de tout Israël. [^22] Les conseils donnés en ce temps-là par Achitophel avaient autant d’autorité que si l’on eût consulté Dieu lui-même. Il en était ainsi de tous les conseils d’Achitophel, soit pour David, soit pour Absalom. [^23] 

[[2 Samuel - 15|<--]] 2 Samuel - 16 [[2 Samuel - 17|-->]]

---
# Notes
