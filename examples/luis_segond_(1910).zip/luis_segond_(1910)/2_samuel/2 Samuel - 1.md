---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 1 - Luis Segond (1910)"
---
2 Samuel - 1 [[2 Samuel - 2|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Samuel]]

# 2 Samuel - 1

Après la mort de Saül, David, qui avait battu les #1 S 30:17.Amalécites, était depuis deux jours revenu à Tsiklag. [^1] Le troisième jour, un homme arriva du camp de Saül, les vêtements déchirés et la tête couverte de terre. Lorsqu’il fut en présence de David, il se jeta par terre et se prosterna. [^2] David lui dit: D’où viens-tu? Et il lui répondit: Je me suis sauvé du camp d’Israël. [^3] David lui dit: Que s’est-il passé? Dis-moi donc! Et il répondit: Le peuple s’est enfui du champ de bataille, et un grand nombre d’hommes sont tombés et ont péri; Saül même et Jonathan, son fils, sont morts. [^4] David dit au jeune homme qui lui apportait ces nouvelles: Comment sais-tu que Saül et Jonathan, son fils, sont morts? [^5] Et le jeune homme qui lui apportait ces nouvelles répondit: Je me trouvais sur la montagne de Guilboa; et voici, Saül s’appuyait sur sa lance, et voici, les chars et les cavaliers étaient près de l’atteindre. [^6] S’étant retourné, il m’aperçut et m’appela. Je dis: Me voici! [^7] Et il me dit: Qui es-tu? Je lui répondis: Je suis Amalécite. [^8] Et il dit: Approche donc, et donne-moi la mort; car je suis pris de vertige, quoique encore plein de vie. [^9] Je m’approchai de lui, et je lui donnai la mort, sachant bien qu’il ne survivrait pas à sa défaite. J’ai enlevé le diadème qui était sur sa tête et le bracelet qu’il avait au bras, et je les apporte ici à mon seigneur. [^10] #2 S 3:31; 13:31.David saisit ses vêtements et les déchira, et tous les hommes qui étaient auprès de lui firent de même. [^11] Ils furent dans le deuil, pleurèrent et jeûnèrent jusqu’au soir, à cause de Saül, de Jonathan, son fils, du peuple de l’Éternel, et de la maison d’Israël, parce qu’ils étaient tombés par l’épée. [^12] David dit au jeune homme qui lui avait apporté ces nouvelles: D’où es-tu? Et il répondit: Je suis le fils d’un étranger, d’un Amalécite. [^13] David lui dit: Comment n’as-tu pas craint de porter la main sur l’oint de l’Éternel et de lui donner la mort? [^14] Et David appela l’un de ses gens, et dit: Approche, et tue-le! Cet homme frappa l’Amalécite, qui mourut. [^15] Et David lui dit: Que ton sang retombe sur ta tête, car ta bouche a déposé contre toi, puisque tu as dit: J’ai donné la mort à l’oint de l’Éternel! [^16] Voici le cantique funèbre que David composa sur Saül et sur Jonathan, son fils, [^17] et qu’il ordonna d’enseigner aux enfants de Juda. C’est le cantique de l’arc: il est écrit dans le livre du #Jos 10:13.Juste. [^18] L’élite d’Israël a succombé sur tes collines!Comment des héros sont-ils tombés? [^19] #    
        Mi 1:10.  Ne l’annoncez point dans Gath,N’en publiez point la nouvelle dans les rues d’Askalon,De peur que les filles des Philistins ne se réjouissent,De peur que les filles des incirconcis ne triomphent. [^20] Montagnes de Guilboa!Qu’il n’y ait sur vous ni rosée ni pluie,Ni champs qui donnent des prémices pour les offrandes!Car là ont été jetés les boucliers des héros,Le bouclier de Saül; L’huile a cessé de les oindre. [^21] Devant le sang des blessés, devant la graisse des plus vaillants,L’arc de Jonathan n’a jamais reculé,Et l’épée de Saül ne retournait point à vide. [^22] Saül et Jonathan, aimables et chéris pendant leur vie,N’ont point été séparés dans leur mort;Ils étaient plus légers que les aigles,Ils étaient plus forts que les lions. [^23] Filles d’Israël! Pleurez sur Saül,Qui vous revêtait magnifiquement de cramoisi,Qui mettait des ornements d’or sur vos habits. [^24] Comment des héros sont-ils tombés au milieu du combat?Comment Jonathan a-t-il succombé sur tes collines? [^25] Je suis dans la douleur à cause de toi, Jonathan, mon frère!Tu faisais tout mon plaisir;Ton amour pour moi était admirable,Au-dessus de l’amour des femmes. [^26] Comment des héros sont-ils tombés?Comment leurs armes se sont-elles perdues! [^27] 

2 Samuel - 1 [[2 Samuel - 2|-->]]

---
# Notes
