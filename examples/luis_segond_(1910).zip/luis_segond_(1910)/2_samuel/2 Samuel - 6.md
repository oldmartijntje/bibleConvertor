---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 6 - Luis Segond (1910)"
---
[[2 Samuel - 5|<--]] 2 Samuel - 6 [[2 Samuel - 7|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Samuel]]

# 2 Samuel - 6

#    1 Ch 13:5, etc.  David rassembla encore toute l’élite d’Israël, au nombre de trente mille hommes. [^1] Et David, avec tout le peuple qui était auprès de lui, se mit en marche depuis Baalé-Juda, pour faire monter de là l’arche de Dieu, devant laquelle est invoqué le nom de l’Éternel des armées qui réside entre les chérubins au-dessus de l’arche. [^2] Ils mirent sur un #1 S 6:7, 8, etc.char neuf l’arche de Dieu, et l’emportèrent de #1 S 7:1.la maison d’Abinadab sur la colline; Uzza et Achjo, fils d’Abinadab, conduisaient le char neuf. [^3] Ils l’emportèrent donc de la maison d’Abinadab sur la colline; Uzza marchait à côté de l’arche de Dieu, et Achjo allait devant l’arche. [^4] David et toute la maison d’Israël jouaient devant l’Éternel de toutes sortes d’instruments de bois de cyprès, des harpes, des luths, des tambourins, des sistres et des cymbales. [^5] #1 Ch 13:9.Lorsqu’ils furent arrivés à l’aire de Nacon, Uzza étendit la main vers l’arche de Dieu et la saisit, parce que les bœufs la faisaient pencher. [^6] La colère de l’Éternel s’enflamma contre Uzza, et Dieu le frappa sur place à cause de sa faute. Uzza mourut là, près de l’arche de Dieu. [^7] David fut irrité de ce que l’Éternel avait frappé Uzza d’un tel châtiment. Et ce lieu a été appelé jusqu’à ce jour Pérets-Uzza. [^8] David eut peur de l’Éternel en ce jour-là, et il dit: Comment l’arche de l’Éternel entrerait-elle chez moi? [^9] Il ne voulut pas retirer l’arche de l’Éternel chez lui dans la cité de David, et il la fit conduire dans la maison d’Obed-Édom de Gath. [^10] L’arche de l’Éternel resta trois mois dans la maison d’Obed-Édom de Gath, et #1 Ch 13:14.l’Éternel bénit Obed-Édom et toute sa maison. [^11] On vint dire au roi David: L’Éternel a béni la maison d’Obed-Édom et tout ce qui est à lui, à cause de l’arche de Dieu. Et David se mit en route, et il fit monter l’arche de Dieu depuis la maison d’Obed-Édom jusqu’à la cité de David, au milieu des réjouissances. [^12] Quand ceux qui portaient l’arche de l’Éternel eurent fait six pas, on sacrifia un bœuf et un veau gras. [^13] David dansait de toute sa force devant l’Éternel, et il était ceint d’un éphod de lin. [^14] David et toute la maison d’Israël firent monter l’arche de l’Éternel avec des cris de joie et au son des trompettes. [^15] Comme l’arche de l’Éternel entrait dans la cité de David, Mical, fille de Saül, regardait par la fenêtre, et, voyant le roi David sauter et danser devant l’Éternel, elle le méprisa dans son cœur. [^16] Après qu’on eut amené l’arche de l’Éternel, on la mit à sa #1 Ch 15:1; 16:1.place au milieu de la tente que David avait dressée pour elle; et David offrit devant l’Éternel des holocaustes et des sacrifices d’actions de grâces. [^17] Quand David eut achevé d’offrir les holocaustes et les sacrifices d’actions de grâces, #1 Ch 16:2.il bénit le peuple au nom de l’Éternel des armées. [^18] Puis il distribua à tout le peuple, à toute la multitude d’Israël, hommes et femmes, à chacun un pain, une portion de viande et un gâteau de raisins. Et tout le peuple s’en alla, chacun dans sa maison. [^19] David s’en retourna pour bénir sa maison, et Mical, fille de Saül, sortit à sa rencontre. Elle dit: Quel honneur aujourd’hui pour le roi d’Israël de s’être découvert aux yeux des servantes de ses serviteurs, comme se découvrirait un homme de rien! [^20] David répondit à Mical: C’est devant l’Éternel, qui m’a choisi de préférence à ton père et à toute sa maison pour m’établir chef sur le peuple de l’Éternel, sur Israël, c’est devant l’Éternel que j’ai dansé. [^21] Je veux paraître encore plus vil que cela, et m’abaisser à mes propres yeux; néanmoins je serai en honneur auprès des servantes dont tu parles. [^22] Or Mical, fille de Saül, n’eut point d’enfants jusqu’au jour de sa mort. [^23] 

[[2 Samuel - 5|<--]] 2 Samuel - 6 [[2 Samuel - 7|-->]]

---
# Notes
