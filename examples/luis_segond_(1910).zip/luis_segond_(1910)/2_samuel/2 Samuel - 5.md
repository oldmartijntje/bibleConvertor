---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 5 - Luis Segond (1910)"
---
[[2 Samuel - 4|<--]] 2 Samuel - 5 [[2 Samuel - 6|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Samuel]]

# 2 Samuel - 5

#    
        1 Ch 11:1.  Toutes les tribus d’Israël vinrent auprès de David, à Hébron, et dirent: Voici, nous sommes tes os et ta chair. [^1] Autrefois déjà, lorsque Saül était notre roi, c’était toi qui conduisais et qui ramenais Israël. L’Éternel t’a dit: #2 S 7:7. Ps 78:71.Tu paîtras mon peuple d’Israël, et tu seras le chef d’Israël. [^2] Ainsi tous les anciens d’Israël vinrent auprès du roi à Hébron, et le roi David fit alliance avec eux à Hébron, devant l’Éternel. Ils oignirent David pour roi sur Israël. [^3] David était âgé de trente ans lorsqu’il devint roi, et il régna quarante ans. [^4] #2 S 2:11. 1 R 2:11. 1 Ch 3:4.A Hébron il régna sur Juda sept ans et six mois, et à Jérusalem il régna trente-trois ans sur tout Israël et Juda. [^5] Le roi marcha avec ses gens sur Jérusalem contre les Jébusiens, habitants du pays. Ils dirent à David: Tu n’entreras point ici, car les aveugles mêmes et les boiteux te repousseront! Ce qui voulait dire: David n’entrera point ici. [^6] Mais David s’empara de la forteresse de Sion: c’est la cité de David. [^7] David avait dit en ce jour: #1 Ch 11:6.Quiconque battra les Jébusiens et atteindra le canal, quiconque frappera ces boiteux et ces aveugles qui sont les ennemis de David… C’est pourquoi l’on dit: L’aveugle et le boiteux n’entreront point dans la maison. [^8] David s’établit dans la forteresse, qu’il appela cité de David. Il fit de tous côtés des constructions, en dehors et en dedans de Millo. [^9] David devenait de plus en plus grand, et l’Éternel, le Dieu des armées, était avec lui. [^10] #    
        1 Ch 14:1.  Hiram, roi de Tyr, envoya des messagers à David, et du bois de cèdre, et des charpentiers et des tailleurs de pierres, qui bâtirent une maison pour David. [^11] David reconnut que l’Éternel l’affermissait comme roi d’Israël, et qu’il élevait son royaume à cause de son peuple d’Israël. [^12] #1 Ch 3:9; 14:3, etc.David prit encore des concubines et des femmes de Jérusalem, après qu’il fut venu d’Hébron, et il lui naquit encore des fils et des filles. [^13] #1 Ch 3:5, etc.; 14:4, etc.Voici les noms de ceux qui lui naquirent à Jérusalem: Schammua, Schobab, Nathan, Salomon, [^14] Jibhar, Élischua, Népheg, Japhia, [^15] Élischama, Éliada et Éliphéleth. [^16] #    1 Ch 14:8, etc.  Les Philistins apprirent qu’on avait oint David pour roi sur Israël, et ils montèrent tous à sa recherche. David, qui en fut informé, descendit à la forteresse. [^17] Les Philistins arrivèrent, et se répandirent dans la vallée des Rephaïm. [^18] David consulta l’Éternel, en disant: Monterai-je contre les Philistins? Les livreras-tu entre mes mains? Et l’Éternel dit à David: Monte, car je livrerai les Philistins entre tes mains. [^19] David vint à #És 28:21.Baal-Peratsim, où il les battit. Puis il dit: L’Éternel a dispersé mes ennemis devant moi, comme des eaux qui s’écoulent. C’est pourquoi l’on a donné à ce lieu le nom de Baal-Peratsim. [^20] Ils laissèrent là leurs idoles, et #1 Ch 14:12.David et ses gens les emportèrent. [^21] Les Philistins montèrent de nouveau, et se répandirent dans la vallée des Rephaïm. [^22] David consulta l’Éternel. Et l’Éternel dit: Tu ne monteras pas; tourne-les par derrière, et tu arriveras sur eux vis-à-vis des mûriers. [^23] Quand tu entendras un bruit de pas dans les cimes des mûriers, alors hâte-toi, car c’est l’Éternel qui marche devant toi pour battre l’armée des Philistins. [^24] David fit ce que l’Éternel lui avait ordonné, et il battit les Philistins depuis Guéba jusqu’à Guézer. [^25] 

[[2 Samuel - 4|<--]] 2 Samuel - 5 [[2 Samuel - 6|-->]]

---
# Notes
