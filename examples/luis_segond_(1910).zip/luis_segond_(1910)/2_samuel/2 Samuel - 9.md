---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 9 - Luis Segond (1910)"
---
[[2 Samuel - 8|<--]] 2 Samuel - 9 [[2 Samuel - 10|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Samuel]]

# 2 Samuel - 9

David dit: Reste-t-il encore quelqu’un de la maison de Saül, pour que je lui fasse du bien à cause de Jonathan? [^1] Il y avait un serviteur de la maison de Saül, nommé #2 S 16:1, etc.; 19:17.Tsiba, que l’on fit venir auprès de David. Le roi lui dit: Es-tu Tsiba? Et il répondit: Ton serviteur! [^2] Le roi dit: N’y a-t-il plus personne de la maison de Saül, pour que j’use envers lui de la bonté de Dieu? Et Tsiba répondit au roi: Il y a encore un fils de Jonathan, #2 S 4:4.perclus des pieds. [^3] Le roi lui dit: Où est-il? Et Tsiba répondit au roi: Il est dans la maison de Makir, fils d’Ammiel, à Lodebar. [^4] Le roi David l’envoya chercher dans la maison de Makir, fils d’Ammiel, à Lodebar. [^5] Et Mephiboscheth, fils de Jonathan, fils de Saül, vint auprès de David, tomba sur sa face et se prosterna. David dit: Mephiboscheth! Et il répondit: Voici ton serviteur. [^6] David lui dit: Ne crains point, car je veux te faire du bien à cause de Jonathan, ton père. Je te rendrai toutes les terres de Saül, ton père, et tu mangeras toujours à ma table. [^7] Il se prosterna, et dit: Qu’est ton serviteur, pour que tu regardes un chien mort, tel que moi? [^8] Le roi appela Tsiba, serviteur de Saül, et lui dit: Je donne au fils de ton maître tout ce qui appartenait à Saül et à toute sa maison. [^9] Tu cultiveras pour lui les terres, toi, tes fils, et tes serviteurs, et tu feras les récoltes, afin que le fils de ton maître ait du pain à manger; et Mephiboscheth, fils de ton maître, mangera toujours à ma table. Or Tsiba avait quinze fils et vingt serviteurs. [^10] Il dit au roi: Ton serviteur fera tout ce que le roi mon seigneur ordonne à son serviteur. Et Mephiboscheth mangea à la table de David, comme l’un des fils du roi. [^11] Mephiboscheth avait un jeune fils, nommé Mica, et tous ceux qui demeuraient dans la maison de Tsiba étaient serviteurs de Mephiboscheth. [^12] Mephiboscheth habitait à Jérusalem, car il mangeait toujours à la table du roi. Il était boiteux des deux pieds. [^13] 

[[2 Samuel - 8|<--]] 2 Samuel - 9 [[2 Samuel - 10|-->]]

---
# Notes
