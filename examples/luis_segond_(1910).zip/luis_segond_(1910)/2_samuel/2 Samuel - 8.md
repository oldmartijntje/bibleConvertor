---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 8 - Luis Segond (1910)"
---
[[2 Samuel - 7|<--]] 2 Samuel - 8 [[2 Samuel - 9|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Samuel]]

# 2 Samuel - 8

#    1 Ch 18:1, etc.  Après cela, David battit les Philistins et les humilia, et il enleva de la main des Philistins les rênes de leur capitale. [^1] Il battit les Moabites, et il les mesura avec un cordeau, en les faisant coucher par terre; il en mesura deux cordeaux pour les livrer à la mort, et un plein cordeau pour leur laisser la vie. Et les Moabites furent assujettis à David, et lui payèrent un tribut. [^2] David battit Hadadézer, fils de Rehob, roi de Tsoba, lorsqu’il alla rétablir sa domination sur le fleuve de l’Euphrate. [^3] David #1 Ch 18:4.lui prit mille sept cents cavaliers et vingt mille hommes de pied; il coupa les jarrets à tous les chevaux de trait, et ne conserva que cent attelages. [^4] Les Syriens de Damas vinrent au secours d’Hadadézer, roi de Tsoba, et David battit vingt-deux mille Syriens. [^5] David mit des garnisons dans la Syrie de Damas. Et les Syriens furent assujettis à David, et lui payèrent un tribut. L’Éternel protégeait David partout où il allait. [^6] Et David prit les boucliers d’or qu’avaient les serviteurs d’Hadadézer, et les apporta à Jérusalem. [^7] Le roi David prit encore une grande quantité d’airain à Béthach et à Bérothaï, villes d’Hadadézer. [^8] Thoï, roi de Hamath, apprit que David avait battu toute l’armée d’Hadadézer, [^9] et il envoya Joram, son fils, vers le roi David, pour le saluer, et pour le féliciter d’avoir attaqué Hadadézer et de l’avoir battu. Car Thoï était en guerre avec Hadadézer. Joram apporta des vases d’argent, des vases d’or, et des vases d’airain. [^10] Le roi David les consacra à l’Éternel, comme il avait déjà consacré l’argent et l’or pris sur toutes les nations qu’il avait vaincues, [^11] sur la Syrie, sur Moab, sur les fils d’Ammon, sur les Philistins, sur Amalek, et sur le butin d’Hadadézer, fils de Rehob, roi de Tsoba. [^12] #Ps 60:2.Au retour de sa victoire sur les Syriens, David se fit encore un nom, en battant dans la vallée du sel dix-huit mille Édomites. [^13] Il mit des garnisons dans Édom, il mit des garnisons dans tout Édom. Et tout Édom fut assujetti à David. L’Éternel protégeait David partout où il allait. [^14] David régna sur Israël, et il faisait droit et justice à tout son peuple. [^15] #1 Ch 18:15, etc.Joab, fils de Tseruja, commandait l’armée; Josaphat, fils d’Achilud, était archiviste; [^16] Tsadok, fils d’Achithub, et Achimélec, fils d’Abiathar, étaient sacrificateurs; Seraja était secrétaire; [^17] Benaja, fils de Jehojada, était chef des Kéréthiens et des Péléthiens; et les fils de David étaient ministres d’état. [^18] 

[[2 Samuel - 7|<--]] 2 Samuel - 8 [[2 Samuel - 9|-->]]

---
# Notes
