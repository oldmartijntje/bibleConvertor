---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 4 - Luis Segond (1910)"
---
[[2 Samuel - 3|<--]] 2 Samuel - 4 [[2 Samuel - 5|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Samuel]]

# 2 Samuel - 4

Lorsque le fils de Saül apprit qu’Abner était mort à Hébron, ses mains restèrent sans force, et tout Israël fut dans l’épouvante. [^1] Le fils de Saül avait deux chefs de bandes, dont l’un s’appelait Baana et l’autre Récab; ils étaient fils de Rimmon de Beéroth, d’entre les fils de Benjamin. Car Beéroth était regardée comme faisant partie de Benjamin, [^2] et les Beérothiens s’étaient enfuis à Guitthaïm, où ils ont habité jusqu’à ce jour. [^3] #2 S 9:3, etc.Jonathan, fils de Saül, avait un fils perclus des pieds; et âgé de cinq ans lorsqu’arriva de Jizreel la nouvelle de la mort de Saül et de Jonathan; sa nourrice le prit et s’enfuit, et, comme elle précipitait sa fuite, il tomba et resta boiteux; son nom était Mephiboscheth. [^4] Or les fils de Rimmon de Beéroth, Récab et Baana, se rendirent pendant la chaleur du jour à la maison d’Isch-Boscheth, qui était couché pour son repos de midi. [^5] Ils pénétrèrent jusqu’au milieu de la maison, comme pour prendre du froment, et ils le frappèrent au ventre; puis Récab et Baana, son frère, se sauvèrent. [^6] Ils entrèrent donc dans la maison pendant qu’il reposait sur son lit dans sa chambre à coucher, ils le frappèrent et le firent mourir, et ils lui coupèrent la tête. Ils prirent sa tête, et ils marchèrent toute la nuit au travers de la plaine. [^7] Ils apportèrent la tête d’Isch-Boscheth à David dans Hébron, et ils dirent au roi: Voici la tête d’Isch-Boscheth, fils de Saül, ton ennemi, qui en voulait à ta vie; l’Éternel venge aujourd’hui le roi mon seigneur de Saül et de sa race. [^8] David répondit à Récab et à Baana, son frère, fils de Rimmon de Beéroth: L’Éternel qui m’a délivré de tout péril est vivant! [^9] #2 S 1:15.celui qui est venu me dire: Voici, Saül est mort, et qui croyait m’annoncer une bonne nouvelle, je l’ai fait saisir et tuer à Tsiklag, pour lui donner le salaire de son message; [^10] et quand des méchants ont assassiné un homme juste dans sa maison et sur sa couche, combien plus ne redemanderai-je pas son sang de vos mains et ne vous exterminerai-je pas de la terre? [^11] Et David ordonna à ses gens de les tuer; ils leur coupèrent les mains et les pieds, et les pendirent au bord de l’étang d’Hébron. Ils prirent ensuite la tête d’Isch-Boscheth, et l’enterrèrent dans le #2 S 3:32.sépulcre d’Abner à Hébron. [^12] 

[[2 Samuel - 3|<--]] 2 Samuel - 4 [[2 Samuel - 5|-->]]

---
# Notes
