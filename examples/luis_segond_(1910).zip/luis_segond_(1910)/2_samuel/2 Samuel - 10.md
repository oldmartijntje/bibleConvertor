---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 10 - Luis Segond (1910)"
---
[[2 Samuel - 9|<--]] 2 Samuel - 10 [[2 Samuel - 11|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Samuel]]

# 2 Samuel - 10

#    1 Ch 19:1, etc.  Après cela, le roi des fils d’Ammon mourut, et Hanun, son fils, régna à sa place. [^1] David dit: Je montrerai de la bienveillance à Hanun, fils de Nachasch, comme son père en a montré à mon égard. Et David envoya ses serviteurs pour le consoler au sujet de son père. Lorsque les serviteurs de David arrivèrent dans le pays des fils d’Ammon, [^2] les chefs des fils d’Ammon dirent à Hanun, leur maître: Penses-tu que ce soit pour honorer ton père que David t’envoie des consolateurs? N’est-ce pas pour reconnaître et explorer la ville, et pour la détruire, qu’il envoie ses serviteurs auprès de toi? [^3] Alors Hanun saisit les serviteurs de David, leur fit raser la moitié de la barbe, et fit couper leurs habits par le milieu jusqu’au haut des cuisses. Puis il les congédia. [^4] David, qui fut informé, envoya des gens à leur rencontre, car ces hommes étaient dans une grande confusion; et le roi leur fit dire: Restez à Jéricho jusqu’à ce que votre barbe ait repoussé, et revenez ensuite. [^5] Les fils d’Ammon, voyant qu’ils s’étaient rendus odieux à David, firent enrôler à leur solde vingt mille hommes de pied chez les Syriens de Beth-Rehob et chez les Syriens de Tsoba, mille hommes chez le roi de Maaca, et douze mille hommes chez les gens de Tob. [^6] A cette nouvelle, David envoya contre eux Joab et toute l’armée, les hommes vaillants. [^7] Les fils d’Ammon sortirent, et se rangèrent en bataille à l’entrée de la porte; les Syriens de Tsoba et de Rehob, et les hommes de Tob et de Maaca, étaient à part dans la campagne. [^8] Joab vit qu’il avait à combattre par devant et par derrière. Il choisit alors sur toute l’élite d’Israël un corps, qu’il opposa aux Syriens; [^9] et il plaça sous le commandement de son frère Abischaï le reste du peuple, pour faire face aux fils d’Ammon. [^10] Il dit: Si les Syriens sont plus forts que moi, tu viendras à mon secours; et si les fils d’Ammon sont plus forts que toi, j’irai te secourir. [^11] Sois ferme, et montrons du courage pour notre peuple et pour les villes de notre Dieu, et que l’Éternel fasse ce qui lui semblera bon! [^12] Joab, avec son peuple, s’avança pour attaquer les Syriens, et ils s’enfuirent devant lui. [^13] Et quand les fils d’Ammon virent que les Syriens avaient pris la fuite, ils s’enfuirent aussi devant Abischaï et rentrèrent dans la ville. Joab s’éloigna des fils d’Ammon et revint à Jérusalem. [^14] Les Syriens, voyant qu’ils avaient été battus par Israël, réunirent leurs forces. [^15] Hadarézer envoya chercher les Syriens qui étaient de l’autre côté du fleuve; et ils arrivèrent à Hélam, ayant à leur tête Schobac, chef de l’armée d’Hadarézer. [^16] On l’annonça à David, qui assembla tout Israël, passa le Jourdain, et vint à Hélam. Les Syriens se préparèrent à la rencontre de David, et lui livrèrent bataille. [^17] Mais les Syriens s’enfuirent devant Israël. Et David leur tua les troupes de sept cents chars et quarante mille cavaliers; il frappa aussi le chef de leur armée, Schobac, qui mourut sur place. [^18] Tous les rois soumis à Hadarézer, se voyant battus par Israël, firent la paix avec Israël et lui furent assujettis. Et les Syriens n’osèrent plus secourir les fils d’Ammon. [^19] 

[[2 Samuel - 9|<--]] 2 Samuel - 10 [[2 Samuel - 11|-->]]

---
# Notes
