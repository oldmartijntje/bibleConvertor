---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 8 - Luis Segond (1910)"
---
[[Genesis - 7|<--]] Genesis - 8 [[Genesis - 9|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Genesis]]

# Genesis - 8

Dieu se souvint de Noé, de tous les animaux et de tout le bétail qui étaient avec lui dans l’arche; et Dieu fit passer un vent sur la terre, et les eaux s’apaisèrent. [^1] Les sources de l’abîme et les écluses des cieux furent fermées, et la pluie ne tomba plus du ciel. [^2] Les eaux se retirèrent de dessus la terre, s’en allant et s’éloignant, et les eaux diminuèrent au bout de cent cinquante jours. [^3] Le septième mois, le dix-septième jour du mois, l’arche s’arrêta sur les montagnes d’Ararat. [^4] Les eaux allèrent en diminuant jusqu’au dixième mois. Le dixième mois, le premier jour du mois, apparurent les sommets des montagnes. [^5] Au bout de quarante jours, Noé ouvrit la fenêtre qu’il avait faite à l’arche. [^6] Il lâcha le corbeau, qui sortit, partant et revenant, jusqu’à ce que les eaux eussent séché sur la terre. [^7] Il lâcha aussi la colombe, pour voir si les eaux avaient diminué à la surface de la terre. [^8] Mais la colombe ne trouva aucun lieu pour poser la plante de son pied, et elle revint à lui dans l’arche, car il y avait des eaux à la surface de toute la terre. Il avança la main, la prit, et la fit rentrer auprès de lui dans l’arche. [^9] Il attendit encore sept autres jours, et il lâcha de nouveau la colombe hors de l’arche. [^10] La colombe revint à lui sur le soir; et voici, une feuille d’olivier arrachée était dans son bec. Noé connut ainsi que les eaux avaient diminué sur la terre. [^11] Il attendit encore sept autres jours; et il lâcha la colombe. Mais elle ne revint plus à lui. [^12] L’an six cent un, le premier mois, le premier jour du mois, les eaux avaient séché sur la terre. Noé ôta la couverture de l’arche: il regarda, et voici, la surface de la terre avait séché. [^13] Le second mois, le vingt-septième jour du mois, la terre fut sèche. [^14] Alors Dieu parla à Noé, en disant: [^15] Sors de l’arche, toi et ta femme, tes fils et les femmes de tes fils avec toi. [^16] Fais sortir avec toi tous les animaux de toute chair qui sont avec toi, tant les oiseaux que le bétail et tous les reptiles qui rampent sur la terre: #Ge 1:22, 28; 9:1.qu’ils se répandent sur la terre, qu’ils soient féconds et multiplient sur la terre. [^17] Et Noé sortit, avec ses fils, sa femme, et les femmes de ses fils. [^18] Tous les animaux, tous les reptiles, tous les oiseaux, tout ce qui se meut sur la terre, selon leurs espèces, sortirent de l’arche. [^19] Noé bâtit un autel à l’Éternel; il prit de toutes les bêtes #Lé 11.pures et de tous les oiseaux purs, et il offrit des holocaustes sur l’autel. [^20] L’Éternel sentit une odeur agréable, et l’Éternel dit en son cœur: Je ne maudirai plus la terre, à cause de l’homme, #Ge 6:5. Pr 22:15. Mt 15:19.parce que les pensées du cœur de l’homme sont mauvaises dès sa #Pr 22:15.jeunesse; et je ne frapperai plus tout ce qui est vivant, comme je l’ai fait. [^21] #Jé 33:20, 25.Tant que la terre subsistera, les semailles et la moisson, le froid et la chaleur, l’été et l’hiver, le jour et la nuit ne cesseront point. [^22] 

[[Genesis - 7|<--]] Genesis - 8 [[Genesis - 9|-->]]

---
# Notes
