---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 3 - Luis Segond (1910)"
---
[[Genesis - 2|<--]] Genesis - 3 [[Genesis - 4|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Genesis]]

# Genesis - 3

Le serpent était le plus rusé de tous les animaux des champs, que l’Éternel Dieu avait faits. Il dit à la femme: Dieu a-t-il réellement dit: Vous ne mangerez pas de tous les arbres du jardin? [^1] La femme répondit au serpent: Nous mangeons du fruit des arbres du jardin. [^2] Mais quant au fruit de l’arbre qui est au milieu du jardin, Dieu a dit: Vous n’en mangerez point et vous n’y toucherez point, de peur que vous ne mouriez. [^3] Alors le serpent dit #2 Co 11:3.à la femme: Vous ne mourrez point; [^4] mais #Jn 8:44.Dieu sait que, le jour où vous en mangerez, vos yeux s’ouvriront, et que vous serez comme des dieux, connaissant le bien et le mal. [^5] La femme vit que l’arbre était bon à manger et agréable à la vue, et qu’il était précieux pour ouvrir l’intelligence; elle prit de son fruit, et en mangea; elle en donna aussi à son mari, qui était auprès d’elle, #Ro 5:12, 14, 15, etc. 1 Ti 2:14.et il en mangea. [^6] Les yeux de l’un et de l’autre s’ouvrirent, ils connurent qu’ils étaient #Ge 2:25.nus, et ayant cousu des feuilles de figuier, ils s’en firent des ceintures. [^7] Alors ils entendirent la voix de l’Éternel Dieu, qui parcourait le jardin vers le soir, et l’homme et sa femme se cachèrent loin de la face de l’Éternel Dieu, au milieu des arbres du jardin. [^8] Mais l’Éternel Dieu appela l’homme, et lui dit: Où es-tu? [^9] Il répondit: J’ai entendu ta voix dans le jardin, et j’ai eu peur, parce que je suis nu, et je me suis caché. [^10] Et l’Éternel Dieu dit: Qui t’a appris que tu es nu? Est-ce que tu as mangé de l’arbre dont je t’avais défendu de manger? [^11] L’homme répondit: La femme que tu as mise auprès de moi m’a donné de l’arbre, et j’en ai mangé. [^12] Et l’Éternel Dieu dit à la femme: Pourquoi as-tu fait cela? La femme répondit: #Ap 12:13.Le serpent m’a séduite, et j’en ai mangé. [^13] L’Éternel Dieu dit au serpent: Puisque tu as fait cela, tu seras maudit entre tout le bétail et entre tous les animaux des champs, tu marcheras sur ton ventre, et tu mangeras de la poussière tous les jours de ta vie. [^14] Je mettrai #Mt 4:1.inimitié entre toi et la femme, entre ta postérité et sa postérité: #Col 2:15.celle-ci t’écrasera la tête, et tu lui blesseras le talon. [^15] Il dit à la femme: J’augmenterai la souffrance de tes grossesses, tu enfanteras avec douleur, et tes désirs se porteront vers ton mari, #1 Co 14:34. 1 Ti 2:11, 12. Tit 2:5. 1 Pi 3:6.mais il dominera sur toi. [^16] Il dit à l’homme: Puisque tu as écouté la voix de ta femme, et que tu as mangé de l’arbre au sujet duquel je t’avais donné cet ordre: Tu n’en mangeras point! Le sol sera maudit à cause de toi. C’est à force de peine que tu en tireras ta nourriture tous les jours de ta vie, [^17] il te produira des épines et des ronces, et tu mangeras de l’herbe des champs. [^18] C’est à la sueur de ton visage que tu mangeras du pain, jusqu’à ce que tu retournes dans la terre, d’où tu as été pris; car tu es poussière, et tu retourneras dans la poussière. [^19] Adam donna à sa femme le nom d’Ève: car elle a été la mère de tous les vivants. [^20] L’Éternel Dieu fit à Adam et à sa femme des habits de peau, et il les en revêtit. [^21] L’Éternel Dieu dit: Voici, l’homme est devenu comme l’un de nous, pour la connaissance du bien et du mal. Empêchons-le maintenant d’avancer sa main, de prendre de l’arbre de vie, d’en manger, et de vivre éternellement. [^22] Et l’Éternel Dieu le chassa du jardin d’Éden, pour qu’il cultivât la terre, d’où il avait été pris. [^23] C’est ainsi qu’il chassa Adam; et il mit à l’orient du jardin d’Éden les chérubins qui agitent une épée flamboyante, pour garder le chemin de l’arbre de vie. [^24] 

[[Genesis - 2|<--]] Genesis - 3 [[Genesis - 4|-->]]

---
# Notes
