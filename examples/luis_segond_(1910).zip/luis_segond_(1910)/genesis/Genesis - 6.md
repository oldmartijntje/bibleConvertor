---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 6 - Luis Segond (1910)"
---
[[Genesis - 5|<--]] Genesis - 6 [[Genesis - 7|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Genesis]]

# Genesis - 6

Lorsque les hommes eurent commencé à se multiplier sur la face de la terre, et que des filles leur furent nées, [^1] les fils de Dieu virent que les filles des hommes étaient belles, et ils en prirent pour femmes parmi toutes celles qu’ils choisirent. [^2] Alors l’Éternel dit: Mon esprit ne restera pas à toujours dans l’homme, car l’homme n’est que chair, et ses jours seront de cent vingt ans. [^3] Les géants étaient sur la terre en ces temps-là, après que les fils de Dieu furent venus vers les filles des hommes, et qu’elles leur eurent donné des enfants: ce sont ces héros qui furent fameux dans l’antiquité. [^4] L’Éternel vit que la méchanceté des hommes était grande sur la terre, et que #Ge 8:21. Job 15:16. Pr 6:14. Jé 17:9. Mt 15:19. Ro 3:10, 11, 12; 8:6.toutes les pensées de leur cœur se portaient chaque jour uniquement vers le mal. [^5] L’Éternel se repentit d’avoir fait l’homme sur la terre, et il fut affligé en son cœur. [^6] Et l’Éternel dit: J’exterminerai de la face de la terre l’homme que j’ai créé, depuis l’homme jusqu’au bétail, aux reptiles, et aux oiseaux du ciel; car je me repens de les avoir faits. [^7] Mais Noé trouva grâce aux yeux de l’Éternel. [^8] Voici la postérité de Noé. Noé était un homme juste et intègre dans son temps; #Ge 5:22.Noé marchait avec Dieu. [^9] Noé engendra trois fils: Sem, Cham et Japhet. [^10] La terre était corrompue devant Dieu, la terre était pleine de violence. [^11] Dieu regarda la terre, et voici, elle était corrompue; car toute chair avait corrompu sa voie sur la terre. [^12] Alors Dieu dit à Noé: La fin de toute chair est arrêtée par devers moi; car ils ont rempli la terre de violence; voici, je vais les détruire avec la terre. [^13] Fais-toi une arche de bois de gopher; tu disposeras cette arche en cellules, et tu l’enduiras de poix en dedans et en dehors. [^14] Voici comment tu la feras: l’arche aura trois cents coudées de longueur, cinquante coudées de largeur et trente coudées de hauteur. [^15] Tu feras à l’arche une fenêtre, que tu réduiras à une coudée en haut; tu établiras une porte sur le côté de l’arche; et tu construiras un étage inférieur, un second et un troisième. [^16] Et moi, je vais faire venir le déluge d’eaux sur la terre, pour détruire toute chair ayant souffle de vie sous le ciel; tout ce qui est sur la terre périra. [^17] Mais j’établis mon alliance avec toi; #1 Pi 3:20. 2 Pi 2:5.tu entreras dans l’arche, toi et tes fils, ta femme et les femmes de tes fils avec toi. [^18] De tout ce qui vit, de toute chair, tu feras entrer dans l’arche deux de chaque espèce, pour les conserver en vie avec toi: il y aura un mâle et une femelle. [^19] Des oiseaux selon leur espèce, du bétail selon son espèce, et de tous les reptiles de la terre selon leur espèce, deux de chaque espèce viendront vers toi, pour que tu leur conserves la vie. [^20] Et toi, prends de tous les aliments que l’on mange, et fais-en une provision auprès de toi, afin qu’ils te servent de nourriture ainsi qu’à eux. [^21] C’est ce que fit Noé: #Ge 7:5. Hé 11:7.il exécuta tout ce que Dieu lui avait ordonné. [^22] 

[[Genesis - 5|<--]] Genesis - 6 [[Genesis - 7|-->]]

---
# Notes
