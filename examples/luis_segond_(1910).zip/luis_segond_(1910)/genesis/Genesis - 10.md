---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 10 - Luis Segond (1910)"
---
[[Genesis - 9|<--]] Genesis - 10 [[Genesis - 11|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Genesis]]

# Genesis - 10

Voici la postérité des fils de #1 Ch 1:4.Noé, Sem, Cham et Japhet. Il leur naquit des fils après le déluge. [^1] Les #1 Ch 1:5.fils de Japhet furent: Gomer, Magog, Madaï, Javan, Tubal, Méschec et Tiras. [^2] Les fils de Gomer: Aschkenaz, Riphat et Togarma. [^3] Les fils de Javan: Élischa, Tarsis, Kittim et Dodanim. [^4] C’est par eux qu’ont été peuplées les îles des nations selon leurs terres, selon la langue de chacun, selon leurs familles, selon leurs nations. [^5] Les #1 Ch 1:8.fils de Cham furent: Cusch, Mitsraïm, Puth et Canaan. [^6] Les fils de Cusch: Saba, Havila, Sabta, Raema et Sabteca. Les fils de Raema: Séba et Dedan. [^7] #1 Ch 1:10.Cusch engendra aussi Nimrod; c’est lui qui commença à être puissant sur la terre. [^8] Il fut un vaillant chasseur devant l’Éternel; c’est pourquoi l’on dit: Comme Nimrod, vaillant chasseur devant l’Éternel. [^9] Il régna d’abord sur Babel, Érec, Accad et Calné, au pays de Schinear. [^10] De ce pays-là sortit Assur; il bâtit Ninive, Rehoboth Hir, Calach, [^11] et Résen entre Ninive et Calach; c’est la grande ville. [^12] Mitsraïm engendra les Ludim, les Anamim, les Lehabim, les Naphtuhim, [^13] les Patrusim, les Casluhim, d’où sont sortis les Philistins, et les Caphtorim. [^14] Canaan engendra Sidon, son premier-né, et Heth; [^15] et les Jébusiens, les Amoréens, les Guirgasiens, [^16] les Héviens, les Arkiens, les Siniens, [^17] les Arvadiens, les Tsemariens, les Hamathiens. Ensuite, les familles des Cananéens se dispersèrent. [^18] Les limites des Cananéens allèrent depuis Sidon, du côté de Guérar, jusqu’à Gaza, et du côté de Sodome, de Gomorrhe, d’Adma et de Tseboïm, jusqu’à Léscha. [^19] Ce sont là les fils de Cham, selon leurs familles, selon leurs langues, selon leurs pays, selon leurs nations. [^20] Il naquit aussi des fils à Sem, père de tous les fils d’Héber, et frère de Japhet l’aîné. [^21] #1 Ch 1:17.Les fils de Sem furent: Élam, Assur, #Ge 11:10.Arpacschad, Lud et Aram. [^22] Les fils d’Aram: Uts, Hul, Guéter et Masch. [^23] #1 Ch 1:18.Arpacschad engendra Schélach; et Schélach engendra Héber. [^24] Il naquit à Héber deux fils: le nom de l’un était Péleg, parce que de son temps la terre fut partagée, et le nom de son frère était Jokthan. [^25] Jokthan engendra Almodad, Schéleph, Hatsarmaveth, Jérach, [^26] Hadoram, Uzal, Dikla, [^27] Obal, Abimaël, Séba, [^28] Ophir, Havila et Jobab. Tous ceux-là furent fils de Jokthan. [^29] Ils habitèrent depuis Méscha, du côté de Sephar, jusqu’à la montagne de l’orient. [^30] Ce sont là les fils de Sem, selon leurs familles, selon leurs langues, selon leurs pays, selon leurs nations. [^31] Telles sont les familles des fils de Noé, selon leurs générations, selon leurs nations. Et c’est d’eux que sont sorties les nations qui se sont répandues sur la terre après le déluge. [^32] 

[[Genesis - 9|<--]] Genesis - 10 [[Genesis - 11|-->]]

---
# Notes
