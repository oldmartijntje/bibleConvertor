---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 23 - Luis Segond (1910)"
---
[[Genesis - 22|<--]] Genesis - 23 [[Genesis - 24|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Genesis]]

# Genesis - 23

La vie de Sara fut de cent vingt-sept ans: telles sont les années de la vie de Sara. [^1] Sara mourut à Kirjath-Arba, qui est Hébron, dans le pays de Canaan; et Abraham vint pour mener deuil sur Sara et pour la pleurer. [^2] Abraham se leva de devant son mort, et parla ainsi aux fils de Heth: [^3] Je suis étranger et habitant parmi vous; #Ac 7:5.donnez-moi la possession d’un sépulcre chez vous, pour enterrer mon mort et l’ôter de devant moi. [^4] Les fils de Heth répondirent à Abraham, en lui disant: [^5] Écoute-nous, mon seigneur! Tu es un prince de Dieu au milieu de nous; enterre ton mort dans celui de nos sépulcres que tu choisiras; aucun de nous ne te refusera son sépulcre pour enterrer ton mort. [^6] Abraham se leva, et se prosterna devant le peuple du pays, devant les fils de Heth. [^7] Et il leur parla ainsi: Si vous permettez que j’enterre mon mort et que je l’ôte de devant mes yeux, écoutez-moi, et priez pour moi Éphron, fils de Tsochar, [^8] de me céder la caverne de Macpéla, qui lui appartient, à l’extrémité de son champ, de me la céder contre sa valeur en argent, afin qu’elle me serve de possession sépulcrale au milieu de vous. [^9] Éphron était assis parmi les fils de Heth. Et Éphron, le Héthien, répondit à Abraham, en présence des fils de Heth et de tous ceux qui entraient par la porte de sa ville: [^10] Non, mon seigneur, écoute-moi! Je te donne le champ, et je te donne la caverne qui y est. Je te les donne, aux yeux des fils de mon peuple: enterre ton mort. [^11] Abraham se prosterna devant le peuple du pays. [^12] Et il parla ainsi à Éphron, en présence du peuple du pays: Écoute-moi, je te prie! Je donne le prix du champ: accepte-le de moi; et j’y enterrerai mon mort. [^13] Et Éphron répondit à Abraham, en lui disant: [^14] Mon seigneur, écoute-moi! Une terre de quatre cents sicles d’argent, qu’est-ce que cela entre moi et toi? Enterre ton mort. [^15] #Ge 50:13.Abraham comprit Éphron; et Abraham pesa à Éphron l’argent qu’il avait dit, en présence des fils de Heth, quatre cents sicles d’argent ayant cours chez le marchand. [^16] #Ac 7:16.Le champ d’Éphron à Macpéla, vis-à-vis de Mamré, le champ et la caverne qui y est, et tous les arbres qui sont dans le champ et dans toutes ses limites alentour, [^17] devinrent ainsi la propriété d’Abraham, aux yeux des fils de Heth et de tous ceux qui entraient par la porte de sa ville. [^18] Après cela, Abraham enterra Sara, sa femme, dans la caverne du champ de Macpéla, vis-à-vis de Mamré, qui est Hébron, dans le pays de Canaan. [^19] Le champ et la caverne qui y est demeurèrent à Abraham comme possession sépulcrale, acquise des fils de Heth. [^20] 

[[Genesis - 22|<--]] Genesis - 23 [[Genesis - 24|-->]]

---
# Notes
