---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 14 - Luis Segond (1910)"
---
[[Genesis - 13|<--]] Genesis - 14 [[Genesis - 15|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Genesis]]

# Genesis - 14

Dans le temps d’Amraphel, roi de Schinear, d’Arjoc, roi d’Ellasar, de Kedorlaomer, roi d’Élam, et de Tideal, roi de Gojim, [^1] il arriva qu’ils firent la guerre à Béra, roi de Sodome, à Birscha, roi de Gomorrhe, à Schineab, roi d’Adma, à Schémeéber, roi de Tseboïm, et au roi de Béla, qui est Tsoar. [^2] Ces derniers s’assemblèrent tous dans la vallée de Siddim, qui est la mer Salée. [^3] Pendant douze ans, ils avaient été soumis à Kedorlaomer; et la treizième année, ils s’étaient révoltés. [^4] Mais, la quatorzième année, Kedorlaomer et les rois qui étaient avec lui se mirent en marche, et ils battirent les #Ge 15:20.Rephaïm à Aschteroth-Karnaïm, les Zuzim à Ham, les #De 2:10, 11.Émim à Schavé-Kirjathaïm, [^5] et les Horiens dans leur montagne de Séir, jusqu’au chêne de Paran, qui est près du désert. [^6] Puis ils s’en retournèrent, vinrent à En-Mischpath, qui est Kadès, et battirent les Amalécites sur tout leur territoire, ainsi que les Amoréens établis à Hatsatson-Thamar. [^7] Alors s’avancèrent le roi de Sodome, le roi de Gomorrhe, le roi d’Adma, le roi de Tseboïm, et le roi de Béla, qui est Tsoar; et ils se rangèrent en bataille contre eux, dans la vallée de Siddim, [^8] contre Kedorlaomer, roi d’Élam, Tideal, roi de Gojim, Amraphel, roi de Schinear, et Arjoc, roi d’Ellasar: quatre rois contre cinq. [^9] La vallée de Siddim était couverte de puits de bitume; le roi de Sodome et celui de Gomorrhe prirent la fuite, et y tombèrent; le reste s’enfuit vers la montagne. [^10] Les vainqueurs enlevèrent toutes les richesses de Sodome et de Gomorrhe, et toutes leurs provisions; et ils s’en allèrent. [^11] Ils enlevèrent aussi, avec ses biens, Lot, fils du frère d’Abram, qui demeurait à Sodome; et ils s’en allèrent. [^12] Un fuyard vint l’annoncer à Abram, l’Hébreu; celui-ci habitait parmi les #Ge 13:18.chênes de Mamré, l’Amoréen, frère d’Eschcol et frère d’Aner, qui avaient fait alliance avec Abram. [^13] Dès qu’Abram eut appris que son frère avait été fait prisonnier, il arma trois cent dix-huit de ses plus braves serviteurs, nés dans sa maison, et il poursuivit les rois jusqu’à Dan. [^14] Il divisa sa troupe, pour les attaquer de nuit, lui et ses serviteurs; il les battit, et les poursuivit jusqu’à Choba, qui est à la gauche de Damas. [^15] Il ramena toutes les richesses; il ramena aussi Lot, son frère, avec ses biens, ainsi que les femmes et le peuple. [^16] Après qu’Abram fut revenu vainqueur de Kedorlaomer et des rois qui étaient avec lui, le roi de Sodome sortit à sa rencontre dans la vallée de Schavé, qui est la vallée du roi. [^17] #Hé 7:1, 2, 3.Melchisédek, roi de Salem, fit apporter du pain et du vin: il était sacrificateur du Dieu Très-Haut. [^18] Il bénit Abram, et dit: Béni soit Abram par le Dieu Très-Haut, maître du ciel et de la terre! [^19] Béni soit le Dieu Très-Haut, qui a livré tes ennemis entre tes mains! Et Abram lui donna la dîme de tout. [^20] Le roi de Sodome dit à Abram: Donne-moi les personnes, et prends pour toi les richesses. [^21] Abram répondit au roi de Sodome: Je lève la main vers l’Éternel, le Dieu Très-Haut, maître du ciel et de la terre: [^22] je ne prendrai rien de tout ce qui est à toi, pas même un fil, ni un cordon de soulier, afin que tu ne dises pas: J’ai enrichi Abram. Rien pour moi! [^23] Seulement, ce qu’ont mangé les jeunes gens, et la part des hommes qui ont marché avec moi, Aner, Eschcol et Mamré: eux, ils prendront leur part. [^24] 

[[Genesis - 13|<--]] Genesis - 14 [[Genesis - 15|-->]]

---
# Notes
