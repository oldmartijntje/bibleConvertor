---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 50 - Luis Segond (1910)"
---
[[Genesis - 49|<--]] Genesis - 50

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Genesis]]

# Genesis - 50

Joseph se jeta sur le visage de son père, pleura sur lui, et le baisa. [^1] Il ordonna aux médecins à son service d’embaumer son père, et les médecins embaumèrent Israël. [^2] Quarante jours s’écoulèrent ainsi, et furent employés à l’embaumer. Et les Égyptiens le pleurèrent soixante-dix jours. [^3] Quand les jours du deuil furent passés, Joseph s’adressa aux gens de la maison de Pharaon, et leur dit: Si j’ai trouvé grâce à vos yeux, rapportez, je vous prie, à Pharaon ce que je vous dis. [^4] Mon père m’a #Ge 47:29.fait jurer, en disant: Voici, je vais mourir! Tu m’enterreras dans le sépulcre que je me suis acheté au pays de Canaan. Je voudrais donc y monter, pour enterrer mon père; et je reviendrai. [^5] Pharaon répondit: Monte, et enterre ton père, comme il te l’a fait jurer. [^6] Joseph monta, pour enterrer son père. Avec lui montèrent tous les serviteurs de Pharaon, anciens de sa maison, tous les anciens du pays d’Égypte, [^7] toute la maison de Joseph, ses frères, et la maison de son père: on ne laissa dans le pays de Gosen que les enfants, les brebis et les bœufs. [^8] Il y avait encore avec Joseph des chars et des cavaliers, en sorte que le cortège était très nombreux. [^9] Arrivés à l’aire d’Athad, qui est audelà du Jourdain, ils firent entendre de grandes et profondes lamentations; et Joseph fit en l’honneur de son père un deuil de sept jours. [^10] Les habitants du pays, les Cananéens, furent témoins de ce deuil dans l’aire d’Athad, et ils dirent: Voilà un grand deuil parmi les Égyptiens! C’est pourquoi l’on a donné le nom d’Abel-Mitsraïm à cette aire qui est au-delà du Jourdain. [^11] C’est ainsi que les fils de Jacob exécutèrent les ordres de leur père. [^12] #Ac 7:15, 16.Ils le transportèrent au pays de Canaan, et l’enterrèrent dans la caverne du champ de #Ge 23:16.Macpéla, qu’Abraham avait achetée d’Éphron, le Héthien, comme propriété sépulcrale, et qui est vis-à-vis de Mamré. [^13] Joseph, après avoir enterré son père, retourna en Égypte, avec ses frères et tous ceux qui étaient montés avec lui pour enterrer son père. [^14] Quand les frères de Joseph virent que leur père était mort, ils dirent: Si Joseph nous prenait en haine, et nous rendait tout le mal que nous lui avons fait! [^15] Et ils firent dire à Joseph: Ton père a donné cet ordre avant de mourir: [^16] Vous parlerez ainsi à Joseph: Oh! Pardonne le crime de tes frères et leur péché, car ils t’ont fait du mal! Pardonne maintenant le péché des serviteurs du Dieu de ton père! Joseph pleura, en entendant ces paroles. [^17] Ses frères vinrent eux-mêmes se prosterner devant lui, et ils dirent: Nous sommes tes serviteurs. [^18] Joseph leur dit: Soyez sans crainte; car suis-je #Ge 45:5.à la place de Dieu? [^19] Vous aviez médité de me faire du mal: Dieu l’a changé en bien, pour accomplir ce qui arrive aujourd’hui, pour sauver la vie à un peuple nombreux. [^20] Soyez donc sans crainte; je vous entretiendrai, vous et vos enfants. Et il les consola, en parlant à leur cœur. [^21] Joseph demeura en Égypte, lui et la maison de son père. Il vécut cent dix ans. [^22] Joseph vit les fils d’Éphraïm jusqu’à la troisième génération; et les fils de #No 32:39.Makir, fils de Manassé, naquirent sur ses genoux. [^23] Joseph dit à ses frères: Je #Hé 11:22.vais mourir! Mais Dieu vous visitera, et il vous fera remonter de ce pays-ci dans le pays qu’il a juré de donner à Abraham, à Isaac et à Jacob. [^24] Joseph fit jurer les fils d’Israël, en disant: Dieu vous visitera; #Ex 13:19. Jos 24:32.et vous ferez remonter mes os loin d’ici. [^25] Joseph mourut, âgé de cent dix ans. On l’embauma, et on le mit dans un cercueil en Égypte. [^26] 

[[Genesis - 49|<--]] Genesis - 50

---
# Notes
