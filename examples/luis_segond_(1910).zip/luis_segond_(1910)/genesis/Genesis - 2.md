---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 2 - Luis Segond (1910)"
---
[[Genesis - 1|<--]] Genesis - 2 [[Genesis - 3|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Genesis]]

# Genesis - 2

Ainsi furent achevés les cieux et la terre, et toute leur armée. [^1] #Ex 20:11, 31, 17. De 5:14. Hé 4:4.Dieu acheva au septième jour son œuvre, qu’il avait faite: et il se reposa au septième jour de toute son œuvre, qu’il avait faite. [^2] Dieu bénit le septième jour, et il le sanctifia, parce qu’en ce jour il se reposa de toute son œuvre qu’il avait créée en la faisant. [^3] Voici les origines des cieux et de la terre, quand ils furent créés. Lorsque l’Éternel Dieu fit une terre et des cieux, [^4] aucun arbuste des champs n’était encore sur la terre, et aucune herbe des champs ne germait encore: car l’Éternel Dieu n’avait pas fait pleuvoir sur la terre, et il n’y avait point d’homme pour cultiver le sol. [^5] Mais une vapeur s’éleva de la terre, et arrosa toute la surface du sol. [^6] L’Éternel Dieu forma l’homme de #1 Co 15:47.la poussière de la terre, il souffla dans ses narines un souffle de vie et l’homme devint #1 Co 15:45.un être vivant. [^7] Puis l’Éternel Dieu planta un jardin en Éden, du côté de l’orient, et il y mit l’homme qu’il avait formé. [^8] L’Éternel Dieu fit pousser du sol des arbres de toute espèce, agréables à voir et bons à manger, et #Ap 2:7.l’arbre de la vie au milieu du jardin, et l’arbre de la connaissance du bien et du mal. [^9] Un fleuve sortait d’Éden pour arroser le jardin, et de là il se divisait en quatre bras. [^10] Le nom du premier est Pischon; c’est celui qui entoure tout le pays de Havila, où se trouve l’or. [^11] L’or de ce pays est pur; on y trouve aussi le bdellium et la pierre d’onyx. [^12] Le nom du second fleuve est Guihon; c’est celui qui entoure tout le pays de Cusch. [^13] Le nom du troisième est Hiddékel; c’est celui qui coule à l’orient de l’Assyrie. Le quatrième fleuve, c’est l’Euphrate. [^14] L’Éternel Dieu prit l’homme, et le plaça dans le jardin d’Éden pour le cultiver et pour le garder. [^15] L’Éternel Dieu donna cet ordre à l’homme: Tu pourras manger de tous les arbres du jardin; [^16] mais tu ne mangeras pas de l’arbre de la connaissance du bien et du mal, car le jour où tu en mangeras, tu mourras. [^17] L’Éternel Dieu dit: Il n’est pas bon que l’homme soit seul; je lui ferai une aide semblable à lui. [^18] L’Éternel Dieu forma de la terre tous les animaux des champs et tous les oiseaux du ciel, et il les fit venir vers l’homme, pour voir comment il les appellerait, et afin que tout être vivant portât le nom que lui donnerait l’homme. [^19] Et l’homme donna des noms à tout le bétail, aux oiseaux du ciel et à tous les animaux des champs; mais, pour l’homme, il ne trouva point d’aide semblable à lui. [^20] Alors l’Éternel Dieu fit tomber un profond sommeil sur l’homme, qui s’endormit; il prit une de ses côtes, et referma la chair à sa place. [^21] L’Éternel Dieu forma une femme de la côte qu’il avait prise #1 Co 11:8.de l’homme, et il l’amena vers l’homme. [^22] Et l’homme dit: Voici cette fois celle qui est #Mal 2:14. Ép 5:30, 31.os de mes os et chair de ma chair! On l’appellera femme, parce qu’elle a été prise de l’homme. [^23] #Mt 19:5. Mc 10:7. Ép 5:31.C’est pourquoi l’homme quittera son père et sa mère, et s’attachera à sa femme, #1 Co 6:16. Ép 5:28, 29.et ils deviendront une seule chair. [^24] L’homme et sa femme étaient tous deux #Ge 3:7.nus, et ils n’en avaient point honte. [^25] 

[[Genesis - 1|<--]] Genesis - 2 [[Genesis - 3|-->]]

---
# Notes
