---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 33 - Luis Segond (1910)"
---
[[Genesis - 32|<--]] Genesis - 33 [[Genesis - 34|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Genesis]]

# Genesis - 33

Jacob leva les yeux, et regarda; et voici, Ésaü arrivait, avec quatre cents hommes. Il répartit les enfants entre Léa, Rachel, et les deux servantes. [^1] Il plaça en tête les servantes avec leurs enfants, puis Léa avec ses enfants, et enfin Rachel avec Joseph. [^2] Lui-même passa devant eux; et il se prosterna en terre sept fois, jusqu’à ce qu’il fût près de son frère. [^3] Ésaü courut à sa rencontre; il l’embrassa, se jeta à son cou, et le baisa. Et ils pleurèrent. [^4] Ésaü, levant les yeux, vit les femmes et les enfants, et il dit: Qui sont ceux que tu as là? Et Jacob répondit: Ce sont les enfants que Dieu a accordés à ton serviteur. [^5] Les servantes s’approchèrent, elles et leurs enfants, et se prosternèrent; [^6] Léa et ses enfants s’approchèrent aussi, et se prosternèrent; ensuite Joseph et Rachel s’approchèrent, et se prosternèrent. [^7] Ésaü dit: A quoi destines-tu tout ce camp que j’ai rencontré? Et Jacob répondit: A trouver grâce aux yeux de mon seigneur. [^8] Ésaü dit: Je suis dans l’abondance, mon frère; garde ce qui est à toi. [^9] Et Jacob répondit: Non, je te prie, si j’ai trouvé grâce à tes yeux, accepte de ma main mon présent; car c’est pour cela que j’ai regardé ta face comme on regarde la face de Dieu, et tu m’as accueilli favorablement. [^10] Accepte donc mon présent qui t’a été offert, puisque Dieu m’a comblé de grâces, et que je ne manque de rien. Il insista auprès de lui, et Ésaü accepta. [^11] Ésaü dit: Partons, mettons-nous en route; j’irai devant toi. [^12] Jacob lui répondit: Mon seigneur sait que les enfants sont délicats, et que j’ai des brebis et des vaches qui allaitent; si l’on forçait leur marche un seul jour, tout le troupeau périrait. [^13] Que mon seigneur prenne les devants sur son serviteur; et moi, je suivrai lentement, au pas du troupeau qui me précédera, et au pas des enfants, jusqu’à ce que j’arrive chez mon seigneur, à Séir. [^14] Ésaü dit: Je veux au moins laisser avec toi une partie de mes gens. Et Jacob répondit: Pourquoi cela? Que je trouve seulement grâce aux yeux de mon seigneur! [^15] Le même jour, Ésaü reprit le chemin de Séir. [^16] Jacob partit pour Succoth. Il bâtit une maison pour lui, et il fit des cabanes pour ses troupeaux. C’est pourquoi l’on a appelé ce lieu du nom de Succoth. [^17] A son retour de Paddan-Aram, #Jos 24:32. Ac 7:16.Jacob arriva heureusement à la ville de Sichem, dans le pays de Canaan, et il campa devant la ville. [^18] Il acheta la portion du champ où il avait dressé sa tente, des fils d’Hamor, père de Sichem, pour cent kesita. [^19] Et là, il éleva un autel, qu’il appela El-Élohé-Israël. [^20] 

[[Genesis - 32|<--]] Genesis - 33 [[Genesis - 34|-->]]

---
# Notes
