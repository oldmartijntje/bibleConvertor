---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 49 - Luis Segond (1910)"
---
[[Genesis - 48|<--]] Genesis - 49 [[Genesis - 50|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Genesis]]

# Genesis - 49

Jacob appela ses fils, et dit: Assemblez-vous, et je vous annoncerai ce qui vous arrivera dans la suite des temps. [^1] Rassemblez-vous, et écoutez, fils de Jacob!Écoutez Israël, votre père! [^2] Ruben, toi, #Ge 29:32.mon premier-né,Ma force et les prémices de ma vigueur,Supérieur en dignité et supérieur en puissance, [^3] Impétueux comme les eaux, tu n’auras pas la prééminence!#    
        Ge 35:22. 1 Ch 5:1.  Car tu es monté sur la couche de ton père,Tu as souillé ma couche en y montant. [^4] Siméon et Lévi sont frères;Leurs glaives sont des instruments de violence. [^5] Que mon âme n’entre point dans leur conciliabule,Que mon esprit ne s’unisse point à leur assemblée!Car, dans leur colère, #Ge 34:25.ils ont tué des hommes,Et, dans leur méchanceté, ils ont coupé les jarrets des taureaux. [^6] Maudite soit leur colère, car elle est violente,Et leur fureur, car elle est cruelle!Je les #Jos 19:1; 21:3, 4, etc.séparerai dans Jacob,Et je les disperserai dans Israël. [^7] Juda, tu recevras les hommages de tes frères;Ta main sera sur la nuque de tes ennemis.Les fils de ton père se prosterneront devant toi. [^8] Juda #No 24:9. Mi 5:7.est un jeune lion.Tu reviens du carnage, mon fils!Il ploie les genoux, il se couche comme un lion,Comme une lionne: qui le fera lever? [^9] Le sceptre ne s’éloignera point #Mt 2:6.de Juda,Ni le bâton souverain d’entre ses pieds,Jusqu’à ce que vienne le Schilo,Et que les peuples lui obéissent. [^10] Il attache à la vigne son âne,Et au meilleur cep le petit de son ânesse;Il lave dans le vin son vêtement,Et dans le sang des raisins son manteau. [^11] Il a les yeux rouges de vin,Et les dents blanches de lait. [^12] Zabulon habitera #Jos 19:10, 11.sur la côte des mers,Il sera sur la côte des navires,Et sa limite s’étendra du côté de Sidon. [^13] Issacar est un âne robuste,Qui se couche dans les étables. [^14] Il voit que le lieu où il repose est agréable,Et que la contrée est magnifique;Et il courbe son épaule sous le fardeau,Il s’assujettit à un tribut. [^15] Dan jugera son peuple,Comme l’une des tribus d’Israël. [^16] Dan sera un serpent sur le chemin,Une vipère sur le sentier,Mordant les talons du cheval,Pour que le cavalier tombe à la renverse. [^17] J’espère en ton secours, ô Éternel! [^18] Gad sera assailli par des bandes armées,Mais il les assaillira et les poursuivra. [^19] Aser produit une nourriture excellente;Il fournira les mets délicats des rois. [^20] Nephthali est une biche en liberté;Il profère de belles paroles. [^21] #    
        1 Ch 5:1.  Joseph est le rejeton d’un arbre fertile,Le rejeton d’un arbre fertile près d’une source;Les branches s’élèvent au-dessus de la muraille. [^22] #    
        Ge 50:20.  Ils l’ont provoqué, ils ont lancé des traits;Les archers l’ont poursuivi de leur haine. [^23] Mais son arc est demeuré ferme,Et ses mains ont été fortifiéesPar les mains du Puissant de Jacob:Il est ainsi devenu le berger, le rocher d’Israël. [^24] C’est l’œuvre du Dieu de ton père, qui t’aidera;C’est l’œuvre du Tout-Puissant, qui te béniraDes bénédictions des cieux en haut,Des bénédictions des eaux en bas,Des bénédictions des mamelles et du sein maternel. [^25] Les bénédictions de ton père s’élèventAu-dessus des bénédictions de mes pèresJusqu’à la cime des collines éternelles:Qu’elles soient sur la tête de Joseph,Sur le sommet de la tête du prince de ses frères! [^26] Benjamin est un loup qui déchire;Le matin, il dévore la proie,Et le soir, il partage le butin. [^27] Ce sont là tous ceux qui forment les douze tribus d’Israël. Et c’est là ce que leur dit leur père, en les bénissant. Il les bénit, chacun selon sa bénédiction. [^28] Puis il leur donna cet ordre: Je vais être recueilli auprès de mon peuple; enterrez-moi avec mes pères, dans la caverne qui est au champ d’Éphron, le Héthien, [^29] dans la caverne #Ge 23:9, 16.du champ de Macpéla, vis-à-vis de Mamré, dans le pays de Canaan. C’est le champ qu’Abraham a acheté d’Éphron, le Héthien, comme propriété sépulcrale. [^30] Là on a enterré #Ge 25:9; 35:29. Ac 7:16.Abraham et Sara, sa femme; là on a enterré Isaac et Rebecca, sa femme; et là j’ai enterré Léa. [^31] Le champ et la caverne qui s’y trouve ont été achetés des fils de Heth. [^32] Lorsque Jacob eut achevé de donner ses ordres à ses fils, #Ac 7:15.il retira ses pieds dans le lit, il expira, et fut recueilli auprès de son peuple. [^33] 

[[Genesis - 48|<--]] Genesis - 49 [[Genesis - 50|-->]]

---
# Notes
