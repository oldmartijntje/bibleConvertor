---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 4 - Luis Segond (1910)"
---
[[Genesis - 3|<--]] Genesis - 4 [[Genesis - 5|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Genesis]]

# Genesis - 4

Adam connut Ève, sa femme; elle conçut, et enfanta Caïn et elle dit: J’ai formé un homme avec l’aide de l’Éternel. [^1] Elle enfanta encore son frère Abel. Abel fut berger, et Caïn fut laboureur. [^2] Au bout de quelque temps, Caïn fit à l’Éternel une offrande des fruits de la terre; [^3] et Abel, de son côté, en fit une des premiers-nés de son troupeau et de leur graisse. #Hé 11:4.L’Éternel porta un regard favorable sur Abel et sur son offrande; [^4] mais il ne porta pas un regard favorable sur Caïn et sur son offrande. Caïn fut très irrité, et son visage fut abattu. [^5] Et l’Éternel dit à Caïn: Pourquoi es-tu irrité, et pourquoi ton visage est-il abattu? [^6] Certainement, si tu agis bien, tu relèveras ton visage, et si tu agis mal, le péché se couche à la porte, et ses désirs se portent vers toi: mais toi, domine sur lui. [^7] Cependant, Caïn adressa la parole à son frère Abel; mais, comme ils étaient dans les champs, Caïn se jeta sur son frère Abel, #Mt 23:35. 1 Jn 3:12. Jud v. 11.et le tua. [^8] L’Éternel dit à Caïn: Où est ton frère Abel? Il répondit: Je ne sais pas; suis-je le gardien de mon frère? [^9] Et Dieu dit: Qu’as-tu fait? #Hé 12:24.La voix du sang de ton frère crie de la terre jusqu’à moi. [^10] Maintenant, tu seras maudit de la terre qui a ouvert sa bouche pour recevoir de ta main le sang de ton frère. [^11] Quand tu cultiveras le sol, il ne te donnera plus sa richesse. #Pr 28:17.Tu seras errant et vagabond sur la terre. [^12] Caïn dit à l’Éternel: Mon châtiment est trop grand pour être supporté. [^13] Voici, tu me chasses aujourd’hui de cette terre; je serai caché loin de ta face, je serai errant et vagabond sur la terre, et #Job 15:20, 21, etc.quiconque me trouvera me tuera. [^14] L’Éternel lui dit: Si quelqu’un tuait Caïn, Caïn serait vengé sept fois. Et l’Éternel mit un signe sur Caïn pour que quiconque le trouverait ne le tuât point. [^15] Puis, Caïn s’éloigna de la face de l’Éternel, et habita dans la terre de Nod, à l’orient d’Éden. [^16] Caïn connut sa femme; elle conçut, et enfanta Hénoc. Il bâtit ensuite une ville, et il donna à cette ville le nom de son fils Hénoc. [^17] Hénoc engendra Irad, Irad engendra Mehujaël, Mehujaël engendra Metuschaël, et Metuschaël engendra Lémec. [^18] Lémec prit deux femmes: le nom de l’une était Ada, et le nom de l’autre Tsilla. [^19] Ada enfanta Jabal: il fut le père de ceux qui habitent sous des tentes et près des troupeaux. [^20] Le nom de son frère était Jubal: il fut le père de tous ceux qui jouent de la harpe et du chalumeau. [^21] Tsilla, de son côté, enfanta Tubal-Caïn, qui forgeait tous les instruments d’airain et de fer. La sœur de Tubal-Caïn était Naama. [^22] Lémec dit à ses femmes:Ada et Tsilla, écoutez ma voix!Femmes de Lémec, écoutez ma parole!J’ai tué un homme pour ma blessure,Et un jeune homme pour ma meurtrissure. [^23] Caïn sera #v. 15.vengé sept fois,Et Lémec soixante-dix-sept fois. [^24] Adam connut encore sa femme; elle enfanta un fils, et l’appela du nom de Seth, car, dit-elle, Dieu m’a donné un autre fils à la place d’Abel, que Caïn a tué. [^25] Seth eut aussi un fils, et il l’appela du nom d’Énosch. C’est alors que l’on commença à invoquer le nom de l’Éternel. [^26] 

[[Genesis - 3|<--]] Genesis - 4 [[Genesis - 5|-->]]

---
# Notes
