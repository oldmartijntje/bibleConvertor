---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 13 - Luis Segond (1910)"
---
[[Genesis - 12|<--]] Genesis - 13 [[Genesis - 14|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Genesis]]

# Genesis - 13

Abram remonta d’Égypte vers le midi, lui, sa femme, et tout ce qui lui appartenait, et Lot avec lui. [^1] Abram était très riche en troupeaux, en argent et en or. [^2] Il dirigea ses marches du midi jusqu’à Béthel, #Ge 12:8.jusqu’au lieu où était sa tente au commencement, entre Béthel et Aï, [^3] au lieu où était l’autel qu’il avait fait précédemment. Et là, Abram invoqua le #Ge 4:26; 12:8.nom de l’Éternel. [^4] Lot, qui voyageait avec Abram, avait aussi des brebis, des bœufs et des tentes. [^5] #Ge 36:7.Et la contrée était insuffisante pour qu’ils demeurassent ensemble, car leurs biens étaient si considérables qu’ils ne pouvaient demeurer ensemble. [^6] Il y eut querelle entre les bergers des troupeaux d’Abram et les bergers des troupeaux de Lot. #Ge 12:6.Les Cananéens et les Phérésiens habitaient alors dans le pays. [^7] Abram dit à Lot: Qu’il n’y ait point, je te prie, de dispute entre moi et toi, ni entre mes bergers et tes bergers; car nous sommes frères. [^8] #Ge 20:15; 34:10.Tout le pays n’est-il pas devant toi? Sépare-toi donc de moi: si tu vas à gauche, j’irai à droite; si tu vas à droite, j’irai à gauche. [^9] Lot leva les yeux, et vit toute la plaine du Jourdain, qui était entièrement arrosée. Avant que l’Éternel eût détruit Sodome et Gomorrhe, c’était, jusqu’à Tsoar, comme un jardin de l’Éternel, comme le pays d’Égypte. [^10] Lot choisit pour lui toute la plaine du Jourdain, et il s’avança vers l’orient. C’est ainsi qu’ils se séparèrent l’un de l’autre. [^11] Abram habita dans le pays de Canaan; et Lot habita dans les villes de la plaine, et dressa ses tentes jusqu’à Sodome. [^12] #Ge 18:20. Éz 16:49.Les gens de Sodome étaient méchants, et de grands pécheurs contre l’Éternel. [^13] L’Éternel dit à Abram, après que Lot se fut séparé de lui: Lève les yeux, et, du lieu où tu es, regarde vers le nord et le midi, vers l’orient et l’occident; [^14] #Ge 12:7; 15:7, 18; 17:8; 26:4. De 34:4. Ac 7:5.car tout le pays que tu vois, je le donnerai à toi et à ta postérité pour toujours. [^15] #Ge 15:5; 17:4. De 10:22. Jé 33:22. Ro 4:17, 18. Hé 11:12.Je rendrai ta postérité comme la poussière de la terre, en sorte que, si quelqu’un peut compter la poussière de la terre, ta postérité aussi sera comptée. [^16] Lève-toi, parcours le pays dans sa longueur et dans sa largeur; car je te le donnerai. [^17] Abram leva ses tentes, et vint habiter #Ge 14:13.parmi les chênes de Mamré, qui sont près d’Hébron. Et il bâtit là un autel à l’Éternel. [^18] 

[[Genesis - 12|<--]] Genesis - 13 [[Genesis - 14|-->]]

---
# Notes
