---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 20 - Luis Segond (1910)"
---
[[Genesis - 19|<--]] Genesis - 20 [[Genesis - 21|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Genesis]]

# Genesis - 20

Abraham partit de là pour la contrée du midi; il s’établit entre Kadès et Schur, et fit un séjour à Guérar. [^1] Abraham disait de Sara, sa femme: #Ge 12:13; 26:7.C’est ma sœur. Abimélec, roi de Guérar, fit enlever Sara. [^2] Alors Dieu apparut en songe à Abimélec pendant la nuit, et lui dit: Voici, tu vas mourir à cause de la femme que tu as enlevée, car elle a un mari. [^3] Abimélec, qui ne s’était point approché d’elle, répondit: Seigneur, ferais-tu périr même une nation juste? [^4] Ne m’a-t-il pas dit: C’est ma sœur? Et elle-même n’a-t-elle pas dit: C’est mon frère? J’ai agi avec un cœur pur et avec des mains innocentes. [^5] Dieu lui dit en songe: Je sais que tu as agi avec un cœur pur; aussi t’ai-je empêché de pécher contre moi. C’est pourquoi je n’ai pas permis que tu la touchasses. [^6] Maintenant, rends la femme de cet homme; car il est prophète, il priera pour toi, et tu vivras. Mais, si tu ne la rends pas, sache que tu mourras, toi et tout ce qui t’appartient. [^7] Abimélec se leva de bon matin, il appela tous ses serviteurs, et leur rapporta toutes ces choses; et ces gens furent saisis d’une grande frayeur. [^8] Abimélec appela aussi Abraham, et lui dit: Qu’est-ce que tu nous as fait? Et en quoi t’ai-je offensé, que tu aies fait venir sur moi et sur mon royaume un si grand péché? Tu as commis à mon égard des actes qui ne doivent pas se commettre. [^9] Et Abimélec dit à Abraham: Quelle intention avais-tu pour agir de la sorte? [^10] Abraham répondit: Je me disais qu’il n’y avait sans doute aucune crainte de Dieu dans ce pays, et que l’on me tuerait à cause de ma femme. [^11] De plus, il est vrai qu’elle est ma sœur, fille de mon père; seulement, elle n’est pas fille de ma mère; et elle est devenue ma femme. [^12] Lorsque Dieu me fit errer loin de la maison de mon père, je dis à Sara: Voici la grâce que tu me feras; dans tous les lieux où nous irons, #Ge 12:13.dis de moi: C’est mon frère. [^13] Abimélec prit des brebis et des bœufs, des serviteurs et des servantes, et les donna à Abraham; et il lui rendit Sara, sa femme. [^14] Abimélec dit: Voici, mon pays est devant toi; demeure où il te plaira. [^15] Et il dit à Sara: Voici, je donne à ton frère mille pièces d’argent; cela te sera un voile sur les yeux pour tous ceux qui sont avec toi, et auprès de tous tu seras justifiée. [^16] Abraham pria Dieu, et Dieu guérit Abimélec, sa femme et ses servantes; et elles purent enfanter. [^17] Car l’Éternel avait frappé de stérilité toute la maison d’Abimélec, à cause de Sara, femme d’Abraham. [^18] 

[[Genesis - 19|<--]] Genesis - 20 [[Genesis - 21|-->]]

---
# Notes
