---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 15 - Luis Segond (1910)"
---
[[Genesis - 14|<--]] Genesis - 15 [[Genesis - 16|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Genesis]]

# Genesis - 15

Après ces événements, la parole de l’Éternel fut adressée à Abram dans une vision, et il dit: Abram, ne crains point; #Ps 16:6; 18:3; 19:12.je suis ton bouclier, et ta récompense sera très grande. [^1] Abram répondit: Seigneur Éternel, que me donneras-tu? Je m’en vais sans enfants; et l’héritier de ma maison, c’est Éliézer de Damas. [^2] Et Abram dit: Voici, tu ne m’as pas donné de postérité, et celui qui est né dans ma maison sera mon héritier. [^3] Alors la parole de l’Éternel lui fut adressée ainsi: Ce n’est pas lui qui sera ton héritier, mais c’est celui qui sortira de tes entrailles qui sera ton héritier. [^4] Et après l’avoir conduit dehors, il dit: Regarde vers le ciel, et compte les étoiles, si tu peux les compter. Et il lui dit: #Ex 32:13. De 10:22. Ro 4:18. Hé 11:12.Telle sera ta postérité. [^5] #Ro 4:3, 9, 18, 22. Ga 3:6. Ja 2:23.Abram eut confiance en l’Éternel, qui le lui imputa à justice. [^6] L’Éternel lui dit encore: Je suis l’Éternel, qui t’ai fait sortir d’Ur en Chaldée, #Ps 105:11.pour te donner en possession ce pays. [^7] Abram répondit: Seigneur Éternel, à quoi connaîtrai-je que je le posséderai? [^8] Et l’Éternel lui dit: Prends une génisse de trois ans, une chèvre de trois ans, un bélier de trois ans, une tourterelle et une jeune colombe. [^9] Abram prit tous ces animaux, les coupa par le milieu, et mit chaque morceau l’un vis-à-vis de l’autre; mais il ne partagea point les oiseaux. [^10] Les oiseaux de proie s’abattirent sur les cadavres; et Abram les chassa. [^11] Au coucher du soleil, un profond sommeil tomba sur Abram; et voici, une frayeur et une grande obscurité vinrent l’assaillir. [^12] Et l’Éternel dit à Abram: Sache #Ex 12:40. Ac 7:6. Ga 3:17.que tes descendants seront étrangers dans un pays qui ne sera point à eux; ils y seront asservis, et on les opprimera pendant quatre cents ans. [^13] Mais je jugerai la nation à laquelle ils seront asservis, et ils sortiront ensuite #Ex 3:22; 11:2; 12:35, 36.avec de grandes richesses. [^14] #Ge 25:7, 8.Toi, tu iras en paix vers tes pères, tu seras enterré après une heureuse vieillesse. [^15] #Ex 12:40.A la quatrième génération, ils reviendront ici; car l’iniquité des Amoréens n’est pas encore à son comble. [^16] Quand le soleil fut couché, il y eut une obscurité profonde; et voici, ce fut une fournaise fumante, et des flammes passèrent entre les animaux partagés. [^17] En ce jour-là, l’Éternel fit alliance avec Abram, et dit: #Ge 12:7; 13:15; 24:7; 26:4. Ex 32:13. De 1:8; 34:4.Je donne ce pays à ta postérité, depuis le fleuve d’Égypte jusqu’au grand fleuve, au fleuve d’Euphrate, [^18] le pays des Kéniens, des Keniziens, des Kadmoniens, [^19] des Héthiens, des Phéréziens, des Rephaïm, [^20] des Amoréens, des Cananéens, des Guirgasiens et des Jébusiens. [^21] 

[[Genesis - 14|<--]] Genesis - 15 [[Genesis - 16|-->]]

---
# Notes
