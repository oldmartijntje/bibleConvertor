---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 40 - Luis Segond (1910)"
---
[[Genesis - 39|<--]] Genesis - 40 [[Genesis - 41|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Genesis]]

# Genesis - 40

Après ces choses, il arriva que l’échanson et le panetier du roi d’Égypte, offensèrent leur maître, le roi d’Égypte. [^1] Pharaon fut irrité contre ses deux officiers, le chef des échansons et le chef des panetiers. [^2] Et il les fit mettre dans la maison du chef des gardes, dans la prison, dans le lieu où Joseph était enfermé. [^3] Le chef des gardes les plaça sous la surveillance de Joseph, qui faisait le service auprès d’eux; et ils passèrent un certain temps en prison. [^4] Pendant une même nuit, l’échanson et le panetier du roi d’Égypte, qui étaient enfermés dans la prison, eurent tous les deux un songe, chacun le sien, pouvant recevoir une explication distincte. [^5] Joseph, étant venu le matin vers eux, les regarda; et voici, ils étaient tristes. [^6] Alors il questionna les officiers de Pharaon, qui étaient avec lui dans la prison de son maître, et il leur dit: Pourquoi avez-vous mauvais visage aujourd’hui? [^7] Ils lui répondirent: Nous avons eu un songe, et il n’y a personne pour l’expliquer. Joseph leur dit: N’est-ce pas à Dieu qu’appartiennent les explications? Racontez-moi donc votre songe. [^8] Le chef des échansons raconta son songe à Joseph, et lui dit: Dans mon songe, voici, il y avait un cep devant moi. [^9] Ce cep avait trois sarments. Quand il eut poussé, sa fleur se développa et ses grappes donnèrent des raisins mûrs. [^10] La coupe de Pharaon était dans ma main. Je pris les raisins, je les pressai dans la coupe de Pharaon, et je mis la coupe dans la main de Pharaon. [^11] Joseph lui dit: En voici l’explication. Les trois sarments sont trois jours. [^12] Encore trois jours, et Pharaon relèvera ta tête et te rétablira dans ta charge; tu mettras la coupe dans la main de Pharaon, comme tu en avais l’habitude lorsque tu étais son échanson. [^13] Mais souviens-toi de moi, quand tu seras heureux, et montre, je te prie, de la bonté à mon égard; parle en ma faveur à Pharaon, et fais-moi sortir de cette maison. [^14] Car j’ai été enlevé du pays des Hébreux, et ici même je n’ai rien fait pour être mis en prison. [^15] Le chef des panetiers, voyant que Joseph avait donné une explication favorable, dit: Voici, il y avait aussi, dans mon songe, trois corbeilles de pain blanc sur ma tête. [^16] Dans la corbeille la plus élevée il y avait pour Pharaon des mets de toute espèce, cuits au four; et les oiseaux les mangeaient dans la corbeille au-dessus de ma tête. [^17] Joseph répondit, et dit: En voici l’explication. Les trois corbeilles sont trois jours. [^18] Encore trois jours, et Pharaon enlèvera ta tête de dessus toi, te fera pendre à un bois, et les oiseaux mangeront ta chair. [^19] Le troisième jour, jour de la naissance de Pharaon, il fit un festin à tous ses serviteurs; et il éleva la tête du chef des échansons et la tête du chef des panetiers, au milieu de ses serviteurs: [^20] il rétablit le chef des échansons dans sa charge d’échanson, pour qu’il mît la coupe dans la main de Pharaon; [^21] mais il fit pendre le chef des panetiers, selon l’explication que Joseph leur avait donnée. [^22] Le chef des échansons ne pensa plus à Joseph. Il l’oublia. [^23] 

[[Genesis - 39|<--]] Genesis - 40 [[Genesis - 41|-->]]

---
# Notes
