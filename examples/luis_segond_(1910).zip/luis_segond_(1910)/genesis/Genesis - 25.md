---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 25 - Luis Segond (1910)"
---
[[Genesis - 24|<--]] Genesis - 25 [[Genesis - 26|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Genesis]]

# Genesis - 25

Abraham prit encore une femme, nommée Ketura. [^1] #1 Ch 1:32.Elle lui enfanta Zimran, Jokschan, Medan, Madian, Jischbak et Schuach. [^2] Jokschan engendra Séba et Dedan. Les fils de Dedan furent les Aschurim, les Letuschim et les Leummim. [^3] Les fils de Madian furent Épha, Épher, Hénoc, Abida et Eldaa. Ce sont là tous les fils de Ketura. [^4] #Ge 24:36.Abraham donna tous ses biens à Isaac. [^5] Il fit des dons aux fils de ses concubines; et, tandis qu’il vivait encore, il les envoya loin de son fils Isaac du côté de l’orient, dans le pays d’Orient. [^6] Voici les jours des années de la vie d’Abraham: il vécut cent soixante quinze ans. [^7] Abraham expira et mourut, #Ge 15:15.après une heureuse vieillesse, âgé et rassasié de jours, et il fut recueilli auprès de son peuple. [^8] Isaac et Ismaël, ses fils, l’enterrèrent dans la caverne de Macpéla, dans le champ d’Éphron, fils de Tsochar, le Héthien, vis-à-vis de Mamré. [^9] C’est le champ qu’Abraham avait acquis des fils de Heth. Là furent enterrés Abraham et Sara, sa femme. [^10] Après la mort d’Abraham, Dieu bénit Isaac, son fils. Il habitait près du puits de Lachaï-roï. [^11] Voici la postérité d’Ismaël, fils d’Abraham, qu’Agar, l’Égyptienne, servante de Sara, avait enfanté à Abraham. [^12] Voici #1 Ch 1:29.les noms des fils d’Ismaël, par leurs noms, selon leurs générations: Nebajoth, premier-né d’Ismaël, Kédar, Adbeel, Mibsam, [^13] Mischma, Duma, Massa, [^14] Hadad, Théma, Jethur, Naphisch et Kedma. [^15] Ce sont là les fils d’Ismaël; ce sont là leurs noms, selon leurs parcs et leurs enclos. Ils furent les douze chefs de leurs peuples. [^16] Et voici les années de la vie d’Ismaël: cent trente-sept ans. Il expira et mourut, et il fut recueilli auprès de son peuple. [^17] Ses fils habitèrent depuis Havila jusqu’à Schur, qui est en face de l’Égypte, en allant vers l’Assyrie. Il s’établit en présence de tous ses frères. [^18] Voici la postérité d’Isaac, fils d’Abraham. [^19] Abraham engendra Isaac. Isaac était âgé de quarante ans, quand il prit pour femme Rebecca, fille de Bethuel, l’Araméen, de Paddan-Aram, et sœur de Laban, l’Araméen. [^20] Isaac implora l’Éternel pour sa femme, car elle était stérile, et l’Éternel l’exauça: #Ro 9:10.Rebecca, sa femme, devint enceinte. [^21] Les enfants se heurtaient dans son sein; et elle dit: S’il en est ainsi, pourquoi suis-je enceinte? Elle alla consulter l’Éternel. [^22] Et l’Éternel lui dit: Deux nations sont dans ton ventre, et deux peuples se sépareront au sortir de tes entrailles; #2 S 8:14.un de ces peuples sera plus fort que l’autre, et #Ro 9:12.le plus grand sera assujetti au plus petit. [^23] Les jours où elle devait accoucher s’accomplirent; et voici, il y avait deux jumeaux dans son ventre. [^24] Le premier sortit entièrement roux, comme un manteau de poil; et on lui donna le nom d’Ésaü. [^25] Ensuite sortit son frère, #Os 12:4.dont la main tenait le talon d’Ésaü; et on lui donna le nom de Jacob. Isaac était âgé de soixante ans, lorsqu’ils naquirent. [^26] Ces enfants grandirent. Ésaü devint un habile chasseur, un homme des champs; mais Jacob fut un homme tranquille, qui restait sous les tentes. [^27] Isaac aimait Ésaü, parce qu’il mangeait du gibier; et Rebecca aimait Jacob. [^28] Comme Jacob faisait cuire un potage, Ésaü revint des champs, accablé de fatigue. [^29] Et Ésaü dit à Jacob: Laisse-moi, je te prie, manger de ce roux, de ce roux-là, car je suis fatigué. C’est pour cela qu’on a donné à Ésaü le nom d’Édom. [^30] Jacob dit: Vends-moi aujourd’hui ton droit d’aînesse. [^31] Ésaü répondit: Voici, je m’en vais mourir; à quoi me sert ce droit d’aînesse? [^32] Et Jacob dit: Jure-le moi d’abord. Il le lui jura, et il vendit son droit d’aînesse à Jacob. [^33] Alors Jacob donna à Ésaü du pain et du potage de lentilles. Il mangea et but, puis se leva et s’en alla. C’est ainsi qu’Ésaü méprisa le droit d’aînesse. [^34] 

[[Genesis - 24|<--]] Genesis - 25 [[Genesis - 26|-->]]

---
# Notes
