---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 7 - Luis Segond (1910)"
---
[[Genesis - 6|<--]] Genesis - 7 [[Genesis - 8|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Genesis]]

# Genesis - 7

L’Éternel dit #2 Pi 2:5.à Noé: Entre dans l’arche, toi et toute ta maison; car je #Ge 6:9.t’ai vu juste devant moi parmi cette génération. [^1] #Lé 11.Tu prendras auprès de toi sept couples de tous les animaux purs, le mâle et sa femelle; une paire des animaux qui ne sont pas purs, le mâle et sa femelle; [^2] sept couples aussi des oiseaux du ciel, mâle et femelle, afin de conserver leur race en vie sur la face de toute la terre. [^3] Car, encore sept jours, et je ferai pleuvoir sur la terre quarante jours et quarante nuits, et j’exterminerai de la face de la terre tous les êtres que j’ai faits. [^4] #Ge 6:22.Noé exécuta tout ce que l’Éternel lui avait ordonné. [^5] Noé avait six cents ans, lorsque le déluge d’eaux fut sur la terre. [^6] Et Noé #Mt 24:38. Lu 17:27. 1 Pi 3:20.entra dans l’arche avec ses fils, sa femme et les femmes de ses fils, pour échapper aux eaux du déluge. [^7] D’entre les animaux purs et les animaux qui ne sont pas purs, les oiseaux et tout ce qui se meut sur la terre, [^8] il entra dans l’arche auprès de Noé, deux à deux, un mâle et une femelle, comme Dieu l’avait ordonné à Noé. [^9] Sept jours après, les eaux du déluge furent sur la terre. [^10] L’an six cent de la vie de Noé, le second mois, le dix-septième jour du mois, en ce jour-là toutes les sources du grand abîme jaillirent, et les écluses des cieux s’ouvrirent. [^11] La pluie tomba sur la terre quarante jours et quarante nuits. [^12] Ce même jour entrèrent dans l’arche Noé, Sem, Cham et Japhet, fils de Noé, la femme de Noé et les trois femmes de ses fils avec eux: [^13] eux, et tous les animaux selon leur espèce, tout le bétail selon son espèce, tous les reptiles qui rampent sur la terre selon leur espèce, tous les oiseaux selon leur espèce, tous les petits oiseaux, tout ce qui a des ailes. [^14] Ils entrèrent dans l’arche auprès de Noé, deux à deux, de toute chair ayant souffle de vie. [^15] Il en entra, mâle et femelle, de toute chair, comme Dieu l’avait ordonné à Noé. Puis l’Éternel ferma la porte sur lui. [^16] Le déluge fut quarante jours sur la terre. Les eaux crûrent et soulevèrent l’arche, et elle s’éleva au-dessus de la terre. [^17] Les eaux grossirent et s’accrurent beaucoup sur la terre, et l’arche flotta sur la surface des eaux. [^18] Les eaux grossirent de plus en plus, et toutes les hautes montagnes qui sont sous le ciel entier furent couvertes. [^19] Les eaux s’élevèrent de quinze coudées au-dessus des montagnes, qui furent couvertes. [^20] #Lu 17:27.Tout ce qui se mouvait sur la terre périt, tant les oiseaux que le bétail et les animaux, tout ce qui rampait sur la terre, et tous les hommes. [^21] Tout ce qui avait respiration, souffle de vie dans ses narines, et qui était sur la terre sèche, mourut. [^22] Tous les êtres qui étaient sur la face de la terre furent exterminés, depuis l’homme jusqu’au bétail, aux reptiles et aux oiseaux du ciel: ils furent exterminés de la terre. #2 Pi 2:5.Il ne resta que Noé, et ce qui était avec lui dans l’arche. [^23] Les eaux furent grosses sur la terre pendant cent cinquante jours. [^24] 

[[Genesis - 6|<--]] Genesis - 7 [[Genesis - 8|-->]]

---
# Notes
