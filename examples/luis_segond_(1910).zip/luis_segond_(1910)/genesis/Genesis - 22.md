---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 22 - Luis Segond (1910)"
---
[[Genesis - 21|<--]] Genesis - 22 [[Genesis - 23|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Genesis]]

# Genesis - 22

Après ces choses, Dieu mit Abraham à l’épreuve, et lui dit: Abraham! Et il répondit: Me voici! [^1] Dieu dit: Prends ton fils, #Hé 11:17.ton unique, celui que tu aimes, Isaac; va-t’en au pays de Morija, et là offre-le en holocauste sur l’une des montagnes que je te dirai. [^2] Abraham se leva de bon matin, sella son âne, et prit avec lui deux serviteurs et son fils Isaac. Il fendit du bois pour l’holocauste, et partit pour aller au lieu que Dieu lui avait dit. [^3] Le troisième jour, Abraham, levant les yeux, vit le lieu de loin. [^4] Et Abraham dit à ses serviteurs: Restez ici avec l’âne; moi et le jeune homme, nous irons jusque-là pour adorer, et nous reviendrons auprès de vous. [^5] Abraham prit le bois pour l’holocauste, le chargea sur son fils Isaac, et porta dans sa main le feu et le couteau. Et ils marchèrent tous deux ensemble. [^6] Alors Isaac, parlant à Abraham, son père, dit: Mon père! Et il répondit: Me voici, mon fils! Isaac reprit: Voici le feu et le bois; mais où est l’agneau pour l’holocauste? [^7] Abraham répondit: Mon fils, Dieu se pourvoira lui-même de l’agneau pour l’holocauste. Et ils marchèrent tous deux ensemble. [^8] Lorsqu’ils furent arrivés au lieu que Dieu lui avait dit, Abraham y éleva un autel, et rangea le bois. Il lia son fils Isaac, et #Ja 2:21.le mit sur l’autel, par-dessus le bois. [^9] Puis Abraham étendit la main, et prit le couteau, pour égorger son fils. [^10] Alors l’ange de l’Éternel l’appela des cieux, et dit: Abraham! Abraham! Et il répondit: Me voici! [^11] L’ange dit: N’avance pas ta main sur l’enfant, et ne lui fais rien; car je sais maintenant que tu crains Dieu, et que tu ne m’as pas refusé ton fils, ton unique. [^12] Abraham leva les yeux, et vit derrière lui un bélier retenu dans un buisson par les cornes; et Abraham alla prendre le bélier, et l’offrit en holocauste à la place de son fils. [^13] Abraham donna à ce lieu le nom de Jehova-Jiré. C’est pourquoi l’on dit aujourd’hui: A la montagne de l’Éternel il sera pourvu. [^14] L’ange de l’Éternel appela une seconde fois Abraham des cieux, [^15] et dit: #Lu 1:73.Je le jure #Hé 6:13.par moi-même, parole de l’Éternel! Parce que tu as fait cela, et que tu n’as pas refusé ton fils, ton unique, [^16] je te bénirai et je multiplierai ta postérité, comme les étoiles du ciel et comme le sable qui est sur le bord de la mer; #Ge 24:60.et ta postérité possédera la porte de ses ennemis. [^17] #Ge 12:3; 18:18; 26:4. Ac 3:25. Ga 3:8.Toutes les nations de la terre seront bénies en ta postérité, parce que tu as obéi à ma voix. [^18] Abraham étant retourné vers ses serviteurs, ils se levèrent et s’en allèrent ensemble à Beer-Schéba; car Abraham demeurait à Beer-Schéba. [^19] Après ces choses, on fit à Abraham un rapport, en disant: Voici, Milca a aussi enfanté des fils à Nachor, ton frère: [^20] Uts, son premier-né, Buz, son frère, Kemuel, père d’Aram, [^21] Késed, Hazo, Pildasch, Jidlaph et Bethuel. [^22] Bethuel a engendré Rebecca. Ce sont là les huit fils que Milca a enfantés à Nachor, frère d’Abraham. [^23] Sa concubine, nommée Réuma, a aussi enfanté Thébach, Gaham, Tahasch et Maaca. [^24] 

[[Genesis - 21|<--]] Genesis - 22 [[Genesis - 23|-->]]

---
# Notes
