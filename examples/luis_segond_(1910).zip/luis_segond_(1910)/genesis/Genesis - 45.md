---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 45 - Luis Segond (1910)"
---
[[Genesis - 44|<--]] Genesis - 45 [[Genesis - 46|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Genesis]]

# Genesis - 45

Joseph ne pouvait plus se contenir devant tous ceux qui l’entouraient. Il s’écria: Faites sortir tout le monde. Et il ne resta personne avec Joseph, quand il se fit connaître à ses frères. [^1] Il éleva la voix, en pleurant. Les Égyptiens l’entendirent, et la maison de Pharaon l’entendit. [^2] Joseph dit à ses frères: Je suis Joseph! Mon père vit-il encore? Mais ses frères ne purent lui répondre, car ils étaient troublés en sa présence. [^3] Joseph dit à ses frères: Approchez-vous de moi. Et ils s’approchèrent. Il dit: #Ac 7:13.Je suis Joseph, votre frère, #Ge 37:28. Ps 105:17. Ac 7:9.que vous avez vendu pour être mené en Égypte. [^4] Maintenant, #Ge 50: 19, 20, 21.ne vous affligez pas, et ne soyez pas fâchés de m’avoir vendu pour être conduit ici, car c’est pour vous sauver la vie que Dieu m’a envoyé devant vous. [^5] Voilà deux ans que la famine est dans le pays; et pendant cinq années encore, il n’y aura ni labour, ni moisson. [^6] Dieu m’a envoyé devant vous pour vous faire subsister dans le pays, et pour vous faire vivre par une grande délivrance. [^7] Ce n’est donc pas vous qui m’avez envoyé ici, mais c’est Dieu; il m’a établi père de Pharaon, maître de toute sa maison, et gouverneur de tout le pays d’Égypte. [^8] Hâtez-vous de remonter auprès de mon père, et vous lui direz: Ainsi a parlé ton fils Joseph: Dieu m’a établi seigneur de toute l’Égypte; descends vers moi, ne tarde pas! [^9] Tu habiteras dans le pays de Gosen, et tu seras près de moi, toi, tes fils, et les fils de tes fils, tes brebis et tes bœufs, et tout ce qui est à toi. [^10] Là, je te nourrirai, car il y aura encore cinq années de famine; et ainsi tu ne périras point, toi, ta maison, et tout ce qui est à toi. [^11] Vous voyez de vos yeux, et mon frère Benjamin voit de ses yeux que c’est moi-même qui vous parle. [^12] Racontez à mon père toute ma gloire en Égypte, et tout ce que vous avez vu; et #Ac 7:14.vous ferez descendre ici mon père au plus tôt. [^13] Il se jeta au cou de Benjamin, son frère, et pleura; et Benjamin pleura sur son cou. [^14] Il embrassa aussi tous ses frères, en pleurant. Après quoi, ses frères s’entretinrent avec lui. [^15] Le bruit se répandit dans la maison de Pharaon que les frères de Joseph étaient arrivés: ce qui fut agréable à Pharaon et à ses serviteurs. [^16] Pharaon dit à Joseph: Dis à tes frères: Faites ceci. Chargez vos bêtes, et partez pour le pays de Canaan; [^17] prenez votre père et vos familles, et venez auprès de moi. Je vous donnerai ce qu’il y a de meilleur au pays d’Égypte, et vous mangerez la graisse du pays. [^18] Tu as ordre de leur dire: Faites ceci. Prenez dans le pays d’Égypte des chars pour vos enfants et pour vos femmes; amenez votre père, et venez. [^19] Ne regrettez point ce que vous laisserez, car ce qu’il y a de meilleur dans tout le pays d’Égypte sera pour vous. [^20] Les fils d’Israël firent ainsi. Joseph leur donna des chars, selon l’ordre de Pharaon; il leur donna aussi des provisions pour la route. [^21] Il leur donna à tous des vêtements de rechange, et il donna à Benjamin trois cents sicles d’argent et cinq vêtements de rechange. [^22] Il envoya à son père dix ânes chargés de ce qu’il y avait de meilleur en Égypte, et dix ânesses chargées de blé, de pain et de vivres, pour son père pendant le voyage. [^23] Puis il congédia ses frères, qui partirent; et il leur dit: Ne vous querellez pas en chemin. [^24] Ils remontèrent de l’Égypte, et ils arrivèrent dans le pays de Canaan, auprès de Jacob, leur père. [^25] Ils lui dirent: Joseph vit encore, et même c’est lui qui gouverne tout le pays d’Égypte. Mais le cœur de Jacob resta froid, parce qu’il ne les croyait pas. [^26] Ils lui rapportèrent toutes les paroles que Joseph leur avait dites. Il vit les chars que Joseph avait envoyés pour le transporter. C’est alors que l’esprit de Jacob, leur père, se ranima; [^27] et Israël dit: C’est assez! Joseph, mon fils, vit encore! J’irai, et je le verrai avant que je meure. [^28] 

[[Genesis - 44|<--]] Genesis - 45 [[Genesis - 46|-->]]

---
# Notes
