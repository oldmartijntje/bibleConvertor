---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 5 - Luis Segond (1910)"
---
[[Genesis - 4|<--]] Genesis - 5 [[Genesis - 6|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Genesis]]

# Genesis - 5

Voici le livre de la postérité d’Adam. Lorsque Dieu créa l’homme, il le fit #Ge 1:26; 9:6. 1 Co 11:7.à la ressemblance de Dieu. [^1] #Ge 1:26. Mt 19:4. Mc 10:6.Il créa l’homme et la femme, il les bénit, et il les appela du nom d’homme, lorsqu’ils furent créés. [^2] Adam, âgé de cent trente ans, engendra un fils à sa ressemblance, selon son image, et il lui donna le nom de Seth. [^3] Les jours d’Adam, #1 Ch 1:1.après la naissance de Seth, furent de huit cents ans; et il engendra des fils et des filles. [^4] Tous les jours qu’Adam vécut furent de neuf cent trente ans; puis il mourut. [^5] Seth, âgé de cent cinq ans, #Ge 4:26.engendra Énosch. [^6] Seth vécut, après la naissance d’Énosch, huit cent sept ans; et il engendra des fils et des filles. [^7] Tous les jours de Seth furent de neuf cent douze ans; puis il mourut. [^8] Énosch, âgé de quatre-vingt-dix ans, engendra #1 Ch 1:2.Kénan. [^9] Énosch vécut, après la naissance de Kénan, huit cent quinze ans; et il engendra des fils et des filles. [^10] Tous les jours d’Énosch furent de neuf cent cinq ans; puis il mourut. [^11] Kénan, âgé de soixante-dix ans, engendra Mahalaleel. [^12] Kénan vécut, après la naissance de Mahalaleel, huit cent quarante ans; et il engendra des fils et des filles. [^13] Tous les jours de Kénan furent de neuf cent dix ans; puis il mourut. [^14] Mahalaleel, âgé de soixante-cinq ans, engendra Jéred. [^15] Mahalaleel vécut, après la naissance de Jéred, huit cent trente ans; et il engendra des fils et des filles. [^16] Tous les jours de Mahalaleel furent de huit cent quatre-vingt-quinze ans; puis il mourut. [^17] Jéred, âgé de cent soixante-deux ans, engendra #1 Ch 1:3.Hénoc. [^18] Jéred vécut, après la naissance d’Hénoc, huit cents ans; et il engendra des fils et des filles. [^19] Tous les jours de Jéred furent de neuf cent soixante-deux ans; puis il mourut. [^20] #Jud v. 14.Hénoc, âgé de soixante-cinq ans, engendra Metuschélah. [^21] #Hé 11:5.Hénoc, après la naissance de Metuschélah, marcha avec Dieu trois cents ans; et il engendra des fils et des filles. [^22] Tous les jours d’Hénoc furent de trois cent soixante-cinq ans. [^23] Hénoc marcha avec Dieu; puis il ne fut plus, #2 R 2:11. Hé 11:5.parce que Dieu le prit. [^24] Metuschélah, âgé de cent quatre-vingt-sept ans, engendra Lémec. [^25] Metuschélah vécut, après la naissance de Lémec, sept cent quatre-vingt-deux ans; et il engendra des fils et des filles. [^26] Tous les jours de Metuschélah furent de neuf cent soixante-neuf ans; puis il mourut. [^27] Lémec, âgé de cent quatre-vingt-deux ans, engendra un fils. [^28] Il lui donna le nom de Noé, en disant: Celui-ci nous consolera de nos fatigues et du travail pénible de nos mains, provenant de cette terre que l’Éternel a maudite. [^29] Lémec vécut, après la naissance de Noé, cinq cent quatre-vingt-quinze ans; et il engendra des fils et des filles. [^30] Tous les jours de Lémec furent de sept cent soixante-dix sept ans; puis il mourut. [^31] Noé, âgé de cinq cents ans, engendra Sem, Cham et Japhet. [^32] 

[[Genesis - 4|<--]] Genesis - 5 [[Genesis - 6|-->]]

---
# Notes
