---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 35 - Luis Segond (1910)"
---
[[Genesis - 34|<--]] Genesis - 35 [[Genesis - 36|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Genesis]]

# Genesis - 35

Dieu dit à Jacob: Lève-toi, monte à Béthel, et demeures-y; là, tu dresseras un autel au Dieu qui #Ge 28:12, 13.t’apparut, #Ge 27:43.lorsque tu fuyais Ésaü, ton frère. [^1] Jacob dit à sa maison et à tous ceux qui étaient avec lui: Otez les dieux étrangers qui sont au milieu de vous, purifiez-vous, et changez de vêtements. [^2] Nous nous lèverons, et nous monterons à Béthel; là, je dresserai un autel au Dieu qui m’a exaucé dans le jour de ma détresse, et qui a été avec moi pendant le voyage que j’ai fait. [^3] Ils donnèrent à Jacob tous les dieux étrangers qui étaient entre leurs mains, et les anneaux qui étaient à leurs oreilles. Jacob les enfouit sous le térébinthe qui est près de Sichem. [^4] Ensuite ils partirent. La terreur de Dieu se répandit sur les villes qui les entouraient, et l’on ne poursuivit point les fils de Jacob. [^5] Jacob arriva, lui et tous ceux qui étaient avec lui, à Luz, qui est Béthel, dans le pays de Canaan. [^6] Il bâtit là un autel, et #Ge 28:19.il appela ce lieu El-Béthel; car c’est là que Dieu s’était révélé à lui lorsqu’il fuyait son frère. [^7] Débora, nourrice de Rebecca, mourut; et elle fut enterrée au-dessous de Béthel, sous le chêne auquel on a donné le nom de chêne des pleurs. [^8] #Os 12:5.Dieu apparut encore à Jacob, après son retour de Paddan-Aram, et il le bénit. [^9] Dieu lui dit: Ton nom est Jacob; #Ge 32:28. 2 Ch 17:34.tu ne seras plus appelé Jacob, mais ton nom sera Israël. Et il lui donna le nom d’Israël. [^10] Dieu lui dit: #Ge 17:1; 28:3; 48:3.Je suis le Dieu tout-puissant. Sois fécond, et multiplie: #Ge 17:6, 16.une nation et une multitude de nations naîtront de toi, et #Mt 1:6.des rois sortiront de tes reins. [^11] Je te donnerai le pays que j’ai donné à Abraham et à Isaac, et je donnerai ce pays à ta postérité après toi. [^12] Dieu s’éleva au-dessus de lui, dans le lieu où il lui avait parlé. [^13] Et Jacob #Ge 28:18.dressa un monument dans le lieu où Dieu lui avait parlé, un monument de pierres, sur lequel il fit une libation et versa de l’huile. [^14] Jacob donna le nom de Béthel au lieu où Dieu lui avait parlé. [^15] Ils partirent de Béthel; et il y avait encore une certaine distance jusqu’à Éphrata, lorsque Rachel accoucha. Elle eut un accouchement pénible; [^16] et pendant les douleurs de l’enfantement, la sage-femme lui dit: Ne crains point, car tu as encore un fils! [^17] Et comme elle allait rendre l’âme, car elle était mourante, elle lui donna le nom de Ben-Oni; mais le père l’appela Benjamin. [^18] #Ge 48:7.Rachel mourut, et elle fut enterrée sur le chemin d’Éphrata, qui est Bethléhem. [^19] Jacob éleva un monument sur son sépulcre; c’est le monument du sépulcre de Rachel, qui existe encore aujourd’hui. [^20] Israël partit; et il dressa sa tente au-delà de Migdal-Éder. [^21] Pendant qu’Israël habitait cette contrée, #Ge 49:4.Ruben alla coucher avec Bilha, concubine de son père. Et Israël l’apprit. Les fils de Jacob étaient au nombre de douze. [^22] #Ge 46:8. Ex 1:2.Fils de Léa: Ruben, premier-né de Jacob, Siméon, Lévi, Juda, Issacar et Zabulon. [^23] Fils de Rachel: Joseph et Benjamin. [^24] Fils de Bilha, servante de Rachel: Dan et Nephthali. [^25] Fils de Zilpa, servante de Léa: Gad et Aser. Ce sont là les fils de Jacob, qui lui naquirent à Paddan-Aram. [^26] Jacob arriva auprès d’Isaac, son père, à Mamré, à Kirjath-Arba, qui est Hébron, où avaient séjourné Abraham et Isaac. [^27] Les jours d’Isaac furent de cent quatre-vingts ans. [^28] #Ge 25:8.Il expira et mourut, et il fut recueilli auprès de son peuple, âgé et rassasié de jours, et Ésaü et Jacob, ses fils, l’enterrèrent. [^29] 

[[Genesis - 34|<--]] Genesis - 35 [[Genesis - 36|-->]]

---
# Notes
