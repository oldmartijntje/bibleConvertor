---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 28 - Luis Segond (1910)"
---
[[Genesis - 27|<--]] Genesis - 28 [[Genesis - 29|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Genesis]]

# Genesis - 28

Isaac appela Jacob, le bénit, et lui donna cet ordre: Tu ne prendras pas une femme parmi les filles de Canaan. [^1] #Os 12:13.Lève-toi, va à Paddan-Aram, à la maison de Bethuel, père de ta mère, et prends-y une femme d’entre les filles de Laban, frère de ta mère. [^2] Que le Dieu tout-puissant te bénisse, te rende fécond et te multiplie, afin que tu deviennes une multitude de peuples! [^3] Qu’il te donne la bénédiction d’Abraham, à toi #Ge 12:7; 13:15; 15:18; 24:7; 26:3. De 34:4. Ac 7:5.et à ta postérité avec toi, afin que tu possèdes le pays où tu habites comme étranger, et qu’il a donné à Abraham! [^4] Et Isaac fit partir Jacob, qui s’en alla à Paddan-Aram, auprès de Laban, fils de Bethuel, l’Araméen, frère de Rebecca, mère de Jacob et d’Ésaü. [^5] Ésaü vit qu’Isaac avait béni Jacob, et qu’il l’avait envoyé à Paddan-Aram pour y prendre une femme, et qu’en le bénissant il lui avait donné cet ordre: Tu ne prendras pas une femme parmi les filles de Canaan. [^6] Il vit que Jacob avait obéi à son père et à sa mère, et qu’il était parti pour Paddan-Aram. [^7] Ésaü comprit ainsi que les filles de Canaan déplaisaient à Isaac, son père. [^8] Et Ésaü s’en alla vers Ismaël. Il prit pour femme, outre les femmes qu’il avait, Mahalath, fille d’Ismaël, fils d’Abraham, et sœur de Nebajoth. [^9] Jacob partit de Beer-Schéba, et s’en alla à Charan. [^10] Il arriva dans un lieu où il passa la nuit; car le soleil était couché. Il y prit une pierre, dont il fit son chevet, et il se coucha dans ce lieu-là. [^11] Il eut un songe. Et voici, une échelle était appuyée sur la terre, et son sommet touchait au ciel. Et voici, #Jn 1:52.les anges de Dieu montaient et descendaient par cette échelle. [^12] Et voici, l’Éternel se tenait au-dessus d’elle; et il dit: #Ge 35:1, 3; 48:3.Je suis l’Éternel, le Dieu d’Abraham, ton père, et le Dieu d’Isaac. La terre sur laquelle tu es couché, #De 12:20; 19:8.je la donnerai à toi et à ta postérité. [^13] Ta postérité sera comme la poussière de la terre; tu t’étendras à l’occident et à l’orient, au septentrion et au midi; et toutes les familles de la terre seront bénies #Ge 12:3; 18:18; 22:18; 26:4.en toi et en ta postérité. [^14] Voici, je suis avec toi, je te garderai partout où tu iras, et je te ramènerai dans ce pays; car je ne t’abandonnerai point, que je n’aie exécuté ce que je te dis. [^15] Jacob s’éveilla de son sommeil et il dit: Certainement, l’Éternel est en ce lieu, et moi, je ne le savais pas! [^16] Il eut peur, et dit: Que ce lieu est redoutable! C’est ici la maison de Dieu, c’est ici la porte des cieux! [^17] Et Jacob se leva de bon matin; il prit la pierre dont il avait fait son chevet, #Ge 31:13; 35:14.il la dressa pour monument, et il versa de l’huile sur son sommet. [^18] Il donna à ce lieu le nom de Béthel; mais la ville s’appelait auparavant Luz. [^19] Jacob fit un vœu, en disant: Si Dieu est avec moi et me garde pendant ce voyage que je fais, s’il me donne du pain à manger et des habits pour me vêtir, [^20] et si je retourne en paix à la maison de mon père, alors l’Éternel sera mon Dieu; [^21] cette pierre, que j’ai dressée pour monument, sera la maison de Dieu; et je te donnerai la dîme de tout ce que tu me donneras. [^22] 

[[Genesis - 27|<--]] Genesis - 28 [[Genesis - 29|-->]]

---
# Notes
