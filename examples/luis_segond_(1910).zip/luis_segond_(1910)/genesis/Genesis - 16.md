---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 16 - Luis Segond (1910)"
---
[[Genesis - 15|<--]] Genesis - 16 [[Genesis - 17|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Genesis]]

# Genesis - 16

Saraï, femme d’Abram, ne lui avait point donné d’enfants. Elle avait une servante égyptienne, nommée Agar. [^1] Et Saraï dit à Abram: Voici, l’Éternel m’a rendue stérile; viens, je te prie, vers ma servante; peut-être aurai-je par elle des enfants. Abram écouta la voix de Saraï. [^2] Alors Saraï, femme d’Abram, prit Agar, l’Égyptienne, sa servante, et la donna pour femme à Abram, son mari, après qu’Abram eut habité dix années dans le pays de Canaan. [^3] Il alla vers Agar, et elle devint enceinte. Quand elle se vit enceinte, elle regarda sa maîtresse avec mépris. [^4] Et Saraï dit à Abram: L’outrage qui m’est fait retombe sur toi. J’ai mis ma servante dans ton sein; et, quand elle a vu qu’elle était enceinte, elle m’a regardée avec mépris. Que l’Éternel soit juge entre moi et toi! [^5] Abram répondit à Saraï: Voici, ta servante est en ton pouvoir, agis à son égard comme tu le trouveras bon. Alors Saraï la maltraita; et Agar s’enfuit loin d’elle. [^6] L’ange de l’Éternel la trouva près d’une source d’eau dans le désert, près de la source qui est sur le chemin de Schur. [^7] Il dit: Agar, servante de Saraï, d’où viens-tu, et où vas-tu? Elle répondit: Je fuis loin de Saraï, ma maîtresse. [^8] L’ange de l’Éternel lui dit: Retourne vers ta maîtresse, et humilie-toi sous sa main. [^9] L’ange de l’Éternel lui dit: Je multiplierai ta postérité, et elle sera si nombreuse qu’on ne pourra la compter. [^10] L’ange de l’Éternel lui dit: Voici, tu es enceinte, et tu enfanteras un fils, à qui tu donneras le nom d’Ismaël; car l’Éternel t’a entendue dans ton affliction. [^11] Il sera comme un âne sauvage; sa main sera contre tous, et la main de tous sera contre lui; et #Ge 25:18.il habitera en face de tous ses frères. [^12] Elle appela Atta-El-roï le nom de l’Éternel qui lui avait parlé; car elle dit: Ai-je rien vu ici, après qu’il m’a vue? [^13] C’est pourquoi l’on a appelé ce #Ge 24:62; 25:11.puits le puits de Lachaï-roï; il est entre Kadès et Bared. [^14] #Ga 4:22.Agar enfanta un fils à Abram; et Abram donna le nom d’Ismaël au fils qu’Agar lui enfanta. [^15] Abram était âgé de quatre-vingt-six ans lorsqu’Agar enfanta Ismaël à Abram. [^16] 

[[Genesis - 15|<--]] Genesis - 16 [[Genesis - 17|-->]]

---
# Notes
