---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 11 - Luis Segond (1910)"
---
[[Genesis - 10|<--]] Genesis - 11 [[Genesis - 12|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Genesis]]

# Genesis - 11

Toute la terre avait une seule langue et les mêmes mots. [^1] Comme ils étaient partis de l’orient, ils trouvèrent une plaine au pays de #Ge 10:10.Schinear, et ils y habitèrent. [^2] Ils se dirent l’un à l’autre: Allons! Faisons des briques, et cuisons-les au feu. Et la brique leur servit de pierre, et le bitume leur servit de ciment. [^3] Ils dirent encore: Allons! Bâtissons-nous une ville et une tour dont le sommet touche au ciel, et faisons-nous un nom, afin que nous ne soyons pas dispersés sur la face de toute la terre. [^4] L’Éternel descendit pour voir la ville et la tour que bâtissaient les fils des hommes. [^5] Et l’Éternel dit: Voici, ils forment un seul peuple et ont tous une même langue, et c’est là ce qu’ils ont entrepris; maintenant rien ne les empêcherait de faire tout ce qu’ils auraient projeté. [^6] Allons! Descendons, et là confondons leur langage, afin qu’ils n’entendent plus la langue, les uns des autres. [^7] Et #De 32:8. Ac 17:26.l’Éternel les dispersa loin de là sur la face de toute la terre; et ils cessèrent de bâtir la ville. [^8] C’est pourquoi on l’appela du nom de Babel, car c’est là que l’Éternel confondit le langage de toute la terre, et c’est de là que l’Éternel les dispersa sur la face de toute la terre. [^9] #    Ge 10:22, etc. 1 Ch 1:17, etc.  Voici la postérité de Sem. Sem, âgé de cent ans, engendra Arpacschad, deux ans après le déluge. [^10] Sem vécut, après la naissance d’Arpacschad, cinq cents ans; et il engendra des fils et des filles. [^11] Arpacschad, âgé de trente-cinq ans, engendra Schélach. [^12] Arpacschad vécut, après la naissance de Schélach, quatre cent trois ans; et il engendra des fils et des filles. [^13] Schélach, âgé de trente ans, engendra Héber. [^14] Schélach vécut, après la naissance d’Héber, quatre cent trois ans; et il engendra des fils et des filles. [^15] Héber, âgé de trente-quatre ans, engendra Péleg. [^16] Héber vécut, après la naissance de Péleg, quatre cent trente ans; et il engendra des fils et des filles. [^17] #1 Ch 1:25.Péleg, âgé de trente ans, engendra Rehu. [^18] Péleg vécut, après la naissance de Rehu, deux cent neuf ans; et il engendra des fils et des filles. [^19] Rehu, âgé de trente-deux ans, engendra Serug. [^20] Rehu vécut, après la naissance de Serug, deux cent sept ans; et il engendra des fils et des filles. [^21] Serug, âgé de trente ans, engendra Nachor. [^22] Serug vécut, après la naissance de Nachor, deux cents ans; et il engendra des fils et des filles. [^23] Nachor, âgé de vingt-neuf ans, engendra Térach. [^24] Nachor vécut, après la naissance de Térach, cent dix-neuf ans; et il engendra des fils et des filles. [^25] Térach, âgé de soixante-dix ans, engendra Abram, Nachor et Haran. [^26] #Jos 24:2. 1 Ch 1:26.Voici la postérité de Térach. Térach engendra Abram, Nachor et Haran. Haran engendra Lot. [^27] Et Haran mourut en présence de Térach, son père, au pays de sa naissance, à Ur en Chaldée. [^28] Abram et Nachor prirent des femmes: le nom de la femme d’Abram était Saraï, et le nom de la femme de Nachor était #Ge 22:20.Milca, fille d’Haran, père de Milca et père de Jisca. [^29] #Ge 16:1, 2; 18:11, 12.Saraï était stérile: elle n’avait point d’enfants. [^30] #Jos 24:2. Né 9:7. Ac 7:4.Térach prit Abram, son fils, et Lot, fils d’Haran, fils de son fils, et Saraï, sa belle-fille, femme d’Abram, son fils. Ils sortirent ensemble d’Ur en Chaldée, pour aller au pays de Canaan. Ils vinrent jusqu’à Charan, et ils y habitèrent. [^31] Les jours de Térach furent de deux cent cinq ans; et Térach mourut à Charan. [^32] 

[[Genesis - 10|<--]] Genesis - 11 [[Genesis - 12|-->]]

---
# Notes
