---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 39 - Luis Segond (1910)"
---
[[Genesis - 38|<--]] Genesis - 39 [[Genesis - 40|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Genesis]]

# Genesis - 39

#    
        Ge 37:28. Ps 105:17.  On fit descendre Joseph en Égypte; et Potiphar, officier de Pharaon, chef des gardes, Égyptien, l’acheta des Ismaélites qui l’y avaient fait descendre. [^1] L’Éternel #v. 21. Ac 7:9.fut avec lui, et la prospérité l’accompagna; il habitait dans la maison de son maître, l’Égyptien. [^2] Son maître vit que l’Éternel était avec lui, et que l’Éternel faisait prospérer entre ses mains tout ce qu’il entreprenait. [^3] Joseph trouva grâce aux yeux de son maître, qui l’employa à son service, l’établit sur sa maison, et lui confia tout ce qu’il possédait. [^4] Dès que Potiphar l’eut établi sur sa maison et sur tout ce qu’il possédait, l’Éternel bénit la maison de l’Égyptien, à cause de Joseph; et la bénédiction de l’Éternel fut sur tout ce qui lui appartenait, soit à la maison, soit aux champs. [^5] Il abandonna aux mains de Joseph tout ce qui lui appartenait, et il n’avait avec lui d’autre soin que celui de prendre sa nourriture. Or, Joseph était beau de taille et beau de figure. [^6] Après ces choses, il arriva #Pr 7:13.que la femme de son maître porta les yeux sur Joseph, et dit: Couche avec moi! [^7] Il refusa, et dit à la femme de son maître: Voici, mon maître ne prend avec moi connaissance de rien dans la maison, et il a remis entre mes mains tout ce qui lui appartient. [^8] Il n’est pas plus grand que moi dans cette maison, et il ne m’a rien interdit, excepté toi, parce que tu es sa femme. Comment ferais-je un aussi grand mal et pécherais-je contre Dieu? [^9] Quoiqu’elle parlât tous les jours à Joseph, il refusa de coucher auprès d’elle, d’être avec elle. [^10] Un jour qu’il était entré dans la maison pour faire son ouvrage, et qu’il n’y avait là aucun des gens de la maison, [^11] elle le saisit par son vêtement, en disant: Couche avec moi! Il lui laissa son vêtement dans la main, et s’enfuit au dehors. [^12] Lorsqu’elle vit qu’il lui avait laissé son vêtement dans la main, et qu’il s’était enfui dehors, [^13] elle appela les gens de sa maison, et leur dit: Voyez, il nous a amené un Hébreu pour se jouer de nous. Cet homme est venu vers moi pour coucher avec moi; mais j’ai crié à haute voix. [^14] Et quand il a entendu que j’élevais la voix et que je criais, il a laissé son vêtement à côté de moi et s’est enfui dehors. [^15] Et elle posa le vêtement de Joseph à côté d’elle, jusqu’à ce que son maître rentrât à la maison. [^16] Alors elle lui parla ainsi: L’esclave hébreu que tu nous as amené est venu vers moi pour se jouer de moi. [^17] Et comme j’ai élevé la voix et que j’ai crié, il a laissé son vêtement à côté de moi et s’est enfui dehors. [^18] Après avoir entendu les paroles de sa femme, qui lui disait: Voilà ce que m’a fait ton esclave! Le maître de Joseph fut enflammé de colère. [^19] Il prit Joseph, et #Ps 105:18.le mit dans la prison, dans le lieu où les prisonniers du roi étaient enfermés: il fut là, en prison. [^20] L’Éternel fut avec Joseph, et il étendit sur lui sa bonté. Il le mit en faveur aux yeux du chef de la prison. [^21] Et le chef de la prison plaça sous sa surveillance tous les prisonniers qui étaient dans la prison; et rien ne s’y faisait que par lui. [^22] Le chef de la prison ne prenait aucune connaissance de ce que Joseph avait en main, parce que l’Éternel était avec lui. Et l’Éternel donnait de la réussite à ce qu’il faisait. [^23] 

[[Genesis - 38|<--]] Genesis - 39 [[Genesis - 40|-->]]

---
# Notes
