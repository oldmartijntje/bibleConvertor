---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 9 - Luis Segond (1910)"
---
[[Genesis - 8|<--]] Genesis - 9 [[Genesis - 10|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Genesis]]

# Genesis - 9

Dieu bénit Noé et ses fils, et leur dit: #Ge 1:28; 8:17.Soyez féconds, multipliez, et remplissez la terre. [^1] Vous serez un sujet de crainte et d’effroi pour tout animal de la terre, pour tout oiseau du ciel, pour tout ce qui se meut sur la terre, et pour tous les poissons de la mer: ils sont livrés entre vos mains. [^2] Tout ce qui se meut et qui a vie vous servira de nourriture: je vous donne tout cela comme #Ge 1:29.l’herbe verte. [^3] #Lé 3:27; 7:26; 17:14; 19:26. De 12:23.Seulement, vous ne mangerez point de chair avec son âme, avec son sang. [^4] #Ex 21:12, 28.Sachez-le aussi, je redemanderai le sang de vos âmes, je le redemanderai à tout animal; et je redemanderai l’âme de l’homme à l’homme, à l’homme qui est son frère. [^5] #La 4:13. Mt 26:52. Ap 13:10.Si quelqu’un verse le sang de l’homme, par l’homme son sang sera versé; car Dieu a fait l’homme #Ge 1:27.à son image. [^6] #Ge 1:28; 8:17.Et vous, soyez féconds et multipliez, répandez-vous sur la terre et multipliez sur elle. [^7] Dieu parla encore à Noé et à ses fils avec lui, en disant: [^8] #És 54:9.Voici, j’établis mon alliance avec vous et avec votre postérité après vous; [^9] avec tous les êtres vivants qui sont avec vous, tant les oiseaux que le bétail et tous les animaux de la terre, soit avec tous ceux qui sont sortis de l’arche, soit avec tous les animaux de la terre. [^10] J’établis mon alliance avec vous: aucune chair ne sera plus exterminée par les eaux du déluge, et il n’y aura plus de déluge pour détruire la terre. [^11] Et Dieu dit: C’est ici le signe de l’alliance que j’établis entre moi et vous, et tous les êtres vivants qui sont avec vous, pour les générations à toujours: [^12] j’ai placé mon arc dans la nue, et il servira de signe d’alliance entre moi et la terre. [^13] Quand j’aurai rassemblé des nuages au-dessus de la terre, l’arc paraîtra dans la nue; [^14] et je me souviendrai de mon alliance entre moi et vous, et tous les êtres vivants, de toute chair, et les eaux ne deviendront plus un déluge pour détruire toute chair. [^15] L’arc sera dans la nue; et je le regarderai, pour me souvenir de l’alliance perpétuelle entre Dieu et tous les êtres vivants, de toute chair qui est sur la terre. [^16] Et Dieu dit à Noé: Tel est le signe de l’alliance que j’établis entre moi et toute chair qui est sur la terre. [^17] Les fils de Noé, qui sortirent de l’arche, étaient #Ge 6:10.Sem, Cham et Japhet. Cham fut le père de Canaan. [^18] Ce sont là les trois fils de Noé, et c’est leur postérité qui peupla toute la terre. [^19] Noé commença à cultiver la terre, et planta de la vigne. [^20] Il but du vin, s’enivra, et se découvrit au milieu de sa tente. [^21] Cham, père de Canaan, vit la nudité de son père, et il le rapporta dehors à ses deux frères. [^22] Alors Sem et Japhet prirent le manteau, le mirent sur leurs épaules, marchèrent à reculons, et couvrirent la nudité de leur père; comme leur visage était détourné, ils ne virent point la nudité de leur père. [^23] Lorsque Noé se réveilla de son vin, il apprit ce que lui avait fait son fils cadet. [^24] Et il dit: Maudit soit Canaan! Qu’il soit l’esclave des esclaves de ses frères! [^25] Il dit encore: Béni soit l’Éternel, Dieu de Sem, et que Canaan soit leur esclave! [^26] Que Dieu étende les possessions de Japhet, qu’il habite dans les tentes de Sem, et que Canaan soit leur esclave! [^27] Noé vécut, après le déluge, trois cent cinquante ans. [^28] Tous les jours de Noé furent de neuf cent cinquante ans; puis il mourut. [^29] 

[[Genesis - 8|<--]] Genesis - 9 [[Genesis - 10|-->]]

---
# Notes
