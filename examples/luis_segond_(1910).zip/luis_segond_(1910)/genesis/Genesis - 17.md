---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 17 - Luis Segond (1910)"
---
[[Genesis - 16|<--]] Genesis - 17 [[Genesis - 18|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Genesis]]

# Genesis - 17

Lorsque Abram fut âgé de quatre-vingt-dix-neuf ans, l’Éternel apparut à Abram, et lui dit: Je suis le Dieu tout-puissant. #Ge 5:22.Marche devant ma face, et sois intègre. [^1] #Ge 15:18. Ex 2:24; 6:4. Lé 26:42.J’établirai mon alliance entre moi et toi, #Ge 12:2; 13:16; 15:5.et je te multiplierai à l’infini. [^2] Abram tomba sur sa face; et Dieu lui parla, en disant: [^3] Voici mon alliance, que je fais avec toi. Tu deviendras #Ro 4:17.père d’une multitude de nations. [^4] On ne t’appellera plus Abram; mais ton nom sera Abraham, car je te rends père d’une multitude de nations. [^5] Je te rendrai fécond à l’infini, je ferai de toi des nations; et #Mt 1:6, etc.des rois sortiront de toi. [^6] J’établirai mon alliance entre moi et toi, et tes descendants après toi, selon leurs générations: ce sera #Ge 13:15.une alliance perpétuelle, en vertu de laquelle je serai ton Dieu et celui de ta postérité après toi. [^7] #Ge 15:18. De 1:8.Je te donnerai, et à tes descendants après toi, le pays que tu habites comme étranger, tout le pays de Canaan, en possession perpétuelle, et je serai leur Dieu. [^8] Dieu dit à Abraham: Toi, tu garderas mon alliance, toi et tes descendants après toi, selon leurs générations. [^9] C’est ici mon alliance, que vous garderez entre moi et vous, et ta postérité après toi: tout mâle parmi vous sera circoncis. [^10] Vous vous circoncirez; et #Ac 7:8. Ro 4:11.ce sera un signe d’alliance entre moi et vous. [^11] #Lé 12:3. Lu 2:21.A l’âge de huit jours, tout mâle parmi vous sera circoncis, selon vos générations, qu’il soit né dans la maison, ou qu’il soit acquis à prix d’argent de tout fils d’étranger, sans appartenir à ta race. [^12] On devra circoncire celui qui est né dans la maison et celui qui est acquis à prix d’argent; et mon alliance sera dans votre chair une alliance perpétuelle. [^13] Un mâle incirconcis, qui n’aura pas été circoncis dans sa chair, sera exterminé du milieu de son peuple: il aura violé mon alliance. [^14] Dieu dit à Abraham: Tu ne donneras plus à Saraï, ta femme, le nom de Saraï; mais son nom sera Sara. [^15] Je la bénirai, et je te donnerai d’elle un fils; je la bénirai, et elle deviendra des nations; des rois de peuples sortiront d’elle. [^16] Abraham tomba sur sa face; il rit, et dit en son cœur: Naîtrait-il un fils à un homme de cent ans? Et Sara, âgée de quatre-vingt-dix ans, enfanterait-elle? [^17] Et Abraham dit à Dieu: Oh! Qu’Ismaël vive devant ta face! [^18] Dieu dit: Certainement #Ge 18:10; 21:2.Sara, ta femme, t’enfantera un fils; et tu l’appelleras du nom d’Isaac. J’établirai mon alliance avec lui comme une alliance perpétuelle pour sa postérité après lui. [^19] A l’égard d’Ismaël, #Ge 16:10; 25:12, 16.je t’ai exaucé. Voici, je le bénirai, je le rendrai fécond, et je le multiplierai à l’infini; il engendrera douze princes, et je ferai de lui une grande nation. [^20] J’établirai mon alliance avec Isaac, que Sara t’enfantera #Ge 21:2.à cette époque-ci de l’année prochaine. [^21] Lorsqu’il eut achevé de lui parler, Dieu s’éleva au-dessus d’Abraham. [^22] Abraham prit Ismaël, son fils, tous ceux qui étaient nés dans sa maison et tous ceux qu’il avait acquis à prix d’argent, tous les mâles parmi les gens de la maison d’Abraham; et il les circoncit ce même jour, selon l’ordre que Dieu lui avait donné. [^23] Abraham était âgé de quatre-vingt-dix-neuf ans, lorsqu’il fut circoncis. [^24] Ismaël, son fils, était âgé de treize ans lorsqu’il fut circoncis. [^25] Ce même jour, Abraham fut circoncis, ainsi qu’Ismaël, son fils. [^26] Et tous les gens de sa maison, nés dans sa maison, ou acquis à prix d’argent des étrangers, furent circoncis avec lui. [^27] 

[[Genesis - 16|<--]] Genesis - 17 [[Genesis - 18|-->]]

---
# Notes
