---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 12 - Luis Segond (1910)"
---
[[Genesis - 11|<--]] Genesis - 12 [[Genesis - 13|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Genesis]]

# Genesis - 12

L’Éternel dit à Abram: #Ac 7:3. Hé 11:8.Vat’en de ton pays, de ta patrie, et de la maison de ton père, dans le pays que je te montrerai. [^1] Je ferai de toi une grande nation, et je te bénirai; je rendrai ton nom grand, et tu seras une source de bénédiction. [^2] Je bénirai ceux qui te béniront, et je maudirai ceux qui te maudiront; #Ge 18:18; 22:18; 26:4. Ac 3:25. Ga 3:8.et toutes les familles de la terre seront bénies en toi. [^3] Abram partit, comme l’Éternel le lui avait dit, et Lot partit avec lui. Abram était âgé de soixante-quinze ans, lorsqu’il sortit de Charan. [^4] #Ac 7:4.Abram prit Saraï, sa femme, et Lot, fils de son frère, avec tous les biens qu’ils possédaient et les serviteurs qu’ils avaient acquis à Charan. Ils partirent pour aller dans le pays de Canaan, et ils arrivèrent au pays de Canaan. [^5] Abram parcourut le pays jusqu’au lieu nommé Sichem, jusqu’aux chênes de Moré. #Ge 10:18, 19; 13:7.Les Cananéens étaient alors dans le pays. [^6] L’Éternel apparut à Abram, et dit: #Ge 13:15; 15:18; 17:8; 24:7; 26:4. De 34:4.Je donnerai ce pays à ta postérité. Et Abram bâtit là un autel à l’Éternel, qui lui était apparu. [^7] Il se transporta de là vers la montagne, à l’orient de Béthel, et il dressa ses tentes, ayant Béthel à l’occident et Aï à l’orient. Il bâtit encore là un autel à l’Éternel, et il invoqua le nom de l’Éternel. [^8] Abram continua ses marches, en s’avançant vers le midi. [^9] Il y eut une famine dans le pays; et Abram descendit en Égypte pour y séjourner, car la famine était grande dans le pays. [^10] Comme il était près d’entrer en Égypte, il dit à Saraï, sa femme: Voici, je sais que tu es une femme belle de figure. [^11] Quand les Égyptiens te verront, ils diront: C’est sa femme! Et ils me tueront, et te laisseront la vie. [^12] #Ge 20:12; 26:7.Dis, je te prie, que tu es ma sœur, afin que je sois bien traité à cause de toi, et que mon âme vive grâce à toi. [^13] Lorsque Abram fut arrivé en Égypte, les Égyptiens virent que la femme était fort belle. [^14] Les grands de Pharaon la virent aussi et la vantèrent à Pharaon; et la femme fut emmenée dans la maison de Pharaon. [^15] Il traita bien Abram à cause d’elle; et Abram reçut des brebis, des bœufs, des ânes, des serviteurs et des servantes, des ânesses, et des chameaux. [^16] Mais #Ps 105:14.l’Éternel frappa de grandes plaies Pharaon et sa maison, au sujet de Saraï, femme d’Abram. [^17] Alors Pharaon appela Abram, et dit: Qu’est-ce que tu m’as fait? Pourquoi ne m’as-tu pas déclaré que c’est ta femme? [^18] Pourquoi as-tu dit: C’est ma sœur? Aussi l’ai-je prise pour ma femme. Maintenant, voici ta femme, prends-la, et va-t’en! [^19] Et Pharaon donna ordre à ses gens de le renvoyer, lui et sa femme, avec tout ce qui lui appartenait. [^20] 

[[Genesis - 11|<--]] Genesis - 12 [[Genesis - 13|-->]]

---
# Notes
