---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 1 - Luis Segond (1910)"
---
2 Kings - 1 [[2 Kings - 2|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Kings]]

# 2 Kings - 1

#    
        2 R 3:5.  Moab se révolta contre Israël, après la mort d’Achab. [^1] Or Achazia tomba par le treillis de sa chambre haute à Samarie, et il en fut malade. Il fit partir des messagers, et leur dit: Allez, consultez Baal-Zebub, dieu d’Ékron, pour savoir si je guérirai de cette maladie. [^2] Mais l’ange de l’Éternel dit à Élie, le Thischbite: Lève-toi, monte à la rencontre des messagers du roi de Samarie, et dis-leur: Est-ce parce qu’il n’y a point de Dieu en Israël que vous allez consulter Baal-Zebub, dieu d’Ékron? [^3] C’est pourquoi ainsi parle l’Éternel: Tu ne descendras pas du lit sur lequel tu es monté, car tu mourras. Et Élie s’en alla. [^4] Les messagers retournèrent auprès d’Achazia. Et il leur dit: Pourquoi revenez-vous? [^5] Ils lui répondirent: Un homme est monté à notre rencontre, et nous a dit: Allez, retournez vers le roi qui vous a envoyés, et dites-lui: Ainsi parle l’Éternel: Est-ce parce qu’il n’y a point de Dieu en Israël que tu envoies consulter Baal-Zebub, dieu d’Ékron? C’est pourquoi tu ne descendras pas du lit sur lequel tu es monté, car tu mourras. [^6] Achazia leur dit: Quel air avait l’homme qui est monté à votre rencontre et qui vous a dit ces paroles? [^7] Ils lui répondirent: C’était un homme vêtu de poil et ayant une ceinture de cuir autour des reins. Et Achazia dit: C’est Élie, le Thischbite. [^8] Il envoya vers lui un chef de cinquante avec ses cinquante hommes. Ce chef monta auprès d’Élie, qui était assis sur le sommet de la montagne, et il lui dit: Homme de Dieu, le roi a dit: Descends! [^9] Élie répondit au chef de cinquante: Si je suis un homme de Dieu, que #Lu 9:54.le feu descende du ciel et te consume, toi et tes cinquante hommes! Et le feu descendit du ciel et le consuma, lui et ses cinquante hommes. [^10] Achazia envoya de nouveau vers lui un autre chef de cinquante avec ses cinquante hommes. Ce chef prit la parole et dit à Élie: Homme de Dieu, ainsi a dit le roi: Hâte-toi de descendre! [^11] Élie leur répondit: Si je suis un homme de Dieu, que le feu descende du ciel et te consume, toi et tes cinquante hommes! Et le feu de Dieu descendit du ciel et le consuma, lui et ses cinquante hommes. [^12] Achazia envoya de nouveau un troisième chef de cinquante avec ses cinquante hommes. Ce troisième chef de cinquante monta; et à son arrivée, il fléchit les genoux devant Élie, et lui dit en suppliant: Homme de Dieu, que ma vie, je te prie, et que la vie de ces cinquante hommes tes serviteurs soit précieuse à tes yeux! [^13] Voici, le feu est descendu du ciel et a consumé les deux premiers chefs de cinquante et leurs cinquante hommes: mais maintenant, que ma vie soit précieuse à tes yeux! [^14] L’ange de l’Éternel dit à Élie: Descends avec lui, n’aie aucune crainte de lui. Élie se leva et descendit avec lui vers le roi. [^15] Il lui dit: Ainsi parle l’Éternel: Parce que tu as envoyé des messagers pour consulter Baal-Zebub, dieu d’Ékron, comme s’il n’y avait en Israël point de Dieu dont on puisse consulter la parole, tu ne descendras pas du lit sur lequel tu es monté, car tu mourras. [^16] Achazia mourut, selon la parole de l’Éternel prononcée par Élie. Et Joram régna à sa place, la seconde année de Joram, fils de Josaphat, roi de Juda; car il n’avait point de fils. [^17] Le reste des actions d’Achazia, et ce qu’il a fait, cela n’est-il pas écrit dans le livre des Chroniques des rois d’Israël? [^18] 

2 Kings - 1 [[2 Kings - 2|-->]]

---
# Notes
