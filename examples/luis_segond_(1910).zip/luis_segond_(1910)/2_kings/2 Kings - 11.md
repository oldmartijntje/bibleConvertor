---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 11 - Luis Segond (1910)"
---
[[2 Kings - 10|<--]] 2 Kings - 11 [[2 Kings - 12|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Kings]]

# 2 Kings - 11

Athalie, #2 Ch 22:10.mère d’Achazia, voyant que son fils était mort, se leva et fit périr toute la race royale. [^1] Mais Joschéba, fille du roi Joram, sœur d’Achazia, prit Joas, fils d’Achazia, et l’enleva du milieu des fils du roi, quand on les fit mourir: elle le mit avec sa nourrice dans la chambre des lits. Il fut ainsi dérobé aux regards d’Athalie, et ne fut point mis à mort. [^2] Il resta six ans caché avec Joschéba dans la maison de l’Éternel. Et c’était Athalie qui régnait dans le pays. [^3] La #2 Ch 23:1.septième année, Jehojada envoya chercher les chefs de centaines des Kéréthiens et des coureurs, et il les fit venir auprès de lui dans la maison de l’Éternel. Il traita alliance avec eux et les fit jurer dans la maison de l’Éternel, et il leur montra le fils du roi. [^4] Puis il leur donna ses ordres, en disant: Voici ce que vous ferez. Parmi ceux de vous qui entrent en service le jour du sabbat, un tiers doit monter la garde à la maison du roi, [^5] un tiers à la porte de Sur, et un tiers à la porte derrière les coureurs: vous veillerez à la garde de la maison, de manière à en empêcher l’entrée. [^6] Vos deux autres divisions, tous ceux qui sortent de service le jour du sabbat feront la garde de la maison de l’Éternel auprès du roi: [^7] vous entourerez le roi de toutes parts, chacun les armes à la main, et l’on donnera la mort à quiconque s’avancera dans les rangs; vous serez près du roi quand il sortira et quand il entrera. [^8] #2 Ch 23:8.Les chefs de centaines exécutèrent tous les ordres qu’avait donnés le sacrificateur Jehojada. Ils prirent chacun leurs gens, ceux qui entraient en service et ceux qui sortaient de service le jour du sabbat, et ils se rendirent vers le sacrificateur Jehojada. [^9] Le sacrificateur remit aux chefs de centaines les lances et les boucliers qui provenaient du roi David, et qui se trouvaient dans la maison de l’Éternel. [^10] Les coureurs, chacun les armes à la main, entourèrent le roi, en se plaçant depuis le côté droit jusqu’au côté gauche de la maison, près de l’autel et près de la maison. [^11] Le sacrificateur fit avancer le fils du roi, et il mit sur lui le diadème et le témoignage. Ils l’établirent roi et l’oignirent, et frappant des mains, ils dirent: Vive le roi! [^12] Athalie entendit le bruit des coureurs et du peuple, et elle vint vers le peuple à la maison de l’Éternel. [^13] Elle regarda. Et voici, le roi se tenait sur l’estrade, selon l’usage; les chefs et les trompettes étaient près du roi: tout le peuple du pays était dans la joie, et l’on sonnait des trompettes. Athalie déchira ses vêtements, et cria: Conspiration! Conspiration! [^14] Alors le sacrificateur Jehojada donna cet ordre aux chefs de centaines, qui étaient à la tête de l’armée: Faites-la sortir en dehors des rangs, et tuez par l’épée quiconque la suivra. Car le sacrificateur avait dit: Qu’elle ne soit pas mise à mort dans la maison de l’Éternel! [^15] On lui fit place, et elle se rendit à la maison du roi par le chemin de l’entrée des chevaux: c’est là qu’elle fut tuée. [^16] #2 Ch 23:16.Jehojada traita entre l’Éternel, le roi et le peuple, l’alliance par laquelle ils devaient être le peuple de l’Éternel; il établit aussi l’alliance entre le roi et le peuple. [^17] Tout le peuple du pays entra dans la maison de Baal, et ils la démolirent; ils brisèrent entièrement ses autels et ses images, et ils tuèrent devant les autels Matthan, prêtre de Baal. Le sacrificateur Jehojada mit des surveillants dans la maison de l’Éternel. [^18] Il prit les chefs de centaines, les Kéréthiens et les coureurs, et tout le peuple du pays; et ils firent descendre le roi de la maison de l’Éternel, et ils entrèrent dans la maison du roi par le chemin de la porte des coureurs. Et Joas s’assit sur le trône des rois. [^19] Tout le peuple du pays se réjouissait, et la ville était tranquille. On avait fait mourir Athalie par l’épée dans la maison du roi. [^20] Joas avait sept ans lorsqu’il devint roi. [^21] 

[[2 Kings - 10|<--]] 2 Kings - 11 [[2 Kings - 12|-->]]

---
# Notes
