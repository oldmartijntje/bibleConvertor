---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 22 - Luis Segond (1910)"
---
[[2 Kings - 21|<--]] 2 Kings - 22 [[2 Kings - 23|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Kings]]

# 2 Kings - 22

Josias avait #2 Ch 34:1.huit ans lorsqu’il devint roi, et il régna trente et un ans à Jérusalem. Sa mère s’appelait Jedida, fille d’Adaja, de Botskath. [^1] Il fit ce qui est droit aux yeux de l’Éternel, et il marcha dans toute la voie de David, son père; il ne s’en détourna ni à droite ni à gauche. [^2] La dix-huitième année du roi Josias, le roi envoya dans la maison de l’Éternel Schaphan, le secrétaire, fils d’Atsalia, fils de Meschullam. [^3] Il lui dit: Monte vers Hilkija, le souverain sacrificateur, et qu’il amasse l’argent qui a été apporté dans la maison de l’Éternel et que ceux qui ont la garde du seuil ont recueilli du peuple. [^4] On remettra cet argent entre les mains de ceux qui sont chargés de faire exécuter l’ouvrage dans la maison de l’Éternel. Et ils l’emploieront pour ceux qui travaillent aux réparations de la maison de l’Éternel, [^5] pour les charpentiers, les manœuvres et les maçons, pour les achats de bois et de pierres de taille nécessaires aux réparations de la maison. [^6] Mais on ne leur demandera pas de compte pour l’argent remis entre leurs mains, car ils agissent avec probité. [^7] Alors Hilkija, le souverain sacrificateur, dit à Schaphan, le secrétaire: J’ai trouvé le livre de la loi dans la maison de l’Éternel. Et Hilkija donna le livre à Schaphan, et Schaphan le lut. [^8] Puis Schaphan, le secrétaire, alla rendre compte au roi, et dit: Tes serviteurs ont amassé l’argent qui se trouvait dans la maison, et l’ont remis entre les mains de ceux qui sont chargés de faire exécuter l’ouvrage dans la maison de l’Éternel. [^9] Schaphan, le secrétaire, dit encore au roi: Le sacrificateur Hilkija m’a donné un livre. Et Schaphan le lut devant le roi. [^10] Lorsque le roi entendit les paroles du livre de la loi, il déchira ses vêtements. [^11] Et le roi donna cet ordre au sacrificateur Hilkija, à Achikam, fils de Schaphan, à Acbor, fils de Michée, à Schaphan, le secrétaire, et à Asaja, serviteur du roi: [^12] Allez, consultez l’Éternel pour moi, pour le peuple, et pour tout Juda, au sujet des paroles de ce livre qu’on a trouvé; car grande est la colère de l’Éternel, qui s’est enflammée contre nous, parce que nos pères n’ont point obéi aux paroles de ce livre et n’ont point mis en pratique tout ce qui nous y est prescrit. [^13] Le sacrificateur Hilkija, Achikam, Acbor, Schaphan et Asaja, allèrent auprès de la prophétesse Hulda, femme de Schallum, fils de Thikva, fils de Harhas, gardien des vêtements. Elle habitait à Jérusalem, dans l’autre quartier de la ville. [^14] Après qu’ils lui eurent parlé, elle leur dit: Ainsi parle l’Éternel, le Dieu d’Israël: Dites à l’homme qui vous a envoyés vers moi: [^15] Ainsi parle l’Éternel: Voici, je vais faire venir des malheurs sur ce lieu et sur ses habitants, selon toutes les paroles du livre qu’a lu le roi de Juda. [^16] Parce qu’ils m’ont abandonné et qu’ils ont offert des parfums à d’autres dieux, afin de m’irriter par tous les ouvrages de leurs mains, ma colère s’est enflammée contre ce lieu, et elle ne s’éteindra point. [^17] Mais vous direz au roi de Juda, qui vous a envoyés pour consulter l’Éternel: Ainsi parle l’Éternel, le Dieu d’Israël, au sujet des paroles que tu as entendues: [^18] Parce que ton cœur a été touché, parce que tu t’es humilié devant l’Éternel en entendant ce que j’ai prononcé contre ce lieu et contre ses habitants, qui seront un objet d’épouvante et de malédiction, et parce que tu as déchiré tes vêtements et que tu as pleuré devant moi, moi aussi, j’ai entendu, dit l’Éternel. [^19] C’est pourquoi, voici, je te recueillerai auprès de tes pères, tu seras recueilli en paix dans ton sépulcre, et tes yeux ne verront pas tous les malheurs que je ferai venir sur ce lieu. Ils rapportèrent au roi cette réponse. [^20] 

[[2 Kings - 21|<--]] 2 Kings - 22 [[2 Kings - 23|-->]]

---
# Notes
