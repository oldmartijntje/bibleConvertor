---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 16 - Luis Segond (1910)"
---
[[2 Kings - 15|<--]] 2 Kings - 16 [[2 Kings - 17|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Kings]]

# 2 Kings - 16

La #2 Ch 28:1.dix-septième année de Pékach, fils de Remalia, Achaz, fils de Jotham, roi de Juda, régna. [^1] Achaz avait vingt ans lorsqu’il devint roi, et il régna seize ans à Jérusalem. Il ne fit point ce qui est droit aux yeux de l’Éternel, son Dieu, comme avait fait David, son père. [^2] Il marcha dans la voie des rois d’Israël; #Lé 18:21; 20:2, 3. 2 R 17:31.et même il fit passer son fils par le feu, suivant les abominations des nations que l’Éternel avait chassées devant les enfants d’Israël. [^3] Il offrait des sacrifices et des parfums sur les hauts lieux, sur les collines et sous tout arbre vert. [^4] #És 7:1.Alors Retsin, roi de Syrie, et Pékach, fils de Remalia, roi d’Israël, montèrent contre Jérusalem pour l’attaquer. Ils assiégèrent Achaz; mais ils ne purent pas le vaincre. [^5] Dans ce même temps, Retsin, roi de Syrie, fit rentrer Élath au pouvoir des Syriens; il expulsa d’Élath les Juifs, et les Syriens vinrent à Élath, où ils ont habité jusqu’à ce jour. [^6] Achaz envoya des messagers à Tiglath-Piléser, roi d’Assyrie, pour lui dire: Je suis ton serviteur et ton fils; monte, et délivre-moi de la main du roi de Syrie et de la main du roi d’Israël, qui s’élèvent contre moi. [^7] Et #2 Ch 28:21.Achaz prit l’argent et l’or qui se trouvaient dans la maison de l’Éternel et dans les trésors de la maison du roi, et il l’envoya en présent au roi d’Assyrie. [^8] Le roi d’Assyrie l’écouta; il monta contre Damas, la prit, emmena les habitants en captivité à Kir, et fit mourir Retsin. [^9] Le roi Achaz se rendit à Damas au-devant de Tiglath-Piléser, roi d’Assyrie. Et ayant vu l’autel qui était à Damas, le roi Achaz envoya au sacrificateur Urie le modèle et la forme exacte de cet autel. [^10] Le sacrificateur Urie construisit un autel entièrement d’après le modèle envoyé de Damas par le roi Achaz, et le sacrificateur Urie le fit avant que le roi Achaz fût de retour de Damas. [^11] A son arrivée de Damas, le roi vit l’autel, s’en approcha et y monta: [^12] il fit brûler son holocauste et son offrande, versa ses libations, et répandit sur l’autel le sang de ses sacrifices d’actions de grâces. [^13] Il éloigna de la face de la maison l’autel d’airain qui était devant l’Éternel, afin qu’il ne fût pas entre le nouvel autel et la maison de l’Éternel; et il le plaça à côté du nouvel autel, vers le nord. [^14] Et le roi Achaz donna cet ordre au sacrificateur Urie: Fais brûler sur le grand autel l’holocauste du matin et l’offrande du soir, l’holocauste du roi et son offrande, les holocaustes de tout le peuple du pays et leurs offrandes, verses-y leurs libations, et répands-y tout le sang des holocaustes et tout le sang des sacrifices; pour ce qui concerne l’autel d’airain, je m’en occuperai. [^15] Le sacrificateur Urie se conforma à tout ce que le roi Achaz avait ordonné. [^16] Et le roi Achaz brisa #1 R 7:23, etc.les panneaux des bases, et en ôta les bassins qui étaient dessus. Il descendit la mer de dessus les bœufs d’airain qui étaient sous elle, et il la posa sur un pavé de pierres. [^17] Il changea dans la maison de l’Éternel, à cause du roi d’Assyrie, le portique du sabbat qu’on y avait bâti et l’entrée extérieure du roi. [^18] Le reste des actions d’Achaz, et tout ce qu’il a fait, cela n’est-il pas écrit dans le livre des Chroniques des rois de Juda? [^19] Achaz se coucha avec ses pères, et il fut enterré avec ses pères dans la ville de David. Et Ézéchias, son fils, régna à sa place. [^20] 

[[2 Kings - 15|<--]] 2 Kings - 16 [[2 Kings - 17|-->]]

---
# Notes
