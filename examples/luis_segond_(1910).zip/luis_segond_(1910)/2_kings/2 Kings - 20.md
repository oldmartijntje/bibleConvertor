---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 20 - Luis Segond (1910)"
---
[[2 Kings - 19|<--]] 2 Kings - 20 [[2 Kings - 21|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Kings]]

# 2 Kings - 20

En ce temps-là, #2 Ch 32:24. És 38:1.Ézéchias fut malade à la mort. Le prophète Ésaïe, fils d’Amots, vint auprès de lui, et lui dit: Ainsi parle l’Éternel: Donne tes ordres à ta maison, car tu vas mourir, et tu ne vivras plus. [^1] Ézéchias tourna son visage contre le mur, et fit cette prière à l’Éternel: [^2] O Éternel! Souviens-toi que j’ai marché devant ta face avec fidélité et intégrité de cœur, et que j’ai fait ce qui est bien à tes yeux! Et Ézéchias répandit d’abondantes larmes. [^3] Ésaïe, qui était sorti, n’était pas encore dans la cour du milieu, lorsque la parole de l’Éternel lui fut adressée en ces termes: [^4] Retourne, et dis à Ézéchias, chef de mon peuple: Ainsi parle l’Éternel, le Dieu de David, ton père: J’ai entendu ta prière, j’ai vu tes larmes. Voici, je te guérirai; le troisième jour, tu monteras à la maison de l’Éternel. [^5] J’ajouterai à tes jours quinze années. Je te délivrerai, toi et cette ville, de la main du roi d’Assyrie; je protégerai cette ville, à cause de moi, et à cause de David, mon serviteur. [^6] Ésaïe dit: Prenez une masse de figues. On la prit, et on l’appliqua sur l’ulcère. Et Ézéchias guérit. [^7] Ézéchias avait dit à Ésaïe: A quel signe connaîtrai-je que l’Éternel me guérira, et que je monterai le troisième jour à la maison de l’Éternel? [^8] Et Ésaïe dit: Voici, de la part de l’Éternel, le signe auquel tu connaîtras que l’Éternel accomplira la parole qu’il a prononcée: L’ombre avancera-t-elle de dix degrés, ou reculera-t-elle de dix degrés? [^9] Ézéchias répondit: C’est peu de chose que l’ombre avance de dix degrés; mais plutôt qu’elle recule de dix degrés. [^10] Alors Ésaïe, le prophète, invoqua l’Éternel, qui fit reculer l’ombre de dix degrés sur les degrés d’Achaz, où elle était descendue. [^11] En ce même temps, Berodac-Baladan, fils de Baladan, roi de Babylone, envoya une lettre et un présent à Ézéchias, car il avait appris la maladie d’Ézéchias. [^12] Ézéchias donna audience aux envoyés, et il leur montra le lieu où étaient ses choses de prix, l’argent et l’or, les aromates et l’huile précieuse, son arsenal, et tout ce qui se trouvait dans ses trésors: il n’y eut rien qu’Ézéchias ne leur fît voir dans sa maison et dans tous ses domaines. [^13] Ésaïe, le prophète, vint ensuite auprès du roi Ézéchias, et lui dit: Qu’ont dit ces gens-là, et d’où sont-ils venus vers toi? Ézéchias répondit: Ils sont venus d’un pays éloigné, de Babylone. [^14] Ésaïe dit encore: Qu’ont-ils vu dans ta maison? Ézéchias répondit: Ils ont vu tout ce qui est dans ma maison: il n’y a rien dans mes trésors que je ne leur aie fait voir. [^15] Alors Ésaïe dit à Ézéchias: Écoute la parole de l’Éternel! [^16] Voici, les temps viendront où l’on emportera à Babylone tout ce qui est dans ta maison et ce que tes pères ont amassé jusqu’à ce jour; il n’en restera rien, dit l’Éternel. [^17] Et l’on prendra de tes fils, qui seront sortis de toi, que tu auras engendrés, pour en faire des eunuques dans le palais du roi de Babylone. [^18] Ézéchias répondit à Ésaïe: La parole de l’Éternel, que tu as prononcée, est bonne. Et il ajouta: N’y aura-t-il pas paix et sécurité pendant ma vie? [^19] Le reste des actions d’Ézéchias, tous ses exploits, et comment il fit l’étang et l’aqueduc, et amena les eaux dans la ville, cela n’est-il pas écrit dans le livre des Chroniques des rois de Juda? [^20] Ézéchias se coucha avec ses pères. Et Manassé, son fils, régna à sa place. [^21] 

[[2 Kings - 19|<--]] 2 Kings - 20 [[2 Kings - 21|-->]]

---
# Notes
