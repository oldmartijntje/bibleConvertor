---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 12 - Luis Segond (1910)"
---
[[2 Kings - 11|<--]] 2 Kings - 12 [[2 Kings - 13|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Kings]]

# 2 Kings - 12

La #2 Ch 24:1.septième année de Jéhu, Joas devint roi, et il régna quarante ans à Jérusalem. Sa mère s’appelait Tsibja, de Beer-Schéba. [^1] Joas fit ce qui est droit aux yeux de l’Éternel tout le temps qu’il suivit les directions du sacrificateur Jehojada. [^2] Seulement, les hauts lieux ne disparurent point; le peuple offrait encore des sacrifices et des parfums sur les hauts lieux. [^3] Joas dit aux sacrificateurs: #2 R 22:3, etc.Tout l’argent consacré qu’on apporte dans la maison de l’Éternel, l’argent ayant cours, savoir l’argent pour le rachat des personnes d’après l’estimation qui en est faite, et tout l’argent qu’il vient au cœur de quelqu’un d’apporter à la maison de l’Éternel, [^4] que les sacrificateurs le prennent chacun de la part des gens de sa connaissance, et qu’ils l’emploient à réparer la maison partout où il se trouvera quelque chose à réparer. [^5] Mais il arriva que, la vingt-troisième année du roi Joas, les sacrificateurs n’avaient point réparé ce qui était à réparer à la maison. [^6] Le roi Joas appela le sacrificateur Jehojada et les autres sacrificateurs, et leur dit: Pourquoi n’avez-vous pas réparé ce qui est à réparer à la maison? Maintenant, vous ne prendrez plus l’argent de vos connaissances, mais vous le livrerez pour les réparations de la maison. [^7] Les sacrificateurs convinrent de ne pas prendre l’argent du peuple, et de n’être pas chargés des réparations de la maison. [^8] Alors le sacrificateur Jehojada prit un coffre, perça un trou dans son couvercle, et le plaça à côté de l’autel, à droite, sur le passage par lequel on entrait à la maison de l’Éternel. Les sacrificateurs qui avaient la garde du seuil y mettaient tout l’argent qu’on apportait dans la maison de l’Éternel. [^9] Quand ils voyaient qu’il y avait beaucoup d’argent dans le coffre, le secrétaire du roi montait avec le souverain sacrificateur, et ils serraient et comptaient l’argent qui se trouvait dans la maison de l’Éternel. [^10] Ils remettaient l’argent pesé entre les mains de ceux qui étaient chargés de faire exécuter l’ouvrage dans la maison de l’Éternel. Et l’on employait cet argent pour les charpentiers et pour les ouvriers qui travaillaient à la maison de l’Éternel, [^11] pour les maçons et les tailleurs de pierres, pour les achats de bois et de pierres de taille nécessaires aux réparations de la maison de l’Éternel, et pour toutes les dépenses concernant les réparations de la maison. [^12] Mais, avec l’argent qu’on apportait dans la maison de l’Éternel, on ne fit pour la maison de l’Éternel ni bassins d’argent, ni couteaux, ni coupes, ni trompettes, ni aucun ustensile d’or ou d’argent: [^13] on le donnait à ceux qui faisaient l’ouvrage, afin qu’ils l’employassent à réparer la maison de l’Éternel. [^14] On ne demandait pas de compte aux hommes entre les mains desquels on remettait l’argent pour qu’ils le donnassent à ceux qui faisaient l’ouvrage, car ils agissaient avec probité. [^15] L’argent des sacrifices de culpabilité et des sacrifices d’expiation n’était point apporté dans la maison de l’Éternel: il était pour les sacrificateurs. [^16] #    
        2 R 13:25.  Alors Hazaël, roi de Syrie, monta et se battit contre Gath, dont il s’empara. #2 R 8:12. 2 R 24:23.Hazaël avait l’intention de monter contre Jérusalem. [^17] #2 R 18:15.Joas, roi de Juda, prit toutes les choses consacrées, ce qui avait été consacré par Josaphat, par Joram et par Achazia, ses pères, rois de Juda, ce qu’il avait consacré lui-même, et tout l’or qui se trouvait dans les trésors de la maison de l’Éternel et de la maison du roi, et il envoya le tout à Hazaël, roi de Syrie, qui ne monta pas contre Jérusalem. [^18] Le reste des actions de Joas, et tout ce qu’il a fait, cela n’est-il pas écrit dans le livre des Chroniques des rois de Juda? [^19] #2 R 14:5.Ses serviteurs se soulevèrent et formèrent une conspiration; ils frappèrent Joas dans la maison de Millo, qui est à la descente de Silla. [^20] Jozacar, fils de Schimeath, et Jozabad, fils de Schomer, ses serviteurs, le frappèrent, et il mourut. On l’enterra avec ses pères, dans la ville de David. Et Amatsia, son fils, régna à sa place. [^21] 

[[2 Kings - 11|<--]] 2 Kings - 12 [[2 Kings - 13|-->]]

---
# Notes
