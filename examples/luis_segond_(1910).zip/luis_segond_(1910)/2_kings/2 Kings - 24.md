---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 24 - Luis Segond (1910)"
---
[[2 Kings - 23|<--]] 2 Kings - 24 [[2 Kings - 25|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[2 Kings]]

# 2 Kings - 24

#    
        2 Ch 36:6.  De son temps, Nebucadnetsar, roi de Babylone, se mit en campagne. Jojakim lui fut assujetti pendant trois ans; mais il se révolta de nouveau contre lui. [^1] Alors l’Éternel envoya contre Jojakim des troupes de Chaldéens, des troupes de Syriens, des troupes de Moabites et des troupes d’Ammonites; il les envoya contre Juda pour le détruire, #2 R 20:17; 23:27.selon la parole que l’Éternel avait prononcée par ses serviteurs les prophètes. [^2] Cela arriva uniquement sur l’ordre de l’Éternel, qui voulait ôter Juda de devant sa face, à cause de tous les péchés commis par Manassé, [^3] et à cause du sang innocent qu’avait répandu Manassé et dont il avait rempli Jérusalem. Aussi l’Éternel ne voulut-il point pardonner. [^4] Le reste des actions de Jojakim, et tout ce qu’il a fait, cela n’est-il pas écrit dans le livre des Chroniques des rois de Juda? [^5] Jojakim se coucha avec ses pères. Et Jojakin, son fils, régna à sa place. [^6] Le roi d’Égypte ne sortit plus de son pays, car le roi de Babylone avait pris tout ce qui était au roi d’Égypte depuis le torrent d’Égypte jusqu’au fleuve de l’Euphrate. [^7] Jojakin avait dix-huit ans lorsqu’il devint roi, et il régna trois mois à Jérusalem. Sa mère s’appelait Nehuschtha, fille d’Elnathan, de Jérusalem. [^8] Il fit ce qui est mal aux yeux de l’Éternel, entièrement comme avait fait son père. [^9] #Da 1:1.En ce temps-là, les serviteurs de Nebucadnetsar, roi de Babylone, montèrent contre Jérusalem, et la ville fut assiégée. [^10] Nebucadnetsar, roi de Babylone, arriva devant la ville pendant que ses serviteurs l’assiégeaient. [^11] Alors Jojakin, roi de Juda, se rendit auprès du roi de Babylone, avec sa mère, ses serviteurs, ses chefs et ses eunuques. Et le roi de Babylone le fit prisonnier, la huitième année de son règne. [^12] #2 R 20:17. És 39:6.Il tira de là tous les trésors de la maison de l’Éternel et les trésors de la maison du roi; et il brisa tous les ustensiles d’or que Salomon, roi d’Israël, avait faits dans le temple de l’Éternel, comme l’Éternel l’avait prononcé. [^13] Il emmena en captivité tout Jérusalem, tous les chefs et tous les hommes vaillants, au nombre de dix mille exilés, avec tous les charpentiers et les serruriers: il ne resta que le peuple pauvre du pays. [^14] #2 Ch 36:10. Est 2:6.Il transporta Jojakin à Babylone; et il emmena captifs de Jérusalem à Babylone la mère du roi, les femmes du roi et ses eunuques, et les grands du pays, [^15] #Jé 52:28.tous les guerriers au nombre de sept mille, et les charpentiers et les serruriers au nombre de mille, tous hommes vaillants et propres à la guerre. Le roi de Babylone les emmena captifs à Babylone. [^16] Et #Jé 37:1; 52:1.le roi de Babylone établit roi, à la place de Jojakin, Matthania, son oncle, dont il changea le nom en celui de Sédécias. [^17] Sédécias avait vingt et un ans lorsqu’il devint roi, et il régna onze ans à Jérusalem. Sa mère s’appelait Hamuthal, fille de Jérémie, de Libna. [^18] Il fit ce qui est mal aux yeux de l’Éternel, entièrement comme avait fait Jojakim. [^19] Et cela arriva à cause de la colère de l’Éternel contre Jérusalem et contre Juda, qu’il voulait rejeter de devant sa face. Et Sédécias se révolta contre le roi de Babylone. [^20] 

[[2 Kings - 23|<--]] 2 Kings - 24 [[2 Kings - 25|-->]]

---
# Notes
