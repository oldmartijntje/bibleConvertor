---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 15 - Luis Segond (1910)"
---
[[Judges - 14|<--]] Judges - 15 [[Judges - 16|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Judges]]

# Judges - 15

Quelque temps après, à l’époque de la moisson des blés, Samson alla voir sa femme, et lui porta un chevreau. Il dit: Je veux entrer vers ma femme dans sa chambre. Mais le père de sa femme ne lui permit pas d’entrer. [^1] J’ai pensé dit-il, que tu avais pour elle de la haine, et je l’ai donnée à ton compagnon. Est-ce que sa jeune sœur n’est pas plus belle qu’elle? Prends-la donc à sa place. [^2] Samson leur dit: Cette fois je ne serai pas coupable envers les Philistins, si je leur fais du mal. [^3] Samson s’en alla. Il attrapa trois cents renards, et prit des flambeaux; puis il tourna queue contre queue, et mit un flambeau entre deux queues, au milieu. [^4] Il alluma les flambeaux, lâcha les renards dans les blés des Philistins, et embrasa les tas de gerbes, le blé sur pied, et jusqu’aux plantations d’oliviers. [^5] Les Philistins dirent: Qui a fait cela? On répondit: Samson, le gendre du Thimnien, parce que celui-ci lui a pris sa femme et l’a donnée à son compagnon. Et les Philistins montèrent, et ils la brûlèrent, elle et son père. [^6] Samson leur dit: Est-ce ainsi que vous agissez? Je ne cesserai qu’après m’être vengé de vous. [^7] Il les battit rudement, dos et ventre; puis il descendit, et se retira dans la caverne du rocher d’Étam. [^8] Alors les Philistins se mirent en marche, campèrent en Juda, et s’étendirent jusqu’à Léchi. [^9] Les hommes de Juda dirent: Pourquoi êtes-vous montés contre nous? Ils répondirent: Nous sommes montés pour lier Samson, afin de le traiter comme il nous a traités. [^10] Sur quoi trois mille hommes de Juda descendirent à la caverne du rocher d’Étam, et dirent à Samson: Ne sais-tu pas que les Philistins dominent sur nous? Que nous as-tu donc fait? Il leur répondit: Je les ai traités comme ils m’ont traité. [^11] Ils lui dirent: Nous sommes descendus pour te lier, afin de te livrer entre les mains des Philistins. Samson leur dit: Jurez-moi que vous ne me tuerez pas. [^12] Ils lui répondirent: Non; nous voulons seulement te lier et te livrer entre leurs mains, mais nous ne te ferons pas mourir. Et ils le lièrent avec deux cordes neuves, et le firent sortir du rocher. [^13] Lorsqu’il arriva à Léchi, les Philistins poussèrent des cris à sa rencontre. Alors l’esprit de l’Éternel le saisit. Les cordes qu’il avait aux bras devinrent comme du lin brûlé par le feu, et ses liens tombèrent de ses mains. [^14] Il trouva une mâchoire d’âne fraîche, il étendit sa main pour la prendre, et il en tua mille hommes. [^15] Et Samson dit:Avec une mâchoire d’âne, un monceau, deux monceaux;Avec une mâchoire d’âne, j’ai tué mille hommes. [^16] Quand il eut achevé de parler, il jeta de sa main la mâchoire. Et l’on appela ce lieu Ramath-Léchi. [^17] Pressé par la soif, il invoqua l’Éternel, et dit: C’est toi qui as permis par la main de ton serviteur cette grande délivrance; et maintenant mourrais-je de soif, et tomberais-je entre les mains des #1 S 17:26, 36. 2 S 1:20.incirconcis? [^18] Dieu fendit la cavité du rocher qui est à Léchi, et il en sortit de l’eau. Samson but, son esprit se ranima, et il reprit vie. C’est de là qu’on a appelé cette source En-Hakkoré; elle existe encore aujourd’hui à Léchi. [^19] Samson fut juge en Israël, au temps des Philistins, pendant vingt ans. [^20] 

[[Judges - 14|<--]] Judges - 15 [[Judges - 16|-->]]

---
# Notes
