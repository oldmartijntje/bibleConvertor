---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 4 - Luis Segond (1910)"
---
[[Judges - 3|<--]] Judges - 4 [[Judges - 5|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Judges]]

# Judges - 4

Les enfants d’Israël firent encore ce qui déplaît à l’Éternel, après qu’Éhud fut mort. [^1] Et l’Éternel les vendit entre les mains de Jabin, roi de Canaan, qui régnait à Hatsor. Le chef de son armée était #1 S 12:9.Sisera, et habitait à Haroscheth-Goïm. [^2] Les enfants d’Israël crièrent à l’Éternel, car Jabin avait neuf cents chars de fer, et il opprimait avec violence les enfants d’Israël depuis vingt ans. [^3] Dans ce temps-là, Débora, prophétesse, femme de Lappidoth, était juge en Israël. [^4] Elle siégeait sous le palmier de Débora, entre Rama et Béthel, dans la montagne d’Éphraïm; et les enfants d’Israël montaient vers elle pour être jugés. [^5] Elle envoya appeler #Hé 11:32.Barak, fils d’Abinoam, de Kédesch-Nephthali, et elle lui dit: N’est-ce pas l’ordre qu’a donné l’Éternel, le Dieu d’Israël? Va, dirige-toi sur le mont Thabor, et prends avec toi dix mille hommes des enfants de Nephthali et des enfants de Zabulon; [^6] j’attirerai vers toi, au torrent de #Ps 83:10.Kison, Sisera, chef de l’armée de Jabin, avec ses chars et ses troupes, et je le livrerai entre tes mains. [^7] Barak lui dit: Si tu viens avec moi, j’irai; mais si tu ne viens pas avec moi, je n’irai pas. [^8] Elle répondit: J’irai bien avec toi; mais tu n’auras point de gloire sur la voie où tu marches, car l’Éternel livrera Sisera entre les mains d’une femme. Et Débora se leva, et elle se rendit avec Barak à Kédesch. [^9] Barak convoqua Zabulon et Nephthali à Kédesch; dix mille hommes marchèrent à sa suite, et Débora partit avec lui. [^10] Héber, le Kénien, s’était séparé des Kéniens, des fils #No 10:29.de Hobab, beau-père de Moïse, et il avait dressé sa tente jusqu’au chêne de Tsaannaïm, près de Kédesch. [^11] On informa Sisera que Barak, fils d’Abinoam, s’était dirigé sur le mont Thabor. [^12] Et, depuis Haroscheth-Goïm, Sisera rassembla vers le torrent de Kison tous ses chars, neuf cents chars de fer, et tout le peuple qui était avec lui. [^13] Alors Débora dit à Barak: Lève-toi, car voici le jour où l’Éternel livre Sisera entre tes mains. L’Éternel ne marche-t-il pas devant toi? Et Barak descendit du mont Thabor, ayant dix mille hommes à sa suite. [^14] #Ps 83:10.L’Éternel mit en déroute devant Barak, par le tranchant de l’épée, Sisera, tous ses chars et tout le camp. Sisera descendit de son char, et s’enfuit à pied. [^15] Barak poursuivit les chars et l’armée jusqu’à Haroscheth-Goïm; et toute l’armée de Sisera tomba sous le tranchant de l’épée, sans qu’il en restât un seul homme. [^16] Sisera se réfugia à pied dans la tente de Jaël, femme de Héber, le Kénien; car il y avait paix entre Jabin, roi de Hatsor, et la maison de Héber, le Kénien. [^17] Jaël sortit au-devant de Sisera, et lui dit: Entre, mon seigneur, entre chez moi, ne crains point. Il entra chez elle dans la tente, et elle le cacha sous une couverture. [^18] #Jg 5:25.Il lui dit: Donne-moi, je te prie, un peu d’eau à boire, car j’ai soif. Elle ouvrit l’outre du lait, lui donna à boire, et le couvrit. [^19] Il lui dit encore: Tiens-toi à l’entrée de la tente, et si l’on vient t’interroger en disant: Y a-t-il ici quelqu’un? Tu répondras: Non. [^20] Jaël, femme de Héber, saisit un pieu de la tente, prit en main le marteau, s’approcha de lui doucement, et lui enfonça dans la tempe le pieu, qui pénétra en terre. Il était profondément endormi et accablé de fatigue; et il mourut. [^21] Comme Barak poursuivait Sisera, Jaël sortit à sa rencontre et lui dit: Viens, et je te montrerai l’homme que tu cherches. Il entra chez elle, et voici, Sisera était étendu mort, le pieu dans la tempe. [^22] En ce jour, Dieu humilia Jabin, roi de Canaan, devant les enfants d’Israël. [^23] Et la main des enfants d’Israël s’appesantit de plus en plus sur Jabin, roi de Canaan, jusqu’à ce qu’ils eussent exterminé Jabin, roi de Canaan. [^24] 

[[Judges - 3|<--]] Judges - 4 [[Judges - 5|-->]]

---
# Notes
