---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 17 - Luis Segond (1910)"
---
[[Judges - 16|<--]] Judges - 17 [[Judges - 18|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Judges]]

# Judges - 17

Il y avait un homme de la montagne d’Éphraïm, nommé Mica. [^1] Il dit à sa mère: Les mille et cent sicles d’argent qu’on t’a pris, et pour lesquels tu as fait des imprécations même à mes oreilles, voici, cet argent est entre mes mains, c’est moi qui l’avais pris. Et sa mère dit: Béni soit mon fils par l’Éternel! [^2] Il rendit à sa mère les mille et cent sicles d’argent; et sa mère dit: Je consacre de ma main cet argent à l’Éternel, afin d’en faire pour mon fils une image taillée et une image en fonte; et c’est ainsi que je te le rendrai. [^3] Il rendit à sa mère l’argent. Sa mère prit deux cents sicles d’argent. Et elle donna l’argent au fondeur, qui en fit une image taillée et une image en fonte. On les plaça dans la maison de Mica. [^4] Ce Mica avait une maison de Dieu; il fit un éphod et des théraphim, et il consacra l’un de ses fils, qui lui servit de prêtre. [^5] #Jg 18:1; 21:25.En ce temps-là, il n’y avait point de roi en Israël. Chacun faisait ce qui lui semblait bon. [^6] Il y avait un jeune homme de Bethléhem de Juda, de la famille de Juda; il était Lévite, et il séjournait là. [^7] Cet homme partit de la ville de Bethléhem de Juda, pour chercher une demeure qui lui convînt. En poursuivant son chemin, il arriva dans la montagne d’Éphraïm jusqu’à la maison de Mica. [^8] Mica lui dit: D’où viens-tu? Il lui répondit: Je suis Lévite, de Bethléhem de Juda, et je voyage pour chercher une demeure qui me convienne. [^9] Mica lui dit: Reste avec moi; tu me serviras de père et de prêtre, et je te donnerai dix sicles d’argent par année, les vêtements dont tu auras besoin, et ton entretien. Et le Lévite entra. [^10] Il se décida ainsi à rester avec cet homme, qui regarda le jeune homme comme l’un de ses fils. [^11] Mica consacra le Lévite, et ce jeune homme lui servit de prêtre et demeura dans sa maison. [^12] Et Mica dit: Maintenant, je sais que l’Éternel me fera du bien, puisque j’ai ce Lévite pour prêtre. [^13] 

[[Judges - 16|<--]] Judges - 17 [[Judges - 18|-->]]

---
# Notes
