---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 12 - Luis Segond (1910)"
---
[[Judges - 11|<--]] Judges - 12 [[Judges - 13|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Judges]]

# Judges - 12

Les hommes d’Éphraïm se rassemblèrent, partirent pour le nord, et dirent à Jephthé: #Jg 8:1.Pourquoi es-tu allé combattre les fils d’Ammon sans nous avoir appelés à marcher avec toi? Nous voulons incendier ta maison et te brûler avec elle. [^1] Jephthé leur répondit: Nous avons eu de grandes contestations, moi et mon peuple, avec les fils d’Ammon; et quand je vous ai appelés, vous ne m’avez pas délivré de leurs mains. [^2] Voyant que tu ne venais pas à mon secours, j’ai exposé ma vie, et j’ai marché contre les fils d’Ammon. L’Éternel les a livrés entre mes mains. Pourquoi donc aujourd’hui montez-vous contre moi pour me faire la guerre? [^3] Jephthé rassembla tous les hommes de Galaad, et livra bataille à Éphraïm. Les hommes de Galaad battirent Éphraïm, parce que les Éphraïmites disaient: Vous êtes des fugitifs d’Éphraïm! Galaad est au milieu d’Éphraïm, au milieu de Manassé! [^4] Galaad s’empara des gués du Jourdain du côté d’Éphraïm. Et quand l’un des fuyards d’Éphraïm disait: Laissez-moi passer! Les hommes de Galaad lui demandaient: Es-tu Éphraïmite? Il répondait: Non. [^5] Ils lui disaient alors: Hé bien, dis Schibboleth. Et il disait Sibboleth, car il ne pouvait pas bien prononcer. Sur quoi les hommes de Galaad le saisissaient, et l’égorgeaient près des gués du Jourdain. Il périt en ce temps-là quarante-deux mille hommes d’Éphraïm. [^6] Jephthé fut juge en Israël pendant six ans; puis Jephthé, le Galaadite, mourut, et fut enterré dans l’une des villes de Galaad. [^7] Après lui, Ibtsan de Bethléhem fut juge en Israël. [^8] Il eut trente fils, il maria trente filles au-dehors, et il fit venir pour ses fils trente filles du dehors. Il fut juge en Israël pendant sept ans; [^9] puis Ibtsan mourut, et fut enterré à Bethléhem. [^10] Après lui, Élon de Zabulon fut juge en Israël. Il fut juge en Israël pendant dix ans; [^11] puis Élon de Zabulon mourut, et fut enterré à Ajalon, dans le pays de Zabulon. [^12] Après lui, Abdon, fils d’Hillel, le Pirathonite, fut juge en Israël. [^13] Il eut quarante fils et trente petits-fils, qui montaient sur soixante dix #Jg 10:4.ânons. Il fut juge en Israël pendant huit ans; [^14] puis Abdon, fils d’Hillel, le Pirathonite, mourut, et fut enterré à Pirathon, dans le pays d’Éphraïm, sur la montagne des Amalécites. [^15] 

[[Judges - 11|<--]] Judges - 12 [[Judges - 13|-->]]

---
# Notes
