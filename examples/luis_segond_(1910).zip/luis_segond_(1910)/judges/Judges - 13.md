---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 13 - Luis Segond (1910)"
---
[[Judges - 12|<--]] Judges - 13 [[Judges - 14|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Judges]]

# Judges - 13

Les enfants d’Israël firent encore #Jg 2:11; 3:7; 4:1; 6:1; 10:6.ce qui déplaît à l’Éternel; et l’Éternel les livra entre les mains des Philistins, pendant quarante ans. [^1] Il y avait un homme de Tsorea, de la famille des Danites, et qui s’appelait Manoach. Sa femme était stérile, et n’enfantait pas. [^2] Un ange de l’Éternel apparut à la femme, et lui dit: Voici, tu es stérile, et tu n’as point d’enfants; tu deviendras enceinte, et tu enfanteras un fils. [^3] Maintenant prends bien garde, ne bois ni #No 6:2, 3.vin ni liqueur forte, et ne mange rien d’impur. [^4] Car tu vas devenir enceinte et tu enfanteras un fils. #No 6:5. 1 S 1:11.Le rasoir ne passera point sur sa tête, parce que cet enfant sera consacré à Dieu dès le ventre de sa mère; et ce sera lui qui commencera à délivrer Israël de la main des Philistins. [^5] La femme alla dire à son mari; Un homme de Dieu est venu vers moi, et il avait l’aspect d’un ange de Dieu, un aspect redoutable. Je ne lui ai pas demandé d’où il était, et il ne m’a pas fait connaître son nom. [^6] Mais il m’a dit: Tu vas devenir enceinte, et tu enfanteras un fils; et maintenant ne bois ni vin ni liqueur forte, et ne mange rien d’impur, parce que cet enfant sera consacré à Dieu dès le ventre de sa mère jusqu’au jour de sa mort. [^7] Manoach fit cette prière à l’Éternel: Ah! Seigneur, que l’homme de Dieu que tu as envoyé vienne encore vers nous, et qu’il nous enseigne ce que nous devons faire pour l’enfant qui naîtra! [^8] Dieu exauça la prière de Manoach, et l’ange de Dieu vint encore vers la femme. Elle était assise dans un champ, et Manoach, son mari, n’était pas avec elle. [^9] Elle courut promptement donner cette nouvelle à son mari, et lui dit: Voici, l’homme qui était venu l’autre jour vers moi m’est apparu. [^10] Manoach se leva, suivit sa femme, alla vers l’homme, et lui dit: Est-ce toi qui as parlé à cette femme? Il répondit: C’est moi. [^11] Manoach dit: Maintenant, si ta parole s’accomplit, que faudra-t-il observer à l’égard de l’enfant, et qu’y aura-t-il à faire? [^12] L’ange de l’Éternel répondit à Manoach: La femme s’abstiendra de tout ce que je lui ai dit. [^13] Elle ne goûtera d’aucun produit de la vigne, elle ne boira ni vin ni liqueur forte, et elle ne mangera rien d’impur; elle observera tout ce que je lui ai prescrit. [^14] Manoach dit à l’ange de l’Éternel: Permets-nous de te retenir, et de t’apprêter un chevreau. [^15] L’ange de l’Éternel répondit à Manoach: Quand tu me retiendrais, je ne mangerais pas de ton mets; mais si tu veux faire un holocauste, tu l’offriras à l’Éternel. Manoach ne savait point que ce fût un ange de l’Éternel. [^16] Et Manoach dit à l’ange de l’Éternel: Quel est ton nom, afin que nous te rendions gloire, quand ta parole s’accomplira? [^17] L’ange de l’Éternel lui répondit: Pourquoi demandes-tu mon nom? Il est merveilleux. [^18] Manoach prit le chevreau et l’offrande, et fit un sacrifice à l’Éternel sur le rocher. Il s’opéra un prodige, pendant que Manoach et sa femme regardaient. [^19] Comme la flamme montait de dessus l’autel vers le ciel, l’ange de l’Éternel monta dans la flamme de l’autel. A cette vue, Manoach et sa femme tombèrent la face contre terre. [^20] L’ange de l’Éternel n’apparut plus à Manoach et à sa femme. Alors Manoach comprit que c’était l’ange de l’Éternel, [^21] et il dit à sa femme: Nous allons #Ex 33:20. De 5:26. Jg 6:22, 23.mourir, car nous avons vu Dieu. [^22] Sa femme lui répondit: Si l’Éternel eût voulu nous faire mourir, il n’aurait pas pris de nos mains l’holocauste et l’offrande, il ne nous aurait pas fait voir tout cela, et il ne nous aurait pas maintenant fait entendre pareilles choses. [^23] La femme enfanta un fils, et lui donna le nom de #Hé 11:32.Samson. L’enfant grandit, et l’Éternel le bénit. [^24] Et l’Esprit de l’Éternel commença à l’agiter à Machané-Dan, entre Tsorea et Eschthaol. [^25] 

[[Judges - 12|<--]] Judges - 13 [[Judges - 14|-->]]

---
# Notes
