---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 10 - Luis Segond (1910)"
---
[[Judges - 9|<--]] Judges - 10 [[Judges - 11|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Judges]]

# Judges - 10

Après Abimélec, Thola, fils de Pua, fils de Dodo, homme d’Issacar, se leva pour délivrer Israël; il habitait à Schamir, dans la montagne d’Éphraïm. [^1] Il fut juge en Israël pendant vingt-trois ans; puis il mourut, et fut enterré à Schamir. [^2] Après lui, se leva Jaïr, le Galaadite, qui fut juge en Israël pendant vingt-deux ans. [^3] Il avait trente fils, qui montaient sur trente ânons, et qui possédaient trente villes, appelées encore aujourd’hui bourgs de Jaïr, et situées dans le pays de Galaad. [^4] Et Jaïr mourut, et fut enterré à Kamon. [^5] Les enfants d’Israël firent encore ce qui #Jg 2:11; 3:7; 4:1; 6:1.déplaît à l’Éternel; ils servirent les Baals et les Astartés, les dieux de Syrie, les dieux de Sidon, les dieux de Moab, les dieux des fils d’Ammon, et les dieux des Philistins, et ils abandonnèrent l’Éternel et ne le servirent plus. [^6] La colère de l’Éternel s’enflamma contre Israël, et il les vendit entre les mains des Philistins et entre les mains des fils d’Ammon. [^7] Ils opprimèrent et écrasèrent les enfants d’Israël cette année-là, et pendant dix-huit ans tous les enfants d’Israël qui étaient de l’autre côté du Jourdain dans le pays des Amoréens en Galaad. [^8] Les fils d’Ammon passèrent le Jourdain pour combattre aussi contre Juda, contre Benjamin et contre la maison d’Éphraïm. Et Israël fut dans une grande détresse. [^9] Les enfants d’Israël crièrent à l’Éternel, en disant: Nous avons péché contre toi, car nous avons abandonné notre Dieu et nous avons servi les Baals. [^10] L’Éternel dit aux enfants d’Israël: Ne vous ai-je pas délivrés des Égyptiens, des Amoréens, des fils d’Ammon, des Philistins? [^11] Et lorsque les Sidoniens, Amalek et Maon, vous opprimèrent, et que vous criâtes à moi, ne vous ai-je pas délivrés de leurs mains? [^12] Mais vous, vous m’avez #De 32:15. Jé 2:13.abandonné, et vous avez servi d’autres dieux. C’est pourquoi je ne vous délivrerai plus. [^13] Allez, invoquez les dieux que vous avez choisis; qu’ils vous délivrent au temps de votre détresse! [^14] Les enfants d’Israël dirent à l’Éternel: Nous avons péché; traite-nous comme il te plaira. Seulement, daigne nous délivrer aujourd’hui! [^15] Et ils ôtèrent les dieux étrangers du milieu d’eux, et servirent l’Éternel, qui fut touché des maux d’Israël. [^16] Les fils d’Ammon se rassemblèrent et campèrent en Galaad, et les enfants d’Israël se rassemblèrent et campèrent à Mitspa. [^17] Le peuple, les chefs de Galaad se dirent l’un à l’autre: Quel est l’homme qui commencera l’attaque contre les fils d’Ammon? #Jg 11:6, 9, 10, 11.Il sera chef de tous les habitants de Galaad. [^18] 

[[Judges - 9|<--]] Judges - 10 [[Judges - 11|-->]]

---
# Notes
