---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 2 - Luis Segond (1910)"
---
[[Judges - 1|<--]] Judges - 2 [[Judges - 3|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Judges]]

# Judges - 2

Un envoyé de l’Éternel monta de Guilgal à Bokim, et dit: Je vous ai fait monter hors d’Égypte, et je vous ai amenés dans le pays que j’ai juré à vos pères de vous donner. J’ai dit: #Ge 17:7. De 29:14, 15.Jamais je ne romprai mon alliance avec vous; [^1] et vous, vous ne traiterez point #De 7:2.alliance avec les habitants de ce pays, vous renverserez leurs #De 12:3.autels. Mais vous n’avez point obéi à ma voix. Pourquoi avez-vous fait cela? [^2] J’ai dit alors: #Jos 23:13.Je ne les chasserai point devant vous; mais ils seront à vos côtés, et leurs dieux vous seront #Ex 23:33; 34:12. De 7:16.un piège. [^3] Lorsque l’envoyé de l’Éternel eut dit ces paroles à tous les enfants d’Israël, le peuple éleva la voix et pleura. [^4] Ils donnèrent à ce lieu le nom de Bokim, et ils y offrirent des sacrifices à l’Éternel. [^5] #    
        Jos 24:28.  Josué renvoya le peuple, et les enfants d’Israël allèrent chacun dans son héritage pour prendre possession du pays. [^6] Le peuple servit l’Éternel pendant toute la vie de Josué, et pendant toute la vie des anciens qui survécurent à Josué et qui avaient vu toutes les grandes choses que l’Éternel avait faites en faveur d’Israël. [^7] Josué, fils de Nun, serviteur de l’Éternel, mourut âgé de cent dix ans. [^8] On l’ensevelit dans le territoire qu’il avait eu en partage, à Thimnath-Hérès, dans la montagne d’Éphraïm, au nord de la montagne de Gaasch. [^9] Toute cette génération fut recueillie auprès de ses pères, et il s’éleva après elle une autre génération, qui ne connaissait point l’Éternel, ni ce qu’il avait fait en faveur d’Israël. [^10] Les enfants d’Israël firent alors ce qui déplaît à l’Éternel, et ils servirent les Baals. [^11] Ils abandonnèrent l’Éternel, le Dieu de leurs pères, qui les avait fait sortir du pays d’Égypte, et ils allèrent après d’autres dieux d’entre les dieux des peuples qui les entouraient; ils se prosternèrent devant eux, et ils irritèrent l’Éternel. [^12] Ils abandonnèrent l’Éternel, et ils servirent Baal et les Astartés. [^13] La colère de l’Éternel s’enflamma contre Israël. Il les livra entre les mains de pillards qui les pillèrent, #Ps 44:13. És 50:1.il les vendit entre les mains de leurs ennemis d’alentour, et ils ne purent plus résister à leurs ennemis. [^14] Partout où ils allaient, la main de l’Éternel était contre eux pour leur faire du mal, #Lé 26. De 28.comme l’Éternel l’avait dit, comme l’Éternel le leur avait juré. Ils furent ainsi dans une grande détresse. [^15] L’Éternel suscita des juges, afin qu’ils les délivrassent de la main de ceux qui les pillaient. [^16] Mais ils n’écoutèrent pas même leurs juges, car ils se prostituèrent à d’autres dieux, se prosternèrent devant eux. Ils se détournèrent promptement de la voie qu’avaient suivie leurs pères, et ils n’obéirent point comme eux aux commandements de l’Éternel. [^17] Lorsque l’Éternel leur suscitait des juges, l’Éternel était avec le juge, et il les délivrait de la main de leurs ennemis pendant toute la vie du juge; car l’Éternel avait pitié de leurs gémissements contre ceux qui les opprimaient et les tourmentaient. [^18] #Jg 3:12.Mais, à la mort du juge, ils se corrompaient de nouveau plus que leurs pères, en allant après d’autres dieux pour les servir et se prosterner devant eux, et ils persévéraient dans la même conduite et le même endurcissement. [^19] Alors la colère de l’Éternel s’enflamma contre Israël, et il dit: Puisque cette nation a transgressé mon alliance que j’avais prescrite à ses pères, et puisqu’ils n’ont point obéi à ma voix, [^20] #Jos 23:13.je ne chasserai plus devant eux aucune des nations que Josué laissa quand il mourut. [^21] C’est ainsi que je mettrai par elles Israël à l’épreuve, pour savoir s’ils prendront garde ou non de suivre la voie de l’Éternel, comme leurs pères y ont pris garde. [^22] Et l’Éternel laissa en repos ces nations qu’il n’avait pas livrées entre les mains de Josué, et il ne se hâta point de les chasser. [^23] 

[[Judges - 1|<--]] Judges - 2 [[Judges - 3|-->]]

---
# Notes
