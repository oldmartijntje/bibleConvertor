---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 14 - Luis Segond (1910)"
---
[[Judges - 13|<--]] Judges - 14 [[Judges - 15|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Judges]]

# Judges - 14

Samson descendit à Thimna, et il y vit une femme parmi les filles des Philistins. [^1] Lorsqu’il fut remonté, il le déclara à son père et à sa mère, et dit: J’ai vu à Thimna une femme parmi les filles des Philistins; prenez-la maintenant pour ma femme. [^2] Son père et sa mère lui dirent: N’y a-t-il point de femme parmi les filles de tes frères et dans tout notre peuple, que tu ailles prendre une femme chez les Philistins, qui sont incirconcis? Et Samson dit à son père: Prends-la pour moi, car elle me plaît. [^3] Son père et sa mère ne savaient pas que cela venait de l’Éternel: car Samson cherchait une occasion de dispute de la part des Philistins. En ce temps-là, les Philistins dominaient sur Israël. [^4] Samson descendit avec son père et sa mère à Thimna. Lorsqu’ils arrivèrent aux vignes de Thimna, voici, un jeune lion rugissant vint à sa rencontre. [^5] L’esprit de l’Éternel saisit Samson; et, sans avoir rien à la main, Samson déchira le lion comme on déchire un chevreau. Il ne dit point à son père et à sa mère ce qu’il avait fait. [^6] Il descendit et parla à la femme, et elle lui plut. [^7] Quelque temps après, il se rendit de nouveau à Thimna pour la prendre, et se détourna pour voir le cadavre du lion. Et voici, il y avait un essaim d’abeilles et du miel dans le corps du lion. [^8] Il prit entre ses mains le miel, dont il mangea pendant la route; et lorsqu’il fut arrivé près de son père et de sa mère, il leur en donna, et ils en mangèrent. Mais il ne leur dit pas qu’il avait pris ce miel dans le corps du lion. [^9] Le père de Samson descendit chez la femme. Et là, Samson fit un festin, car c’était la coutume des jeunes gens. [^10] Dès qu’on le vit, on invita trente compagnons qui se tinrent avec lui. [^11] Samson leur dit: Je vais vous proposer une énigme. Si vous me l’expliquez pendant les sept jours du festin, et si vous la découvrez, je vous donnerai trente chemises et trente vêtements de rechange. [^12] Mais si vous ne pouvez pas me l’expliquer, ce sera vous qui me donnerez trente chemises et trente vêtements de rechange. Ils lui dirent: Propose ton énigme, et nous l’écouterons. [^13] Et il leur dit: De celui qui mange est sorti ce qui se mange, et du fort est sorti le doux. Pendant trois jours, ils ne purent expliquer l’énigme. [^14] Le septième jour, ils dirent à la femme de Samson: Persuade ton mari de nous expliquer l’énigme; sinon, nous te brûlerons, toi et la maison de ton père. C’est pour nous dépouiller que vous nous avez invités, n’est-ce pas? [^15] La femme de Samson pleurait auprès de lui, et disait: Tu n’as pour moi que de la haine, et tu ne m’aimes pas; tu as proposé une énigme aux enfants de mon peuple, et tu ne me l’as point expliquée! Et il lui répondait: Je ne l’ai expliquée ni à mon père ni à ma mère; est-ce à toi que je l’expliquerais? [^16] Elle pleura auprès de lui pendant les sept jours que dura leur festin; et le septième jour, il la lui expliqua, car elle le tourmentait. Et elle donna l’explication de l’énigme aux enfants de son peuple. [^17] Les gens de la ville dirent à Samson le septième jour, avant le coucher du soleil: Quoi de plus doux que le miel, et quoi de plus fort que le lion? Et il leur dit: Si vous n’aviez pas labouré avec ma génisse, vous n’auriez pas découvert mon énigme. [^18] L’esprit de l’Éternel le saisit, et il descendit à Askalon. Il y tua trente hommes, prit leurs dépouilles, et donna les vêtements de rechange à ceux qui avaient expliqué l’énigme. Il était enflammé de colère, et il monta à la maison de son père. [^19] Sa femme fut donnée à l’un de ses compagnons, avec lequel il était lié. [^20] 

[[Judges - 13|<--]] Judges - 14 [[Judges - 15|-->]]

---
# Notes
