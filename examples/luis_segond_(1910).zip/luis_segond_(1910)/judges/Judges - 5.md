---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 5 - Luis Segond (1910)"
---
[[Judges - 4|<--]] Judges - 5 [[Judges - 6|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Judges]]

# Judges - 5

En ce jour-là, Débora chanta ce cantique, avec Barak, fils d’Abinoam: [^1] Des chefs se sont mis à la tête du peuple en Israël,Et le peuple s’est montré prêt à combattre:Bénissez-en l’Éternel! [^2] Rois, écoutez! Princes, prêtez l’oreille!Je chanterai, oui, je chanterai à l’Éternel,Je chanterai à l’Éternel, le Dieu d’Israël. [^3] O Éternel! Quand tu sortis de Séir,Quand tu t’avanças des champs d’Édom,#    
        Ps 68:8, 9.  La terre trembla, et les cieux se fondirentEt les nuées se fondirent en eaux; [^4] #    
        Ps 68:15, 16, 17; 97:5.  Les montagnes s’ébranlèrent devant l’Éternel,Ce #Ex 19:18.Sinaï devant l’Éternel, le Dieu d’Israël. [^5] Au temps de Schamgar, fils d’Anath,Au temps de Jaël, les routes étaient abandonnées,Et ceux qui voyageaient prenaient des chemins détournés. [^6] Les chefs étaient sans force en Israël, sans force,Quand je me suis levée, moi, Débora,Quand je me suis levée comme une mère en Israël. [^7] Il avait choisi de nouveaux dieux:Alors la guerre était aux portes;On ne voyait ni bouclier ni lanceChez quarante milliers en Israël. [^8] Mon cœur est aux chefs d’Israël,A ceux du peuple qui se sont montrés prêts à combattre.Bénissez l’Éternel! [^9] Vous qui montez de blanches ânesses,Vous qui avez pour sièges des tapis,Et vous qui marchez sur la route, chantez! [^10] Que de leur voix les archers, du milieu des abreuvoirs,Célèbrent les bienfaits de l’Éternel,Les bienfaits de son conducteur en Israël!Alors le peuple de l’Éternel descendit aux portes. [^11] Réveille-toi, réveille-toi, Débora!Réveille-toi, réveille-toi, dis un cantique!Lève-toi, Barak, et emmène tes captifs, fils d’Abinoam! [^12] Alors un reste du peuple triompha des puissants,L’Éternel me donna la victoire sur les héros. [^13] D’Éphraïm arrivèrent les habitants d’Amalek.A ta suite marcha Benjamin parmi ta troupe.De Makir vinrent des chefs,Et de Zabulon des commandants. [^14] Les princes d’Issacar furent avec Débora,Et Issacar suivit Barak,Il fut envoyé sur ses pas dans la vallée.Près des ruisseaux de Ruben,Grandes furent les résolutions du cœur! [^15] Pourquoi es-tu resté au milieu des établesA écouter le bêlement des troupeaux?Aux ruisseaux de Ruben,Grandes furent les délibérations du cœur! [^16] Galaad au-delà du Jourdain n’a pas quitté sa demeure.Pourquoi Dan s’est-il tenu sur les navires?Aser s’est assis sur le rivage de la mer,Et s’est reposé dans ses ports. [^17] Zabulon est un peuple qui affronta la mort,Et Nephthali de même,Sur les hauteurs des champs. [^18] Les rois vinrent, ils combattirent,Alors combattirent les rois de Canaan,A Thaanac, aux eaux de Meguiddo;Ils ne remportèrent nul butin, nul argent. [^19] Des cieux on combattit,De leurs sentiers les étoiles combattirent contre Sisera. [^20] Le torrent de Kison les a entraînés,Le torrent des anciens temps, le torrent de Kison.Mon âme, foule aux pieds les héros! [^21] Alors les talons des chevaux retentirent,A la fuite, à la fuite précipitée de leurs guerriers. [^22] Maudissez Méroz, dit l’ange de l’Éternel,Maudissez, maudissez ses habitants,Car ils ne vinrent pas au secours de l’Éternel,Au secours de l’Éternel, parmi les hommes vaillants. [^23] Bénie soit entre les femmes Jaël,Femme de Héber, le Kénien!Bénie soit-elle entre les femmes qui habitent sous les tentes! [^24] Il demanda de l’eau, elle a donné du lait,Dans la coupe d’honneur elle a présenté de la crème. [^25] D’une main elle a saisi le pieu,Et de sa droite le marteau des travailleurs;Elle a frappé Sisera, lui a fendu la tête,Fracassé et transpercé la tempe. [^26] Aux pieds de Jaël il s’est affaissé, il est tombé, il s’est couché;A ses pieds il s’est affaissé, il est tombé;Là où il s’est affaissé, là il est tombé sans vie. [^27] Par la fenêtre, à travers le treillis,La mère de Sisera regarde, et s’écrie:Pourquoi son char tarde-t-il à venir?Pourquoi ses chars vont-ils si lentement? [^28] Les plus sages d’entre ses femmes lui répondent,Et elle se répond à elle-même: [^29] Ne trouvent-ils pas du butin? Ne le partagent-ils pas?Une jeune fille, deux jeunes filles par homme,Du butin en vêtements de couleur pour Sisera,Du butin en vêtements de couleur, brodés,Un vêtement de couleur, deux vêtements brodés,Pour le cou du vainqueur. [^30] Périssent ainsi tous tes ennemis, ô Éternel!Ceux qui l’aiment sont comme le soleil,Quand il paraît dans sa force.Le pays fut en repos pendant quarante ans. [^31] 

[[Judges - 4|<--]] Judges - 5 [[Judges - 6|-->]]

---
# Notes
