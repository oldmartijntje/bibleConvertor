---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/nehemiah"
  - "#bible/testament/old"
aliases:
  - "Nehemiah - 8 - Luis Segond (1910)"
---
[[Nehemiah - 7|<--]] Nehemiah - 8 [[Nehemiah - 9|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Nehemiah]]

# Nehemiah - 8

Alors tout le peuple s’assembla comme un seul homme sur la place qui est devant la porte des eaux. Ils dirent à Esdras, le scribe, d’apporter le livre de la loi de Moïse, prescrite par l’Éternel à Israël. [^1] Et le sacrificateur Esdras apporta la loi devant l’assemblée, composée d’hommes et de femmes et de tous ceux qui étaient capables de l’entendre. C’était le premier jour du septième mois. [^2] Esdras lut dans le livre depuis le matin jusqu’au milieu du jour, sur la place qui est devant la porte des eaux, en présence des hommes et des femmes et de ceux qui étaient capables de l’entendre. Tout le peuple fut attentif à la lecture du livre de la loi. [^3] Esdras, le scribe, était placé sur une estrade de bois, dressée à cette occasion. Auprès de lui, à sa droite, se tenaient Matthithia, Schéma, Anaja, Urie, Hilkija et Maaséja, et à sa gauche, Pedaja, Mischaël, Malkija, Haschum, Haschbaddana, Zacharie et Meschullam. [^4] Esdras ouvrit le livre à la vue de tout le peuple, car il était élevé au-dessus de tout le peuple; et lorsqu’il l’eut ouvert, tout le peuple se tint en place. [^5] Esdras bénit l’Éternel, le grand Dieu, et tout le peuple répondit, en levant les mains: Amen! Amen! Et ils s’inclinèrent et se prosternèrent devant l’Éternel, le visage contre terre. [^6] Josué, Bani, Schérébia, Jamin, Akkub, Schabbethaï, Hodija, Maaséja, Kelitha, Azaria, Jozabad, Hanan, Pelaja, et les Lévites, expliquaient la loi au peuple, et chacun restait à sa place. [^7] Ils lisaient distinctement dans le livre de la loi de Dieu, et ils en donnaient le sens pour faire comprendre ce qu’ils avaient lu. [^8] Néhémie, le gouverneur, Esdras, le sacrificateur et le scribe, et les Lévites qui enseignaient le peuple, dirent à tout le peuple: Ce jour est consacré à l’Éternel, votre Dieu; ne soyez pas dans la désolation et dans les larmes! Car tout le peuple pleurait en entendant les paroles de la loi. [^9] Ils leur dirent: Allez, mangez des viandes grasses et buvez des liqueurs douces, et envoyez des portions à ceux qui n’ont rien de préparé, car ce jour est consacré à notre Seigneur; ne vous affligez pas, car la joie de l’Éternel sera votre force. [^10] Les Lévites calmaient tout le peuple, en disant: Taisez-vous, car ce jour est saint; ne vous affligez pas! [^11] Et tout le peuple s’en alla pour manger et boire, pour envoyer des portions, et pour se livrer à de grandes réjouissances. Car ils avaient compris les paroles qu’on leur avait expliquées. [^12] Le second jour, les chefs de famille de tout le peuple, les sacrificateurs et les Lévites, s’assemblèrent auprès d’Esdras, le scribe, pour entendre l’explication des paroles de la loi. [^13] Et ils trouvèrent #Ex 23:16. Lé 23:34. No 29:12, etc. De 16:13, 14, 15.écrit dans la loi que l’Éternel avait prescrite par Moïse, que les enfants d’Israël devaient habiter sous des tentes pendant la fête du septième mois, [^14] et proclamer cette publication dans toutes leurs villes et à Jérusalem: Allez chercher à la montagne des rameaux d’olivier, des rameaux d’olivier sauvage, des rameaux de myrte, des rameaux de palmier, et des rameaux d’arbres touffus, pour faire des tentes, comme il est écrit. [^15] Alors le peuple alla chercher des rameaux, et ils se firent des tentes sur le toit de leurs maisons, dans leurs cours, dans les parvis de la maison de Dieu, sur la place de la porte des eaux et sur la place de la porte d’Éphraïm. [^16] Toute l’assemblée de ceux qui étaient revenus de la captivité fit des tentes, et ils habitèrent sous ces tentes. Depuis le temps de Josué, fils de Nun, jusqu’à ce jour, les enfants d’Israël n’avaient rien fait de pareil. Et il y eut de très grandes réjouissances. [^17] On lut dans le livre de la loi de Dieu chaque jour, depuis le premier jour jusqu’au dernier. On célébra la fête pendant sept jours, et il y eut une assemblée solennelle le huitième jour, comme cela est ordonné. [^18] 

[[Nehemiah - 7|<--]] Nehemiah - 8 [[Nehemiah - 9|-->]]

---
# Notes
