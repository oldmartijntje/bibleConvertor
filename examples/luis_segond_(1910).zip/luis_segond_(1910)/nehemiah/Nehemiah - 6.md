---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/nehemiah"
  - "#bible/testament/old"
aliases:
  - "Nehemiah - 6 - Luis Segond (1910)"
---
[[Nehemiah - 5|<--]] Nehemiah - 6 [[Nehemiah - 7|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Nehemiah]]

# Nehemiah - 6

Je n’avais pas encore posé les battants des portes, lorsque Sanballat, Tobija, Guéschem, l’Arabe, et nos autres ennemis apprirent que j’avais rebâti la muraille et qu’il n’y restait plus de brèche. [^1] Alors Sanballat et Guéschem m’envoyèrent dire: Viens, et ayons ensemble une entrevue dans les villages de la vallée d’Ono. Ils avaient médité de me faire du mal. [^2] Je leur envoyai des messagers avec cette réponse: J’ai un grand ouvrage à exécuter, et je ne puis descendre; le travail serait interrompu pendant que je le quitterais pour aller vers vous. [^3] Ils m’adressèrent quatre fois la même demande, et je leur fis la même réponse. [^4] Sanballat m’envoya ce message une cinquième fois par son serviteur, qui tenait à la main une lettre ouverte. [^5] Il y était écrit: Le bruit se répand parmi les nations et Gaschmu affirme que toi et les Juifs vous pensez à vous révolter, et que c’est dans ce but que tu rebâtis la muraille. Tu vas, dit-on, devenir leur roi, [^6] tu as même établi des prophètes pour te proclamer à Jérusalem roi de Juda. Et maintenant ces choses arriveront à la connaissance du roi. Viens donc, et consultons-nous ensemble. [^7] Je fis répondre à Sanballat: Ce que tu dis là n’est pas; c’est toi qui l’inventes! [^8] Tous ces gens voulaient nous effrayer, et ils se disaient: Ils perdront courage, et l’œuvre ne se fera pas. Maintenant, ô Dieu, fortifie-moi! [^9] Je me rendis chez Schemaeja, fils de Delaja, fils de Mehétabeel. Il s’était enfermé, et il dit: Allons ensemble dans la maison de Dieu, au milieu du temple, et fermons les portes du temple; car ils viennent pour te tuer, et c’est pendant la nuit qu’ils viendront pour te tuer. [^10] Je répondis: Un homme comme moi prendre la fuite! Et quel homme tel que moi pourrait entrer dans le temple et vivre? Je n’entrerai point. [^11] Et je reconnus que ce n’était pas Dieu qui l’envoyait. Mais il prophétisa ainsi sur moi parce que Sanballat et Tobija lui avaient donné de l’argent. [^12] En le gagnant ainsi, ils espéraient que j’aurais peur, et que je suivrais ses avis et commettrais un péché; et ils auraient profité de cette atteinte à ma réputation pour me couvrir d’opprobre. [^13] Souviens-toi, ô mon Dieu, de Tobija et de Sanballat, et de leurs œuvres! Souviens-toi aussi de Noadia, la prophétesse, et des autres prophètes qui cherchaient à m’effrayer! [^14] La muraille fut achevée le vingt-cinquième jour du mois d’Élul, en cinquante-deux jours. [^15] Lorsque tous nos ennemis l’apprirent, toutes les nations qui étaient autour de nous furent dans la crainte; elles éprouvèrent une grande humiliation, et reconnurent que l’œuvre s’était accomplie par la volonté de notre Dieu. [^16] Dans ce temps-là, il y avait aussi des grands de Juda qui adressaient fréquemment des lettres à Tobija et qui en recevaient de lui. [^17] Car plusieurs en Juda étaient liés à lui par serment, parce qu’il était gendre de Schecania, fils d’Arach, et que son fils Jochanan avait pris la fille de Meschullam, fils de Bérékia. [^18] Ils disaient même du bien de lui en ma présence, et ils lui rapportaient mes paroles. Tobija envoyait des lettres pour m’effrayer. [^19] 

[[Nehemiah - 5|<--]] Nehemiah - 6 [[Nehemiah - 7|-->]]

---
# Notes
