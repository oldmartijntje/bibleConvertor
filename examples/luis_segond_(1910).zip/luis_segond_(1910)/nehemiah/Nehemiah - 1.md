---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/nehemiah"
  - "#bible/testament/old"
aliases:
  - "Nehemiah - 1 - Luis Segond (1910)"
---
Nehemiah - 1 [[Nehemiah - 2|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Nehemiah]]

# Nehemiah - 1

Paroles de Néhémie, fils de Hacalia. Au mois de Kisleu, la vingtième année, comme j’étais à Suse, dans la capitale, [^1] Hanani, l’un de mes frères, et quelques hommes arrivèrent de Juda. Je les questionnai au sujet des Juifs réchappés qui étaient restés de la captivité, et au sujet de Jérusalem. [^2] Ils me répondirent: Ceux qui sont restés de la captivité sont là dans la province, au comble du malheur et de l’opprobre; les murailles de Jérusalem sont en ruines, et ses portes sont consumées par le feu. [^3] Lorsque j’entendis ces choses, je m’assis, je pleurai, et je fus plusieurs jours dans la désolation. Je jeûnai et je priai devant le Dieu des cieux, [^4] et je dis: #Da 9:4.O Éternel, Dieu des cieux, Dieu grand et redoutable, #Ex 20:6; 34:7. No 14:18. De 5:10. Ps 86:15; 103:8; 145:8.toi qui gardes ton alliance et qui fais miséricorde à ceux qui t’aiment et qui observent tes commandements! [^5] Que ton oreille soit attentive et que tes yeux soient ouverts: écoute la prière que ton serviteur t’adresse en ce moment, jour et nuit, pour tes serviteurs les enfants d’Israël, en confessant les péchés des enfants d’Israël, nos péchés contre toi; car moi et la maison de mon père, nous avons péché. [^6] Nous t’avons offensé, et nous n’avons point observé les commandements, les lois et les ordonnances que tu prescrivis à Moïse, ton serviteur. [^7] Souviens-toi de cette #De 4:25, 26, 27; 30:2, 3, 4.parole que tu donnas ordre à Moïse, ton serviteur, de prononcer. Lorsque vous pécherez, je vous disperserai parmi les peuples; [^8] mais si vous revenez à moi, et si vous observez mes commandements et les mettez en pratique, alors, quand vous seriez exilés à l’extrémité du ciel, de là je vous rassemblerai et je vous ramènerai dans le lieu que j’ai choisi pour y faire résider mon nom. [^9] Ils sont tes serviteurs et ton peuple, que tu as rachetés par ta grande puissance et par ta main forte. [^10] Ah! Seigneur, que ton oreille soit attentive à la prière de ton serviteur, et à la prière de tes serviteurs qui veulent craindre ton nom! Donne aujourd’hui du succès à ton serviteur, et fais-lui trouver grâce devant cet homme! J’étais alors échanson du roi. [^11] 

Nehemiah - 1 [[Nehemiah - 2|-->]]

---
# Notes
