---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/nehemiah"
  - "#bible/testament/old"
aliases:
  - "Nehemiah - 5 - Luis Segond (1910)"
---
[[Nehemiah - 4|<--]] Nehemiah - 5 [[Nehemiah - 6|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Nehemiah]]

# Nehemiah - 5

Il s’éleva de la part des gens du peuple et de leurs femmes de grandes plaintes contre leurs frères les Juifs. [^1] Les uns disaient: Nous, nos fils et nos filles, nous sommes nombreux; qu’on nous donne du blé, afin que nous mangions et que nous vivions. [^2] D’autres disaient: Nous engageons nos champs, nos vignes, et nos maisons, pour avoir du blé pendant la famine. [^3] D’autres disaient: Nous avons emprunté de l’argent sur nos champs et nos vignes pour le tribut du roi. [^4] Et pourtant notre chair est comme la chair de nos frères, nos enfants sont comme leurs enfants; et voici, nous soumettons à la servitude nos fils et nos filles, et plusieurs de nos filles y sont déjà réduites; nous sommes sans force, et nos champs et nos vignes sont à d’autres. [^5] Je fus très irrité lorsque j’entendis leurs plaintes et ces paroles-là. [^6] Je résolus de faire des réprimandes aux grands et aux magistrats, et je leur dis: Quoi! Vous prêtez à intérêt à vos frères! Et je rassemblai autour d’eux une grande foule, [^7] et je leur dis: Nous avons racheté selon notre pouvoir nos frères les Juifs vendus aux nations; et vous vendriez vous-mêmes vos frères, et c’est à nous qu’ils seraient vendus! Ils se turent, ne trouvant rien à répondre. [^8] Puis je dis: Ce que vous faites n’est pas bien. Ne devriez-vous pas marcher dans la crainte de notre Dieu, pour n’être pas insultés par les nations nos ennemies? [^9] Moi aussi, et mes frères et mes serviteurs, nous leur avons prêté de l’argent et du blé. Abandonnons ce qu’ils nous doivent! [^10] Rendez-leur donc aujourd’hui leurs champs, leurs vignes, leurs oliviers et leurs maisons, et le centième de l’argent, du blé, du moût et de l’huile que vous avez exigé d’eux comme intérêt. [^11] Ils répondirent: Nous les rendrons, et nous ne leur demanderons rien, nous ferons ce que tu dis. Alors j’appelai les sacrificateurs, devant lesquels je les fis jurer de tenir parole. [^12] Et je secouai mon manteau, en disant: Que Dieu secoue de la même manière hors de sa maison et de ses biens tout homme qui n’aura point tenu parole, et qu’ainsi cet homme soit secoué et laissé à vide! Toute l’assemblée dit: Amen! On célébra l’Éternel. Et le peuple tint parole. [^13] Dès le jour où le roi m’établit leur gouverneur dans le pays de Juda, depuis la vingtième année jusqu’à la trente-deuxième année du roi Artaxerxès, pendant douze ans, ni moi ni mes frères n’avons vécu des revenus du gouverneur. [^14] Avant moi, les premiers gouverneurs accablaient le peuple, et recevaient de lui du pain et du vin, outre quarante sicles d’argent; leurs serviteurs mêmes opprimaient le peuple. Je n’ai point agi de la sorte, par crainte de Dieu. [^15] Bien plus, j’ai travaillé à la réparation de cette muraille, et nous n’avons acheté aucun champ, et mes serviteurs tous ensemble étaient à l’ouvrage. [^16] J’avais à ma table cent cinquante hommes, Juifs et magistrats, outre ceux qui venaient à nous des nations d’alentour. [^17] On m’apprêtait chaque jour un bœuf, six moutons choisis, et des oiseaux; et tous les dix jours on préparait en abondance tout le vin nécessaire. Malgré cela, je n’ai point réclamé les revenus du gouverneur, parce que les travaux étaient à la charge de ce peuple. [^18] #Né 13:22.Souviens-toi favorablement de moi, ô mon Dieu, à cause de tout ce que j’ai fait pour ce peuple! [^19] 

[[Nehemiah - 4|<--]] Nehemiah - 5 [[Nehemiah - 6|-->]]

---
# Notes
