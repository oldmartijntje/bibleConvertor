---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/nehemiah"
  - "#bible/testament/old"
aliases:
  - "Nehemiah - 4 - Luis Segond (1910)"
---
[[Nehemiah - 3|<--]] Nehemiah - 4 [[Nehemiah - 5|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Nehemiah]]

# Nehemiah - 4

Lorsque Sanballat apprit que nous rebâtissions la muraille, il fut en colère et très irrité. [^1] Il se moqua des Juifs, et dit devant ses frères et devant les soldats de Samarie: A quoi travaillent ces Juifs impuissants? Les laissera-t-on faire? Sacrifieront-ils? Vont-ils achever? Redonneront-ils vie à des pierres ensevelies sous des monceaux de poussière et consumées par le feu? [^2] Tobija, l’Ammonite, était à côté de lui, et il dit: Qu’ils bâtissent seulement! Si un renard s’élance, il renversera leur muraille de pierres! [^3] Écoute, ô notre Dieu, comme nous sommes méprisés! Fais retomber leurs insultes sur leur tête, et livre-les au pillage sur une terre où ils soient captifs. [^4] Ne pardonne pas leur iniquité, et que leur péché ne soit pas effacé de devant toi; car ils ont offensé ceux qui bâtissent. [^5] Nous rebâtîmes la muraille, qui fut partout achevée jusqu’à la moitié de sa hauteur. Et le peuple prit à cœur ce travail. [^6] Mais Sanballat, Tobija, les Arabes, les Ammonites et les Asdodiens, furent très irrités en apprenant que la réparation des murs avançait et que les brèches commençaient à se fermer. [^7] Ils se liguèrent tous ensemble pour venir attaquer Jérusalem et lui causer du dommage. [^8] Nous priâmes notre Dieu, et nous établîmes une garde jour et nuit pour nous défendre contre leurs attaques. [^9] Cependant Juda disait: Les forces manquent à ceux qui portent les fardeaux, et les décombres sont considérables; nous ne pourrons pas bâtir la muraille. [^10] Et nos ennemis disaient: Ils ne sauront et ne verront rien jusqu’à ce que nous arrivions au milieu d’eux; nous les tuerons, et nous ferons ainsi cesser l’ouvrage. [^11] Or les Juifs qui habitaient près d’eux vinrent dix fois nous avertir, de tous les lieux d’où ils se rendaient vers nous. [^12] C’est pourquoi je plaçai, dans les enfoncements derrière la muraille et sur des terrains secs, le peuple par familles, tous avec leurs épées, leurs lances et leurs arcs. [^13] Je regardai, et m’étant levé, je dis aux grands, aux magistrats, et au reste du peuple: #No 14:9. De 1:21; 20:3.Ne les craignez pas! Souvenez-vous du Seigneur, grand et redoutable, et combattez pour vos frères, pour vos fils et vos filles, pour vos femmes et pour vos maisons! [^14] Lorsque nos ennemis apprirent que nous étions avertis, Dieu anéantit leur projet, et nous retournâmes tous à la muraille, chacun à son ouvrage. [^15] Depuis ce jour, la moitié de mes serviteurs travaillaient, et l’autre moitié était armée de lances, de boucliers, d’arcs et de cuirasses. Les chefs étaient derrière toute la maison de Juda. [^16] Ceux qui bâtissaient la muraille, et ceux qui portaient ou chargeaient les fardeaux, travaillaient d’une main et tenaient une arme de l’autre; [^17] chacun d’eux, en travaillant, avait son épée ceinte autour des reins. Celui qui sonnait de la trompette se tenait près de moi. [^18] Je dis aux grands, aux magistrats, et au reste du peuple: L’ouvrage est considérable et étendu, et nous sommes dispersés sur la muraille, éloignés les uns des autres. [^19] Au son de la trompette, rassemblez-vous auprès de nous, vers le lieu d’où vous l’entendrez; #Ex 14:25. De 1:3; 28:7.notre Dieu combattra pour nous. [^20] C’est ainsi que nous poursuivions l’ouvrage, la moitié d’entre nous la lance à la main depuis le lever de l’aurore jusqu’à l’apparition des étoiles. [^21] Dans ce même temps, je dis encore au peuple: Que chacun passe la nuit dans Jérusalem avec son serviteur; faisons la garde pendant la nuit, et travaillons pendant le jour. [^22] Et nous ne quittions point nos vêtements, ni moi, ni mes frères, ni mes serviteurs, ni les hommes de garde qui me suivaient; chacun n’avait que ses armes et de l’eau. [^23] 

[[Nehemiah - 3|<--]] Nehemiah - 4 [[Nehemiah - 5|-->]]

---
# Notes
