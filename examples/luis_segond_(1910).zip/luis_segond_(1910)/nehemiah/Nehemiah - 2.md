---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/nehemiah"
  - "#bible/testament/old"
aliases:
  - "Nehemiah - 2 - Luis Segond (1910)"
---
[[Nehemiah - 1|<--]] Nehemiah - 2 [[Nehemiah - 3|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[Nehemiah]]

# Nehemiah - 2

Au mois de Nisan, la vingtième année du roi Artaxerxès, comme le vin était devant lui, je pris le vin et je l’offris au roi. Jamais je n’avais paru triste en sa présence. [^1] Le roi me dit: Pourquoi as-tu mauvais visage? Tu n’es pourtant pas malade; ce ne peut être qu’un chagrin de cœur. Je fus saisi d’une grande crainte, [^2] et je répondis au roi: Que le roi vive éternellement! Comment n’aurais-je pas mauvais visage, lorsque la ville où sont les sépulcres de mes pères est détruite et que ses portes sont consumées par le feu? [^3] Et le roi me dit: Que demandes-tu? Je priai le Dieu des cieux, [^4] et je répondis au roi: Si le roi le trouve bon, et si ton serviteur lui est agréable, envoie-moi en Juda, vers la ville des sépulcres de mes pères, pour que je la rebâtisse. [^5] Le roi, auprès duquel la reine était assise, me dit alors: Combien ton voyage durera-t-il, et quand seras-tu de retour? Il plut au roi de me laisser partir, et je lui fixai un temps. [^6] Puis je dis au roi: Si le roi le trouve bon, qu’on me donne des lettres pour les gouverneurs de l’autre côté du fleuve, afin qu’ils me laissent passer et entrer en Juda, [^7] et une lettre pour Asaph, garde forestier du roi, afin qu’il me fournisse du bois de charpente pour les portes de la citadelle près de la maison, pour la muraille de la ville, et pour la maison que j’occuperai. Le roi me donna ces lettres, car la bonne main de mon Dieu était sur moi. [^8] Je me rendis auprès des gouverneurs de l’autre côté du fleuve, et je leur remis les lettres du roi, qui m’avait fait accompagner par des chefs de l’armée et par des cavaliers. [^9] Sanballat, le Horonite, et Tobija, le serviteur ammonite, l’ayant appris, eurent un grand déplaisir de ce qu’il venait un homme pour chercher le bien des enfants d’Israël. [^10] J’arrivai à Jérusalem, et j’y passai trois jours. [^11] Après quoi, je me levai pendant la nuit avec quelques hommes, sans avoir dit à personne ce que mon Dieu m’avait mis au cœur de faire pour Jérusalem. Il n’y avait avec moi d’autre bête de somme que ma propre monture. [^12] Je sortis de nuit par la porte de la vallée, et je me dirigeai contre la source du dragon et vers la porte du fumier, considérant les murailles en ruines de Jérusalem et réfléchissant à ses portes consumées par le feu. [^13] Je passai près de la porte de la source et de l’étang du roi, et il n’y avait point de place par où pût passer la bête qui était sous moi. [^14] Je montai de nuit par le torrent, et je considérai encore la muraille. Puis je rentrai par la porte de la vallée, et je fus ainsi de retour. [^15] Les magistrats ignoraient où j’étais allé, et ce que je faisais. Jusqu’à ce moment, je n’avais rien dit aux Juifs, ni aux sacrificateurs, ni aux grands, ni aux magistrats, ni à aucun de ceux qui s’occupaient des affaires. [^16] Je leur dis alors: Vous voyez le malheureux état où nous sommes! Jérusalem est détruite, et ses portes sont consumées par le feu! Venez, rebâtissons la muraille de Jérusalem, et nous ne serons plus dans l’opprobre. [^17] Et je leur racontai comment la bonne main de mon Dieu avait été sur moi, et quelles paroles le roi m’avait adressées. Ils dirent: Levons-nous, et bâtissons! Et ils se fortifièrent dans cette bonne résolution. [^18] Sanballat, le Horonite, Tobija, le serviteur ammonite, et Guéschem, l’Arabe, en ayant été informés, se moquèrent de nous et nous méprisèrent. Ils dirent: Que faites-vous là? Vous révoltez-vous contre le roi? [^19] Et je leur fis cette réponse: Le Dieu des cieux nous donnera le succès. Nous, ses serviteurs, nous nous lèverons et nous bâtirons; mais vous, vous n’avez ni part, ni droit, ni souvenir dans Jérusalem. [^20] 

[[Nehemiah - 1|<--]] Nehemiah - 2 [[Nehemiah - 3|-->]]

---
# Notes
