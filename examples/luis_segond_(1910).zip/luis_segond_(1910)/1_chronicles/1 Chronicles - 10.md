---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 10 - Luis Segond (1910)"
---
[[1 Chronicles - 9|<--]] 1 Chronicles - 10 [[1 Chronicles - 11|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[1 Chronicles]]

# 1 Chronicles - 10

Les Philistins livrèrent bataille à Israël, et les hommes d’Israël prirent la fuite devant les Philistins et tombèrent morts sur la montagne de Guilboa. [^1] Les Philistins poursuivirent Saül et ses fils, et tuèrent Jonathan, Abinadab et Malki-Schua, fils de Saül. [^2] L’effort du combat porta sur Saül; les archers l’atteignirent et le blessèrent. [^3] Saül dit alors à celui qui portait ses armes: Tire ton épée, et transperce-m’en, de peur que ces incirconcis ne viennent me faire subir leurs outrages. Celui qui portait ses armes ne voulut pas, car il était saisi de crainte. Et Saül prit son épée, et se jeta dessus. [^4] Celui qui portait les armes de Saül, le voyant mort, se jeta aussi sur son épée, et mourut. [^5] Ainsi périrent Saül et ses trois fils, et toute sa maison périt en même temps. [^6] Tous ceux d’Israël qui étaient dans la vallée, ayant vu qu’on avait fui et que Saül et ses fils étaient morts, abandonnèrent leurs villes pour prendre aussi la fuite. Et les Philistins allèrent s’y établir. [^7] Le lendemain, les Philistins vinrent pour dépouiller les morts, et ils trouvèrent Saül et ses fils tombés sur la montagne de Guilboa. [^8] Ils le dépouillèrent, et emportèrent sa tête et ses armes. Puis ils firent annoncer ces bonnes nouvelles par tout le pays des Philistins à leurs idoles et au peuple. [^9] #1 S 31:10.Ils mirent les armes de Saül dans la maison de leur dieu, et ils attachèrent son crâne dans le temple de Dagon. [^10] Tout Jabès en Galaad ayant appris tout ce que les Philistins avaient fait à Saül, [^11] tous les hommes vaillants se levèrent, prirent le corps de Saül et ceux de ses fils, et les transportèrent à Jabès. Ils enterrèrent leurs os sous le térébinthe, à Jabès, et ils jeûnèrent sept jours. [^12] Saül mourut, parce qu’il se rendit coupable d’infidélité envers l’Éternel, dont il n’observa point la parole, et #1 S 28:8.parce qu’il interrogea et consulta ceux qui évoquent les morts. [^13] Il ne consulta point l’Éternel; alors l’Éternel le fit mourir, et transféra la royauté à David, fils d’Isaï. [^14] 

[[1 Chronicles - 9|<--]] 1 Chronicles - 10 [[1 Chronicles - 11|-->]]

---
# Notes
