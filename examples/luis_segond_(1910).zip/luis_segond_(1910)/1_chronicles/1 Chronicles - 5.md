---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 5 - Luis Segond (1910)"
---
[[1 Chronicles - 4|<--]] 1 Chronicles - 5 [[1 Chronicles - 6|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[1 Chronicles]]

# 1 Chronicles - 5

Fils de Ruben, premier-né d’Israël. Car il était le premier-né; mais, parce qu’il souilla la couche de son père, son droit d’aînesse fut donné aux fils de Joseph, fils d’Israël; toutefois Joseph ne dut pas être enregistré dans les généalogies comme premier-né. [^1] Juda fut, à la vérité, puissant parmi ses frères, et de lui est issu un prince; mais le droit d’aînesse est à Joseph. [^2] Fils de Ruben, premier-né d’Israël: #Ge 46:9. Ex 6:13. No 26:5.Hénoc, Pallu, Hetsron et Carmi. [^3] Fils de Joël: Schemaeja, son fils; Gog, son fils; Schimeï, son fils; [^4] Michée, son fils; Reaja, son fils; Baal, son fils; [^5] Beéra, son fils, que Tilgath-Pilnéser, roi d’Assyrie, emmena captif: il était prince des Rubénites. [^6] Frères de Beéra, d’après leurs familles, tels qu’ils sont enregistrés dans les généalogies selon leurs générations: le premier, Jeïel; Zacharie; [^7] Béla, fils d’Azaz, fils de Schéma, fils de Joël. Béla habitait à Aroër, et jusqu’à Nebo et à Baal-Meon; [^8] à l’orient, il habitait jusqu’à l’entrée du désert depuis le fleuve de l’Euphrate, car leurs troupeaux étaient nombreux dans le pays de Galaad. [^9] Du temps de Saül, ils firent la guerre aux Hagaréniens, qui tombèrent entre leurs mains; et ils habitèrent dans leurs tentes, sur tout le côté oriental de Galaad. [^10] Les fils de Gad habitaient vis-à-vis d’eux, dans #Jos 13:24.le pays de Basan, jusqu’à Salca. [^11] Joël, le premier, Schapham, le second, Jaenaï, et Schaphath, en Basan. [^12] Leurs frères, d’après les maisons de leurs pères: Micaël, Meschullam, Schéba, Joraï, Jaecan, Zia et Éber, sept. [^13] Voici les fils d’Abichaïl, fils de Huri, fils de Jaroach, fils de Galaad, fils de Micaël, fils de Jeschischaï, fils de Jachdo, fils de Buz; [^14] Achi, fils d’Abdiel, fils de Guni, était chef des maisons de leurs pères. [^15] Ils habitaient en Galaad, en Basan, et dans les villes de leur ressort, et dans toutes les banlieues de Saron jusqu’à leurs extrémités. [^16] Ils furent tous enregistrés dans les généalogies, du temps de Jotham, roi de Juda, et du temps de Jéroboam, roi d’Israël. [^17] Les fils de Ruben, les Gadites et la demi-tribu de Manassé avaient de vaillants hommes, portant le bouclier et l’épée, tirant de l’arc, et exercés à la guerre, au nombre de quarante-quatre mille sept cent soixante, en état d’aller à l’armée. [^18] Ils firent la guerre aux Hagaréniens, à Jethur, à Naphisch et à Nodab. [^19] Ils reçurent du secours contre eux, et les Hagaréniens et tous ceux qui étaient avec eux furent livrés entre leurs mains. Car, pendant le combat, ils avaient crié à Dieu, qui les exauça, parce qu’ils s’étaient confiés en lui. [^20] Ils prirent leurs troupeaux, cinquante mille chameaux, deux cent cinquante mille brebis, deux mille ânes, et cent mille personnes; [^21] car il y eut beaucoup de morts, parce que le combat venait de Dieu. Et ils s’établirent à leur place jusqu’au temps où ils furent emmenés captifs. [^22] Les fils de la demi-tribu de Manassé habitaient dans le pays, depuis Basan jusqu’à Baal-Hermon et à Senir, et à la montagne d’Hermon; ils étaient nombreux. [^23] Voici les chefs des maisons de leurs pères: Épher, Jischeï, Éliel, Azriel, Jérémie, Hodavia et Jachdiel, vaillants hommes, gens de renom, chefs des maisons de leurs pères. [^24] Mais ils péchèrent contre le Dieu de leurs pères, et ils se prostituèrent après les dieux des peuples du pays, que Dieu avait détruits devant eux. [^25] Le Dieu d’Israël excita l’esprit de Pul, roi d’Assyrie, et l’esprit de Tilgath-Pilnéser, roi d’Assyrie, et Tilgath-Pilnéser emmena captifs les Rubénites, les Gadites et la demi-tribu de Manassé, et il les conduisit à Chalach, à Chabor, à Hara, et au fleuve de Gozan, où ils sont demeurés jusqu’à ce jour. [^26] 

[[1 Chronicles - 4|<--]] 1 Chronicles - 5 [[1 Chronicles - 6|-->]]

---
# Notes
