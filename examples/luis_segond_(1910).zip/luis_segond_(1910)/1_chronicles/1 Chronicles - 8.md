---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 8 - Luis Segond (1910)"
---
[[1 Chronicles - 7|<--]] 1 Chronicles - 8 [[1 Chronicles - 9|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[1 Chronicles]]

# 1 Chronicles - 8

Benjamin engendra Béla, son premier-né, Aschbel le second, Achrach le troisième, [^1] Nocha le quatrième, et Rapha le cinquième. [^2] Les fils de Béla furent: Addar, Guéra, Abihud, [^3] Abischua, Naaman, Achoach, [^4] Guéra, Schephuphan et Huram. [^5] Voici les fils d’Échud, qui étaient chefs de famille parmi les habitants de Guéba, et qui les transportèrent à Manachath: [^6] Naaman, Achija et Guéra. Guéra, qui les transporta, engendra Uzza et Achichud. [^7] Schacharaïm eut des enfants au pays de Moab, après qu’il eut renvoyé Huschim et Baara, ses femmes. [^8] Il eut de Hodesch, sa femme: Jobab, Tsibja, Méscha, Malcam, [^9] Jeuts, Schocja et Mirma. Ce sont là ses fils, chefs de famille. [^10] Il eut de Huschim: Abithub et Elpaal. [^11] Fils d’Elpaal: Éber, Mischeam, et Schémer, qui bâtit Ono, Lod et les villes de son ressort. [^12] Beria et Schéma, qui étaient chefs de famille parmi les habitants d’Ajalon, mirent en fuite les habitants de Gath. [^13] Achjo, Schaschak, Jerémoth, [^14] Zebadja, Arad, Éder, [^15] Micaël, Jischpha et Jocha étaient fils de Beria. [^16] Zebadja, Meschullam, Hizki, Héber, [^17] Jischmeraï, Jizlia et Jobab étaient fils d’Elpaal. [^18] Jakim, Zicri, Zabdi, [^19] Éliénaï, Tsilthaï, Éliel, [^20] Adaja, Beraja et Schimrath étaient fils de Schimeï. [^21] Jischpan, Éber, Éliel, [^22] Abdon, Zicri, Hanan, [^23] Hanania, Élam, Anthothija, [^24] Jiphdeja et Penuel étaient fils de Schaschak. [^25] Schamscheraï, Schecharia, Athalia, [^26] Jaaréschia, Élija et Zicri étaient fils de Jerocham. [^27] Ce sont là des chefs de famille, chefs selon leurs générations. Ils habitaient à Jérusalem. [^28] Le père de Gabaon habitait à Gabaon, et le nom de sa femme était Maaca. [^29] Abdon, son fils premier-né, puis Tsur, Kis, Baal, Nadab, [^30] Guedor, Achjo, et Zéker. [^31] Mikloth engendra Schimea. Ils habitaient aussi à Jérusalem près de leurs frères, avec leurs frères. [^32] Ner engendra Kis; Kis engendra Saül; Saül engendra Jonathan, Malki-Schua, Abinadab et Eschbaal. [^33] Fils de Jonathan: Merib-Baal. #2 S 9:12.Merib-Baal engendra Michée. [^34] Fils de Michée: Pithon, Mélec, Thaeréa et Achaz. [^35] Achaz engendra Jehoadda; Jehoadda engendra Alémeth, Azmaveth et Zimri; Zimri engendra Motsa; [^36] Motsa engendra Binea. Rapha, son fils; Éleasa, son fils; Atsel, son fils; [^37] Atsel eut six fils, dont voici les noms: Azrikam, Bocru, Ismaël, Schearia, Abdias et Hanan. Tous ceux-là étaient fils d’Atsel. [^38] Fils d’Eschek, son frère: Ulam, son premier-né, Jeusch le second, et Éliphéleth le troisième. [^39] Les fils d’Ulam furent de vaillants hommes, tirant de l’arc; et ils eurent beaucoup de fils et de petits-fils, cent cinquante. Tous ceux-là sont des fils de Benjamin. [^40] 

[[1 Chronicles - 7|<--]] 1 Chronicles - 8 [[1 Chronicles - 9|-->]]

---
# Notes
