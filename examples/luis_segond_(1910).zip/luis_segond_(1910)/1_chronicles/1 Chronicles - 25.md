---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 25 - Luis Segond (1910)"
---
[[1 Chronicles - 24|<--]] 1 Chronicles - 25 [[1 Chronicles - 26|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[1 Chronicles]]

# 1 Chronicles - 25

David et les chefs de l’armée mirent à part pour le service ceux des fils d’Asaph, d’Héman et de Jeduthun qui prophétisaient en s’accompagnant de la harpe, du luth et des cymbales. Et voici le nombre de ceux qui avaient des fonctions à remplir. [^1] Des fils d’Asaph: Zaccur, Joseph, Nethania et Aschareéla, fils d’Asaph, sous la direction d’Asaph qui prophétisait suivant les ordres du roi. [^2] De Jeduthun, les fils de Jeduthun: Guedalia, Tseri, Ésaïe, Haschabia, Matthithia et Schimeï, six, sous la direction de leur père Jeduthun qui prophétisait avec la harpe pour louer et célébrer l’Éternel. [^3] D’Héman, les fils d’Héman: Bukkija, Matthania, Uziel, Schebuel, Jerimoth, Hanania, Hanani, Éliatha, Guiddalthi, Romamthi-Ézer, Joschbekascha, Mallothi, Hothir, Machazioth, [^4] tous fils d’Héman, qui était voyant du roi pour révéler les paroles de Dieu et pour exalter sa puissance; Dieu avait donné à Héman quatorze fils et trois filles. [^5] Tous ceux-là étaient sous la direction de leurs pères, pour le chant de la maison de l’Éternel, et avaient des cymbales, des luths et des harpes pour le service de la maison de Dieu. Asaph, Jeduthun et Héman recevaient les ordres du roi. [^6] Ils étaient au nombre de deux cent quatre-vingt-huit, y compris leurs frères exercés au chant de l’Éternel, tous ceux qui étaient habiles. [^7] Ils tirèrent au sort pour leurs fonctions, petits et grands, maîtres et disciples. [^8] Le premier sort échut, pour Asaph, à Joseph; le second, à Guedalia, lui, ses frères et ses fils, douze; [^9] le troisième, à Zaccur, ses fils et ses frères, douze; [^10] le quatrième, à Jitseri, ses fils et ses frères, douze; [^11] le cinquième, à Nethania, ses fils et ses frères, douze; [^12] le sixième, à Bukkija, ses fils et ses frères, douze; [^13] le septième, à Jesareéla, ses fils et ses frères, douze; [^14] le huitième, à Ésaïe, ses fils et ses frères, douze; [^15] le neuvième, à Matthania, ses fils et ses frères, douze; [^16] le dixième, à Schimeï, ses fils et ses frères, douze; [^17] le onzième, à Azareel, ses fils et ses frères, douze; [^18] le douzième, à Haschabia, ses fils et ses frères, douze; [^19] le treizième, à Schubaël, ses fils et ses frères, douze; [^20] le quatorzième, à Matthithia, ses fils et ses frères, douze; [^21] le quinzième, à Jerémoth, ses fils et ses frères, douze; [^22] le seizième, à Hanania, ses fils et ses frères, douze; [^23] le dix-septième, à Joschbekascha, ses fils et ses frères, douze; [^24] le dix-huitième, à Hanani, ses fils et ses frères, douze; [^25] le dix-neuvième, à Mallothi, ses fils et ses frères, douze; [^26] le vingtième, à Élijatha, ses fils et ses frères, douze; [^27] le vingt et unième, à Hothir, ses fils et ses frères, douze; [^28] le vingt-deuxième, à Guiddalthi, ses fils et ses frères, douze; [^29] le vingt-troisième, à Machazioth, ses fils et ses frères, douze; [^30] le vingt-quatrième, à Romamthi-Ézer, ses fils et ses frères, douze. [^31] 

[[1 Chronicles - 24|<--]] 1 Chronicles - 25 [[1 Chronicles - 26|-->]]

---
# Notes
