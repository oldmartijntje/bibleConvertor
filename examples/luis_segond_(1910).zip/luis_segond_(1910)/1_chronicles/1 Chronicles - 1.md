---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 1 - Luis Segond (1910)"
---
1 Chronicles - 1 [[1 Chronicles - 2|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[1 Chronicles]]

# 1 Chronicles - 1

Adam, #Ge 5:3, 4.Seth, Énosch, [^1] Kénan, Mahalaleel, Jéred, [^2] Hénoc, Metuschélah, Lémec, [^3] Noé.Sem, Cham et Japhet. [^4] #Ge 10:2, etc.Fils de Japhet: Gomer, Magog, Madaï, Javan, Tubal, Méschec et Tiras. [^5] Fils de Gomer: Aschkenaz, Diphat et Togarma. [^6] Fils de Javan: Élischa, Tarsisa, Kittim et Rodanim. [^7] Fils de #Ge 10:6, etc.Cham: Cusch, Mitsraïm, Puth et Canaan. [^8] Fils de Cusch: Saba, Havila, Sabta, Raema et Sabteca. Fils de Raema: Séba et Dedan. [^9] Cusch engendra Nimrod; c’est lui qui commença à être puissant sur la terre. [^10] Mitsraïm engendra les Ludim, les Ananim, les Lehabim, les Naphtuhim, [^11] les Patrusim, les Casluhim, #Ge 10:14.d’où sont sortis les Philistins, et les Caphtorim. [^12] Canaan engendra Sidon, son premier-né, et Heth, [^13] et les Jébusiens, les Amoréens, les Guirgasiens, [^14] les Héviens, les Arkiens, les Siniens, [^15] les Arvadiens, les Tsemariens, les Hamathiens. [^16] #    Ge 10:22, etc.  Fils de Sem: Élam, Assur, Arpacschad, Lud et Aram; Uts, Hul, Guéter et Méschec. [^17] Arpacschad engendra Schélach; et Schélach engendra Héber. [^18] Il naquit à Héber deux fils: le nom de l’un était Péleg, parce que de son temps la terre fut partagée, et le nom de son frère était Jokthan. [^19] Jokthan engendra Almodad, Schéleph, Hatsarmaveth, Jérach, [^20] Hadoram, Uzal, Dikla, [^21] Ébal, Abimaël, Séba, Ophir, Havila et Jobab. [^22] Tous ceux-là furent fils de Jokthan. [^23] #    Ge 11:10, etc. Lu 3:36.  Sem, Arpacschad, Schélach, [^24] Héber, Péleg, Rehu, [^25] Serug, Nachor, Térach, [^26] Abram, qui est Abraham. [^27] #    
        Ge 16:15; 21:2.  Fils d’Abraham: Isaac et Ismaël. [^28] Voici leur postérité. #Ge 25:13, etc.Nebajoth, premier-né d’Ismaël, Kédar, Adbeel, Mibsam, [^29] Mischma, Duma, Massa, Hadad, Téma, [^30] Jethur, Naphisch et Kedma. Ce sont là les fils d’Ismaël. [^31] #Ge 25:2.Fils de Ketura, concubine d’Abraham. Elle enfanta Zimran, Jokschan, Medan, Madian, Jischbak et Schuach. Fils de Jokschan: Séba et Dedan. [^32] Fils de Madian: Épha, Épher, Hénoc, Abida et Eldaa. Ce sont là tous les fils de Ketura. [^33] Abraham engendra Isaac. #Ge 25:21, 24, etc.Fils d’Isaac: Ésaü et Israël. [^34] #Ge 36:10.Fils d’Ésaü: Éliphaz, Reuel, Jeusch, Jaelam et Koré. [^35] Fils d’Éliphaz: Théman, Omar, Tsephi, Gaetham, Kenaz, Thimna et Amalek. [^36] Fils de Reuel: Nahath, Zérach, Schamma et Mizza. [^37] Fils de Séir: Lothan, Schobal, Tsibeon, Ana, Dischon, Étser et Dischan. [^38] Fils de Lothan: Hori et Homam. Sœur de Lothan: Thimna. [^39] Fils de Schobal: Aljan, Manahath, Ébal, Schephi et Onam. Fils de Tsibeon: Ajja et Ana. [^40] Fils d’Ana: Dischon. Fils de Dischon: Hamran, Eschban, Jithran et Keran. [^41] Fils d’Étser: Bilhan, Zaavan et Jaakan. Fils de Dischan: Uts et Aran. [^42] Voici les rois qui ont régné dans le pays d’Édom, avant qu’un roi régnât sur les enfants d’Israël. Béla, fils de Beor; et le nom de sa ville était Dinhaba. [^43] Béla mourut; et Jobab, fils de Zérach, de Botsra, régna à sa place. [^44] Jobab mourut; et Huscham, du pays des Thémanites, régna à sa place. [^45] Huscham mourut; et Hadad, fils de Bedad, régna à sa place. C’est lui qui frappa Madian dans les champs de Moab. Le nom de sa ville était Avith. [^46] Hadad mourut; et Samla, de Masréka, régna à sa place. [^47] Samla mourut; et Saül, de Rehoboth sur le fleuve, régna à sa place. [^48] Saül mourut; et Baal-Hanan, fils d’Acbor, régna à sa place. [^49] Baal-Hanan mourut; et Hadad régna à sa place. Le nom de sa ville était Pahi; et le nom de sa femme Mehéthabeel, fille de Mathred, fille de Mézahab. [^50] Hadad mourut. Les chefs d’Édom furent: le chef Thimna, le chef Alja, le chef Jetheth, [^51] le chef Oholibama, le chef Éla, le chef Pinon, [^52] le chef Kenaz, le chef Théman, le chef Mibtsar, [^53] le chef Magdiel, le chef Iram. Ce sont là des chefs d’Édom. [^54] 

1 Chronicles - 1 [[1 Chronicles - 2|-->]]

---
# Notes
