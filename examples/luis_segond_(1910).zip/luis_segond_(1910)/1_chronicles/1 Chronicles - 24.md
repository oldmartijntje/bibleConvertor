---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 24 - Luis Segond (1910)"
---
[[1 Chronicles - 23|<--]] 1 Chronicles - 24 [[1 Chronicles - 25|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[1 Chronicles]]

# 1 Chronicles - 24

#    
        Lé 10.  Voici les classes des fils d’Aaron. Fils d’Aaron: Nadab, Abihu, Éléazar et Ithamar. [^1] #Lé 10:2. No 3:4; 26:61.Nadab et Abihu moururent avant leur père, sans avoir de fils; et Éléazar et Ithamar remplirent les fonctions du sacerdoce. [^2] David divisa les fils d’Aaron en les classant pour le service qu’ils avaient à faire; Tsadok appartenait aux descendants d’Éléazar, et Achimélec aux descendants d’Ithamar. [^3] Il se trouva parmi les fils d’Éléazar plus de chefs que parmi les fils d’Ithamar, et on en fit la division; les fils d’Éléazar avaient seize chefs de maisons paternelles, et les fils d’Ithamar huit chefs de maisons paternelles. [^4] On les classa par le sort, les uns avec les autres, car les chefs du sanctuaire et les chefs de Dieu étaient des fils d’Éléazar et des fils d’Ithamar. [^5] Schemaeja, fils de Nethaneel, le secrétaire, de la tribu de Lévi, les inscrivit devant le roi et les princes, devant Tsadok, le sacrificateur, et Achimélec, fils d’Abiathar, et devant les chefs des maisons paternelles des sacrificateurs et des Lévites. On tira au sort une maison paternelle pour Éléazar, et on en tira une autre pour Ithamar. [^6] Le premier sort échut à Jehojarib; le second, à Jedaeja; [^7] le troisième, à Harim; le quatrième, à Seorim; [^8] le cinquième, à Malkija; le sixième, à Mijamin; [^9] le septième, à Hakkots; le huitième, à Abija; [^10] le neuvième, à Josué; le dixième, à Schecania; [^11] le onzième, à Éliaschib; le douzième, à Jakim; [^12] le treizième, à Huppa; le quatorzième, à Jeschébeab; [^13] le quinzième, à Bilga; le seizième, à Immer; [^14] le dix-septième, à Hézir; le dix-huitième, à Happitsets; [^15] le dix-neuvième, à Pethachja; le vingtième, à Ézéchiel; [^16] le vingt et unième, à Jakin; le vingt-deuxième, à Gamul; [^17] le vingt-troisième, à Delaja; le vingt-quatrième, à Maazia. [^18] C’est ainsi qu’ils furent classés pour leur service, afin qu’ils entrassent dans la maison de l’Éternel en se conformant à la règle établie par Aaron, leur père, d’après les ordres que lui avait donnés l’Éternel, le Dieu d’Israël. [^19] Voici les chefs du reste des Lévites. Des fils d’Amram: Schubaël; des fils de Schubaël: Jechdia; [^20] de Rechabia, des fils de Rechabia: le chef Jischija. [^21] Des Jitseharites: Schelomoth; des fils de Schelomoth: Jachath. [^22] Fils d’Hébron: Jerija, Amaria le second, Jachaziel le troisième, Jekameam le quatrième. [^23] Fils d’Uziel: Michée; des fils de Michée: Schamir; [^24] frère de Michée: Jischija; des fils de Jischija: Zacharie. [^25] Fils de Merari: Machli et Muschi, et les fils de Jaazija, son fils. [^26] Fils de Merari, de Jaazija, son fils: Schoham, Zaccur et Ibri. [^27] De Machli: Éléazar, qui n’eut point de fils; [^28] de Kis, les fils de Kis: Jerachmeel. [^29] Fils de Muschi: Machli, Éder et Jerimoth. Ce sont là les fils de Lévi, selon leurs maisons paternelles. [^30] Eux aussi, comme leurs frères, les fils d’Aaron, ils tirèrent au sort devant le roi David, Tsadok et Achimélec, et les chefs des maisons paternelles des sacrificateurs et des Lévites. Il en fut ainsi pour chaque chef de maison comme pour le moindre de ses frères. [^31] 

[[1 Chronicles - 23|<--]] 1 Chronicles - 24 [[1 Chronicles - 25|-->]]

---
# Notes
