---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 23 - Luis Segond (1910)"
---
[[1 Chronicles - 22|<--]] 1 Chronicles - 23 [[1 Chronicles - 24|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[1 Chronicles]]

# 1 Chronicles - 23

David, âgé et rassasié de jours, établit Salomon, son fils, roi sur Israël. [^1] Il assembla tous les chefs d’Israël, les sacrificateurs et les Lévites. [^2] On fit le dénombrement des Lévites, depuis l’âge de trente ans et au-dessus; comptés par tête et par homme, ils se trouvèrent au nombre de trente-huit mille. [^3] Et David dit: Qu’il y en ait vingt-quatre mille pour veiller aux offices de la maison de l’Éternel, six mille comme magistrats et juges, [^4] quatre mille comme portiers, et quatre mille chargés de louer l’Éternel avec les instruments que j’ai faits pour le célébrer. [^5] David les divisa en classes d’après les fils de Lévi, Guerschon, Kehath et Merari. [^6] Des Guerschonites: Laedan et Schimeï. [^7] Fils de Laedan: le chef Jehiel, Zétham et Joël, trois. [^8] Fils de Schimeï: Schelomith, Haziel et Haran, trois. Ce sont là les chefs des maisons paternelles de la famille de Laedan. [^9] Fils de Schimeï: Jachath, Zina, Jeusch et Beria. Ce sont là les quatre fils de Schimeï. [^10] Jachath était le chef, et Zina le second; Jeusch et Beria n’eurent pas beaucoup de fils, et ils formèrent une seule maison paternelle dans le dénombrement. [^11] Fils de Kehath: Amram, Jitsehar, Hébron et Uziel, quatre. [^12] #Ex 6:19.Fils d’Amram: Aaron et Moïse. #Ex 28:1, etc. Hé 5:4.Aaron fut mis à part pour être sanctifié comme très saint, lui et ses fils à perpétuité, pour offrir les parfums devant l’Éternel, pour faire son service, et pour bénir à toujours en son nom. [^13] Mais les fils de Moïse, homme de Dieu, furent comptés dans la tribu de Lévi. [^14] #Ex 2:22; 18:3.Fils de Moïse: Guerschom et Éliézer. [^15] Fils de Guerschom: Schebuel, le chef. [^16] Et les fils d’Éliézer furent: Rechabia, le chef; Éliézer n’eut pas d’autre fils, mais les fils de Rechabia furent très nombreux. [^17] Fils de Jitsehar: Schelomith, le chef. [^18] Fils d’Hébron: Jerija, le chef; Amaria, le second; Jachaziel, le troisième; et Jekameam, le quatrième. [^19] Fils d’Uziel: Michée, le chef; et Jischija, le second. [^20] Fils de Merari: Machli et Muschi. Fils de Machli: Éléazar et Kis. [^21] Éléazar mourut sans avoir de fils; mais il eut des filles, que prirent pour femmes les fils de Kis, leurs frères. [^22] Fils de Muschi: Machli, Éder et Jerémoth, trois. [^23] Ce sont là les fils de Lévi, selon leurs maisons paternelles, les chefs des maisons paternelles, d’après le dénombrement qu’on en fit en comptant les noms par tête. Ils étaient employés au service de la maison de l’Éternel, depuis l’âge de vingt ans et au-dessus. [^24] Car David dit: L’Éternel, le Dieu d’Israël, a donné du repos à son peuple, et il habitera pour toujours à Jérusalem; [^25] et les Lévites n’auront plus à porter le tabernacle et tous les ustensiles pour son service. [^26] Ce fut d’après les derniers ordres de David qu’eut lieu le dénombrement des fils de Lévi depuis l’âge de vingt ans et au-dessus. [^27] Placés auprès des fils d’Aaron pour le service de la maison de l’Éternel, ils avaient à prendre soin des parvis et des chambres, de la purification de toutes les choses saintes, des ouvrages concernant le service de la maison de Dieu, [^28] des pains de proposition, de la fleur de farine pour les offrandes, des galettes sans levain, des gâteaux cuits sur la plaque et des gâteaux frits, de toutes les mesures de capacité et de longueur: [^29] ils avaient à se présenter chaque matin et chaque soir, afin de louer et de célébrer l’Éternel, [^30] et à offrir continuellement devant l’Éternel tous les holocaustes à l’Éternel, aux sabbats, aux nouvelles lunes et aux fêtes, selon le nombre et les usages prescrits. [^31] Ils donnaient leurs soins à la tente d’assignation, au sanctuaire, et aux fils d’Aaron, leurs frères, pour le service de la maison de l’Éternel. [^32] 

[[1 Chronicles - 22|<--]] 1 Chronicles - 23 [[1 Chronicles - 24|-->]]

---
# Notes
