---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 20 - Luis Segond (1910)"
---
[[1 Chronicles - 19|<--]] 1 Chronicles - 20 [[1 Chronicles - 21|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[1 Chronicles]]

# 1 Chronicles - 20

L’année suivante, au temps où les rois se mettaient en campagne, Joab, à la tête d’une forte armée, alla ravager le pays des fils d’Ammon et assiéger Rabba. Mais David resta à Jérusalem. Joab battit Rabba et la détruisit. [^1] David enleva la couronne de dessus la tête de son roi, et la trouva du poids d’un talent d’or: elle était garnie de pierres précieuses. On la mit sur la tête de David, qui emporta de la ville un très grand butin. [^2] Il fit sortir les habitants, et #2 S 12:31.il les mit en pièces avec des scies, des herses de fer et des haches; il traita de même toutes les villes des fils d’Ammon. David retourna à Jérusalem avec tout le peuple. [^3] Après cela, il y eut une bataille à Guézer avec les Philistins. Alors Sibbecaï, le Huschatite, tua Sippaï, l’un des enfants de Rapha. Et les Philistins furent humiliés. [^4] Il y eut encore une bataille avec les Philistins. Et Elchanan, fils de Jaïr, tua le frère de Goliath, Lachmi de Gath, qui avait une lance dont le bois était comme une ensouple de tisserand. [^5] Il y eut encore une bataille à Gath. Il s’y trouva un homme de haute taille, qui avait six doigts à chaque main et à chaque pied, vingt-quatre en tout, et qui était aussi issu de Rapha. [^6] Il jeta un défi à Israël; et Jonathan, fils de Schimea, frère de David, le tua. [^7] Ces hommes étaient des enfants de Rapha à Gath. Ils périrent par la main de David et par la main de ses serviteurs. [^8] 

[[1 Chronicles - 19|<--]] 1 Chronicles - 20 [[1 Chronicles - 21|-->]]

---
# Notes
