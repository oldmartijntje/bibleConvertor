---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 13 - Luis Segond (1910)"
---
[[1 Chronicles - 12|<--]] 1 Chronicles - 13 [[1 Chronicles - 14|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[1 Chronicles]]

# 1 Chronicles - 13

David tint conseil avec les chefs de milliers et de centaines, avec tous les princes. [^1] Et David dit à toute l’assemblée d’Israël: Si vous le trouvez bon, et si cela vient de l’Éternel, notre Dieu, envoyons de tous côtés vers nos frères qui restent dans toutes les contrées d’Israël, et aussi vers les sacrificateurs et les Lévites dans les villes où sont leurs banlieues, afin qu’ils se réunissent à nous, [^2] et ramenons auprès de nous l’arche de notre Dieu, car nous ne nous en sommes pas occupés du temps de Saül. [^3] Toute l’assemblée décida de faire ainsi, car la chose parut convenable à tout le peuple. [^4] #2 S 6:1.David assembla tout Israël, depuis le Schichor d’Égypte jusqu’à l’entrée de Hamath, pour faire venir de Kirjath-Jearim l’arche de Dieu. [^5] Et David, avec tout Israël, monta à Baala, à Kirjath-Jearim, qui est à Juda, pour faire monter de là l’arche de Dieu, devant laquelle est invoqué le nom de l’Éternel qui réside entre les chérubins. [^6] Ils mirent sur un char neuf l’arche de Dieu, qu’ils emportèrent de la maison d’Abinadab: Uzza et Achjo conduisaient le char. [^7] David et tout Israël dansaient devant Dieu de toute leur force, en chantant, et en jouant des harpes, des luths, des tambourins, des cymbales et des trompettes. [^8] Lorsqu’ils furent arrivés à l’aire de Kidon, Uzza étendit la main pour saisir l’arche, parce que les bœufs la faisaient pencher. [^9] La colère de l’Éternel s’enflamma contre Uzza, et l’Éternel le frappa parce qu’il avait étendu la main sur l’arche. Uzza mourut là, devant Dieu. [^10] David fut irrité de ce que l’Éternel avait frappé Uzza d’un tel châtiment. Et ce lieu a été appelé jusqu’à ce jour Pérets-Uzza. [^11] David eut peur de Dieu en ce jour-là, et il dit: Comment ferais-je entrer chez moi l’arche de Dieu? [^12] #2 S 6:10.David ne retira pas l’arche chez lui dans la cité de David, et il la fit conduire dans la maison d’Obed-Édom de Gath. [^13] L’arche de Dieu resta trois mois dans la maison d’Obed-Édom, dans sa maison. Et l’Éternel bénit la maison d’Obed-Édom et tout ce qui lui appartenait. [^14] 

[[1 Chronicles - 12|<--]] 1 Chronicles - 13 [[1 Chronicles - 14|-->]]

---
# Notes
