---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 14 - Luis Segond (1910)"
---
[[1 Chronicles - 13|<--]] 1 Chronicles - 14 [[1 Chronicles - 15|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[1 Chronicles]]

# 1 Chronicles - 14

#    
        2 S 5:11.  Hiram, roi de Tyr, envoya des messagers à David, et du bois de cèdre, et des tailleurs de pierres et des charpentiers, pour lui bâtir une maison. [^1] David reconnut que l’Éternel l’affermissait comme roi d’Israël, et que son royaume était haut élevé, à cause de son peuple d’Israël. [^2] David prit encore des femmes à Jérusalem, et il engendra encore des fils et des filles. [^3] #1 Ch 3:5.Voici les noms de ceux qui lui naquirent à Jérusalem: Schammua, Schobab, Nathan, Salomon, [^4] Jibhar, Élischua, Elphéleth, [^5] Noga, Népheg, Japhia, [^6] Élischama, Beéliada et Éliphéleth. [^7] Les Philistins apprirent que David avait été oint pour roi sur tout Israël, et ils montèrent tous à sa recherche. David, qui en fut informé, sortit au-devant d’eux. [^8] Les Philistins arrivèrent, et se répandirent dans la vallée des Rephaïm. [^9] David consulta Dieu, en disant: Monterai-je contre les Philistins, et les livreras-tu entre mes mains? Et l’Éternel lui dit: Monte, et je les livrerai entre tes mains. [^10] Ils montèrent à Baal-Peratsim, où David les battit. Puis il dit: Dieu a dispersé mes ennemis par ma main, comme des eaux qui s’écoulent. C’est pourquoi l’on a donné à ce lieu le nom de Baal-Peratsim. [^11] Ils laissèrent là leurs dieux, qui furent brûlés au feu d’après l’ordre de David. [^12] Les Philistins se répandirent de nouveau dans la vallée. [^13] David consulta encore Dieu. Et Dieu lui dit: Tu ne monteras pas après eux; détourne-toi d’eux, et tu arriveras sur eux vis-à-vis des mûriers. [^14] Quand tu entendras un bruit de pas dans les cimes des mûriers, alors tu sortiras pour combattre, car c’est Dieu qui marche devant toi pour battre l’armée des Philistins. [^15] David fit ce que Dieu lui avait ordonné, et l’armée des Philistins fut battue depuis Gabaon jusqu’à Guézer. [^16] La renommée de David se répandit dans tous les pays, et l’Éternel le rendit redoutable à toutes les nations. [^17] 

[[1 Chronicles - 13|<--]] 1 Chronicles - 14 [[1 Chronicles - 15|-->]]

---
# Notes
