---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 22 - Luis Segond (1910)"
---
[[1 Chronicles - 21|<--]] 1 Chronicles - 22 [[1 Chronicles - 23|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[1 Chronicles]]

# 1 Chronicles - 22

Et David dit: Ici sera la maison de l’Éternel Dieu, et ici sera l’autel des holocaustes pour Israël. [^1] David fit rassembler les étrangers qui étaient dans le pays d’Israël, et il chargea des tailleurs de pierres de préparer des pierres de taille pour la construction de la maison de Dieu. [^2] Il prépara aussi du fer en abondance pour les clous des battants des portes et pour les crampons, de l’airain en quantité telle qu’il n’était pas possible de le peser, [^3] et des bois de cèdre sans nombre, car les Sidoniens et les Tyriens avaient amené à David des bois de cèdre en abondance. [^4] David disait: Mon fils Salomon est jeune et d’un âge faible, et la maison qui sera bâtie à l’Éternel s’élèvera à un haut degré de renommée et de gloire dans tous les pays; c’est pourquoi je veux faire pour lui des préparatifs. Et David fit beaucoup de préparatifs avant sa mort. [^5] David appela Salomon, son fils, et lui ordonna de bâtir une maison à l’Éternel, le Dieu d’Israël. [^6] David dit à Salomon: Mon fils, j’avais l’intention de bâtir une maison au nom de l’Éternel, mon Dieu. [^7] Mais la parole de l’Éternel m’a été ainsi adressée: Tu as versé beaucoup de sang, et tu as fait de grandes guerres; tu ne bâtiras pas une maison à mon nom, #1 Ch 28:3.car tu as versé devant moi beaucoup de sang sur la terre. [^8] Voici, il te naîtra un fils, qui sera un homme de repos, et à qui je donnerai du repos en le délivrant de tous ses ennemis d’alentour; car Salomon sera son nom, et je ferai venir sur Israël la paix et la tranquillité pendant sa vie. [^9] #2 S 7:13. 1 R 5:5.Ce sera lui qui bâtira une maison à mon nom. Il sera pour moi un fils, et je serai pour lui un père; et j’affermirai pour toujours le trône de son royaume en Israël. [^10] Maintenant, mon fils, que l’Éternel soit avec toi, afin que tu prospères et que tu bâtisses la maison de l’Éternel, ton Dieu, comme il l’a déclaré à ton égard! [^11] Veuille seulement l’Éternel t’accorder de la sagesse et de l’intelligence, et te faire régner sur Israël dans l’observation de la loi de l’Éternel, ton Dieu! [^12] Alors tu prospéreras, si tu as soin de mettre en pratique les lois et les ordonnances que l’Éternel a prescrites à Moïse pour Israël. #De 31:7, 8. Jos 1:7.Fortifie-toi et prends courage, ne crains point et ne t’effraie point. [^13] Voici, par mes efforts, j’ai préparé pour la maison de l’Éternel cent mille talents d’or, un million de talents d’argent, et une quantité d’airain et de fer qu’il n’est pas possible de peser, car il y en a en abondance; j’ai aussi préparé du bois et des pierres, et tu en ajouteras encore. [^14] Tu as auprès de toi un grand nombre d’ouvriers, des tailleurs de pierres, et des charpentiers, et des hommes habiles dans toute espèce d’ouvrages. [^15] L’or, l’argent, l’airain et le fer, sont sans nombre. Lève-toi et agis, et que l’Éternel soit avec toi! [^16] David ordonna à tous les chefs d’Israël de venir en aide à Salomon, son fils. [^17] L’Éternel, votre Dieu, n’est-il pas avec vous, et ne vous a-t-il pas donné du repos de tous côtés? Car il a livré entre mes mains les habitants du pays, et le pays est assujetti devant l’Éternel et devant son peuple. [^18] Appliquez maintenant votre cœur et votre âme à chercher l’Éternel, votre Dieu; levez-vous, et bâtissez le sanctuaire de l’Éternel Dieu, afin d’amener l’arche de l’alliance de l’Éternel et les ustensiles consacrés à Dieu dans la maison qui sera bâtie au nom de l’Éternel. [^19] 

[[1 Chronicles - 21|<--]] 1 Chronicles - 22 [[1 Chronicles - 23|-->]]

---
# Notes
