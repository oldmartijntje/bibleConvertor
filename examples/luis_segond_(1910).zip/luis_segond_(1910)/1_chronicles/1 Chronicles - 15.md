---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 15 - Luis Segond (1910)"
---
[[1 Chronicles - 14|<--]] 1 Chronicles - 15 [[1 Chronicles - 16|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[1 Chronicles]]

# 1 Chronicles - 15

David se bâtit des maisons dans la cité de David; il prépara une place à l’arche de Dieu, et dressa pour elle une tente. [^1] Alors David dit: L’arche de Dieu ne doit être portée que par les Lévites, #No 4:15.car l’Éternel les a choisis pour porter l’arche de Dieu et pour en faire le service à toujours. [^2] Et David assembla tout Israël à Jérusalem pour faire monter l’arche de l’Éternel à la place qu’il lui avait préparée. [^3] David #1 Ch 6:1, 2.assembla les fils d’Aaron et les Lévites: [^4] des fils de Kehath, Uriel le chef et ses frères, cent vingt; [^5] des fils de Merari, Asaja le chef et ses frères, deux cent vingt; [^6] des fils de Guerschom, Joël le chef et ses frères, cent trente; [^7] des fils d’Élitsaphan, Schemaeja le chef et ses frères, deux cents; [^8] des fils d’Hébron, Éliel le chef et ses frères, quatre-vingts; [^9] des fils d’Uziel, Amminadab le chef et ses frères, cent douze. [^10] David appela les sacrificateurs Tsadok et Abiathar, et les Lévites Uriel, Asaja, Joël, Schemaeja, Éliel et Amminadab. [^11] Il leur dit: Vous êtes les chefs de famille des Lévites; sanctifiez-vous, vous et vos frères, et faites monter à la place que je lui ai préparée l’arche de l’Éternel, du Dieu d’Israël. [^12] Parce que vous n’y étiez pas la première fois, l’Éternel, notre Dieu, nous a frappés; car nous ne l’avons pas cherché selon la loi. [^13] Les sacrificateurs et les Lévites se sanctifièrent pour faire monter l’arche de l’Éternel, du Dieu d’Israël. [^14] Les fils des Lévites portèrent l’arche de Dieu sur leurs épaules avec des barres, #Ex 25:14. No 4:15; 7:9.comme Moïse l’avait ordonné d’après la parole de l’Éternel. [^15] Et David dit aux chefs des Lévites de disposer leurs frères les chantres avec des instruments de musique, des luths, des harpes et des cymbales, qu’ils devaient faire retentir de sons éclatants en signe de réjouissance. [^16] Les Lévites disposèrent #1 Ch 6:33, 39, 44.Héman, fils de Joël; parmi ses frères, Asaph, fils de Bérékia; et parmi les fils de Merari, leurs frères, Éthan, fils de Kuschaja; [^17] puis avec eux leurs frères du second ordre Zacharie, Ben, Jaaziel, Schemiramoth, Jehiel, Unni, Éliab, Benaja, Maaséja, Matthithia, Éliphelé et Miknéja, et Obed-Édom et Jeïel, les portiers. [^18] Les chantres Héman, Asaph et Éthan avaient des cymbales d’airain, pour les faire retentir. [^19] Zacharie, Aziel, Schemiramoth, Jehiel, Unni, Éliab, Maaséja et Benaja avaient des luths sur alamoth; [^20] et Matthithia, Éliphelé, Miknéja, Obed-Édom, Jeïel et Azazia, avaient des harpes à huit cordes, pour conduire le chant. [^21] Kenania, chef de musique parmi les Lévites, dirigeait la musique, car il était habile. [^22] Bérékia et Elkana étaient portiers de l’arche. [^23] Schebania, Josaphat, Nethaneel, Amasaï, Zacharie, Benaja et Éliézer, les sacrificateurs, sonnaient des trompettes devant l’arche de Dieu. Obed-Édom et Jechija étaient portiers de l’arche. [^24] David, les anciens d’Israël, et les chefs de milliers se mirent en route pour faire monter l’arche de l’alliance de l’Éternel depuis la maison d’Obed-Édom, au milieu des réjouissances. [^25] Ce fut avec l’assistance de Dieu que les Lévites portèrent l’arche de l’alliance de l’Éternel; et l’on sacrifia sept taureaux et sept béliers. [^26] David était revêtu d’un manteau de byssus; il en était de même de tous les Lévites qui portaient l’arche, des chantres, et de Kenania, chef de musique parmi les chantres; et David avait sur lui un éphod de lin. [^27] Tout Israël fit monter l’arche de l’alliance de l’Éternel avec des cris de joie, au son des clairons, des trompettes et des cymbales, et en faisant retentir les luths et les harpes. [^28] #2 S 6:16.Comme l’arche de l’alliance de l’Éternel entrait dans la cité de David, Mical, fille de Saül, regardait par la fenêtre, et voyant le roi David sauter et danser, elle le méprisa dans son cœur. [^29] 

[[1 Chronicles - 14|<--]] 1 Chronicles - 15 [[1 Chronicles - 16|-->]]

---
# Notes
