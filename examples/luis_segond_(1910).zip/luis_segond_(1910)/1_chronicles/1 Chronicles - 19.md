---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 19 - Luis Segond (1910)"
---
[[1 Chronicles - 18|<--]] 1 Chronicles - 19 [[1 Chronicles - 20|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[1 Chronicles]]

# 1 Chronicles - 19

Après cela, Nachasch, roi des fils d’Ammon, mourut, et son fils régna à sa place. [^1] David dit: Je montrerai de la bienveillance à Hanun, fils de Nachasch, car son père en a montré à mon égard. Et David envoya des messagers pour le consoler au sujet de son père. Lorsque les serviteurs de David arrivèrent dans le pays des fils d’Ammon auprès de Hanun, pour le consoler, [^2] les chefs des fils d’Ammon dirent à Hanun: Penses-tu que ce soit pour honorer ton père que David t’envoie des consolateurs? N’est-ce pas pour reconnaître la ville et pour la détruire, et pour explorer le pays, que ses serviteurs sont venus auprès de toi? [^3] Alors Hanun saisit les serviteurs de David, les fit raser, et fit couper leurs habits par le milieu jusqu’au haut des cuisses. Puis il les congédia. [^4] David, que l’on vint informer de ce qui était arrivé à ces hommes, envoya des gens à leur rencontre, car ils étaient dans une grande confusion; et le roi leur fit dire: Restez à Jéricho jusqu’à ce que votre barbe ait repoussé, et revenez ensuite. [^5] Les fils d’Ammon virent qu’ils s’étaient rendus odieux à David, et Hanun et les fils d’Ammon envoyèrent mille talents d’argent pour prendre à leur solde des chars et des cavaliers chez les Syriens de Mésopotamie et chez les Syriens de Maaca et de Tsoba. [^6] Ils prirent à leur solde trente-deux mille chars et le roi de Maaca avec son peuple, lesquels vinrent camper devant Médeba. Les fils d’Ammon se rassemblèrent de leurs villes, et marchèrent au combat. [^7] A cette nouvelle, David envoya contre eux Joab et toute l’armée, les hommes vaillants. [^8] Les fils d’Ammon sortirent, et se rangèrent en bataille à l’entrée de la ville; les rois qui étaient venus prirent position séparément dans la campagne. [^9] Joab vit qu’il avait à combattre par devant et par derrière. Il choisit alors sur toute l’élite d’Israël un corps, qu’il opposa aux Syriens; [^10] et il plaça sous le commandement de son frère Abischaï le reste du peuple, pour faire face aux fils d’Ammon. [^11] Il dit: Si les Syriens sont plus forts que moi, tu viendras à mon secours; et si les fils d’Ammon sont plus forts que toi, j’irai à ton secours. [^12] Sois ferme, et montrons du courage pour notre peuple et pour les villes de notre Dieu, et que l’Éternel fasse ce qui lui semblera bon! [^13] Joab, avec son peuple, s’avança pour attaquer les Syriens, et ils s’enfuirent devant lui. [^14] Et quand les fils d’Ammon virent que les Syriens avaient pris la fuite, ils s’enfuirent aussi devant Abischaï, frère de Joab, et rentrèrent dans la ville. Et Joab revint à Jérusalem. [^15] Les Syriens, voyant qu’ils avaient été battus par Israël, envoyèrent chercher les Syriens qui étaient de l’autre côté du fleuve; et Schophach, chef de l’armée d’Hadarézer, était à leur tête. [^16] On l’annonça à David, qui assembla tout Israël, passa le Jourdain, marcha contre eux, et se prépara à les attaquer. David se rangea en bataille contre les Syriens. Mais les Syriens, après s’être battus avec lui, s’enfuirent devant Israël. [^17] David leur tua les troupes de sept mille chars et quarante mille hommes de pied, et il fit mourir Schophach, chef de l’armée. [^18] Les serviteurs d’Hadarézer, se voyant battus par Israël, firent la paix avec David et lui furent assujettis. Et les Syriens ne voulurent plus secourir les fils d’Ammon. [^19] 

[[1 Chronicles - 18|<--]] 1 Chronicles - 19 [[1 Chronicles - 20|-->]]

---
# Notes
