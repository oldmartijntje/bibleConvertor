---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 18 - Luis Segond (1910)"
---
[[1 Chronicles - 17|<--]] 1 Chronicles - 18 [[1 Chronicles - 19|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[1 Chronicles]]

# 1 Chronicles - 18

Après cela, David battit les Philistins et les humilia, et il enleva de la main des Philistins Gath et les villes de son ressort. [^1] Il battit les Moabites, et les Moabites furent assujettis à David et lui payèrent un tribut. [^2] David battit Hadarézer, roi de Tsoba, vers Hamath, lorsqu’il alla établir sa domination sur le fleuve de l’Euphrate. [^3] David lui prit mille chars, sept mille cavaliers, et vingt mille hommes de pied; il coupa les jarrets à tous les chevaux de trait, et ne conserva que cent attelages. [^4] Les Syriens de Damas vinrent au secours d’Hadarézer, roi de Tsoba, et David battit vingt-deux mille Syriens. [^5] David mit des garnisons dans la Syrie de Damas. Et les Syriens furent assujettis à David, et lui payèrent un tribut. L’Éternel protégeait David partout où il allait. [^6] Et David prit les boucliers d’or qu’avaient les serviteurs d’Hadarézer, et les apporta à Jérusalem. [^7] David prit encore une grande quantité d’airain à Thibchath et à Cun, villes d’Hadarézer. Salomon en fit la mer d’airain, les colonnes et les ustensiles d’airain. [^8] Thohu, roi de Hamath, apprit que David avait battu toute l’armée d’Hadarézer, roi de Tsoba, [^9] et il envoya Hadoram, son fils, vers le roi David, pour le saluer, et pour le féliciter d’avoir attaqué Hadarézer et de l’avoir battu. Car Thohu était en guerre avec Hadarézer. Il envoya aussi toutes sortes de vases d’or, d’argent et d’airain. [^10] Le roi David les consacra à l’Éternel, avec l’argent et l’or qu’il avait pris sur toutes les nations, sur Édom, sur Moab, sur les fils d’Ammon, sur les Philistins et sur Amalek. [^11] Abischaï, fils de Tseruja, battit dans la vallée du sel dix-huit mille Édomites. [^12] Il mit des garnisons dans Édom, et tout Édom fut assujetti à David. L’Éternel protégeait David partout où il allait. [^13] David régna sur tout Israël, et il faisait droit et justice à tout son peuple. [^14] Joab, fils de Tseruja, commandait l’armée; Josaphat, fils d’Achilud, était archiviste; [^15] Tsadok, fils d’Achithub, et Abimélec, fils d’Abiathar, étaient sacrificateurs; Schavscha était secrétaire; [^16] Benaja, fils de Jehojada, était chef des Kéréthiens et des Péléthiens; et les fils de David étaient les premiers auprès du roi. [^17] 

[[1 Chronicles - 17|<--]] 1 Chronicles - 18 [[1 Chronicles - 19|-->]]

---
# Notes
