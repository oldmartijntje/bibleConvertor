---
translation: Luis Segond (1910)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 3 - Luis Segond (1910)"
---
[[1 Chronicles - 2|<--]] 1 Chronicles - 3 [[1 Chronicles - 4|-->]]

Translation: [[bible - Luis Segond (1910)|Luis Segond (1910)]]
Book: [[1 Chronicles]]

# 1 Chronicles - 3

Voici les fils de David, qui #2 S 3:2, etc.lui naquirent à Hébron. Le premier-né, Amnon, d’Achinoam de Jizreel; le second, Daniel, d’Abigaïl de Carmel; [^1] le troisième, Absalom, fils de Maaca, fille de Talmaï, roi de Gueschur; le quatrième, Adonija, fils de Haggith; [^2] le cinquième, Schephatia, d’Abithal; le sixième, Jithream, d’Égla, sa femme. [^3] Ces six lui naquirent à Hébron. Il régna là sept ans et six mois, et il régna trente-trois ans à Jérusalem. [^4] #2 S 5:14, etc.Voici ceux qui lui naquirent à Jérusalem. Schimea, Schobab, Nathan et Salomon, quatre de Bath-Schua, fille d’Ammiel; [^5] Jibhar, Élischama, Éliphéleth, [^6] Noga, Népheg, Japhia, Élischama, [^7] Éliada et Éliphéleth, neuf. [^8] Ce sont là tous les fils de David, outre les fils des concubines. Et Tamar était leur sœur. [^9] Fils de Salomon: #1 R 11:43; 14:31; 15:8, 24.Roboam. Abija, son fils; Asa, son fils; Josaphat, son fils; [^10] #2 R 8:16, 25; 11:2.Joram, son fils; Achazia, son fils; Joas, son fils; [^11] #2 R 12:21; 14:21; 15:7.Amatsia, son fils; Azaria, son fils; Jotham, son fils; [^12] #2 R 15:38; 16:20; 20:21.Achaz, son fils; Ézéchias, son fils; Manassé, son fils; [^13] #2 R 21:18, 26.Amon, son fils; Josias, son fils. [^14] #2 R 23:30, 34.Fils de Josias: le premier-né, Jochanan; le second, Jojakim; le troisième, Sédécias; le quatrième, Schallum. [^15] Fils de Jojakim: #2 R 24:6, 17.Jéconias, son fils; Sédécias, son fils. [^16] #Mt 1:11, 12.Fils de Jéconias: Assir, dont le fils fut Schealthiel, [^17] Malkiram, Pedaja, Schénatsar, Jekamia, Hoschama et Nedabia. [^18] Fils de Pedaja: Zorobabel et Schimeï. Fils de Zorobabel: Meschullam et Hanania; Schelomith, leur sœur; [^19] et Haschuba, Ohel, Bérékia, Hasadia, Juschab-Hésed, cinq. [^20] Fils de Hanania: Pelathia et Ésaïe; les fils de Rephaja, les fils d’Arnan, les fils d’Abdias, les fils de Schecania. [^21] Fils de Schecania: Schemaeja. Fils de Schemaeja: Hattusch, Jigueal, Bariach, Nearia et Schaphath, six. [^22] Fils de Nearia: Éljoénaï, Ézéchias et Azrikam, trois. [^23] Fils d’Éljoénaï: Hodavia, Éliaschib, Pelaja, Akkub, Jochanan, Delaja et Anani, sept. [^24] 

[[1 Chronicles - 2|<--]] 1 Chronicles - 3 [[1 Chronicles - 4|-->]]

---
# Notes
