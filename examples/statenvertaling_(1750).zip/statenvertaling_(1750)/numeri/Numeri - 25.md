---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numeri"
  - "#bible/testament/old"
aliases:
  - "Numeri - 25 - Statenvertaling (1750)"
---
[[Numeri - 24|<--]] Numeri - 25 [[Numeri - 26|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Numeri]]

# Numeri - 25

En Israël verbleef te Sittim, en het volk begon te hoereren met de dochteren der Moabieten. [^1] En zij nodigden het volk tot de slachtofferen harer goden; en het volk at, en boog zich voor haar goden. [^2] Als nu Israël zich koppelde aan Baäl-Peor, ontstak de toorn des HEEREN tegen Israël. [^3] En de HEERE zeide tot Mozes: Neem al de hoofden des volks, en hang ze den HEERE tegen de zon, zo zal de hittigheid van des HEEREN toorn gekeerd worden van Israël. [^4] Toen zeide Mozes tot de rechters van Israël: Een ieder dode zijn mannen, die zich aan Baäl-Peor gekoppeld hebben! [^5] En ziet, een man uit de kinderen Israëls kwam, en bracht een Midianietin tot zijn broederen voor de ogen van Mozes, en voor de ogen van de ganse vergadering der kinderen Israëls, toen zij weenden voor de deur van de tent der samenkomst. [^6] Toen Pinehas, de zoon van Eleazar, den zoon van Aäron, den priester, dat zag, zo stond hij op uit het midden der vergadering, en nam een spies in zijn hand; [^7] En hij ging den Israëlietischen man na in den hoerenwinkel, en doorstak hen beiden, den Israëlietischen man en de vrouw, door hun buik. Toen werd de plaag van over de kinderen Israëls opgehouden. [^8] Degenen nu, die aan de plaag stierven, waren vier en twintig duizend. [^9] Toen sprak de HEERE tot Mozes, zeggende: [^10] Pinehas, de zoon van Eleazar, den zoon van Aäron, den priester, heeft Mijn grimmigheid van over de kinderen Israëls afgewend, dewijl hij Mijn ijver geijverd heeft in het midden derzelve, zodat Ik de kinderen Israëls in Mijn ijver niet vernield heb. [^11] Daarom spreek: Zie, Ik geef hem Mijn verbond des vredes. [^12] En hij zal hebben, en zijn zaad na hem, het verbond des eeuwigen priesterdoms, daarom dat hij voor zijn God geijverd, en verzoening gedaan heeft voor de kinderen Israëls. [^13] De naam nu des verslagenen Israëlietischen mans, die verslagen was met de Midianietin, was Zimri, de zoon van Salu, een overste van een vaderlijk huis der Simeonieten. [^14] En de naam der verslagene Midianietische vrouw was Kozbi, een dochter van Zur, die een hoofd was der volken van een vaderlijk huis onder de Midianieten. [^15] Verder sprak de HEERE tot Mozes, zeggende: [^16] Handel vijandelijk met de Midianieten, en versla hen; [^17] Want zij hebben vijandelijk tegen ulieden gehandeld door hun listen, die zij listig tegen u bedacht hebben in de zaak van Peor, en in de zaak van Kozbi, de dochter van den overste der Midianieten, hun zuster, die verslagen is, ten dage der plaag, om de zaak van Peor. [^18] 

[[Numeri - 24|<--]] Numeri - 25 [[Numeri - 26|-->]]

---
# Notes
