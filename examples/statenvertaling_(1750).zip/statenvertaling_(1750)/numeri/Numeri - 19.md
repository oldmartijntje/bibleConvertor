---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numeri"
  - "#bible/testament/old"
aliases:
  - "Numeri - 19 - Statenvertaling (1750)"
---
[[Numeri - 18|<--]] Numeri - 19 [[Numeri - 20|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Numeri]]

# Numeri - 19

Wijders sprak de HEERE tot Mozes en tot Aäron, zeggende: [^1] Dit is de inzetting van de wet, die de HEERE geboden heeft, zeggende: Spreek tot de kinderen Israëls, dat zij tot u brengen een rode volkomene vaars, in welke geen gebrek is, op welke geen juk gekomen is. [^2] En gij zult die geven aan Eleazar, den priester; en hij zal ze uitbrengen tot buiten het leger, en men zal haar voor zijn aangezicht slachten. [^3] En Eleazar, de priester, zal van haar bloed met zijn vinger nemen, en hij zal van haar bloed recht tegenover de tent der samenkomst zevenmaal sprengen. [^4] Voorts zal men deze vaars voor zijn ogen verbranden; haar vel, en haar vlees, en haar bloed, met haar mest, zal men verbranden. [^5] En de priester zal nemen cederhout, en hysop, en scharlaken, en werpen ze in het midden van den brand dezer vaars. [^6] Dan zal de priester zijn klederen wassen, en zijn vlees met water baden, en daarna in het leger gaan; en de priester zal onrein zijn tot aan den avond. [^7] Ook die haar verbrand heeft, zal zijn klederen met water wassen, en zijn vlees met water baden, en onrein zijn tot aan den avond. [^8] En een rein man zal de as dezer vaars verzamelen, en buiten het leger in een reine plaats wegleggen; en het zal zijn ter bewaring voor de vergadering van de kinderen Israëls, tot het water der afzondering; het is ontzondiging. [^9] En die de as dezer vaars verzameld heeft, zal zijn klederen wassen, en onrein zijn tot aan den avond. Dit zal den kinderen Israëls, en den vreemdeling, die in het midden van hen als vreemdeling verkeert, tot een eeuwige inzetting zijn. [^10] Wie een dode, enig dood lichaam van een mens, aanroert, die zal zeven dagen onrein zijn. [^11] Op den derden dag zal hij zich daarmede ontzondigen, zo zal hij op den zevenden dag rein zijn; maar indien hij zich op den derden dag niet ontzondigt, zo zal hij op den zevenden dag niet rein zijn. [^12] Al wie een dode, het dode lichaam eens mensen, die gestorven zal zijn, aanroert, en zich niet ontzondigd zal hebben, die verontreinigt den tabernakel des HEEREN; daarom zal die ziel uitgeroeid worden uit Israël; omdat het water der afzondering op hem niet gesprengd is, zal hij onrein zijn; zijn onreinigheid is nog in hem. [^13] Dit is de wet, wanneer een mens zal gestorven zijn in een tent: al wie in die tent ingaat, en al wie in die tent is, zal zeven dagen onrein zijn. [^14] Ook alle open gereedschap, waarop geen deksel gebonden is, dat is onrein. [^15] En al wie in het open veld een, die met het zwaard verslagen is, of een dode, of het gebeente eens mensen, of een graf zal aangeroerd hebben, zal zeven dagen onrein zijn. [^16] Voor een onreine nu zullen zij nemen van het stof des brands der ontzondiging, en daarop levend water doen in een vat. [^17] En een rein man zal hysop nemen, en in dat water dopen, en sprengen het aan die tent, en op al het gereedschap, en aan de zielen, die daar geweest zijn; insgelijks aan dengene, die een gebeente, of een verslagene, of een dode, of een graf aangeroerd heeft. [^18] En de reine zal den onreine op den derden dag, en op den zevenden dag besprengen; en op den zevenden dag zal hij hem ontzondigen; en hij zal zijn klederen wassen, en zich met water baden, en op den avond rein zijn. [^19] Wie daarentegen onrein zal zijn, en zich niet zal ontzondigen, die ziel zal uit het midden der gemeente uitgeroeid worden; want hij heeft het heiligdom des HEEREN verontreinigd, het water der afzondering is op hem niet gesprengd, hij is onrein. [^20] Dit zal hunlieden zijn tot een eeuwige inzetting. En die het water der afzondering sprengt, zal zijn klederen wassen; ook wie het water der afzondering aanroert, die zal onrein zijn tot aan den avond. [^21] Ja, al wat die onreine aangeroerd zal hebben, zal onrein zijn; en de ziel, die dat aangeroerd zal hebben, zal onrein zijn tot aan den avond. [^22] 

[[Numeri - 18|<--]] Numeri - 19 [[Numeri - 20|-->]]

---
# Notes
