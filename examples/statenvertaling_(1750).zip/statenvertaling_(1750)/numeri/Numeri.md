---
translation: Statenvertaling (1750)
aliases:
  - "Numeri - Statenvertaling (1750)"
tags:
  - "#bible/type/book"
  - "#bible/book/numeri"
  - "#bible/testament/old"
---
[[Leviticus|<--]] Numeri [[Deuteronomium|-->]]

# Numeri - Statenvertaling (1750)

The Numeri book has 36 chapters. It is part of the old testament.

## Chapters

- Numeri [[Numeri - 1|chapter 1]]
- Numeri [[Numeri - 2|chapter 2]]
- Numeri [[Numeri - 3|chapter 3]]
- Numeri [[Numeri - 4|chapter 4]]
- Numeri [[Numeri - 5|chapter 5]]
- Numeri [[Numeri - 6|chapter 6]]
- Numeri [[Numeri - 7|chapter 7]]
- Numeri [[Numeri - 8|chapter 8]]
- Numeri [[Numeri - 9|chapter 9]]
- Numeri [[Numeri - 10|chapter 10]]
- Numeri [[Numeri - 11|chapter 11]]
- Numeri [[Numeri - 12|chapter 12]]
- Numeri [[Numeri - 13|chapter 13]]
- Numeri [[Numeri - 14|chapter 14]]
- Numeri [[Numeri - 15|chapter 15]]
- Numeri [[Numeri - 16|chapter 16]]
- Numeri [[Numeri - 17|chapter 17]]
- Numeri [[Numeri - 18|chapter 18]]
- Numeri [[Numeri - 19|chapter 19]]
- Numeri [[Numeri - 20|chapter 20]]
- Numeri [[Numeri - 21|chapter 21]]
- Numeri [[Numeri - 22|chapter 22]]
- Numeri [[Numeri - 23|chapter 23]]
- Numeri [[Numeri - 24|chapter 24]]
- Numeri [[Numeri - 25|chapter 25]]
- Numeri [[Numeri - 26|chapter 26]]
- Numeri [[Numeri - 27|chapter 27]]
- Numeri [[Numeri - 28|chapter 28]]
- Numeri [[Numeri - 29|chapter 29]]
- Numeri [[Numeri - 30|chapter 30]]
- Numeri [[Numeri - 31|chapter 31]]
- Numeri [[Numeri - 32|chapter 32]]
- Numeri [[Numeri - 33|chapter 33]]
- Numeri [[Numeri - 34|chapter 34]]
- Numeri [[Numeri - 35|chapter 35]]
- Numeri [[Numeri - 36|chapter 36]]

[[Leviticus|<--]] Numeri [[Deuteronomium|-->]]

---
# Notes
