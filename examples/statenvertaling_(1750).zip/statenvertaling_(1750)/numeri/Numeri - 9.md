---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numeri"
  - "#bible/testament/old"
aliases:
  - "Numeri - 9 - Statenvertaling (1750)"
---
[[Numeri - 8|<--]] Numeri - 9 [[Numeri - 10|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Numeri]]

# Numeri - 9

En de HEERE sprak tot Mozes in de woestijn van Sinaï, in het tweede jaar, nadat zij uit Egypteland uitgetogen waren, in de eerste maand, zeggende: [^1] Dat de kinderen Israëls het pascha houden zouden, op zijn gezetten tijd; [^2] Op den veertienden dag in deze maand, tussen de twee avonden zult gij dat houden, op zijn gezetten tijd; naar al zijn inzettingen, en naar al zijn rechten zult gij dat houden. [^3] Mozes dan sprak tot de kinderen Israëls, dat zij het pascha zouden houden. [^4] En zij hielden het pascha op den veertienden dag der eerste maand, tussen de twee avonden, in de woestijn van Sinaï; naar alles, wat de HEERE Mozes geboden had, alzo deden de kinderen Israëls. [^5] Toen waren er lieden geweest, die over het dode lichaam eens mensen onrein waren, en op denzelven dag het pascha niet hadden kunnen houden; daarom naderden zij voor het aangezicht van Mozes, en voor het aangezicht van Aäron op dienzelven dag. [^6] En diezelve lieden zeiden tot hem: Wij zijn onrein over het dode lichaam eens mensen; waarom zouden wij verkort worden, dat wij de offerande des HEEREN op zijn gezetten tijd niet zouden offeren, in het midden van de kinderen Israëls? [^7] En Mozes zeide tot hen: Blijft staande, dat ik hoor, wat de HEERE u gebieden zal. [^8] Toen sprak de HEERE tot Mozes, zeggende: [^9] Spreek tot de kinderen Israëls, zeggende: Wanneer iemand onder u, of onder uw geslachten, over een dood lichaam onrein, of op een verren weg zal zijn, hij zal dan nog den HEERE het pascha houden. [^10] In de tweede maand, op den veertienden dag, tussen de twee avonden, zullen zij dat houden; met ongezuurde broden en bittere saus zullen zij dat eten. [^11] Zij zullen daarvan niet overlaten tot den morgen, en zullen daaraan geen been breken; naar alle inzetting van het pascha zullen zij dat houden. [^12] Als een man, die rein is, en op den weg niet is, en nalaten zal het pascha te houden, zo zal diezelve ziel uit haar volken uitgeroeid worden; want hij heeft de offerande des HEEREN op zijn gezetten tijd niet geofferd, diezelve man zal zijn zonde dragen. [^13] En wanneer een vreemdeling bij u als vreemdeling verkeert, en hij het pascha den HEERE ook houden zal, naar de inzetting van het pascha, en naar zijn wijze, alzo zal hij het houden; het zal enerlei inzetting voor ulieden zijn, beiden den vreemdeling en den inboorling des lands. [^14] En op den dag van het oprichten des tabernakels bedekte de wolk den tabernakel, op de tent der getuigenis; en in den avond was over den tabernakel als een gedaante des vuurs, tot aan den morgen. [^15] Alzo geschiedde het geduriglijk; de wolk bedekte denzelven, en des nachts was er een gedaante des vuurs. [^16] Maar nadat de wolk opgeheven werd van boven de tent, zo verreisden ook daarna de kinderen Israëls; en in de plaats, waar de wolk bleef, daar legerden zich de kinderen Israëls. [^17] Naar den mond des HEEREN, verreisden de kinderen Israëls, en naar des HEEREN mond legerden zij zich; al de dagen, in dewelke de wolk over den tabernakel bleef, legerden zij zich. [^18] En als de wolk vele dagen over den tabernakel verbleef, zo namen de kinderen Israëls de wacht des HEEREN waar, en verreisden niet. [^19] Als het nu was, dat de wolk weinige dagen op den tabernakel was, naar den mond des HEEREN legerden zij zich, en naar den mond des HEEREN verreisden zij. [^20] Maar was het, dat de wolk van den avond tot den morgen daar was, en de wolk in den morgen opgeheven werd, zo verreisden zij; of des daags, of des nachts, als de wolk opgeheven werd, zo verreisden zij. [^21] Of als de wolk twee dagen, of een maand, of vele dagen vertoog op den tabernakel, blijvende daarop, zo legerden zich de kinderen Israëls, en verreisden niet; en als zij verheven werd, verreisden zij. [^22] Naar den mond des HEEREN legerden zij zich, en naar den mond des HEEREN verreisden zij; zij namen de wacht des HEEREN waar, naar den mond des HEEREN, door de hand van Mozes. [^23] 

[[Numeri - 8|<--]] Numeri - 9 [[Numeri - 10|-->]]

---
# Notes
