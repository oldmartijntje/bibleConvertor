---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numeri"
  - "#bible/testament/old"
aliases:
  - "Numeri - 17 - Statenvertaling (1750)"
---
[[Numeri - 16|<--]] Numeri - 17 [[Numeri - 18|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Numeri]]

# Numeri - 17

Toen sprak de HEERE tot Mozes, zeggende: [^1] Spreek tot de kinderen Israëls, en neem van hen voor elk vaderlijk huis een staf, van al hun oversten, naar het huis hunner vaderen, twaalf staven; eens iegelijken naam zult gij schrijven op zijn staf. [^2] Doch Aärons naam zult gij schrijven op den staf van Levi; want een staf zal er zijn voor het hoofd van het huis hunner vaderen. [^3] En gij zult ze wegleggen in de tent der samenkomst, voor de getuigenis, waarheen Ik met ulieden samenkomen zal. [^4] En het zal geschieden, dat de staf des mans, welke Ik zal verkoren hebben, zal bloeien; en Ik zal stillen de murmureringen van de kinderen Israëls tegen Mij, welke zij tegen ulieden murmureerden. [^5] Mozes dan sprak tot de kinderen Israëls, en al hun oversten gaven aan hem een staf, voor elken overste een staf, naar het huis hunner vaderen, twaalf staven; Aärons staf was ook onder hun staven. [^6] En Mozes legde deze staven weg, voor het aangezicht des HEEREN, in de tent der getuigenis. [^7] Het geschiedde nu des anderen daags, dat Mozes in de tent der getuigenis inging; en ziet, Aärons staf, voor het huis van Levi, bloeide; want hij bracht bloeisel voort, en bloesemde bloesem, en droeg amandelen. [^8] Toen bracht Mozes al deze staven uit, van voor het aangezicht des HEEREN, tot al de kinderen Israëls; en zij zagen het, en namen elk zijn staf. [^9] Toen zeide de HEERE tot Mozes: Breng de staf van Aäron weder voor de getuigenis, in bewaring, tot een teken voor de wederspannige kinderen; alzo zult gij een einde maken van hun murmureringen tegen Mij, dat zij niet sterven. [^10] En Mozes deed het; gelijk als de HEERE hem geboden had, alzo deed hij. [^11] Toen spraken de kinderen Israëls tot Mozes, zeggende: Zie, wij geven den geest, wij vergaan, wij allen vergaan! [^12] Al wie enigszins nadert tot den tabernakel des HEEREN, zal sterven; zullen wij dan den geest gevende verdaan worden? [^13] 

[[Numeri - 16|<--]] Numeri - 17 [[Numeri - 18|-->]]

---
# Notes
