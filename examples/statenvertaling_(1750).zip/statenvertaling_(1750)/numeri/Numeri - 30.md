---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numeri"
  - "#bible/testament/old"
aliases:
  - "Numeri - 30 - Statenvertaling (1750)"
---
[[Numeri - 29|<--]] Numeri - 30 [[Numeri - 31|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Numeri]]

# Numeri - 30

En Mozes sprak tot de hoofden der stammen van de kinderen Israëls, zeggende: Dit is de zaak, die de HEERE geboden heeft: [^1] Wanneer een man den HEERE een gelofte zal beloofd, of een eed zal gezworen hebben, zijn ziel met een verbintenis verbindende, zijn woord zal hij niet ontheiligen; naar alles, wat uit zijn mond gegaan is, zal hij doen. [^2] Maar als een vrouw den HEERE een gelofte zal beloofd hebben, en zich met een verbintenis in het huis haars vaders in haar jonkheid zal verbonden hebben; [^3] En haar vader haar gelofte, en haar verbintenis, waarmede zij haar ziel verbonden heeft, zal horen, en haar vader tegen haar zal stilzwijgen, zo zullen al haar geloften bestaan, en alle verbintenis, waarmede zij haar ziel verbonden heeft, zal bestaan. [^4] Maar indien haar vader dat zal breken, ten dage als hij het hoort, al haar geloften, en haar verbintenissen, waarmede zij haar ziel verbonden heeft, zullen niet bestaan; maar de HEERE zal het haar vergeven; want haar vader heeft ze haar doen breken. [^5] Doch indien zij immers een man heeft, en haar geloften op haar zijn, of de uitspraak harer lippen, waarmede zij haar ziel verbonden heeft; [^6] En haar man dat zal horen, en ten dage als hij het hoort, tegen haar zal stilzwijgen, zo zullen haar geloften bestaan, en haar verbintenissen, waarmede zij haar ziel verbonden heeft, zullen bestaan. [^7] Maar indien haar man ten dage, als hij het hoorde, dat zal breken, en haar gelofte, die op haar was, zal te niet maken, mitsgaders de uitspraak harer lippen, waarmede zij haar ziel verbonden heeft, zo zal het de HEERE haar vergeven. [^8] Aangaande de gelofte ener weduwe, of ener verstotene: alles, waarmede zij haar ziel verbonden heeft, zal over haar bestaan. [^9] Maar indien zij ten huize haars mans gelofte gedaan heeft, of met een eed door verbintenis haar ziel verbonden heeft; [^10] En haar man dat gehoord, en tegen haar stil zal gezwegen hebben, dat niet brekende; zo zullen al haar geloften bestaan, mitsgaders alle verbintenis, waarmede zij haar ziel verbonden heeft, zal bestaan. [^11] Maar indien haar man die dingen ganselijk te niet maakt, ten dage als hij het hoort, niets van al wat uit haar lippen gegaan is, van haar gelofte, en van de verbintenis harer ziel, zal bestaan; haar man heeft ze te niet gemaakt, en de HEERE zal het haar vergeven. [^12] Alle gelofte, en allen eed der verbintenis, om de ziel te verootmoedigen, die zal haar man bevestigen, of die zal haar man te niet maken. [^13] Maar zo haar man tegen haar van dag tot dag ganselijk stilzwijgt, zo bevestigt hij al haar geloften, of al haar verbintenissen, dewelke op haar zijn; hij heeft ze bevestigd, omdat hij tegen haar stilgezwegen heeft, ten dage als hij het hoorde. [^14] Doch zo hij ze ganselijk te niet maken zal, nadat hij het gehoord zal hebben, zo zal hij haar ongerechtigheid dragen. [^15] Dat zijn de inzettingen, die de HEERE Mozes geboden heeft, tussen een man en zijn huisvrouw, tussen een vader en zijn dochter, zijnde in haar jonkheid, ten huize haars vaders. [^16] 

[[Numeri - 29|<--]] Numeri - 30 [[Numeri - 31|-->]]

---
# Notes
