---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numeri"
  - "#bible/testament/old"
aliases:
  - "Numeri - 12 - Statenvertaling (1750)"
---
[[Numeri - 11|<--]] Numeri - 12 [[Numeri - 13|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Numeri]]

# Numeri - 12

Mirjam nu sprak, en Aäron, tegen Mozes, ter oorzake der vrouw, der Cuschietische, die hij genomen had; want hij had een Cuschietische ter vrouw genomen. [^1] En zij zeiden: Heeft dan de HEERE maar alleen door Mozes gesproken? Heeft Hij ook niet door ons gesproken? En de HEERE hoorde het! [^2] Doch de man Mozes was zeer zachtmoedig, meer dan alle mensen, die op den aardbodem waren. [^3] Toen sprak de HEERE haastelijk tot Mozes, en tot Aäron, en tot Mirjam: Gij drie, komt uit tot de tent der samenkomst! En zij drie kwamen uit. [^4] Toen kwam de HEERE af in de wolkkolom, en stond aan de deur der tent; daarna riep Hij Aäron en Mirjam; en zij beiden kwamen uit. [^5] En Hij zeide: Hoort nu Mijn woorden! Zo er een profeet onder u is, Ik, de HEERE, zal door een gezicht Mij aan hem bekend maken, door een droom zal Ik met hem spreken. [^6] Alzo is Mijn knecht Mozes niet, die in Mijn ganse huis getrouw is. [^7] Van mond tot mond spreek Ik met hem, en door aanzien, en niet door duistere woorden; en de gelijkenis des HEEREN aanschouwt hij; waarom dan hebt gijlieden niet gevreesd tegen Mijn knecht, tegen Mozes, te spreken? [^8] Zo ontstak des HEEREN toorn tegen hen, en Hij ging weg. [^9] En de wolk week van boven de tent; en ziet, Mirjam was melaats, wit als de sneeuw. En Aäron zag Mirjam aan, en ziet, zij was melaats. [^10] Daarom zeide Aäron tot Mozes: Och, mijn heer! leg toch niet op ons de zonde, waarmede wij zottelijk gedaan, en waarmede wij gezondigd hebben! [^11] Laat zij toch niet zijn als een dode, van wiens vlees, als hij uit zijns moeders lijf uitgaat, de helft wel verteerd is! [^12] Mozes dan riep tot den HEERE, zeggende: O God! heel haar toch! [^13] En de HEERE zeide tot Mozes: Zo haar vader smadelijk in haar aangezicht gespogen had, zou zij niet zeven dagen beschaamd zijn? Laat haar zeven dagen buiten het leger gesloten, en daarna aangenomen worden! [^14] Zo werd Mirjam buiten het leger zeven dagen gesloten; en het volk verreisde niet, totdat Mirjam aangenomen werd. [^15] Maar daarna verreisde het volk van Hazeroth, en zij legerden zich in de woestijn van Paran. [^16] 

[[Numeri - 11|<--]] Numeri - 12 [[Numeri - 13|-->]]

---
# Notes
