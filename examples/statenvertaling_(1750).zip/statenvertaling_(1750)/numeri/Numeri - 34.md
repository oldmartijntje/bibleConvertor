---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numeri"
  - "#bible/testament/old"
aliases:
  - "Numeri - 34 - Statenvertaling (1750)"
---
[[Numeri - 33|<--]] Numeri - 34 [[Numeri - 35|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Numeri]]

# Numeri - 34

Voorts sprak de HEERE tot Mozes, zeggende: [^1] Gebied den kinderen Israëls, en zeg tot hen: Wanneer gij in het land Kanaän ingaat, zo zal dit land zijn, dat u ter erfenis vallen zal, het land Kanaän, naar zijn landpalen. [^2] De zuiderhoek nu zal u zijn van de woestijn Zin, aan de zijden van Edom; en de zuider landpale zal u zijn van het einde der Zoutzee tegen het oosten; [^3] En deze landpale zal u omgaan van het zuiden naar den opgang van Akrabbim, en doorgaan naar Zin; en haar uitgangen zullen zijn, van het zuiden naar Kades-Barnea; en zij zal uitgaan naar Hazar-Addar, en doorgaan naar Azmon. [^4] Voorts zal deze landpale omgaan van Azmon naar de rivier van Egypte, en haar uitgangen zullen zijn naar de zee. [^5] Aangaande de landpale van het westen, daar zal u de grote zee de landpale zijn; dit zal uw landpale van het westen zijn. [^6] Voorts zal u de landpale van het noorden deze zijn; van de grote zee af zult gij u den berg Hor aftekenen. [^7] Van den berg Hor zult gij aftekenen tot daar men komt te Hamath; en de uitgangen dezer landpale zullen zijn naar Zedad. [^8] En deze landpale zal uitgaan naar Zifron, en haar uitgangen zullen zijn te Hazar-Enan; dit zal u de noorder landpale zijn. [^9] Voorts zult gij u tot een landpale tegen het oosten aftekenen van Hazar-Enan naar Sefam. [^10] En deze landpale zal afgaan van Sefam naar Ribla, tegen het oosten van Ain; daarna zal deze landpale afgaan en strekken langs den oever van de zee Cinnereth oostwaarts. [^11] Voorts zal deze landpale afgaan langs de Jordaan, en haar uitgangen zullen zijn aan de Zoutzee. Dit zal u zijn het land naar zijn landpalen rondom. [^12] En Mozes gebood den kinderen Israëls, zeggende: Dit is het land, dat gij door het lot ten erve innemen zult, hetwelk de HEERE aan de negen stammen en den halven stam van Manasse te geven geboden heeft. [^13] Want de stam van de kinderen der Rubenieten, naar het huis hunner vaderen, en de stam van de kinderen der Gadieten, naar het huis hunner vaderen, hebben ontvangen; mitsgaders de halve stam van Manasse heeft zijn erfenis ontvangen. [^14] Twee stammen en een halve stam hebben hun erfenis ontvangen aan deze zijde van de Jordaan, van Jericho oostwaarts tegen den opgang. [^15] Voorts sprak de HEERE tot Mozes, zeggende: [^16] Dit zijn de namen der mannen, die ulieden het land ten erve zullen uitdelen: Eleazar, de priester, en Jozua, de zoon van Nun. [^17] Daartoe zult gij uit elken stam een overste nemen, om het land ten erve uit te delen. [^18] En dit zijn de namen dezer mannen: van de stam van Juda, Kaleb, de zoon van Jefunne; [^19] En van den stam der kinderen van Simeon, Semuël, zoon van Ammihud; [^20] Van den stam van Benjamin, Elidad, zoon van Chislon; [^21] En van den stam der kinderen van Dan, de overste Bukki, zoon van Jogli; [^22] Van de kinderen van Jozef: van den stam der kinderen van Manasse, de overste Hanniël, zoon van Efod; [^23] En van den stam der kinderen van Efraïm, de overste Kemuël, zoon van Siftan; [^24] En van den stam der kinderen van Zebulon, de overste Elizafan, zoon van Parnach; [^25] En van den stam der kinderen van Issaschar, de overste Paltiël, zoon van Azzan; [^26] En van den stam der kinderen van Aser, de overste Achihud, zoon van Selomi; [^27] En van den stam der kinderen van Nafthali, de overste Pedaël, zoon van Ammihud. [^28] Dit zijn ze, dien de HEERE geboden heeft, den kinderen Israëls de erfenissen uit te delen, in het land Kanaän. [^29] 

[[Numeri - 33|<--]] Numeri - 34 [[Numeri - 35|-->]]

---
# Notes
