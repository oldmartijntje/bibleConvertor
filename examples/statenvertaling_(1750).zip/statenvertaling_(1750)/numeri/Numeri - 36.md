---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numeri"
  - "#bible/testament/old"
aliases:
  - "Numeri - 36 - Statenvertaling (1750)"
---
[[Numeri - 35|<--]] Numeri - 36

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Numeri]]

# Numeri - 36

En de hoofden der vaderen van het geslacht der kinderen van Gilead, den zoon van Machir, den zoon van Manasse, uit de geslachten der kinderen van Jozef, traden toe, en spraken voor het aangezicht van Mozes, en voor het aangezicht der oversten, hoofden van de vaderen der kinderen Israëls. [^1] En zeiden: De HEERE heeft mijn heer geboden, dat land door het lot aan de kinderen Israëls in erfenis te geven; en mijn heer is door den HEERE geboden, de erfenis van onzen broeder Zelafead te geven aan zijn dochteren. [^2] Wanneer zij een van de zonen der andere stammen van de kinderen Israëls tot vrouwen zouden worden, zo zou haar erfenis van de erfenis onzer vaderen afgetrokken worden, en toegedaan tot de erfenis van dien stam, aan welken zij geworden zouden; alzo zou van het lot onzer erfenis worden afgetrokken. [^3] Als ook de kinderen Israëls een jubeljaar zullen hebben, zo zou haar erfenis toegedaan zijn tot de erfenis van dien stam, aan welken zij zouden geworden zijn; alzo zou haar erfenis van de erfenis van den stam onzer vaderen afgetrokken worden. [^4] Toen gebood Mozes den kinderen Israëls, naar des HEEREN mond, zeggende: De stam der kinderen van Jozef spreekt recht. [^5] Dit is het woord, dat de HEERE van de dochteren van Zelafead geboden heeft, zeggende: Laat zij dien tot vrouwen worden, die in haar ogen goed zal zijn; alleenlijk, dat zij aan het geslacht van haars vaders stam tot vrouwen worden. [^6] Zo zal de erfenis van de kinderen Israëls niet omgewend worden van stam tot stam; want de kinderen Israëls zullen aanhangen, een ieder aan de erfenis van den stam zijner vaderen. [^7] Voorts zal elke dochter, die een erfenis erft, van de stammen der kinderen Israëls, ter vrouw worden aan een van het geslacht van den stam haars vaders; opdat de kinderen Israëls erfelijk bezitten, een ieder de erfenis zijner vaderen. [^8] Zo zal de erfenis niet omgewend worden van den enen stam tot den anderen; want de stammen der kinderen Israëls zullen aanhangen, een ieder aan zijn erfenis. [^9] Gelijk als de HEERE Mozes geboden had, alzo deden de dochteren van Zelafead; [^10] Want Machla, Thirza, en Hogla, en Milka, en Noha, dochteren van Zelafead, zijn den zonen harer ooms tot vrouwen geworden. [^11] Onder de geslachten van de kinderen van Manasse, den zoon van Jozef, zijn zij tot vrouwen geworden; alzo bleef haar erfenis aan den stam van het geslacht haars vaders. [^12] Dat zijn de geboden en de rechten, die de HEERE door de dienst van Mozes aan de kinderen Israëls geboden heeft, in de vlakke velden der Moabieten, aan de Jordaan van Jericho. [^13] 

[[Numeri - 35|<--]] Numeri - 36

---
# Notes
