---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numeri"
  - "#bible/testament/old"
aliases:
  - "Numeri - 24 - Statenvertaling (1750)"
---
[[Numeri - 23|<--]] Numeri - 24 [[Numeri - 25|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Numeri]]

# Numeri - 24

Toen Bileam zag, dat het goed was in de ogen des HEEREN, dat hij Israël zegende, zo ging hij ditmaal niet heen, gelijk meermalen, tot de toverijen; maar hij stelde zijn aangezicht naar de woestijn. [^1] Als Bileam zijn ogen ophief, en Israël zag, wonende naar zijn stammen, zo was de Geest van God op hem. [^2] En hij hief zijn spreuk op, en zeide: Bileam, de zoon van Beor, spreekt, en de man, wien de ogen geopend zijn, spreekt! [^3] De hoorder der redenen Gods spreekt, die het gezicht des Almachtigen ziet; die verrukt wordt, en wien de ogen ontdekt worden! [^4] Hoe goed zijn uw tenten, Jakob! uw woningen, Israël! [^5] Gelijk de beken breiden zij zich uit, als de hoven aan de rivieren; de HEERE heeft ze geplant, als de sandelbomen, als de cederbomen aan het water. [^6] Er zal water uit zijn emmeren vloeien, en zijn zaad zal in vele wateren zijn; en zijn koning zal boven Agag verheven worden, en zijn koninkrijk zal verhoogd worden. [^7] God heeft hem uit Egypte uitgevoerd; zijn krachten zijn als van een eenhoorn; hij zal de heidenen, zijn vijanden, verteren, en hun gebeente breken, en met zijn pijlen doorschieten. [^8] Hij heeft zich gekromd, hij heeft zich nedergelegd, gelijk een leeuw, en als een oude leeuw; wie zal hem doen opstaan? Zo wie u zegent, die zij gezegend, en vervloekt zij, wie u vervloekt! [^9] Toen ontstak de toorn van Balak tegen Bileam, en hij sloeg zijn handen samen; en Balak zeide tot Bileam: Ik heb u geroepen, om mijn vijanden te vloeken; maar zie, gij hebt hen nu driemaal gedurig gezegend! [^10] En nu, pak u weg naar uw plaats! Ik had gezegd, dat ik u hoog vereren zou; maar zie, de HEERE heeft die eer van u geweerd! [^11] Toen zeide Bileam tot Balak: Heb ik ook niet tot uw boden, die gij tot mij gezonden hebt, gesproken, zeggende: [^12] Wanneer mij Balak zijn huis vol zilver en goud gave, zo kan ik het bevel des HEEREN niet overtreden, doende goed of kwaad uit mijn eigen hart; wat de HEERE spreken zal, dat zal ik spreken. [^13] En nu, zie, ik ga tot mijn volk; kom, ik zal u raad geven, en zeggen wat dit volk uw volk doen zal in de laatste dagen. [^14] Toen hief hij zijn spreuk op, en zeide: Bileam, de zoon van Beor, spreekt, en die man, wien de ogen geopend zijn, spreekt! [^15] De hoorder der redenen Gods spreekt, en die de wetenschap des Allerhoogsten weet; die het gezicht des Almachtigen ziet, die verrukt wordt, en wien de ogen ontdekt worden. [^16] Ik zal hem zien, maar nu niet; ik zal hem aanschouwen, maar niet nabij. Er zal een ster voortgaan uit Jakob, en er zal een scepter uit Israël opkomen; die zal de palen der Moabieten verslaan, en zal al de kinderen van Seth verstoren. [^17] En Edom zal een erfelijke bezitting zijn; en Seïr zal zijn vijanden een erfelijke bezitting zijn; doch Israël zal kracht doen. [^18] En er zal een uit Jakob heersen, en hij zal de overigen uit de steden ombrengen. [^19] Toen hij de Amalekieten zag, zo hief hij zijn spreuk op, en zeide: Amalek is de eersteling der heidenen; maar zijn uiterste is ten verderve! [^20] Toen hij de Kenieten zag, zo hief hij zijn spreuk op, en zeide: Uw woning is vast, en gij hebt uw nest in een steenrots gelegd. [^21] Evenwel zal Kaïn verteerd worden, totdat u Assur gevankelijk wegvoeren zal! [^22] Voorts hief hij zijn spreuk op, en zeide: Och, wie zal leven, als God dit doen zal! [^23] En de schepen van den oever der Chitteërs, die zullen Assur plagen, zij zullen ook Heber plagen; en hij zal ook ten verderve zijn. [^24] Toen stond Bileam op, en ging heen, en keerde weder tot zijn plaats. Balak ging ook zijn weg. [^25] 

[[Numeri - 23|<--]] Numeri - 24 [[Numeri - 25|-->]]

---
# Notes
