---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/numeri"
  - "#bible/testament/old"
aliases:
  - "Numeri - 27 - Statenvertaling (1750)"
---
[[Numeri - 26|<--]] Numeri - 27 [[Numeri - 28|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Numeri]]

# Numeri - 27

Toen naderden de dochteren van Zelafead, den zoon van Hefer, den zoon van Gilead, den zoon van Machir, den zoon van Manasse, onder de geslachten van Manasse, den zoon van Jozef (en dit zijn de namen zijner dochteren: Machla, Noa, en Hogla, en Milka, en Tirza); [^1] En zij stonden voor het aangezicht van Mozes, en voor het aangezicht van Eleazar, den priester, en voor het aangezicht van de oversten, en van de ganse vergadering, aan de deur van de tent der samenkomst, zeggende: [^2] Onze vader is gestorven in de woestijn, en hij is niet geweest in het midden der vergadering dergenen, die zich tegen den HEERE vergaderd hebben in de vergadering van Korach; maar hij is in zijn zonde gestorven, en had geen zonen. [^3] Waarom zou de naam onzes vaders uit het midden van zijn geslacht weggenomen worden, omdat hij geen zoon heeft? Geef ons een bezitting in het midden der broederen van onzen vader. [^4] En Mozes bracht haar rechtzaak voor het aangezicht des HEEREN. [^5] En de HEERE sprak tot Mozes, zeggende: [^6] De dochteren van Zelafead spreken recht; gij zult haar ganselijk geven de bezitting ener erfenis, in het midden van de broederen haars vaders; en gij zult de erfenis haars vaders op haar doen komen. [^7] En tot de kinderen Israëls zult gij spreken, zeggende: Wanneer iemand sterft, en geen zoon heeft, zo zult gij zijn erfenis op zijn dochter doen komen. [^8] En indien hij geen dochter heeft, zo zult gij zijn erfenis aan zijn broederen geven. [^9] Indien hij nu geen broederen heeft, zo zult gij zijn erfenis aan de broederen zijns vaders geven. [^10] Indien ook zijn vader geen broeders heeft, zo zult gij zijn erfenis geven aan zijn naastbestaande, die hem de naaste van zijn geslacht is, dat hij het erfelijk bezitte. Dit zal den kinderen Israëls tot een inzetting des rechts zijn, gelijk als de HEERE Mozes geboden heeft. [^11] Daarna zeide de HEERE tot Mozes: Klim op dezen berg Abarim, en zie dat land, hetwelk Ik den kinderen Israëls gegeven heb. [^12] Wanneer gij dat gezien zult hebben, dan zult gij tot uw volken verzameld worden, gij ook, gelijk als uw broeder Aäron verzameld geworden is; [^13] Naardien gijlieden Mijn mond wederspannig zijt geweest in de woestijn Zin, in de twisting der vergadering, om Mij aan de wateren voor hun ogen te heiligen. Dat zijn de wateren van Meriba, van Kades, in de woestijn Zin. [^14] Toen sprak Mozes tot den HEERE, zeggende: [^15] Dat de HEERE, de God der geesten van alle vlees, een man stelle over deze vergadering. [^16] Die voor hun aangezicht uitga, en die voor hun aangezicht inga, en die hen uitleide, en die hen inleide; opdat de vergadering des HEEREN niet zij als schapen, die geen herder hebben. [^17] Toen zeide de HEERE tot Mozes: Neem tot u Jozua, den zoon van Nun, een man, in wien de Geest is; en leg uw hand op hem; [^18] En stel hem voor het aangezicht van Eleazar, den priester, en voor het aangezicht der ganse vergadering; en geef hem bevel voor hun ogen; [^19] En leg op hem van uw heerlijkheid, opdat zij horen, te weten de ganse vergadering der kinderen Israëls. [^20] En hij zal voor het aangezicht van Eleazar, den priester, staan, die voor hem raad vragen zal, naar de wijze van Urim, voor het aangezicht des HEEREN; naar zijn mond zullen zij uitgaan, en naar zijn mond zullen zij ingaan, hij, en al de kinderen Israëls met hem, en de ganse vergadering. [^21] En Mozes deed, gelijk als de HEERE hem geboden had; want hij nam Jozua, en stelde hem voor het aangezicht van Eleazar, den priester, en voor het aangezicht der ganse vergadering. [^22] En hij legde zijn handen op hem, en gaf hem bevel; gelijk als de HEERE door den dienst van Mozes gesproken had. [^23] 

[[Numeri - 26|<--]] Numeri - 27 [[Numeri - 28|-->]]

---
# Notes
