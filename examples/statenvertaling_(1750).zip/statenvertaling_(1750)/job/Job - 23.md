---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 23 - Statenvertaling (1750)"
---
[[Job - 22|<--]] Job - 23 [[Job - 24|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 23

Maar Job antwoordde en zeide: [^1] Ook heden is mijn klacht wederspannigheid; mijn plage is zwaar boven mijn zuchten. [^2] Och, of ik wist, dat ik Hem vinden zou, ik zou tot Zijn stoel komen; [^3] Ik zou het recht voor Zijn aangezicht ordentelijk voorstellen, en mijn mond zou ik met verdedigingen vervullen. [^4] Ik zou de redenen weten, die Hij mij antwoorden zou; en verstaan, wat Hij mij zeggen zou. [^5] Zou Hij naar de grootheid Zijner macht met mij twisten? Neen; maar Hij zou acht op mij slaan. [^6] Daar zou de oprechte met Hem pleiten; en ik zou mij in eeuwigheid van mijn Rechter vrijmaken. [^7] Zie, ga ik voorwaarts, zo is Hij er niet, of achterwaarts, zo verneem ik Hem niet. [^8] Als Hij ter linkerhand werkt, zo aanschouw ik Hem niet; bedekt Hij Zich ter rechterhand, zo zie ik Hem niet. [^9] Doch Hij kent den weg, die bij mij is; Hij beproeve mij; als goud zal ik uitkomen. [^10] Aan Zijn gang heeft mijn voet vastgehouden; Zijn weg heb ik bewaard, en ben niet afgeweken. [^11] Het gebod Zijner lippen heb ik ook niet weggedaan; de redenen Zijns monds heb ik meer dan mijn bescheiden deel weggelegd. [^12] Maar is Hij tegen iemand, wie zal dan Hem afkeren? Wat Zijn ziel begeert, dat zal Hij doen. [^13] Want Hij zal volbrengen, dat over mij bescheiden is; en diergelijke dingen zijn er vele bij Hem. [^14] Hierom word ik voor Zijn aangezicht beroerd; aanmerk het, en vrees voor Hem; [^15] Want God heeft mijn hart week gemaakt, en de Almachtige heeft mij beroerd; [^16] Omdat ik niet uitgedelgd ben voor de duisternis, en dat Hij van mijn aangezicht de donkerheid bedekt heeft. [^17] 

[[Job - 22|<--]] Job - 23 [[Job - 24|-->]]

---
# Notes
