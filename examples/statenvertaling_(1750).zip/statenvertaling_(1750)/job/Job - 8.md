---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 8 - Statenvertaling (1750)"
---
[[Job - 7|<--]] Job - 8 [[Job - 9|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 8

Toen antwoordde Bildad, de Suhiet, en zeide: [^1] Hoe lang zult gij deze dingen spreken, en de redenen uws monds een geweldige wind zijn? [^2] Zou dan God het recht verkeren, en zou de Almachtige de gerechtigheid verkeren? [^3] Indien uw kinderen gezondigd hebben tegen Hem, Hij heeft hen ook in de hand hunner overtreding geworpen. [^4] Maar indien gij naar God vroeg zoekt, en tot den Almachtige om genade bidt; [^5] Zo gij zuiver en recht zijt, gewisselijk zal Hij nu opwaken, om uwentwil, en Hij zal de woning uwer gerechtigheid volmaken. [^6] Uw beginsel zal wel gering zijn; maar uw laatste zal zeer vermeerderd worden. [^7] Want vraag toch naar het vorige geslacht, en bereid u tot de onderzoeking hunner vaderen. [^8] Want wij zijn van gisteren en weten niet; dewijl onze dagen op de aarde een schaduw zijn. [^9] Zullen die u niet leren, tot u spreken, en uit hun hart redenen voortbrengen? [^10] Verheft zich de bieze zonder slijk? Groeit het rietgras zonder water? [^11] Als het nog in zijn groenigheid is, hoewel het niet afgesneden wordt, nochtans verdort het voor alle gras. [^12] Alzo zijn de paden van allen, die God vergeten; en de verwachting des huichelaars zal vergaan. [^13] Van denwelke zijn hoop walgen zal; en zijn vertrouwen zal zijn een huis der spinnekop. [^14] Hij zal op zijn huis leunen, maar het zal niet bestaan; hij zal zich daaraan vasthouden, maar het zal niet staande blijven. [^15] Hij is sappig voor de zon, en zijn scheuten gaan over zijn hof uit. [^16] Zijn wortelen worden bij de springader ingevlochten; hij ziet een stenige plaats. [^17] Maar als God hem verslindt uit zijn plaats, zo zal zij hem loochenen, zeggende: Ik heb u niet gezien. [^18] Zie, dat is de vreugde zijns wegs; en uit het stof zullen anderen voortspruiten. [^19] Zie, God zal den oprechte niet verwerpen; Hij vat ook de boosdoeners niet bij de hand; [^20] Totdat Hij uw mond met gelach vervulle, en uw lippen met gejuich. [^21] Uw haters zullen met schaamte bekleed worden; en de tent der goddelozen zal niet meer zijn. [^22] 

[[Job - 7|<--]] Job - 8 [[Job - 9|-->]]

---
# Notes
