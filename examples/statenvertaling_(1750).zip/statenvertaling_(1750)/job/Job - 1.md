---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 1 - Statenvertaling (1750)"
---
Job - 1 [[Job - 2|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 1

Er was een man in het land Uz, zijn naam was Job; en dezelve man was oprecht, en vroom, en godvrezende, en wijkende van het kwaad. [^1] En hem werden zeven zonen en drie dochteren geboren. [^2] Daartoe was zijn vee zeven duizend schapen, en drie duizend kemelen, en vijfhonderd juk ossen, en vijfhonderd ezelinnen; ook was zijn dienstvolk zeer veel; zodat deze man groter was dan al die van het oosten. [^3] En zijn zonen gingen, en maakten maaltijden in ieders huis op zijn dag; en zij zonden henen, en nodigden hun drie zusteren, om met hen te eten en te drinken. [^4] Het geschiedde dan, als de dagen der maaltijden omgegaan waren, dat Job henenzond, en hen heiligde, en des morgens vroeg opstond, en brandofferen offerde naar hun aller getal; want Job zeide: Misschien hebben mijn kinderen gezondigd, en God in hun hart gezegend. Alzo deed Job al die dagen. [^5] Er was nu een dag, als de kinderen Gods kwamen, om zich voor den HEERE te stellen, dat de satan ook in het midden van hen kwam. [^6] Toen zeide de HEERE tot den satan: Van waar komt gij? En de satan antwoordde den HEERE, en zeide: Van om te trekken op de aarde, en van die te doorwandelen. [^7] En de HEERE zeide tot den satan: Hebt gij ook acht geslagen op Mijn knecht Job? Want niemand is op de aarde gelijk hij, een man oprecht en vroom, godvrezende en wijkende van het kwaad. [^8] Toen antwoordde de satan den HEERE, en zeide: Is het om niet, dat Job God vreest? [^9] Hebt Gij niet een betuining gemaakt voor hem, en voor zijn huis, en voor al wat hij heeft rondom? Het werk zijner handen hebt Gij gezegend, en zijn vee is in menigte uitgebroken in den lande. [^10] Maar toch strek nu Uw hand uit, en tast aan alles, wat hij heeft; zo hij U niet in Uw aangezicht zal zegenen? [^11] En de HEERE zeide tot den satan: Zie, al wat hij heeft, zij in uw hand; alleen aan hem strek uw hand niet uit. En de satan ging uit van het aangezicht des HEEREN. [^12] Er was nu een dag, als zijn zonen en zijn dochteren aten, en wijn dronken in het huis van hun broeder, den eerstgeborene. [^13] Dat een bode tot Job kwam, en zeide: De runderen waren ploegende, en de ezelinnen weidende aan hun zijden. [^14] Doch de Sabeers deden een inval, en namen ze, en sloegen de jongeren met de scherpte des zwaards; en ik ben maar alleen ontkomen, om het u aan te zeggen. [^15] Als deze nog sprak, zo kwam een ander, en zeide: Het vuur Gods viel uit den hemel, en ontstak onder de schapen en onder de jongeren, en verteerde ze; en ik ben maar alleen ontkomen, om het u aan te zeggen. [^16] Als deze nog sprak, zo kwam een ander, en zeide: De Chaldeën stelden drie hopen, en vielen op de kemelen aan, en namen ze, en sloegen de jongeren met de scherpte des zwaards; en ik ben maar alleen ontkomen, om het u aan te zeggen. [^17] Als deze nog sprak, zo kwam een ander, en zeide: Uw zonen en uw dochteren aten, en dronken wijn, in het huis van hun broeder, den eerstgeborene; [^18] En zie, een grote wind kwam van over de woestijn, en stiet aan de vier hoeken van het huis, en het viel op de jongelingen, dat ze stierven; en ik ben maar alleen ontkomen, om het u aan te zeggen. [^19] Toen stond Job op, en scheurde zijn mantel, en schoor zijn hoofd, en viel op de aarde, en boog zich neder; [^20] En hij zeide: Naakt ben ik uit mijner moeders buik gekomen, en naakt zal ik daarhenen wederkeren. De HEERE heeft gegeven, en de HEERE heeft genomen; de Naam des HEEREN zij geloofd! [^21] In dit alles zondigde Job niet, en schreef Gode niets ongerijmds toe. [^22] 

Job - 1 [[Job - 2|-->]]

---
# Notes
