---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 27 - Statenvertaling (1750)"
---
[[Job - 26|<--]] Job - 27 [[Job - 28|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 27

En Job ging voort zijn spreuk op te heffen, en zeide: [^1] Zo waarachtig als God leeft, Die mijn recht weggenomen heeft, en de Almachtige, Die mijner ziel bitterheid heeft aangedaan! [^2] Zo lang als mijn adem in mij zal zijn, en het geblaas Gods in mijn neus; [^3] Indien mijn lippen onrecht zullen spreken, en indien mijn tong bedrog zal uitspreken! [^4] Het zij verre van mij, dat ik ulieden rechtvaardigen zou; totdat ik den geest zal gegeven hebben, zal ik mijn oprechtigheid van mij niet wegdoen. [^5] Aan mijn gerechtigheid zal ik vasthouden, en zal ze niet laten varen; mijn hart zal die niet versmaden van mijn dagen. [^6] Mijn vijand zij als de goddeloze, en die zich tegen mij opmaakt, als de verkeerde. [^7] Want wat is de verwachting des huichelaars, als hij zal gierig geweest zijn, wanneer God zijn ziel zal uittrekken? [^8] Zal God zijn geroep horen, als benauwdheid over hem komt? [^9] Zal hij zich verlustigen in den Almachtige? Zal hij God aanroepen te aller tijd? [^10] Ik zal ulieden leren van de hand Gods; wat bij den Almachtige is, zal ik niet verhelen. [^11] Ziet, gij zelve allen hebt het gezien; en waarom wordt gij dus door ijdelheid verijdeld? [^12] Dit is het deel des goddelozen mensen bij God, en de erve der tirannen, die zij van den Almachtige ontvangen zullen. [^13] Indien zijn kinderen vermenigvuldigen, het is ten zwaarde; en zijn spruiten zullen van brood niet verzadigd worden. [^14] Zijn overgeblevenen zullen in den dood begraven worden, en zijn weduwen zullen niet wenen. [^15] Zo hij zilver opgehoopt zal hebben als stof, en kleding bereid als leem; [^16] Hij zal ze bereiden, maar de rechtvaardige zal ze aantrekken, en de onschuldige zal het zilver delen. [^17] Hij bouwt zijn huis als een motte, en als een hoeder de hutte maakt. [^18] Rijk ligt hij neder, en wordt niet weggenomen; doet hij zijn ogen open, zo is hij er niet. [^19] Verschrikkingen zullen hem als wateren aangrijpen; des nachts zal hem een wervelwind wegstelen. [^20] De oostenwind zal hem wegvoeren, dat hij henengaat, en zal hem wegstormen uit zijn plaats. [^21] En God zal dit over hem werpen, en niet sparen; van Zijn hand zal hij snellijk vlieden. [^22] Een ieder zal over hem met zijn handen klappen, en over hem fluiten uit zijn plaats. [^23] 

[[Job - 26|<--]] Job - 27 [[Job - 28|-->]]

---
# Notes
