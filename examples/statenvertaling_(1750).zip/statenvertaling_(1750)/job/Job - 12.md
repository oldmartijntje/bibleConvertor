---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 12 - Statenvertaling (1750)"
---
[[Job - 11|<--]] Job - 12 [[Job - 13|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 12

Maar Job antwoordde en zeide: [^1] Trouwens, omdat gijlieden het volk zijt, zo zal de wijsheid met ulieden sterven! [^2] Ik heb ook een hart even als gijlieden, ik zwicht niet voor u; en bij wien zijn niet dergelijke dingen? [^3] Ik ben het, die zijn vriend een spot is, maar roepende tot God, Die hem verhoort; de rechtvaardige en oprechte is een spot. [^4] Hij is een verachte fakkel, naar de mening desgenen, die gerust is; hij is gereed met den voet te struikelen. [^5] De tenten der verwoesters hebben rust, en die God tergen, hebben verzekerdheden, om hetgene God met Zijn hand toebrengt. [^6] En waarlijk, vraag toch de beesten, en elkeen van die zal het u leren; en het gevogelte des hemels, dat zal het u te kennen geven. [^7] Of spreek tot de aarde, en zij zal het u leren; ook zullen het u de vissen der zee vertellen. [^8] Wie weet niet uit alle deze, dat de hand des HEEREN dit doet? [^9] In Wiens hand de ziel is van al wat leeft, en de geest van alle vlees des mensen. [^10] Zal niet het oor de woorden proeven, gelijk het gehemelte voor zich de spijze smaakt? [^11] In de stokouden is de wijsheid, en in de langheid der dagen het verstand. [^12] Bij Hem is wijsheid en macht; Hij heeft raad en verstand. [^13] Ziet, Hij breekt af, en het zal niet herbouwd worden; Hij besluit iemand, en er zal niet opengedaan worden. [^14] Ziet, Hij houdt de wateren op, en zij drogen uit; ook laat Hij ze uit, en zij keren de aarde om. [^15] Bij Hem is kracht en wijsheid; Zijns is de dwalende, en die doet dwalen. [^16] Hij voert de raadsheren beroofd weg, en de rechters maakt Hij uitzinnig, [^17] Den band der koningen maakt Hij los, en Hij bindt den gordel aan hun lenden. [^18] Hij voert de oversten beroofd weg, en de machtigen keert Hij om. [^19] Hij beneemt den getrouwen de spraak, en der ouden oordeel neemt Hij weg. [^20] Hij giet verachting over de prinsen uit, en Hij verslapt den riem der geweldigen. [^21] Hij openbaart de diepten uit de duisternis, en des doods schaduwe brengt Hij voort in het licht. [^22] Hij vermenigvuldigt de volken, en verderft ze; Hij breidt de volken uit, en leidt ze. [^23] Hij neemt het hart van de hoofden des volks der aarde weg, en doet hen dwalen in het woeste, waar geen weg is. [^24] Zij tasten in de duisternis, waar geen licht is; en Hij doet hen dwalen, als een dronkaard. [^25] 

[[Job - 11|<--]] Job - 12 [[Job - 13|-->]]

---
# Notes
