---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 3 - Statenvertaling (1750)"
---
[[Job - 2|<--]] Job - 3 [[Job - 4|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 3

Daarna opende Job zijn mond, en vervloekte zijn dag. [^1] Want Job antwoordde en zeide: [^2] De dag verga, waarin ik geboren ben, en de nacht, waarin men zeide: Een knechtje is ontvangen; [^3] Diezelve dag zij duisternis; dat God naar hem niet vrage van boven; en dat geen glans over hem schijne; [^4] Dat de duisternis en des doods schaduw hem verontreinigen; dat wolken over hem wonen; dat hem verschrikken de zwarte dampen des dags! [^5] Diezelve nacht, donkerheid neme hem in; dat hij zich niet verheuge onder de dagen des jaars; dat hij in het getal der maanden niet kome! [^6] Ziet, diezelve nacht zij eenzaam; dat geen vrolijk gezang daarin kome; [^7] Dat hem vervloeken de vervloekers des dags, die bereid zijn hun rouw te verwekken; [^8] Dat de sterren van zijn schemertijd verduisterd worden; hij wachte naar het licht, en het worde niet; en hij zie niet de oogleden des dageraads! [^9] Omdat hij niet toegesloten heeft de deuren mijns buiks, noch verborgen de moeite van mijn ogen. [^10] Waarom ben ik niet gestorven van de baarmoeder af, en heb den geest gegeven, als ik uit den buik voortkwam? [^11] Waarom zijn mij de knieën voorgekomen, en waartoe de borsten, opdat ik zuigen zou? [^12] Want nu zou ik nederliggen, en stil zijn; ik zou slapen, dan zou voor mij rust wezen; [^13] Met de koningen en raadsheren der aarde, die voor zich woeste plaatsen bebouwden; [^14] Of met de vorsten, die goud hadden, die hun huizen met zilver vervulden. [^15] Of als een verborgene misdracht, zou ik niet zijn; als de kinderkens, die het licht niet gezien hebben. [^16] Daar houden de bozen op van beroering, en daar rusten de vermoeiden van kracht; [^17] Daar zijn de gebondenen te zamen in rust; zij horen de stem des drijvers niet. [^18] De kleine en de grote is daar; en de knecht vrij van zijn heer. [^19] Waarom geeft Hij den ellendige het licht, en het leven den bitterlijk bedroefden van gemoed? [^20] Die verlangen naar den dood, maar hij is er niet; en graven daarnaar meer dan naar verborgene schatten; [^21] Die blijde zijn tot opspringens toe, en zich verheugen, als zij het graf vinden; [^22] Aan den man, wiens weg verborgen is, en dien God overdekt heeft? [^23] Want voor mijn brood komt mijn zuchting; en mijn brullingen worden uitgestort als water. [^24] Want ik vreesde een vreze, en zij is mij aangekomen; en wat ik schroomde, is mij overkomen. [^25] Ik was niet gerust; en was niet stil, en rustte niet; en de beroering is gekomen. [^26] 

[[Job - 2|<--]] Job - 3 [[Job - 4|-->]]

---
# Notes
