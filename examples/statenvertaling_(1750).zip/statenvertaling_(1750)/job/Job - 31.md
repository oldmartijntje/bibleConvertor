---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 31 - Statenvertaling (1750)"
---
[[Job - 30|<--]] Job - 31 [[Job - 32|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 31

Ik heb een verbond gemaakt met mijn ogen; hoe zou ik dan acht gegeven hebben op een maagd? [^1] Want wat is het deel Gods van boven, of de erve des Almachtigen uit de hoogten? [^2] Is niet het verderf voor den verkeerde, ja, wat vreemds voor de werkers der ongerechtigheid? [^3] Ziet Hij niet mijn wegen, en telt Hij niet al mijn treden? [^4] Zo ik met ijdelheid omgegaan heb, en mijn voet gesneld heeft tot bedriegerij; [^5] Hij wege mij op, in een rechte weegschaal, en God zal mijn oprechtigheid weten. [^6] Zo mijn gang uit den weg geweken is, en mijn hart mijn ogen nagevolgd is, en aan mijn handen iets aankleeft; [^7] Zo moet ik zaaien, maar een ander eten, en mijn spruiten moeten uitgeworteld worden! [^8] Zo mijn hart verlokt is geweest tot een vrouw, of ik aan mijns naasten deur geloerd heb; [^9] Zo moet mijn huisvrouw met een ander malen, en anderen zich over haar krommen! [^10] Want dat is een schandelijke daad, en het is een misdaad bij de rechters. [^11] Want dat is een vuur, hetwelk tot de verderving toe verteert, en al mijn inkomen uitgeworteld zou hebben. [^12] Zo ik versmaad heb het recht mijns knechts, of mijner dienstmaagd, als zij geschil hadden met mij; [^13] (Want wat zou ik doen, als God opstond? En als Hij bezoeking deed, wat zou ik Hem antwoorden? [^14] Heeft Hij niet, Die mij in den buik maakte, hem ook gemaakt en Eén ons in de baarmoeder bereid?) [^15] Zo ik den armen hun begeerte onthouden heb, of de ogen der weduwe laten versmachten; [^16] En mijn bete alleen gegeten heb, zodat de wees daarvan niet gegeten heeft; [^17] (Want van mijn jonkheid af is hij bij mij opgetogen, als bij een vader, en van mijner moeders buik af heb ik haar geleid;) [^18] Zo ik iemand heb zien omkomen, omdat hij zonder kleding was, en dat de nooddruftige geen deksel had; [^19] Zo zijn lenden mij niet gezegend hebben, toen hij van de vellen mijner lammeren verwarmd werd; [^20] Zo ik mijn hand tegen den wees bewogen heb, omdat ik in de poort mijn hulp zag; [^21] Mijn schouder valle van het schouderbeen, en mijn arm breke van zijn pijp af! [^22] Want het verderf Gods was bij mij een schrik, en ik vermocht niet vanwege Zijn hoogheid. [^23] Zo ik het goud tot mijn hoop gezet heb, of tot het fijn goud gezegd heb: Gij zijt mijn vertrouwen; [^24] Zo ik blijde ben geweest, omdat mijn vermogen groot was, en omdat mijn hand geweldig veel verkregen had; [^25] Zo ik het licht aangezien heb, wanneer het scheen, of de maan heerlijk voortgaande; [^26] En mijn hart verlokt is geweest in het verborgen, dat mijn hand mijn mond gekust heeft; [^27] Dat ware ook een misdaad bij den rechter; want ik zou den God van boven verzaakt hebben. [^28] Zo ik verblijd ben geweest in de verdrukking mijns haters, en mij opgewekt heb, als het kwaad hem vond; [^29] (Ook heb ik mijn gehemelte niet toegelaten te zondigen, mits door een vloek zijn ziel te begeren). [^30] Zo de lieden mijner tent niet hebben gezegd: Och, of wij van zijn vlees hadden, wij zouden niet verzadigd worden; [^31] De vreemdeling overnachtte niet op de straat; mijn deuren opende ik naar den weg; [^32] Zo ik, gelijk Adam, mijn overtredingen bedekt heb, door eigenliefde mijn misdaad verbergende! [^33] Zeker, ik kon wel een grote menigte geweldiglijk onderdrukt hebben; maar de verachtste der huisgezinnen zou mij afgeschrikt hebben; zodat ik gewezen zou hebben, en ter deure niet uitgegaan zijn. [^34] Och, of ik een hadde, die mij hoorde! Zie, mijn oogmerk is, dat de Almachtige mij antwoorde, en dat mijn tegenpartij een boek schrijve. [^35] Zou ik het niet op mijn schouder dragen? Ik zou het op mij binden als een kroon. [^36] Het getal mijner treden zou ik hem aanwijzen; als een vorst zou ik tot hem naderen. [^37] Zo mijn land tegen mij roept, en zijn voren te zamen wenen; [^38] Zo ik zijn vermogen gegeten heb zonder geld, en de ziel zijner akkerlieden heb doen hijgen; [^39] Dat voor tarwe distelen voortkomen, en voor gerst stinkkruid! De woorden van Job hebben een einde. [^40] 

[[Job - 30|<--]] Job - 31 [[Job - 32|-->]]

---
# Notes
