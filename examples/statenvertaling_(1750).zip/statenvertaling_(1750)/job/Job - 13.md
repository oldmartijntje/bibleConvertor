---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 13 - Statenvertaling (1750)"
---
[[Job - 12|<--]] Job - 13 [[Job - 14|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 13

Ziet, dat alles heeft mijn oog gezien, mijn oor gehoord en verstaan. [^1] Gelijk gijlieden het weet, weet ik het ook; ik zwicht niet voor u. [^2] Maar ik zal tot den Almachtige spreken, en ben belust mij te verdedigen voor God. [^3] Want gewisselijk, gij zijt leugenstoffeerders; gij allen zijt nietige medicijnmeesters. [^4] Och, of gij gans stilzweegt! Dat zou ulieden voor wijsheid wezen. [^5] Hoort toch mijn verdediging, en merkt op de twistingen mijner lippen. [^6] Zult gij voor God onrecht spreken, en zult gij voor Hem bedriegerij spreken? [^7] Zult gij Zijn aangezicht aannemen? Zult gij voor God twisten? [^8] Zal het goed zijn, als Hij u zal onderzoeken? Zult gij met Hem spotten, gelijk men met een mens spot? [^9] Hij zal u gewisselijk bestraffen, zo gij in het verborgene het aangezicht aanneemt. [^10] Zal u niet Zijn hoogheid verschrikken, en Zijn vreze over u vallen? [^11] Uw gedachtenissen zijn gelijk as, uw hoogten als hoogten van leem. [^12] Houdt stil van mij, opdat ik spreke, en er ga over mij, wat het zij. [^13] Waarom zou ik mijn vlees in mijn tanden nemen, en mijn ziel in mijn hand stellen? [^14] Ziet, zo Hij mij doodde, zou ik niet hopen? Evenwel zal ik mijn wegen voor Zijn aangezicht verdedigen. [^15] Ook zal Hij mij tot zaligheid zijn; maar een huichelaar zal voor Zijn aangezicht niet komen. [^16] Hoort naarstiglijk mijn rede, en mijn aanwijzing met uw oren. [^17] Ziet nu, ik heb het recht ordentelijk gesteld; ik weet, dat ik rechtvaardig zal verklaard worden. [^18] Wie is hij, die met mij twist? Wanneer ik nu zweeg, zo zou ik den geest geven. [^19] Alleenlijk doe twee dingen niet met mij; dan zal ik mij van Uw aangezicht niet verbergen. [^20] Doe Uw hand verre van op mij, en Uw verschrikking make mij niet verbaasd. [^21] Roep dan, en ik zal antwoorden; of ik zal spreken, en geef mij antwoord. [^22] Hoeveel misdaden en zonden heb ik? Maak mijn overtreding en mijn zonden mij bekend. [^23] Waarom verbergt Gij Uw aangezicht, en houdt mij voor Uw vijand? [^24] Zult Gij een gedreven blad verbrijzelen, en zult Gij een drogen stoppel vervolgen? [^25] Want Gij schrijft tegen mij bittere dingen; en Gij doet mij erven de misdaden mijner jonkheid. [^26] Gij legt ook mijn voeten in den stok, en neemt waar al mijn paden; Gij drukt U in de wortelen mijner voeten, [^27] En hij veroudert als een verrotting, als een kleed, dat de mot opeet. [^28] 

[[Job - 12|<--]] Job - 13 [[Job - 14|-->]]

---
# Notes
