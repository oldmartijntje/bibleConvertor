---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 36 - Statenvertaling (1750)"
---
[[Job - 35|<--]] Job - 36 [[Job - 37|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 36

Elihu ging nog voort, en zeide: [^1] Verbeid mij een weinig, en ik zal u aanwijzen, dat er nog redenen voor God zijn. [^2] Ik zal mijn gevoelen van verre ophalen, en mijn Schepper gerechtigheid toewijzen. [^3] Want voorwaar, mijn woorden zullen geen valsheid zijn; een, die oprecht is van gevoelen, is bij u. [^4] Zie, God is geweldig, nochtans versmaadt Hij niet; geweldig is Hij in kracht des harten. [^5] Hij laat den goddeloze niet leven, en het recht der ellendigen beschikt Hij. [^6] Hij onttrekt Zijn ogen niet van den rechtvaardige, maar met de koningen zijn zij in den troon; daar zet Hij hen voor altoos, en zij worden verheven. [^7] En zo zij, gebonden zijnde in boeien, vastgehouden worden met banden der ellende; [^8] Dan geeft Hij hun hun werk te kennen, en hun overtredingen, omdat zij de overhand genomen hebben; [^9] En Hij openbaart het voor hunlieder oor ter tucht, en zegt, dat zij zich van de ongerechtigheid bekeren zouden. [^10] Indien zij horen, en Hem dienen, zo zullen zij hun dagen eindigen in het goede, en hun jaren in liefelijkheden. [^11] Maar zo zij niet horen, zo gaan zij door het zwaard door, en zij geven den geest zonder kennis. [^12] En die met het hart huichelachtig zijn, leggen toorn op; zij roepen niet, als Hij hen gebonden heeft. [^13] Hun ziel zal in de jonkheid sterven, en hun leven onder de schandjongens. [^14] Hij zal den ellendige in zijn ellende vrijmaken, en in de onderdrukking zal Hij het voor hunlieder oor openbaren. [^15] Alzo zou Hij ook u afgekeerd hebben van den mond des angstes tot de ruimte, onder dewelke geen benauwing zou geweest zijn; en het gerecht uwer tafel zou vol vettigheid geweest zijn. [^16] Maar gij hebt het gericht des goddelozen vervuld; het gericht en het recht houden u vast. [^17] Omdat er grimmigheid is, wacht u, dat Hij u misschien niet met een klop wegstote; zodat u een groot rantsoen er niet zou afbrengen. [^18] Zou Hij uw rijkdom achten, dat gij niet in benauwdheid zoudt zijn; of enige versterkingen van kracht? [^19] Haak niet naar dien nacht, als de volken van hun plaats opgenomen worden. [^20] Wacht u, wend u niet tot ongerechtigheid; overmits gij ze in dezen verkoren hebt, uit oorzake van de ellende. [^21] Zie, God verhoogt door Zijn kracht; wie is een Leraar, gelijk Hij? [^22] Wie heeft Hem gesteld over Zijn weg? Of wie heeft gezegd: Gij hebt onrecht gedaan? [^23] Gedenk, dat gij Zijn werk groot maakt, hetwelk de lieden aanschouwen. [^24] Alle mensen zien het aan; de mens schouwt het van verre. [^25] Zie, God is groot, en wij begrijpen het niet; er is ook geen onderzoeking van het getal Zijner jaren. [^26] Want Hij trekt de druppelen der wateren op, die den regen na zijn damp uitgieten; [^27] Welke de wolken uitgieten, en over den mens overvloediglijk afdruipen. [^28] Kan men ook verstaan de uitbreidingen der wolken, en de krakingen Zijner hutte? [^29] Zie, Hij breidt over hem Zijn licht uit, en de wortelen der zee bedekt Hij. [^30] Want daardoor richt Hij de volken; Hij geeft spijze ten overvloede. [^31] Met handen bedekt Hij het licht, en doet aan hetzelve verbod door dengene, die tussen doorkomt. [^32] Daarvan verkondigt Zijn geklater, en het vee; ook van den opgaanden damp. [^33] 

[[Job - 35|<--]] Job - 36 [[Job - 37|-->]]

---
# Notes
