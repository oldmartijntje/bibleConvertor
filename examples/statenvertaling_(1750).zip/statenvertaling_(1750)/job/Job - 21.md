---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 21 - Statenvertaling (1750)"
---
[[Job - 20|<--]] Job - 21 [[Job - 22|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 21

Maar Job antwoordde en zeide: [^1] Hoort aandachtelijk mijn rede, en laat dit zijn uw vertroostingen. [^2] Verdraagt mij, en ik zal spreken; en nadat ik gesproken zal hebben, spot dan. [^3] Is (mij aangaande) mijn klacht tot den mens? Doch of het zo ware, waarom zou mijn geest niet verdrietig zijn? [^4] Ziet mij aan, en wordt verbaasd, en legt de hand op den mond. [^5] Ja, wanneer ik daaraan gedenk, zo word ik beroerd, en mijn vlees heeft een gruwen gevat. [^6] Waarom leven de goddelozen, worden oud, ja, worden geweldig in vermogen? [^7] Hun zaad is bestendig met hen voor hun aangezicht, en hun spruiten zijn voor hun ogen. [^8] Hun huizen hebben vrede zonder vreze, en de roede Gods is op hen niet. [^9] Zijn stier bespringt, en mist niet; zijn koe kalft, en misdraagt niet. [^10] Hun jonge kinderen zenden zij uit als een kudde, en hun kinderen huppelen. [^11] Zij heffen op met de trommel en de harp, en zij verblijden zich op het geluid des orgels. [^12] In het goede verslijten zij hun dagen; en in een ogenblik dalen zij in het graf. [^13] Nochtans zeggen zij tot God: Wijk van ons, want aan de kennis Uwer wegen hebben wij geen lust. [^14] Wat is de Almachtige, dat wij Hem zouden dienen? En wat baat zullen wij hebben, dat wij Hem aanlopen zouden? [^15] Doch ziet, hun goed is niet in hun hand; de raad der goddelozen is verre van mij. [^16] Hoe dikwijls geschiedt het, dat de lamp der goddelozen uitgeblust wordt, en hun verderf hun overkomt; dat God hun smarten uitdeelt in Zijn toorn! [^17] Dat zij gelijk stro worden voor den wind, en gelijk kaf, dat de wervelwind wegsteelt; [^18] Dat God zijn geweld weglegt voor zijn kinderen, hem vergeldt, dat hij het gewaar wordt; [^19] Dat zijn ogen zijn ondergang zien, en hij drinkt van de grimmigheid des Almachtigen! [^20] Want wat lust zou hij na zich aan zijn huis hebben, als het getal zijner maanden afgesneden is? [^21] Zal men God wetenschap leren, daar Hij de hogen richt? [^22] Deze sterft in de kracht zijner volkomenheid, daar hij gans stil en gerust was; [^23] Zijn melkvaten waren vol melk, en het merg zijner benen was bevochtigd. [^24] De ander daarentegen sterft met een bittere ziel, en hij heeft van het goede niet gegeten. [^25] Zij liggen te zamen neder in het stof, en het gewormte overdekt ze. [^26] Ziet, ik weet ulieder gedachten, en de boze verdichtselen, waarmede gij tegen mij geweld doet. [^27] Want gij zult zeggen: Waar is het huis van den prins, en waar is de tent van de woningen der goddelozen? [^28] Hebt gijlieden niet gevraagd de voorbijgaanden op den weg, en kent gij hun tekenen niet? [^29] Dat de boze onttrokken wordt ten dage des verderfs; dat zij ten dage der verbolgenheden ontvoerd worden. [^30] Wie zal hem in het aangezicht zijn weg vertonen? Als hij wat doet, wie zal hem vergelden? [^31] Eindelijk wordt hij naar de graven gebracht, en is gedurig in den aardhoop. [^32] De kluiten des dals zijn hem zoet, en hij trekt na zich alle mensen; en dergenen, die voor hem geweest zijn, is geen getal. [^33] Hoe vertroost gij mij dan met ijdelheid, dewijl in uw antwoorden overtreding overig is? [^34] 

[[Job - 20|<--]] Job - 21 [[Job - 22|-->]]

---
# Notes
