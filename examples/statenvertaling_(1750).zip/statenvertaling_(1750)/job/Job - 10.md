---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 10 - Statenvertaling (1750)"
---
[[Job - 9|<--]] Job - 10 [[Job - 11|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 10

Mijn ziel is verdrietig over mijn leven; ik zal mijn klacht op mij laten; ik zal spreken in bitterheid mijner ziel. [^1] Ik zal tot God zeggen: Verdoem mij niet; doe mij weten, waarover Gij met mij twist. [^2] Is het U goed, dat Gij verdrukt, dat Gij verwerpt den arbeid Uwer handen, en over den raad der goddelozen schijnsel geeft? [^3] Hebt Gij vleselijke ogen, ziet Gij, gelijk een mens ziet? [^4] Zijn Uw dagen als de dagen van een mens? Zijn Uw jaren als de dagen eens mans? [^5] Dat Gij onderzoekt naar mijn ongerechtigheid, en naar mijn zonde verneemt? [^6] Het is Uw wetenschap, dat ik niet goddeloos ben; nochtans is er niemand, die uit Uw hand verlosse. [^7] Uw handen doen mij smart aan, hoewel zij mij gemaakt hebben, te zamen rondom mij zijn zij, en Gij verslindt mij. [^8] Gedenk toch, dat Gij mij als leem bereid hebt, en mij tot stof zult doen wederkeren. [^9] Hebt Gij mij niet als melk gegoten, en mij als een kaas doen runnen? [^10] Met vel en vlees hebt Gij mij bekleed; met beenderen ook en zenuwen hebt Gij mij samengevlochten; [^11] Benevens het leven hebt Gij weldadigheid aan mij gedaan, en Uw opzicht heeft mijn geest bewaard. [^12] Maar deze dingen hebt Gij verborgen in Uw hart; ik weet, dat dit bij U geweest is. [^13] Indien ik zondig, zo zult Gij mij waarnemen, en van mijn misdaad zult Gij mij niet onschuldig houden. [^14] Zo ik goddeloos ben, wee mij! En ben ik rechtvaardig, ik zal mijn hoofd niet opheffen; ik ben zat van schande, maar aanzie mijn ellende. [^15] Want zij verheft zich; gelijk een felle leeuw jaagt Gij mij; Gij keert weder en stelt U wonderlijk tegen mij. [^16] Gij vernieuwt Uw getuigen tegenover mij, en vermenigvuldigt Uw toorn tegen mij; verwisselingen, ja, een heirleger, zijn tegen mij. [^17] En waarom hebt Gij mij uit de baarmoeder voortgebracht? Och, dat ik den geest gegeven had, en geen oog mij gezien had! [^18] Ik zou zijn, alsof ik niet geweest ware; van moeders buik zou ik tot het graf gebracht zijn geweest. [^19] Zijn mijn dagen niet weinig? Houd op, zet van mij af, dat ik mij een weinig verkwikke; [^20] Eer ik henenga (en niet wederkom) in een land der duisternis en der schaduwe des doods; [^21] Een stikdonker land, als de duisternis zelve, de schaduwe des doods, en zonder ordeningen, en het geeft schijnsel als de duisternis. [^22] 

[[Job - 9|<--]] Job - 10 [[Job - 11|-->]]

---
# Notes
