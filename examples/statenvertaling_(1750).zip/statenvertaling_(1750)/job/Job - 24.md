---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 24 - Statenvertaling (1750)"
---
[[Job - 23|<--]] Job - 24 [[Job - 25|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 24

Waarom zouden van den Almachtige de tijden niet verborgen zijn, dewijl zij, die Hem kennen, Zijn dagen niet zien? [^1] Zij tasten de landpalen aan; de kudden roven zij, en weiden ze. [^2] Den ezel der wezen drijven zij weg; den os ener weduwe nemen zij te pand. [^3] Zij doen de nooddruftigen wijken van den weg; te zamen versteken zich de ellendigen des lands. [^4] Ziet, zij zijn woudezels in de woestijn; zij gaan uit tot hun werk, makende zich vroeg op ten roof; het vlakke veld is hem tot spijs, en den jongeren. [^5] Op het veld maaien zij zijn voeder, en den wijnberg des goddelozen lezen zij af. [^6] Den naakten laten zij vernachten zonder kleding, die geen deksel heeft tegen de koude. [^7] Van den stroom der bergen worden zij nat, en zonder toevlucht zijnde, omhelzen zij de steenrotsen. [^8] Zij rukken het weesje van de borst, en dat over den arme is, nemen zij te pand. [^9] Den naakte doen zij weggaan zonder kleed, en hongerig, die garven dragen. [^10] Tussen hun muren persen zij olie uit, treden de wijnpersen, en zijn dorstig. [^11] Uit de stad zuchten de lieden, en de ziel der verwonden schreeuwt uit; nochtans beschikt God niets ongerijmds. [^12] Zij zijn onder de wederstrevers des lichts; zij kennen Zijn wegen niet, en zij blijven niet op Zijn paden. [^13] Met het licht staat de moorder op, doodt den arme en den nooddruftige; en des nachts is hij als een dief. [^14] Ook neemt het oog des overspelers de schemering waar, zeggende: Geen oog zal mij zien; en hij legt een deksel op het aangezicht. [^15] In de duisternis doorgraaft hij de huizen, die zij zich des daags afgetekend hadden; zij kennen het licht niet. [^16] Want de morgenstond is hun te zamen de schaduw des doods; als men hen kent, zijn zij in de strikken van des doods schaduw. [^17] Hij is licht op het vlakke der wateren; vervloekt is hun deel op de aarde; hij wendt zich niet tot den weg der wijngaarden. [^18] De droogte mitsgaders de hitte nemen de sneeuwwateren weg; alzo het graf dergenen, die gezondigd hebben. [^19] De baarmoeder vergeet hem, het gewormte is hem zoet, zijns wordt niet meer gedacht; en het onrecht wordt gebroken als een hout. [^20] De onvruchtbare, die niet baart, teert hij af, en aan de weduwe doet hij niets goeds. [^21] Ook trekt hij de machtigen door zijn kracht; staat hij op, zo is men des levens niet zeker. [^22] Stelt hem God in gerustigheid, zo steunt hij daarop; nochtans zijn Zijn ogen op hun wegen. [^23] Zij zijn een weinig tijds verheven, daarna is er niemand van hen; zij worden nedergedrukt; gelijk alle anderen worden zij besloten; en gelijk de top ener aar worden zij afgesneden. [^24] Indien het nu zo niet is, wie zal mij leugenachtig maken, en mijn rede tot niet brengen? [^25] 

[[Job - 23|<--]] Job - 24 [[Job - 25|-->]]

---
# Notes
