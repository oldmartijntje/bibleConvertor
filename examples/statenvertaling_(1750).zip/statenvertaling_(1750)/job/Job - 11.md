---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 11 - Statenvertaling (1750)"
---
[[Job - 10|<--]] Job - 11 [[Job - 12|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 11

Toen antwoordde Zofar, de Naämathiet, en zeide: [^1] Zou de veelheid der woorden niet beantwoord worden, en zou een klapachtig man recht hebben? [^2] Zouden uw leugenen de lieden doen zwijgen, en zoudt gij spotten, en niemand u beschamen? [^3] Want gij hebt gezegd: Mijn leer is zuiver, en ik ben rein in Uw ogen. [^4] Maar gewisselijk, och, of God sprak, en Zijn lippen tegen u opende; [^5] En u bekend maakte de verborgenheden der wijsheid, omdat zij dubbel zijn in wezen! Daarom weet, dat God voor u vergeet van uw ongerechtigheid. [^6] Zult gij de onderzoeking Gods vinden? Zult gij tot de volmaaktheid toe den Almachtige vinden? [^7] Zij is als de hoogten der hemelen, wat kunt gij doen? Dieper dan de hel, wat kunt gij weten? [^8] Langer dan de aarde is haar maat, en breder dan de zee. [^9] Indien Hij voorbijgaat, opdat Hij overlevere of vergadere, wie zal dan Hem afkeren? [^10] Want Hij kent de ijdele lieden en Hij ziet de ondeugd; zou Hij dan niet aanmerken? [^11] Dan zal een verstandeloos man kloekzinnig worden; hoewel de mens als het veulen eens woudezels geboren is. [^12] Indien gij uw hart bereid hebt, zo breid uw handen tot Hem uit. [^13] Indien er ondeugd in uw hand is, doe die verre weg; en laat het onrecht in uw tenten niet wonen. [^14] Want dan zult gij uw aangezicht opheffen uit de gebreken, en zult vast wezen, en niet vrezen. [^15] Want gij zult de moeite vergeten, en harer gedenken als der wateren, die voorbijgegaan zijn. [^16] Ja, uw tijd zal klaarder dan de middag oprijzen; gij zult uitvliegen, als de morgenstond zult gij zijn. [^17] En gij zult vertrouwen, omdat er verwachting zal zijn; en gij zult graven, gerustelijk zult gij slapen; [^18] En gij zult nederliggen, en niemand zal u verschrikken; en velen zullen uw aangezicht smeken. [^19] Maar de ogen der goddelozen zullen bezwijken, en de toevlucht zal van hen vergaan; en hun verwachting zal zijn de uitblazing der ziel. [^20] 

[[Job - 10|<--]] Job - 11 [[Job - 12|-->]]

---
# Notes
