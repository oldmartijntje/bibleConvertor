---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 9 - Statenvertaling (1750)"
---
[[Job - 8|<--]] Job - 9 [[Job - 10|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 9

Maar Job antwoordde en zeide: [^1] Waarlijk, ik weet, dat het zo is; want hoe zou de mens rechtvaardig zijn bij God? [^2] Zo hij lust heeft, om met Hem te twisten, niet één uit duizend zal hij Hem beantwoorden. [^3] Hij is wijs van hart, en sterk van kracht; wie heeft zich tegen Hem verhard, en vrede gehad? [^4] Die de bergen verzet, dat zij het niet gewaar worden, Die ze omkeert in Zijn toorn; [^5] Die de aarde beweegt uit haar plaats, dat haar pilaren schudden; [^6] Die de zon gebiedt, en zij gaat niet op; en verzegelt de sterren; [^7] Die alleen de hemelen uitbreidt, en treedt op de hoogten der zee; [^8] Die den Wagen maakt, den Orion, en het Zevengesternte, en de binnenkameren van het Zuiden; [^9] Die grote dingen doet, die men niet doorzoeken kan; en wonderen, die men niet tellen kan. [^10] Zie, Hij zal voor mij henengaan, en ik zal Hem niet zien; en Hij zal voorbijgaan, en ik zal Hem niet merken. [^11] Zie, Hij zal roven, wie zal het Hem doen wedergeven? Wie zal tot Hem zeggen: Wat doet Gij? [^12] God zal Zijn toorn niet afkeren; onder Hem worden gebogen de hovaardige helpers. [^13] Hoeveel te min zal ik Hem antwoorden, en mijn woorden uitkiezen tegen Hem? [^14] Denwelken ik, zo ik rechtvaardig ware, niet zou antwoorden; mijn Rechter zal ik om genade bidden. [^15] Indien ik roep, en Hij mij antwoordt; ik zal niet geloven, dat Hij mijn stem ter ore genomen heeft. [^16] Want Hij vermorzelt mij door een onweder, en vermenigvuldigt mijn wonden zonder oorzaak. [^17] Hij laat mij niet toe mijn adem te verhalen; maar Hij verzadigt mij met bitterheden. [^18] Zo het aan de kracht komt, zie, Hij is sterk; en zo het aan het recht komt, wie zal mij dagvaarden? [^19] Zo ik mij rechtvaardig, mijn mond zal mij verdoemen; ben ik oprecht, Hij zal mij toch verkeerd verklaren. [^20] Ben ik oprecht, zo acht ik toch mijn ziel niet; ik versmaad mijn leven. [^21] Dat is één ding, daarom zeg ik: Den oprechte en den goddeloze verdoet Hij. [^22] Als de gesel haastelijk doodt, bespot Hij de verzoeking der onschuldigen. [^23] De aarde wordt gegeven in de hand des goddelozen; Hij overdekt het aangezicht harer rechteren; zo niet, wie is Hij dan? [^24] En mijn dagen zijn lichter geweest dan een loper; zij zijn weggevloden, zij hebben het goede niet gezien. [^25] Zij zijn voorbijgevaren met jachtschepen; gelijk een arend naar het aas toevliegt. [^26] Indien mijn zeggen is: Ik zal mijn klacht vergeten, en ik zal mijn gebaar laten varen, en mij verkwikken; [^27] Zo schroom ik voor al mijn smarten; ik weet, dat Gij mij niet onschuldig zult houden. [^28] Ik zal toch goddeloos zijn; waarom dan zal ik ijdellijk arbeiden? [^29] Indien ik mij wasse met sneeuwwater, en mijn handen zuivere met zeep; [^30] Dan zult Gij mij in de gracht induiken, en mijn klederen zullen van mij gruwen. [^31] Want Hij is niet een man, als ik, dien ik antwoorden zou, zo wij te zamen in het gericht kwamen. [^32] Er is geen scheidsman tussen ons, die zijn hand op ons beiden leggen mocht. [^33] Dat Hij van op mij Zijn roede wegdoe, en dat Zijn verschrikking mij niet verbaasd make; [^34] Zo zal ik spreken, en Hem niet vrezen; want zodanig ben ik niet bij mij. [^35] 

[[Job - 8|<--]] Job - 9 [[Job - 10|-->]]

---
# Notes
