---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 19 - Statenvertaling (1750)"
---
[[Job - 18|<--]] Job - 19 [[Job - 20|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 19

Maar Job antwoordde en zeide: [^1] Hoe lang zult gijlieden mijn ziel bedroeven, en mij met woorden verbrijzelen? [^2] Gij hebt nu tienmaal mij schande aangedaan; gij schaamt u niet, gij verhardt u tegen mij. [^3] Maar ook het zij waarlijk, dat ik gedwaald heb, mijn dwaling zal bij mij vernachten. [^4] Indien gijlieden waarlijk u verheft tegen mij, en mijn smaad tegen mij drijft; [^5] Weet nu, dat God mij heeft omgekeerd, en mij met Zijn net omsingeld. [^6] Ziet, ik roep, geweld! doch word niet verhoord; ik schreeuw, doch er is geen recht. [^7] Hij heeft mijn weg toegemuurd, dat ik niet doorgaan kan, en over mijn paden heeft Hij duisternis gesteld. [^8] Mijn eer heeft Hij van mij afgetrokken, en de kroon mijns hoofds heeft Hij weggenomen. [^9] Hij heeft mij rondom afgebroken, zodat ik henenga, en heeft mijn verwachting als een boom weggerukt. [^10] Daartoe heeft Hij Zijn toorn tegen mij ontstoken, en mij bij Zich geacht als Zijn vijanden. [^11] Zijn benden zijn te zamen aangekomen, en hebben tegen mij haar weg gebaand, en hebben zich gelegerd rondom mijn tent. [^12] Mijn broeders heeft Hij verre van mij gedaan; en die mij kennen, zekerlijk, zij zijn van mij vervreemd. [^13] Mijn nabestaanden houden op, en mijn bekenden vergeten mij. [^14] Mijn huisgenoten en mijn dienstmaagden achten mij voor een vreemde; een uitlander ben ik in hun ogen. [^15] Ik riep mijn knecht, en hij antwoordde niet; ik smeekte met mijn mond tot hem. [^16] Mijn adem is mijn huisvrouw vreemd; en ik smeek om der kinderen mijns buiks wil. [^17] Ook versmaden mij de jonge kinderen; sta ik op, zo spreken zij mij tegen. [^18] Alle mensen mijns heimelijken raads hebben een gruwel aan mij; en die ik liefhad, zijn tegen mij gekeerd. [^19] Mijn gebeente kleeft aan mijn huid en aan mijn vlees; en ik ben ontkomen met de huid mijner tanden. [^20] Ontfermt u mijner, ontfermt u mijner, o gij, mijn vrienden! want de hand Gods heeft mij aangeraakt. [^21] Waarom vervolgt gij mij als God, en wordt niet verzadigd van mijn vlees? [^22] Och, of nu mijn woorden toch opgeschreven wierden. Och, of zij in een boek ook wierden ingetekend! [^23] Dat zij met een ijzeren griffie en lood voor eeuwig in een rots gehouwen wierden! [^24] Want ik weet: mijn Verlosser leeft, en Hij zal de laatste over het stof opstaan; [^25] En als zij na mijn huid dit doorknaagd zullen hebben, zal ik uit mijn vlees God aanschouwen; [^26] Denwelken ik voor mij aanschouwen zal, en mijn ogen zien zullen, en niet een vreemde; mijn nieren verlangen zeer in mijn schoot. [^27] Voorwaar, gij zoudt zeggen: Waarom vervolgen wij hem? Nademaal de wortel der zaak in mij gevonden wordt. [^28] Schroomt u vanwege het zwaard; want de grimmigheid is over de misdaden des zwaards; opdat gij weet, dat er een gericht zij. [^29] 

[[Job - 18|<--]] Job - 19 [[Job - 20|-->]]

---
# Notes
