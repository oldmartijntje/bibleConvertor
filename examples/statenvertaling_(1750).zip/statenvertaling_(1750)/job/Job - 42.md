---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 42 - Statenvertaling (1750)"
---
[[Job - 41|<--]] Job - 42

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 42

Toen antwoordde Job den HEERE, en zeide: [^1] Ik weet, dat Gij alles vermoogt, en dat geen van Uw gedachten kan afgesneden worden. [^2] Wie is hij, zegt Gij, die den raad verbergt zonder wetenschap? Zo heb ik dan verhaald, hetgeen ik niet verstond, dingen, die voor mij te wonderbaar waren, die ik niet wist. [^3] Hoor toch, en ik zal spreken; ik zal U vragen, en onderricht Gij mij. [^4] Met het gehoor des oors heb ik U gehoord; maar nu ziet U mijn oog. [^5] Daarom verfoei ik mij, en ik heb berouw in stof en as. [^6] Het geschiedde nu, nadat de HEERE die woorden tot Job gesproken had, dat de HEERE tot Elifaz, den Themaniet, zeide: Mijn toorn is ontstoken tegen u, en tegen uw twee vrienden, want gijlieden hebt niet recht van Mij gesproken, gelijk Mijn knecht Job. [^7] Daarom neemt nu voor ulieden zeven varren en zeven rammen, en gaat henen tot Mijn knecht Job, en offert brandoffer voor ulieden, en laat Mijn knecht Job voor ulieden bidden; want zekerlijk, Ik zal zijn aangezicht aannemen, opdat Ik aan ulieden niet doe naar uw dwaasheid; want gijlieden hebt niet recht van Mij gesproken, gelijk Mijn knecht Job. [^8] Toen gingen Elifaz, de Themaniet, en Bildad, de Suhiet, en Zofar, de Naämathiet, henen, en deden, gelijk als de HEERE tot hen gesproken had; en de HEERE nam het aangezicht van Job aan. [^9] En de HEERE wendde de gevangenis van Job, toen hij gebeden had voor zijn vrienden; en de HEERE vermeerderde al hetgeen Job gehad had tot dubbel zoveel. [^10] Ook kwamen tot hem al zijn broeders, en al zijn zusters, en allen, die hem te voren gekend hadden, en aten brood met hem in zijn huis, en beklaagden hem, en vertroostten hem over al het kwaad, dat de HEERE over hem gebracht had; en zij gaven hem een iegelijk een stuk gelds, een iegelijk ook een gouden voorhoofdsiersel. [^11] En de HEERE zegende Jobs laatste meer dan zijn eerste; want hij had veertien duizend schapen, en zes duizend kemelen, en duizend juk runderen, en duizend ezelinnen. [^12] Daartoe had hij zeven zonen en drie dochteren. [^13] En hij noemde den naam der eerste Jemima, en den naam der tweede Kezia, en den naam der derde Keren-Happuch. [^14] En er werden zo schone vrouwen niet gevonden in het ganse land, als de dochteren van Job; en haar vader gaf haar erfdeel onder haar broederen. [^15] En Job leefde na dezen honderd en veertig jaren, dat hij zag zijn kinderen, en de kinderen zijner kinderen, tot in vier geslachten. [^16] En Job stierf, oud en der dagen zat. [^17] 

[[Job - 41|<--]] Job - 42

---
# Notes
