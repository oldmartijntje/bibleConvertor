---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 16 - Statenvertaling (1750)"
---
[[Job - 15|<--]] Job - 16 [[Job - 17|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 16

Maar Job antwoordde en zeide: [^1] Ik heb vele dergelijke dingen gehoord; gij allen zijt moeilijke vertroosters. [^2] Zal er een einde zijn aan de winderige woorden? Of wat stijft u, dat gij alzo antwoordt? [^3] Zou ik ook, als gijlieden, spreken, indien uw ziel ware in mijner ziele plaats? Zou ik woorden tegen u samenhopen, en zou ik over u met mijn hoofd schudden? [^4] Ik zou u versterken met mijn mond, en de beweging mijner lippen zou zich inhouden. [^5] Zo ik spreek, mijn smart wordt niet ingehouden; en houd ik op, wat gaat er van mij weg? [^6] Gewisselijk, Hij heeft mij nu vermoeid; Gij hebt mijn ganse vergadering verwoest. [^7] Dat Gij mij rimpelachtig gemaakt hebt, is tot een getuige; en mijn magerheid staat tegen mij op, zij getuigt in mijn aangezicht. [^8] Zijn toorn verscheurt, en Hij haat mij; Hij knerst over mij met Zijn tanden; mijn Wederpartijder scherpt Zijn ogen tegen mij. [^9] Zij gapen met hun mond tegen mij; zij slaan met smaadheid op mijn kinnebakken; zij vervullen zich te zamen aan mij. [^10] God heeft mij den verkeerde overgegeven, en heeft mij afgewend in de handen der goddelozen. [^11] Ik had rust, maar Hij heeft mij verbroken, en bij mijn nek gegrepen, en mij verpletterd; en Hij heeft mij Zich tot een doelwit opgericht. [^12] Zijn schutters hebben mij omringd; Hij heeft mijn nieren doorspleten, en niet gespaard; Hij heeft mijn gal op de aarde uitgegoten. [^13] Hij heeft mij gebroken met breuk op breuk; Hij is tegen mij aangelopen als een geweldige. [^14] Ik heb een zak over mijn huid genaaid; ik heb mijn hoorn in het stof gedaan. [^15] Mijn aangezicht is gans bemodderd van wenen, en over mijn oogleden is des doods schaduw. [^16] Daar toch geen wrevel in mijn handen is, en mijn gebed zuiver is. [^17] O, aarde! bedek mijn bloed niet; en voor mijn geroep zij geen plaats. [^18] Ook nu, zie, in den hemel is mijn Getuige, en mijn Getuige in de hoogten. [^19] Mijn vrienden zijn mijn bespotters; doch mijn oog druipt tot God. [^20] Och, mocht men rechten voor een man met God, gelijk een kind des mensen voor zijn vriend. [^21] Want weinige jaren in getal zullen er nog aankomen, en ik zal het pad henengaan, waardoor ik niet zal wederkeren. [^22] 

[[Job - 15|<--]] Job - 16 [[Job - 17|-->]]

---
# Notes
