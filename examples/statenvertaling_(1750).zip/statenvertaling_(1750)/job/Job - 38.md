---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 38 - Statenvertaling (1750)"
---
[[Job - 37|<--]] Job - 38 [[Job - 39|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 38

Daarna antwoordde de HEERE Job uit een onweder, en zeide: [^1] Wie is hij, die den raad verduistert met woorden zonder wetenschap? [^2] Gord nu, als een man, uw lenden, zo zal Ik u vragen, en onderricht Mij. [^3] Waar waart gij, toen Ik de aarde grondde? Geef het te kennen, indien gij kloek van verstand zijt. [^4] Wie heeft haar maten gezet, want gij weet het; of wie heeft over haar een richtsnoer getrokken? [^5] Waarop zijn haar grondvesten nedergezonken, of wie heeft haar hoeksteen gelegd? [^6] Toen de morgensterren te zamen vrolijk zongen, en al de kinderen Gods juichten. [^7] Of wie heeft de zee met deuren toegesloten, toen zij uitbrak, en uit de baarmoeder voortkwam? [^8] Toen Ik de wolk tot haar kleding stelde, en de donkerheid tot haar windeldoek; [^9] Toen Ik voor haar met Mijn besluit de aarde doorbrak, en zette grendel en deuren; [^10] En zeide: Tot hiertoe zult gij komen, en niet verder, en hier zal hij zich stellen tegen den hoogmoed uwer golven. [^11] Hebt gij van uw dagen den morgenstond geboden? Hebt gij den dageraad zijn plaats gewezen; [^12] Opdat hij de einden der aarde vatten zou; en de goddelozen uit haar uitgeschud zouden worden? [^13] Dat zij veranderd zou worden gelijk zegelleem, en zij gesteld worden als een kleed? [^14] En dat van de goddelozen hun licht geweerd worde, en de hoge arm worde gebroken? [^15] Zijt gij gekomen tot aan de oorsprongen der zee, en hebt gij in het onderste des afgronds gewandeld? [^16] Zijn u de poorten des doods ontdekt, en hebt gij gezien de poorten van de schaduw des doods? [^17] Zijt gij met uw verstand gekomen tot aan de breedte der aarde? Geef het te kennen, indien gij dit alles weet. [^18] Waar is de weg, daar het licht woont? En de duisternis, waar is haar plaats? [^19] Dat gij dat brengen zoudt tot zijn pale, en dat gij merken zoudt de paden zijns huizes? [^20] Gij weet het, want gij waart toen geboren, en uw dagen zijn veel in getal. [^21] Zijt gij gekomen tot de schatkameren der sneeuw, en hebt gij de schatkameren des hagels gezien? [^22] Dien Ik ophoude tot den tijd der benauwdheid, tot den dag des strijds en des oorlogs! [^23] Waar is de weg, daar het licht verdeeld wordt, en de oostenwind zich verstrooit op de aarde? [^24] Wie deelt voor den stortregen een waterloop uit, en een weg voor het weerlicht der donderen? [^25] Om te regenen op het land, waar niemand is, op de woestijn, waarin geen mens is; [^26] Om het woeste en het verwoeste te verzadigen, en om het uitspruitsel der grasscheutjes te doen wassen. [^27] Heeft de regen een vader, of wie baart de druppelen des dauws? [^28] Uit wiens buik komt het ijs voort, en wie baart den rijm des hemels? [^29] Als met een steen verbergen zich de wateren, en het vlakke des afgrond wordt omvat. [^30] Kunt gij de liefelijkheden van het Zevengesternte binden, of de strengen des Orions losmaken? [^31] Kunt gij de Mazzaroth voortbrengen op haar tijd, en den Wagen met zijn kinderen leiden? [^32] Weet gij de verordeningen des hemels, of kunt gij deszelfs heerschappij op de aarde bestellen? [^33] Kunt gij uw stem tot de wolken opheffen, opdat een overvloed van water u bedekke? [^34] Kunt gij de bliksemen uitlaten, dat zij henenvaren, en tot u zeggen: Zie, hier zijn wij? [^35] Wie heeft de wijsheid in het binnenste gezet? Of wie heeft den zin het verstand gegeven? [^36] Wie kan de wolken met wijsheid tellen, en wie kan de flessen des hemels nederleggen? [^37] Als het stof doorgoten is tot vastigheid, en de kluiten samenkleven? [^38] 

[[Job - 37|<--]] Job - 38 [[Job - 39|-->]]

---
# Notes
