---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 35 - Statenvertaling (1750)"
---
[[Job - 34|<--]] Job - 35 [[Job - 36|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 35

Elihu antwoordde verder, en zeide: [^1] Houdt gij dat voor recht, dat gij gezegd hebt: Mijn gerechtigheid is meerder dan Gods? [^2] Want gij hebt gezegd: Wat zou zij u baten? Wat meer voordeel zal ik daarmede doen, dan met mijn zonde? [^3] Ik zal u antwoord geven, en uw vrienden met u. [^4] Bemerk den hemel en zie; en aanschouw de bovenste wolken, zij zijn hoger dan gij. [^5] Indien gij zondigt, wat bedrijft gij tegen Hem? Indien uw overtredingen menigvuldig zijn, wat doet gij Hem? [^6] Indien gij rechtvaardig zijt, wat geeft gij Hem, of wat ontvangt Hij uit uw hand? [^7] Uw goddeloosheid zou zijn tegen een man, gelijk gij zijt, en uw gerechtigheid voor eens mensen kind. [^8] Vanwege hun grootheid doen zij de onderdrukten roepen; zij schreeuwen vanwege den arm der groten. [^9] Maar niemand zegt: Waar is God, mijn Maker, Die de psalmen geeft in den nacht? [^10] Die ons geleerder maakt dan de beesten der aarde, en ons wijzer maakt dan het gevogelte des hemels? [^11] Daar roepen zij; maar Hij antwoordt niet, vanwege den hoogmoed der bozen. [^12] Gewisselijk zal God de ijdelheid niet verhoren, en de Almachtige zal die niet aanschouwen. [^13] Dat gij ook gezegd hebt: Gij zult Hem niet aanschouwen; er is nochtans gericht voor Zijn aangezicht, wacht gij dan op Hem. [^14] Maar nu, dewijl het niets is, dat Zijn toorn Job bezocht heeft, en Hij hem niet zeer in overvloed doorkend heeft; [^15] Zo heeft Job in ijdelheid zijn mond geopend, en zonder wetenschap woorden vermenigvuldigd. [^16] 

[[Job - 34|<--]] Job - 35 [[Job - 36|-->]]

---
# Notes
