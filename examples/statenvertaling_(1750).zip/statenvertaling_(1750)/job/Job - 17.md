---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 17 - Statenvertaling (1750)"
---
[[Job - 16|<--]] Job - 17 [[Job - 18|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 17

Mijn geest is verdorven, mijn dagen worden uitgeblust, de graven zijn voor mij. [^1] Zijn niet bespotters bij mij, en overnacht niet mijn oog in hunlieder verbittering? [^2] Zet toch bij, stel mij een borg bij U; wie zal hij zijn? Dat in mijn hand geklapt worde. [^3] Want hun hart hebt Gij van kloek verstand verborgen; daarom zult Gij hen niet verhogen. [^4] Die met vleiïng den vrienden wat aanzegt, ook zijner kinderen ogen zullen versmachten. [^5] Doch Hij heeft mij tot een spreekwoord der volken gesteld; zodat ik een trommelslag ben voor ieders aangezicht. [^6] Daarom is mijn oog door verdriet verdonkerd, en al mijn ledematen zijn gelijk een schaduw. [^7] De oprechten zullen hierover verbaasd zijn, en de onschuldige zal zich tegen den huichelaar opmaken; [^8] En de rechtvaardige zal zijn weg vasthouden, en die rein van handen is, zal in sterkte toenemen. [^9] Maar toch gij allen, keert weder, en komt nu; want ik vind onder u geen wijze. [^10] Mijn dagen zijn voorbijgegaan; uitgerukt zijn mijn gedachten, de bezittingen mijns harten. [^11] Den nacht verstellen zij in den dag; het licht is nabij den ondergang vanwege de duisternis. [^12] Zo ik wacht, het graf zal mijn huis wezen; in de duisternis zal ik mijn bed spreiden. [^13] Tot de groeve roep ik: Gij zijt mijn vader! Tot het gewormte: Mijn moeder, en mijn zuster! [^14] Waar zou dan nu mijn verwachting wezen? Ja, mijn verwachting, wie zal ze aanschouwen? [^15] Zij zullen ondervaren met de handbomen des grafs, als er rust te zamen in het stof wezen zal. [^16] 

[[Job - 16|<--]] Job - 17 [[Job - 18|-->]]

---
# Notes
