---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 18 - Statenvertaling (1750)"
---
[[Job - 17|<--]] Job - 18 [[Job - 19|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 18

Toen antwoordde Bildad, de Suhiet, en zeide: [^1] Hoe lang is het, dat gijlieden een einde van woorden zult maken? Merkt op, en daarna zullen wij spreken. [^2] Waarom worden wij geacht als beesten, en zijn onrein in ulieder ogen? [^3] O gij, die zijn ziel verscheurt door zijn toorn! Zal om uwentwil de aarde verlaten worden, en zal een rots versteld worden uit haar plaats? [^4] Ja, het licht der goddelozen zal uitgeblust worden, en de vonk zijns vuurs zal niet glinsteren. [^5] Het licht zal verduisteren in zijn tent, en zijn lamp zal over hem uitgeblust worden. [^6] De treden zijner macht zullen benauwd worden, en zijn raad zal hem nederwerpen. [^7] Want met zijn voeten zal hij in het net geworpen worden, en zal in het wargaren wandelen. [^8] De strik zal hem bij de verzenen vatten; de struikrover zal hem overweldigen. [^9] Zijn touw is in de aarde verborgen, en zijn val op het pad. [^10] De beroeringen zullen hem rondom verschrikken, en hem verstrooien op zijn voeten. [^11] Zijn macht zal hongerig wezen, en het verderf is bereid aan zijn zijde. [^12] De eerstgeborene des doods zal de grendelen zijner huid verteren, zijn grendelen zal hij verteren. [^13] Zijn vertrouwen zal uit zijn tent uitgerukt worden; zulks zal hem doen treden tot den koning der verschrikkingen. [^14] Zij zal wonen in zijn tent, waar zij de zijne niet is; zijn woning zal met zwavel overstrooid worden. [^15] Van onder zullen zijn wortelen verdorren, en van boven zal zijn tak afgesneden worden. [^16] Zijn gedachtenis zal vergaan van de aarde, en hij zal geen naam hebben op de straten. [^17] Men zal hem stoten van het licht in de duisternis, en men zal hem van de wereld verjagen. [^18] Hij zal geen zoon, noch neef hebben onder zijn volk; en niemand zal in zijn woningen overig zijn. [^19] Over zijn dag zullen de nakomelingen verbaasd zijn, en de ouden met schrik bevangen worden. [^20] Gewisselijk, zodanige zijn de woningen des verkeerden, en dit is de plaats desgenen die God niet kent. [^21] 

[[Job - 17|<--]] Job - 18 [[Job - 19|-->]]

---
# Notes
