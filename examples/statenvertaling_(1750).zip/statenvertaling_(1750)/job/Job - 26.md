---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 26 - Statenvertaling (1750)"
---
[[Job - 25|<--]] Job - 26 [[Job - 27|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 26

Maar Job antwoordde en zeide: [^1] Hoe hebt gij geholpen dien, die zonder kracht is, en behouden den arm, die zonder sterkte is? [^2] Hoe hebt gij hem geraden, die geen wijsheid heeft, en de zaak, alzo zij is, ten volle bekend gemaakt? [^3] Aan wien hebt gij die woorden verhaald? En wiens geest is van u uitgegaan? [^4] De doden zullen geboren worden van onder de wateren, en hun inwoners. [^5] De hel is naakt voor Hem, en geen deksel is er voor het verderf. [^6] Hij breidt het noorden uit over het woeste; Hij hangt de aarde aan een niet. [^7] Hij bindt de wateren in Zijn wolken; nochtans scheurt de wolk daaronder niet. [^8] Hij houdt het vlakke Zijns troons vast; Hij spreidt Zijn wolk daarover. [^9] Hij heeft een gezet perk over het vlakke der wateren rondom afgetekend, tot aan de voleinding toe des lichts met de duisternis. [^10] De pilaren des hemels sidderen, en ontzetten zich voor Zijn schelden. [^11] Door Zijn kracht klieft Hij de zee, en door Zijn verstand verslaat Hij haar verheffing. [^12] Door Zijn Geest heeft Hij de hemelen versierd; Zijn hand heeft de langwemelende slang geschapen. [^13] Ziet, dit zijn maar uiterste einden Zijner wegen; en wat een klein stukje der zaak hebben wij van Hem gehoord? Wie zou dan den donder Zijner mogendheden verstaan? [^14] 

[[Job - 25|<--]] Job - 26 [[Job - 27|-->]]

---
# Notes
