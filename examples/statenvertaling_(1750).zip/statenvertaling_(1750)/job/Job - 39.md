---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 39 - Statenvertaling (1750)"
---
[[Job - 38|<--]] Job - 39 [[Job - 40|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 39

Zult gij voor den ouden leeuw roof jagen, of de graagheid der jonge leeuwen vervullen? [^1] Als zij nederbukken in de holen, en in den kuil zitten, ter loering? [^2] Wie bereidt de raaf haar kost, als haar jongen tot God schreeuwen, als zij dwalen, omdat er geen eten is? [^3] Weet gij den tijd van het baren der steengeiten? Hebt gij waargenomen den arbeid der hinden? [^4] Zult gij de maanden tellen, die zij vervullen, en weet gij den tijd van haar baren? [^5] Als zij zich krommen, haar jongen met versplijting voortbrengen, haar smarten uitwerpen? [^6] Haar jongen worden kloek, worden groot door het koren; zij gaan uit, en keren niet weder tot dezelve. [^7] Wie heeft den woudezel vrij henengezonden, en wie heeft de banden des wilden ezels gelost? [^8] Dien Ik de wildernis tot zijn huis besteld heb, en het ziltige tot zijn woningen. [^9] Hij belacht het gewoel der stad; het menigerlei getier des drijvers hoort hij niet. [^10] Dat hij uitspeurt op de bergen, is zijn weide; en hij zoekt allerlei groensel na. [^11] Zal de eenhoorn u willen dienen? Zal hij vernachten aan uw kribbe? [^12] Zult gij den eenhoorn met zijn touw aan de voren binden? Zal hij de laagten achter u eggen? [^13] Zult gij op hem vertrouwen, omdat zijn kracht groot is, en zult gij uw arbeid op hem laten? [^14] Zult gij hem geloven, dat hij uw zaad zal wederbrengen, en vergaderen tot uw dorsvloer? [^15] Zijn van u de verheugelijke vleugelen der pauwen? Of de vederen des ooievaars, en des struisvogels? [^16] Dat zij haar eieren in de aarde laat, en in het stof die verwarmt, [^17] En vergeet, dat de voet die drukken kan, en de dieren des velds die vertrappen kunnen? [^18] Zij verhardt zich tegen haar jongen, alsof zij de hare niet waren; haar arbeid is tevergeefs, omdat zij zonder vreze is. [^19] Want God heeft haar van wijsheid ontbloot, en heeft haar des verstands niets medegedeeld. [^20] Als het tijd is, verheft zij zich in de hoogte; zij belacht het paard en zijn rijder. [^21] Zult gij het paard sterkte geven? Kunt gij zijn hals met donder bekleden? [^22] Zult gij het beroeren als een sprinkhaan? De pracht van zijn gesnuif is een verschrikking. [^23] Het graaft in den grond, en het is vrolijk in zijn kracht; en trekt uit, den geharnaste tegemoet. [^24] Het belacht de vreze, en wordt niet ontsteld, en keert niet wederom vanwege het zwaard. [^25] Tegen hem ratelt de pijlkoker, het vlammig ijzer des spies en der lans. [^26] Met schudding en beroering slokt het de aarde op, en gelooft niet, dat het is het geluid der bazuin. [^27] In het volle geklank der bazuin, zegt het: Heah! en ruikt den krijg van verre, den donder der vorsten en het gejuich. [^28] Vliegt de sperwer door uw verstand, en breidt hij zijn vleugelen uit naar het zuiden? [^29] Is het naar uw bevel, dat de arend zich omhoog verheft, en dat hij zijn nest in de hoogte maakt? [^30] Hij woont en vernacht in de steenrots, op de scherpte der steenrots en der vaste plaats. [^31] Van daar speurt hij de spijze op; zijn ogen zien van verre af. [^32] Ook zuipen zijn jongen bloed; en waar verslagenen zijn, daar is hij. [^33] En de HEERE antwoordde Job, en zeide: [^34] Is het twisten met den Almachtige onderrichten? Wie God bestraft, die antwoorde daarop. [^35] Toen antwoordde Job den HEERE, en zeide: [^36] Zie, ik ben te gering; wat zou ik U antwoorden? Ik leg mijn hand op mijn mond. [^37] Eenmaal heb ik gesproken, maar zal niet antwoorden; of tweemaal, maar zal niet voortvaren. [^38] 

[[Job - 38|<--]] Job - 39 [[Job - 40|-->]]

---
# Notes
