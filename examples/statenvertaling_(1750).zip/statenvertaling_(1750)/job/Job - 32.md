---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 32 - Statenvertaling (1750)"
---
[[Job - 31|<--]] Job - 32 [[Job - 33|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 32

Toen hielden de drie mannen op van Job te antwoorden, dewijl hij in zijn ogen rechtvaardig was. [^1] Zo ontstak de toorn van Elihu, den zoon van Baracheël, den Buziet, van het geslacht van Ram; tegen Job werd zijn toorn ontstoken, omdat hij zijn ziel meer rechtvaardigde dan God. [^2] Zijn toorn ontstak ook tegen zijn drie vrienden, omdat zij, geen antwoord vindende, nochtans Job verdoemden. [^3] Doch Elihu had gewacht op Job in het spreken, omdat zij ouder van dagen waren dan hij. [^4] Als dan Elihu zag, dat er geen antwoord was in den mond van die drie mannen, ontstak zijn toorn. [^5] Hierom antwoordde Elihu, de zoon van Baracheël, den Buziet, en zeide: Ik ben minder van dagen, maar gijlieden zijt stokouden; daarom heb ik geschroomd en gevreesd, ulieden mijn gevoelen te vertonen. [^6] Ik zeide: Laat de dagen spreken, en de veelheid der jaren wijsheid te kennen geven. [^7] Zekerlijk de geest, die in den mens is, en de inblazing des Almachtigen, maakt henlieden verstandig. [^8] De groten zijn niet wijs, en de ouden verstaan het recht niet. [^9] Daarom zeg ik: Hoor naar mij; ik zal mijn gevoelen ook vertonen. [^10] Ziet, ik heb gewacht op ulieder woorden; ik heb het oor gewend tot ulieder aanmerkingen, totdat gij redenen uitgezocht hadt. [^11] Als ik nu acht op u gegeven heb, ziet, er is niemand, die Job overreedde, die uit ulieden zijn redenen beantwoordde; [^12] Opdat gij niet zegt: Wij hebben de wijsheid gevonden; God heeft hem nedergestoten, geen mens. [^13] Nu heeft hij tegen mij geen woorden gericht, en met ulieder woorden zal ik hem niet beantwoorden. [^14] Zij zijn ontzet, zij antwoorden niet meer; zij hebben de woorden van zich verzet. [^15] Ik heb dan gewacht, maar zij spreken niet; want zij staan stil; zij antwoorden niet meer. [^16] Ik zal mijn deel ook antwoorden, ik zal mijn gevoelen ook vertonen. [^17] Want ik ben der woorden vol; de geest mijns buiks benauwt mij. [^18] Ziet, mijn buik is als de wijn, die niet geopend is; gelijk nieuwe lederen zakken zou hij bersten. [^19] Ik zal spreken, opdat ik voor mij lucht krijge; ik zal mijn lippen openen, en zal antwoorden. [^20] Och, dat ik niemands aangezicht aanneme, en tot den mens geen bijnamen gebruike! [^21] Want ik weet geen bijnamen te gebruiken; in kort zou mijn Maker mij wegnemen. [^22] 

[[Job - 31|<--]] Job - 32 [[Job - 33|-->]]

---
# Notes
