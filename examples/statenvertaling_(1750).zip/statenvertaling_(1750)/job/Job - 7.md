---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 7 - Statenvertaling (1750)"
---
[[Job - 6|<--]] Job - 7 [[Job - 8|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 7

Heeft niet de mens een strijd op de aarde, en zijn zijn dagen niet als de dagen des dagloners? [^1] Gelijk de dienstknecht hijgt naar de schaduw, en gelijk de dagloner verwacht zijn werkloon; [^2] Alzo zijn mij maanden der ijdelheid ten erve geworden, en nachten der moeite zijn mij voorbereid. [^3] Als ik te slapen lig, dan zeg ik: Wanneer zal ik opstaan, en Hij den avond afgemeten hebben? En ik word zat van woelingen tot aan den schemertijd. [^4] Mijn vlees is met het gewormte en met het gruis des stofs bekleed; mijn huid is gekliefd en verachtelijk geworden. [^5] Mijn dagen zijn lichter geweest dan een weversspoel, en zijn vergaan zonder verwachting. [^6] Gedenk, dat mijn leven een wind is; mijn oog zal niet wederkomen, om het goede te zien. [^7] Het oog desgenen, die mij nu ziet, zal mij niet zien; Uw ogen zullen op mij zijn; maar ik zal niet meer zijn. [^8] Een wolk vergaat en vaart henen; alzo die in het graf daalt, zal niet weder opkomen. [^9] Hij zal niet meer wederkeren tot zijn huis, en zijn plaats zal hem niet meer kennen. [^10] Zo zal ik ook mijn mond niet wederhouden, ik zal spreken in benauwdheid mijns geestes; ik zal klagen in bitterheid mijner ziel. [^11] Ben ik dan een zee, of walvis, dat Gij om mij een wacht zet? [^12] Wanneer ik zeg: Mijn bedstede zal mij vertroosten, mijn leger zal van mijn klacht wat wegnemen; [^13] Dan ontzet Gij mij met dromen, en door gezichten verschrikt Gij mij; [^14] Zodat mijn ziel de verworging kiest; den dood meer dan mijn beenderen. [^15] Ik versmaad ze, ik zal toch in der eeuwigheid niet leven; houd op van mij, want mijn dagen zijn ijdelheid. [^16] Wat is de mens, dat Gij hem groot acht, en dat Gij Uw hart op hem zet? [^17] En dat Gij hem bezoekt in elken morgenstond; dat Gij hem in elken ogenblik beproeft? [^18] Hoe lang keert Gij U niet af van mij, en laat niet van mij af, totdat ik mijn speeksel inzwelge? [^19] Heb ik gezondigd, wat zal ik U doen, o Mensenhoeder? Waarom hebt Gij mij U tot een tegenloop gesteld, dat ik mijzelven tot een last zij? [^20] En waarom vergeeft Gij niet mijn overtreding, en doet mijn ongerechtigheid niet weg? Want nu zal ik in het stof liggen; en Gij zult mij vroeg zoeken, maar ik zal niet zijn. [^21] 

[[Job - 6|<--]] Job - 7 [[Job - 8|-->]]

---
# Notes
