---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 22 - Statenvertaling (1750)"
---
[[Job - 21|<--]] Job - 22 [[Job - 23|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 22

Toen antwoordde Elifaz, de Themaniet, en zeide: [^1] Zal ook een man Gode voordelig zijn? Maar voor zichzelven zal de verstandige voordelig zijn. [^2] Is het voor den Almachtige nuttigheid, dat gij rechtvaardig zijt; of gewin, dat gij uw wegen volmaakt? [^3] Is het om uw vreze, dat Hij u bestraft, dat Hij met u in het gericht komt? [^4] Is niet uw boosheid groot, en uwer ongerechtigheden geen einde? [^5] Want gij hebt uw broederen zonder oorzaak pand afgenomen, en de klederen der naakten hebt gij uitgetogen. [^6] Den moede hebt gij geen water te drinken gegeven, en van den hongerige hebt gij het brood onthouden. [^7] Maar was er een man van geweld, voor dien was het land, en een aanzienlijk persoon woonde daarin. [^8] De weduwen hebt gij ledig weggezonden, en de armen der wezen zijn verbrijzeld. [^9] Daarom zijn strikken rondom u, en vervaardheid heeft u haastelijk beroerd. [^10] Of gij ziet de duisternis niet, en des water overvloed bedekt u. [^11] Is niet God in de hoogte der hemelen? Zie toch het opperste der sterren aan, dat zij verheven zijn. [^12] Daarom zegt gij: Wat weet er God van? Zal Hij door de donkerheid oordelen? [^13] De wolken zijn Hem een verberging, dat Hij niet ziet; en Hij bewandelt den omgang der hemelen. [^14] Hebt gij het pad der eeuw waargenomen, dat de ongerechtige lieden betreden hebben? [^15] Die rimpelachtig gemaakt zijn, als het de tijd niet was; een vloed is over hun grond uitgestort; [^16] Die zeiden tot God: Wijk van ons! En wat had de Almachtige hun gedaan? [^17] Hij had immers hun huizen met goed gevuld; daarom is de raad der goddelozen verre van mij. [^18] De rechtvaardigen zagen het, en waren blijde, en de onschuldige bespotte hen; [^19] Dewijl onze stand niet verdelgd is, maar het vuur hun overblijfsel verteerd heeft. [^20] Gewen u toch aan Hem, en heb vrede; daardoor zal u het goede overkomen. [^21] Ontvang toch de wet uit Zijn mond, en leg Zijn redenen in uw hart. [^22] Zo gij u bekeert tot den Almachtige, gij zult gebouwd worden; doe het onrecht verre van uw tenten. [^23] Dan zult gij het goud op het stof leggen, en het goud van Ofir bij den rotssteen der beken; [^24] Ja, de Almachtige zal uw overvloedig goud zijn, en uw krachtig zilver zijn; [^25] Want dan zult gij u over den Almachtige verlustigen, en gij zult tot God uw aangezicht opheffen. [^26] Gij zult tot Hem ernstiglijk bidden, en Hij zal u verhoren; en gij zult uw geloften betalen. [^27] Als gij een zaak besluit, zo zal zij u bestendig zijn; en op uw wegen zal het licht schijnen. [^28] Als men iemand vernederen zal, en gij zeggen zult: Het zij verhoging; dan zal God den nederige van ogen behouden. [^29] Ja, Hij zal dien bevrijden, die niet onschuldig is, want hij wordt bevrijd door de zuiverheid uwer handen. [^30] 

[[Job - 21|<--]] Job - 22 [[Job - 23|-->]]

---
# Notes
