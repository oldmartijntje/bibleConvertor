---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 2 - Statenvertaling (1750)"
---
[[Job - 1|<--]] Job - 2 [[Job - 3|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 2

Wederom was er een dag, als de kinderen Gods kwamen, om zich voor den HEERE te stellen, dat de satan ook in het midden van hen kwam, om zich voor den HEERE te stellen. [^1] Toen zeide de HEERE tot den satan: Van waar komt gij? En de satan antwoordde den HEERE, en zeide: Van om te trekken op de aarde, en van die te doorwandelen. [^2] En de HEERE zeide tot den satan: Hebt gij ook acht geslagen op Mijn knecht Job? Want niemand is op de aarde gelijk hij, een man, oprecht en vroom, godvrezende en wijkende van het kwaad; en hij houdt nog vast aan zijn oprechtigheid, hoewel gij Mij tegen hem opgehitst hebt, om hem te verslinden zonder oorzaak. [^3] Toen antwoordde de satan den HEERE, en zeide: Huid voor huid, en al wat iemand heeft, zal hij geven voor zijn leven. [^4] Doch strek nu Uw hand uit, en tast zijn gebeente en zijn vlees aan; zo hij U niet in Uw aangezicht zal zegenen! [^5] En de HEERE zeide tot den satan: Zie, hij zij in uw hand, doch verschoon zijn leven. [^6] Toen ging de satan uit van het aangezicht des HEEREN, en sloeg Job met boze zweren, van zijn voetzool af tot zijn schedel toe. [^7] En hij nam zich een potscherf, om zich daarmede te schrabben, en hij zat neder in het midden der as. [^8] Toen zeide zijn huisvrouw tot hem: Houdt gij nog vast aan uw oprechtigheid? Zegen God, en sterf. [^9] Maar hij zeide tot haar: Gij spreekt als een der zottinnen spreekt; ja, zouden wij het goede van God ontvangen, en het kwade niet ontvangen? In dit alles zondigde Job met zijn lippen niet. [^10] Als nu de drie vrienden van Job gehoord hadden al dit kwaad, dat over hem gekomen was, kwamen zij, ieder uit zijn plaats, Elifaz, de Themaniet, en Bildad, de Suhiet, en Zofar, de Naämathiet; en zij waren het eens geworden, dat zij kwamen om hem te beklagen, en om hem te vertroosten. [^11] En toen zij hun ogen van verre ophieven, kenden zij hem niet, en hieven hun stem op, en weenden; daartoe scheurden zij een ieder zijn mantel, en strooiden stof op hun hoofden naar den hemel. [^12] Alzo zaten zij met hem op de aarde, zeven dagen en zeven nachten; en niemand sprak tot hem een woord, want zij zagen, dat de smart zeer groot was. [^13] 

[[Job - 1|<--]] Job - 2 [[Job - 3|-->]]

---
# Notes
