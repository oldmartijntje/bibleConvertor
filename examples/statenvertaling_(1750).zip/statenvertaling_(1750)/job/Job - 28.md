---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 28 - Statenvertaling (1750)"
---
[[Job - 27|<--]] Job - 28 [[Job - 29|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 28

Gewisselijk, er is voor het zilver een uitgang, en een plaats voor het goud, dat zij smelten. [^1] Het ijzer wordt uit stof genomen, en uit steen wordt koper gegoten. [^2] Het einde, dat God gesteld heeft voor de duisternis, en al het uiterste onderzoekt hij; het gesteente der donkerheid en der schaduw des doods. [^3] Breekt er een beek door, bij dengene, die daar woont, de wateren vergeten zijnde van den voet, worden van den mens uitgeput, en gaan weg. [^4] Uit de aarde komt het brood voort, en onder zich wordt zij veranderd, alsof zij vuur ware. [^5] Haar stenen zijn de plaats van den saffier, en zij heeft stofjes van goud. [^6] De roofvogel heeft het pad niet gekend, en het oog der kraai heeft het niet gezien. [^7] De jonge hoogmoedige dieren hebben het niet betreden, de felle leeuw is daarover niet heengegaan. [^8] Hij legt zijn hand aan de keiachtige rots, hij keert de bergen van den wortel om. [^9] In de rotsstenen houwt hij stromen uit, en zijn oog ziet al het kostelijke. [^10] Hij bindt de rivier toe, dat niet een traan uitkomt, en het verborgene brengt hij uit in het licht. [^11] Maar de wijsheid, van waar zal zij gevonden worden? En waar is de plaats des verstands? [^12] De mens weet haar waarde niet, en zij wordt niet gevonden in het land der levenden. [^13] De afgrond zegt: Zij is in mij niet; en de zee zegt: Zij is niet bij mij. [^14] Het gesloten goud kan voor haar niet gegeven worden, en met zilver kan haar prijs niet worden opgewogen. [^15] Zij kan niet geschat worden tegen fijn goud van Ofir, tegen den kostelijken Schoham, en den Saffier. [^16] Men kan het goud of het kristal haar niet gelijk waarderen; ook is zij niet te verwisselen voor een kleinood van dicht goud. [^17] De Ramoth en Gabisch zal niet gedacht worden; want de trek der wijsheid is meerder dan der Robijnen. [^18] Men kan de Topaas van Morenland haar niet gelijk waarderen; en bij het fijn louter goud kan zij niet geschat worden. [^19] De wijsheid dan, van waar komt zij, en waar is de plaats des verstands? [^20] Want zij is verholen voor de ogen aller levenden, en voor het gevogelte des hemels is zij verborgen. [^21] Het verderf en de dood zeggen: Haar gerucht hebben wij met onze oren gehoord. [^22] God verstaat haar weg, en Hij weet haar plaats. [^23] Want Hij schouwt tot aan de einden der aarde, Hij ziet onder al de hemelen. [^24] Als Hij den wind het gewicht maakte, en de wateren opwoog in mate; [^25] Als Hij den regen een gezette orde maakte, en een weg voor het weerlicht der donderen; [^26] Toen zag Hij haar, en vertelde ze; Hij schikte ze, en ook doorzocht Hij ze. [^27] Maar tot den mens heeft Hij gezegd: Zie, de vreze des Heeren is de wijsheid, en van het kwade te wijken is het verstand. [^28] 

[[Job - 27|<--]] Job - 28 [[Job - 29|-->]]

---
# Notes
