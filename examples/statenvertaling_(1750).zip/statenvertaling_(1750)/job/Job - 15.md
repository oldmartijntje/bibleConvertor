---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 15 - Statenvertaling (1750)"
---
[[Job - 14|<--]] Job - 15 [[Job - 16|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 15

Toen antwoordde Elifaz, de Themaniet, en zeide: [^1] Zal een wijs man winderige wetenschap voor antwoord geven, en zal hij zijn buik vullen met oostenwind? [^2] Bestraffende door woorden, die niet baten, en door redenen, met dewelke hij geen voordeel doet? [^3] Ja, gij vernietigt de vreze, en neemt het gebed voor het aangezicht Gods weg. [^4] Want uw mond leert uw ongerechtigheid, en gij hebt de tong der arglistigen verkoren. [^5] Uw mond verdoemt u, en niet ik; en uw lippen getuigen tegen u. [^6] Zijt gij de eerste een mens geboren? Of zijt gij voor de heuvelen voortgebracht? [^7] Hebt gij den verborgen raad Gods gehoord, en hebt gij de wijsheid naar u getrokken? [^8] Wat weet gij, dat wij niet weten? Wat verstaat gij, dat bij ons niet is? [^9] Onder ons is ook een grijze, ja, een stokoude, meerder van dagen dan uw vader. [^10] Zijn de vertroostingen Gods u te klein, en schuilt er enige zaak bij u? [^11] Waarom rukt uw hart u weg, en waarom wenken uw ogen? [^12] Dat gij uw geest keert tegen God, en zulke redenen uit uw mond laat uitgaan. [^13] Wat is de mens, dat hij zuiver zou zijn, en die geboren is van een vrouw, dat hij rechtvaardig zou zijn? [^14] Zie, op Zijn heiligen zou Hij niet vertrouwen, en de hemelen zijn niet zuiver in Zijn ogen. [^15] Hoeveel te meer is een man gruwelijk en stinkende, die het onrecht indrinkt als water? [^16] Ik zal u wijzen, hoor mij aan, en hetgeen ik gezien heb, dat zal ik vertellen; [^17] Hetwelk de wijzen verkondigd hebben, en men voor hun vaderen niet verborgen heeft; [^18] Denwelken alleen het land gegeven was, en door welker midden niemand vreemds doorging. [^19] Te allen dage doet de goddeloze zichzelven weedom aan; en weinige jaren in getal zijn voor den tiran weggelegd. [^20] Het geluid der verschrikkingen is in zijn oren; in den vrede zelven komt de verwoester hem over. [^21] Hij gelooft niet uit de duisternis weder te keren, maar dat hij beloerd wordt ten zwaarde. [^22] Hij zwerft heen en weder om brood, waar het zijn mag; hij weet, dat bij zijn hand gereed is de dag der duisternis. [^23] Angst en benauwdheid verschrikken hem; zij overweldigt hem, gelijk een koning, bereid ten strijde. [^24] Want hij strekt tegen God zijn hand uit, en tegen den Almachtige stelt hij zich geweldiglijk aan. [^25] Hij loopt tegen Hem aan met den hals, met zijn dikke, hoog verhevene schilden; [^26] Omdat hij zijn aangezicht met zijn vet bedekt heeft, en rimpelen gemaakt om de weekdarmen; [^27] En heeft bewoond verdelgde steden, en huizen, die men niet bewoonde, die gereed waren tot steen hopen te worden. [^28] Hij zal niet rijk worden, en zijn vermogen zal niet bestaan; en hun volmaaktheid zal zich niet uitbreiden op de aarde. [^29] Hij zal van de duisternis niet ontwijken, de vlam zal zijn scheut verdrogen; hij zal wijken door het geblaas zijns monds. [^30] Hij betrouwe niet op ijdelheid, waardoor hij verleid wordt; want ijdelheid zal zijn vergelding wezen. [^31] Als zijn dag nog niet is, zal hij vervuld worden; want zijn tak zal niet groenen. [^32] Men zal zijn onrijpe druiven afrukken, als van een wijnstok, en zijn bloeisel afwerpen, als van een olijfboom. [^33] Want de vergadering der huichelaren wordt eenzaam, en het vuur verteert de tenten der geschenken. [^34] Zijn ontvangen moeite, en baren ijdelheid, en hun buik richt bedrog aan. [^35] 

[[Job - 14|<--]] Job - 15 [[Job - 16|-->]]

---
# Notes
