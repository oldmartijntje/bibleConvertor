---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 14 - Statenvertaling (1750)"
---
[[Job - 13|<--]] Job - 14 [[Job - 15|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 14

De mens, van een vrouw geboren, is kort van dagen, en zat van onrust. [^1] Hij komt voort als een bloem, en wordt afgesneden; ook vlucht hij als een schaduw, en bestaat niet. [^2] Nog doet Gij Uw ogen over zulk een open; en Gij betrekt mij in het gericht met U. [^3] Wie zal een reine geven uit den onreine? Niet één. [^4] Dewijl zijn dagen bestemd zijn, het getal zijner maanden bij U is, en Gij zijn bepalingen gemaakt hebt, die hij niet overgaan zal; [^5] Wend U van hem af, dat hij rust hebbe, totdat hij als een dagloner aan zijn dag een welgevallen hebbe. [^6] Want voor een boom, als hij afgehouwen wordt, is er verwachting, dat hij zich nog zal veranderen, en zijn scheut niet zal ophouden. [^7] Indien zijn wortel in de aarde veroudert, en zijn stam in het stof versterft; [^8] Hij zal van den reuk der wateren weder uitspruiten, en zal een tak maken, gelijk een plant. [^9] Maar een man sterft, als hij verzwakt is, en de mens geeft den geest, waar is hij dan? [^10] De wateren verlopen uit een meer, en een rivier droogt uit en verdort; [^11] Alzo ligt de mens neder, en staat niet op; totdat de hemelen niet meer zijn, zullen zij niet opwaken, noch uit hun slaap opgewekt worden. [^12] Och, of Gij mij in het graf verstaakt, mij verborgt, totdat Uw toorn zich afkeerde; dat Gij mij een bepaling steldet, en mijner gedachtig waart! [^13] Als een man gestorven is, zal hij weder leven? Ik zou al de dagen mijns strijds hopen, totdat mijn verandering komen zou. [^14] Dat Gij zoudt roepen, en ik U zou antwoorden, dat Gij tot het werk Uwer handen zoudt begerig zijn. [^15] Maar nu telt Gij mijn treden; Gij bewaart mij niet om mijner zonden wil. [^16] Mijn overtreding is in een bundeltje verzegeld, en Gij pakt mijn ongerechtigheid opeen. [^17] En voorwaar, een berg vallende vergaat, en een rots wordt versteld uit haar plaats; [^18] De wateren vermalen de stenen, het stof der aarde overstelpt het gewas, dat vanzelf daaruit voortkomt; alzo verderft Gij de verwachting des mensen. [^19] Gij overweldigt hem in eeuwigheid, en hij gaat heen; veranderende zijn gelaat, zo zendt Gij hem weg. [^20] Zijn kinderen komen tot eer, en hij weet het niet; of zij worden klein, en hij let niet op hen. [^21] Maar zijn vlees, nog aan hem zijnde, heeft smart; en zijn ziel, in hem zijnde, heeft rouw. [^22] 

[[Job - 13|<--]] Job - 14 [[Job - 15|-->]]

---
# Notes
