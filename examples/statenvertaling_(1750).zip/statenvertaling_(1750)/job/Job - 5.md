---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 5 - Statenvertaling (1750)"
---
[[Job - 4|<--]] Job - 5 [[Job - 6|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 5

Roep nu, zal er iemand zijn, die u antwoorde? En tot wien van de heiligen zult gij u keren? [^1] Want den dwaze brengt de toornigheid om, en de ijver doodt den slechte. [^2] Ik heb gezien een dwaas wortelende; doch terstond vervloekte ik zijn woning. [^3] Verre waren zijn zonen van heil; en zij werden verbrijzeld in de poort, en er was geen verlosser. [^4] Wiens oogst de hongerige verteerde, dien hij ook tot uit de doornen gehaald had; de struikrover slokte hun vermogen in. [^5] Want uit het stof komt het verdriet niet voort, en de moeite spruit niet uit de aarde; [^6] Maar de mens wordt tot moeite geboren; gelijk de spranken der vurige kolen zich verheffen tot vliegen. [^7] Doch ik zou naar God zoeken, en tot God mijn aanspraak richten; [^8] Die grote dingen doet, die men niet doorzoeken kan; wonderen, die men niet tellen kan; [^9] Die den regen geeft op de aarde, en water zendt op de straten; [^10] Om de vernederden te stellen in het hoge; dat de rouwdragenden door heil verheven worden. [^11] Hij maakt te niet de gedachten der arglistigen; dat hun handen niet een ding uitrichten. [^12] Hij vangt de wijzen in hun arglistigheid; dat de raad der verdraaiden gestort wordt. [^13] Des daags ontmoeten zij de duisternis, en gelijk des nachts tasten zij in den middag. [^14] Maar Hij verlost den behoeftige van het zwaard, van hun mond, en van de hand des sterken. [^15] Zo is voor den arme verwachting; en de boosheid stopt haar mond toe. [^16] Zie, gelukzalig is de mens, denwelken God straft; daarom verwerp de kastijding des Almachtigen niet. [^17] Want Hij doet smart aan, en Hij verbindt; Hij doorwondt, en Zijn handen helen. [^18] In zes benauwdheden zal Hij u verlossen, en in de zevende zal u het kwaad niet aanroeren. [^19] In den honger zal Hij u verlossen van den dood, en in den oorlog van het geweld des zwaards. [^20] Tegen den gesel der tong zult gij verborgen wezen, en gij zult niet vrezen voor de verwoesting, als zij komt. [^21] Tegen de verwoesting en tegen den honger zult gij lachen, en voor het gedierte der aarde zult gij niet vrezen. [^22] Want met de stenen des velds zal uw verbond zijn, en het gedierte des velds zal met u bevredigd zijn. [^23] En gij zult bevinden, dat uw tent in vrede is; en gij zult uw woning verzorgen, en zult niet feilen. [^24] Ook zult gij bevinden, dat uw zaad menigvuldig wezen zal, en uw spruiten als het kruid der aarde. [^25] Gij zult in ouderdom ten grave komen, gelijk de korenhoop te zijner tijd opgevoerd wordt. [^26] Zie dit, wij hebben het doorzocht, het is alzo; hoor het, en bemerk gij het voor u. [^27] 

[[Job - 4|<--]] Job - 5 [[Job - 6|-->]]

---
# Notes
