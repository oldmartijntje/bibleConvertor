---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 37 - Statenvertaling (1750)"
---
[[Job - 36|<--]] Job - 37 [[Job - 38|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 37

Ook beeft hierover mijn hart, en springt op uit zijn plaats. [^1] Hoort met aandacht de beweging Zijner stem, en het geluid, dat uit Zijn mond uitgaat! [^2] Dat zendt Hij rechtuit onder den gansen hemel, en Zijn licht over de einden der aarde. [^3] Daarna brult Hij met de stem; Hij dondert met de stem Zijner hoogheid, en vertrekt die dingen niet, als Zijn stem zal gehoord worden. [^4] God dondert met Zijn stem zeer wonderlijk; Hij doet grote dingen, en wij begrijpen ze niet. [^5] Want Hij zegt tot de sneeuw: Wees op de aarde; en tot den plasregen des regens; dan is er de plasregen Zijner sterke regenen. [^6] Dan zegelt Hij de hand van ieder mens toe, opdat Hij kenne al de lieden Zijns werks. [^7] En het gedierte gaat in de loerplaatsen, en blijft in zijn holen. [^8] Uit de binnenkamer komt de wervelwind, en van de verstrooiende winden de koude. [^9] Door Zijn geblaas geeft God de vorst, zodat de brede wateren verstijfd worden. [^10] Ook vermoeit Hij de dikke wolken door klaarheid; Hij verstrooit de wolk Zijns lichts. [^11] Die keert zich dan naar Zijn wijzen raad door ommegangen, dat zij doen al wat Hij ze gebiedt, op het vlakke der wereld, op de aarde. [^12] Hetzij dat Hij die tot een roede, of tot Zijn land, of tot weldadigheid beschikt. [^13] Neem dit, o Job, ter ore; sta, en aanmerk de wonderen Gods. [^14] Weet gij, wanneer God over dezelve orde stelt, en het licht Zijner wolk laat schijnen? [^15] Hebt gij wetenschap van de opwegingen der dikke wolken; de wonderheden Desgenen, Die volmaakt is in wetenschappen? [^16] Hoe uw klederen warm worden, als Hij de aarde stil maakt uit het zuiden? [^17] Hebt gij met Hem de hemelen uitgespannen, die vast zijn, als een gegoten spiegel? [^18] Onderricht ons, wat wij Hem zeggen zullen; want wij zullen niets ordentelijk voorstellen kunnen vanwege de duisternis. [^19] Zal het Hem verteld worden, als ik zo zou spreken? Denkt iemand dat, gewisselijk, hij zal verslonden worden. [^20] En nu ziet men het licht niet als het helder is in den hemel, als de wind doorgaat, en dien zuivert; [^21] Als van het noorden het goud komt; maar bij God is een vreselijke majesteit! [^22] Den Almachtige, Dien kunnen wij niet uitvinden; Hij is groot van kracht; doch door gericht en grote gerechtigheid verdrukt Hij niet. [^23] Daarom vrezen Hem de lieden; Hij ziet geen wijzen van harte aan. [^24] 

[[Job - 36|<--]] Job - 37 [[Job - 38|-->]]

---
# Notes
