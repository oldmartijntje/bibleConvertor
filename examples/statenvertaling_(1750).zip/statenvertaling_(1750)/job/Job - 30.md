---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 30 - Statenvertaling (1750)"
---
[[Job - 29|<--]] Job - 30 [[Job - 31|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 30

Maar nu lachen over mij minderen dan ik van dagen, welker vaderen ik versmaad zou hebben, om bij de honden mijner kudde te stellen. [^1] Waartoe zou mij ook geweest zijn de kracht hunner handen? Zij was door ouderdom in hen vergaan. [^2] Die door gebrek en honger eenzaam waren, vliedende naar dorre plaatsen, in het donkere, woeste en verwoeste. [^3] Die ziltige kruiden plukten bij de struiken, en welker spijze was de wortel der jeneveren. [^4] Zij werden uit het midden uitgedreven; (men jouwde over hen, als over een dief), [^5] Opdat zij wonen zouden in de kloven der dalen, de holen des stofs en der steenrotsen. [^6] Zij schreeuwden tussen de struiken; onder de netelen vergaderden zij zich. [^7] Zij waren kinderen der dwazen, en kinderen van geen naam; zij waren geslagen uit den lande. [^8] Maar nu ben ik hun een snarenspel geworden, en ik ben hun tot een klapwoord. [^9] Zij hebben een gruwel aan mij, zij maken zich verre van mij, ja, zij onthouden het speeksel niet van mijn aangezicht. [^10] Want Hij heeft mijn zeel losgemaakt, en mij bedrukt; daarom hebben zij den breidel voor mijn aangezicht afgeworpen. [^11] Ter rechterhand staat de jeugd op, stoten mijn voeten uit, en banen tegen mij hun verderfelijke wegen. [^12] Zij breken mijn pad af, zij bevorderen mijn ellende; zij hebben geen helper van doen. [^13] Zij komen aan, als door een wijde breuk; onder de verwoesting rollen zij zich aan. [^14] Men is met verschrikkingen tegen mij gekeerd; elk een vervolgt als een wind mijn edele ziel, en mijn heil is als een wolk voorbijgegaan. [^15] Daarom stort zich nu mijn ziel in mij uit; de dagen des druks grijpen mij aan. [^16] Des nachts doorboort Hij mijn beenderen in mij, en mijn polsaderen rusten niet. [^17] Door de veelheid der kracht is mijn kleed veranderd; Hij omgordt mij als de kraag mijns roks. [^18] Hij heeft mij in het slijk geworpen, en ik ben gelijk geworden als stof en as. [^19] Ik schrei tot U, maar Gij antwoordt mij niet; ik sta, maar Gij acht niet op mij. [^20] Gij zijt veranderd in een wrede tegen mij; door de sterkte Uwer hand wederstaat Gij mij hatelijk. [^21] Gij heft mij op in den wind; Gij doet mij daarop rijden, en Gij versmelt mij het wezen. [^22] Want ik weet, dat Gij mij ter dood brengen zult, en tot het huis der samenkomst aller levenden. [^23] Maar Hij zal tot den aardhoop de hand niet uitsteken; is er bij henlieden geschrei in zijn verdrukking? [^24] Weende ik niet over hem, die harde dagen had? Was mijn ziel niet beangst over den nooddruftige? [^25] Nochtans toen ik het goede verwachtte, zo kwam het kwade; toen ik hoopte naar het licht, zo kwam de donkerheid. [^26] Mijn ingewand ziedt, en is niet stil; de dagen der verdrukking zijn mij voorgekomen. [^27] Ik ga zwart daarheen, niet van de zon; opstaande schreeuw ik in de gemeente. [^28] Ik ben den draken een broeder geworden, en een metgezel der jonge struisen. [^29] Mijn huid is zwart geworden over mij, en mijn gebeente is ontstoken van dorrigheid. [^30] Hierom is mijn harp tot een rouwklage geworden, en mijn orgel tot een stem der wenenden. [^31] 

[[Job - 29|<--]] Job - 30 [[Job - 31|-->]]

---
# Notes
