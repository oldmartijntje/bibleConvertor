---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 6 - Statenvertaling (1750)"
---
[[Job - 5|<--]] Job - 6 [[Job - 7|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 6

Maar Job antwoordde en zeide: [^1] Och, of mijn verdriet recht gewogen wierd, en men mijn ellende samen in een weegschaal ophief! [^2] Want het zou nu zwaarder zijn dan het zand der zeeën; daarom worden mijn woorden opgezwolgen. [^3] Want de pijlen des Almachtigen zijn in mij, welker vurig venijn mijn geest uitdrinkt; de verschrikkingen Gods rusten zich tegen mij. [^4] Rochelt ook de woudezel bij het jonge gras? Loeit de os bij zijn voeder? [^5] Wordt ook het onsmakelijke gegeten zonder zout? Is er smaak in het witte des dooiers? [^6] Mijn ziel weigert uw woorden aan te roeren; die zijn als mijn laffe spijze. [^7] Och, of mijn begeerte kwame, en dat God mijn verwachting gave; [^8] En dat het Gode beliefde, dat Hij mij verbrijzelde, Zijn hand losliet, en een einde met mij maakte! [^9] Dat zou nog mijn troost zijn, en zou mij verkwikken in den weedom, zo Hij niet spaarde; want ik heb de redenen des Heiligen niet verborgen gehouden. [^10] Wat is mijn kracht, dat ik hopen zou? Of welk is mijn einde, dat ik mijn leven verlengen zou? [^11] Is mijn kracht stenen kracht? Is mijn vlees staal? [^12] Is dan mijn hulp niet in mij, en is de wijsheid uit mij verdreven? [^13] Aan hem, die versmolten is, zou van zijn vriend weldadigheid geschieden; of hij zou de vreze des Almachtigen verlaten. [^14] Mijn broeders hebben trouwelooslijk gehandeld als een beek; als de storting der beken gaan zij door; [^15] Die verdonkerd zijn van het ijs, en in dewelke de sneeuw zich verbergt. [^16] Ten tijde, als zij van hitte vervlieten, worden zij uitgedelgd; als zij warm worden, verdwijnen zij uit haar plaats. [^17] De gangen haars wegs wenden zich ter zijde af; zij lopen op in het woeste, en vergaan. [^18] De reizigers van Thema zien ze, de wandelaars van Scheba wachten op haar. [^19] Zij worden beschaamd, omdat elkeen vertrouwde; als zij daartoe komen, zo worden zij schaamrood. [^20] Voorwaar, alzo zijt gijlieden mij nu niets geworden; gij hebt gezien de ontzetting, en gij hebt gevreesd. [^21] Heb ik gezegd: Brengt mij, en geeft geschenken voor mij van uw vermogen? [^22] Of bevrijdt mij van de hand des verdrukkers, en verlost mij van de hand der tirannen? [^23] Leert mij, en ik zal zwijgen, en geeft mij te verstaan, waarin ik gedwaald heb. [^24] O, hoe krachtig zijn de rechte redenen! Maar wat bestraft het bestraffen, dat van ulieden is? [^25] Zult gij, om te bestraffen, woorden bedenken, en zullen de redenen des mismoedigen voor wind zijn? [^26] Ook werpt gij u op een wees; en gij graaft tegen uw vriend. [^27] Maar nu, belieft het u, wendt u tot mij, en het zal voor ulieder aangezicht zijn, of ik liege. [^28] Keert toch weder, laat er geen onrecht wezen, ja, keert weder; nog zal mijn gerechtigheid daarin zijn. [^29] Zou onrecht op mijn tong wezen? Zou mijn gehemelte niet de ellenden te verstaan geven? [^30] 

[[Job - 5|<--]] Job - 6 [[Job - 7|-->]]

---
# Notes
