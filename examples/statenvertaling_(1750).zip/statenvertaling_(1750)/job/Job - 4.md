---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 4 - Statenvertaling (1750)"
---
[[Job - 3|<--]] Job - 4 [[Job - 5|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 4

Toen antwoordde Elifaz, de Themaniet, en zeide: [^1] Zo wij een woord opnemen tegen u, zult gij verdrietig zijn? Nochtans wie zal zich van woorden kunnen onthouden? [^2] Zie, gij hebt velen onderwezen, en gij hebt slappe handen gesterkt; [^3] Uw woorden hebben den struikelende opgericht, en de krommende knieën hebt gij vastgesteld; [^4] Maar nu komt het aan u, en gij zijt verdrietig; het raakt tot u, en gij wordt beroerd. [^5] Was niet uw vreze Gods uw hoop, en de oprechtheid uwer wegen uw verwachting? [^6] Gedenk toch, wie is de onschuldige, die vergaan zij; en waar zijn de oprechten verdelgd? [^7] Maar gelijk als ik gezien heb: die ondeugd ploegen, en moeite zaaien, maaien dezelve. [^8] Van den adem Gods vergaan zij, en van het geblaas van Zijn neus worden zij verdaan. [^9] De brulling des leeuws, en de stem des fellen leeuws, en de tanden der jonge leeuwen worden verbroken. [^10] De oude leeuw vergaat, omdat er geen roof is, en de jongens eens oudachtigen leeuws worden verstrooid. [^11] Voorts is tot mij een woord heimelijk gebracht, en mijn oor heeft een weinigje daarvan gevat; [^12] Onder de gedachten van de gezichten des nachts, als diepe slaap valt op de mensen; [^13] Kwam mij schrik en beving over, en verschrikte de veelheid mijner beenderen. [^14] Toen ging voorbij mijn aangezicht een geest; hij deed het haar mijns vleses te berge rijzen. [^15] Hij stond, doch ik kende zijn gedaante niet; een beeltenis was voor mijn ogen; er was stilte, en ik hoorde een stem, zeggende: [^16] Zou een mens rechtvaardiger zijn dan God? Zou een man reiner zijn dan zijn Maker? [^17] Zie, op Zijn knechten zou Hij niet vertrouwen; hoewel Hij in Zijn engelen klaarheid gesteld heeft. [^18] Hoeveel te min op degenen, die lemen huizen bewonen, welker grondslag in het stof is? Zij worden verbrijzeld voor de motten. [^19] Van den morgen tot den avond worden zij vermorzeld; zonder dat men er acht op slaat, vergaan zij in eeuwigheid. [^20] Verreist niet hun uitnemendheid met hen? Zij sterven, maar niet in wijsheid. [^21] 

[[Job - 3|<--]] Job - 4 [[Job - 5|-->]]

---
# Notes
