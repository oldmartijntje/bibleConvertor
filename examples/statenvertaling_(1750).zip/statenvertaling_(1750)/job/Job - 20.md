---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 20 - Statenvertaling (1750)"
---
[[Job - 19|<--]] Job - 20 [[Job - 21|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 20

Toen antwoordde Zofar, de Naämathiet, en zeide: [^1] Daarom doen mijn gedachten mij antwoorden, en over zulks is mijn verhaasten in mij. [^2] Ik heb aangehoord een bestraffing, die mij schande aandoet; maar de geest zal uit mijn verstand voor mij antwoorden. [^3] Weet gij dit? Van altoos af, van dat God den mens op de wereld gezet heeft, [^4] Dat het gejuich de goddelozen van nabij geweest is, en de vreugde des huichelaars voor een ogenblik? [^5] Wanneer zijn hoogheid tot den hemel toe opklomme, en zijn hoofd tot aan de wolken raakte; [^6] Zal hij, gelijk zijn drek, in eeuwigheid vergaan; die hem gezien hadden, zullen zeggen: Waar is hij? [^7] Hij zal wegvlieden als een droom, dat men hem niet vinden zal, en hij zal verjaagd worden als een gezicht des nachts. [^8] Het oog, dat hem zag, zal het niet meer doen; en zijn plaats zal hem niet meer aanschouwen. [^9] Zijn kinderen zullen zoeken den armen te behagen; en zijn handen zullen zijn vermogen moeten wederuitkeren. [^10] Zijn beenderen zullen vol van zijn verborgene zonden zijn; van welke elkeen met hem op het stof nederliggen zal. [^11] Indien het kwaad in zijn mond zoet is, hij dat verbergt, onder zijn tong, [^12] Hij dat spaart, en hetzelve niet verlaat, maar dat in het midden van zijn gehemelte inhoudt; [^13] Zijn spijze zal in zijn ingewand veranderd worden; gal der adderen zal zij in het binnenste van hem zijn. [^14] Hij heeft goed ingeslokt, maar zal het uitspuwen; God zal het uit zijn buik uitdrijven. [^15] Het vergif der adderen zal hij zuigen; de tong der slang zal hem doden. [^16] De stromen, rivieren, beken van honig en boter zal hij niet zien. [^17] Den arbeid zal hij wedergeven en niet inslokken; naar het vermogen zijner verandering, zo zal hij van vreugde niet opspringen. [^18] Omdat hij onderdrukt heeft, de armen verlaten heeft, een huis geroofd heeft, dat hij niet opgebouwd had; [^19] Omdat hij geen rust in zijn buik gekend heeft, zo zal hij van zijn gewenst goed niet uitbehouden. [^20] Er zal niets overig zijn, dat hij ete; daarom zal hij niet wachten naar zijn goed. [^21] Als zijn genoegzaamheid zal vol zijn, zal hem bang zijn; alle hand des ellendigen zal over hem komen. [^22] Er zij wat om zijn buik te vullen; God zal over hem de hitte Zijns toorns zenden, en over hem regenen op zijn spijze. [^23] Hij zij gevloden van de ijzeren wapenen, de stalen boog zal hem doorschieten. [^24] Men zal het zwaard uittrekken, het zal uit het lijf uitgaan, en glinsterende uit zijn gal voortkomen; verschrikkingen zullen over hem zijn. [^25] Alle duisternis zal verborgen zijn in zijn schuilplaatsen; een vuur, dat niet opgeblazen is, zal hem verteren; den overigen in zijn tent zal het kwalijk gaan. [^26] De hemel zal zijn ongerechtigheid openbaren, en de aarde zal zich tegen hem opmaken. [^27] De inkomste van zijn huis zal weggevoerd worden; het zal al henenvloeien in den dag Zijns toorns. [^28] Dit is het deel des goddelozen mensen van God, en de erve zijner redenen van God. [^29] 

[[Job - 19|<--]] Job - 20 [[Job - 21|-->]]

---
# Notes
