---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 34 - Statenvertaling (1750)"
---
[[Job - 33|<--]] Job - 34 [[Job - 35|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 34

Verder antwoordde Elihu, en zeide: [^1] Hoort, gij wijzen, mijn woorden, en gij verstandigen, neigt de oren naar mij. [^2] Want het oor proeft de woorden, gelijk het gehemelte de spijze smaakt. [^3] Laat ons kiezen voor ons, wat recht is; laat ons kennen onder ons wat goed is. [^4] Want Job heeft gezegd: Ik ben rechtvaardig, en God heeft mijn recht weggenomen. [^5] Ik moet liegen in mijn recht; mijn pijl is smartelijk zonder overtreding. [^6] Wat man is er, gelijk Job? Hij drinkt de bespotting in als water; [^7] En gaat over weg in gezelschap met de werkers der ongerechtigheid, en wandelt met goddeloze lieden. [^8] Want hij heeft gezegd: Het baat een man niet, als hij welbehagen heeft aan God. [^9] Daarom, gij, lieden van verstand, hoort naar mij: Verre zij God van goddeloosheid, en de Almachtige van onrecht! [^10] Want naar het werk des mensen vergeldt Hij hem, en naar eens ieders weg doet Hij het hem vinden. [^11] Ook waarlijk, God handelt niet goddelooslijk, en de Almachtige verkeert het recht niet. [^12] Wie heeft Hem gesteld over de aarde, en wie heeft de ganse wereld geschikt? [^13] Indien Hij Zijn hart tegen hem zette, zijn geest en zijn adem zou Hij tot Zich vergaderen; [^14] Alle vlees zou tegelijk den geest geven, en de mens zou tot stof wederkeren. [^15] Zo er dan verstand bij u is, hoor dit; neig de oren tot de stem mijner woorden. [^16] Zou hij ook, die het recht haat, den gewonde verbinden, en zoudt gij den zeer Rechtvaardige verdoemen? [^17] Zou men tot een koning zeggen: Gij Belial; tot de prinsen: Gij goddelozen! [^18] Hoe dan tot Dien, Die het aangezicht der vorsten niet aanneemt, en den rijke voor den arme niet kent? Want zij zijn allen Zijner handen werk. [^19] In een ogenblik sterven zij; zelfs ter middernacht wordt een volk geschud, dat het doorga; en de machtige wordt weggenomen zonder hand. [^20] Want Zijn ogen zijn op ieders wegen, en Hij ziet al zijn treden. [^21] Er is geen duisternis, en er is geen schaduw des doods, dat aldaar de werkers der ongerechtigheid zich verbergen mochten. [^22] Gewisselijk, Hij legt den mens niet te veel op, dat hij tegen God in het gericht zou mogen treden. [^23] Hij vermorzelt de geweldigen, dat men het niet doorzoeken kan, en stelt anderen in hun plaats. [^24] Daarom dat Hij hun werken kent, zo keert Hij hen des nachts om, en zij worden verbrijzeld. [^25] Hij klopt hen samen als goddelozen, in een plaats, waar aanschouwers zijn; [^26] Daarom dat zij van achter Hem afgeweken zijn, en geen Zijner wegen verstaan hebben; [^27] Opdat Hij op hem het geroep des armen brenge, en het geroep der ellendigen verhore. [^28] Als Hij stilt, wie zal dan beroeren? Als Hij het aangezicht verbergt, wie zal Hem dan aanschouwen, zowel voor een volk, als voor een mens alleen? [^29] Opdat de huichelachtige mens niet meer regere, en geen strikken des volks zijn. [^30] Zekerlijk heeft hij tot God gezegd: Ik heb Uw straf verdragen, ik zal het niet verderven. [^31] Behalve wat ik zie, leer Gij mij; heb ik onrecht gewrocht, ik zal het niet meer doen. [^32] Zal het van u zijn, hoe Hij iets vergelden zal, dewijl gij Hem versmaadt? Zoudt gij dan verkiezen, en niet Ik? Wat weet gij dan? Spreek. [^33] De lieden van verstand zullen met mij zeggen, en een wijs man zal naar mij horen: [^34] Dat Job niet met wetenschap gesproken heeft, en zijn woorden niet met kloek verstand geweest zijn. [^35] Mijn Vader, laat Job beproefd worden tot het einde toe, om zijner antwoorden wil onder de ongerechtige lieden. [^36] Want tot zijn zonde zou hij nog overtreding bijvoegen; hij zou onder ons in de handen klappen, en hij zou zijn redenen vermenigvuldigen tegen God. [^37] 

[[Job - 33|<--]] Job - 34 [[Job - 35|-->]]

---
# Notes
