---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 29 - Statenvertaling (1750)"
---
[[Job - 28|<--]] Job - 29 [[Job - 30|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 29

En Job ging voort zijn spreuk op te heffen, en zeide: [^1] Och, of ik ware, gelijk in de vorige maanden, gelijk in de dagen, toen God mij bewaarde! [^2] Toen Hij Zijn lamp deed schijnen over mijn hoofd, en ik bij Zijn licht de duisternis doorwandelde; [^3] Gelijk als ik was in de dagen mijner jonkheid, toen Gods verborgenheid over mijn tent was; [^4] Toen de Almachtige nog met mij was, en mijn jongens rondom mij; [^5] Toen ik mijn gangen wies in boter, en de rots bij mij oliebeken uitgoot; [^6] Toen ik uitging naar de poort door de stad, toen ik mijn stoel op de straat liet bereiden. [^7] De jongens zagen mij, en verstaken zich, en de stokouden rezen op en stonden. [^8] De oversten hielden de woorden in, en legden de hand op hun mond. [^9] De stem der vorsten verstak zich, en hun tong kleefde aan hun gehemelte. [^10] Als een oor mij hoorde, zo hield het mij gelukzalig; als mij een oog zag, zo getuigde het van mij. [^11] Want ik bevrijdde den ellendige, die riep, en den wees, die geen helper had. [^12] De zegen desgenen, die verloren ging, kwam op mij; en het hart der weduwe deed ik vrolijk zingen. [^13] Ik bekleedde mij met gerechtigheid, en zij bekleedde mij; mijn oordeel was als een mantel en vorstelijke hoed. [^14] Den blinden was ik tot ogen, en den kreupelen was ik tot voeten. [^15] Ik was den nooddruftigen een vader; en het geschil, dat ik niet wist, dat onderzocht ik. [^16] En ik verbrak de baktanden des verkeerden, en wierp den roof uit zijn tanden. [^17] En ik zeide: Ik zal in mijn nest den geest geven, en ik zal de dagen vermenigvuldigen als het zand. [^18] Mijn wortel was uitgebreid aan het water, en dauw vernachtte op mijn tak. [^19] Mijn heerlijkheid was nieuw bij mij, en mijn boog veranderde zich in mijn hand. [^20] Zij hoorden mij aan, en wachtten, en zwegen op mijn raad. [^21] Na mijn woord spraken zij niet weder, en mijn rede drupte op hen. [^22] Want zij wachtten naar mij, gelijk naar den regen, en sperden hun mond open, als naar den spaden regen. [^23] Lachte ik hun toe, zij geloofden het niet; en het licht mijns aangezichts deden zij niet nedervallen. [^24] Verkoos ik hun weg, zo zat ik bovenaan, en woonde als een koning onder de benden, als een, die treurigen vertroost. [^25] 

[[Job - 28|<--]] Job - 29 [[Job - 30|-->]]

---
# Notes
