---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 25 - Statenvertaling (1750)"
---
[[Job - 24|<--]] Job - 25 [[Job - 26|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 25

Toen antwoordde Bildad, de Suhiet, en zeide: [^1] Heerschappij en vreze zijn bij Hem, Hij maakt vrede in Zijn hoogten. [^2] Is er een getal Zijner benden? En over wien staat Zijn licht niet op? [^3] Hoe zou dan een mens rechtvaardig zijn bij God, en hoe zou hij zuiver zijn, die van een vrouw geboren is? [^4] Zie, tot de maan toe, en zij zal geen schijnsel geven; en de sterren zijn niet zuiver in Zijn ogen. [^5] Hoeveel te min de mens, die een made is, en des mensen kind, die een worm is! [^6] 

[[Job - 24|<--]] Job - 25 [[Job - 26|-->]]

---
# Notes
