---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 40 - Statenvertaling (1750)"
---
[[Job - 39|<--]] Job - 40 [[Job - 41|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 40

En de HEERE antwoordde Job uit een onweder, en zeide: [^1] Gord nu als een man uw lenden; Ik zal u vragen, en onderricht Mij. [^2] Zult gij ook Mijn oordeel te niet maken? Zult gij Mij verdoemen, opdat gij rechtvaardig zijt? [^3] Hebt gij een arm gelijk God? En kunt gij, gelijk Hij, met de stem donderen? [^4] Versier u nu met voortreffelijkheid en hoogheid, en bekleed u met majesteit en heerlijkheid! [^5] Strooi de verbolgenheden uws toorns uit, en zie allen hoogmoedige, en verneder hem! [^6] Zie allen hoogmoedige, en breng hem ten onder; en verpletter de goddelozen in hun plaats! [^7] Verberg hen te zamen in het stof; verbind hun aangezichten in het verborgen! [^8] Dan zal Ik ook u loven, omdat uw rechterhand u zal verlost hebben. [^9] Zie nu Behemoth, welken Ik gemaakt heb nevens u; hij eet hooi, gelijk een rund. [^10] Zie toch, zijn kracht is in zijn lenden, en zijn macht in den navel zijns buiks. [^11] Als het hem lust, zijn staart is als een ceder; de zenuwen zijner schaamte zijn doorvlochten. [^12] Zijn beenderen zijn als vast koper; zijn gebeenten zijn als ijzeren handbomen. [^13] Hij is een hoofdstuk der wegen Gods; Die hem gemaakt heeft, heeft hem zijn zwaard aangehecht. [^14] Omdat de bergen hem voeder voortbrengen, daarom spelen al de dieren des velds aldaar. [^15] Onder schaduwachtige bomen ligt hij neder, in een schuilplaats des riets en des slijks. [^16] De schaduwachtige bomen bedekken hem, elkeen met zijn schaduw; de beekwilgen omringen hem. [^17] Zie, hij doet de rivier geweld aan, en verhaast zich niet; hij vertrouwt, dat hij de Jordaan in zijn mond zou kunnen intrekken. [^18] Zou men hem voor zijn ogen kunnen vangen? Zou men hem met strikken den neus doorboren kunnen? [^19] Zult gij den Leviathan met den angel trekken, of zijn tong met een koord, dat gij laat nederzinken? [^20] Zult gij hem een bieze in den neus leggen, of met een doorn zijn kaak doorboren? [^21] Zal hij aan u veel smekingen maken? Zal hij zachtjes tot u spreken? [^22] Zal hij een verbond met u maken? Zult gij hem aannemen tot een eeuwigen slaaf? [^23] Zult gij met hem spelen gelijk met een vogeltje, of zult gij hem binden voor uw jonge dochters? [^24] Zullen de metgezellen over hem een maaltijd bereiden? Zullen zij hem delen onder de kooplieden? [^25] Zult gij zijn huis met haken vullen, of met een visserskrauwel zijn hoofd? [^26] Leg uw hand op hem, gedenk des strijds, doe het niet meer. [^27] Zie, zijn hoop zal feilen; zal hij ook voor zijn gezicht nedergeslagen worden? [^28] 

[[Job - 39|<--]] Job - 40 [[Job - 41|-->]]

---
# Notes
