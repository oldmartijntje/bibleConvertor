---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 33 - Statenvertaling (1750)"
---
[[Job - 32|<--]] Job - 33 [[Job - 34|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 33

En gewisselijk, o Job! hoor toch mijn redenen, en neem al mijn woorden ter ore. [^1] Zie nu, ik heb mijn mond opengedaan; mijn tong spreekt onder mijn gehemelte. [^2] Mijn redenen zullen de oprechtigheid mijns harten, en de wetenschap mijner lippen, wat zuiver is, uitspreken. [^3] De Geest Gods heeft mij gemaakt, en de adem des Almachtigen heeft mij levend gemaakt. [^4] Zo gij kunt, antwoord mij; schik u voor mijn aangezicht, stel u. [^5] Zie, ik ben Godes, gelijk gij; uit het leem ben ik ook afgesneden. [^6] Zie, mijn verschrikking zal u niet beroeren, en mijn hand zal over u niet zwaar zijn. [^7] Zeker, gij hebt gezegd voor mijn oren, en ik heb de stem der woorden gehoord; [^8] Ik ben rein, zonder overtreding; ik ben zuiver, en heb geen misdaad. [^9] Zie, Hij vindt oorzaken tegen mij, Hij houdt mij voor Zijn vijand. [^10] Hij legt mijn voeten in den stok; Hij neemt al mijn paden waar. [^11] Zie, hierin zijt gij niet rechtvaardig, antwoord ik u; want God is meerder dan een mens. [^12] Waarom hebt gij tegen Hem getwist? Want Hij antwoordt niet van al Zijn daden. [^13] Maar God spreekt eens of tweemaal; doch men let niet daarop. [^14] In den droom, door het gezicht des nachts, als een diepe slaap op de lieden valt, in de sluimering op het leger; [^15] Dan openbaart Hij het voor het oor der lieden, en Hij verzegelt hun kastijding; [^16] Opdat Hij den mens afwende van zijn werk, en van den man de hovaardij verberge; [^17] Dat Hij zijn ziel van het verderf afhoude; en zijn leven, dat het door het zwaard niet doorga. [^18] Ook wordt hij gestraft met smart op zijn leger, en de sterke menigte zijner beenderen; [^19] Zodat zijn leven het brood zelf verfoeit, en zijn ziel de begeerlijke spijze; [^20] Dat zijn vlees verdwijnt uit het gezicht, en zijn beenderen, die niet gezien werden, uitsteken; [^21] En zijn ziel nadert ten verderve, en zijn leven tot de dingen, die doden. [^22] Is er dan bij hem een gezant, een uitlegger, één uit duizend, om den mens zijn rechten plicht te verkondigen; [^23] Zo zal Hij hem genadig zijn, en zeggen: Verlos hem, dat hij in het verderf niet nederdale, Ik heb verzoening gevonden. [^24] Zijn vlees zal frisser worden dan het was in de jeugd; hij zal tot de dagen zijner jonkheid wederkeren. [^25] Hij zal tot God ernstiglijk bidden, Die in hem een welbehagen nemen zal, en zijn aangezicht met gejuich aanzien; want Hij zal den mens zijn gerechtigheid wedergeven. [^26] Hij zal de mensen aanschouwen, en zeggen: Ik heb gezondigd, en het recht verkeerd, hetwelk mij niet heeft gebaat; [^27] Maar God heeft mijn ziel verlost, dat zij niet voere in het verderf, zodat mijn leven het licht aanziet. [^28] Zie, dit alles werkt God twee- of driemaal met een man; [^29] Opdat hij zijn ziel afkere van het verderf, en hij verlicht worde met het licht der levenden. [^30] Merk op, o Job! Hoor naar mij; zwijg, en ik zal spreken. [^31] Zo er redenen zijn, antwoord mij; spreek, want ik heb lust u te rechtvaardigen. [^32] Zo niet, hoor naar mij; zwijg, en ik zal u wijsheid leren. [^33] 

[[Job - 32|<--]] Job - 33 [[Job - 34|-->]]

---
# Notes
