---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 41 - Statenvertaling (1750)"
---
[[Job - 40|<--]] Job - 41 [[Job - 42|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Job]]

# Job - 41

Niemand is zo koen, dat hij hem opwekken zou; wie is dan hij, die zich voor Mijn aangezicht stellen zou? [^1] Wie heeft Mij voorgekomen, dat Ik hem zou vergelden? Wat onder den gansen hemel is, is het Mijne. [^2] Ik zal zijn leden niet verzwijgen, noch het verhaal zijner sterkte, noch de bevalligheid zijner gestaltenis. [^3] Wie zou het opperste zijns kleeds ontdekken? Wie zou met zijn dubbelen breidel hem aankomen? [^4] Wie zou de deuren zijns aangezichts opendoen? Rondom zijn tanden is verschrikking. [^5] Zeer uitnemend zijn zijn sterke schilden, elkeen gesloten als met een nauwdrukkend zegel. [^6] Het een is zo na aan het andere, dat de wind daar niet kan tussen komen. [^7] Zij kleven aan elkander, zij vatten zich samen, dat zij zich niet scheiden. [^8] Elkeen zijner niezingen doet een licht schijnen; en zijn ogen zijn als de oogleden des dageraads. [^9] Uit zijn mond gaan fakkelen, vurige vonken raken er uit. [^10] Uit zijn neusgaten komt rook voort, als uit een ziedenden pot en ruimen ketel. [^11] Zijn adem zou kolen doen vlammen, en een vlam komt uit zijn mond voort. [^12] In zijn hals herbergt de sterkte; voor hem springt zelfs de droefheid van vreugde op. [^13] De stukken van zijn vlees kleven samen; elkeen is vast in hem, het wordt niet bewogen. [^14] Zijn hart is vast gelijk een steen; ja, vast gelijk een deel van den ondersten molensteen. [^15] Van zijn verheffen schromen de sterken; om zijner doorbrekingen wille ontzondigen zij zich. [^16] Raakt hem iemand met het zwaard, dat zal niet bestaan, spies, schicht noch pantsier. [^17] Hij acht het ijzer voor stro, en het staal voor verrot hout. [^18] De pijl zal hem niet doen vlieden, de slingerstenen worden hem in stoppelen veranderd. [^19] De werpstenen worden van hem geacht als stoppelen, en hij belacht de drilling der lans. [^20] Onder hem zijn scherpe scherven; hij spreidt zich op het puntachtige, als op slijk. [^21] Hij doet de diepte zieden gelijk een pot; hij stelt de zee als een apothekerskokerij. [^22] Achter zich verlicht hij het pad; men zou den afgrond voor grijzigheid houden. [^23] Op de aarde is niets met hem te vergelijken, die gemaakt is om zonder schrik te wezen. [^24] Hij aanziet alles, wat hoog is, hij is een koning over alle jonge hoogmoedige dieren. [^25] 

[[Job - 40|<--]] Job - 41 [[Job - 42|-->]]

---
# Notes
