---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/jozua"
  - "#bible/testament/old"
aliases:
  - "Jozua - 17 - Statenvertaling (1750)"
---
[[Jozua - 16|<--]] Jozua - 17 [[Jozua - 18|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Jozua]]

# Jozua - 17

De stam van Manasse had ook een lot, omdat hij de eerstgeborene van Jozef was: te weten Machir, de eerstgeborene van Manasse, de vader van Gilead; omdat hij een krijgsman was, zo had hij Gilead en Bazan. [^1] Ook hadden de overgebleven kinderen van Manasse een lot, naar hun huisgezinnen; te weten de kinderen van Abiëzer, en de kinderen van Helek, en de kinderen van Asriël, en de kinderen van Sechem, en de kinderen van Hefer, en de kinderen van Semida. Dit zijn de mannelijke kinderen van Manasse, den zoon van Jozef, naar hun huisgezinnen. [^2] Zelafead nu, de zoon van Hefer, den zoon van Gilead, den zoon van Machir, den zoon van Manasse, had geen zonen, maar dochters; en dit zijn de namen zijner dochteren: Machla en Noa, Hogla, Milka en Tirza. [^3] Dezen dan traden toe voor het aangezicht van Eleazar, den priester, en voor het aangezicht van Jozua, den zoon van Nun, en voor het aangezicht der oversten, zeggende: De HEERE heeft Mozes geboden, dat men ons een erfdeel geven zou in het midden onzer broederen. Daarom gaf hij haar, naar den mond des HEEREN, een erfdeel in het midden der broederen van haar vader. [^4] En aan Manasse vielen tien snoeren toe, behalve het land Gilead en Bazan, dat op gene zijde van de Jordaan is. [^5] Want de dochteren van Manasse erfden een erfdeel in het midden zijner zonen; en het land Gilead hadden de overgebleven kinderen van Manasse. [^6] Zodat de landpale van Manasse was van Aser af tot Michmetath, die voor aan Sichem is; en deze landpale gaat ter rechterhand tot aan de inwoners van En-Tappuah. [^7] Manasse had wel het land van Tappuah, maar Tappuah zelve, aan de landpale van Manasse, hadden de kinderen van Efraïm. [^8] Daarna komt de landpale af naar de beek Kana tegen het zuiden der beek. Deze steden zijn van Efraïm in het midden der steden van Manasse; en de landpale van Manasse is aan het noorden der beek, en haar uitgangen zijn aan de zee. [^9] Het was van Efraïm tegen het zuiden, en tegen het noorden was het van Manasse, en de zee was zijn landpale; en aan het noorden stieten zij aan Aser, en aan het oosten aan Issaschar. [^10] Want Manasse had, in Issaschar en in Aser, Beth-Sean en haar onderhorige plaatsen, en Jibleam en haar onderhorige plaatsen, en de inwoners te Dor en haar onderhorige plaatsen, en de inwoners te En-Dor en haar onderhorige plaatsen, en de inwoners te Thaänach en haar onderhorige plaatsen, en de inwoners te Megiddo en haar onderhorige plaatsen: drie landstreken. [^11] En de kinderen van Manasse konden de inwoners van die steden niet verdrijven; want de Kanaänieten wilden in hetzelve land wonen. [^12] En het geschiedde, als de kinderen Israëls sterk werden, zo maakten zij de Kanaänieten cijnsbaar; maar zij verdreven hen niet ganselijk. [^13] Toen spraken de kinderen van Jozef tot Jozua, zeggende: Waarom hebt gij mij ten erfdeel maar een lot en een snoer gegeven, daar ik toch een groot volk ben, voor zoveel de HEERE mij dus verre gezegend heeft? [^14] Jozua nu zeide tot henlieden: Dewijl gij een groot volk zijt, zo ga op naar het woud, en houw daar voor u af in het land der Ferezieten en der Refaïeten, dewijl u het gebergte van Efraïm te eng is. [^15] Toen zeiden de kinderen van Jozef: Dat gebergte zou ons niet genoegzaam zijn; er zijn ook ijzeren wagens bij alle Kanaänieten, die in het land des dals wonen, bij die te Beth-Sean en haar onderhorige plaatsen, en die in het dal van Jizreël zijn. [^16] Verder sprak Jozua tot het huis van Jozef, tot Efraïm en tot Manasse, zeggende: Gij zijt een groot volk, en gij hebt grote kracht, gij zult geen een lot hebben; [^17] Maar het gebergte zal het uwe zijn; en dewijl het een woud is, zo houw het af, zo zullen zijn uitgangen de uwe zijn; want gij zult de Kanaänieten verdrijven, al hebben zij ijzeren wagens, al zijn zij sterk. [^18] 

[[Jozua - 16|<--]] Jozua - 17 [[Jozua - 18|-->]]

---
# Notes
