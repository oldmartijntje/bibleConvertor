---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/jozua"
  - "#bible/testament/old"
aliases:
  - "Jozua - 14 - Statenvertaling (1750)"
---
[[Jozua - 13|<--]] Jozua - 14 [[Jozua - 15|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Jozua]]

# Jozua - 14

Dit is nu hetgeen de kinderen Israëls geërfd hebben in het land Kanaän; hetwelk de priester Eleazar, en Jozua, de zoon van Nun, en de hoofden der vaderen van de stammen der kinderen Israëls, hun hebben doen erven; [^1] Door het lot hunner erfenis, gelijk als de HEERE door den dienst van Mozes geboden had, aangaande de negen stammen en den halven stam. [^2] Want aan de twee stammen en den halven stam had Mozes een erfdeel gegeven op gene zijde van de Jordaan; maar aan de Levieten had hij geen erfdeel onder hen gegeven. [^3] Want de kinderen van Jozef waren twee stammen, Manasse en Efraïm; en aan de Levieten gaven zij geen deel in het land, maar steden om te bewonen, en derzelver voorsteden voor hun vee en voor hun bezitting. [^4] Gelijk als de HEERE Mozes geboden had, alzo deden de kinderen Israëls, en zij deelden het land. [^5] Toen naderden de kinderen van Juda tot Jozua, te Gilgal, en Kaleb, de zoon van Jefunne, de Keneziet, zeide tot hem: Gij weet het woord, dat de HEERE tot Mozes, den man Gods, gesproken heeft te Kades-Barnea, ter oorzake van mij, en ter oorzake van u. [^6] Ik was veertig jaren oud, toen Mozes, de knecht des HEEREN, mij uitgezonden heeft van Kades-Barnea, om het land te verspieden, en ik hem antwoord bracht, gelijk als het in mijn hart was. [^7] Maar mijn broeders, die met mij opgegaan waren, deden het hart des volks smelten; doch ik volhardde den HEERE, mijn God, na te volgen. [^8] Toen zwoer Mozes te dien zelven dage, zeggende: Indien niet het land, waarop uw voet getreden heeft, u en uw kinderen ten erfdeel zal zijn in eeuwigheid, dewijl gij volhard hebt den HEERE, mijn God, na te volgen. [^9] En nu, zie, de HEERE heeft mij in het leven behouden, gelijk als Hij gesproken heeft; het zijn nu vijf en veertig jaren, sedert dat de HEERE dit woord tot Mozes gesproken heeft, toen Israël in de woestijn wandelde; en nu, zie, ik ben heden vijf en tachtig jaren oud. [^10] Ik ben nog heden zo sterk, gelijk als ik was ten dage, toen Mozes mij uitzond; gelijk mijn kracht toen was, alzo is nu mijn kracht, tot den oorlog, en om uit te gaan, en om in te gaan. [^11] En nu, geef mij dit gebergte, waarvan de HEERE te dien dage gesproken heeft; want gij hebt het te dienzelven dage gehoord, dat de Enakieten aldaar waren, en dat er grote vaste steden waren; of de HEERE met mij ware, dat ik hen verdreef, gelijk als de HEERE gesproken heeft. [^12] Toen zegende hem Jozua, en hij gaf Kaleb, den zoon van Jefunne, Hebron ten erfdeel. [^13] Daarom werd Hebron aan Kaleb, den zoon van Jefunne, den Keneziet, ten erfdeel tot op dezen dag; omdat hij volhard had den HEERE, den God Israëls, na te volgen. [^14] De naam nu van Hebron was eertijds Kirjath-Arba, die een groot mens geweest is onder de Enakieten. En het land rustte van den krijg. [^15] 

[[Jozua - 13|<--]] Jozua - 14 [[Jozua - 15|-->]]

---
# Notes
