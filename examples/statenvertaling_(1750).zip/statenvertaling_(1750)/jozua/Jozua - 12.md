---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/jozua"
  - "#bible/testament/old"
aliases:
  - "Jozua - 12 - Statenvertaling (1750)"
---
[[Jozua - 11|<--]] Jozua - 12 [[Jozua - 13|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Jozua]]

# Jozua - 12

Dit nu zijn de koningen des lands, die de kinderen Israëls geslagen hebben, en hun land erfelijk bezaten, aan gene zijde van de Jordaan, tegen den opgang der zon; van de beek Arnon af tot den berg Hermon, en het ganse vlakke veld tegen het oosten: [^1] Sihon, de koning der Amorieten, die te Hesbon woonde; die van Aroër af heerste, welke aan den oever der beek Arnon is, en over het midden der beek en de helft van Gilead, en tot aan de beek Jabbok, de landpale der kinderen Ammons; [^2] En over het vlakke veld tot aan de zee van Cinneroth tegen het oosten, en tot aan de zee des vlakken velds, de Zoutzee, tegen het oosten, op den weg naar Beth-Jesimoth; en van het zuiden beneden Asdoth-Pisga. [^3] Daartoe de landpale van Og, den koning van Bazan, die van het overblijfsel der reuzen was, wonende te Astharoth en te Edreï. [^4] En heerste over den berg Hermon, en over Salcha, en over geheel Bazan, tot aan de landpale der Gezurieten, en der Maächathieten; en de helft van Gilead, de landpale van Sihon, den koning van Hesbon. [^5] Mozes, de knecht des HEEREN, en de kinderen Israëls sloegen hen, en Mozes, de knecht des HEEREN, gaf aan de Rubenieten en aan de Gadieten, en aan den halven stam van Manasse, dat land tot een erfelijke bezitting. [^6] Dit nu zijn de koningen des lands, die Jozua sloeg, en de kinderen Israëls, aan deze zijde van de Jordaan tegen het westen, van Baäl-Gad aan, in het dal van den Libanon, en tot aan den kalen berg, die naar Seïr opgaat; en Jozua gaf het aan de stammen Israëls tot een erfelijke bezitting, naar hun afdelingen. [^7] Wat op het gebergte, en in de laagte, en in het vlakke veld, en in de aflopingen der wateren, en in de woestijn, en tegen het zuiden was: de Hethieten, de Amorieten, en Kanaänieten, de Ferezieten, de Hevieten, en de Jebusieten. [^8] De koning van Jericho, één; de koning van Ai, die ter zijde van Beth-El is, één; [^9] De koning van Jeruzalem, één; de koning van Hebron, één; [^10] De koning van Jarmuth, één; de koning van Lachis, één; [^11] De koning van Eglon, één; de koning van Gezer, één; [^12] De koning van Debir, één; de koning van Geder, één; [^13] De koning van Horma, één; de koning van Harad, één; [^14] De koning van Libna, één; de koning van Adullam, één; [^15] De koning van Makkeda, één; de koning van Beth-El, één; [^16] De koning van Tappuah, één; de koning van Hefer, één; [^17] De koning van Afek, één; de koning van Lassaron, één; [^18] De koning van Madon, één; de koning van Hazor, één; [^19] De koning van Simron-Meron, één; de koning van Achsaf, één; [^20] De koning van Taänach, één; de koning van Megiddo, één; [^21] De koning van Kedes, één, de koning van Jokneam, aan den Karmel, één; [^22] De koning van Dor, tot Nafath-Dor, één; de koning der heidenen te Gilgal, één; [^23] De koning van Thirza, één. Al deze koningen zijn één en dertig. [^24] 

[[Jozua - 11|<--]] Jozua - 12 [[Jozua - 13|-->]]

---
# Notes
