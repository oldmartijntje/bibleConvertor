---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/jozua"
  - "#bible/testament/old"
aliases:
  - "Jozua - 16 - Statenvertaling (1750)"
---
[[Jozua - 15|<--]] Jozua - 16 [[Jozua - 17|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Jozua]]

# Jozua - 16

Daarna kwam het lot der kinderen van Jozef uit: van de Jordaan bij Jericho, aan het water van Jericho, oostwaarts, de woestijn opgaande van Jericho, door het gebergte Beth-El; [^1] En het komt van Beth-El uit naar Luz; en het gaat door tot de landpale des Archiets, tot Ataroth toe; [^2] En het gaat af tegen het westen naar de landpale Jafleti, tot aan de landpale van het benedenste Beth-Horon, en tot Gezer; en haar uitgangen zijn aan de zee. [^3] Alzo hebben hun erfdeel bekomen de kinderen van Jozef, Manasse en Efraïm. [^4] De landpale nu der kinderen van Efraïm, naar hun huisgezinnen, is deze: te weten, de landpale huns erfdeels was oostwaarts Atroth-Addar tot aan het bovenste Beth-horon. [^5] En deze landpale gaat uit tegen het westen bij Michmetath, van het noorden, en deze landpale keert zich om tegen het oosten naar Thaanath-Silo, en gaat door dezelve van het oosten naar Janoah; [^6] En komt af van Janoah naar Ataroth en Naharoth, en stoot aan Jericho, en gaat uit aan de Jordaan. [^7] Van Tappuah gaat deze landpale westwaarts naar de beek Kana, en haar uitgangen zijn aan de zee. Dit is het erfdeel van den stam der kinderen van Efraïm, naar hun huisgezinnen. [^8] En de steden, die afgezonderd waren voor de kinderen van Efraïm, waren in het midden van het erfdeel der kinderen van Manasse, al die steden en haar dorpen. [^9] En zij verdreven de Kanaänieten niet, die te Gezer woonden; alzo woonden die Kanaänieten in het midden der Efraïmieten tot op dezen dag; maar zij waren onder schatting dienende. [^10] 

[[Jozua - 15|<--]] Jozua - 16 [[Jozua - 17|-->]]

---
# Notes
