---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/jozua"
  - "#bible/testament/old"
aliases:
  - "Jozua - 23 - Statenvertaling (1750)"
---
[[Jozua - 22|<--]] Jozua - 23 [[Jozua - 24|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Jozua]]

# Jozua - 23

En het geschiedde na vele dagen, nadat de HEERE Israël rust gegeven had van al zijn vijanden rondom heen, en Jozua oud geworden en wel bedaagd was; [^1] Zo riep Jozua gans Israël, hun oudsten, en hun hoofden, en hun richters, en hun ambtlieden, en hij zeide tot hen: Ik ben oud geworden, en wel bedaagd; [^2] En gijlieden hebt gezien alles, wat de HEERE, uw God, gedaan heeft aan al deze volken voor uw aangezicht; want de HEERE, uw God, Zelf, is het, Die voor u gestreden heeft. [^3] Ziet, ik heb u deze overige volken door het lot doen toevallen, ten erfdeel voor uw stammen, van de Jordaan af, met al de volken, die ik uitgeroeid heb, en tot de grote zee, tegen den ondergang der zon. [^4] En de HEERE, uw God, Zelf zal hen uitstoten voor ulieder aangezicht, en Hij zal hen van voor ulieder aangezicht verdrijven; en gij zult hun land erfelijk bezitten, gelijk als de HEERE, uw God, tot u gesproken heeft. [^5] Zo weest zeer sterk, om te bewaren en om te doen alles, wat geschreven is in het wetboek van Mozes; opdat gij daarvan niet afwijkt ter rechter- noch ter linkerhand; [^6] Dat gij niet ingaat tot deze volken: deze, die overgebleven zijn bij ulieden; gedenkt ook niet aan den naam hunner goden, en doet er niet bij zweren, en dient hen niet, en buigt u voor die niet; [^7] Maar den HEERE, uw God, zult gij aanhangen, gelijk als gij tot op dezen dag gedaan hebt. [^8] Want de HEERE heeft van uw aangezicht verdreven grote en machtige volken; en u aangaande, niemand heeft voor uw aangezicht bestaan, tot op dezen dag toe. [^9] Eén enig man onder u zal er duizend jagen; want het is de HEERE, uw God, Zelf, Die voor u strijdt, gelijk als Hij tot u gesproken heeft. [^10] Daarom bewaart uw zielen naarstiglijk, dat gij den HEERE, uw God, liefhebt. [^11] Want zo gij enigszins afkeert, en het overige van deze volken aanhangt, van deze, die bij u overgebleven zijn, en u met hen verzwagert, en gij tot hen zult ingaan, en zij tot u; [^12] Weet voorzeker, dat de HEERE, uw God, niet voortvaren zal deze volken van voor uw aangezicht te verdrijven; maar zij zullen ulieden zijn tot een strik, en tot een net, en tot een gesel aan uw zijden, en tot doornen in uw ogen, totdat gij omkomt van dit goede land, hetwelk u de HEERE, uw God, gegeven heeft. [^13] En ziet, ik ga heden in den weg der ganse aarde; en gij weet in uw ganse hart en in uw ganse ziel, dat er niet één enig woord gevallen is van al die goede woorden, welke de HEERE, uw God, over u gesproken heeft; zij zijn u alle overkomen; er is van dezelve niet een enig woord gevallen. [^14] En het zal geschieden, gelijk als al die goede dingen over u gekomen zijn, die de HEERE, uw God, tot u gesproken heeft, alzo zal de HEERE over u komen laten al die kwade dingen, totdat Hij u verdelge van dit goede land, hetwelk u de HEERE, uw God gegeven heeft. [^15] Wanneer gij het verbond des HEEREN, uws Gods, overtreedt, dat Hij u geboden heeft, en gij heengaat en dient andere goden, en u voor dezelve nederbuigt, zo zal de toorn des HEEREN over u ontsteken, en gij zult haastiglijk omkomen van het goede land, hetwelk Hij u gegeven heeft. [^16] 

[[Jozua - 22|<--]] Jozua - 23 [[Jozua - 24|-->]]

---
# Notes
