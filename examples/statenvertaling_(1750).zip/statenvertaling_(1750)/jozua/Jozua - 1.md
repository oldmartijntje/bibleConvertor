---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/jozua"
  - "#bible/testament/old"
aliases:
  - "Jozua - 1 - Statenvertaling (1750)"
---
Jozua - 1 [[Jozua - 2|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Jozua]]

# Jozua - 1

Het geschiedde nu, na den dood van Mozes, den knecht des HEEREN, dat de HEERE tot Jozua, den zoon van Nun, den dienaar van Mozes, sprak, zeggende: [^1] Mijn knecht Mozes is gestorven; zo maak u nu op, trek over deze Jordaan, gij en al dit volk, tot het land, dat Ik hun, den kinderen Israëls, geve. [^2] Alle plaats, waarop ulieder voetzool treden zal, heb Ik u gegeven, gelijk als Ik tot Mozes gesproken heb. [^3] Van de woestijn en dezen Libanon af tot aan de grote rivier, de rivier Frath, het ganse land der Hethieten, en tot aan de grote zee, tegen den ondergang der zon, zal ulieder landpale zijn. [^4] Niemand zal voor uw aangezicht bestaan al de dagen uws levens; gelijk als Ik met Mozes geweest ben, zal Ik met u zijn; Ik zal u niet begeven, en zal u niet verlaten. [^5] Wees sterk en heb goeden moed! want gij zult dit volk dat land erfelijk doen bezitten, dat Ik hun vaderen heb gezworen hun te geven. [^6] Alleenlijk wees sterk en heb zeer goeden moed, dat gij waarneemt te doen naar de ganse wet, welke Mozes, Mijn knecht, u geboden heeft, en wijk daarvan niet, ter rechter- noch ter linkerhand, opdat gij verstandelijk handelt alom, waar gij zult gaan; [^7] Dat het boek dezer wet niet wijke van uw mond, maar overleg het dag en nacht, opdat gij waarneemt te doen naar alles, wat daarin geschreven is; want alsdan zult gij uw wegen voorspoedig maken, en alsdan zult gij verstandelijk handelen. [^8] Heb Ik het u niet bevolen? wees sterk en heb goeden moed, en verschrik niet, en ontzet u niet; want de HEERE, uw God, is met u alom, waar gij heengaat. [^9] Toen gebood Jozua den ambtlieden des volks, zeggende: [^10] Gaat door het midden des legers, en beveelt het volk, zeggende: Bereidt teerkost voor ulieden; want binnen nog drie dagen zult gijlieden over deze Jordaan gaan, dat gij ingaat, om te erven het land, hetwelk de HEERE, uw God, ulieden geeft om te beërven. [^11] En Jozua sprak tot de Rubenieten en Gadieten, en den halven stam van Manasse, zeggende: [^12] Gedenkt aan het woord, hetwelk Mozes, de knecht des HEEREN, ulieden geboden heeft, zeggende: De HEERE, uw God, geeft ulieden rust, en Hij geeft u dit land; [^13] Laat uw vrouwen, uw kleine kinderen, en uw vee blijven in het land, dat Mozes ulieden aan deze zijde van de Jordaan gegeven heeft; maar gijlieden zult gewapend trekken, voor het aangezicht uwer broederen, alle strijdbare helden, en zult hen helpen; [^14] Totdat de HEERE uw broederen rust geve, als ulieden, en dat zij ook erfelijk bezitten het land, dat de HEERE, uw God, hun geeft; alsdan zult gijlieden wederkeren tot het land uwer erfenis, en zult het erfelijk bezitten, dat Mozes, de knecht des HEEREN, ulieden gegeven heeft, aan deze zijde van de Jordaan, tegen den opgang der zon. [^15] Toen antwoordden zij Jozua, zeggende: Al wat gij ons geboden hebt, zullen wij doen, en alom, waar gij ons zenden zult, zullen wij gaan. [^16] Gelijk wij in alles naar Mozes hebben gehoord, alzo zullen wij naar u horen; alleenlijk dat de HEERE, uw God, met u zij, gelijk als Hij met Mozes geweest is! [^17] Alle man, die uw mond wederspannig wezen zal, en uw woorden niet horen zal in alles, wat gij hem gebieden zult, die zal gedood worden, alleenlijk wees sterk en heb goeden moed! [^18] 

Jozua - 1 [[Jozua - 2|-->]]

---
# Notes
