---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/jozua"
  - "#bible/testament/old"
aliases:
  - "Jozua - 20 - Statenvertaling (1750)"
---
[[Jozua - 19|<--]] Jozua - 20 [[Jozua - 21|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Jozua]]

# Jozua - 20

Verder sprak de HEERE tot Jozua, zeggende: [^1] Spreek tot de kinderen Israëls, zeggende: Geeft voor ulieden de vrijsteden, waarvan Ik met ulieden gesproken heb door den dienst van Mozes. [^2] Dat daarheen vliede de doodslager, die een ziel door dwaling, niet met wetenschap, verslaat; opdat zij ulieden zijn tot een toevlucht voor den bloedwreker. [^3] Als hij vlucht tot een van die steden, zo zal hij staan aan de deur der stadspoort, en hij zal zijn woorden spreken voor de oren van de oudsten derzelver stad; dan zullen zij hem tot zich in de stad nemen, en hem plaats geven, dat hij bij hen wone. [^4] En als de bloedwreker hem najaagt, zo zullen zij den doodslager in zijn hand niet overgeven, dewijl hij zijn naaste niet met wetenschap verslagen heeft, en hem gisteren en eergisteren niet heeft gehaat. [^5] En hij zal in dezelve stad wonen, totdat hij sta voor het aangezicht der vergadering voor het gericht, totdat de hogepriester sterve, die in die dagen zijn zal; dan zal de doodslager wederkeren, en komen tot zijn stad, en tot zijn huis, tot de stad, van waar hij gevloden is. [^6] Toen heiligden zij Kedes in Galiléa, op het gebergte van Nafthali, en Sichem op het gebergte van Efraïm, en Kirjath-Arba, deze is Hebron, op het gebergte van Juda. [^7] En aan gene zijde van de Jordaan, van Jericho oostwaarts, gaven zij Bezer in de woestijn, in het platte land, van den stam van Ruben; en Ramoth in Gilead, van den stam van Gad; en Golan in Bazan, van den stam van Manasse. [^8] Dit nu zijn de steden, die bestemd waren voor al de kinderen Israëls, en voor den vreemdeling, die in het midden van henlieden verkeert, opdat derwaarts vluchte al wie een ziel slaat door dwaling; opdat hij niet sterve door de hand des bloedwrekers, totdat hij voor het aangezicht der vergadering gestaan zal hebben. [^9] 

[[Jozua - 19|<--]] Jozua - 20 [[Jozua - 21|-->]]

---
# Notes
