---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/jozua"
  - "#bible/testament/old"
aliases:
  - "Jozua - 4 - Statenvertaling (1750)"
---
[[Jozua - 3|<--]] Jozua - 4 [[Jozua - 5|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Jozua]]

# Jozua - 4

Het geschiedde nu, toen al het volk geëindigd had over de Jordaan te trekken, dat de HEERE tot Jozua sprak, zeggende: [^1] Neemt gijlieden u twaalf mannen uit het volk, uit elken stam een man. [^2] En gebiedt hun, zeggende: Neemt voor ulieden op, van hier uit het midden van de Jordaan, uit de standplaats van de voeten der priesteren, en bereidt twaalf stenen, en brengt ze met ulieden over, en stelt ze in het nachtleger, waar gij dezen nacht zult vernachten. [^3] Jozua dan riep die twaalf mannen, die hij had doen bestellen van de kinderen Israëls, uit elken stam een man. [^4] En Jozua zeide tot hen: Gaat over voor de ark des HEEREN, uws Gods, midden in de Jordaan; en heft u een ieder een steen op zijn schouder, naar het getal der stammen van de kinderen Israëls; [^5] Opdat dit een teken zij onder ulieden; wanneer uw kinderen morgen vragen zullen, zeggende: Wat zijn u deze stenen? [^6] Zo zult gij tot hen zeggen: Omdat de wateren van de Jordaan zijn afgesneden geweest voor de ark des verbonds des HEEREN; als zij toog door de Jordaan, werden de wateren van de Jordaan afgesneden; zo zullen deze stenen den kinderen Israëls ter gedachtenis zijn tot in eeuwigheid. [^7] De kinderen Israëls nu deden alzo, gelijk als Jozua geboden had; en zij namen twaalf stenen op midden uit de Jordaan, gelijk als de HEERE tot Jozua gesproken had, naar het getal der stammen van de kinderen Israëls; en zij brachten ze met zich over naar het nachtleger, en stelden ze aldaar. [^8] Jozua richtte ook twaalf stenen op, midden in de Jordaan, ter standplaats van de voeten der priesteren, die de ark des verbonds droegen; en zij zijn daar tot op dezen dag. [^9] De priesters nu, die de ark droegen, stonden midden in de Jordaan, totdat alle ding volbracht was, hetwelk de HEERE Jozua geboden had het volk aan te zeggen, naar al wat Mozes Jozua geboden had. En het volk haastte, en het trok over. [^10] En het geschiedde, als al het volk geëindigd had over te gaan, toen ging de ark des HEEREN over, en de priesters voor het aangezicht des volks. [^11] En de kinderen van Ruben, en de kinderen van Gad, mitsgaders de halve stam van Manasse, trokken gewapend voor het aangezicht der kinderen Israëls, gelijk als Mozes tot hen gesproken had. [^12] Omtrent veertig duizend toegeruste krijgsmannen trokken er voor het aangezicht des HEEREN ten strijde, naar de vlakke velden van Jericho. [^13] Te dienzelven dage maakte de HEERE Jozua groot voor de ogen van het ganse Israël; en zij vreesden hem, gelijk als zij Mozes gevreesd hadden, al de dagen zijns levens. [^14] De HEERE dan sprak tot Jozua, zeggende: [^15] Gebied den priesteren, die de ark der getuigenis dragen, dat zij uit de Jordaan opklimmen. [^16] Toen gebood Jozua den priesteren, zeggende: Klimt op uit den Jordaan. [^17] En het geschiedde, toen de priesters, die de ark des verbonds des HEEREN droegen, uit het midden van de Jordaan opgeklommen waren, en de voetzolen der priesteren afgetrokken waren tot op het droge; zo keerden de wateren van de Jordaan weder in hun plaats, en gingen als gisteren en eergisteren aan al haar oevers. [^18] Het volk nu was den tienden der eerste maand uit de Jordaan opgeklommen; en zij legerden zich te Gilgal, aan het oosteinde van Jericho. [^19] En Jozua richtte die twaalf stenen te Gilgal op, die zij uit de Jordaan genomen hadden. [^20] En hij sprak tot de kinderen Israëls, zeggende: Wanneer uw kinderen morgen hun vaderen vragen zullen, zeggende: Wat zijn deze stenen? [^21] Zo zult gij het uw kinderen te kennen geven, zeggende: Op het droge is Israël door deze Jordaan gegaan. [^22] Want de HEERE, uw God, heeft de wateren van de Jordaan voor uw aangezichten doen uitdrogen, totdat gijlieden er waart doorgegaan; gelijk als de HEERE, uw God, aan de Schelfzee gedaan heeft, die Hij voor ons aangezicht heeft doen uitdrogen, totdat wij daardoor gegaan waren; [^23] Opdat alle volken der aarde de hand des HEEREN kennen zouden, dat zij sterk is; opdat gijlieden den HEERE, uw God, vrezet te allen dage. [^24] 

[[Jozua - 3|<--]] Jozua - 4 [[Jozua - 5|-->]]

---
# Notes
