---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/jozua"
  - "#bible/testament/old"
aliases:
  - "Jozua - 3 - Statenvertaling (1750)"
---
[[Jozua - 2|<--]] Jozua - 3 [[Jozua - 4|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Jozua]]

# Jozua - 3

Jozua dan maakte zich des morgens vroeg op, en zij reisden van Sittim, en kwamen tot aan de Jordaan, hij en al de kinderen Israëls; en zij vernachtten aldaar, eer zij overtrokken. [^1] En het geschiedde, dat de ambtlieden, op het einde van drie dagen, door het midden des legers gingen; [^2] En zij geboden het volk, zeggende: Wanneer gij de ark des verbonds des HEEREN, uws Gods, ziet, en de Levietische priesters dezelve dragende, verreist gijlieden ook van uw plaats, en volgt haar na; [^3] Dat er nochtans ruimte zij tussen ulieden en tussen dezelve, bij de twee duizend ellen in de maat; en nadert tot dezelve niet; opdat gij dien weg wetet, dien gij gaan zult; want gijlieden zijt door dien weg niet gegaan gisteren en eergisteren. [^4] Jozua zeide ook tot het volk: Heiligt u! want morgen zal de HEERE wonderheden in het midden van ulieden doen. [^5] Desgelijks sprak Jozua tot de priesters, zeggende: Neemt de ark des verbonds op, en gaat door voor het aangezicht van dit volk. Zij dan namen de ark des verbonds op, en zij gingen voor het aangezicht des volks. [^6] Want de HEERE had tot Jozua gezegd: Dezen dag zal Ik beginnen u groot te maken voor de ogen van gans Israël, opdat zij weten, dat Ik met u zijn zal, gelijk als Ik met Mozes geweest ben. [^7] Gij dan zult den priesteren, die de ark des verbonds dragen, gebieden, zeggende: Wanneer gijlieden komt tot aan het uiterste van het water van de Jordaan, staat stil in de Jordaan. [^8] Toen zeide Jozua tot de kinderen Israëls: Nadert herwaarts, en hoort de woorden des HEEREN, uws Gods. [^9] Verder zeide Jozua: Hieraan zult gijlieden bekennen, dat de levende God in het midden van u is, en dat Hij ganselijk voor uw aangezicht uitdrijven zal de Kanaänieten, en de Hethieten, en de Hevieten, en de Ferezieten, en de Girgazieten, en de Amorieten en de Jebusieten. [^10] Ziet, de ark des verbonds van den Heere der ganse aarde gaat door voor ulieder aangezicht in de Jordaan. [^11] Nu dan, neemt gijlieden u twaalf mannen uit de stammen Israëls, uit iederen stam een man; [^12] Want het zal geschieden, met dat de voetzolen der priesteren, die de ark van den HEERE, den Heere der ganse aarde, dragen, in het water van de Jordaan zullen rusten, zo zullen de wateren van de Jordaan afgesneden worden, te weten de wateren, die van boven afvlieten, en zij zullen op een hoop blijven staan. [^13] En het geschiedde, toen het volk vertrok uit zijn tenten, om over de Jordaan te gaan, zo droegen de priesters de ark des verbonds voor het aangezicht des volks. [^14] En als zij, die de ark droegen, tot aan de Jordaan gekomen waren, en de voeten der priesteren, dragende de ark, ingedoopt waren in het uiterste van het water (de Jordaan nu was vol al de dagen des oogstes aan al haar oevers); [^15] Zo stonden de wateren, die van boven afkwamen; zij rezen op een hoop, zeer verre van de stad Adam af, die ter zijde van Sarthan ligt; en die naar de zee des vlakken velds, te weten de Zoutzee, afliepen, vergingen, zij werden afgesneden. Toen trok het volk over, tegenover Jericho. [^16] Maar de priesters, die de ark des verbonds des HEEREN droegen, stonden steevast op het droge, in het midden van de Jordaan; en gans Israël ging over op het droge, totdat al het volk geëindigd had door de Jordaan te trekken. [^17] 

[[Jozua - 2|<--]] Jozua - 3 [[Jozua - 4|-->]]

---
# Notes
