---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/jozua"
  - "#bible/testament/old"
aliases:
  - "Jozua - 11 - Statenvertaling (1750)"
---
[[Jozua - 10|<--]] Jozua - 11 [[Jozua - 12|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Jozua]]

# Jozua - 11

Het geschiedde daarna, als Jabin, de koning van Hazor, dit hoorde, zo zond hij tot Jobab, den koning van Madon, en tot den koning van Simron, en tot den koning van Achsaf, [^1] En tot de koningen, die tegen het noorden op het gebergte, en op het vlakke, tegen het zuiden van Cinneroth, en in de laagte, en in Nafoth-Dor, aan de zee waren; [^2] Tot de Kanaänieten tegen het oosten en tegen het westen, en de Amorieten, en de Hethieten, en de Ferezieten; en de Jebusieten op het gebergte, en de Hevieten onder aan Hermon, in het land van Mizpa. [^3] Dezen nu togen uit, en al hun heirlegers met hen; veel volks, als het zand, dat aan den oever der zee is, in veelheid; en zeer vele paarden en wagens. [^4] Al deze koningen werden vergaderd, en kwamen en legerden zich samen aan de wateren van Merom, om tegen Israël te krijgen. [^5] En de HEERE zeide tot Jozua: Vrees niet voor hun aangezichten; want morgen omtrent dezen tijd zal Ik hen altegader verslagen geven voor het aangezicht van Israël; hun paarden zult gij verlammen, en hun wagenen met vuur verbranden. [^6] En Jozua, en al het krijgsvolk met hem, kwam snellijk over hen aan de wateren van Merom, en zij overvielen hen. [^7] En de HEERE gaf hen in de hand van Israël, en zij sloegen hen, en joegen hen na tot groot Sidon toe, en tot Misrefoth-maïm, en tot het dal Mizpa tegen het oosten; en zij sloegen hen, totdat zij geen overigen onder hen overlieten. [^8] Jozua nu deed hun, gelijk hem de HEERE gezegd had; hun paarden verlamde hij, en hun wagenen verbrandde hij met vuur. [^9] En Jozua keerde weder ter zelver tijd, en hij nam Hazor in, en haar koning sloeg hij met het zwaard; want Hazor was te voren het hoofd van al deze koninkrijken. [^10] En zij sloegen alle ziel, die daarin was, met de scherpte des zwaards, die verbannende; er bleef niets over, dat adem had; en Hazor verbrandde hij met vuur. [^11] En Jozua nam al de steden dezer koningen in, en al haar koningen, en hij sloeg hen met de scherpte des zwaards, hen verbannende, gelijk als Mozes, de knecht des HEEREN geboden had. [^12] Alleenlijk verbrandden de Israëlieten geen steden, die op haar heuvelen stonden, behalve Hazor alleen; dat verbrandde Jozua. [^13] En al den roof dezer steden, en het vee, roofden de kinderen Israëls voor zich; alleenlijk sloegen zij al de mensen met de scherpte des zwaards, totdat zij hen verdelgden; zij lieten niet overblijven wat adem had. [^14] Gelijk als de HEERE Mozes, Zijn knecht, geboden had, alzo gebood Mozes aan Jozua; en alzo deed Jozua; hij deed er niet een woord af van alles, wat de HEERE Mozes geboden had. [^15] Alzo nam Jozua al dat land in, het gebergte, en al het zuiden, en al het land van Gosen, en de laagte, en het vlakke veld, en het gebergte Israëls, en zijn laagte. [^16] Van den kalen berg, die opwaarts naar Seïr gaat, tot Baäl-Gad toe, in het dal van den Libanon, onder aan den berg Hermon; al hun koningen nam hij ook, en sloeg hen, en doodde hen. [^17] Vele dagen voerde Jozua krijg tegen al deze koningen. [^18] Er was geen stad, die vrede maakte met de kinderen Israëls, behalve de Hevieten, inwoners van Gibeon; zij namen ze allen in door krijg. [^19] Want het was van den HEERE, hun harten te verstokken, dat zij Israël met oorlog tegemoet gingen, opdat hij hen verbannen zoude, dat hun geen genade geschiedde, maar opdat hij hen verdelgen zoude, gelijk als de HEERE Mozes geboden had. [^20] Te dier tijde nu kwam Jozua, en roeide de Enakieten uit, van het gebergte, van Hebron, van Debir, van Anab, en van het ganse gebergte van Juda, en van het ganse gebergte van Israël; Jozua verbande hen met hun steden. [^21] Er bleef niemand van de Enakieten over in het land der kinderen Israëls; alleenlijk bleven zij over te Gaza, te Gath, en te Asdod. [^22] Alzo nam Jozua al dat land in, naar alles, wat de HEERE tot Mozes gesproken had; en Jozua gaf het Israël ten erve, naar hun afdelingen, naar hun stammen. En het land rustte van den krijg. [^23] 

[[Jozua - 10|<--]] Jozua - 11 [[Jozua - 12|-->]]

---
# Notes
