---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/jozua"
  - "#bible/testament/old"
aliases:
  - "Jozua - 5 - Statenvertaling (1750)"
---
[[Jozua - 4|<--]] Jozua - 5 [[Jozua - 6|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Jozua]]

# Jozua - 5

En het geschiedde, toen al de koningen der Amorieten, die aan deze zijde van de Jordaan westwaarts, en al de koningen der Kanaänieten, die aan de zee waren, hoorden, dat de HEERE de wateren van de Jordaan had uitgedroogd, voor het aangezicht der kinderen Israëls, totdat wij daardoor gegaan waren; zo versmolt hun hart, en er was geen moed meer in hen, voor het aangezicht der kinderen Israëls. [^1] Te dier tijd sprak de HEERE tot Jozua: Maak u stenen messen, en besnijd wederom de kinderen Israëls ten tweeden maal. [^2] Toen maakte zich Jozua stenen messen, en besneed de kinderen Israëls op den heuvel der voorhuiden. [^3] Dit nu was de oorzaak, waarom hen Jozua besneed: al het volk, dat uit Egypte getogen was, de manspersonen, alle krijgslieden, waren gestorven in de woestijn, op den weg, nadat zij uit Egypte getogen waren. [^4] Want al het volk, dat er uittoog, was besneden; maar al het volk, dat geboren was in de woestijn op den weg, nadat zij uit Egypte getrokken waren, hadden zij niet besneden. [^5] Want de kinderen Israëls wandelden veertig jaren in de woestijn, totdat vergaan was het ganse volk der krijgslieden, die uit Egypte gegaan waren; die de stem des HEEREN niet gehoorzaam geweest waren, denwelken de HEERE gezworen had, dat Hij hun niet zoude laten zien het land, hetwelk de HEERE hun vaderen gezworen had ons te zullen geven, een land vloeiende van melk en honig. [^6] Maar hun zonen heeft Hij aan hun plaats gesteld; die heeft Jozua besneden, omdat zij de voorhuid hadden; want zij hadden hen op den weg niet besneden. [^7] En het geschiedde, als men een einde gemaakt had van al dat volk te besnijden, zo bleven zij in hun plaats in het leger, totdat zij genezen waren. [^8] Verder sprak de HEERE tot Jozua: Heden heb Ik den smaad van Egypte van ulieden afgewenteld; daarom noemde men den naam dier plaats Gilgal, tot op dezen dag. [^9] Terwijl de kinderen Israëls te Gilgal gelegerd lagen, zo hielden zij het pascha op den veertienden dag derzelver maand, in den avond, op de vlakke velden van Jericho. [^10] En zij aten van het overjarige koren des lands, des anderen daags van het pascha, ongezuurde broden en verzengde aren, even op dienzelven dag. [^11] En het Manna hield op des anderen daags, nadat zij van des lands overjarige koren gegeten hadden; en de kinderen Israëls hadden geen Manna meer, maar zij aten in hetzelve jaar van de inkomst des lands Kanaän. [^12] Voorts geschiedde het, als Jozua bij Jericho was, dat hij zijn ogen ophief, en zag toe, en ziet, er stond een Man tegenover hem, Die een uitgetogen zwaard in Zijn hand had. En Jozua ging tot Hem, en zeide tot Hem: Zijt Gij van ons, of van onze vijanden? [^13] En Hij zeide: Neen, maar Ik ben de Vorst van het heir des HEEREN: Ik ben nu gekomen! Toen viel Jozua op zijn aangezicht ter aarde en aanbad, en zeide tot Hem: Wat spreekt mijn Heere tot Zijn knecht? [^14] Toen zeide de Vorst van het heir des HEEREN tot Jozua: Trek uw schoenen af van uw voeten; want de plaats, waarop gij staat, is heilig. En Jozua deed alzo. [^15] 

[[Jozua - 4|<--]] Jozua - 5 [[Jozua - 6|-->]]

---
# Notes
