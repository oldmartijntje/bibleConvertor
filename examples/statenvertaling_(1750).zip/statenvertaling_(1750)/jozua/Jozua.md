---
translation: Statenvertaling (1750)
aliases:
  - "Jozua - Statenvertaling (1750)"
tags:
  - "#bible/type/book"
  - "#bible/book/jozua"
  - "#bible/testament/old"
---
[[Deuteronomium|<--]] Jozua [[Rechters|-->]]

# Jozua - Statenvertaling (1750)

The Jozua book has 24 chapters. It is part of the old testament.

## Chapters

- Jozua [[Jozua - 1|chapter 1]]
- Jozua [[Jozua - 2|chapter 2]]
- Jozua [[Jozua - 3|chapter 3]]
- Jozua [[Jozua - 4|chapter 4]]
- Jozua [[Jozua - 5|chapter 5]]
- Jozua [[Jozua - 6|chapter 6]]
- Jozua [[Jozua - 7|chapter 7]]
- Jozua [[Jozua - 8|chapter 8]]
- Jozua [[Jozua - 9|chapter 9]]
- Jozua [[Jozua - 10|chapter 10]]
- Jozua [[Jozua - 11|chapter 11]]
- Jozua [[Jozua - 12|chapter 12]]
- Jozua [[Jozua - 13|chapter 13]]
- Jozua [[Jozua - 14|chapter 14]]
- Jozua [[Jozua - 15|chapter 15]]
- Jozua [[Jozua - 16|chapter 16]]
- Jozua [[Jozua - 17|chapter 17]]
- Jozua [[Jozua - 18|chapter 18]]
- Jozua [[Jozua - 19|chapter 19]]
- Jozua [[Jozua - 20|chapter 20]]
- Jozua [[Jozua - 21|chapter 21]]
- Jozua [[Jozua - 22|chapter 22]]
- Jozua [[Jozua - 23|chapter 23]]
- Jozua [[Jozua - 24|chapter 24]]

[[Deuteronomium|<--]] Jozua [[Rechters|-->]]

---
# Notes
