---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 7 - Statenvertaling (1750)"
---
[[Exodus - 6|<--]] Exodus - 7 [[Exodus - 8|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Exodus]]

# Exodus - 7

Toen zeide de HEERE tot Mozes: Zie, Ik heb u tot een god gezet over Farao; en Aäron, uw broeder, zal uw profeet zijn. [^1] Gij zult spreken alles, wat Ik u gebieden zal; en Aäron, uw broeder, zal tot Farao spreken, dat hij de kinderen Israëls uit zijn land trekken laat. [^2] Doch Ik zal Farao’s hart verharden; en Ik zal Mijn tekenen en Mijn wonderheden in Egypteland vermenigvuldigen. [^3] Farao nu zal naar ulieden niet horen, en Ik zal Mijn hand aan Egypte leggen, en voeren Mijn heiren, Mijn volk, de kinderen Israëls, uit Egypteland, door grote gerichten. [^4] Dan zullen de Egyptenaars weten, dat Ik de HEERE ben, wanneer Ik Mijn hand over Egypte uitstrekke, en de kinderen Israëls uit het midden van hen uitleide. [^5] Toen deed Mozes en Aäron, als hun de HEERE geboden had, alzo deden zij. [^6] En Mozes was tachtig jaar oud, en Aäron was drie en tachtig jaar oud, toen zij tot Farao spraken. [^7] En de HEERE sprak tot Mozes en tot Aäron, zeggende: [^8] Wanneer Farao tot ulieden spreken zal, zeggende: Doet een wonderteken voor ulieden; zo zult gij tot Aäron zeggen: Neem uw staf, en werp hem voor Farao’s aangezicht neder; hij zal tot een draak worden. [^9] Toen ging Mozes en Aäron tot Farao henen in, en deden alzo, gelijk de HEERE geboden had; en Aäron wierp zijn staf neder voor Farao’s aangezicht, en voor het aangezicht zijner knechten; en hij werd tot een draak. [^10] Farao nu riep ook de wijzen en de guichelaars; en de Egyptische tovenaars deden ook alzo met hun bezweringen. [^11] Want een iegelijk wierp zijn staf neder, en zij werden tot draken; maar Aärons staf verslond hun staven. [^12] Doch Farao’s hart verstokte, zodat hij naar hen niet hoorde, gelijk de HEERE gesproken had. [^13] Toen zeide de HEERE tot Mozes: Farao’s hart is zwaar; hij weigert het volk te laten trekken. [^14] Ga heen tot Farao in den morgenstond; zie, hij zal uitgaan naar het water toe, zo stel u tegen hem over aan den oever der rivier, en den staf, die in een slang is veranderd geweest, zult gij in uw hand nemen. [^15] En gij zult tot hem zeggen: de HEERE, de God der Hebreën, heeft mij tot u gezonden, zeggende: Laat Mijn volk trekken, dat het Mij diene in de woestijn; doch zie, gij hebt tot nu toe niet gehoord. [^16] Zo zegt de HEERE: Daaraan zult gij weten, dat Ik de HEERE ben; zie, ik zal met dezen staf, die in mijn hand is, op het water, dat in deze rivier is, slaan, en het zal in bloed veranderd worden. [^17] En de vis in de rivier zal sterven, zodat de rivier zal stinken; en de Egyptenaars zullen vermoeid worden, dat zij het water uit de rivier drinken mogen. [^18] Verder zeide de HEERE tot Mozes: Zeg tot Aäron: Neem uw staf, en steek uw hand uit over de wateren der Egyptenaren, over hun stromen, over hun rivieren, en over hun poelen, en over alle vergadering hunner wateren, dat zij bloed worden; en er zij bloed in het ganse Egypteland, beide in houten en in stenen vaten. [^19] Mozes nu en Aäron deden alzo, gelijk de HEERE geboden had; en hij hief den staf op, en sloeg het water, dat in de rivier was, voor de ogen van Farao, en voor de ogen van zijn knechten; en al het water in de rivier werd in bloed veranderd. [^20] En de vis, die in de rivier was, stierf; en de rivier stonk, zodat de Egyptenaars het water uit de rivier niet drinken konden; en er was bloed in het ganse Egypteland. [^21] Doch de Egyptische tovenaars deden ook alzo met hun bezweringen; zodat Farao’s hart verstokte, en hij hoorde naar hen niet, gelijk als de HEERE gesproken had. [^22] En Farao keerde zich om, en ging naar zijn huis; en hij zette zijn hart daar ook niet op. [^23] Doch alle Egyptenaars groeven rondom de rivier, om water te drinken; want zij konden van het water der rivier niet drinken. [^24] Alzo werden zeven dagen vervuld, nadat de HEERE de rivier geslagen had. [^25] 

[[Exodus - 6|<--]] Exodus - 7 [[Exodus - 8|-->]]

---
# Notes
