---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 1 - Statenvertaling (1750)"
---
Exodus - 1 [[Exodus - 2|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Exodus]]

# Exodus - 1

Dit nu zijn de namen der zonen van Israël, die in Egypte gekomen zijn, met Jakob; zij kwamen er in, elk met zijn huis. [^1] Ruben, Simeon, Levi, en Juda; [^2] Issaschar, Zebulon, en Benjamin; [^3] Dan en Nafthali, Gad en Aser. [^4] Al de zielen nu, die uit Jakobs heup voortgekomen zijn, waren zeventig zielen; doch Jozef was in Egypte. [^5] Toen nu Jozef gestorven was, en al zijn broeders, en al dat geslacht, [^6] Zo werden de kinderen Israëls vruchtbaar en wiesen overvloedig, en zij vermeerderden, en werden gans zeer machtig, zodat het land met hen vervuld werd. [^7] Daarna stond een nieuwe koning op over Egypte, die Jozef niet gekend had; [^8] Die zeide tot zijn volk: Ziet, het volk der kinderen Israëls is veel, ja, machtiger dan wij. [^9] Komt aan, laat ons wijselijk tegen hetzelve handelen, opdat het niet vermenigvuldige, en het geschiede, als er enige krijg voorvalt, dat het zich ook niet vervoege tot onze vijanden, en tegen ons strijde, en uit het land optrekke. [^10] En zij zetten oversten der schattingen over hetzelve, om het te verdrukken met hun lasten; want men bouwde voor Farao schatsteden, Pitom en Raämses. [^11] Maar hoe meer zij het verdrukten, hoe meer het vermeerderde, en hoe meer het wies; zodat zij verdrietig waren vanwege de kinderen Israëls. [^12] En de Egyptenaars deden de kinderen Israëls dienen met hardigheid; [^13] Zodat zij hun het leven bitter maakten met harden dienst, in leem en in tichelstenen, en met allen dienst op het veld, met al hun dienst, dien zij hen deden dienen met hardigheid. [^14] Daarenboven sprak de koning van Egypte tot de vroedvrouwen der Hebreïnnen, welker ener naam Sifra, en de naam der andere Pua was; [^15] En zeide: Wanneer gij de Hebreïnnen in het baren helpt, en ziet haar op de stoelen; is het een zoon, zo doodt hem; maar is het een dochter, zo laat haar leven! [^16] Doch de vroedvrouwen vreesden God, en deden niet, gelijk als de koning van Egypte tot haar gesproken had, maar zij behielden de knechtjes in het leven. [^17] Toen riep de koning van Egypte de vroedvrouwen, en zeide tot haar: Waarom hebt gijlieden deze zaak gedaan, dat gij de knechtjes in het leven behouden hebt? [^18] En de vroedvrouwen zeiden tot Farao: Omdat de Hebreïnnen niet zijn gelijk de Egyptische vrouwen; want zij zijn sterk; eer de vroedvrouw tot haar komt, zo hebben zij gebaard. [^19] Daarom deed God aan de vroedvrouwen goed; en dat volk vermeerderde, en het werd zeer machtig. [^20] En het geschiedde, dewijl de vroedvrouwen God vreesden, zo bouwde Hij haar huizen. [^21] Toen gebood Farao aan al zijn volk, zeggende: Alle zonen, die geboren worden, zult gij in de rivier werpen, maar al de dochteren in het leven behouden. [^22] 

Exodus - 1 [[Exodus - 2|-->]]

---
# Notes
