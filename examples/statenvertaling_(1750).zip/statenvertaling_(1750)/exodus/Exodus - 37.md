---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 37 - Statenvertaling (1750)"
---
[[Exodus - 36|<--]] Exodus - 37 [[Exodus - 38|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Exodus]]

# Exodus - 37

Alzo maakte Bezáleël de ark van sittimhout; twee ellen en een halve was haar lengte, en anderhalve el haar breedte, en anderhalve el haar hoogte. [^1] En hij overtrok ze met louter goud, van binnen en van buiten; en hij maakte ze een gouden krans rondom. [^2] En hij goot voor dezelve vier gouden ringen, aan haar vier hoeken, alzo dat twee ringen op derzelver ene zijde waren, en twee ringen op haar andere zijde. [^3] En hij maakte handbomen van sittimhout, en hij overtrok ze met goud. [^4] En hij stak de handbomen in de ringen, aan de zijden der ark, om de ark te dragen. [^5] Hij maakte ook een verzoendeksel van louter goud; twee ellen en een halve was deszelfs lengte, en anderhalve el deszelfs breedte. [^6] Ook maakte hij twee cherubim van goud; van dicht werk maakte hij ze, uit de beide einden des verzoendeksels. [^7] Een cherub uit het ene einde aan deze zijde, en den anderen cherub uit het andere einde aan gene zijde; uit het verzoendeksel maakte hij de cherubim, uit deszelfs beide einden. [^8] En de cherubim waren de beide vleugelen omhoog uitbreidende, bedekkende met hun vleugelen het verzoendeksel; en hun aangezichten waren tegenover elkander; de aangezichten der cherubim waren naar het verzoendeksel. [^9] Hij maakte ook een tafel van sittimhout; twee ellen was haar lengte, en een el haar breedte; en een el en een halve haar hoogte. [^10] En hij overtrok ze met louter goud; en hij maakte een gouden krans daaraan, rondom. [^11] Hij maakte daaraan ook een lijst rondom, een hand breed; en hij maakte een gouden krans rondom derzelver lijst. [^12] Hij goot ook vier gouden ringen daaraan; en hij zette de ringen aan de vier hoeken, die aan derzelver vier voeten waren. [^13] Tegenover de lijst waren de ringen tot plaatsen voor de handbomen, om de tafel te dragen. [^14] Hij maakte ook de handbomen van sittimhout; en hij overtrok ze met goud, om de tafel te dragen. [^15] En hij maakte het gereedschap, dat op de tafel zijn zoude, haar schotelen, en haar reukschalen, en haar kroezen, en haar platelen (met welke zij bedekt zoude worden), van louter goud. [^16] Hij maakte ook een kandelaar van louter goud. Van dicht werk maakte hij dezen kandelaar, zijn schacht, en zijn rieten; zijn schaaltjes, zijn knopen, en zijn bloemen waren uit hem. [^17] Zes rieten nu gingen uit zijn zijden; drie rieten des kandelaars uit zijn ene zijde, en drie rieten des kandelaars uit zijn andere zijde. [^18] In het ene riet waren drie schaaltjes, gelijk amandelnoten, een knoop en een bloem; en drie schaaltjes, gelijk amandelnoten in een ander riet, een knoop en een bloem; alzo waren die zes rieten, die uit den kandelaar gingen. [^19] Maar aan den kandelaar zelven waren vier schaaltjes, gelijk amandelnoten, met zijn knopen, en met zijn bloemen. [^20] En daar was een knoop onder twee rieten, uit denzelven uitgaande; ook een knoop onder twee rieten, uit denzelven uitgaande; nog een knoop onder twee rieten, uit denzelven uitgaande; alzo was het met de zes rieten, die uit denzelven uitgingen. [^21] Hun knopen en hun rieten waren uit hem; het was altemaal een enig dicht werk van louter goud. [^22] En hij maakte hem zeven lampen; zijn snuiters en zijn blusvaten waren van louter goud. [^23] Hij maakte denzelven uit een talent louter goud, met al zijn vaten, [^24] En hij maakte het reukaltaar van sittimhout; een el was zijn lengte en een el zijn breedte, vierkant, maar twee ellen zijn hoogte; uit hetzelve waren zijn hoornen. [^25] En hij overtrok het met louter goud, zijn dak, en zijn wanden rondom, alsook zijn hoornen; en hij maakte het een gouden krans rondom. [^26] Hij maakte ook twee gouden ringen daaraan, onder zijn krans, aan zijn twee hoeken, aan zijn beide zijden, tot plaatsen voor de handbomen, dat men het daarmede droeg. [^27] En hij maakte de handbomen van sittimhout, en hij overtrok ze met goud. [^28] Hij maakte ook de heilige zalfolie, en het reukwerk der zuiverste welriekende specerijen, naar apothekerswerk. [^29] 

[[Exodus - 36|<--]] Exodus - 37 [[Exodus - 38|-->]]

---
# Notes
