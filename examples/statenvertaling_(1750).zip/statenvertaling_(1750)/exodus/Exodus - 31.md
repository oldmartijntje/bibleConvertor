---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 31 - Statenvertaling (1750)"
---
[[Exodus - 30|<--]] Exodus - 31 [[Exodus - 32|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Exodus]]

# Exodus - 31

Daarna sprak de HEERE tot Mozes, zeggende: [^1] Zie, Ik heb met name geroepen Bezáleël, den zoon van Uri, den zoon van Hur, van den stam van Juda. [^2] En Ik heb hem vervuld met den Geest Gods, met wijsheid, en met verstand, en met wetenschap, namelijk in alle handwerk; [^3] Om te bedenken vernuftigen arbeid; te werken in goud, en in zilver, en in koper, [^4] En in kunstige steensnijding, om in te zetten, en in kunstige houtsnijding, om te werken in alle handwerk. [^5] En Ik, zie, Ik heb hem bijgevoegd Aholiab, den zoon van Ahisamach, van den stam van Dan; en in het hart van een iegelijk, die wijs van hart is, heb Ik wijsheid gegeven; en zij zullen maken al wat Ik u geboden heb. [^6] Namelijk de tent der samenkomst, en de ark der getuigenis, en het verzoendeksel, dat daarop zal zijn, en al het gereedschap der tent; [^7] En de tafel, met haar gereedschap; en den louteren kandelaar, met al zijn gereedschap; en het reukaltaar; [^8] Ook des brandoffers altaar, met al zijn gereedschap; en het wasvat met zijn voet; [^9] En de ambtsklederen, en de heilige klederen van den priester Aäron, en de klederen van zijn zonen, om het priesterambt te bedienen; [^10] Ook de zalfolie, en het reukwerk van welriekende specerijen voor het heiligdom; naar alles, wat Ik u geboden heb, zullen zij het maken. [^11] Verder sprak de HEERE tot Mozes, zeggende: [^12] Gij nu, spreek tot de kinderen Israëls, zeggende: Gij zult evenwel mijn sabbatten onderhouden; want dit is een teken tussen Mij en tussen ulieden, bij uw geslachten; opdat men wete, dat Ik de HEERE ben, Die u heilige. [^13] Onderhoudt dan den sabbat, dewijl hij ulieden heilig is! Wie hem ontheiligt, zal zekerlijk gedood worden; want een ieder, die op denzelven enig werk doet, die ziel zal uitgeroeid worden uit het midden harer volken. [^14] Zes dagen zal men het werk doen; doch op den zevenden dag is de sabbat der rust, een heiligheid des HEEREN! Wie op den sabbatdag arbeid doet, zal zekerlijk gedood worden. [^15] Dat dan de kinderen Israëls den sabbat houden, den sabbat onderhoudende in hun geslachten, tot een eeuwig verbond. [^16] Hij zal tussen Mij en tussen de kinderen Israëls een teken in eeuwigheid zijn; dewijl de HEERE, in zes dagen, den hemel en de aarde gemaakt, en op den zevenden dag gerust en zich verkwikt heeft. [^17] En Hij gaf aan Mozes, als Hij met hem op den berg Sinaï te spreken geëindigd had, de twee tafelen der getuigenis, tafelen van steen, beschreven met den vinger Gods. [^18] 

[[Exodus - 30|<--]] Exodus - 31 [[Exodus - 32|-->]]

---
# Notes
