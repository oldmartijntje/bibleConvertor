---
translation: Statenvertaling (1750)
aliases:
  - "Exodus - Statenvertaling (1750)"
tags:
  - "#bible/type/book"
  - "#bible/book/exodus"
  - "#bible/testament/old"
---
[[Genesis|<--]] Exodus [[Leviticus|-->]]

# Exodus - Statenvertaling (1750)

The Exodus book has 40 chapters. It is part of the old testament.

## Chapters

- Exodus [[Exodus - 1|chapter 1]]
- Exodus [[Exodus - 2|chapter 2]]
- Exodus [[Exodus - 3|chapter 3]]
- Exodus [[Exodus - 4|chapter 4]]
- Exodus [[Exodus - 5|chapter 5]]
- Exodus [[Exodus - 6|chapter 6]]
- Exodus [[Exodus - 7|chapter 7]]
- Exodus [[Exodus - 8|chapter 8]]
- Exodus [[Exodus - 9|chapter 9]]
- Exodus [[Exodus - 10|chapter 10]]
- Exodus [[Exodus - 11|chapter 11]]
- Exodus [[Exodus - 12|chapter 12]]
- Exodus [[Exodus - 13|chapter 13]]
- Exodus [[Exodus - 14|chapter 14]]
- Exodus [[Exodus - 15|chapter 15]]
- Exodus [[Exodus - 16|chapter 16]]
- Exodus [[Exodus - 17|chapter 17]]
- Exodus [[Exodus - 18|chapter 18]]
- Exodus [[Exodus - 19|chapter 19]]
- Exodus [[Exodus - 20|chapter 20]]
- Exodus [[Exodus - 21|chapter 21]]
- Exodus [[Exodus - 22|chapter 22]]
- Exodus [[Exodus - 23|chapter 23]]
- Exodus [[Exodus - 24|chapter 24]]
- Exodus [[Exodus - 25|chapter 25]]
- Exodus [[Exodus - 26|chapter 26]]
- Exodus [[Exodus - 27|chapter 27]]
- Exodus [[Exodus - 28|chapter 28]]
- Exodus [[Exodus - 29|chapter 29]]
- Exodus [[Exodus - 30|chapter 30]]
- Exodus [[Exodus - 31|chapter 31]]
- Exodus [[Exodus - 32|chapter 32]]
- Exodus [[Exodus - 33|chapter 33]]
- Exodus [[Exodus - 34|chapter 34]]
- Exodus [[Exodus - 35|chapter 35]]
- Exodus [[Exodus - 36|chapter 36]]
- Exodus [[Exodus - 37|chapter 37]]
- Exodus [[Exodus - 38|chapter 38]]
- Exodus [[Exodus - 39|chapter 39]]
- Exodus [[Exodus - 40|chapter 40]]

[[Genesis|<--]] Exodus [[Leviticus|-->]]

---
# Notes
