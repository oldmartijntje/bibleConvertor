---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 24 - Statenvertaling (1750)"
---
[[Exodus - 23|<--]] Exodus - 24 [[Exodus - 25|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Exodus]]

# Exodus - 24

Daarna zeide Hij tot Mozes: Klim op tot den HEERE, gij en Aäron, Nadab en Abihu, en zeventig van de oudsten van Israël; en buigt u neder van verre! [^1] En dat Mozes alleen zich nadere tot den HEERE, maar dat zij niet naderen; en het volk klimme ook niet op met hem. [^2] Als Mozes kwam en verhaalde aan het volk al de woorden des HEEREN, en al de rechten, toen antwoordde al het volk met één stem, en zij zeiden: Al deze woorden, die de HEERE gesproken heeft, zullen wij doen. [^3] Mozes nu beschreef al de woorden des HEEREN, en hij maakte zich des morgens vroeg op, en hij bouwde een altaar onder aan den berg, en twaalf kolommen, naar de twaalf stammen van Israël. [^4] En hij zond de jongelingen van de kinderen Israëls, die brandofferen offerden, en den HEERE dankofferen offerden, van jonge ossen. [^5] En Mozes nam de helft van het bloed, en zette het in bekkens; en de helft van het bloed sprengde hij op het altaar. [^6] En hij nam het boek des verbonds, en hij las het voor de oren des volks; en zij zeiden: Al wat de HEERE gesproken heeft, zullen wij doen en gehoorzamen. [^7] Toen nam Mozes dat bloed, en sprengde het op het volk; en hij zeide: Ziet, dit is het bloed des verbonds, hetwelk de HEERE met ulieden gemaakt heeft over al die woorden. [^8] Mozes nu en Aäron klommen opwaarts, ook Nadab en Abihu, en zeventig van de oudsten van Israël. [^9] En zij zagen den God van Israël, en onder Zijn voeten als een werk van saffierstenen, en als de gestaltenis des hemels in zijn klaarheid. [^10] Doch Hij strekte Zijn hand niet tot de afgezonderden van de kinderen Israëls; maar zij aten en dronken, nadat zij God gezien hadden. [^11] Toen zeide de HEERE tot Mozes: Kom tot Mij op den berg, en wees aldaar; en Ik zal u stenen tafelen geven, en de wet, en de geboden, die Ik geschreven heb, om hen te onderwijzen. [^12] Toen maakte zich Mozes op, met Jozua, zijn dienaar; en Mozes klom op den berg Gods. [^13] En hij zeide tot de oudsten: Blijft gij ons hier, totdat wij weder tot u komen; en ziet, Aäron en Hur zijn bij u; wie enige zaken heeft, zal tot dezelve komen. [^14] Toen Mozes op den berg geklommen was, zo heeft een wolk den berg bedekt. [^15] En de heerlijkheid des HEEREN woonde op den berg Sinaï, en de wolk bedekte hem zes dagen, en op den zevenden dag riep Hij Mozes uit het midden der wolk. [^16] En het aanzien der heerlijkheid des HEEREN was als een verterend vuur, op het opperste diens bergs, in de ogen der kinderen Israëls. [^17] En Mozes ging in het midden der wolk, nadat hij op den berg geklommen was; en Mozes was op dien berg veertig dagen en veertig nachten. [^18] 

[[Exodus - 23|<--]] Exodus - 24 [[Exodus - 25|-->]]

---
# Notes
