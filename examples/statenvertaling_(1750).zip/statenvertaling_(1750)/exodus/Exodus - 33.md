---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 33 - Statenvertaling (1750)"
---
[[Exodus - 32|<--]] Exodus - 33 [[Exodus - 34|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Exodus]]

# Exodus - 33

Voorts sprak de HEERE tot Mozes: Ga heen, trek op van hier, gij en het volk, dat gij uit Egypteland opgevoerd hebt, naar het land, dat Ik Abraham, Izak en Jakob gezworen heb, zeggende: Aan uw zaad zal Ik het geven; [^1] En Ik zal een Engel voor uw aangezicht zenden (en Ik zal uitdrijven de Kanaänieten, de Amorieten, en de Hethieten, en de Ferezieten, de Hevieten, en de Jebusieten), [^2] Naar het land, dat van melk en honig is vloeiende; want Ik zal in het midden van u niet optrekken; want gij zijt een hardnekkig volk; dat Ik u op dezen weg niet vertere. [^3] Toen het volk dit kwade woord hoorde, zo droegen zij leed; en niemand van hen deed zijn versiersel aan zich. [^4] En de HEERE had tot Mozes gezegd: Zeg tot de kinderen Israëls: Gij zijt een hardnekkig volk; in een ogenblik zou Ik in het midden van ulieden optrekken, en zou u vernielen; doch nu, legt uw sieraad van u af, en Ik zal weten, wat Ik u doen zal. [^5] De kinderen Israëls dan beroofden zichzelven van hun versierselen, verre van den berg Horeb. [^6] En Mozes nam de tent, en spande ze zich buiten het leger, ver van het leger afwijkende; en hij noemde ze de Tent der samenkomst. En het geschiedde, dat al wie den HEERE zocht, uitging tot de tent der samenkomst, die buiten het leger was. [^7] En het geschiedde, wanneer Mozes uitging naar de tent, stond al het volk op, en een ieder stelde zich in de deur zijner tent; en zij zagen Mozes na, totdat hij de tent ingegaan was. [^8] En het geschiedde, als Mozes de tent ingegaan was, zo kwam de wolkkolom nederwaarts, en stond in de deur der tent, en Hij sprak met Mozes. [^9] Als al het volk de wolkkolom zag staan in de deur der tent, zo stond al het volk op, en zij bogen zich, een ieder in de deur zijner tent. [^10] En de HEERE sprak tot Mozes aangezicht tot aangezicht, gelijk een man met zijn vriend spreekt; daarna keerde hij weder tot het leger; doch zijn dienaar Jozua, de zoon van Nun, de jongeling, week niet uit het midden der tent. [^11] En Mozes zeide tot den HEERE: Zie, Gij zegt tot mij: Voer dit volk op! maar Gij laat mij niet weten, wien Gij met mij zult zenden; daar Gij gezegd hebt: Ik ken u bij name! en ook: Gij hebt genade gevonden in Mijn ogen! [^12] Nu dan, ik bidde, indien ik genade gevonden heb in Uw ogen, zo laat mij nu Uw weg weten, en ik zal U kennen, opdat ik genade vinde in Uw ogen; en zie aan, dat deze natie Uw volk is! [^13] Hij dan zeide: Zou Mijn aangezicht moeten medegaan, om u gerust te stellen? [^14] Toen zeide hij tot Hem: Indien Uw aangezicht niet medegaan zal, doe ons van hier niet optrekken! [^15] Want waarbij zou nu bekend worden, dat ik genade gevonden heb in Uw ogen, ik en Uw volk? Is het niet daarbij, dat Gij met ons gaat? Alzo zullen wij afgezonderd worden, ik en Uw volk, van alle volk, dat op den aardbodem is. [^16] Toen zeide de HEERE tot Mozes: Ook deze zelfde zaak, die gij gesproken hebt, zal Ik doen, dewijl gij genade gevonden hebt in Mijn ogen, en Ik u bij name ken. [^17] Toen zeide hij: Toon mij nu Uw heerlijkheid! [^18] Doch Hij zeide: Ik zal al Mijn goedigheid voorbij uw aangezicht laten gaan, en zal den Naam des HEEREN uitroepen voor uw aangezicht; maar Ik zal genadig zijn, wien Ik zal genadig zijn, en Ik zal Mij ontfermen, over wien Ik Mij ontfermen zal. [^19] Hij zeide verder: Gij zoudt Mijn aangezicht niet kunnen zien; want Mij zal geen mens zien, en leven. [^20] De HEERE zeide verder: Zie, er is een plaats bij Mij; daar zult gij u op de steenrots stellen. [^21] En het zal geschieden, wanneer Mijn heerlijkheid voorbij zal gaan, zo zal Ik u in een kloof der steenrots zetten; en Ik zal u met Mijn hand overdekken, totdat Ik zal voorbijgegaan zijn. [^22] En wanneer Ik Mijn hand zal weggenomen hebben, zo zult gij Mijn achterste delen zien; maar Mijn aangezicht zal niet gezien worden. [^23] 

[[Exodus - 32|<--]] Exodus - 33 [[Exodus - 34|-->]]

---
# Notes
