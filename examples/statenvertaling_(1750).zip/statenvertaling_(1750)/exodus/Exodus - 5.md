---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 5 - Statenvertaling (1750)"
---
[[Exodus - 4|<--]] Exodus - 5 [[Exodus - 6|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Exodus]]

# Exodus - 5

En daarna gingen Mozes en Aäron heen, en zeiden tot Farao: Alzo zegt de HEERE, de God van Israël: Laat Mijn volk trekken, dat het Mij een feest houde in de woestijn! [^1] Maar Farao zeide: Wie is de HEERE, Wiens stem ik gehoorzamen zou, om Israël te laten trekken? Ik ken den HEERE niet, en ik zal ook Israël niet laten trekken. [^2] Zij dan zeiden: De God der Hebreën is ons ontmoet; zo laat ons toch heentrekken, den weg van drie dagen in de woestijn, en den HEERE, onzen God, offeren, dat Hij ons niet overkome met pestilentie, of met het zwaard. [^3] Toen zeide de koning van Egypte tot hen: Gij, Mozes en Aäron! waarom trekt gij het volk af van hun werken? Gaat heen tot uw lasten. [^4] Verder zeide Farao: Ziet, het volk des lands is alreeds te veel; en zoudt gijlieden hen doen rusten van hun lasten? [^5] Daarom beval Farao, ten zelfden dage, aan de aandrijvers onder het volk, en deszelfs ambtlieden, zeggende: [^6] Gij zult voortaan aan deze lieden geen stro meer geven, tot het maken der tichelstenen, als gisteren en eergisteren; laat hen zelven heengaan, en stro voor zichzelven verzamelen. [^7] En het getal der tichelstenen, die zij gisteren en eergisteren gemaakt hebben, zult gij hun opleggen; gij zult daarvan niet verminderen; want zij gaan ledig; daarom roepen zij, zeggende: Laat ons gaan, laat ons onzen God offeren! [^8] Men verzware den dienst over deze mannen, dat zij daaraan te doen hebben, en zich niet vergapen aan leugenachtige woorden. [^9] Toen gingen de aandrijvers des volks uit, en deszelfs ambtlieden, en spraken tot het volk, zeggende: Zo zegt Farao: Ik zal ulieden geen stro geven. [^10] Gaat gij zelve heen, haalt u stro, waar gij het vindt; doch van uw dienst zal niet verminderd worden. [^11] Toen verstrooide zich het volk in het ganse land van Egypte, dat het stoppelen verzamelde, voor stro. [^12] En de aandrijvers drongen aan, zeggende: Voleindigt uw werken, elk dagwerk op zijn dag, gelijk toen er stro was. [^13] En de ambtlieden der kinderen Israëls, die Farao’s aandrijvers over hen gesteld hadden, werden geslagen, en men zeide: Waarom hebt gijlieden uw gezette werk niet voleindigd, in het maken der tichelstenen, gelijk te voren, alzo ook gisteren en heden? [^14] Derhalve gingen de ambtlieden der kinderen Israëls, en schreeuwden tot Farao, zeggende: Waarom doet gij uw knechten alzo? [^15] Aan uw knechten wordt geen stro gegeven, en zij zeggen tot ons: Maakt de tichelstenen; en ziet, uw knechten worden geslagen, doch de schuld is uws volks! [^16] Hij dan zeide: Gijlieden gaat ledig, ledig gaat gij; daarom zegt gij: Laat ons gaan, laat ons den HEERE offeren! [^17] Zo gaat nu heen, arbeidt; doch stro zal u niet gegeven worden; evenwel zult gij het getal der tichelstenen leveren. [^18] Toen zagen de ambtlieden der kinderen Israëls, dat het kwalijk met hen stond, dewijl men zeide: Gij zult niet minderen van uw tichelstenen, van het dagwerk op zijn dag. [^19] En zij ontmoetten Mozes en Aäron, die tegen hen over stonden, toen zij van Farao uitgingen. [^20] En zeiden tot hen: De HEERE zie op u, en richte het, dewijl dat gij onzen reuk hebt stinkende gemaakt voor Farao, en voor zijn knechten, gevende een zwaard in hun handen, om ons te doden. [^21] Toen keerde Mozes weder tot den HEERE, en zeide: Heere! waarom hebt Gij dit volk kwaad gedaan, waarom hebt Gij mij nu gezonden? [^22] Want van toen af, dat ik tot Farao ben ingegaan, om in Uw Naam te spreken, heeft hij dit volk kwaad gedaan; en Gij hebt Uw volk geenszins verlost. [^23] Toen zeide de HEERE tot Mozes: Nu zult gij zien, wat Ik aan Farao doen zal; want door een machtige hand zal hij hen laten trekken, ja, door een machtige hand zal hij hen uit zijn land drijven. [^24] 

[[Exodus - 4|<--]] Exodus - 5 [[Exodus - 6|-->]]

---
# Notes
