---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 27 - Statenvertaling (1750)"
---
[[Exodus - 26|<--]] Exodus - 27 [[Exodus - 28|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Exodus]]

# Exodus - 27

Gij zult ook een altaar maken van sittimhout; vijf ellen zal de lengte zijn, en vijf ellen de breedte (vierkant zal dit altaar zijn), en drie ellen zijn hoogte. [^1] En gij zult zijn hoornen maken op zijn vier hoeken; uit hetzelve zullen zijn hoornen zijn, en gij zult het met koper overtrekken. [^2] Gij zult het ook potten maken, om zijn as te ontvangen, ook zijn schoffelen, en zijn besprengbekkens, en zijn krauwelen, en zijn koolpannen; al zijn gereedschap zult gij van koper maken. [^3] Gij zult het een rooster maken van koperen netwerk; en gij zult aan dat net vier koperen ringen maken aan zijn vier einden. [^4] En gij zult het onder den omloop des altaars van beneden opleggen, alzo dat het net tot het midden des altaars zij. [^5] Gij zult ook handbomen maken tot het altaar, handbomen van sittimhout; en gij zult ze met koper overtrekken. [^6] En de handbomen zullen in de ringen gedaan worden, alzo dat de handbomen zijn aan beide zijden des altaars, als men het draagt. [^7] Gij zult hetzelve hol van planken maken; gelijk als Hij u op den berg gewezen heeft, alzo zullen zij doen. [^8] Gij zult ook den voorhof des tabernakels maken; aan den zuidhoek zuidwaarts, zullen aan den voorhof behangselen zijn van fijn getweernd linnen; de lengte ener zijde zal honderd ellen zijn. [^9] Ook zullen zijn twintig pilaren, en derzelver twintig voeten, van koper zijn; de haken dezer pilaren, en hun banden zullen van zilver zijn. [^10] Alzo zullen ook aan den noorderhoek, in de lengte, de behangsels honderd ellen lang zijn; en zijn twintig pilaren, en derzelver twintig voeten, van koper; de haken der pilaren, en derzelver banden zullen van zilver zijn. [^11] En in de breedte des voorhofs, aan den westerhoek, zullen behangselen zijn van vijftig ellen; hun pilaren tien, en derzelver voeten tien. [^12] Van gelijken zal de breedte des voorhofs, aan den oosterhoek oostwaarts, van vijftig ellen zijn. [^13] Alzo dat er vijftien ellen der behangselen op de ene zijde zijn; hun pilaren drie, en hun voeten drie; [^14] En vijftien ellen der behangselen aan de andere zijde; hun pilaren drie, en hun voeten drie. [^15] In de poort nu des voorhofs zal een deksel zijn van twintig ellen, hemelsblauw, en purper, en scharlaken, en fijn getweernd linnen, geborduurd werk; de pilaren vier, en hun voeten vier. [^16] Al de pilaren des voorhofs zullen rondom met zilveren banden bezet zijn; hun haken zullen van zilver zijn, maar hun voeten zullen van koper zijn. [^17] De lengte des voorhofs zal honderd ellen zijn, en de breedte doorgaans vijftig, en de hoogte vijf ellen, van fijn getweernd linnen; maar hun voeten zullen van koper zijn. [^18] Aangaande al het gereedschap des tabernakels, in al deszelfs dienst, ja, al zijn pennen, en al de pennen des voorhofs, zullen van koper zijn. [^19] Gij nu zult den kinderen Israëls gebieden, dat zij tot u brengen reine olie van olijven, gestoten tot den luchter, dat men geduriglijk de lampen aansteke. [^20] In de tent der samenkomst, van buiten den voorhang, die voor de getuigenis is, zal ze Aäron en zijn zonen toerichten, van den avond tot den morgen, voor het aangezicht des HEEREN; dit zal een eeuwige inzetting zijn voor hun geslachten, vanwege de kinderen Israëls. [^21] 

[[Exodus - 26|<--]] Exodus - 27 [[Exodus - 28|-->]]

---
# Notes
