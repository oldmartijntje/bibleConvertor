---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 13 - Statenvertaling (1750)"
---
[[Exodus - 12|<--]] Exodus - 13 [[Exodus - 14|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Exodus]]

# Exodus - 13

Toen sprak de HEERE tot Mozes, zeggende: [^1] Heilig Mij alle eerstgeborenen; wat enige baarmoeder opent onder de kinderen Israëls, van mensen en van beesten, dat is Mijn. [^2] Verder zeide Mozes tot het volk: Gedenkt aan dezen zelfden dag, op welken gijlieden uit Egypte, uit het diensthuis, gegaan zijt; want de HEERE heeft u door een sterke hand van hier uitgevoerd; daarom zal het gedesemde niet gegeten worden. [^3] Heden gaat gijlieden uit, in de maand Abib. [^4] En het zal geschieden, als u de HEERE zal gebracht hebben in het land der Kanaänieten, en der Hethieten, en der Amorieten, en der Hevieten, en der Jebusieten, hetwelk Hij uw vaderen gezworen heeft u te geven, een land vloeiende van melk en honig; zo zult gij dezen dienst houden in deze maand. [^5] Zeven dagen zult gij ongezuurde broden eten, en aan den zevenden dag zal den HEERE een feest zijn. [^6] Zeven dagen zullen ongezuurde broden gegeten worden, en het gedesemde zal bij u niet gezien worden, ja, er zal geen zuurdeeg bij u gezien worden, in al uw palen. [^7] En gij zult uw zoon te kennen geven te dienzelven dage, zeggende: Dit is om hetgeen de HEERE mij gedaan heeft, toen ik uit Egypte uittoog. [^8] En het zal u zijn tot een teken op uw hand, en tot een gedachtenis tussen uw ogen, opdat de wet des HEEREN in uw mond zij, omdat u de HEERE door een sterke hand uit Egypte uitgevoerd heeft. [^9] Daarom onderhoudt deze inzetting ter bestemder tijd, van jaar tot jaar. [^10] Het zal ook geschieden, wanneer u de HEERE in het land der Kanaänieten zal gebracht hebben, gelijk Hij u en uw vaderen gezworen heeft, en Hij het u zal gegeven hebben; [^11] Zo zult gij tot den HEERE doen overgaan alles, wat de baarmoeder opent; ook alles, wat de baarmoeder opent van de vrucht der beesten, die gij hebben zult; de mannetjes zullen des HEEREN zijn. [^12] Doch al wat de baarmoeder der ezelin opent, zult gij lossen met een lam; wanneer gij het nu niet lost, zo zult gij het den nek breken; maar alle eerstgeborenen des mensen onder uw zonen zult gij lossen. [^13] Wanneer het geschieden zal, dat uw zoon u morgen zal vragen, zeggende: Wat is dat? zo zult gij tot hem zeggen: De HEERE heeft ons door een sterke hand uit Egypte, uit het diensthuis, uitgevoerd. [^14] Want het geschiedde, toen Farao zich verhardde ons te laten trekken, zo doodde de HEERE alle eerstgeborenen in Egypteland, van des mensen eerstgeborene af, tot den eerstgeborene der beesten; daarom offer ik den HEERE de mannetjes van alles, wat de baarmoeder opent; doch alle eerstgeborenen mijner zonen los ik. [^15] En het zal tot een teken zijn op uw hand, en tot voorhoofdspanselen tussen uw ogen; want de HEERE heeft door een sterke hand ons uit Egypte uitgevoerd. [^16] En het is geschied, toen Farao het volk had laten trekken, zo leidde hen God niet op den weg van het land der Filistijnen, hoewel die nader was; want God zeide: Dat het den volke niet rouwe, als zij den strijd zien zouden, en wederkeren naar Egypte. [^17] Maar God leidde het volk om, langs den weg van de woestijn der Schelfzee. De kinderen Israëls nu togen bij vijven uit Egypteland. [^18] En Mozes nam de beenderen van Jozef met zich; want hij had met een zwaren eed de kinderen Israëls bezworen, zeggende: God zal ulieden voorzeker bezoeken; voert dan mijn beenderen met ulieden op van hier! [^19] Alzo reisden zij uit Sukkoth; en zij legerden zich in Etham, aan het einde der woestijn. [^20] En de HEERE toog voor hun aangezicht, des daags in een wolkkolom, dat Hij hen op den weg leidde, en des nachts in een vuurkolom, dat Hij hen lichtte, om voort te gaan dag en nacht. [^21] Hij nam de wolkkolom des daags, noch de vuurkolom des nachts niet weg van het aangezicht des volks. [^22] 

[[Exodus - 12|<--]] Exodus - 13 [[Exodus - 14|-->]]

---
# Notes
