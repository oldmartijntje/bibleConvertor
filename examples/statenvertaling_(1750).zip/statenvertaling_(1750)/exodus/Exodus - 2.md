---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 2 - Statenvertaling (1750)"
---
[[Exodus - 1|<--]] Exodus - 2 [[Exodus - 3|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Exodus]]

# Exodus - 2

En een man van het huis van Levi ging, en nam een dochter van Levi. [^1] En de vrouw werd zwanger, en baarde een zoon. Toen zij hem zag, dat hij schoon was, zo verborg zij hem drie maanden. [^2] Doch als zij hem niet langer verbergen kon, zo nam zij voor hem een kistje van biezen, en belijmde het met lijm en met pek; en zij legde het knechtje daarin, en legde het in de biezen, aan den oever der rivier. [^3] En zijn zuster stelde zich van verre, om te weten, wat hem gedaan zou worden. [^4] En de dochter van Farao ging af, om zich te wassen in de rivier; en haar jonkvrouwen wandelden aan den kant der rivier; toen zij het kistje in het midden van de biezen zag, zo zond zij haar dienstmaagd heen, en liet het halen. [^5] Toen zij het open deed, zo zag zij dat knechtje; en ziet, het jongsken weende; en zij werd met barmhartigheid bewogen over hetzelve, en zij zeide: Dit is een van de knechtjes der Hebreën! [^6] Toen zeide zijn zuster tot Farao’s dochter: Zal ik heengaan, en u een voedstervrouw uit de Hebreïnnen roepen, die dat knechtje voor u zoge? [^7] En de dochter van Farao zeide tot haar: Ga heen. En de jonge maagd ging, en riep des knechtjes moeder. [^8] Toen zeide Farao’s dochter tot haar: Neem dit knechtje heen, en zoog het mij; ik zal u uw loon geven. En de vrouw nam het knechtje en zoogde het. [^9] En toen het knechtje groot geworden was, zo bracht zij het tot Farao’s dochter, en het werd haar ten zoon; en zij noemde zijn naam Mozes, en zeide: Want ik heb hem uit het water getogen. [^10] En het geschiedde in die dagen, toen Mozes groot geworden was, dat hij uitging tot zijn broederen, en bezag hun lasten; en hij zag, dat een Egyptisch man een Hebreeuwsen man uit zijn broederen sloeg. [^11] En hij zag herwaarts en gindswaarts; en toen hij zag, dat er niemand was, zo versloeg hij den Egyptenaar, en verborg hem in het zand. [^12] Des anderen daags ging hij wederom uit, en ziet, twee Hebreeuwse mannen twistten; en hij zeide tot den ongerechte: Waarom slaat gij uw naaste? [^13] Hij dan zeide: Wie heeft u tot een overste en rechter over ons gezet? Zegt gij dit, om mij te doden, gelijk gij den Egyptenaar gedood hebt? Toen vreesde Mozes, en zeide: Voorwaar, deze zaak is bekend geworden! [^14] Als nu Farao deze zaak hoorde, zo zocht hij Mozes te doden; doch Mozes vlood voor Farao’s aangezicht, en woonde in het land Midian, en hij zat bij een waterput. [^15] En de priester in Midian had zeven dochters, die kwamen om te putten, en vulden de drinkbakken, om de kudde haars vaders te drenken. [^16] Toen kwamen de herders, en zij dreven haar van daar; doch Mozes stond op, en verloste ze, en drenkte haar kudden. [^17] En toen zij tot haar vader Rehuël kwamen, zo sprak hij: Waarom zijt gij heden zo haast wedergekomen? [^18] Toen zeiden zij: Een Egyptisch man heeft ons verlost uit de hand der herderen; en hij heeft ook overvloedig voor ons geput, en de kudde gedrenkt. [^19] En hij zeide tot zijn dochters: Waar is hij toch, waarom liet gij den man nu gaan? roept hem, dat hij brood ete. [^20] En Mozes bewilligde bij den man te wonen; en hij gaf Mozes zijn dochter Zippora; [^21] Die baarde een zoon; en hij noemde zijn naam Gersom; want hij zeide: Ik ben een vreemdeling geworden in een vreemd land. [^22] En het geschiedde na vele dezer dagen, als de koning van Egypte gestorven was, dat de kinderen Israëls zuchtten en schreeuwden over den dienst; en hun gekrijt over hun dienst kwam op tot God. [^23] En God hoorde hun gekerm, en God gedacht aan Zijn verbond met Abraham, met Izak, en met Jakob. [^24] En God zag de kinderen Israëls aan, en God kende hen. [^25] 

[[Exodus - 1|<--]] Exodus - 2 [[Exodus - 3|-->]]

---
# Notes
