---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 17 - Statenvertaling (1750)"
---
[[Exodus - 16|<--]] Exodus - 17 [[Exodus - 18|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Exodus]]

# Exodus - 17

Daarna toog de ganse vergadering van de kinderen Israëls, naar hun dagreizen, uit de woestijn Sin, op het bevel des HEEREN, en zij legerden zich te Rafidim. Daar nu was geen water voor het volk om te drinken. [^1] Toen twistte het volk met Mozes, en zeide: Geeft gijlieden ons water, dat wij drinken! Mozes dan zeide tot hen: Wat twist gij met mij? Waarom verzoekt gij den HEERE? [^2] Toen nu het volk aldaar dorstte naar water, zo murmureerde het volk tegen Mozes, en het zeide: Waartoe hebt gij ons nu uit Egypte doen optrekken, opdat gij mij, en mijn kinderen, en mijn vee, van dorst deed sterven? [^3] Zo riep Mozes tot den HEERE, zeggende: Wat zal ik dit volk doen? Er feilt niet veel aan, of zij zullen mij stenigen. [^4] Toen zeide de HEERE tot Mozes: Ga heen voor het aangezicht des volks, en neem met u uit de oudsten van Israël; en neem uw staf in uw hand, waarmede gij de rivier sloegt, en ga heen. [^5] Zie, Ik zal aldaar voor uw aangezicht op den rotssteen in Horeb staan; en gij zult op den rotssteen slaan, zo zal er water uitgaan, dat het volk drinke. Mozes nu deed alzo voor de ogen der oudsten van Israël. [^6] En hij noemde den naam dier plaats Massa en Meriba, om den twist der kinderen Israëls, en omdat zij den HEERE verzocht hadden, zeggende: Is de HEERE in het midden van ons, of niet? [^7] Toen kwam Amalek en streed tegen Israël in Rafidim. [^8] Mozes dan zeide tot Jozua: Kies ons mannen, en trek uit, strijd tegen Amalek; morgen zal ik op de hoogte des heuvels staan, en de staf Gods zal in mijn hand zijn. [^9] Jozua nu deed, als Mozes hem gezegd had, strijdende tegen Amalek; doch Mozes, Aäron en Hur klommen op de hoogte des heuvels. [^10] En het geschiedde, terwijl Mozes zijn hand ophief, zo was Israël de sterkste; maar terwijl hij zijn hand nederliet, zo was Amalek de sterkste. [^11] Doch de handen van Mozes werden zwaar; daarom namen zij een steen, en legden dien onder hem, dat hij daarop zat; en Aäron en Hur onderstutten zijn handen, de een op deze, de ander op de andere zijde; alzo waren zijn handen gewis, totdat de zon onderging. [^12] Alzo dat Jozua Amalek en zijn volk krenkte, door de scherpte des zwaards. [^13] Toen zeide de HEERE tot Mozes: Schrijf dit ter gedachtenis in een boek, en leg het in de oren van Jozua, dat Ik de gedachtenis van Amalek geheel uitdelgen zal van onder den hemel. [^14] En Mozes bouwde een altaar; en hij noemde deszelfs naam: De HEERE is mijn Banier! [^15] En hij zeide: Dewijl de hand op den troon des HEEREN is, zo zal de oorlog des HEEREN tegen Amalek zijn, van geslacht tot geslacht! [^16] 

[[Exodus - 16|<--]] Exodus - 17 [[Exodus - 18|-->]]

---
# Notes
