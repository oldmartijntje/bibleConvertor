---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 19 - Statenvertaling (1750)"
---
[[Exodus - 18|<--]] Exodus - 19 [[Exodus - 20|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Exodus]]

# Exodus - 19

In de derde maand, na het uittrekken der kinderen Israëls uit Egypteland, ten zelfden dage kwamen zij in de woestijn Sinaï. [^1] Want zij togen uit Rafidim, en kwamen in de woestijn Sinaï, en zij legerden zich in de woestijn; Israël nu legerde zich aldaar tegenover dien berg. [^2] En Mozes klom op tot God. En de HEERE riep tot hem van den berg, zeggende: Aldus zult gij tot het huis van Jakob spreken, en den kinderen Israëls verkondigen: [^3] Gijlieden hebt gezien, wat Ik den Egyptenaren gedaan heb; hoe Ik u op vleugelen der arenden gedragen en u tot Mij gebracht hebt. [^4] Nu dan, indien gij naarstiglijk Mijner stem zult gehoorzamen, en Mijn verbond houden, zo zult gij Mijn eigendom zijn uit alle volken, want de ganse aarde is Mijn; [^5] En gij zult Mij een priesterlijk koninkrijk, en een heilig volk zijn. Dit zijn de woorden, die gij tot de kinderen Israëls spreken zult. [^6] En Mozes kwam en riep de oudsten des volks, en stelde voor hun aangezichten al deze woorden, die de HEERE hem geboden had. [^7] Toen antwoordde al het volk gelijkelijk, en zeide: Al wat de HEERE gesproken heeft, zullen wij doen! En Mozes bracht de woorden des volks weder tot den HEERE. [^8] En de HEERE zeide tot Mozes: Zie, Ik zal tot u komen in een dikke wolk, opdat het volk hore, als Ik met u spreek, en dat zij ook eeuwiglijk aan u geloven. Want Mozes had den HEERE de woorden des volks verkondigd. [^9] Ook zeide de HEERE tot Mozes: Ga tot het volk, en heilig hen heden en morgen, en dat zij hun klederen wassen, [^10] En bereid zijn tegen den derden dag; want op den derden dag zal de HEERE voor de ogen van al het volk afkomen, op den berg Sinaï. [^11] En bepaal het volk rondom, zeggende: Wacht u op den berg te klimmen, en deszelfs einde aan te roeren; al wie den berg aanroert, zal zekerlijk gedood worden. [^12] Geen hand zal hem aanroeren, maar hij zal zekerlijk gestenigd, of zekerlijk doorschoten worden; hetzij een beest, hetzij een man, hij zal niet leven. Als de ramshoorn langzaam gaat, zullen zij op den berg klimmen. [^13] Toen ging Mozes van den berg af tot het volk, en hij heiligde het volk; en zij wiesen hun klederen. [^14] En hij zeide tot het volk: Weest gereed tegen den derden dag, en nadert niet tot de vrouw. [^15] En het geschiedde op den derden dag, toen het morgen was, dat er op den berg donderen en bliksemen waren, en een zware wolk, en het geluid ener zeer sterke bazuin, zodat al het volk verschrikte, dat in het leger was. [^16] En Mozes leidde het volk uit het leger, Gode tegemoet; en zij stonden aan het onderste des bergs. [^17] En de ganse berg Sinaï rookte, omdat de HEERE op denzelven nederkwam in vuur; en zijn rook ging op, als de rook van een oven; en de ganse berg beefde zeer. [^18] Toen het geluid der bazuin gaande was, en zeer sterk werd, sprak Mozes; en God antwoordde hem met een stem. [^19] Als de HEERE nedergekomen was op den berg Sinaï, op de spits des bergs, zo riep de HEERE Mozes op de spits des bergs; en Mozes klom op. [^20] En de HEERE zeide tot Mozes: Ga af, betuig dit volk, dat zij niet doorbreken tot den HEERE, om te zien, en velen van hen vallen. [^21] Daartoe zullen ook de priesters, die tot den HEERE naderen, zich heiligen, dat de HEERE niet tegen hen uitbreke. [^22] Toen zeide Mozes tot den HEERE: Het volk zal op den berg Sinaï niet kunnen klimmen, want Gij hebt ons betuigd, zeggende: Bepaal den berg, en heilig hem. [^23] De HEERE dan zeide tot hem: Ga heen, klim af, daarna zult gij, en Aäron met u, opklimmen; doch dat de priesters en het volk niet doorbreken, om op te klimmen tot den HEERE, dat Hij tegen hen niet uitbreke. [^24] Toen klom Mozes af tot het volk, en zeide het hun aan. [^25] 

[[Exodus - 18|<--]] Exodus - 19 [[Exodus - 20|-->]]

---
# Notes
