---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 20 - Statenvertaling (1750)"
---
[[Exodus - 19|<--]] Exodus - 20 [[Exodus - 21|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Exodus]]

# Exodus - 20

Toen sprak God al deze woorden, zeggende: [^1] Ik ben de HEERE uw God, Die u uit Egypteland, uit het diensthuis, uitgeleid heb. [^2] Gij zult geen andere goden voor Mijn aangezicht hebben. [^3] Gij zult u geen gesneden beeld, noch enige gelijkenis maken, van hetgeen boven in den hemel is, noch van hetgeen onder op de aarde is, noch van hetgeen in de wateren onder de aarde is. [^4] Gij zult u voor die niet buigen, noch hen dienen; want Ik, de HEERE uw God, ben een ijverig God, Die de misdaad der vaderen bezoek aan de kinderen, aan het derde, en aan het vierde lid dergenen, die Mij haten; [^5] En doe barmhartigheid aan duizenden dergenen, die Mij liefhebben, en Mijn geboden onderhouden. [^6] Gij zult den Naam des HEEREN uws Gods niet ijdellijk gebruiken; want de HEERE zal niet onschuldig houden, die Zijn Naam ijdellijk gebruikt. [^7] Gedenkt den sabbatdag, dat gij dien heiligt. [^8] Zes dagen zult gij arbeiden en al uw werk doen; [^9] Maar de zevende dag is de sabbat des HEEREN uws Gods; dan zult gij geen werk doen, gij, noch uw zoon, noch uw dochter, noch uw dienstknecht, noch uw dienstmaagd, noch uw vee, noch uw vreemdeling, die in uw poorten is; [^10] Want in zes dagen heeft de HEERE den hemel en de aarde gemaakt, de zee en al wat daarin is, en Hij rustte ten zevenden dage; daarom zegende de HEERE den sabbatdag, en heiligde denzelven. [^11] Eert uw vader en uw moeder, opdat uw dagen verlengd worden in het land, dat u de HEERE uw God geeft. [^12] Gij zult niet doodslaan. [^13] Gij zult niet echtbreken. [^14] Gij zult niet stelen. [^15] Gij zult geen valse getuigenis spreken tegen uw naaste. [^16] Gij zult niet begeren uws naasten huis; gij zult niet begeren uws naasten vrouw, noch zijn dienstknecht, noch zijn dienstmaagd, noch zijn os, noch zijn ezel, noch iets, dat uws naasten is. [^17] En al het volk zag de donderen, en de bliksemen, en het geluid der bazuin, en den rokenden berg; toen het volk zulks zag, weken zij af, en stonden van verre. [^18] En zij zeiden tot Mozes: Spreek gij met ons, en wij zullen horen; en dat God met ons niet spreke, opdat wij niet sterven! [^19] En Mozes zeide tot het volk: Vreest niet, want God is gekomen, opdat Hij u verzocht, en opdat Zijn vreze voor uw aangezicht zou zijn, dat gij niet zondigdet. [^20] En het volk stond van verre; maar Mozes naderde tot de donkerheid, alwaar God was. [^21] Toen zeide de HEERE tot Mozes: Aldus zult gij tot de kinderen Israëls zeggen: Gij hebt gezien, dat Ik met ulieden van den hemel gesproken heb. [^22] Gij zult nevens Mij niet maken zilveren goden, en gouden goden zult gij u niet maken. [^23] Maakt Mij een altaar van aarde, en offert daarop uw brandofferen, en uw dankofferen, uw schapen, en uw runderen; aan alle plaats, waar Ik Mijns Naams gedachtenis stichten zal, zal Ik tot u komen, en zal u zegenen. [^24] Maar indien gij Mij een stenen altaar zult maken, zo zult gij dit niet bouwen van gehouwen steen; zo gij uw houwijzer daarover verheft, zo zult gij het ontheiligen. [^25] Gij zult ook niet met trappen tot Mijn altaar opklimmen, opdat uw schaamte voor hetzelve niet ontdekt worde. [^26] 

[[Exodus - 19|<--]] Exodus - 20 [[Exodus - 21|-->]]

---
# Notes
