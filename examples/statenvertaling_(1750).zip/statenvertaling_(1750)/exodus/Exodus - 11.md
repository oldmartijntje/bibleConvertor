---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 11 - Statenvertaling (1750)"
---
[[Exodus - 10|<--]] Exodus - 11 [[Exodus - 12|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Exodus]]

# Exodus - 11

(Want de HEERE had tot Mozes gesproken: Ik zal nog één plaag over Farao, en over Egypte brengen, daarna zal hij ulieden van hier laten trekken; als hij u geheellijk zal laten trekken, zo zal hij u haastelijk van hier uitdrijven. [^1] Spreek nu voor de oren des volks, dat ieder man van zijn naaste, en iedere vrouw van haar naaste zilveren vaten en gouden vaten eise. [^2] En de HEERE gaf het volk genade in de ogen der Egyptenaren; ook was de man Mozes zeer groot in Egypteland voor de ogen van Farao’s knechten, en voor de ogen des volks.) [^3] Verder zeide Mozes: Zo heeft de HEERE gezegd: Omtrent middernacht zal Ik uitgaan door het midden van Egypte; [^4] En alle eerstgeborenen in Egypteland zullen sterven, van Farao’s eerstgeborene af, die op zijn troon zitten zou, tot den eerstgeborene der dienstmaagd, die achter den molen is, en alle eerstgeborenen van het vee. [^5] En er zal een groot geschrei zijn in het ganse Egypteland, desgelijke nooit geweest is, en desgelijke niet meer wezen zal. [^6] Maar bij alle kinderen Israëls zal niet een hond zijn tong verroeren, van de mensen af tot de beesten toe; opdat gijlieden weet, dat de HEERE tussen de Egyptenaren en tussen de Israëlieten een afzondering maakt. [^7] Dan zullen al deze uw knechten tot mij afkomen, en zich voor mij neigen, zeggende: Trek uit, gij en al het volk, dat uw voetstappen volgt; en daarna zal ik uitgaan. En hij ging uit van Farao in hitte des toorns. [^8] De HEERE dan had tot Mozes gesproken: Farao zal naar ulieden niet horen, opdat Mijn wonderen in Egypteland vermenigvuldigd worden. [^9] En Mozes en Aäron hebben al deze wonderen gedaan voor Farao’s aangezicht; doch de HEERE verhardde Farao’s hart, dat hij de kinderen Israëls uit zijn land niet trekken liet. [^10] 

[[Exodus - 10|<--]] Exodus - 11 [[Exodus - 12|-->]]

---
# Notes
