---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 6 - Statenvertaling (1750)"
---
[[Exodus - 5|<--]] Exodus - 6 [[Exodus - 7|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Exodus]]

# Exodus - 6

Verder sprak God tot Mozes, en zeide tot hem: Ik ben de HEERE, [^1] En Ik ben aan Abraham, Izak, en Jakob verschenen, als God de Almachtige; doch met Mijn Naam HEERE ben Ik hun niet bekend geweest. [^2] En ook heb Ik Mijn verbond met hen opgericht, dat Ik hun geven zou het land Kanaän, het land hunner vreemdelingschappen, waarin zij vreemdelingen geweest zijn. [^3] En ook heb Ik gehoord het gekerm der kinderen Israëls, die de Egyptenaars in dienstbaarheid houden, en Ik heb aan Mijn verbond gedacht. [^4] Derhalve zeg tot de kinderen Israëls: Ik ben de HEERE! en Ik zal ulieden uitleiden van onder de lasten der Egyptenaren, en Ik zal u redden uit hun dienstbaarheid, en zal u verlossen door een uitgestrekten arm, en door grote gerichten; [^5] En Ik zal ulieden tot Mijn volk aannemen, en Ik zal u tot een God zijn; en gijlieden zult bekennen, dat Ik de HEERE uw God ben, Die u uitleide van onder de lasten der Egyptenaren. [^6] En Ik zal ulieden brengen in dat land, waarover Ik Mijn hand opgeheven heb, dat Ik het aan Abraham, Izak, en Jakob geven zou; en Ik zal het ulieden geven tot een erfdeel, Ik, de HEERE! [^7] En Mozes sprak alzo tot de kinderen Israëls; doch zij hoorden naar Mozes niet, vanwege de benauwdheid des geestes, en vanwege de harde dienstbaarheid. [^8] Verder sprak de HEERE tot Mozes, zeggende: [^9] Ga heen, spreek tot Farao, den koning van Egypte, dat hij de kinderen Israëls uit zijn land trekken late. [^10] Doch Mozes sprak voor den HEERE, zeggende: Zie, de kinderen Israëls hebben naar mij niet gehoord; hoe zou mij dan Farao horen? daartoe ben ik onbesneden van lippen. [^11] Evenwel sprak de HEERE tot Mozes en tot Aäron, en gaf hun bevel aan de kinderen Israëls, en aan Farao, den koning van Egypte, om de kinderen Israëls uit Egypteland te leiden. [^12] Dit zijn de hoofden van ieder huis hunner vaderen: de zonen van Ruben, den eerstgeborene van Israël, zijn Hanoch en Pallu, Hezron en Charmi; dit zijn de huisgezinnen van Ruben. [^13] En de zonen van Simeon: Jemuël, en Jamin, en Ohad, en Jachin, en Zohar, en Saul, de zoon ener Kanaänietische; dit zijn de huisgezinnen van Simeon. [^14] Dit nu zijn de namen der zonen van Levi, naar hun geboorten: Gerson, en Kehath, en Merari. En de jaren des levens van Levi waren honderd zeven en dertig jaren. [^15] De zonen van Gerson: Libni en Simeï, naar hun huisgezinnen. [^16] En de zonen van Kehath: Amram, en Jizhar, en Hebron, en Uzziël, en de jaren des levens van Kehath waren honderd drie en dertig jaren. [^17] En de zonen van Merari: Machli en Musi; dit zijn de huisgezinnen van Levi, naar hun geboorten. [^18] En Amram nam Jochebed, zijn moei, zich tot een huisvrouw, en zij baarde hem Aäron en Mozes; en de jaren des levens van Amram waren honderd zeven en dertig jaren. [^19] En de zonen van Jizhar: Korah, en Nefeg, en Zichri. [^20] En de zonen van Uzziël: Misaël, en Elzafan, en Sithri. [^21] En Aäron nam zich tot een vrouw Eliseba, dochter van Amminadab, zuster van Nahesson; en zij baarde hem Nadab en Abihu, Eleazar en Ithamar. [^22] En de zonen van Korah waren: Assir, en Elkana, en Abiasaf; dat zijn de huisgezinnen der Korachieten. [^23] En Eleazar, de zoon van Aäron, nam voor zich een van de dochteren van Putiël tot een vrouw; en zij baarde hem Pinehas. Dit zijn de hoofden van de vaderen der Levieten, naar hun huisgezinnen. [^24] Dit is Aäron en Mozes, tot welke de HEERE zeide: Leidt de kinderen Israëls uit Egypteland, naar hun heiren. [^25] Dezen zijn het, die tot Farao, den koning van Egypte, spraken, opdat zij de kinderen Israëls uit Egypte leidden; dit is Mozes en Aäron. [^26] En het geschiedde te dien dage, als de HEERE tot Mozes sprak in Egypteland; [^27] Zo sprak de HEERE tot Mozes, zeggende: Ik ben de HEERE! spreek tot Farao, den koning van Egypte, alles, wat Ik tot u spreek. [^28] Toen zeide Mozes voor het aangezicht des HEEREN: Zie, ik ben onbesneden van lippen; hoe zal dan Farao naar mij horen? [^29] 

[[Exodus - 5|<--]] Exodus - 6 [[Exodus - 7|-->]]

---
# Notes
