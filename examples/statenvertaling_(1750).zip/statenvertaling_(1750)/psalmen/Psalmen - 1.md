---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/psalmen"
  - "#bible/testament/old"
aliases:
  - "Psalmen - 1 - Statenvertaling (1750)"
---
Psalmen - 1 [[Psalmen - 2|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Psalmen]]

# Psalmen - 1

Welgelukzalig is de man, die niet wandelt in den raad der goddelozen, noch staat op den weg der zondaren, noch zit in het gestoelte der spotters; [^1] Maar zijn lust is in des HEEREN wet, en hij overdenkt Zijn wet dag en nacht. [^2] Want hij zal zijn als een boom, geplant aan waterbeken, die zijn vrucht geeft op zijn tijd, en welks blad niet afvalt; en al wat hij doet, zal wel gelukken. [^3] Alzo zijn de goddelozen niet, maar als het kaf, dat de wind henendrijft. [^4] Daarom zullen de goddelozen niet bestaan in het gericht, noch de zondaars in de vergadering der rechtvaardigen. [^5] Want de HEERE kent den weg der rechtvaardigen; maar de weg der goddelozen zal vergaan. [^6] 

Psalmen - 1 [[Psalmen - 2|-->]]

---
# Notes
