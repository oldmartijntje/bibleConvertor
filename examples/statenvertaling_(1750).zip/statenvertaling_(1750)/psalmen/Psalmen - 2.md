---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/psalmen"
  - "#bible/testament/old"
aliases:
  - "Psalmen - 2 - Statenvertaling (1750)"
---
[[Psalmen - 1|<--]] Psalmen - 2 [[Psalmen - 3|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Psalmen]]

# Psalmen - 2

Waarom woeden de heidenen, en bedenken de volken ijdelheid? [^1] De koningen der aarde stellen zich op, en de vorsten beraadslagen te zamen tegen den HEERE, en tegen Zijn Gezalfde, zeggende: [^2] Laat ons hun banden verscheuren, en hun touwen van ons werpen. [^3] Die in den hemel woont, zal lachen; de Heere zal hen bespotten. [^4] Dan zal Hij tot hen spreken in Zijn toorn, en in Zijn grimmigheid zal Hij hen verschrikken. [^5] Ik toch heb Mijn Koning gezalfd over Sion, den berg Mijner heiligheid. [^6] Ik zal van het besluit verhalen: de HEERE heeft tot Mij gezegd: Gij zijt Mijn Zoon, heden heb Ik U gegenereerd. [^7] Eis van Mij, en Ik zal de heidenen geven tot Uw erfdeel, en de einden der aarde tot Uw bezitting. [^8] Gij zult hen verpletteren met een ijzeren scepter; Gij zult hen in stukken slaan als een pottenbakkersvat. [^9] Nu dan, gij koningen, handelt verstandiglijk; laat u tuchtigen, gij rechters der aarde! [^10] Dient den HEERE met vreze, en verheugt u met beving. [^11] Kust den Zoon, opdat Hij niet toorne, en gij op den weg vergaat, wanneer Zijn toorn maar een weinig zou ontbranden. Welgelukzalig zijn allen, die op Hem betrouwen. [^12] 

[[Psalmen - 1|<--]] Psalmen - 2 [[Psalmen - 3|-->]]

---
# Notes
