---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/ruth"
  - "#bible/testament/old"
aliases:
  - "Ruth - 4 - Statenvertaling (1750)"
---
[[Ruth - 3|<--]] Ruth - 4

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Ruth]]

# Ruth - 4

En Boaz ging op in de poort, en zette zich aldaar en ziet, de losser, van welken Boaz gesproken had, ging voorbij; zo zeide hij: Wijk herwaarts, zet u hier, gij, zulk een! En hij week derwaarts, en zette zich. [^1] En hij nam tien mannen van de oudsten der stad, en zeide: Zet u hier; en zij zetten zich. [^2] Toen zeide hij tot dien losser: Het stuk lands, dat van onzen broeder Elimelech was, heeft Naomi, die uit der Moabieten land wedergekomen is, verkocht; [^3] En ik heb gezegd: Ik zal het voor uw oor openbaren, zeggende: Aanvaard het in tegenwoordigheid der inwoners, en in tegenwoordigheid der oudsten mijns volks; zo gij het zult lossen, los het; en zo men het ook niet zou lossen, verklaar het mij, dat ik het wete; want er is niemand, behalve gij, die het losse, en ik na u. Toen zeide hij: Ik zal het lossen. [^4] Maar Boaz zeide: Ten dage, als gij het land aanvaardt van de hand van Naomi, zo zult gij het ook aanvaarden van Ruth, de Moabietische, de huisvrouw des verstorvenen, om den naam des verstorvenen te verwekken over zijn erfdeel. [^5] Toen zeide die losser: Ik zal het voor mij niet kunnen lossen, opdat ik mijn erfdeel niet misschien verderve; los gij mijn lossing voor u; want ik zal niet kunnen lossen. [^6] Nu was dit van ouds een gewoonheid in Israël, bij de lossing en bij de verwisseling, om de ganse zaak te bevestigen, zo trok de man zijn schoen uit en gaf dien aan zijn naaste; en dit was tot een getuigenis in Israël. [^7] Zo zeide deze losser tot Boaz: Aanvaard gij het voor u; en hij trok zijn schoen uit. [^8] Toen zeide Boaz tot de oudsten en al het volk: Gijlieden zijt heden getuigen, dat ik aanvaard heb alles, wat van Elimelech geweest is, en alles, wat van Chiljon en Machlon geweest is, van de hand van Naomi. [^9] Daartoe aanvaard ik mij ook Ruth, de Moabietische, de huisvrouw van Machlon, tot een vrouw, om den naam des verstorvenen over zijn erfdeel te verwekken, opdat de naam des verstorvenen niet worde uitgeroeid van zijn broederen, en van de poort zijner plaats; gijlieden zijt heden getuigen. [^10] En al het volk, dat in de poort was, mitsgaders de oudsten, zeiden: Wij zijn getuigen; de HEERE make deze vrouw, die in uw huis komt, als Rachel en als Lea, die beiden het huis van Israël gebouwd hebben; en handel kloekelijk in Efratha, en maak uw naam vermaard in Bethlehem! [^11] En uw huis zij, als het huis van Perez (dien Thamar aan Juda baarde), van het zaad, dat de HEERE u geven zal uit deze jonge vrouw. [^12] Alzo nam Boaz Ruth, en zij werd hem ter vrouwe, en hij ging tot haar in; en de HEERE gaf haar, dat zij zwanger werd en een zoon baarde. [^13] Toen zeiden de vrouwen tot Naomi: Geloofd zij de HEERE, Die niet heeft nagelaten u heden een losser te geven; en zijn naam worde vermaard in Israël! [^14] Die zal u zijn tot een verkwikker der ziel, en om uw ouderdom te onderhouden; want uw schoondochter, die u liefheeft, heeft hem gebaard, dewelke u beter is dan zeven zonen. [^15] En Naomi nam dat kind, en zette het op haar schoot, en werd zijn voedster. [^16] En de naburinnen gaven hem een naam, zeggende: Aan Naomi is een zoon geboren; en zij noemden zijn naam Obed; deze is de vader van Isaï, Davids vader. [^17] Dit nu zijn de geboorten van Perez: Perez gewon Hezron; [^18] En Hezron gewon Ram; en Ram gewon Amminadab; [^19] En Amminadab gewon Nahesson; en Nahesson gewon Salma; [^20] En Salmon gewon Boaz, en Boaz gewon Obed; [^21] En Obed gewon Isaï; en Isaï gewon David. [^22] 

[[Ruth - 3|<--]] Ruth - 4

---
# Notes
