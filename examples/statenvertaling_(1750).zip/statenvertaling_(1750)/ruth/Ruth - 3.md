---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/ruth"
  - "#bible/testament/old"
aliases:
  - "Ruth - 3 - Statenvertaling (1750)"
---
[[Ruth - 2|<--]] Ruth - 3 [[Ruth - 4|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Ruth]]

# Ruth - 3

En Naomi, haar schoonmoeder, zeide tot haar: Mijn dochter! zoude ik u geen rust zoeken, dat het u welga? [^1] Nu dan, is niet Boaz, met wiens maagden gij geweest zijt, van onze bloedvriendschap? Zie, hij zal dezen nacht gerst op den dorsvloer wannen. [^2] Zo baad u, en zalf u, en doe uw klederen aan, en ga af naar den dorsvloer; maar maak u den man niet bekend, totdat hij geëindigd zal hebben te eten en te drinken. [^3] En het zal geschieden, als hij nederligt, dat gij de plaats zult merken, waar hij zal nedergelegen zijn; ga dan in, en sla zijn voetdeksel op, en leg u; zo zal hij u te kennen geven, wat gij doen zult. [^4] En zij zeide tot haar: Al wat gij tot mij zegt, zal ik doen. [^5] Alzo ging zij af naar den dorsvloer, en deed naar alles, wat haar schoonmoeder haar geboden had. [^6] Als nu Boaz gegeten en gedronken had, en zijn hart vrolijk was, zo kwam hij om neder te liggen aan het uiterste van een korenhoop. Daarna kwam zij stilletjes in, en sloeg zijn voetdeksel op, en legde zich. [^7] En het geschiedde te middernacht, dat die man verschrikte, en om zich greep; en ziet, een vrouw lag aan zijn voetdeksel. [^8] En hij zeide: Wie zijt gij? En zij zeide: Ik ben Ruth, uw dienstmaagd, breid dan uw vleugel uit over uw dienstmaagd, want gij zijt de losser. [^9] En hij zeide: Gezegend zijt gij den HEERE, mijn dochter! Gij hebt deze uw laatste weldadigheid beter gemaakt dan de eerste, dewijl gij geen jonge gezellen zijt nagegaan, hetzij arm of rijk. [^10] En nu, mijn dochter, vrees niet; al wat gij gezegd hebt, zal ik u doen; want de ganse stad mijns volks weet, dat gij een deugdelijke vrouw zijt. [^11] Nu dan, wel is waar, dat ik een losser ben; maar er is nog een losser, nader dan ik. [^12] Blijf dezen nacht over; voorts in den morgen zal het geschieden, indien hij u lost, goed, laat hem lossen; maar indien het hem niet lust u te lossen, zo zal ik u lossen, zo waarachtig als de HEERE leeft; leg u neder tot den morgen toe. [^13] Alzo lag zij neder aan zijn voetdeksel tot den morgen toe; en zij stond op, eer dat de een den ander kennen kon; want hij zeide: Het worde niet bekend, dat een vrouw op den dorsvloer gekomen is. [^14] Voorts zeide hij: Lang den sluier, die op u is, en houd dien; en zij hield hem; en hij mat zes maten gerst, en legde ze op haar; daarna ging hij in de stad. [^15] Zij nu kwam tot haar schoonmoeder, dewelke zeide: Wie zijt gij, mijn dochter? En zij verhaalde haar alles, wat die man haar gedaan had. [^16] Ook zeide zij: Deze zes maten gerst heeft hij mij gegeven; want hij zeide tot mij: Kom niet ledig tot uw schoonmoeder. [^17] Toen zeide zij: Zit stil, mijn dochter, totdat gij weet, hoe de zaak zal vallen; want die man zal niet rusten, tenzij dat hij heden deze zaak voleind hebbe. [^18] 

[[Ruth - 2|<--]] Ruth - 3 [[Ruth - 4|-->]]

---
# Notes
