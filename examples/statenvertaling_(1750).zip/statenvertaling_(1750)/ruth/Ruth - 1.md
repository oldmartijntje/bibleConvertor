---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/ruth"
  - "#bible/testament/old"
aliases:
  - "Ruth - 1 - Statenvertaling (1750)"
---
Ruth - 1 [[Ruth - 2|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Ruth]]

# Ruth - 1

In de dagen, als de richters richtten, zo geschiedde het, dat er honger in het land was; daarom toog een man van Bethlehem-Juda, om als vreemdeling te verkeren in de velden Moabs, hij, en zijn huisvrouw, en zijn twee zonen. [^1] De naam nu dezes mans was Elimelech, en de naam zijner huisvrouw Naomi, en de naam zijner twee zonen Machlon en Chiljon, Efrathers, van Bethlehem-Juda; en zij kwamen in de velden Moabs, en bleven aldaar. [^2] En Elimelech, de man van Naomi, stierf; maar zij werd overgelaten met haar twee zonen. [^3] Die namen zich Moabietische vrouwen; de naam der ene was Orpa, en de naam der andere Ruth; en zij bleven aldaar omtrent tien jaren. [^4] En die twee, Machlon en Chiljon, stierven ook; alzo werd deze vrouw overgelaten na haar twee zonen en na haar man. [^5] Toen maakte zij zich op met haar schoondochters, en keerde weder uit de velden van Moab; want zij had gehoord in het land van Moab, dat de HEERE Zijn volk bezocht had, gevende hun brood. [^6] Daarom ging zij uit van de plaats, waar zij geweest was en haar twee schoondochters met haar. Als zij nu gingen op den weg, om weder te keren naar het land van Juda, [^7] Zo zeide Naomi tot haar twee schoondochters: Gaat heen, keert weder, een iegelijk tot het huis van haar moeder; de HEERE doe bij u weldadigheid, gelijk als gij gedaan hebt bij de doden, en bij mij. [^8] De HEERE geve u, dat gij ruste vindt, een iegelijk in het huis van haar man! En als zij haar kuste, hieven zij haar stem op en weenden; [^9] En zij zeiden tot haar: Wij zullen zekerlijk met u wederkeren tot uw volk. [^10] Maar Naomi zeide: Keert weder, mijn dochters! Waarom zoudt gij met mij gaan? Heb ik nog zonen in mijn lichaam, dat zij u tot mannen zouden zijn? [^11] Keert weder, mijn dochters! Gaat heen; want ik ben te oud om een man te hebben. Wanneer ik al zeide: Ik heb hoop, of ik ook in dezen nacht een man had, ja, ook zonen baarde; [^12] Zoudt gij daarnaar wachten, totdat zij zouden groot geworden zijn; zoudt gij daarnaar opgehouden worden, om geen man te nemen? Niet, mijn dochters! Want het is mij veel bitterder dan u; maar de hand des HEEREN is tegen mij uitgegaan. [^13] Toen hieven zij haar stem op, en weenden wederom; en Orpa kuste haar schoonmoeder, maar Ruth kleefde haar aan. [^14] Daarom zeide zij: Zie, uw zwagerin is wedergekeerd tot haar volk en tot haar goden; keer gij ook weder, uw zwagerin na. [^15] Maar Ruth zeide: Val mij niet tegen, dat ik u zou verlaten, om van achter u weder te keren; want waar gij zult heengaan, zal ik ook heengaan, en waar gij zult vernachten, zal ik vernachten; uw volk is mijn volk, en uw God mijn God. [^16] Waar gij zult sterven, zal ik sterven, en aldaar zal ik begraven worden; alzo doe mij de HEERE en alzo doe Hij daartoe, zo niet de dood alleen zal scheiding maken tussen mij en tussen u! [^17] Als zij nu zag, dat zij vastelijk voorgenomen had met haar te gaan, zo hield zij op tot haar te spreken. [^18] Alzo gingen die beiden, totdat zij te Bethlehem inkwamen; en het geschiedde, als zij te Bethlehem inkwamen, dat de ganse stad over haar beroerd werd, en zij zeiden: Is dit Naomi? [^19] Maar zij zeide tot henlieden: Noemt mij niet Naomi, noemt mij Mara; want de Almachtige heeft mij grote bitterheid aangedaan. [^20] Vol toog ik weg, maar ledig heeft mij de HEERE doen wederkeren; waarom zoudt gij mij Naomi noemen, daar de HEERE tegen mij getuigt, en de Almachtige mij kwaad aangedaan heeft? [^21] Alzo kwam Naomi weder, en Ruth, de Moabietische, haar schoondochter, met haar, die uit de velden Moabs wederkwam; en zij kwamen te Bethlehem in het begin van den gersteoogst. [^22] 

Ruth - 1 [[Ruth - 2|-->]]

---
# Notes
