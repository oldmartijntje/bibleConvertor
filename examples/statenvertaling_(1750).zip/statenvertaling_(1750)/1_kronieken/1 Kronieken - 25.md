---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_kronieken"
  - "#bible/testament/old"
aliases:
  - "1 Kronieken - 25 - Statenvertaling (1750)"
---
[[1 Kronieken - 24|<--]] 1 Kronieken - 25 [[1 Kronieken - 26|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[1 Kronieken]]

# 1 Kronieken - 25

En David, mitsgaders de oversten des heirs, scheidde af tot den dienst, van de kinderen van Asaf, en van Heman, en van Jeduthun, die met harpen, met luiten en met cimbalen profeteren zouden; en die onder hen geteld werden, waren mannen, bekwaam tot het werk van hun dienst. [^1] Van de kinderen van Asaf waren Zakkur, en Jozef, en Nethanja, en Asarela, kinderen van Asaf; aan de hand van Asaf, die aan des konings handen profeteerde. [^2] Aangaande Jeduthun: de kinderen van Jeduthun waren Gedalja, en Zeri, en Jesaja, Hasabja en Mattithja, zes; aan de handen van hun vader Jeduthun, op harpen profeterende met den HEERE te danken en te loven. [^3] Aangaande Heman: de kinderen van Heman waren Bukkia, Mattanja, Uzziël, Sebuël, en Jerimoth, Hananja, Hanani, Eliatha, Giddalti, en Romamthi-Ezer, Josbekasa, Mallothi, Hothir, Mahazioth. [^4] Deze allen waren kinderen van Heman, den ziener des konings, in de woorden Gods, om den hoorn te verheffen; want God had Heman veertien zonen gegeven, en drie dochters. [^5] Dezen waren altemaal aan de handen huns vaders gesteld tot het gezang van het huis des HEEREN, op cimbalen, luiten, en harpen, tot den dienst van het huis Gods, aan de handen van den koning, van Asaf, Jeduthun, en van Heman. [^6] En hun getal met hun broederen, die geleerd waren in het gezang des HEEREN, allen meesters, was tweehonderd acht en tachtig. [^7] En zij wierpen de loten over de wacht, tegen elkander, zo de kleinen, als de groten, den meester met den leerling. [^8] Het eerste lot nu ging uit voor Asaf, namelijk voor Jozef. Het tweede voor Gedalja; hij en zijn broederen, en zijn zonen, waren twaalf. [^9] Het derde voor Zakkur; zijn zonen en zijn broederen, twaalf. [^10] Het vierde voor Jizri; zijn zonen en zijn broederen, twaalf. [^11] Het vijfde voor Nethanja; zijn zonen en zijn broederen, twaalf. [^12] Het zesde voor Bukkia; zijn zonen en zijn broederen, twaalf. [^13] Het zevende voor Jesarela; zijn zonen en zijn broederen, twaalf. [^14] Het achtste voor Jesaja; zijn zonen en zijn broederen, twaalf. [^15] Het negende voor Mattanja; zijn zonen en zijn broederen, twaalf. [^16] Het tiende voor Simeï; zijn zonen en zijn broederen, twaalf. [^17] Het elfde voor Azareël; zijn zonen en zijn broederen, twaalf. [^18] Het twaalfde voor Hasabja; zijn zonen en zijn broederen, twaalf. [^19] Het dertiende voor Subaël; zijn zonen en zijn broederen, twaalf. [^20] Het veertiende voor Mattithja; zijn zonen en zijn broederen, twaalf. [^21] Het vijftiende voor Jeremoth; zijn zonen en zijn broederen, twaalf. [^22] Het zestiende voor Hananja; zijn zonen en zijn broederen, twaalf. [^23] Het zeventiende voor Josbekasa; zijn zonen en zijn broederen, twaalf. [^24] Het achttiende voor Hanani; zijn zonen en zijn broederen, twaalf. [^25] Het negentiende voor Mallothi; zijn zonen en zijn broederen; twaalf. [^26] Het twintigste voor Eliatha; zijn zonen en zijn broederen; twaalf. [^27] Het een en twintigste voor Hothir; zijn zonen en zijn broederen, twaalf. [^28] Het twee en twintigste voor Giddalti; zijn zonen en zijn broederen, twaalf. [^29] Het drie en twintigste voor Mahazioth; zijn zonen en zijn broederen, twaalf. [^30] Het vier en twintigste voor Romamthi-Ezer; zijn zonen en zijn broederen, twaalf. [^31] 

[[1 Kronieken - 24|<--]] 1 Kronieken - 25 [[1 Kronieken - 26|-->]]

---
# Notes
