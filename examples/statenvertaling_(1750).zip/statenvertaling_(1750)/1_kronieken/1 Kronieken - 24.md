---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_kronieken"
  - "#bible/testament/old"
aliases:
  - "1 Kronieken - 24 - Statenvertaling (1750)"
---
[[1 Kronieken - 23|<--]] 1 Kronieken - 24 [[1 Kronieken - 25|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[1 Kronieken]]

# 1 Kronieken - 24

Aangaande nu de kinderen van Aäron, dit waren hun verdelingen. De zonen van Aäron waren Nadab, en Abihu, Eleazar en Ithamar. [^1] Maar Nadab stierf, en Abihu, voor het aangezicht huns vaders, en zij hadden geen kinderen. En Eleazar en Ithamar bedienden het priesterambt. [^2] David nu verdeelde hen, en Zadok uit de kinderen van Eleazar, en Abimelech uit de kinderen van Ithamar, naar hun ambt in hun dienst. [^3] En van de kinderen van Eleazar werden meer gevonden tot hoofden der mannen, dan van de kinderen van Ithamar, als zij hen afdeelden; van de kinderen van Eleazar waren zestien hoofden der vaderlijke huizen, maar van de kinderen van Ithamar, naar hun vaderlijke huizen, acht. [^4] En zij deelden hen door loten af, dezen met genen; want de oversten des heiligdoms en de oversten Gods waren uit de kinderen van Eleazar en van de kinderen van Ithamar. [^5] En Semaja, de zoon van Nethaneël, de schrijver, uit de Levieten, schreef hen op, voor het aangezicht des konings, en van de vorsten, en van den priester Zadok, en van Achimelech, den zoon van Abjathar, en van de hoofden der vaderen onder de priesters en onder de Levieten; één vaderlijk huis werd genomen voor Eleazar, en desgelijks werd genomen voor Ithamar. [^6] Het eerste lot nu ging uit voor Jojarib, het tweede voor Jedaja, [^7] Het derde voor Harim, het vierde voor Seorim, [^8] Het vijfde voor Malchia, het zesde voor Mijamin, [^9] Het zevende voor Hakkoz, het achtste voor Abia, [^10] Het negende voor Jesua, het tiende voor Sechanja, [^11] Het elfde voor Eljasib, het twaalfde voor Jakim, [^12] Het dertiende voor Huppa, het veertiende voor Jesebeab, [^13] Het vijftiende voor Bilga, het zestiende voor Immer, [^14] Het zeventiende voor Hezir, het achttiende voor Happizzes, [^15] Het negentiende voor Petahja, het twintigste voor Jehezkel, [^16] Het een en twintigste voor Jachin, het twee en twintigste voor Gamul, [^17] Het drie en twintigste voor Delaja, het vier en twintigste voor Maäzja. [^18] Het ambt van dezen in hun dienst was te gaan in het huis des HEEREN, naar hun ordening door de hand van Aäron, huns vaders; gelijk als hem de HEERE, de God Israëls, geboden had. [^19] Van de overige kinderen van Levi nu, was van de kinderen van Amram Subaël, van de kinderen van Subaël was Jechdeja. [^20] Aangaande Rehabja: van de kinderen van Rehabja was Jissia het hoofd. [^21] Van de Jizharieten was Selomoth; van de kinderen van Selomoth was Jahath. [^22] En van de kinderen van Hebron was Jeria de eerste, Amarja de tweede, Jahaziël de derde, Jekameam de vierde. [^23] Van de kinderen van Uzziël was Micha; van de kinderen van Micha was Samir; [^24] De broeder van Micha was Jissia; van de kinderen van Jissia was Zecharja. [^25] De kinderen van Merari waren Maheli en Musi. De kinderen van Jaäzia waren Beno. [^26] De kinderen van Merari van Jaäzia waren Beno, en Soham, en Zakkur, en Hibri. [^27] Van Maheli was Eleazar; en die had geen kinderen. [^28] Aangaande Kis: de kinderen van Kis waren Jerahmeël. [^29] En de kinderen van Musi waren Maheli, en Eder, en Jeremoth. Dezen zijn de kinderen der Levieten, naar hun vaderlijke huizen. [^30] En zij wierpen ook loten, nevens hun broederen, de zonen van Aäron, voor het aangezicht van den koning David, en Zadok, en Achimelech, en van de hoofden der vaderen onder de priesteren en onder de Levieten; het hoofd der vaderen tegen zijn kleinsten broeder. [^31] 

[[1 Kronieken - 23|<--]] 1 Kronieken - 24 [[1 Kronieken - 25|-->]]

---
# Notes
