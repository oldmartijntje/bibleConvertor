---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_kronieken"
  - "#bible/testament/old"
aliases:
  - "1 Kronieken - 3 - Statenvertaling (1750)"
---
[[1 Kronieken - 2|<--]] 1 Kronieken - 3 [[1 Kronieken - 4|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[1 Kronieken]]

# 1 Kronieken - 3

Dezen nu waren de kinderen van David, die hem te Hebron geboren zijn: de eerstgeborene Amnon, van Ahinoam, de Jizreëlietische; de tweede Daniël, van Abigaïl, de Karmelietische; [^1] De derde Absalom, de zoon van Maächa, de dochter van Thalmai, den koning te Gesur; de vierde Adonia, de zoon van Haggith; [^2] De vijfde Sefatja, van Abital; de zesde Jithream, van zijn huisvrouw Egla. [^3] Zes zijn hem te Hebron geboren; want hij regeerde daar zeven jaren en zes maanden; en drie en dertig jaren regeerde hij te Jeruzalem. [^4] Dezen nu zijn hem te Jeruzalem geboren: Simea, en Sobab, en Nathan, en Salomo; deze vier zijn van Bath-Sua, de dochter van Ammiël; [^5] Daartoe Jibchar, en Elisama, en Elifelet, [^6] En Nogah, en Nefeg, en Jafia, [^7] En Elisama, en Eljada, en Elifelet, negen. [^8] Deze allen zijn zonen van David, behalve de kinderen der bijwijven, en Thamar hun zuster. [^9] Salomo’s zoon nu was Rehabeam; zijn zoon was Abia; zijn zoon was Asa; zijn zoon was Josafat; [^10] Zijn zoon was Joram; zijn zoon was Ahazia; zijn zoon was Joas; [^11] Zijn zoon was Amazia; zijn zoon was Azaria; zijn zoon was Jotham; [^12] Zijn zoon was Achaz; zijn zoon was Hizkia; zijn zoon was Manasse; [^13] Zijn zoon was Amon; zijn zoon was Josia. [^14] De zonen van Josia nu waren dezen: de eerstgeborene Johanan, de tweede Jojakim, de derde Zedekia, de vierde Sallum. [^15] De kinderen van Jojakim nu waren: Jechonia zijn zoon, Zedekia zijn zoon. [^16] En de kinderen van Jechonia waren Assir; zijn zoon was Sealthiël; [^17] Dezes zonen waren Malchiram, en Pedaja, en Senazar, Jekamja, Hosama en Nedabja. [^18] De kinderen van Pedaja nu waren Zerubbabel en Simeï; en de kinderen van Zerubbabel waren Mesullam en Hananja; en Selomith was hunlieder zuster; [^19] En Hasuba, en Ohel, en Berechja, en Hasadja, Jusabhesed; vijf. [^20] De kinderen van Hananja nu waren Pelatja en Jesaja. De kinderen van Refaja, de kinderen van Arnan, de kinderen van Obadja, de kinderen van Sechanja. [^21] De kinderen nu van Sechanja waren Semaja; en de kinderen van Semaja waren Hattus, en Jigeal, en Bariah, en Nearja, en Safat; zes. [^22] En de kinderen van Nearja waren Eljoënai, en Hizkia, en Azrikam; drie. [^23] En de kinderen van Eljoënai waren Hodajeva, en Eljasib, en Pelaja, en Akkub, en Johanan, en Delaja, en Anani; zeven. [^24] 

[[1 Kronieken - 2|<--]] 1 Kronieken - 3 [[1 Kronieken - 4|-->]]

---
# Notes
