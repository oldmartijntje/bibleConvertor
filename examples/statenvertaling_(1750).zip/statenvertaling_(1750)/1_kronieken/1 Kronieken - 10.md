---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_kronieken"
  - "#bible/testament/old"
aliases:
  - "1 Kronieken - 10 - Statenvertaling (1750)"
---
[[1 Kronieken - 9|<--]] 1 Kronieken - 10 [[1 Kronieken - 11|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[1 Kronieken]]

# 1 Kronieken - 10

En de Filistijnen streden tegen Israël, en de mannen van Israël vloden voor het aangezicht der Filistijnen, en zij vielen verslagen op het gebergte Gilboa. [^1] En de Filistijnen hielden dicht achter Saul aan en achter zijn zonen; en de Filistijnen sloegen Jonathan, en Abinadab, en Malchi-sua, de zonen van Saul. [^2] En de strijd werd zwaar tegen Saul, en de schutters met de bogen troffen hem aan; en hij vreesde zeer voor de schutters. [^3] Toen zeide Saul tot zijn wapendrager: Trek uw zwaard uit en doorsteek mij daarmede, dat misschien deze onbesnedenen niet komen, en met mij den spot drijven. Maar zijn wapendrager wilde niet, want hij vreesde zeer. Toen nam Saul het zwaard, en viel daarin. [^4] Toen zijn wapendrager zag, dat Saul dood was, zo viel hij ook in het zwaard en stierf. [^5] Alzo stierf Saul en zijn drie zonen; ook zijn ganse huis is tegelijk gestorven. [^6] Als al de mannen van Israël, die in het dal waren, zagen, dat zij gevloden waren, en dat Saul en zijn zonen dood waren, zo verlieten zij hun steden, en zij vloden. Toen kwamen de Filistijnen en woonden daarin. [^7] Het geschiedde nu des anderen daags, als de Filistijnen kwamen om de verslagenen te plunderen, zo vonden zij Saul en zijn zonen, liggende op het gebergte Gilboa. [^8] En zij plunderden hem, en zij namen zijn hoofd en zijn wapenen, en zij zonden ze in der Filistijnen land rondom, om dit te boodschappen aan hun afgoden, en aan het volk. [^9] En zij legden zijn wapenen in het huis huns gods; en zijn hoofd hechtten zij in het huis van Dagon. [^10] Als geheel Jabes in Gilead hoorde alles, wat de Filistijnen Saul gedaan hadden, [^11] Zo maakten zich alle strijdbare mannen op, en zij namen het lichaam van Saul, en de lichamen zijner zonen, en zij brachten ze te Jabes; en zij begroeven hun beenderen onder een eikenboom te Jabes, en zij vastten zeven dagen. [^12] Alzo stierf Saul, in zijn overtreding, waarmede hij overtreden had tegen den HEERE, tegen het woord des HEEREN, hetwelk hij niet gehouden had; en ook omdat hij de waarzegster gevraagd had, haar zoekende, [^13] En den HEERE niet gezocht had; daarom doodde Hij hem, en keerde het koninkrijk tot David, den zoon van Isaï. [^14] 

[[1 Kronieken - 9|<--]] 1 Kronieken - 10 [[1 Kronieken - 11|-->]]

---
# Notes
