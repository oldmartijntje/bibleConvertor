---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_kronieken"
  - "#bible/testament/old"
aliases:
  - "1 Kronieken - 14 - Statenvertaling (1750)"
---
[[1 Kronieken - 13|<--]] 1 Kronieken - 14 [[1 Kronieken - 15|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[1 Kronieken]]

# 1 Kronieken - 14

Toen zond Hiram, de koning van Tyrus, boden tot David, en cederenhout, en metselaars, en timmerlieden, dat zij hem een huis bouwden. [^1] En David merkte, dat hem de HEERE tot koning bevestigd had over Israël; want zijn koninkrijk werd ten hoogste verheven, om Zijns volks Israëls wil. [^2] En David nam meer vrouwen te Jeruzalem, en David gewon meer zonen en dochteren. [^3] Dit nu zijn de namen der kinderen, die hij te Jeruzalem had: Sammua, en Sobab, Nathan en Salomo, [^4] En Jibchar, en Elisua, en Elpelet, [^5] En Nogah, en Nefeg, en Jafia, [^6] En Elisama, en Beëljada, en Elifelet. [^7] Toen de Filistijnen hoorden, dat David tot koning gezalfd was over het ganse Israël, zo togen al de Filistijnen op om David te zoeken. Toen David dat hoorde zo toog hij uit tegen hen. [^8] Toen de Filistijnen kwamen, zo spreidden zij zich uit in de laagte van Refaïm. [^9] Toen vraagde David God, zeggende: Zal ik optrekken tegen de Filistijnen, en zult Gij hen in mijn hand geven? En de HEERE zeide tot hem: Trek op, want Ik zal hen in uw hand geven. [^10] Toen zij nu optogen naar Baäl-Perazim, zo sloeg hen David daar; en David zeide: God heeft mijn vijanden door mijn hand gescheurd, als een scheur der wateren; daarom noemden zij den naam derzelver plaats Baäl-Perazim. [^11] En daar lieten zij hun goden; en David gebood, en zij werden met vuur verbrand. [^12] Doch de Filistijnen voeren nog voort, en zij verspreidden zich in dat dal. [^13] En David vraagde God nog eens; en God zeide tot hem: Gij zult niet optrekken achter hen heen; maar omsingel hen van boven, en kom tot hen tegenover de moerbeziënbomen. [^14] En het zal geschieden, als gij hoort het geruis van een gang in de toppen der moerbeziënbomen, kom dan uit ten strijde; want God zal voor uw aangezicht uitgegaan zijn, om het leger der Filistijnen te slaan. [^15] David nu deed, gelijk als hem God geboden had; en zij sloegen het heir der Filistijnen van Gibeon af tot aan Gezer. [^16] Alzo ging Davids naam uit in al die landen; en de HEERE gaf zijn verschrikking over al die heidenen. [^17] 

[[1 Kronieken - 13|<--]] 1 Kronieken - 14 [[1 Kronieken - 15|-->]]

---
# Notes
