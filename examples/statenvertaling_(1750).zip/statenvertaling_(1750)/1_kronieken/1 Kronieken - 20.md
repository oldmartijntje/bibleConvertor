---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_kronieken"
  - "#bible/testament/old"
aliases:
  - "1 Kronieken - 20 - Statenvertaling (1750)"
---
[[1 Kronieken - 19|<--]] 1 Kronieken - 20 [[1 Kronieken - 21|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[1 Kronieken]]

# 1 Kronieken - 20

Het geschiedde nu ten tijde van de wederkomst des jaars, ten tijde als de koningen uittrokken, zo voerde Joab de heirkracht, en hij verdierf het land der kinderen Ammons; en hij kwam, en belegerde Rabba; maar David bleef te Jeruzalem. En Joab sloeg Rabba, en verwoestte ze. [^1] En David nam de kroon huns konings van zijn hoofd, en hij bevond haar in gewicht een talent gouds, en daar was edelgesteente aan; en zij werd op Davids hoofd gezet, en hij voerde zeer veel roofs uit de stad. [^2] Hij voerde ook al het volk uit, dat daarin was, en hij zaagde ze met de zaag, en met ijzeren dorswagens, en met bijlen; en alzo deed David aan al de steden der kinderen Ammons. Toen keerde David wederom met al het volk naar Jeruzalem. [^3] En het geschiedde daarna, als de krijg met de Filistijnen te Gezer opstond, toen sloeg Sibchai, de Husathiet, Sippai, die van de kinderen van Rafa was; en zij werden ten ondergebracht. [^4] Daarna was er nog een krijg tegen de Filistijnen, en Elhanan, de zoon van Jaïr, versloeg Lachmi, den broeder van Goliath, den Gethiet, wiens spieshout was als een weversboom. [^5] Daarna was er nog een krijg te Gath; en daar was een zeer lang man, en zijn vingeren waren zes en zes, vier en twintig, en hij was ook van Rafa geboren; [^6] En hij hoonde Israël, maar Jonathan, de zoon van Simea, den broeder van David, versloeg hem. [^7] Dezen waren van Rafa geboren te Gath; en zij vielen door de hand van David, en door de hand zijner knechten. [^8] 

[[1 Kronieken - 19|<--]] 1 Kronieken - 20 [[1 Kronieken - 21|-->]]

---
# Notes
