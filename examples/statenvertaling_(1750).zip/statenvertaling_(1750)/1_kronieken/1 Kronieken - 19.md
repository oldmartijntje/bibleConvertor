---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_kronieken"
  - "#bible/testament/old"
aliases:
  - "1 Kronieken - 19 - Statenvertaling (1750)"
---
[[1 Kronieken - 18|<--]] 1 Kronieken - 19 [[1 Kronieken - 20|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[1 Kronieken]]

# 1 Kronieken - 19

En het geschiedde na dezen, dat Nahas, de koning der kinderen Ammons, stierf, en zijn zoon werd koning in zijn plaats. [^1] Toen zeide David: Ik zal weldadigheid doen aan Hanun, den zoon van Nahas; want zijn vader heeft weldadigheid aan mij gedaan. Daarom zond David boden, om hem te troosten over zijn vader. Toen de knechten van David in het land der kinderen Ammons tot Hanun kwamen, om hem te troosten, [^2] Zo zeiden de vorsten der kinderen Ammons tot Hanun: Eert David uw vader in uw ogen, omdat hij troosters tot u gezonden heeft? Zijn niet zijn knechten tot u gekomen, om te doorzoeken, en om om te keren, en om het land te verspieden? [^3] Daarom nam Hanun de knechten van David, en hij beschoor hen, en sneed hun klederen half af tot aan de heupen, en liet hen henengaan. [^4] Zij nu gingen henen, en men boodschapte David van deze mannen; en hij zond hun tegemoet; want die mannen waren zeer beschaamd. De koning dan zeide: Blijft te Jericho, totdat ulieder baard weder gewassen zij; komt dan wederom. [^5] Toen de kinderen Ammons zagen, dat zij zich stinkende gemaakt hadden bij David, zo zond Hanun en de kinderen Ammons duizend talenten zilvers, om zich wagenen en ruiters te huren uit Mesopotamië, en uit Syrië-Maächa, en uit Zoba; [^6] Zodat zij zich huurden twee en dertig duizend wagenen; en de koning van Maächa en zijn volk kwamen en legerden zich voor Medeba; ook vergaderden de kinderen Ammons uit hun steden, en zij kwamen ten strijde. [^7] Toen het David hoorde, zo zond hij Joab en het ganse heir met de helden. [^8] Als de kinderen Ammons uitgetogen waren, zo stelden zij de slagorde voor de poort der stad; maar de koningen, die gekomen waren, die waren bijzonder in het veld. [^9] Toen Joab zag, dat de spits der slagorde van voren en van achteren tegen hem was, zo verkoos hij enigen uit alle uitgelezenen in Israël, en hij stelde hen in orde tegen de Syriërs aan. [^10] En het overige des volks gaf hij in de hand van zijn broeder Abisaï, en zij stelden hen in orde tegen de kinderen Ammons aan. [^11] En hij zeide: Indien mij de Syriërs te sterk worden, zo zult gij mij komen verlossen; en indien de kinderen Ammons u te sterk worden, zo zal ik u verlossen. [^12] Wees sterk, en laat ons sterk zijn voor ons volk, en voor de steden onzes Gods; de HEERE nu doe, wat goed is in Zijn ogen. [^13] Toen naderde Joab en het volk, dat bij hem was, ten strijde voor het aangezicht der Syriërs; en zij vloden voor zijn aangezicht. [^14] Toen de kinderen Ammons zagen, dat de Syriërs vloden, zo vloden zij ook voor het aangezicht van Abisaï, zijn broeder, en zij kwamen in de stad; en Joab kwam te Jeruzalem. [^15] Als de Syriërs zagen, dat zij voor het aangezicht van Israël geslagen waren, zo zonden zij boden, en brachten de Syriërs uit, die aan gene zijde der rivier woonden; en Sofach, de krijgsoverste van Hadar-ezer, toog voor hun aangezicht heen. [^16] Toen het David werd aangezegd, zo vergaderde hij gans Israël, en hij toog over de Jordaan, en hij kwam tot hen, en hij stelde de slagorde tegen hen. Als David de slagorde tegen de Syriërs gesteld had, zo streden zij met hem. [^17] Doch de Syriërs vloden voor het aangezicht van Israël, en David versloeg van de Syriërs zeven duizend wagenen, en veertig duizend mannen te voet; daartoe doodde hij Sofach, den krijgsoverste. [^18] Toen de knechten van Hadar-ezer zagen, dat zij geslagen waren, voor het aangezicht van Israël, zo maakten zij vrede met David, en dienden hem; en de Syriërs wilden de kinderen Ammons niet meer verlossen. [^19] 

[[1 Kronieken - 18|<--]] 1 Kronieken - 19 [[1 Kronieken - 20|-->]]

---
# Notes
