---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_kronieken"
  - "#bible/testament/old"
aliases:
  - "1 Kronieken - 22 - Statenvertaling (1750)"
---
[[1 Kronieken - 21|<--]] 1 Kronieken - 22 [[1 Kronieken - 23|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[1 Kronieken]]

# 1 Kronieken - 22

En David zeide: Hier zal het huis Gods des HEEREN zijn, en hier zal het altaar des brandoffers voor Israël zijn. [^1] En David zeide, dat men vergaderen zou de vreemdelingen, die in het land Israëls waren; en hij bestelde steenhouwers, om uit te houwen stenen, welke men behouwen zou, om het huis Gods te bouwen. [^2] En David bereidde ijzer in menigte, tot nagelen aan de deuren der poorten, en tot de samenvoegingen; ook koper in menigte, zonder gewicht; [^3] En cederenhout zonder getal; want de Sidoniërs en de Tyriërs brachten tot David cederenhout in menigte. [^4] Want David zeide: Mijn zoon Salomo is een jongeling en teder; en het huis, dat men den HEERE bouwen zal, zal men ten hoogste groot maken, tot een Naam en tot heerlijkheid in alle landen; ik zal hem nu voorraad bereiden. Alzo bereidde David voorraad in menigte voor zijn dood. [^5] Toen riep hij zijn zoon Salomo, en gebood hem den HEERE, den God Israëls, een huis te bouwen. [^6] En David zeide tot Salomo: Mijn zoon, wat mij aangaat, het was in mijn hart den Naam des HEEREN, mijns Gods, een huis te bouwen; [^7] Doch het woord des HEEREN geschiedde tot mij, zeggende: Gij hebt bloed in menigte vergoten, want gij hebt grote krijgen gevoerd; gij zult Mijn Naam geen huis bouwen, dewijl gij veel bloeds op de aarde voor Mijn aangezicht vergoten hebt. [^8] Zie, de zoon, die u geboren zal worden, die zal een man der rust zijn, want Ik zal hem rust geven van al zijn vijanden rondom henen; want zijn naam zal Salomo zijn, en Ik zal vrede en stilte over Israël geven in zijn dagen. [^9] Die zal Mijn Naam een huis bouwen, en die zal Mij tot een zoon zijn, en Ik hem tot een Vader; en Ik zal den troon zijns rijks over Israël bevestigen tot in eeuwigheid. [^10] Nu, mijn zoon, de HEERE zal met u zijn, en gij zult voorspoedig zijn, en zult het huis des HEEREN, uws Gods, bouwen, gelijk als Hij van u gesproken heeft. [^11] Alleenlijk de HEERE geve u kloekheid en verstand, en geve u bevel over Israël, en dat om te onderhouden de wet des HEEREN, uws Gods. [^12] Dan zult gij voorspoedig zijn, als gij waarnemen zult te doen de inzettingen en de rechten, die de HEERE aan Mozes geboden heeft over Israël. Wees sterk en heb goeden moed, vrees niet, en wees niet verslagen! [^13] Zie daar, ik heb in mijn verdrukking voor het huis des HEEREN bereid honderd duizend talenten gouds, en duizend maal duizend talenten zilvers; en des kopers en des ijzers is geen gewicht, want het is er in menigte; ik heb ook hout en stenen bereid; doe gij er nog meer bij. [^14] Ook zijn er bij u in menigte, die het werk kunnen doen, houwers, en werkmeesters in steen en hout, en allerlei wijze lieden in allerlei werk. [^15] Des gouds, des zilvers, en des kopers, en des ijzers is geen getal; maak u op, en doe het, en de HEERE zal met u zijn. [^16] Ook gebood David aan alle vorsten van Israël, dat zij zijn zoon Salomo helpen zouden, zeggende: [^17] Is niet de HEERE, uw God, met ulieden, en heeft u rust gegeven rondom henen? Want Hij heeft de inwoners des lands in mijn hand gegeven, en dit land is onderworpen geworden voor het aangezicht des HEEREN, en voor het aangezicht Zijns volks. [^18] Zo begeeft dan nu uw hart en uw ziel, om te zoeken den HEERE, uw God, en maakt u op, en bouwt het heiligdom Gods des HEEREN; dat men de ark des verbonds des HEEREN en de heilige vaten Gods in dit huis brenge, dat den Naam des HEEREN zal gebouwd worden. [^19] 

[[1 Kronieken - 21|<--]] 1 Kronieken - 22 [[1 Kronieken - 23|-->]]

---
# Notes
