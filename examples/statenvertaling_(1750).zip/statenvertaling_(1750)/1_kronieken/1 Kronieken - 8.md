---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_kronieken"
  - "#bible/testament/old"
aliases:
  - "1 Kronieken - 8 - Statenvertaling (1750)"
---
[[1 Kronieken - 7|<--]] 1 Kronieken - 8 [[1 Kronieken - 9|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[1 Kronieken]]

# 1 Kronieken - 8

Benjamin nu gewon Bela, zijn eerstgeborene, Asbel, den tweede, en Ahrah, den derde, [^1] Naho, den vierde, en Rafa, den vijfde. [^2] Bela nu had deze kinderen: Addar, en Gera, en Abihud, [^3] En Abisua, en Naäman, en Ahoah, [^4] En Gera, en Sefufan, en Huram. [^5] Dezen nu zijn de kinderen van Ehud; dezen waren hoofden der vaderen van de inwoners te Geba, en hij voerde hen over naar Manahath; [^6] En Naäman, en Ahia, en Gera; dezen voerde hij weg; en hij gewon Uzza en Ahihud. [^7] En Saharaïm gewon kinderen in het land van Moab (nadat hij dezelve weggezonden had) uit Husim en Baära, zijn vrouwen; [^8] En uit Hodes, zijn huisvrouw, gewon hij Jobab, en Zibja, en Mesa, en Malcham, [^9] En Jeüz, en Sochja, en Mirma; dezen zijn zijne zonen, hoofden der vaderen. [^10] En uit Husim gewon hij Abitub en Elpaäl. [^11] De kinderen van Elpaäl nu waren Eber, en Misam, en Semed; deze heeft Ono gebouwd, en Lod en haar onderhorige plaatsen; [^12] En Beria, en Sema; dezen waren hoofden der vaderen van de inwoners te Ajalon; dezen hebben de inwoners van Gath verdreven. [^13] En Ahjo, Sasak en Jeremoth, [^14] En Zebadja, en Arad, en Eder, [^15] En Michaël, en Jispa, en Joha waren kinderen van Beria. [^16] En Zebadja, en Mesullam, en Hizki, en Heber, [^17] En Jismerai, en Jizlia en Jobab, de kinderen van Elpaäl. [^18] En Jakim, en Zichri, en Zabdi, [^19] En Eljoënai, en Zillethai, en Eliël, [^20] En Adaja, en Beraja, en Simrath waren kinderen van Simeï. [^21] En Jispan, en Eber, en Eliël, [^22] En Abdon, en Zichri, en Hanan, [^23] En Hananja, en Elam, en Antothija, [^24] En Jifdeja, en Pnuël waren zonen van Sasak. [^25] En Samserai, en Seharja, en Athalja, [^26] En Jaäresja, en Elia, en Zichri waren zonen van Jeroham. [^27] Dezen waren de hoofden der vaderen, hoofden naar hun geslachten; dezen woonden te Jeruzalem. [^28] En te Gibeon woonde de vader van Gibeon; en de naam zijner huisvrouw was Maächa. [^29] En zijn eerstgeboren zoon was Abdon, daarna Zur, en Kis, en Baäl, en Nadab, [^30] En Gedor, en Ahio, en Zecher. [^31] En Mikloth gewon Simea; en dezen woonden ook tegenover hun broederen te Jeruzalem, met hun broederen. [^32] Ner nu gewon Kis, en Kis gewon Saul, en Saul gewon Jonathan, en Malchi-sua, Abinadab, en Esbaäl. [^33] En Jonathans zoon was Merib-Baäl, en Merib-Baäl gewon Micha. [^34] De kinderen van Micha nu waren Pithon, en Melech, en Thaärea, en Achaz. [^35] En Achaz gewon Jehoadda, en Jehoadda gewon Alemeth, en Azmaveth, en Zimri; Zimri nu gewon Moza; [^36] En Moza gewon Bina; zijn zoon was Rafa; zijn zoon was Elasa; zijn zoon was Azel. [^37] Azel nu had zes zonen, en dit zijn hun namen; Azrikam, Bochru, en Ismaël, en Searja, en Obadja, en Hanan. Al dezen waren zonen van Azel. [^38] En de zonen van Esek, zijn broeder, waren Ulam, zijn eerstgeborene, Jeüs, de tweede, en Elifelet, de derde. [^39] En de zonen van Ulam waren mannen, kloeke helden, den boog spannende, en zij hadden vele zonen, en zoons zonen, honderd en vijftig. Al dezen waren van de kinderen van Benjamin. [^40] 

[[1 Kronieken - 7|<--]] 1 Kronieken - 8 [[1 Kronieken - 9|-->]]

---
# Notes
