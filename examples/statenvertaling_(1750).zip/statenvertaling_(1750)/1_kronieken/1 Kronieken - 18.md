---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_kronieken"
  - "#bible/testament/old"
aliases:
  - "1 Kronieken - 18 - Statenvertaling (1750)"
---
[[1 Kronieken - 17|<--]] 1 Kronieken - 18 [[1 Kronieken - 19|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[1 Kronieken]]

# 1 Kronieken - 18

Het geschiedde nu na dezen, dat David de Filistijnen sloeg, en hen ten onder bracht; en hij nam Gath, en haar onderhorige plaatsen, uit der Filistijnen hand. [^1] Hij sloeg ook de Moabieten, alzo dat de Moabieten Davids knechten werden, brengende geschenken. [^2] David sloeg ook Hadar-ezer, den koning van Zoba, naar Hamath toe, toen hij heentoog, om zijn hand te stellen aan de rivier Frath. [^3] En David nam hem duizend wagens af, en zeven duizend ruiters, en twintig duizend man te voet; en David ontzenuwde al de wagenpaarden; doch hij behield honderd wagens daarvan over. [^4] En de Syriërs van Damaskus kwamen, om Hadar-ezer, den koning van Zoba, te helpen; maar David sloeg van de Syriërs twee en twintig duizend man. [^5] En David legde bezettingen in Syrië van Damaskus, alzo dat de Syriërs Davids knechten werden, geschenken brengende. En de HEERE behoedde David overal, waar hij heenging. [^6] En David nam de gouden schilden, die bij Hadar-ezers knechten waren, en hij bracht ze te Jeruzalem. [^7] Ook nam David zeer veel kopers uit Tibchath, en uit Chun, steden van Hadar-ezer; daarvan heeft Salomo de koperen zee, en de pilaren, en de koperen vaten gemaakt. [^8] Toen Thoü, de koning van Hamath, hoorde, dat David de ganse heirkracht van Hadar-ezer, den koning van Zoba, geslagen had; [^9] Zo zond hij zijn zoon Hadoram tot den koning David, om hem naar zijn welstand te vragen, en om hem te zegenen, vanwege dat hij met Hadar-ezer gestreden, en hem verslagen had (want Hadar-ezer voerde oorlog tegen Thoü), en alle gouden, en zilveren, en koperen vaten; [^10] Deze heiligde de koning David ook den HEERE, met het zilver en het goud, hetwelk hij medegebracht had van al de heidenen: van de Edomieten, en van de Moabieten, en van de kinderen Ammons, en van de Filistijnen, en van de Amalekieten. [^11] Ook sloeg Abisaï, de zoon van Zeruja, de Edomieten in het Zoutdal, achttien duizend. [^12] En hij legde bezettingen in Edom, zodat al de Edomieten Davids knechten werden; en de HEERE behoedde David overal, waar hij heenging. [^13] Alzo regeerde David over gans Israël, en hij deed zijn gansen volke recht en gerechtigheid. [^14] Joab nu, de zoon van Zeruja, was over het heir; en Josafat, de zoon van Ahilud, was kanselier; [^15] En Zadok, de zoon van Ahitub, en Abimelech, de zoon van Abjathar, waren priesters, en Sausa schrijver; [^16] En Benaja, de zoon van Jojada, was over de Krethi en Plethi; maar de zonen van David waren de eersten aan de hand des konings. [^17] 

[[1 Kronieken - 17|<--]] 1 Kronieken - 18 [[1 Kronieken - 19|-->]]

---
# Notes
