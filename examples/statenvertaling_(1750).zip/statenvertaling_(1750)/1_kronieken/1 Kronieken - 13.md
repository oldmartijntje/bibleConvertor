---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_kronieken"
  - "#bible/testament/old"
aliases:
  - "1 Kronieken - 13 - Statenvertaling (1750)"
---
[[1 Kronieken - 12|<--]] 1 Kronieken - 13 [[1 Kronieken - 14|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[1 Kronieken]]

# 1 Kronieken - 13

En David hield raad met de oversten der duizenden en der honderden, en met alle vorsten. [^1] En David zeide tot de ganse gemeente van Israël: Indien het ulieden goeddunkt, en van den HEERE, onzen God, te zijn, laat ons ons uitbreiden, laat ons zenden aan onze overige broeders, in alle landen van Israël, en de priesters en Levieten, die met hen zijn in de steden, met haar voorsteden, opdat zij tot ons vergaderd worden. [^2] En laat ons de ark onzes Gods tot ons wederhalen, want wij hebben ze in de dagen van Saul niet gezocht. [^3] Toen zeide de ganse gemeente, dat men alzo doen zou; want die zaak was recht in de ogen des gansen volks. [^4] David dan vergaderde gans Israël van het Egyptische Sichor af, tot daar men komt te Hamath, om de ark Gods te brengen van Kirjath-Jearim. [^5] Toen toog David op met het ganse Israël naar Baäla, dat is, Kirjath-Jearim, hetwelk in Juda is, dat hij van daar ophaalde de ark Gods, des HEEREN, Die tussen de cherubim woont, waar de Naam wordt aangeroepen. [^6] En zij voerden de ark Gods op een nieuwen wagen uit het huis van Abinadab. Uza nu en Ahio leidden den wagen. [^7] En David en gans Israël speelden voor het aangezicht Gods met alle macht, zo met liederen, als met harpen, en met luiten, en met trommelen, en met cimbalen, en met trompetten. [^8] Toen zij aan den dorsvloer van Chidon gekomen waren, zo strekte Uza zijn hand uit, om de ark te houden, want de runderen struikelden. [^9] Toen ontstak de toorn des HEEREN over Uza, en Hij sloeg hem, omdat hij zijn hand had uitgestrekt aan de ark; en hij stierf aldaar voor het aangezicht Gods. [^10] En David ontstak, dat de HEERE een scheur gescheurd had aan Uza; daarom noemde hij diezelve plaats Perez-Uza, tot op dezen dag. [^11] En David vreesde den HEERE te dien dage, zeggende: Hoe zal ik de ark Gods tot mij brengen? [^12] Daarom liet David de ark niet tot zich brengen in de stad Davids, maar deed ze afwijken in het huis van Obed-Edom, den Gethiet. [^13] Alzo bleef de ark Gods bij het huisgezin van Obed-Edom, in zijn huis, drie maanden; en de HEERE zegende het huis van Obed-Edom, en alles, wat hij had. [^14] 

[[1 Kronieken - 12|<--]] 1 Kronieken - 13 [[1 Kronieken - 14|-->]]

---
# Notes
