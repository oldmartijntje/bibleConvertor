---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_koningen"
  - "#bible/testament/old"
aliases:
  - "2 Koningen - 12 - Statenvertaling (1750)"
---
[[2 Koningen - 11|<--]] 2 Koningen - 12 [[2 Koningen - 13|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[2 Koningen]]

# 2 Koningen - 12

In het zevende jaar van Jehu werd Joas koning, en regeerde veertig jaren te Jeruzalem; en de naam zijner moeder was Zibja van Berseba. [^1] En Joas deed dat recht was in de ogen des HEEREN, al zijn dagen, in dewelke de priester Jojada hem onderwees. [^2] Alleenlijk werden de hoogten niet weggenomen; het volk offerde en rookte nog op de hoogten. [^3] En Joas zeide tot de priesteren: Al het geld der geheiligde dingen, dat gebracht zal worden in het huis des HEEREN, te weten het geld desgenen, die overgaat tot de getelden, het geld van een ieder der personen naar zijn schatting, en al het geld, dat in ieders hart komt, om dat te brengen in het huis des HEEREN, [^4] Zullen de priesters tot zich nemen, een ieder van zijn bekende; en zij zullen de breuken van het huis verbeteren, naar alles wat er voor breuk bevonden zal worden. [^5] Maar het geschiedde in het drie en twintigste jaar van den koning Joas, dat de priesters de breuken van het huis niet gebeterd hadden. [^6] Toen riep de koning Joas den priester Jojada en de andere priesteren, en zeide tot hen: Waarom betert gijlieden niet de breuken van het huis? Nu dan, neemt geen geld van uw bekenden, dat gij het zoudt geven voor de breuken van het huis. [^7] En de priesters bewilligden van het volk geen geld te nemen, noch de breuken van het huis te verbeteren. [^8] Maar de priester Jojada nam een kist, en boorde een gat in haar deksel, en zette die bij het altaar ter rechterhand, als iemand inkwam in het huis des HEEREN; en de priesters, die den dorpel bewaarden, staken daarin al het geld, dat ten huize des HEEREN gebracht werd. [^9] Het geschiedde nu, als zij zagen, dat veel gelds in de kist was, dat des konings schrijver met den hogepriester opkwam, en zij bonden het samen, en telden het geld, dat in het huis des HEEREN gevonden werd. [^10] En zij gaven het geld wel gewogen in handen der verzorgers van dat werk, die gesteld waren over het huis des HEEREN; en zij besteedden het uit aan de timmerlieden en aan de bouwlieden, die het huis des HEEREN vermaakten; [^11] En aan de metselaren, en aan de steenhouwers, en om hout en gehouwen stenen te kopen, om de breuken van het huis des HEEREN te verbeteren, en voor al wat uitgegeven werd voor het huis, om dat te beteren. [^12] Evenwel werden niet gemaakt voor het huis des HEEREN zilveren schalen, gaffelen, sprengbekkens, trompetten, noch enig gouden vat, of zilveren vat, van het geld, dat ten huize des HEEREN gebracht werd. [^13] Maar zij gaven dat aan degenen, die het werk deden; en zij verbeterden daarmede het huis des HEEREN. [^14] Daartoe eisten zij geen rekening van de mannen, wien zij dat geld in hun handen gaven, om aan degenen, die het werk deden, te geven; want zij handelden trouwelijk. [^15] Het geld van schuldoffer, en het geld van zondofferen werd ten huize des HEEREN niet gebracht; het was voor de priesteren. [^16] Toen trok Hazaël, de koning van Syrië op, en krijgde tegen Gath, en nam haar in; daarna stelde Hazaël zijn aangezicht, om tegen Jeruzalem op te trekken. [^17] Maar Joas, de koning van Juda, nam al de geheiligde dingen, die Josafat, en Joram, en Ahazia, zijn vaderen, de koningen van Juda, geheiligd hadden, en zijn geheiligde dingen, en al het goud, dat gevonden werd in de schatten van het huis des HEEREN, en van het huis des konings, en zond het tot Hazaël, den koning van Syrië; toen trok hij op van Jeruzalem. [^18] Het overige nu der geschiedenissen van Joas, en al wat hij gedaan heeft, is dat niet geschreven in het boek der kronieken der koningen van Juda? [^19] En zijn knechten stonden op, en maakten een verbintenis, en sloegen Joas, in het huis van Millo, dat afgaat naar Silla; [^20] Want Jozacar, de zoon van Simeath, en Jozabad, de zoon van Somer, zijn knechten, sloegen hem, dat hij stierf; en zij begroeven hem met zijn vaderen in de stad Davids; en Amazia, zijn zoon, werd koning in zijn plaats. [^21] 

[[2 Koningen - 11|<--]] 2 Koningen - 12 [[2 Koningen - 13|-->]]

---
# Notes
