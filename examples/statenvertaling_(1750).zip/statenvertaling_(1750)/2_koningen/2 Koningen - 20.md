---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_koningen"
  - "#bible/testament/old"
aliases:
  - "2 Koningen - 20 - Statenvertaling (1750)"
---
[[2 Koningen - 19|<--]] 2 Koningen - 20 [[2 Koningen - 21|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[2 Koningen]]

# 2 Koningen - 20

In die dagen werd Hizkia krank tot stervens toe; en de profeet Jesaja, de zoon van Amoz, kwam tot hem, en zeide tot hem: Zo zegt de HEERE: Geef bevel aan uw huis, want gij zult sterven, en niet leven. [^1] Toen keerde hij zijn aangezicht om naar den wand, en hij bad tot den HEERE, zeggende: [^2] Och, HEERE, gedenk toch, dat ik voor Uw aangezicht in waarheid en met een volkomen hart gewandeld, en wat goed in Uw ogen is, gedaan heb. En Hizkia weende gans zeer. [^3] Het gebeurde nu, als Jesaja uit het middelvoorhof nog niet gegaan was, dat het woord des HEEREN tot hem geschiedde, zeggende: [^4] Keer weder en zeg tot Hizkia, den voorganger Mijns volks: Zo zegt de HEERE, de God van uw vader David: Ik heb uw gebed gehoord, Ik heb uw tranen gezien; zie, Ik zal u gezond maken; aan den derden dag zult gij opgaan in het huis des HEEREN; [^5] En Ik zal vijftien jaren tot uw dagen toedoen, en zal u uit de hand des konings van Assyrië verlossen, mitsgaders deze stad; en Ik zal deze stad beschermen om Mijnentwil, en om Mijns knechts Davids wil. [^6] Daarna zeide Jesaja: Neemt een klomp vijgen; en zij namen ze, en legden ze op de zweer, en hij werd genezen. [^7] Hizkia nu had gezegd tot Jesaja: Welk is het teken, dat de HEERE mij gezond maken zal, en dat ik op den derden dag in des HEEREN huis zal opgaan? [^8] En Jesaja zeide: Dit zal u een teken van den HEERE zijn, dat de HEERE het woord, dat Hij gesproken heeft, doen zal: Zal de schaduw tien graden voorwaarts gaan, of tien graden achterwaarts keren? [^9] Toen zeide Hizkia: Het is der schaduwe licht, tien graden nederwaarts te gaan; neen, maar dat de schaduw tien graden achterwaarts kere. [^10] En Jesaja, de profeet, riep den HEERE aan; en Hij deed de schaduw tien graden achterwaarts keren in de graden, dewelke zij nederwaarts gegaan was, in de graden van Achaz’ zonnewijzer. [^11] Te dier tijd zond Berodach Baladan de zoon van Baladan, de koning van Babel, brieven en een geschenk aan Hizkia; want hij had gehoord, dat Hizkia krank geweest was. [^12] En Hizkia hoorde naar hen, en hij toonde hun zijn ganse schathuis, het zilver, en het goud, en de specerijen, en de beste olie, en zijn wapenhuis, en al wat gevonden werd in zijn schatten; er was geen ding in zijn huis, noch in zijn ganse heerschappij, dat hij hun niet toonde. [^13] Toen kwam de profeet Jesaja tot den koning Hizkia, en zeide tot hem: Wat hebben die mannen gezegd, en van waar zijn zij tot u gekomen? En Hizkia zeide: Zij zijn uit verren lande gekomen, uit Babel. [^14] En hij zeide: Wat hebben zij gezien in uw huis? En Hizkia zeide: Zij hebben alles gezien, wat in mijn huis is; geen ding is er in mijn schatten, dat ik hun niet getoond heb. [^15] Toen zeide Jesaja tot Hizkia: Hoor des HEEREN woord. [^16] Zie, de dagen komen, dat al wat in uw huis is, en wat uw vaderen tot dezen dage toe opgelegd hebben, naar Babel weggevoerd zal worden; er zal niets overgelaten worden, zegt de HEERE. [^17] Daartoe zullen zij van uw zonen, die uit u zullen voortkomen, die gij gewinnen zult, nemen, dat zij hovelingen zijn in het paleis des konings van Babel. [^18] Maar Hizkia zeide tot Jesaja: Het woord des HEEREN, dat gij gesproken hebt, is goed. Ook zeide hij: Zou het niet, naardien vrede en waarheid in mijn dagen wezen zal? [^19] Het overige nu der geschiedenissen van Hizkia, en al zijn macht, en hoe hij den vijver en den watergang gemaakt heeft, en water in de stad gebracht heeft, zijn die niet geschreven in het boek der kronieken der koningen van Juda? [^20] En Hizkia ontsliep met zijn vaderen; en zijn zoon Manasse werd koning in zijn plaats. [^21] 

[[2 Koningen - 19|<--]] 2 Koningen - 20 [[2 Koningen - 21|-->]]

---
# Notes
