---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_koningen"
  - "#bible/testament/old"
aliases:
  - "2 Koningen - 16 - Statenvertaling (1750)"
---
[[2 Koningen - 15|<--]] 2 Koningen - 16 [[2 Koningen - 17|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[2 Koningen]]

# 2 Koningen - 16

In het zeventiende jaar van Pekah, den zoon van Remalia, werd Achaz koning, de zoon van Jotham, den koning van Juda. [^1] Twintig jaren was Achaz oud, toen hij koning werd, en hij regeerde zestien jaren te Jeruzalem; en hij deed niet dat recht was in de ogen des HEEREN zijns Gods, als zijn vader David. [^2] Want hij wandelde in den weg der koningen van Israël; ja, hij deed ook zijn zoon door het vuur gaan, naar de gruwelen der heidenen, die de HEERE voor de kinderen Israëls verdreven had. [^3] Hij offerde ook en rookte op de hoogten en op de heuvelen, ook onder alle groen geboomte. [^4] Toen toog Rezin, de koning van Syrië, op, met Pekah, den zoon van Remalia, den koning van Israël, naar Jeruzalem ten strijde; en zij belegerden Achaz, maar zij vermochten niet met strijden. [^5] Te dierzelfder tijd bracht Rezin, de koning van Syrië, Elath weder aan Syrië, en wierp de Joden uit Elath; en de Syriërs kwamen te Elath, en hebben daar gewoond tot op dezen dag. [^6] Achaz nu zond boden tot Tiglath-Pilezer, den koning van Assyrië, zeggende: Ik ben uw knecht en uw zoon; kom op, en verlos mij uit de hand van den koning van Syrië, en uit de hand van den koning van Israël, die zich tegen mij opmaken. [^7] En Achaz nam het zilver en het goud, dat in het huis des HEEREN, en in de schatten van het huis des konings gevonden werd, en hij zond den koning van Assyrië een geschenk. [^8] Zo hoorde de koning van Assyrië naar hem; want de koning van Assyrië toog op tegen Damaskus, en nam haar in, en voerde hen gevankelijk naar Kir, en hij doodde Rezin. [^9] Toen toog de koning Achaz Tiglath-Pilezer, den koning van Assyrië, tegemoet, naar Damaskus; en gezien hebbende een altaar, dat te Damaskus was, zo zond de koning Achaz aan den priester Uria de gelijkenis van het altaar, en zijn afbeelding, naar zijn ganse maaksel. [^10] En Uria, de priester, bouwde een altaar, naar alles, wat de koning Achaz van Damaskus ontboden had; alzo deed de priester Uria, tegen dat de koning Achaz van Damaskus kwam. [^11] Als nu de koning van Damaskus gekomen was, zag de koning het altaar; en de koning naderde tot het altaar, en offerde daarop. [^12] En hij stak zijn brandoffer aan, en zijn spijsoffer, en goot zijn drankoffer en sprengde het bloed zijner dankofferen op dat altaar. [^13] Maar het koperen altaar, dat voor het aangezicht des HEEREN was, dat bracht hij van het voorste deel van het huis, van tussen zijn altaar, en van tussen het huis des HEEREN, en hij zette het aan de zijde zijns altaars noordwaarts. [^14] En de koning Achaz gebood Uria, den priester, zeggende: Steek op het grote altaar aan het morgenbrandoffer, en het avondspijsoffer, en des konings brandoffer, en zijn spijsoffer, en het brandoffer van al het volk des lands, en hun spijsoffer, en hun drankofferen; en spreng daarop al het bloed des brandoffers, en al het bloed des slachtoffers; maar het koperen altaar zal mij zijn, om te onderzoeken. [^15] En Uria, de priester, deed naar alles, wat de koning Achaz geboden had. [^16] En de koning Achaz sneed de lijsten der stellingen af, en nam die van boven het wasvat weg, en deed de zee af van de koperen runderen, die daaronder waren; en hij zette die op een stenen vloer. [^17] Daartoe het deksel des sabbats, dat zij in het huis gebouwd hadden, en den buitensten ingang des konings nam hij weg van het huis des HEEREN, vanwege den koning van Assyrië. [^18] Het overige nu der geschiedenissen van Achaz, wat hij gedaan heeft, is dat niet geschreven in het boek der kronieken der koningen van Juda? [^19] En Achaz ontsliep met zijn vaderen, en werd begraven bij zijn vaderen, in de stad Davids; en Hizkia, zijn zoon, werd koning in zijn plaats. [^20] 

[[2 Koningen - 15|<--]] 2 Koningen - 16 [[2 Koningen - 17|-->]]

---
# Notes
