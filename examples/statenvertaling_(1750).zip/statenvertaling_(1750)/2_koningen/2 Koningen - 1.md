---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_koningen"
  - "#bible/testament/old"
aliases:
  - "2 Koningen - 1 - Statenvertaling (1750)"
---
2 Koningen - 1 [[2 Koningen - 2|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[2 Koningen]]

# 2 Koningen - 1

En Moab viel van Israël af, na Achabs dood. [^1] En Ahazia viel door een tralie in zijn opperzaal, die te Samaria was, en werd krank. En hij zond boden, en zeide tot hen: Gaat heen, vraagt Baäl-Zebub, den god van Ekron, of ik van deze krankheid genezen zal. [^2] Maar de Engel des HEEREN sprak tot Elia, den Thisbiet: Maak u op, ga op, den boden des konings van Samaria tegemoet, en spreek tot hen: Is het, omdat er geen God in Israël is, dat gijlieden heengaat, om Baäl-Zebub, den god van Ekron, te vragen? [^3] Daarom nu zegt de HEERE alzo: Gij zult niet afkomen van dat bed, waarop gij geklommen zijt, maar gij zult den dood sterven. En Elia ging weg. [^4] Zo kwamen de boden weder tot hem; en hij zeide tot hen: Wat is dit, dat gij wederkomt? [^5] En zij zeiden tot hem: Een man kwam op, ons tegemoet, en zeide tot ons: Gaat heen, keert weder tot den koning die u gezonden heeft, en spreekt tot hem: Zo zegt de HEERE: Is het, omdat er geen God in Israël is, dat gij zendt, om Baäl-Zebub, den god van Ekron, te vragen? Daarom zult gij van dat bed, waarop gij geklommen zijt, niet afkomen, maar gij zult den dood sterven. [^6] En hij sprak tot hen: Hoedanig was de gestalte des mans, die u tegemoet opgekomen is, en deze woorden tot u gesproken heeft? [^7] En zij zeiden tot hem: Hij was een man met een harig kleed, en met een lederen gordel gegord om zijn lenden. Toen zeide hij: Het is Elia, de Thisbiet. [^8] En hij zond tot hem een hoofdman van vijftig met zijn vijftigen. En als hij tot hem opkwam (want ziet, hij zat op de hoogte eens bergs), zo sprak hij tot hem: Gij, man Gods! de koning zegt: Kom af. [^9] Maar Elia antwoordde en sprak tot den hoofdman van vijftigen: Indien ik dan een man Gods ben, zo dale vuur van den hemel, en vertere u en uw vijftigen. Toen daalde vuur van den hemel, en verteerde hem en zijn vijftigen. [^10] En hij zond wederom tot hem een anderen hoofdman van vijftig met zijn vijftigen. Deze antwoordde en sprak tot hem: Gij, man Gods! zo zegt de koning: Kom haastelijk af. [^11] En Elia antwoordde en sprak tot hen: Ben ik een man Gods, zo dale vuur van den hemel, en vertere u en uw vijftigen. Toen daalde het vuur Gods van den hemel en verteerde hem en zijn vijftigen. [^12] En wederom zond hij een hoofdman van de derde vijftigen met zijn vijftigen. Zo ging de derde hoofdman van vijftigen op, en kwam en boog zich op zijn knieën, voor Elia, en smeekte hem, en sprak tot hem: Gij, man Gods, laat toch mijn ziel en de ziel van uw knechten, van deze vijftigen, dierbaar zijn in uw ogen! [^13] Zie, het vuur is van den hemel gedaald, en heeft die twee eerste hoofdmannen van vijftigen met hun vijftigen verteerd; maar nu, laat mijn ziel dierbaar zijn in uw ogen! [^14] Toen sprak de Engel des HEEREN tot Elia: Ga af met hem; vrees niet voor zijn aangezicht. En hij stond op, en ging met hem af tot den koning. [^15] En hij sprak tot hem: Zo zegt de HEERE: Daarom, dat gij boden gezonden hebt, om Baäl-Zebub, den god van Ekron, te vragen (is het, omdat er geen God in Israël is, om Zijn woord te vragen?); daarom, van dat bed, waarop gij geklommen zijt, zult gij niet afkomen, maar gij zult den dood sterven. [^16] Alzo stierf hij, naar het woord des HEEREN, dat Elia gesproken had; en Joram werd koning in zijn plaats, in het tweede jaar van Joram, den zoon van Josafat, den koning van Juda; want hij had geen zoon. [^17] Het overige nu der zaken van Ahazia, die hij gedaan heeft, is dat niet geschreven in het boek der kronieken der koningen van Israël? [^18] 

2 Koningen - 1 [[2 Koningen - 2|-->]]

---
# Notes
