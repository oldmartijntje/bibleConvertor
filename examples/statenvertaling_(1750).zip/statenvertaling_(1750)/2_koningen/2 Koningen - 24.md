---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_koningen"
  - "#bible/testament/old"
aliases:
  - "2 Koningen - 24 - Statenvertaling (1750)"
---
[[2 Koningen - 23|<--]] 2 Koningen - 24 [[2 Koningen - 25|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[2 Koningen]]

# 2 Koningen - 24

In zijn dagen toog Nebukadnezar, de koning van Babel, op, en Jojakim werd zijn knecht drie jaren; daarna keerde hij zich om, en rebelleerde tegen hem. [^1] En de HEERE zond tegen hem de benden der Chaldeën, en de benden der Syriërs, en de benden der Moabieten, en de benden der kinderen Ammons, en zond hen tegen Juda, om dat te verderven, naar het woord des HEEREN, dat Hij gesproken had door den dienst Zijner knechten, de profeten. [^2] Zekerlijk geschiedde dit naar het bevel des HEEREN tegen Juda, dat Hij hen van Zijn aangezicht wegdeed, om de zonden van Manasse, naar alles, wat hij gedaan had; [^3] Als ook om het onschuldig bloed, dat hij vergoten had, zodat hij Jeruzalem met onschuldig bloed vervuld had; daarom wilde de HEERE niet vergeven. [^4] Het overige nu der geschiedenissen van Jojakim, en al wat hij gedaan heeft, is dat niet geschreven in het boek der kronieken der koningen van Juda? [^5] En Jojakim ontsliep met zijn vaderen; en zijn zoon Jojachin werd koning in zijn plaats. [^6] De koning nu van Egypte toog voortaan niet meer uit zijn land; want de koning van Babel had, van de rivier van Egypte af tot aan de rivier Frath, ingenomen al wat van den koning van Egypte was. [^7] Jojachin was achttien jaren oud, toen hij koning werd, en regeerde drie maanden te Jeruzalem; en de naam zijner moeder was Nehusta, een dochter van Elnathan, van Jeruzalem. [^8] En hij deed dat kwaad was in de ogen des HEEREN, naar alles, wat zijn vader gedaan had. [^9] Te dier tijd togen de knechten van Nebukadnezar, den koning van Babel, naar Jeruzalem; en de stad werd belegerd. [^10] Zelfs kwam Nebukadnezar, de koning van Babel, tegen de stad, als zijn knechten die belegerden. [^11] Toen ging Jojachin, de koning van Juda, uit tot den koning van Babel, hij, en zijn moeder, en zijn knechten, en zijn vorsten, en zijn hovelingen; en de koning van Babel nam hem gevangen in het achtste jaar zijner regering. [^12] En hij bracht van daar uit al de schatten van het huis des HEEREN, en de schatten van het huis des konings; en hij hieuw alle gouden vaten af, die Salomo, de koning van Israël, in den tempel des HEEREN gemaakt had, gelijk als de HEERE gesproken had. [^13] En hij voerde gans Jeruzalem weg, mitsgaders al de vorsten, en alle strijdbare helden, tien duizend gevangenen, en alle timmerlieden en smeden; niemand werd overgelaten, dan het arme volk des lands. [^14] Zo voerde hij Jojachin weg naar Babel, mitsgaders des konings moeder, en des konings vrouwen, en zijn hovelingen; daartoe de machtigen des lands bracht hij gevankelijk van Jeruzalem naar Babel; [^15] En alle kloeke mannen tot zeven duizend, en timmerlieden en smeden tot een duizend, en alle helden, die ten oorlog geoefend waren; dezen bracht de koning van Babel gevankelijk naar Babel. [^16] En de koning van Babel maakte Mattanja, deszelfs oom, koning in plaats van hem, en veranderde zijn naam in Zedekia. [^17] Zedekia was een en twintig jaren oud, als hij koning werd, en hij regeerde elf jaren te Jeruzalem; en de naam zijner moeder was Hamutal, een dochter van Jeremia, van Libna. [^18] En hij deed dat kwaad was in de ogen des HEEREN, naar alles, wat Jojakim gedaan had. [^19] Want het geschiedde, om den toorn des HEEREN tegen Jeruzalem en tegen Juda, totdat Hij hen van Zijn aangezicht weggeworpen had. En Zedekia rebelleerde tegen den koning van Babel. [^20] 

[[2 Koningen - 23|<--]] 2 Koningen - 24 [[2 Koningen - 25|-->]]

---
# Notes
