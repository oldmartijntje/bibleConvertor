---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_koningen"
  - "#bible/testament/old"
aliases:
  - "2 Koningen - 22 - Statenvertaling (1750)"
---
[[2 Koningen - 21|<--]] 2 Koningen - 22 [[2 Koningen - 23|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[2 Koningen]]

# 2 Koningen - 22

Josia was acht jaren oud, toen hij koning werd, en regeerde een en dertig jaren te Jeruzalem; en de naam zijner moeder was Jedida, een dochter van Adaja, van Bozkath. [^1] En hij deed dat recht was in de ogen des HEEREN; en hij wandelde in al den weg van zijn vader David, en week niet af ter rechter- noch ter linkerhand. [^2] Het geschiedde nu in het achttiende jaar van den koning Josia, dat de koning den schrijver Safan, den zoon van Azalia, den zoon van Mesullam, zond in het huis des HEEREN, zeggende: [^3] Ga op tot Hilkia, den hogepriester, opdat hij het geld opsomme, dat in het huis des HEEREN gebracht is, hetwelk de wachters des dorpels van het volk verzameld hebben; [^4] En dat zij dat geven in de hand der verzorgers van het werk, die besteld zijn over het huis des HEEREN; opdat zij het geven aan degenen, die het werk doen, dat in het huis des HEEREN is, om de breuken van het huis te beteren; [^5] Aan de timmerlieden en de bouwlieden, en de metselaars, en om hout en gehouwene stenen te kopen, om het huis te beteren. [^6] Doch er werd met hen geen rekening gehouden van het geld, dat in hun hand geleverd was, want zij handelden trouwelijk. [^7] Toen zeide de hogepriester Hilkia tot Safan, den schrijver: Ik heb het wetboek in het huis des HEEREN gevonden; en Hilkia gaf dat boek aan Safan, die las het. [^8] Daarna kwam Safan, de schrijver, tot den koning, en bracht den koning bescheid weder, en hij zeide: Uw knechten hebben het geld, dat in het huis gevonden was, samengebracht, en hebben het gegeven in de hand der verzorgers van het werk, die besteld waren over het huis des HEEREN. [^9] Ook gaf Safan, de schrijver, den koning te kennen, zeggende: De priester Hilkia heeft mij een boek gegeven. En Safan las dat voor het aangezicht des konings. [^10] Het geschiedde nu, als de koning de woorden des wetboeks hoorde, dat hij zijn klederen scheurde. [^11] En de koning gebood Hilkia, den priester, en Ahikam, den zoon van Safan, en Achbor, den zoon van Michaja, en Safan, den schrijver, en Asaja, den knecht des konings, zeggende: [^12] Gaat henen, vraagt den HEERE voor mij, en voor het volk, en voor het ganse Juda, over de woorden dezes boeks, dat gevonden is; want de grimmigheid des HEEREN is groot, dewelke tegen ons aangestoken is, omdat onze vaderen niet gehoord hebben naar de woorden dezes boeks, om te doen naar al wat voor ons geschreven is. [^13] Toen ging de priester Hilkia, en Ahikam, en Achbor, en Safan, en Asaja henen tot de profetes Hulda, de huisvrouw van Sallum, den zoon van Tikva, den zoon van Harhas, den klederbewaarder (zij nu woonde te Jeruzalem, in het tweede deel), en zij spraken tot haar. [^14] En zij zeide tot hen: Zo zegt de HEERE, de God Israëls: Zegt tot den man, die u tot Mij gezonden heeft: [^15] Zo zegt de HEERE: Zie, Ik zal kwaad over deze plaats brengen, en over haar inwoners, namelijk al de woorden des boeks, dat de koning van Juda gelezen heeft. [^16] Daarom dat zij Mij verlaten, en anderen goden gerookt hebben, opdat zij Mij tot toorn verwekten met al het werk hunner handen, zo zal Mijn grimmigheid aangestoken worden, tegen deze plaats, en niet uitgeblust worden. [^17] Maar tot den koning van Juda, die u gezonden heeft, om den HEERE te vragen, alzo zult gij tot hem zeggen: Zo zegt de HEERE, de God Israëls: Aangaande de woorden, die gij gehoord hebt; [^18] Omdat uw hart week geworden is, en gij u voor het aangezicht des HEEREN vernederd hebt, als gij hoordet, wat Ik gesproken heb tegen deze plaats en derzelver inwoners, dat zij tot een verwoesting en vloek zullen worden, en dat gij uw klederen gescheurd en voor Mijn aangezicht geweend hebt; zo heb Ik u ook verhoord, spreekt de HEERE. [^19] Daarom zie, Ik zal u verzamelen tot uw vaderen, en gij zult met vrede in uw graf verzameld worden, en uw ogen zullen al het kwaad niet zien, dat Ik over deze plaats brengen zal. En zij brachten den koning het antwoord weder. [^20] 

[[2 Koningen - 21|<--]] 2 Koningen - 22 [[2 Koningen - 23|-->]]

---
# Notes
