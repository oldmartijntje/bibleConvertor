---
aliases:
  - Statenvertaling (1750)
tags:
  - "#bible/type/index"
---
# Bible - Statenvertaling (1750)

This bible translation has been downloaded from [https://bible.com](https://bible.com).

The bible has 66 books. These books have been rewritten many times. 

## Book list:

### Old Testament

- [[Genesis]]: 50 chapters.
- [[Exodus]]: 40 chapters.
- [[Leviticus]]: 27 chapters.
- [[Numeri]]: 36 chapters.
- [[Deuteronomium]]: 34 chapters.
- [[Jozua]]: 24 chapters.
- [[Rechters]]: 21 chapters.
- [[Ruth]]: 4 chapters.
- [[1 Samuel]]: 31 chapters.
- [[2 Samuel]]: 24 chapters.
- [[1 Koningen]]: 22 chapters.
- [[2 Koningen]]: 25 chapters.
- [[1 Kronieken]]: 29 chapters.
- [[2 Kronieken]]: 36 chapters.
- [[Ezra]]: 10 chapters.
- [[Nehemia]]: 13 chapters.
- [[Esther]]: 10 chapters.
- [[Job]]: 42 chapters.
- [[Psalmen]]: 150 chapters.
- [[Spreuken]]: 31 chapters.
- [[Prediker]]: 12 chapters.
- [[Hooglied]]: 8 chapters.
- [[Jesaja]]: 66 chapters.
- [[Jeremia]]: 52 chapters.
- [[Klaagliederen]]: 5 chapters.
- [[Ezechiel]]: 48 chapters.
- [[Daniel]]: 12 chapters.
- [[Hosea]]: 14 chapters.
- [[Joel]]: 3 chapters.
- [[Amos]]: 9 chapters.
- [[Obadja]]: 1 chapters.
- [[Jona]]: 4 chapters.
- [[Micha]]: 7 chapters.
- [[Nahum]]: 3 chapters.
- [[Habakuk]]: 3 chapters.
- [[Sefanja]]: 3 chapters.
- [[Haggai]]: 2 chapters.
- [[Zacharia]]: 14 chapters.
- [[Maleachi]]: 4 chapters.

### New Testament

- [[Matteus]]: 28 chapters.
- [[Markus]]: 16 chapters.
- [[Lukas]]: 24 chapters.
- [[Johannes]]: 21 chapters.
- [[Handelingen]]: 28 chapters.
- [[Romeinen]]: 16 chapters.
- [[1 Korinthiers]]: 16 chapters.
- [[2 Korinthiers]]: 13 chapters.
- [[Galaten]]: 6 chapters.
- [[Efeziers]]: 6 chapters.
- [[Filippenzen]]: 4 chapters.
- [[Kolossenzen]]: 4 chapters.
- [[1 Thessalonicenzen]]: 5 chapters.
- [[2 Thessalonicenzen]]: 3 chapters.
- [[1 Timoteus]]: 6 chapters.
- [[2 Timoteus]]: 4 chapters.
- [[Titus]]: 3 chapters.
- [[Filemon]]: 1 chapters.
- [[Hebreeen]]: 13 chapters.
- [[Jakobus]]: 5 chapters.
- [[1 Petrus]]: 5 chapters.
- [[2 Petrus]]: 3 chapters.
- [[1 Johannes]]: 5 chapters.
- [[2 Johannes]]: 1 chapters.
- [[3 Johannes]]: 1 chapters.
- [[Judas]]: 1 chapters.
- [[Openbaring]]: 22 chapters.
