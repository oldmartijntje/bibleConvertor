---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/ezra"
  - "#bible/testament/old"
aliases:
  - "Ezra - 3 - Statenvertaling (1750)"
---
[[Ezra - 2|<--]] Ezra - 3 [[Ezra - 4|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Ezra]]

# Ezra - 3

Toen nu de zevende maand aankwam, en de kinderen Israëls in de steden waren, verzamelde zich het volk, als een enig man, te Jeruzalem. [^1] En Jesua, de zoon van Jozadak, maakte zich op, en zijn broederen, de priesters en Zerubbabel, de zoon van Sealthiël, en zijn broederen, en zij bouwden het altaar des Gods van Israël, om daarop brandofferen te offeren, gelijk geschreven is in de wet van Mozes, den man Gods. [^2] En zij vestigden het altaar op zijn stelling, maar met verschrikking, die over hen was, vanwege de volken der landen; en zij offerden daarop brandofferen den HEERE, brandofferen des morgens en des avonds. [^3] En zij hielden het feest der loofhutten, gelijk geschreven is; en zij offerden brandofferen dag bij dag in getal, naar het recht, van elk dagelijks op zijn dag. [^4] Daarna ook het gedurig brandoffer, en van de nieuwe maanden, en van alle gezette hoogtijden des HEEREN, die geheiligd waren; ook van een ieder, die een vrijwillige offerande den HEERE vrijwilliglijk offerde. [^5] Van den eersten dag af der zevende maand begonnen zij den HEERE brandofferen te offeren; doch de grond van den tempel des HEEREN was niet gelegd. [^6] Zo gaven zij geld aan de houwers en werkmeesters, ook spijs en drank, en olie aan de Sidoniërs en aan de Tyriërs, om cederenhout van den Libanon te brengen aan de zee naar Jafo, naar de vergunning van Kores, koning van Perzië, aan hen. [^7] In het tweede jaar nu hunner aankomst ten huize Gods te Jeruzalem, in de tweede maand, begonnen Zerubbabel, de zoon van Sealthiël, en Jesua, de zoon van Jozadak, en de overige hunner broederen, de priesters en de Levieten, en allen, die uit de gevangenis te Jeruzalem gekomen waren; en zij stelden de Levieten, van twintig jaren oud en daarboven, om opzicht te nemen over het werk van des HEEREN huis. [^8] Toen stond Jesua, zijn zonen en zijn broederen, en Kadmiël met zijn zonen, kinderen van Juda, als één man, om opzicht te hebben over degenen, die het werk deden aan het huis Gods, met de zonen van Henadad, hun zonen en hun broederen, de Levieten. [^9] Als nu de bouwlieden den grond van des HEEREN tempel legden, zo stelden zij de priesteren, aangekleed zijnde, met trompetten, en de Levieten, Asafs zonen, met cimbalen, om den HEERE te loven, naar de instelling van David, den koning van Israël. [^10] En zij zongen bij beurten, met den HEERE te loven en te danken, dat Hij goedig is, dat Zijn weldadigheid tot in eeuwigheid is over Israël. En al het volk juichte met groot gejuich, als men den HEERE loofde over de grondlegging van het huis des HEEREN. [^11] Maar velen van de priesteren, en de Levieten, en hoofden der vaderen, die oud waren, die het eerste huis gezien hadden, dit huis in zijn grondlegging voor hun ogen zijnde, weenden met luider stem; maar velen verhieven de stem met gejuich en met vreugde. [^12] Zodat het volk niet onderkende de stem van het gejuich der vreugde, van de stem des geweens van het volk; want het volk juichte met groot gejuich, dat de stem tot van verre gehoord werd. [^13] 

[[Ezra - 2|<--]] Ezra - 3 [[Ezra - 4|-->]]

---
# Notes
