---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/ezra"
  - "#bible/testament/old"
aliases:
  - "Ezra - 1 - Statenvertaling (1750)"
---
Ezra - 1 [[Ezra - 2|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Ezra]]

# Ezra - 1

In het eerste jaar nu van Kores, koning van Perzië, opdat volbracht wierd het woord des HEEREN, uit den mond van Jeremia, verwekte de HEERE den geest van Kores, koning van Perzië, dat hij een stem liet doorgaan door zijn ganse koninkrijk, zelfs ook in geschrift, zeggende: [^1] Zo zegt Kores, koning van Perzië: De HEERE, de God des hemels, heeft mij alle koninkrijken der aarde gegeven; en Hij heeft mij bevolen Hem een huis te bouwen te Jeruzalem, hetwelk in Juda is. [^2] Wie is onder ulieden van al Zijn volk? Zijn God zij met hem, en hij trekke op naar Jeruzalem, dat in Juda is, en hij bouwe het huis des HEEREN, des Gods van Israël; Hij is de God, Die te Jeruzalem woont. [^3] En al wie achterblijven zou in enige plaatsen, waar hij als vreemdeling verkeert, dien zullen de lieden zijner plaats bevorderlijk zijn met zilver, en met goud, en met have, en met beesten; benevens een vrijwillige gave, voor het huis Gods, Die te Jeruzalem woont. [^4] Toen maakten zich op de hoofden der vaderen van Juda en Benjamin, en de priesteren en de Levieten, benevens een iegelijk, wiens geest God verwekte, dat zij optrokken om te bouwen het huis des HEEREN, die te Jeruzalem woont. [^5] Allen nu, die rondom hen waren, sterkten hunlieder handen met zilveren vaten, met goud, met have, en met beesten, en met kostelijkheden; behalve alles, wat vrijwillig gegeven werd. [^6] Ook bracht de koning Kores uit, de vaten van het huis des HEEREN, die Nebukadnezar uit Jeruzalem had uitgevoerd, en had gesteld in het huis zijns gods. [^7] En Kores, de koning van Perzië, bracht ze uit door de hand van Mithredath, den schatmeester, die ze aan Sesbazar, den vorst van Juda, toetelde. [^8] En dit is hun getal: dertig gouden bekkens, duizend zilveren bekkens, negen en twintig messen; [^9] Dertig gouden bekers, vierhonderd en tien andere zilveren bekers; andere vaten, duizend. [^10] Alle vaten van goud en van zilver waren vijf duizend en vierhonderd; deze alle voerde Sesbazar op, met degenen, die van de gevangenis opgevoerd werden, van Babel naar Jeruzalem. [^11] 

Ezra - 1 [[Ezra - 2|-->]]

---
# Notes
