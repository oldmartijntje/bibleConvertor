---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/ezra"
  - "#bible/testament/old"
aliases:
  - "Ezra - 9 - Statenvertaling (1750)"
---
[[Ezra - 8|<--]] Ezra - 9 [[Ezra - 10|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Ezra]]

# Ezra - 9

Als nu deze dingen voleind waren, traden de vorsten tot mij toe, zeggende: Het volk Israëls, en de priesters, en de Levieten, zijn niet afgezonderd van de volken dezer landen, naar hun gruwelen, namelijk van de Kanaänieten, de Hethieten, de Ferezieten, de Jebusieten, de Ammonieten, de Moabieten, de Egyptenaren en de Amorieten. [^1] Want zij hebben van hun dochteren genomen voor zichzelven en voor hun zonen, zodat zich vermengd hebben het heilig zaad met de volken dezer landen; ja, de hand der vorsten en overheden is de eerste geweest in deze overtreding. [^2] Als ik nu deze zaak hoorde, scheurde ik mijn kleed en mijn mantel; en ik trok van het haar mijns hoofds en mijns baards uit, en zat verbaasd neder. [^3] Toen verzamelden zich tot mij allen, die voor de woorden van den God Israëls beefden, om de overtreding der weggevoerden; doch ik bleef verbaasd zitten tot aan het avondoffer. [^4] En omtrent het avondoffer stond ik op uit mijn bedruktheid, als ik nu mijn kleed en mijn mantel gescheurd had; en ik boog mij op mijn knieën, en breidde mijn handen uit tot den HEERE, mijn God. [^5] En ik zeide: Mijn God, ik ben beschaamd en schaamrood, om mijn aangezicht tot U op te heffen, mijn God; want onze ongerechtigheden zijn vermenigvuldigd tot boven ons hoofd, en onze schuld is groot geworden tot aan den hemel. [^6] Van de dagen onzer vaderen af zijn wij in grote schuld tot op dezen dag; en wij zijn om onze ongerechtigheden overgegeven, wij, onze koningen en onze priesters, in de hand van de koningen der landen, in zwaard, in gevangenis, en in roof, en in schaamte des aangezichts, gelijk het is te dezen dage. [^7] En nu is er, als een klein ogenblik, een genade geschied van den HEERE, onzen God, om ons een ontkoming over te laten, en ons een nagel te geven in Zijn heilige plaats, om onze ogen te verlichten, o onze God, en om ons een weinig levens te geven in onze dienstbaarheid. [^8] Want wij zijn knechten; doch in onze dienstbaarheid heeft ons onze God niet verlaten; maar Hij heeft weldadigheid tot ons geneigd voor het aangezicht der koningen van Perzië, dat Hij ons een weinig levens gave, om het huis onzes Gods te verhogen, en de woestigheden van hetzelve op te richten, en om ons een tuin te geven in Juda en te Jeruzalem. [^9] En nu, wat zullen wij zeggen, o onze God! na dezen? Want wij hebben Uw geboden verlaten, [^10] Die Gij geboden hadt door den dienst Uwer knechten, de profeten, zeggende: Het land, waar gijlieden inkomt, om dat te erven, is een vuil land, door de vuiligheid van de volken der landen, om hun gruwelen, waarmede zij dat gevuld hebben, van het ene einde tot het andere einde, met hun onreinigheid. [^11] Zo zult gij nu uw dochteren niet geven aan hun zonen, en hun dochteren niet nemen voor uw zonen, en zult hun vrede en hun best niet zoeken, tot in eeuwigheid; opdat gij sterk wordt, en het goede des lands eet, en uw kinderen doet erven tot in eeuwigheid. [^12] En na alles, wat over ons gekomen is, om onze boze werken, en om onze grote schuld, omdat Gij, o onze God! belet hebt, dat wij niet te onder zijn vanwege onze ongerechtigheid, en hebt ons een ontkoming gegeven, als deze is; [^13] Zullen wij nu wederkeren, om Uw geboden te vernietigen, en ons te verzwageren met de volken dezer gruwelen? Zoudt Gij niet tegen ons toornen tot verterens toe, dat er geen overblijfsel noch ontkoming zij? [^14] O HEERE, God van Israël! Gij zijt rechtvaardig; want wij zijn overgelaten ter ontkoming, als het is te dezen dage. Zie, wij zijn voor Uw aangezicht in onze schuld; want er is niemand, die voor Uw aangezicht zou kunnen bestaan, om zulks. [^15] 

[[Ezra - 8|<--]] Ezra - 9 [[Ezra - 10|-->]]

---
# Notes
