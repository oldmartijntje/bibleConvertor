---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/ezra"
  - "#bible/testament/old"
aliases:
  - "Ezra - 5 - Statenvertaling (1750)"
---
[[Ezra - 4|<--]] Ezra - 5 [[Ezra - 6|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Ezra]]

# Ezra - 5

Haggaï nu, de profeet, en Zacharia, de zoon van Iddo, profeten, profeteerden tot de Joden, die in Juda en te Jeruzalem waren; in den naam Gods van Israël profeteerden zij tot hen. [^1] Toen maakten zich op Zerubbabel, de zoon van Sealthiël, en Jesua, de zoon van Jozadak, en begonnen te bouwen het huis Gods, Die te Jeruzalem woont; en met hen de profeten Gods, die hen ondersteunden. [^2] Te dier tijd kwam tot hen Thathnai, de landvoogd aan deze zijde der rivier, en Sthar-Boznai, en hun gezelschap, en zeiden aldus tot hen: Wie heeft ulieden bevel gegeven dit huis te bouwen, en dezen muur te voltrekken? [^3] Toen zeiden wij aldus tot hen, en welke de namen waren der mannen, die dit gebouw bouwden. [^4] Doch het oog huns Gods was over de oudsten der Joden, dat zij hun niet beletten, totdat de zaak aan Darius kwam, en zij alsdan daarover een brief wederbrachten. [^5] Afschrift des briefs, dien Thathnai, de landvoogd aan deze zijde der rivier, met Sthar-Boznai, en zijn gezelschap, de Afarsechaieten, die aan deze zijde der rivier waren, aan den koning Darius zond. [^6] Zij zonden een verhaal aan hem; en daarin was aldus geschreven: Den koning Darius zij alle vrede. [^7] Den koning zij bekend, dat wij getogen zijn naar het landschap Juda, ten huize des groten Gods, hetwelk gebouwd wordt met grote stenen, en het hout wordt gelegd in de wanden; en datzelve werk wordt ras gedaan, en gaat voorspoediglijk door hun handen voort. [^8] Toen hebben wij denzelven oudsten gevraagd, en aldus tot hen gezegd: Wie heeft ulieden bevel gegeven dit huis te bouwen, en dezen muur te voltrekken? [^9] Wijders hebben wij hun ook hun namen afgevraagd, dat wij ze u bekend maakten; dat wij mochten overschrijven de namen der mannen, die hoofden onder hen zijn. [^10] En zij hebben ons dusdanig antwoord wedergegeven, zeggende: Wij zijn knechten van den God des hemels en der aarde, en bouwen het huis, dat vele jaren voor dezen is gebouwd geweest; want een groot koning van Israël had het gebouwd en voltrokken. [^11] Maar nadat onze vaders den God des hemels hadden vertoornd, heeft Hij hen gegeven in de hand van Nebukadnezar, den koning van Babel, den Chaldeër; dewelke dat huis heeft vernield, en het volk naar Babel weggevoerd. [^12] Doch in het eerste jaar van Kores, koning van Babel, heeft de koning Kores bevel gegeven dit huis Gods te bouwen. [^13] Ja, de vaten van Gods huis, welke van goud en zilver waren, die Nebukadnezar uit den tempel, die te Jeruzalem was, had weggenomen en dezelve gebracht in den tempel van Babel, die heeft de koning Kores uitgehaald uit den tempel van Babel, en zij zijn gegeven aan een, wiens naam was Sesbazar, dien hij tot landvoogd had gesteld. [^14] En hij zeide tot hem: Neem deze vaten, ga ze afvoeren in den tempel, die te Jeruzalem is, en laat het huis Gods gebouwd worden op zijn plaats. [^15] Toen kwam dezelve Sesbazar; hij legde de fondamenten van het huis Gods, Die te Jeruzalem woont; en er is van toen af tot nu toe gebouwd, doch niet volbracht. [^16] Zo het dan nu den koning goeddunkt, laat er gezocht worden in het schathuis des konings aldaar, dat te Babel is, of het zij, dat een bevel van den koning Kores gegeven zij, om dit huis Gods te Jeruzalem te bouwen; en dat men des konings believen hiervan tot ons zende. [^17] 

[[Ezra - 4|<--]] Ezra - 5 [[Ezra - 6|-->]]

---
# Notes
