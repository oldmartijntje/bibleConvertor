---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 12 - Statenvertaling (1750)"
---
[[Genesis - 11|<--]] Genesis - 12 [[Genesis - 13|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Genesis]]

# Genesis - 12

De HEERE nu had tot Abram gezegd: Ga gij uit uw land, en uit uw maagschap, en uit uws vaders huis, naar het land, dat Ik u wijzen zal. [^1] En Ik zal u tot een groot volk maken, en u zegenen, en uw naam groot maken; en wees een zegen! [^2] En Ik zal zegenen, die u zegenen, en vervloeken, die u vloekt; en in u zullen alle geslachten des aardrijks gezegend worden. [^3] En Abram toog heen, gelijk de HEERE tot hem gesproken had; en Lot toog met hem; en Abram was vijf en zeventig jaren oud, toen hij uit Haran ging. [^4] En Abram nam Sarai, zijn huisvrouw, en Lot, zijns broeders zoon, en al hun have, die zij verworven hadden, en de zielen, die zij verkregen hadden in Haran; en zij togen uit, om te gaan naar het land Kanaän, en zij kwamen in het land Kanaän. [^5] En Abram is doorgetogen in dat land, tot aan de plaats Sichem, tot aan het eikenbos More; en de Kanaänieten waren toen ter tijd in dat land. [^6] Zo verscheen de HEERE aan Abram, en zeide: Aan uw zaad zal Ik dit land geven. Toen bouwde hij aldaar een altaar den HEERE, Die hem verschenen was. [^7] En hij brak op van daar naar het gebergte, tegen het oosten van Beth-El, en hij sloeg zijn tent op, zijnde Beth-El tegen het westen, en Ai tegen het oosten; en hij bouwde daar den HEERE een altaar, en riep den Naam des HEEREN aan. [^8] Daarna vertrok Abram, gaande en trekkende naar het zuiden. [^9] En er was honger in dat land; zo toog Abram af naar Egypte, om daar als een vreemdeling te verkeren, dewijl de honger zwaar was in dat land. [^10] En het geschiedde, als hij naderde, om in Egypte te komen, dat hij zeide tot Sarai, zijn huisvrouw: Zie toch, ik weet, dat gij een vrouw zijt, schoon van aangezicht. [^11] En het zal geschieden, als u de Egyptenaars zullen zien, zo zullen zij zeggen: Dat is zijn huisvrouw; en zij zullen mij doden, en u in het leven behouden. [^12] Zeg toch: Gij zijt mijn zuster; opdat het mij wel ga om u, en mijn ziel om uwentwil leve. [^13] En het geschiedde, als Abram in Egypte kwam, dat de Egyptenaars deze vrouw zagen, dat zij zeer schoon was. [^14] Ook zagen haar de vorsten van Farao, en prezen haar bij Farao; en die vrouw werd weggenomen naar het huis van Farao. [^15] En hij deed Abram goed, om harentwil; zodat hij had schapen, en runderen, en ezelen, en knechten, en maagden, en ezelinnen, en kemelen. [^16] Maar de HEERE plaagde Farao met grote plagen, ook zijn huis, ter oorzake van Sarai, Abrams huisvrouw. [^17] Toen riep Farao Abram, en zeide: Wat is dit, dat gij mij gedaan hebt? waarom hebt gij mij niet te kennen gegeven, dat zij uw huisvrouw is? [^18] Waarom hebt gij gezegd: Zij is mijn zuster; zodat ik haar mij tot een vrouw zoude genomen hebben? en nu, zie, daar is uw huisvrouw; neem haar en ga henen! [^19] En Farao gebood zijn mannen vanwege hem, en zij geleidden hem, en zijn huisvrouw, en alles wat hij had. [^20] 

[[Genesis - 11|<--]] Genesis - 12 [[Genesis - 13|-->]]

---
# Notes
