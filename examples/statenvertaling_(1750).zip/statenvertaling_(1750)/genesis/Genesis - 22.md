---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 22 - Statenvertaling (1750)"
---
[[Genesis - 21|<--]] Genesis - 22 [[Genesis - 23|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Genesis]]

# Genesis - 22

En het geschiedde na deze dingen, dat God Abraham verzocht; en Hij zeide tot hem: Abraham! En hij zeide: Zie, hier ben ik! [^1] En Hij zeide: Neem nu uw zoon, uw enige, dien gij liefhebt, Izak, en ga heen naar het land Moria, en offer hem aldaar tot een brandoffer, op een van de bergen, dien Ik u zeggen zal. [^2] Toen stond Abraham des morgens vroeg op, en zadelde zijn ezel, en nam twee van zijn jongeren met zich, en Izak zijn zoon; en hij kloofde hout tot het brandoffer, en maakte zich op, en ging naar de plaats, die God hem gezegd had. [^3] Aan den derden dag, toen hief Abraham zijn ogen op, en zag die plaats van verre. [^4] En Abraham zeide tot zijn jongeren: Blijft gij hier met den ezel, en ik en de jongen zullen heengaan tot daar; als wij aangebeden zullen hebben, dan zullen wij tot u wederkeren. [^5] En Abraham nam het hout des brandoffers, en legde het op Izak, zijn zoon; en hij nam het vuur en het mes in zijn hand, en zij beiden gingen samen. [^6] Toen sprak Izak tot Abraham, zijn vader, en zeide: Mijn vader! En hij zeide: Zie, hier ben ik, mijn zoon! En hij zeide: Zie het vuur en het hout; maar waar is het lam tot het brandoffer? [^7] En Abraham zeide: God zal Zichzelven een lam ten brandoffer voorzien, mijn zoon! Zo gingen zij beiden samen. [^8] En zij kwamen ter plaatse, die hem God gezegd had; en Abraham bouwde aldaar een altaar, en hij schikte het hout, en bond zijn zoon Izak, en legde hem op het altaar boven op het hout. [^9] En Abraham strekte zijn hand uit, en nam het mes om zijn zoon te slachten. [^10] Maar de Engel des HEEREN riep tot hem van den hemel, en zeide: Abraham, Abraham! En hij zeide: Zie, hier ben ik! [^11] Toen zeide Hij: Strek uw hand niet uit aan den jongen, en doe hem niets! want nu weet Ik, dat gij God vrezende zijt, en uw zoon, uw enige, van Mij niet hebt onthouden. [^12] Toen hief Abraham zijn ogen op, en zag om, en ziet, achter was een ram in de verwarde struiken vast met zijn hoornen; en Abraham ging, en nam dien ram, en offerde hem ten brandoffer in zijns zoons plaats. [^13] En Abraham noemde den naam van die plaats: De HEERE zal het voorzien! Waarom heden ten dage gezegd wordt: Op den berg des HEEREN zal het voorzien worden! [^14] Toen riep de Engel des HEEREN tot Abraham ten tweeden male van den hemel; [^15] En zeide: Ik zweer bij Mijzelven, spreekt de HEERE; daarom dat gij deze zaak gedaan hebt, en uw zoon, uw enige, niet onthouden hebt; [^16] Voorzeker zal Ik u grotelijks zegenen, en uw zaad zeer vermenigvuldigen, als de sterren des hemels, en als het zand, dat aan den oever der zee is; en uw zaad zal de poort zijner vijanden erfelijk bezitten. [^17] En in uw zaad zullen gezegend worden alle volken der aarde, naardien gij Mijn stem gehoorzaam geweest zijt. [^18] Toen keerde Abraham weder tot zijn jongeren, en zij maakten zich op, en zij gingen samen naar Berseba; en Abraham woonde te Berseba. [^19] En het geschiedde na deze dingen, dat men Abraham boodschapte, zeggende: Zie, Milka heeft ook Nahor, uw broeder, zonen gebaard: [^20] Uz, zijn eerstgeborene, en Buz, zijn broeder, en Kemuël, den vader van Aram, [^21] En Chesed, en Hazo, en Pildas, en Jidlaf, en Bethuël; [^22] (En Bethuël gewon Rebekka) deze acht baarde Milka aan Nahor, den broeder van Abraham. [^23] En zijn bijwijf, welker naam was Reüma, diezelve baarde ook Tebah, en Gaham, en Tahas, en Maächa. [^24] 

[[Genesis - 21|<--]] Genesis - 22 [[Genesis - 23|-->]]

---
# Notes
