---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 10 - Statenvertaling (1750)"
---
[[Genesis - 9|<--]] Genesis - 10 [[Genesis - 11|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Genesis]]

# Genesis - 10

Dit nu zijn de geboorten van Noachs zonen: Sem, Cham, en Jafeth; en hun werden zonen geboren na den vloed. [^1] De zonen van Jafeth zijn: Gomer, en Magog, en Madai, en Javan, en Tubal, en Mesech, en Thiras. [^2] En de zonen van Gomer zijn: Askenaz, en Rifath, en Togarma. [^3] En de zonen van Javan zijn: Elisa, en Tarsis; de Chittieten en Dodanieten. [^4] Van dezen zijn verdeeld de eilanden der volken in hun landschappen, elk naar zijn spraak, naar hun huisgezinnen, onder hun volken. [^5] En de zonen van Cham zijn: Cusch en Mitsraïm, en Put, en Kanaän. [^6] En de zonen van Cusch zijn: Seba en Havila, en Sabta, en Raëma, en Sabtecha. En de zonen van Raëma zijn: Scheba en Dedan. [^7] En Cusch gewon Nimrod; deze begon geweldig te zijn op de aarde. [^8] Hij was een geweldig jager voor het aangezicht des HEEREN; daarom wordt gezegd: Gelijk Nimrod, een geweldig jager voor het aangezicht des HEEREN. [^9] En het beginsel zijns rijks was Babel, en Erech, en Accad, en Calne in het land Sinear. [^10] Uit ditzelve land is Assur uitgegaan, en heeft gebouwd Ninevé, en Rehoboth, Ir, en Kalach. [^11] En Resen, tussen Ninevé en tussen Kalach; deze is die grote stad. [^12] En Mitsraïm gewon de Ludieten, en de Anamieten, en de Lehabieten, en de Naftuchieten, [^13] En de Pathrusieten, en de Casluchieten, van waar de Filistijnen uitgekomen zijn, en de Caftorieten. [^14] En Kanaän gewon Sidon, zijn eerstgeborene, en Heth, [^15] En den Jebusiet, en den Amoriet, en den Girgasiet, [^16] En den Hivviet, en den Arkiet, en den Siniet, [^17] En den Arvadiet, en den Tsemariet, en den Hamathiet; en daarna zijn de huisgezinnen der Kanaänieten verspreid. [^18] En de landpale der Kanaänieten was van Sidon, daar gij gaat naar Gerar tot Gaza toe; daar gij gaat naar Sodom en Gomorra, en Adama, en Zeboïm, tot Lasa toe. [^19] Deze zijn zonen van Cham, naar hun huisgezinnen, naar hun spraken, in hun landschappen, in hun volken. [^20] Voorts zijn Sem zonen geboren; dezelve is ook de vader aller zonen van Heber, broeder van Jafeth, den grootste. [^21] Sems zonen waren Elam, en Assur, en Arfachsad, en Lud, en Aram. [^22] En Arams zonen waren Uz, en Hul, en Gether, en Maz. [^23] En Arfachsad gewon Selah, en Selah gewon Heber. [^24] En Heber werden twee zonen geboren; des enen naam was Peleg; want in zijn dagen is de aarde verdeeld; en zijns broeders naam was Joktan. [^25] En Joktan gewon Almodad, en Selef, en Hatsarmaveth, en Jarach, [^26] En Hadoram, en Usal, en Dikla, [^27] En Obal, en Abimaël, en Scheba, [^28] En Ofir, en Havila, en Jobab; deze allen waren zonen van Joktan. [^29] En hun woning was van Mescha af, daar gij gaat naar Sefar, het gebergte van het oosten. [^30] Deze zijn zonen van Sem, naar hun huisgezinnen, naar hun spraken, in hun landschappen, naar hun volken. [^31] Deze zijn de huisgezinnen der zonen van Noach, naar hun geboorten, in hun volken; en van dezen zijn de volken op de aarde verdeeld na den vloed. [^32] 

[[Genesis - 9|<--]] Genesis - 10 [[Genesis - 11|-->]]

---
# Notes
