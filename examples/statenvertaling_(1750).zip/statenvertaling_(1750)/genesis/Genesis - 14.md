---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 14 - Statenvertaling (1750)"
---
[[Genesis - 13|<--]] Genesis - 14 [[Genesis - 15|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Genesis]]

# Genesis - 14

En het geschiedde in de dagen van Amrafel, den koning van Sinear, van Arioch, den koning van Ellasar, van Kedor-Laomer, den koning van Elam, en van Tideal, den koning der volken; [^1] Dat zij krijg voerden met Bera, koning van Sodom, en met Birsa, koning van Gomorra, Sinab, koning van Adama, en Semeber, koning van Zeboïm, en den koning van Bela, dat is Zoar. [^2] Deze allen voegden zich samen in het dal Siddim, dat is de Zoutzee. [^3] Twaalf jaren hadden zij Kedor-Laomer gediend; maar in het dertiende jaar vielen zij af. [^4] Zo kwam Kedor-Laomer in het veertiende jaar, en de koningen, die met hem waren, en sloegen de Refaïeten in Asteroth-Karnaïm, en de Zuzieten in Ham, en de Emieten in Schave-Kiriathaïm; [^5] En de Horieten op hun gebergte Seïr, tot aan het effen veld van Paran, hetwelk aan de woestijn is. [^6] Daarna keerden zij wederom, en kwamen tot En-Mispat, dat is Kades, en sloegen al het land der Amalekieten, en ook den Amoriet, die te Hazezon-Thamar woonde. [^7] Toen toog de koning van Sodom uit, en de koning van Gomorra, en de koning van Adama, en de koning van Zeboïm, en de koning van Bela, dat is Zoar; en zij stelden tegen hen slagorden in het dal Siddim, [^8] Tegen Kedor-Laomer, den koning van Elam, en Tideal, den koning der volken, en Amrafel, den koning van Sinear, en Arioch, den koning van Ellasar; vier koningen tegen vijf. [^9] Het dal nu van Siddim was vol lijmputten; en de koningen van Sodom en Gomorra vluchtten, en vielen aldaar; en de overgeblevenen vluchtten naar het gebergte. [^10] En zij namen al de have van Sodom en Gomorra, en al hun spijze, en trokken weg. [^11] Ook namen zij Lot, den zoon van Abrams broeder, en zijn have, en trokken weg; want hij woonde in Sodom. [^12] Toen kwam er een, die ontkomen was, en boodschapte het aan Abram, den Hebreër, die woonachtig was aan de eikenbossen van Mamre, den Amoriet, broeder van Eskol, en broeder van Aner, welke Abrams bondgenoten waren. [^13] Als Abram hoorde, dat zijn broeder gevangen was, zo wapende hij zijn onderwezenen, de ingeborenen van zijn huis, driehonderd en achttien, en hij jaagde hen na tot Dan toe. [^14] En hij verdeelde zich tegen hen des nachts, hij en zijn knechten, en sloeg ze; en hij jaagde hen na tot Hoba toe, hetwelk is ter linkerhand van Damaskus. [^15] En hij bracht alle have weder, en ook Lot zijn broeder en deszelfs have bracht hij weder, als ook de vrouwen, en het volk. [^16] En de koning van Sodom toog uit, hem tegemoet (nadat hij wedergekeerd was van het slaan van Kedor-Laomer, en van de koningen, die met hem waren), tot het dal Schave, dat is, het dal des konings. [^17] En Melchizédek, koning van Salem, bracht voort brood en wijn; en hij was een priester des allerhoogsten Gods. [^18] En hij zegende hem, en zeide: Gezegend zij Abram Gode, den Allerhoogste, Die hemel en aarde bezit! [^19] En gezegend zij de allerhoogste God, Die uw vijanden in uw hand geleverd heeft! En hij gaf hem de tiende van alles. [^20] En de koning van Sodom zeide tot Abram: Geef mij de zielen; maar neem de have voor u. [^21] Doch Abram zeide tot den koning van Sodom: Ik heb mijn hand opgeheven tot den HEERE, den allerhoogsten God, Die hemel en aarde bezit; [^22] Zo ik van een draad aan tot een schoenriem toe, ja, zo ik van alles, dat het uwe is, iets neme! opdat gij niet zegt: Ik heb Abram rijk gemaakt! [^23] Het zij buiten mij; alleen wat de jongelingen verteerd hebben, en het deel dezer mannen, die met mij getogen zijn, Aner, Eskol en Mamre, laat die hun deel nemen! [^24] 

[[Genesis - 13|<--]] Genesis - 14 [[Genesis - 15|-->]]

---
# Notes
