---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 48 - Statenvertaling (1750)"
---
[[Genesis - 47|<--]] Genesis - 48 [[Genesis - 49|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Genesis]]

# Genesis - 48

Het geschiedde nu na deze dingen, dat men Jozef zeide: Zie, uw vader is krank! Toen nam hij zijn twee zonen met zich, Manasse en Efraïm! [^1] En men boodschapte Jakob, en men zeide: Zie, uw zoon Jozef komt tot u! Zo versterkte zich Israël, en zat op het bed. [^2] Daarna zeide Jakob tot Jozef: God de Almachtige, is mij verschenen te Luz, in het land Kanaän, en Hij heeft mij gezegend; [^3] En Hij heeft tot mij gezegd: Zie, Ik zal u vruchtbaar maken, en u vermenigvuldigen, en u tot een hoop van volken stellen; en Ik zal aan uw zaad na u dit land tot een eeuwige bezitting geven. [^4] Nu dan, uw twee zonen, die u in Egypteland geboren waren, eer ik in Egypte tot u gekomen ben, zijn mijne; Efraïm en Manasse zullen mijne zijn, als Ruben en Simeon. [^5] Maar uw geslacht, dat gij na hen zult gewinnen, zullen uwe zijn; zij zullen naar hunner broederen naam genoemd worden in hun erfdeel. [^6] Toen ik nu van Paddan kwam, zo is Rachel bij mij gestorven in het land Kanaän, op den weg, als het nog een kleine streek lands was, om tot Efrath te komen; en ik begroef haar aldaar aan den weg van Efrath, welke is Bethlehem. [^7] En Israël zag de zonen van Jozef, en zeide: Wiens zijn deze? [^8] En Jozef zeide tot zijn vader: Zij zijn mijn zonen, die mij God hier gegeven heeft. En hij zeide: Breng hen toch tot mij, dat ik hen zegene! [^9] Doch de ogen van Israël waren zwaar van ouderdom; hij kon niet zien; en hij deed hen naderen tot zich; toen kuste hij hen, en omhelsde hen. [^10] En Israël zeide tot Jozef: Ik had niet gemeend uw aangezicht te zien; maar zie, God heeft mij ook uw zaad doen zien! [^11] Toen deed hen Jozef uitgaan van zijn knieën; en hij boog zich met zijn aangezicht neder ter aarde. [^12] En Jozef nam die beiden, Efraïm met zijn rechterhand, tegenover Israëls linkerhand, en Manasse met zijn linkerhand, tegenover Israëls rechterhand, en hij deed hen naderen tot hem. [^13] Maar Israël strekte zijn rechterhand uit, en legde die op het hoofd van Efraïm, hoewel hij de minste was, en zijn linkerhand op het hoofd van Manasse; hij bestierde zijn handen verstandelijk; want Manasse was de eerstgeborene. [^14] En hij zegende Jozef, en zeide: De God, voor Wiens aangezicht mijn vaders, Abraham en Izak, gewandeld hebben, die God, Die mij gevoed heeft, van dat ik was, tot op dezen dag; [^15] Die Engel, Die mij verlost heeft van alle kwaad, zegene deze jongeren, en dat in hen mijn naam genoemd worde, en de naam mijner vaderen, Abraham en Izak, en dat zij vermenigvuldigen als vissen in menigte, in het midden des lands! [^16] Toen Jozef zag, dat zijn vader zijn rechterhand op het hoofd van Efraïm legde, zo was het kwaad in zijn ogen, en hij ondervatte zijns vaders hand, om die van het hoofd van Efraïm op het hoofd van Manasse af te brengen. [^17] En Jozef zeide tot zijn vader: Niet alzo, mijn vader! want deze is de eerstgeborene; leg uw rechterhand op zijn hoofd. [^18] Maar zijn vader weigerde het, en zeide: Ik weet het, mijn zoon! ik weet het; hij zal ook tot een volk worden, en hij zal ook groot worden; maar nochtans zal zijn kleinste broeder groter worden dan hij, en zijn zaad zal een volle menigte van volkeren worden. [^19] Alzo zegende hij ze te dien dage, zeggende: In u zal Israël zegenen, zeggende: God zette u als Efraïm en als Manasse! En hij zette Efraïm voor Manasse. [^20] Daarna zeide Israël tot Jozef: Zie, ik sterf; maar God zal met ulieden wezen, en Hij zal u wederbrengen in het land uwer vaderen. [^21] En ik heb u een stuk lands gegeven boven uw broederen; hetwelk ik, met mijn zwaard en met mijn boog, uit de hand der Amorieten genomen heb. [^22] 

[[Genesis - 47|<--]] Genesis - 48 [[Genesis - 49|-->]]

---
# Notes
