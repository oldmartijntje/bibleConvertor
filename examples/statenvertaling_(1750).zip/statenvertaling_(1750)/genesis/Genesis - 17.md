---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 17 - Statenvertaling (1750)"
---
[[Genesis - 16|<--]] Genesis - 17 [[Genesis - 18|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Genesis]]

# Genesis - 17

Als nu Abram negen en negentig jaren oud was, zo verscheen de HEERE aan Abram, en zeide tot hem: Ik ben God, de Almachtige! Wandel voor Mijn aangezicht, en zijt oprecht! [^1] En Ik zal Mijn verbond stellen tussen Mij en tussen u, en Ik zal u gans zeer vermenigvuldigen. [^2] Toen viel Abram op zijn aangezicht, en God sprak met hem, zeggende: [^3] Mij aangaande, zie, Mijn verbond is met u; en gij zult tot een vader van menigte der volken worden! [^4] En uw naam zal niet meer genoemd worden Abram; maar uw naam zal wezen Abraham; want Ik heb u gesteld tot een vader van menigte der volken. [^5] En Ik zal u gans zeer vruchtbaar maken, en Ik zal u tot volken stellen, en koningen zullen uit u voortkomen. [^6] En Ik zal Mijn verbond oprichten tussen Mij en tussen u, en tussen uw zaad na u in hun geslachten, tot een eeuwig verbond, om u te zijn tot een God, en uw zaad na u. [^7] En Ik zal u, en uw zaad na u, het land uwer vreemdelingschappen geven, het gehele land Kanaän, tot eeuwige bezitting; en Ik zal hun tot een God zijn. [^8] Voorts zeide God tot Abraham: Gij nu zult Mijn verbond houden, gij, en uw zaad na u, in hun geslachten. [^9] Dit is Mijn verbond, dat gijlieden houden zult tussen Mij, en tussen u, en tussen uw zaad na u: dat al wat mannelijk is, u besneden worde. [^10] En gij zult het vlees uwer voorhuid besnijden; en dat zal tot een teken zijn van het verbond tussen Mij en tussen u. [^11] Een zoontje dan van acht dagen zal u besneden worden, al wat mannelijk is in uw geslachten: de ingeborene van het huis, en de gekochte met geld van allen vreemde, welke niet is van uw zaad; [^12] De ingeborene van uw huis, en de gekochte met uw geld zal zekerlijk besneden worden; en Mijn verbond zal zijn in ulieder vlees, tot een eeuwig verbond. [^13] En wat mannelijk is, de voorhuid hebbende, wiens voorhuids vlees niet zal besneden worden, dezelve ziel zal uit haar volken uitgeroeid worden; hij heeft Mijn verbond gebroken. [^14] Nog zeide God tot Abraham: Gij zult den naam van uw huisvrouw Sarai, niet Sarai noemen; maar haar naam zal zijn Sara. [^15] Want Ik zal haar zegenen, en u ook uit haar een zoon geven; ja, Ik zal haar zegenen, zodat zij tot volken worden zal: koningen der volken zullen uit haar worden! [^16] Toen viel Abraham op zijn aangezicht, en hij lachte; en hij zeide in zijn hart: Zal een, die honderd jaren oud is, een kind geboren worden; en zal Sara, die negentig jaren oud is, baren? [^17] En Abraham zeide tot God: Och, dat Ismaël mocht leven voor Uw aangezicht! [^18] En God zeide: Voorwaar, Sara, uw huisvrouw, zal u een zoon baren, en gij zult zijn naam noemen Izak; en Ik zal Mijn verbond met hem oprichten, tot een eeuwig verbond zijn zade na hem. [^19] En aangaande Ismaël heb Ik u verhoord; zie, Ik heb hem gezegend, en zal hem vruchtbaar maken, en hem gans zeer vermenigvuldigen; twaalf vorsten zal hij gewinnen, en Ik zal hem tot een groot volk stellen; [^20] Maar Mijn verbond zal Ik met Izak oprichten, dien u Sara op dezen gezetten tijd in het andere jaar baren zal. [^21] En Hij eindigde met hem te spreken, en God voer op van Abraham. [^22] Toen nam Abraham zijn zoon Ismaël, en al de ingeborenen van zijn huis, en alle gekochten met zijn geld, al wat mannelijk was onder de lieden van het huis van Abraham, en hij besneed het vlees hunner voorhuid, even ten zelfden dage, gelijk als God met hem gesproken had. [^23] En Abraham was oud negen en negentig jaren, als hem het vlees zijner voorhuid besneden werd. [^24] En Ismaël, zijn zoon, was dertien jaren oud, als hem het vlees zijner voorhuid besneden werd. [^25] Even op dezen zelfden dag werd Abraham besneden, en Ismaël, zijn zoon. [^26] En alle mannen van zijn huis, de ingeborenen des huizes, en de gekochten met geld, van den vreemde af, werden met hem besneden. [^27] 

[[Genesis - 16|<--]] Genesis - 17 [[Genesis - 18|-->]]

---
# Notes
