---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 9 - Statenvertaling (1750)"
---
[[Genesis - 8|<--]] Genesis - 9 [[Genesis - 10|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Genesis]]

# Genesis - 9

En God zegende Noach en zijn zonen, en Hij zeide tot hen: Zijt vruchtbaar en vermenigvuldigt, en vervult de aarde! [^1] En uw vrees, en uw verschrikking zij over al het gedierte der aarde, en over al het gevogelte des hemels; in al wat zich op den aardbodem roert, en in alle vissen der zee; zij zijn in uw hand overgegeven. [^2] Al wat zich roert, dat levend is, zij u tot spijze; Ik heb het u al gegeven, gelijk het groene kruid. [^3] Doch het vlees met zijn ziel, dat is zijn bloed, zult gij niet eten. [^4] En voorwaar, Ik zal uw bloed, het bloed uwer zielen eisen; van de hand van alle gedierte zal Ik het eisen; ook van de hand des mensen, van de hand eens iegelijken zijns broeders zal Ik de ziel des mensen eisen. [^5] Wie des mensen bloed vergiet, zijn bloed zal door den mens vergoten worden; want God heeft den mens naar Zijn beeld gemaakt. [^6] Maar gijlieden, weest vruchtbaar, en vermenigvuldigt; teelt overvloediglijk voort op de aarde, en vermenigvuldigt op dezelve. [^7] Voorts zeide God tot Noach, en tot zijn zonen met hem, zeggende: [^8] Maar Ik, ziet, Ik richt Mijn verbond op met u, en met uw zaad na u; [^9] En met alle levende ziel, die met u is, van het gevogelte, van het vee, en van alle gedierte der aarde met u; van allen, die uit de ark gegaan zijn, tot al het gedierte der aarde toe. [^10] En Ik richt Mijn verbond op met u, dat niet meer alle vlees door de wateren des vloeds zal worden uitgeroeid; en dat er geen vloed meer zal zijn, om de aarde te verderven. [^11] En God zeide: Dit is het teken des verbonds, dat Ik geef tussen Mij en tussen ulieden, en tussen alle levende ziel, die met u is, tot eeuwige geslachten. [^12] Mijn boog heb Ik gegeven in de wolken; die zal zijn tot een teken des verbonds tussen Mij en tussen de aarde. [^13] En het zal geschieden, als Ik wolken over de aarde brenge, dat deze boog zal gezien worden in de wolken; [^14] Dan zal Ik gedenken aan Mijn verbond, hetwelk is tussen Mij en tussen u, en tussen alle levende ziel van alle vlees; en de wateren zullen niet meer wezen tot een vloed, om alle vlees te verderven. [^15] Als deze boog in de wolken zal zijn, zo zal Ik hem aanzien, om te gedenken aan het eeuwig verbond tussen God en tussen alle levende ziel, van alle vlees, dat op de aarde is. [^16] Zo zeide dan God tot Noach: Dit is het teken des verbonds, dat Ik opgericht heb tussen Mij en tussen alle vlees, dat op de aarde is. [^17] En de zonen van Noach, die uit de ark gingen, waren Sem, en Cham, en Jafeth; en Cham is de vader van Kanaän. [^18] Deze drie waren de zonen van Noach; en van dezen is de ganse aarde overspreid. [^19] En Noach begon een akkerman te zijn, en hij plantte een wijngaard. [^20] En hij dronk van dien wijn, en werd dronken; en hij ontblootte zich in het midden zijner tent. [^21] En Cham, Kanaäns vader, zag zijns vaders naaktheid, en hij gaf het zijn beiden broederen daar buiten te kennen. [^22] Toen namen Sem en Jafeth een kleed, en zij leiden het op hun beider schouderen, en gingen achterwaarts, en bedekten de naaktheid huns vaders; en hun aangezichten waren achterwaarts gekeerd, zodat zij de naaktheid huns vaders niet zagen. [^23] En Noach ontwaakte van zijn wijn; en hij merkte wat zijn kleinste zoon hem gedaan had. [^24] En hij zeide: Vervloekt zij Kanaän; een knecht der knechten zij hij zijn broederen! [^25] Voorts zeide hij: Gezegend zij de HEERE, de God van Sem; en Kanaän zij hem een knecht! [^26] God breide Jafeth uit, en hij wone in Sems tenten! en Kanaän zij hem een knecht! [^27] En Noach leefde na den vloed driehonderd en vijftig jaren. [^28] Zo waren al de dagen van Noach negenhonderd en vijftig jaren; en hij stierf. [^29] 

[[Genesis - 8|<--]] Genesis - 9 [[Genesis - 10|-->]]

---
# Notes
