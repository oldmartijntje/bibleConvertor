---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 20 - Statenvertaling (1750)"
---
[[Genesis - 19|<--]] Genesis - 20 [[Genesis - 21|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Genesis]]

# Genesis - 20

En Abraham reisde van daar naar het land van het zuiden, en woonde tussen Kades en tussen Sur; en hij verkeerde als vreemdeling te Gerar. [^1] Als nu Abraham van Sara, zijn huisvrouw, gezegd had: Zij is mijn zuster, zo zond Abimelech, de koning van Gerar, en nam Sara weg. [^2] Maar God kwam tot Abimelech in een droom des nachts, en Hij zeide tot hem: Zie, gij zijt dood om der vrouwe wil, die gij weggenomen hebt; want zij is met een man getrouwd. [^3] Doch Abimelech was tot haar niet genaderd; daarom zeide hij: Heere! zult Gij dan ook een rechtvaardig volk doden? [^4] Heeft hij zelf mij niet gezegd: Zij is mijn zuster? en zij, ook zij heeft gezegd: Hij is mijn broeder. In oprechtheid mijns harten en in reinheid mijner handen, heb ik dit gedaan. [^5] En God zeide tot hem in den droom: Ik heb ook geweten, dat gij dit in oprechtheid uws harten gedaan hebt, en Ik heb u ook belet van tegen Mij te zondigen; daarom heb Ik u niet toegelaten, haar aan te roeren. [^6] Zo geef dan nu dezes mans huisvrouw weder; want hij is een profeet, en hij zal voor u bidden, opdat gij leeft; maar zo gij haar niet wedergeeft, weet, dat gij voorzeker sterven zult, gij, en al wat uwes is! [^7] Toen stond Abimelech des morgens vroeg op, en riep al zijn knechten, en sprak al deze woorden voor hun oren. En die mannen vreesden zeer. [^8] En Abimelech riep Abraham, en zeide tot hem: Wat hebt gij ons gedaan? en wat heb ik tegen u gezondigd, dat gij over mij en over mijn koninkrijk een grote zonde gebracht hebt? gij hebt daden met mij gedaan, die niet zouden gedaan worden. [^9] Voorts zeide Abimelech tot Abraham: Wat hebt gij gezien, dat gij deze zaak gedaan hebt? [^10] En Abraham zeide: Want ik dacht: alleen is de vreze Gods in deze plaats niet, zodat zij mij om mijner huisvrouw wil zullen doden. [^11] En ook is zij waarlijk mijn zuster; zij is mijns vaders dochter, maar niet mijner moeder dochter; en zij is mij ter vrouwe geworden. [^12] En het is geschied, als God mij uit mijns vaders huis deed dwalen, zo sprak ik tot haar: Dit zij uw weldadigheid, die gij bij mij doen zult; aan alle plaatsen waar wij komen zullen, zeg van mij: Hij is mijn broeder! [^13] Toen nam Abimelech schapen en runderen, ook dienstknechten en dienstmaagden, en gaf dezelve aan Abraham; en hij gaf hem Sara zijn huisvrouw weder. [^14] En Abimelech zeide: Zie, mijn land is voor uw aangezicht; woon, waar het goed is in uw ogen. [^15] En tot Sara zeide hij: Zie, ik heb uw broeder duizend zilverlingen gegeven; zie, hij zij u een deksel der ogen, allen, die met u zijn, ja, bij allen, en wees geleerd. [^16] En Abraham bad tot God; en God genas Abimelech, en zijn huisvrouw, en zijn dienstmaagden, zodat zij baarden. [^17] Want de HEERE had al de baarmoeders van het huis van Abimelech ganselijk toegesloten, ter oorzake van Sara, Abrahams huisvrouw. [^18] 

[[Genesis - 19|<--]] Genesis - 20 [[Genesis - 21|-->]]

---
# Notes
