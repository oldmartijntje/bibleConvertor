---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 40 - Statenvertaling (1750)"
---
[[Genesis - 39|<--]] Genesis - 40 [[Genesis - 41|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Genesis]]

# Genesis - 40

En het geschiedde na deze dingen, dat de schenker des konings van Egypte, en de bakker, zondigden tegen hun heer, tegen den koning van Egypte. [^1] Zodat Farao zeer toornig werd op zijn twee hovelingen, op den overste der schenkers, en op den overste der bakkers. [^2] En hij leverde hen in bewaring, ten huize van den overste der trawanten, in het gevangenhuis, ter plaatse, waar Jozef gevangen was. [^3] En de overste der trawanten bestelde Jozef bij hen, dat hij hen diende; en zij waren sommige dagen in bewaring. [^4] Zij droomden nu beiden een droom, elk zijn droom, in een nacht, elk naar de uitlegging zijns drooms, de schenker en de bakker, die des konings van Egypte waren, die gevangen waren in het gevangenhuis. [^5] En Jozef kwam des morgens tot hen, en hij zag hen aan, en ziet, zij waren ontsteld. [^6] Toen vraagde hij de hovelingen van Farao, die bij hem waren in hechtenis van het huis zijns heren, zeggende: Waarom zijn uw aangezichten heden kwalijk gesteld? [^7] En zij zeiden tot hem: Wij hebben een droom gedroomd, en er is niemand, die hem uitlegge. En Jozef zeide tot hen: Zijn de uitleggingen niet van God? Vertelt ze mij toch. [^8] Toen vertelde de overste der schenkers Jozef zijn droom, en zeide tot hem: In mijn droom, zie, zo was een wijnstok voor mijn aangezicht; [^9] En aan den wijnstok waren drie ranken; en hij was als bottende, zijn bloeisel ging op, zijn trossen brachten rijpe druiven voort. [^10] En Farao’s beker was in mijn hand; en ik nam die druiven, en drukte ze uit in Farao’s beker, en ik gaf den beker op Farao’s hand. [^11] Toen zeide Jozef tot hem: Dit is zijn uitlegging: de drie ranken zijn drie dagen. [^12] Binnen nog drie dagen zal Farao uw hoofd verheffen, en zal u in uw staat herstellen; en gij zult Farao’s beker in zijn hand geven, naar de vorige wijze, toen gij zijn schenker waart. [^13] Doch gedenk mijner bij uzelven, wanneer het u wel gaan zal, en doe toch weldadigheid aan mij, en doe van mij melding bij Farao, en maak, dat ik uit dit huis kome. [^14] Want ik ben diefelijk ontstolen uit het land der Hebreën; en ook heb ik hier niets gedaan, dat zij mij in dezen kuil gezet hebben. [^15] Toen de overste der bakkers zag, dat hij een goede uitlegging gedaan had, zo zeide hij tot Jozef: Ik was ook in mijn droom, en zie, drie getraliede korven waren op mijn hoofd. [^16] En in den oppersten korf was van alle spijze van Farao, die bakkerswerk is; en het gevogelte at dezelve uit den korf, van boven mijn hoofd. [^17] Toen antwoordde Jozef, en zeide: Dit is zijn uitlegging: de drie korven zijn drie dagen. [^18] Binnen nog drie dagen zal Farao uw hoofd verheffen van boven u, en hij zal u aan een hout hangen, en het gevogelte zal uw vlees van boven u eten. [^19] En het geschiedde op den derden dag, den dag van Farao’s geboorte, dat hij voor al zijn knechten een maaltijd maakte; en hij verhief het hoofd van den overste der schenkers, en het hoofd van den overste der bakkers, in het midden zijner knechten. [^20] En hij deed den overste der schenkers wederkeren tot zijn schenkambt, zodat hij den beker op Farao’s hand gaf. [^21] Maar den overste der bakkers hing hij op; gelijk Jozef hun uitgelegd had. [^22] Doch de overste der schenkers gedacht aan Jozef niet, maar vergat hem. [^23] 

[[Genesis - 39|<--]] Genesis - 40 [[Genesis - 41|-->]]

---
# Notes
