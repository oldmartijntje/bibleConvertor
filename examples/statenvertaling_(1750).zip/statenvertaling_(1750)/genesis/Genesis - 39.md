---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 39 - Statenvertaling (1750)"
---
[[Genesis - 38|<--]] Genesis - 39 [[Genesis - 40|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Genesis]]

# Genesis - 39

Jozef nu werd naar Egypte afgevoerd; en Potifar, een hoveling van Farao, een overste der trawanten, een Egyptisch man, kocht hem uit de hand der Ismaëlieten, die hem derwaarts afgevoerd hadden. [^1] En de HEERE was met Jozef, zodat hij een voorspoedig man was; en hij was in het huis van zijn heer, den Egyptenaar. [^2] Als nu zijn heer zag, dat de HEERE met hem was, en dat de HEERE al wat hij deed, door zijn hand voorspoedig maakte; [^3] Zo vond Jozef genade in zijn ogen, en diende hem; en hij stelde hem over zijn huis; en al wat hij had, gaf hij in zijn hand. [^4] En het geschiedde van toen af, dat hij hem over zijn huis, en over al wat het zijne was, gesteld had, dat de HEERE des Egyptenaars huis zegende, om Jozefs wil; ja, de zegen des HEEREN was in alles, wat hij had, in het huis en in het veld. [^5] En hij liet alles, wat hij had, in Jozefs hand, zodat hij met hem van geen ding kennis had, behalve van het brood, dat hij at. En Jozef was schoon van gedaante, en schoon van aangezicht. [^6] En het geschiedde na deze dingen, dat de huisvrouw zijns heren haar ogen op Jozef wierp; en zij zeide: lig bij mij! [^7] Maar hij weigerde het, en zeide tot de huisvrouw zijns heren: Zie, mijn heer heeft geen kennis met mij, wat er in het huis is; en al wat hij heeft, dat heeft hij in mijn hand gegeven. [^8] Niemand is groter in dit huis dan ik, en hij heeft voor mij niets onthouden, dan u, daarin dat gij zijn huisvrouw zijt; hoe zoude ik dan dit een zo groot kwaad doen, en zondigen tegen God! [^9] En het geschiedde, als zij Jozef dag op dag aansprak, en hij naar haar niet hoorde, om bij haar te liggen, en bij haar te zijn; [^10] Zo gebeurde het op zulk een dag, dat hij in het huis kwam, om zijn werk te doen; en niemand van de lieden des huizes was daar binnenshuis. [^11] En zij greep hem bij zijn kleed, zeggende: Lig bij mij! En hij liet zijn kleed in haar hand, en vluchtte, en ging uit naar buiten. [^12] En het geschiedde, als zij zag, dat hij zijn kleed in haar hand gelaten had, en naar buiten gevlucht was; [^13] Zo riep zij de lieden van haar huis, en sprak tot hen, zeggende: Ziet, hij heeft ons den Hebreeuwsen man ingebracht, om met ons te spotten; hij is tot mij gekomen, om bij mij te liggen, en ik heb geroepen met luider stem; [^14] En het geschiedde, als hij hoorde, dat ik mijn stem verhief, en riep, zo verliet hij zijn kleed bij mij, en vluchtte, en ging uit naar buiten. [^15] En zij legde zijn kleed bij zich, totdat zijn heer in zijn huis kwam. [^16] Toen sprak zij tot hem naar diezelfde woorden, zeggende: De Hebreeuwse knecht, dien gij ons hebt ingebracht, is tot mij gekomen, om met mij te spotten. [^17] En het is geschied, als ik mijn stem verhief, en riep, dat hij zijn kleed bij mij liet, en vluchtte naar buiten. [^18] En het geschiedde, als zijn heer de woorden zijner huisvrouw hoorde, die zij tot hem sprak, zeggende: Naar deze zelfde woorden heeft mij uw knecht gedaan, zo ontstak zijn toorn. [^19] En Jozefs heer nam hem, en leverde hem in het gevangenhuis, ter plaatse, waar des konings gevangenen gevangen waren; alzo was hij daar in het gevangenhuis. [^20] Doch de HEERE was met Jozef, en wende Zijn goedertierenheid tot hem; en gaf hem genade in de ogen van den overste van het gevangenhuis. [^21] En de overste van het gevangenhuis gaf al de gevangenen, die in het gevangenhuis waren, in Jozefs hand; en al wat zij daar deden, deed hij. [^22] De overste van het gevangenhuis zag gans op geen ding, dat in zijn hand was, overmits dat de HEERE met hem was; en wat hij deed, dat deed de HEERE wel gedijen. [^23] 

[[Genesis - 38|<--]] Genesis - 39 [[Genesis - 40|-->]]

---
# Notes
