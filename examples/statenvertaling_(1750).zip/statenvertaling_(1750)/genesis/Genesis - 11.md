---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 11 - Statenvertaling (1750)"
---
[[Genesis - 10|<--]] Genesis - 11 [[Genesis - 12|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Genesis]]

# Genesis - 11

En de ganse aarde was van enerlei spraak en enerlei woorden. [^1] Maar het geschiedde, als zij tegen het oosten togen, dat zij een laagte vonden in het land Sinear; en zij woonden aldaar. [^2] En zij zeiden een ieder tot zijn naaste: Kom aan, laat ons tichelen strijken, en wel doorbranden! En de tichel was hun voor steen, en het lijm was hun voor leem. [^3] En zij zeiden: Kom aan, laat ons voor ons een stad bouwen, en een toren, welks opperste in den hemel zij, en laat ons een naam voor ons maken, opdat wij niet misschien over de ganse aarde verstrooid worden! [^4] Toen kwam de HEERE neder, om te bezien de stad en den toren, die de kinderen der mensen bouwden. [^5] En de HEERE zeide: Ziet, zij zijn enerlei volk, en hebben allen enerlei spraak; en dit is het, dat zij beginnen te maken; maar nu, zoude hun niet afgesneden worden al wat zij bedacht hebben te maken? [^6] Kom aan, laat Ons nedervaren, en laat Ons hun spraak aldaar verwarren, opdat een iegelijk de spraak zijns naasten niet hore. [^7] Alzo verstrooide hen de HEERE van daar over de ganse aarde; en zij hielden op de stad te bouwen. [^8] Daarom noemde men haar naam Babel; want aldaar verwarde de HEERE de spraak der ganse aarde, en van daar verstrooide hen de HEERE over de ganse aarde. [^9] Deze zijn de geboorten van Sem: Sem was honderd jaren oud, en gewon Arfachsad, twee jaren na den vloed. [^10] En Sem leefde, nadat hij Arfachsad gewonnen had, vijfhonderd jaren; en hij gewon zonen en dochteren. [^11] En Arfachsad leefde vijf en dertig jaren, en hij gewon Selah. [^12] En Arfachsad leefde, nadat hij Selah gewonnen had, vierhonderd en drie jaren; en hij gewon zonen en dochteren. [^13] En Selah leefde dertig jaren, en hij gewon Heber. [^14] En Selah leefde, nadat hij Heber gewonnen had, vierhonderd en drie jaren, en hij gewon zonen en dochteren. [^15] En Heber leefde vier en dertig jaren, en gewon Peleg. [^16] En Heber leefde, nadat hij Peleg gewonnen had, vierhonderd en dertig jaren; en hij gewon zonen en dochteren. [^17] En Peleg leefde dertig jaren, en hij gewon Rehu. [^18] En Peleg leefde, nadat hij Rehu gewonnen had, tweehonderd en negen jaren; en hij gewon zonen en dochteren. [^19] En Rehu leefde twee en dertig jaren, en hij gewon Serug. [^20] En Rehu leefde, nadat hij Serug gewonnen had, tweehonderd en zeven jaren; en hij gewon zonen en dochteren. [^21] En Serug leefde dertig jaren, en gewon Nahor. [^22] En Serug leefde, nadat hij Nahor gewonnen had, tweehonderd jaren; en hij gewon zonen en dochteren. [^23] En Nahor leefde negen en twintig jaren, en gewon Terah. [^24] En Nahor leefde, nadat hij Terah gewonnen had, honderd en negentien jaren; en hij gewon zonen en dochteren. [^25] En Terah leefde zeventig jaren, en gewon Abram, Nahor en Haran. [^26] En deze zijn de geboorten van Terah: Terah gewon Abram, Nahor en Haran; en Haran gewon Lot. [^27] En Haran stierf voor het aangezicht zijns vaders Terah, in het land zijner geboorte, in Ur der Chaldeën. [^28] En Abram en Nahor namen zich vrouwen; de naam van Abrams huisvrouw was Sarai, en de naam van Nahors huisvrouw was Milka, een dochter van Haran, vader van Milka, en vader van Jiska. [^29] En Sarai was onvruchtbaar; zij had geen kind. [^30] En Terah nam Abram, zijn zoon, en Lot, Harans zoon, zijns zoons zoon, en Sarai, zijn schoondochter, de huisvrouw van zijn zoon Abram, en zij togen met hen uit Ur der Chaldeën, om te gaan naar het land Kanaän; en zij kwamen tot Haran, en woonden aldaar. [^31] En de dagen van Terah waren tweehonderd en vijf jaren, en Terah stierf te Haran. [^32] 

[[Genesis - 10|<--]] Genesis - 11 [[Genesis - 12|-->]]

---
# Notes
