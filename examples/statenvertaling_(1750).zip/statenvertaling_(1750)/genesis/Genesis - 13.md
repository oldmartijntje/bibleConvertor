---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 13 - Statenvertaling (1750)"
---
[[Genesis - 12|<--]] Genesis - 13 [[Genesis - 14|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Genesis]]

# Genesis - 13

Alzo toog Abram op uit Egypte naar het zuiden, hij en zijn huisvrouw, en al wat hij had, en Lot met hem. [^1] En Abram was zeer rijk, in vee, in zilver, en in goud. [^2] En hij ging, volgens zijn reizen, van het zuiden tot Beth-El toe, tot aan de plaats, waar zijn tent in het begin geweest was, tussen Beth-El, en tussen Ai; [^3] Tot de plaats des altaars, dat hij in het eerst daar gemaakt had; en Abram heeft aldaar den Naam des HEEREN aangeroepen. [^4] En Lot, die met Abram toog, had ook schapen, en runderen, en tenten. [^5] En dat land droeg hen niet, om samen te wonen; want hun have was vele, zodat zij samen niet konden wonen. [^6] En er was twist tussen de herders van Abrams vee, en tussen de herders van Lots vee. Ook woonden toen de Kanaänieten en Ferezieten in dat land. [^7] En Abram zeide tot Lot: Laat toch geen twisting zijn tussen mij en tussen u, en tussen mijn herders en tussen uw herders; want wij zijn mannen broeders. [^8] Is niet het ganse land voor uw aangezicht? Scheid u toch van mij; zo gij de linkerhand kiest, zo zal ik ter rechterhand gaan; en zo gij de rechterhand, zo zal ik ter linkerhand gaan. [^9] En Lot hief zijn ogen op, en hij zag de ganse vlakte der Jordaan, dat zij die geheel bevochtigde; eer de HEERE Sodom en Gomorra verdorven had, was zij als de hof des HEEREN, als Egypteland, als gij komt te Zoar. [^10] Zo koos Lot voor zich de ganse vlakte der Jordaan, en Lot trok tegen het oosten; en zij werden gescheiden, de een van den ander. [^11] Abram dan woonde in het land Kanaän; en Lot woonde in de steden der vlakte, en sloeg tenten tot aan Sodom toe. [^12] En de mannen van Sodom waren boos, en grote zondaars tegen den HEERE. [^13] En de HEERE zeide tot Abram, nadat Lot van hem gescheiden was: Hef uw ogen op, en zie van de plaats, waar gij zijt noordwaarts en zuidwaarts, en oostwaarts en westwaarts. [^14] Want al dit land, dat gij ziet, zal Ik u geven, en aan uw zaad, tot in eeuwigheid. [^15] En Ik zal uw zaad stellen als het stof der aarde, zodat, indien iemand het stof der aarde zal kunnen tellen, zal ook uw zaad geteld worden. [^16] Maak u op, wandel door dit land, in zijn lengte en in zijn breedte, want Ik zal het u geven. [^17] En Abram sloeg tenten op, en kwam en woonde aan de eikenbossen van Mamre, die bij Hebron zijn; en hij bouwde aldaar den HEERE een altaar. [^18] 

[[Genesis - 12|<--]] Genesis - 13 [[Genesis - 14|-->]]

---
# Notes
