---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 7 - Statenvertaling (1750)"
---
[[Genesis - 6|<--]] Genesis - 7 [[Genesis - 8|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Genesis]]

# Genesis - 7

Daarna zeide de HEERE tot Noach: Ga gij, en uw ganse huis in de ark; want u heb Ik gezien rechtvaardig voor Mijn aangezicht in dit geslacht. [^1] Van alle rein vee zult gij tot u nemen zeven en zeven, het mannetje en zijn wijfje; maar van het vee, dat niet rein is, twee, het mannetje en zijn wijfje. [^2] Ook van het gevogelte des hemels zeven en zeven, het mannetje en het wijfje, om zaad levend te houden op de ganse aarde. [^3] Want over nog zeven dagen zal Ik doen regenen op de aarde veertig dagen, en veertig nachten; en Ik zal van den aardbodem verdelgen al wat bestaat, dat Ik gemaakt heb. [^4] En Noach deed, naar al wat de HEERE hem geboden had. [^5] Noach nu was zeshonderd jaren oud, als de vloed der wateren op de aarde was. [^6] Zo ging Noach, en zijn zonen, en zijn huisvrouw, en de vrouwen zijner zonen met hem in de ark, vanwege de wateren des vloeds. [^7] Van het reine vee, en van het vee, dat niet rein was, en van het gevogelte, en al wat op den aardbodem kruipt, [^8] Kwamen er twee en twee tot Noach in de ark, het mannetje en het wijfje, gelijk als God Noach geboden had. [^9] En het geschiedde na die zeven dagen, dat de wateren des vloeds op de aarde waren. [^10] In het zeshonderdste jaar des levens van Noach, in de tweede maand, op den zeventienden dag der maand, op dezen zelfden dag zijn alle fonteinen des groten afgronds opengebroken, en de sluizen des hemels geopend. [^11] En een plasregen was op de aarde veertig dagen en veertig nachten. [^12] Even op dienzelfden dag ging Noach, en Sem, en Cham, en Jafeth, Noachs zonen, desgelijks Noachs huisvrouw, en de drie vrouwen zijner zonen met hem in de ark; [^13] Zij, en al het gedierte naar zijn aard, en al het vee naar zijn aard, en al het kruipend gedierte, dat op de aarde kruipt, naar zijn aard, en al het gevogelte naar zijn aard, alle vogeltjes van allerlei vleugel. [^14] En van alle vlees, waarin een geest des levens was, kwamen er twee en twee tot Noach in de ark. [^15] En die er kwamen, die kwamen mannetje en wijfje, van alle vlees, gelijk als hem God bevolen had. En de HEERE sloot achter hem toe. [^16] En die vloed was veertig dagen op de aarde, en de wateren vermeerderden, en hieven de ark op, zodat zij oprees boven de aarde. [^17] En de wateren namen de overhand, en vermeerderden zeer op de aarde; en de ark ging op de wateren. [^18] En de wateren namen gans zeer de overhand op de aarde, zodat alle hoge bergen, die onder den gansen hemel zijn, bedekt werden. [^19] Vijftien ellen omhoog namen de wateren de overhand, en de bergen werden bedekt. [^20] En alle vlees, dat zich op de aarde roerde, gaf den geest, van het gevogelte, en van het vee, en van het wild gedierte, en van al het kruipend gedierte, dat op de aarde kroop, en alle mens. [^21] Al wat een adem des geestes des levens in zijn neusgaten had, van alles wat op het droge was, is gestorven. [^22] Alzo werd verdelgd al wat bestond, dat op den aardbodem was, van den mens aan tot het vee, tot het kruipend gedierte, en tot het gevogelte des hemels, en zij werden verdelgd van de aarde; doch Noach alleen bleef over, en wat met hem in de ark was. [^23] En de wateren hadden de overhand boven de aarde, honderd en vijftig dagen. [^24] 

[[Genesis - 6|<--]] Genesis - 7 [[Genesis - 8|-->]]

---
# Notes
