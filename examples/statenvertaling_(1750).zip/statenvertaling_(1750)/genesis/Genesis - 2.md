---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 2 - Statenvertaling (1750)"
---
[[Genesis - 1|<--]] Genesis - 2 [[Genesis - 3|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Genesis]]

# Genesis - 2

Alzo zijn volbracht de hemel en de aarde, en al hun heir. [^1] Als nu God op den zevenden dag volbracht had Zijn werk, dat Hij gemaakt had, heeft Hij gerust op den zevenden dag van al Zijn werk, dat Hij gemaakt had. [^2] En God heeft den zevenden dag gezegend, en dien geheiligd; omdat Hij op denzelven gerust heeft van al Zijn werk, hetwelk God geschapen had, om te volmaken. [^3] Dit zijn de geboorten des hemels en der aarde, als zij geschapen werden; ten dage als de HEERE God de aarde en den hemel maakte. [^4] En allen struik des velds, eer hij in de aarde was, en al het kruid des velds, eer het uitsproot; want de HEERE God had niet doen regenen op de aarde, en er was geen mens geweest, om den aardbodem te bouwen. [^5] Maar een damp was opgegaan uit de aarde, en bevochtigde den gansen aardbodem. [^6] En de HEERE God had den mens geformeerd uit het stof der aarde, en in zijn neusgaten geblazen den adem des levens; alzo werd de mens tot een levende ziel. [^7] Ook had de HEERE God een hof geplant in Eden, tegen het oosten, en Hij stelde aldaar den mens, dien Hij geformeerd had. [^8] En de HEERE God had alle geboomte uit het aardrijk doen spruiten, begeerlijk voor het gezicht, en goed tot spijze; en den boom des levens in het midden van den hof, en den boom der kennis des goeds en des kwaads. [^9] En een rivier was voortgaande uit Eden, om dezen hof te bewateren; en werd van daar verdeeld, en werd tot vier hoofden. [^10] De naam der eerste rivier is Pison; deze is het, die het ganse land van Havila omloopt, waar het goud is. [^11] En het goud van dit land is goed; daar is ook bedólah, en de steen sardónix. [^12] En de naam der tweede rivier is Gihon; deze is het, die het ganse land Cusch omloopt. [^13] En de naam der derde rivier is Hiddékel; deze is gaande naar het oosten van Assur. En de vierde rivier is Frath. [^14] Zo nam de HEERE God den mens, en zette hem in den hof van Eden, om dien te bouwen, en dien te bewaren. [^15] En de HEERE God gebood den mens, zeggende: Van allen boom dezes hofs zult gij vrijelijk eten; [^16] Maar van den boom der kennis des goeds en des kwaads, daarvan zult gij niet eten; want ten dage, als gij daarvan eet, zult gij den dood sterven. [^17] Ook had de HEERE God gesproken: Het is niet goed, dat de mens alleen zij; Ik zal hem een hulpe maken, die als tegen hem over zij. [^18] Want als de HEERE God uit de aarde al het gedierte des velds, en al het gevogelte des hemels gemaakt had, zo bracht Hij die tot Adam, om te zien, hoe hij ze noemen zou; en zo als Adam alle levende ziel noemen zoude, dat zou haar naam zijn. [^19] Zo had Adam genoemd de namen van al het vee, en van het gevogelte des hemels, en van al het gedierte des velds; maar voor den mens vond hij geen hulpe, die als tegen hem over ware. [^20] Toen deed de HEERE God een diepen slaap op Adam vallen, en hij sliep; en Hij nam een van zijn ribben, en sloot derzelver plaats toe met vlees. [^21] En de HEERE God bouwde de ribbe, die Hij van Adam genomen had, tot een vrouw, en Hij bracht haar tot Adam. [^22] Toen zeide Adam: Deze is ditmaal been van mijn benen, en vlees van mijn vlees! Men zal haar Manninne heten, omdat zij uit den man genomen is. [^23] Daarom zal de man zijn vader en zijn moeder verlaten, en zijn vrouw aankleven; en zij zullen tot één vlees zijn. [^24] En zij waren beiden naakt, Adam en zijn vrouw; en zij schaamden zich niet. [^25] 

[[Genesis - 1|<--]] Genesis - 2 [[Genesis - 3|-->]]

---
# Notes
