---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 23 - Statenvertaling (1750)"
---
[[Genesis - 22|<--]] Genesis - 23 [[Genesis - 24|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Genesis]]

# Genesis - 23

En het leven van Sara was honderd zeven en twintig jaren; dit waren de jaren des levens van Sara. [^1] En Sara stierf te Kiriath-Arba, dat is Hebron, in het land Kanaän; en Abraham kwam om Sara te beklagen, en haar te bewenen. [^2] Daarna stond Abraham op van het aangezicht zijner dode, en hij sprak tot de zonen Heths, zeggende: [^3] Ik ben een vreemdeling en inwoner bij u; geeft mij een erfbegrafenis bij u, opdat ik mijn dode van voor mijn aangezicht begrave. [^4] En de zonen Heths antwoordden Abraham, zeggende tot hem: [^5] Hoor ons, mijn heer! gij zijt een vorst Gods in het midden van ons; begraaf uw dode in de keure onzer graven; niemand van ons zal zijn graf voor u weren, dat gij uw dode niet zoudt begraven. [^6] Toen stond Abraham op, en boog zich neder voor het volk des lands, voor de zonen Heths; [^7] En hij sprak met hen, zeggende: Is het met uw wil, dat ik mijn dode begrave van voor mijn aangezicht; zo hoort mij, en spreekt voor mij bij Efron, den zoon van Zohar, [^8] Dat hij mij geve de spelonk van Machpela, die hij heeft, die in het einde van zijn akker is, dat hij dezelve mij om het volle geld geve, tot een erfbegrafenis in het midden van u. [^9] Efron nu zat in het midden van de zonen Heths; en Efron de Hethiet antwoordde Abraham, voor de oren van de zonen Heths, van al degenen, die ter poorte zijner stad ingingen, zeggende: [^10] Neen, mijn heer! hoor mij; den akker geef ik u; ook de spelonk, die daarin is, die geef ik u; voor de ogen van de zonen mijns volks geef ik u die; begraaf uw dode. [^11] Toen boog zich Abraham neder voor het aangezicht van het volk des lands; [^12] En hij sprak tot Efron, voor de oren van het volk des lands, zeggende: Trouwens, zijt gij het? lieve, hoor mij; ik zal het geld des akkers geven; neem het van mij, zo zal ik mijn dode aldaar begraven. [^13] En Efron antwoordde Abraham, zeggende tot hem: [^14] Mijn heer! hoor mij; een land van vierhonderd sikkelen zilvers, wat is dat tussen mij en tussen u? begraaf slechts uw dode. [^15] En Abraham luisterde naar Efron; en Abraham woog Efron het geld, waarvan hij gesproken had voor de oren van de zonen Heths, vierhonderd sikkelen zilvers, onder den koopman gangbaar. [^16] Alzo werd de akker van Efron, die in Machpela was, dat tegenover Mamre lag, de akker en de spelonk, die daarin was, en al het geboomte, dat op den akker stond, dat rondom in zijn ganse landpale was gevestigd, [^17] Aan Abraham tot een bezitting, voor de ogen van de zonen Heths, bij allen, die tot zijn stadspoort ingingen. [^18] En daarna begroef Abraham zijn huisvrouw Sara in de spelonk des akkers van Machpela, tegenover Mamre, hetwelk is Hebron, in het land Kanaän. [^19] Alzo werd die akker, en de spelonk die daarin was, aan Abraham gevestigd tot een erfbegrafenis van de zonen Heths. [^20] 

[[Genesis - 22|<--]] Genesis - 23 [[Genesis - 24|-->]]

---
# Notes
