---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 35 - Statenvertaling (1750)"
---
[[Genesis - 34|<--]] Genesis - 35 [[Genesis - 36|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Genesis]]

# Genesis - 35

Daarna zeide God tot Jakob: Maak u op, trek op naar Beth-El, en woon aldaar; en maak daar een altaar dien God, Die u verscheen, toen gij vluchttet voor het aangezicht van uw broeder Ezau. [^1] Toen zeide Jakob tot zijn huisgezin, en tot allen, die bij hem waren: Doet weg de vreemde goden, die in het midden van u zijn, en reinigt u, en verandert uw klederen; [^2] En laat ons ons opmaken, en optrekken naar Beth-El; en ik zal daar een altaar maken dien God, Die mij antwoordt ten dage mijner benauwdheid, en met mij geweest is op den weg, dien ik gewandeld heb. [^3] Toen gaven zij Jakob al die vreemde goden, die in hun hand waren, en de oorsierselen, die aan hun oren waren, en Jakob verborg ze onder den eikenboom, die bij Sichem is. [^4] En zij reisden heen; en Gods verschrikking was over de steden, die rondom hen waren, zodat zij de zonen van Jakob niet achterna jaagden. [^5] Alzo kwam Jakob te Luz, hetwelk is in het land Kanaän (dat is Beth-El), hij en al het volk, dat bij hem was. [^6] En hij bouwde aldaar een altaar, en noemde die plaats El Beth-El; want God was hem aldaar geopenbaard geweest, als hij voor zijns broeders aangezicht vlood. [^7] En Debora, de voedster van Rebekka, stierf, en zij werd begraven onder aan Beth-El; onder dien eik, welks naam hij noemde Allon-Bachuth. [^8] En God verscheen Jakob wederom, als hij van Paddan-Aram gekomen was; en Hij zegende hem. [^9] En God zeide tot hem: Uw naam is Jakob, uw naam zal voortaan niet Jakob genoemd worden, maar Israël zal uw naam zijn; en Hij noemde zijn naam Israël. [^10] Voorts zeide God tot hem: Ik ben God de Almachtige! wees vruchtbaar, en vermenigvuldig! Een volk, ja, een hoop der volken zal uit u worden, en koningen zullen uit uw lenden voortkomen. [^11] En dit land, dat Ik aan Abraham en Izak gegeven heb, dat zal Ik u geven; en aan uw zaad na u zal Ik dit land geven. [^12] Toen voer God van hem op in die plaats, waar Hij met hem gesproken had. [^13] En Jakob stelde een opgericht teken op in die plaats, waar Hij met hem gesproken had, een stenen opgericht teken; en hij stortte daarop drankoffer, en goot olie daarover. [^14] En Jakob noemde den naam dier plaats, alwaar God met hem gesproken had, Beth-El. [^15] En zij reisden van Beth-El; en er was nog een kleine streek lands om tot Efrath te komen; en Rachel baarde, en zij had het hard in haar baren. [^16] En het geschiedde, als zij het hard had in haar baren, zo zeide de vroedvrouw tot haar: Vrees niet; want dezen zoon zult gij ook hebben! [^17] En het geschiedde, als haar ziel uitging (want zij stierf), dat zij zijn naam noemde Ben-oni; maar zijn vader noemde hem Benjamin. [^18] Alzo stierf Rachel; en zij werd begraven aan den weg naar Efrath, hetwelk is Bethlehem. [^19] En Jakob richtte een gedenkteken op boven haar graf, dit is het gedenkteken van Rachels graf tot op dezen dag. [^20] Toen verreisde Israël, en hij spande zijn tent op gene zijde van Migdal-Eder. [^21] En het geschiedde, als Israël in dat land woonde, dat Ruben heenging, en lag bij Bilha, zijns vaders bijwijf; en Israël hoorde het. En de zonen van Jakob waren twaalf. [^22] De zonen van Lea waren: Ruben, Jakobs eerstgeborene, daarna Simeon, en Levi, en Juda, en Issaschar, en Zebulon. [^23] De zonen van Rachel: Jozef en Benjamin. [^24] En de zonen van Bilha, Rachels dienstmaagd: Dan en Nafthali. [^25] En de zonen van Zilpa, Lea’s dienstmaagd: Gad en Aser. Deze zijn de zonen van Jakob, die hem geboren zijn in Paddan-Aram. [^26] En Jakob kwam tot Izak, zijn vader, in Mamre, te Kirjath-Arba, hetwelk is Hebron, waar Abraham als vreemdeling had verkeerd, en Izak. [^27] En de dagen van Izak waren honderd jaren, en tachtig jaren. [^28] En Izak gaf den geest en stierf, en werd verzameld tot zijn volken, oud en zat van dagen; en zijn zonen Ezau en Jakob begroeven hem. [^29] 

[[Genesis - 34|<--]] Genesis - 35 [[Genesis - 36|-->]]

---
# Notes
