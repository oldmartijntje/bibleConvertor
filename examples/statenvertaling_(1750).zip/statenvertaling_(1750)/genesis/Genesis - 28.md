---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 28 - Statenvertaling (1750)"
---
[[Genesis - 27|<--]] Genesis - 28 [[Genesis - 29|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Genesis]]

# Genesis - 28

En Izak riep Jakob, en zegende hem; en gebood hem, en zeide tot hem: Neem geen vrouw van de dochteren van Kanaän. [^1] Maak u op, ga naar Paddan-Aram, ten huize van Bethuël, den vader uwer moeder, en neem u van daar een vrouw, van de dochteren van Laban, uwer moeders broeder. [^2] En God almachtig zegene u, en make u vruchtbaar, en vermenigvuldige u, dat gij tot een hoop volken wordt. [^3] En Hij geve u den zegen van Abraham; aan u, en uw zaad met u, opdat gij erfelijk bezit het land uwer vreemdelingschappen, hetwelk God aan Abraham gegeven heeft. [^4] Alzo zond Izak Jakob weg, dat hij toog naar Paddan-Aram, tot Laban, den zoon van Bethuël, den Syriër, den broeder van Rebekka, Jakobs en Ezau’s moeder. [^5] Als nu Ezau zag, dat Izak Jakob gezegend, en hem naar Paddan-Aram weggezonden had om zich van daar een vrouw te nemen; en als hij hem zegende, dat hij hem geboden had, zeggende: Neem geen vrouw van de dochteren van Kanaän; [^6] En dat Jakob zijn vader en zijn moeder gehoorzaam geweest was, en naar Paddan-Aram getrokken was; [^7] En dat Ezau zag, dat de dochteren van Kanaän kwaad waren in de ogen van Izak, zijn vader; [^8] Zo ging Ezau tot Ismaël, en nam zich tot een vrouw boven zijn vrouwen, Mahalath, de dochter van Ismaël, den zoon van Abraham, de zuster van Nebajoth. [^9] Jakob dan toog uit van Berseba, en ging naar Haran. [^10] En hij geraakte op een plaats, waar hij vernachtte; want de zon was ondergegaan; en hij nam van de stenen dier plaats, en maakte zijn hoofdpeluw, en legde zich te slapen te dierzelver plaats. [^11] En hij droomde; en ziet, een ladder was gesteld op de aarde, welker opperste aan den hemel raakte; en ziet, de engelen Gods klommen daarbij op en neder. [^12] En ziet, de HEERE stond op dezelve en zeide: Ik ben de HEERE, de God van uw vader Abraham, en de God van Izak; dit land, waarop gij ligt te slapen, zal Ik aan u geven, en aan uw zaad. [^13] En uw zaad zal wezen als het stof der aarde, en gij zult uitbreken in menigte, westwaarts en oostwaarts, en noordwaarts en zuidwaarts; en in u, en in uw zaad zullen alle geslachten des aardbodems gezegend worden. [^14] En zie, Ik ben met u, en Ik zal u behoeden overal, waarheen gij trekken zult, en Ik zal u wederbrengen in dit land; want Ik zal u niet verlaten, totdat Ik zal gedaan hebben, hetgeen Ik tot u gesproken heb. [^15] Toen nu Jakob van zijn slaap ontwaakte, zeide hij: Gewisselijk is de HEERE aan deze plaats, en ik heb het niet geweten! [^16] En hij vreesde, en zeide: Hoe vreselijk is deze plaats! Dit is niet dan een huis Gods, en dit is de poort des hemels! [^17] Toen stond Jakob des morgens vroeg op, en hij nam dien steen, dien hij tot zijn hoofdpeluw gelegd had, en zette hem tot een opgericht teken, en goot daar olie boven op. [^18] En hij noemde den naam dier plaats Beth-El; daar toch de naam dier stad te voren was Luz. [^19] En Jakob beloofde een gelofte, zeggende: Wanneer God met mij geweest zal zijn, en mij behoed zal hebben op dezen weg, dien ik reize, en mij gegeven zal hebben brood om te eten, en klederen om aan te trekken; [^20] En ik ten huize mijns vaders in vrede zal wedergekeerd zijn; zo zal de HEERE mij tot een God zijn! [^21] En deze steen, dien ik tot een opgericht teken gezet heb, zal een huis Gods wezen, en van alles, wat Gij mij geven zult, zal ik U voorzeker de tienden geven! [^22] 

[[Genesis - 27|<--]] Genesis - 28 [[Genesis - 29|-->]]

---
# Notes
