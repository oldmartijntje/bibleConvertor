---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 3 - Statenvertaling (1750)"
---
[[Genesis - 2|<--]] Genesis - 3 [[Genesis - 4|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Genesis]]

# Genesis - 3

De slang nu was listiger dan al het gedierte des velds, hetwelk de HEERE God gemaakt had; en zij zeide tot de vrouw: Is het ook, dat God gezegd heeft: Gijlieden zult niet eten van allen boom dezes hofs? [^1] En de vrouw zeide tot de slang: Van de vrucht der bomen dezes hofs zullen wij eten; [^2] Maar van de vrucht des booms, die in het midden des hofs is, heeft God gezegd: Gij zult van die niet eten, noch die aanroeren, opdat gij niet sterft. [^3] Toen zeide de slang tot de vrouw: Gijlieden zult den dood niet sterven; [^4] Maar God weet, dat, ten dage als gij daarvan eet, zo zullen uw ogen geopend worden, en gij zult als God wezen, kennende het goed en het kwaad. [^5] En de vrouw zag, dat die boom goed was tot spijze, en dat hij een lust was voor de ogen, ja, een boom, die begeerlijk was om verstandig te maken; en zij nam van zijn vrucht en at; en zij gaf ook haar man met haar, en hij at. [^6] Toen werden hun beider ogen geopend, en zij werden gewaar, dat zij naakt waren; en zij hechtten vijgeboombladeren samen, en maakten zich schorten. [^7] En zij hoorden de stem van den HEERE God, wandelende in den hof, aan den wind des daags. Toen verborg zich Adam en zijn vrouw voor het aangezicht van den HEERE God, in het midden van het geboomte des hofs. [^8] En de HEERE God riep Adam, en zeide tot hem: Waar zijt gij? [^9] En hij zeide: Ik hoorde Uw stem in den hof, en ik vreesde; want ik ben naakt; daarom verborg ik mij. [^10] En Hij zeide: Wie heeft u te kennen gegeven, dat gij naakt zijt? Hebt gij van dien boom gegeten, van welken Ik u gebood, dat gij daarvan niet eten zoudt? [^11] Toen zeide Adam: De vrouw, die Gij bij mij gegeven hebt, die heeft mij van dien boom gegeven, en ik heb gegeten. [^12] En de HEERE God zeide tot de vrouw: Wat is dit, dat gij gedaan hebt? En de vrouw zeide: De slang heeft mij bedrogen, en ik heb gegeten. [^13] Toen zeide de HEERE God tot die slang: Dewijl gij dit gedaan hebt, zo zijt gij vervloekt boven al het vee, en boven al het gedierte des velds! Op uw buik zult gij gaan, en stof zult gij eten, al de dagen uws levens. [^14] En Ik zal vijandschap zetten tussen u en tussen deze vrouw, en tussen uw zaad en tussen haar zaad; datzelve zal u den kop vermorzelen, en gij zult het de verzenen vermorzelen. [^15] Tot de vrouw zeide Hij: Ik zal zeer vermenigvuldigen uw smart, namelijk uwer dracht; met smart zult gij kinderen baren; en tot uw man zal uw begeerte zijn, en hij zal over u heerschappij hebben. [^16] En tot Adam zeide Hij: Dewijl gij geluisterd hebt naar de stem uwer vrouw, en van dien boom gegeten, waarvan Ik u gebood, zeggende: Gij zult daarvan niet eten; zo zij het aardrijk om uwentwil vervloekt; en met smart zult gij daarvan eten al de dagen uws levens. [^17] Ook zal het u doornen en distelen voortbrengen, en gij zult het kruid des velds eten. [^18] In het zweet uws aanschijns zult gij brood eten, totdat gij tot de aarde wederkeert, dewijl gij daaruit genomen zijt; want gij zijt stof, en gij zult tot stof wederkeren. [^19] Voorts noemde Adam den naam zijner vrouw Heva, omdat zij een moeder aller levenden is. [^20] En de HEERE God maakte voor Adam en zijn vrouw rokken van vellen, en toog ze hun aan. [^21] Toen zeide de HEERE God: Ziet, de mens is geworden als Onzer één, kennende het goed en het kwaad! Nu dan, dat hij zijn hand niet uitsteke, en neme ook van den boom des levens, en ete, en leve in eeuwigheid. [^22] Zo verzond hem de HEERE God uit den hof van Eden, om den aardbodem te bouwen, waaruit hij genomen was. [^23] En Hij dreef den mens uit; en stelde cherubim tegen het oosten des hofs van Eden, en een vlammig lemmer eens zwaards, dat zich omkeerde, om te bewaren den weg van den boom des levens. [^24] 

[[Genesis - 2|<--]] Genesis - 3 [[Genesis - 4|-->]]

---
# Notes
