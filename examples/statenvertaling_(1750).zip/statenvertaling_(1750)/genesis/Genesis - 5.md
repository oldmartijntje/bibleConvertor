---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 5 - Statenvertaling (1750)"
---
[[Genesis - 4|<--]] Genesis - 5 [[Genesis - 6|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Genesis]]

# Genesis - 5

Dit is het boek van Adams geslacht. Ten dage als God den mens schiep, maakte Hij hem naar de gelijkenis Gods. [^1] Man en vrouw schiep Hij hen, en zegende ze, en noemde hun naam Mens, ten dage als zij geschapen werden. [^2] En Adam leefde honderd en dertig jaren, en gewon een zoon naar zijn gelijkenis, naar zijn evenbeeld, en noemde zijn naam Seth. [^3] En Adams dagen, nadat hij Seth gewonnen had, zijn geweest achthonderd jaren; en hij gewon zonen en dochteren. [^4] Zo waren al de dagen van Adam, die hij leefde, negenhonderd jaren, en dertig jaren; en hij stierf. [^5] En Seth leefde honderd en vijf jaren, en hij gewon Enos. [^6] En Seth leefde, nadat hij Enos gewonnen had, achthonderd en zeven jaren; en hij gewon zonen en dochteren. [^7] Zo waren al de dagen van Seth negenhonderd en twaalf jaren; en hij stierf. [^8] En Enos leefde negentig jaren, en hij gewon Kenan. [^9] En Enos leefde, nadat hij Kenan gewonnen had, achthonderd en vijftien jaren; en hij gewon zonen en dochteren. [^10] Zo waren al de dagen van Enos negenhonderd en vijf jaren; en hij stierf. [^11] En Kenan leefde zeventig jaren, en hij gewon Mahalal-el. [^12] En Kenan leefde, nadat hij Mahalal-el gewonnen had, achthonderd en veertig jaren; en hij gewon zonen en dochteren. [^13] Zo waren al de dagen van Kenan negenhonderd en tien jaren; en hij stierf. [^14] En Mahalal-el leefde vijf en zestig jaren, en hij gewon Jered. [^15] En Mahalal-el leefde, nadat hij Jered gewonnen had, achthonderd en dertig jaren; en hij gewon zonen en dochteren. [^16] Zo waren al de dagen van Mahalal-el achthonderd vijf en negentig jaren; en hij stierf. [^17] En Jered leefde honderd twee en zestig jaren, en hij gewon Henoch. [^18] En Jered leefde, nadat hij Henoch gewonnen had, achthonderd jaren; en hij gewon zonen en dochteren. [^19] Zo waren al de dagen van Jered negenhonderd twee en zestig jaren; en hij stierf. [^20] En Henoch leefde vijf en zestig jaren, en hij gewon Methusalach. [^21] En Henoch wandelde met God, nadat hij Methusalach gewonnen had, driehonderd jaren; en hij gewon zonen en dochteren. [^22] Zo waren al de dagen van Henoch driehonderd vijf en zestig jaren. [^23] Henoch dan wandelde met God; en hij was niet meer; want God nam hem weg. [^24] En Methusalach leefde honderd zeven en tachtig jaren, en hij gewon Lamech. [^25] En Methusalach leefde, nadat hij Lamech gewonnen had, zevenhonderd twee en tachtig jaren; en hij gewon zonen en dochteren. [^26] Zo waren al de dagen van Methusalach negenhonderd negen en zestig jaren; en hij stierf. [^27] En Lamech leefde honderd twee en tachtig jaren, en hij gewon een zoon. [^28] En hij noemde zijn naam Noach, zeggende: Deze zal ons troosten over ons werk, en over de smart onzer handen, vanwege het aardrijk, dat de HEERE vervloekt heeft! [^29] En Lamech leefde, nadat hij Noach gewonnen had, vijfhonderd vijf en negentig jaren; en hij gewon zonen en dochteren. [^30] Zo waren al de dagen van Lamech zevenhonderd zeven en zeventig jaren; en hij stierf. [^31] En Noach was vijfhonderd jaren oud; en Noach gewon Sem, Cham en Jafeth. [^32] 

[[Genesis - 4|<--]] Genesis - 5 [[Genesis - 6|-->]]

---
# Notes
