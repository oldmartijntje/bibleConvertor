---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 16 - Statenvertaling (1750)"
---
[[Genesis - 15|<--]] Genesis - 16 [[Genesis - 17|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Genesis]]

# Genesis - 16

Doch Sarai, Abrams huisvrouw, baarde hem niet; en zij had een Egyptische dienstmaagd, welker naam was Hagar. [^1] Zo zeide Sarai tot Abram: Zie toch, de HEERE heeft mij toegesloten, dat ik niet bare; ga toch in tot mijn dienstmaagd, misschien zal ik uit haar gebouwd worden. En Abram hoorde naar de stem van Sarai. [^2] Zo nam Sarai, Abrams huisvrouw, de Egyptische Hagar, haar dienstmaagd, ten einde van tien jaren, welke Abram in het land Kanaän gewoond had, en zij gaf haar aan Abram, haar man, hem tot een vrouw. [^3] En hij ging in tot Hagar, en zij ontving. Als zij nu zag, dat zij ontvangen had, zo werd haar vrouw veracht in haar ogen. [^4] Toen zeide Sarai tot Abram: Mijn ongelijk is op u; ik heb mijn dienstmaagd in uw schoot gegeven; nu zij ziet, dat zij ontvangen heeft, zo ben ik veracht in haar ogen; de HEERE rechte tussen mij en tussen u! [^5] En Abram zeide tot Sarai: Zie uw dienstmaagd is in uw hand; doe haar, wat goed is in uw ogen. En Sarai vernederde haar, en zij vluchtte van haar aangezicht. [^6] En de Engel des HEEREN vond haar aan een waterfontein in de woestijn, aan de fontein op den weg van Sur. [^7] En Hij zeide: Hagar, gij, dienstmaagd van Sarai! van waar komt gij, en waar zult gij heengaan? En zij zeide: Ik ben vluchtende van het aangezicht mijner vrouw Sarai! [^8] Toen zeide de Engel des HEEREN tot haar: Keer weder tot uw vrouw, en verneder u onder haar handen. [^9] Voorts zeide de Engel des HEEREN tot haar: Ik zal uw zaad grotelijks vermenigvuldigen, zodat het vanwege de menigte niet zal geteld worden. [^10] Ook zeide des HEEREN Engel tot haar: Zie, gij zijt zwanger, en zult een zoon baren, en gij zult zijn naam Ismaël noemen, omdat de HEERE uw verdrukking aangehoord heeft. [^11] En hij zal een woudezel van een mens zijn; zijn hand zal tegen allen zijn, en de hand van allen tegen hem; en hij zal wonen voor het aangezicht van al zijn broederen. [^12] En zij noemde den Naam des HEEREN, Die tot haar sprak: Gij, God des aanziens! want zij zeide: Heb ik ook hier gezien naar Dien, Die mij aanziet? [^13] Daarom noemde men dien put, den put Lachai-Roï; ziet, hij is tussen Kades en tussen Bered. [^14] En Hagar baarde Abram een zoon; en Abram noemde den naam zijns zoons, die Hagar gebaard had, Ismaël. [^15] En Abram was zes en tachtig jaren oud, toen Hagar Ismaël aan Abram baarde. [^16] 

[[Genesis - 15|<--]] Genesis - 16 [[Genesis - 17|-->]]

---
# Notes
