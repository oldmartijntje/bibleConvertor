---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 8 - Statenvertaling (1750)"
---
[[Genesis - 7|<--]] Genesis - 8 [[Genesis - 9|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Genesis]]

# Genesis - 8

En God gedacht aan Noach, en aan al het gedierte, en aan al het vee, dat met hem in de ark was; en God deed een wind over de aarde doorgaan, en de wateren werden stil. [^1] Ook werden de fonteinen des afgronds, en de sluizen des hemels gesloten, en de plasregen van den hemel werd opgehouden. [^2] Daartoe keerden de wateren weder van boven de aarde, heen en weder vloeiende, en de wateren namen af ten einde van honderd en vijftig dagen. [^3] En de ark rustte in de zevende maand, op den zeventienden dag der maand, op de bergen van Ararat. [^4] En de wateren waren gaande, en afnemende tot de tiende maand; in de tiende maand, op den eersten der maand, werden de toppen der bergen gezien. [^5] En het geschiedde, ten einde van veertig dagen, dat Noach het venster der ark, die hij gemaakt had, opendeed. [^6] En hij liet een raaf uit, die dikwijls heen en weder ging, totdat de wateren van boven de aarde verdroogd waren. [^7] Daarna liet hij een duif van zich uit, om te zien, of de wateren gelicht waren van boven den aardbodem. [^8] Maar de duif vond geen rust voor het hol van haar voet; zo keerde zij weder tot hem in de ark; want de wateren waren op de ganse aarde; en hij stak zijn hand uit, en nam haar, en bracht haar tot zich in de ark. [^9] En hij verbeidde nog zeven andere dagen; toen liet hij de duif wederom uit de ark. [^10] En de duif kwam tot hem tegen den avondtijd; en ziet, een afgebroken olijfblad was in haar bek; zo merkte Noach, dat de wateren van boven de aarde gelicht waren. [^11] Toen vertoefde hij nog zeven andere dagen; en hij liet de duif uit; maar zij keerde niet meer weder tot hem. [^12] En het geschiedde in het zeshonderd en eerste jaar, in de eerste maand, op den eersten derzelver maand, dat de wateren droogden van boven de aarde; toen deed Noach het deksel der ark af, en zag toe, en ziet, de aardbodem was gedroogd. [^13] En in de tweede maand, op den zeven en twintigsten dag der maand, was de aarde opgedroogd. [^14] Toen sprak God tot Noach, zeggende: [^15] Ga uit de ark, gij, en uw huisvrouw, en uw zonen, en de vrouwen uwer zonen met u. [^16] Al het gedierte, dat met u is, van alle vlees, aan gevogelte, en aan vee, en aan al het kruipend gedierte, dat op de aarde kruipt, doe met u uitgaan; en dat zij overvloediglijk voorttelen op de aarde, en vruchtbaar zijn, en vermenigvuldigen op de aarde. [^17] Toen ging Noach uit, en zijn zonen, en zijn huisvrouw, en de vrouwen zijner zonen met hem. [^18] Al het gedierte, al het kruipende, en al het gevogelte, al wat zich op de aarde roert, naar hun geslachten, gingen uit de ark. [^19] En Noach bouwde den HEERE een altaar; en hij nam van al het reine vee, en van al het rein gevogelte, en offerde brandofferen op dat altaar. [^20] En de HEERE rook dien liefelijken reuk, en de HEERE zeide in Zijn hart: Ik zal voortaan den aardbodem niet meer vervloeken om des mensen wil; want het gedichtsel van 's mensen hart is boos van zijn jeugd aan; en Ik zal voortaan niet meer al het levende slaan, gelijk als Ik gedaan heb. [^21] Voortaan al de dagen der aarde zullen zaaiing en oogst, en koude en hitte, en zomer en winter, en dag en nacht, niet ophouden. [^22] 

[[Genesis - 7|<--]] Genesis - 8 [[Genesis - 9|-->]]

---
# Notes
