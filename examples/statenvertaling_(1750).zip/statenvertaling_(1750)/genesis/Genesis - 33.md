---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 33 - Statenvertaling (1750)"
---
[[Genesis - 32|<--]] Genesis - 33 [[Genesis - 34|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Genesis]]

# Genesis - 33

En Jakob hief zijn ogen op en zag; en ziet, Ezau kwam, en vierhonderd mannen met hem. Toen verdeelde hij de kinderen onder Lea, en onder Rachel, en onder de twee dienstmaagden. [^1] En hij stelde de dienstmaagden en haar kinderen vooraan; en Lea en haar kinderen meer achterwaarts; maar Rachel en Jozef de achterste. [^2] En hij ging voorbij hun aangezicht heen, en hij boog zich zeven malen ter aarde, totdat hij bij zijn broeder kwam. [^3] Toen liep Ezau hem tegemoet, en nam hem in den arm, en viel hem aan den hals, en kuste hem; en zij weenden. [^4] Daarna hief hij zijn ogen op, en zag die vrouwen en die kinderen, en zeide: Wie zijn deze bij u? En hij zeide: De kinderen, die God aan uw knecht genadiglijk verleend heeft. [^5] Toen traden de dienstmaagden toe, zij en haar kinderen, en zij bogen zich neder. [^6] En Lea trad ook toe, met haar kinderen, en zij bogen zich neder; en daarna trad Jozef toe en Rachel, en zij bogen zich neder. [^7] En hij zeide: Voor wien is u al dit heir, dat ik ontmoet heb? En hij zeide: Om genade te vinden in de ogen mijns heren! [^8] Maar Ezau zeide: Ik heb veel, mijn broeder! het zij het uwe, wat gij hebt! [^9] Toen zeide Jakob: Och neen! indien ik nu genade in uw ogen gevonden heb, zo neem mijn geschenk van mijn hand; daarom, omdat ik uw aangezicht gezien heb, als had ik Gods aangezicht gezien, en gij welgevallen aan mij genomen hebt. [^10] Neem toch mijn zegen, die u toegebracht is, dewijl het God mij genadiglijk verleend heeft, en dewijl ik alles heb; en hij hield bij hem aan, zodat hij het nam. [^11] En hij zeide: Laat ons reizen en voorttrekken; en ik zal voor u trekken. [^12] Maar hij zeide tot hem: Mijn heer weet, dat deze kinderen teder zijn, en dat ik zogende schapen en koeien bij mij heb; indien men dezelve maar één dag afdrijft, zo zal de gehele kudde sterven. [^13] Mijn heer trekke toch voorbij, voor het aangezicht van zijn knecht; en ik zal mij op mijn gemak als leidsman voegen, naar den gang van het werk, hetwelk voor mijn aangezicht is, en naar den gang dezer kinderen, totdat ik bij mijn heer te Seïr kome. [^14] En Ezau zeide: Laat mij toch van dit volk, dat met mij is, u bijstellen. En hij zeide: Waartoe dat? laat mij genade vinden in mijns heren ogen! [^15] Alzo keerde Ezau dien dag wederom zijns weegs naar Seïr toe. [^16] Maar Jakob reisde naar Sukkoth, en bouwde een huis voor zich, en maakte hutten voor zijn vee; daarom noemde hij den naam dier plaats Sukkoth. [^17] En Jakob kwam behouden tot de stad Sichem, welke is in het land Kanaän, als hij kwam van Paddan-Aram; en hij legerde zich in het gezicht der stad. [^18] En hij kocht een deel des velds, waarop hij zijn tent gespannen had, van de hand der zonen van Hemor, den vader van Sichem, voor honderd stukken gelds. [^19] En hij richtte aldaar een altaar op, en noemde het: De God Israëls is God! [^20] 

[[Genesis - 32|<--]] Genesis - 33 [[Genesis - 34|-->]]

---
# Notes
