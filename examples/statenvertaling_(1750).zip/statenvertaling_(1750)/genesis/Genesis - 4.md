---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 4 - Statenvertaling (1750)"
---
[[Genesis - 3|<--]] Genesis - 4 [[Genesis - 5|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Genesis]]

# Genesis - 4

En Adam bekende Heva, zijn huisvrouw, en zij werd zwanger, en baarde Kaïn, en zeide: Ik heb een man van den HEERE verkregen! [^1] En zij voer voort te baren zijn broeder Habel; en Habel werd een schaapherder, en Kaïn werd een landbouwer. [^2] En het geschiedde ten einde van enige dagen, dat Kaïn van de vrucht des lands den HEERE offer bracht. [^3] En Habel bracht ook van de eerstgeborenen zijner schapen, en van hun vet. En de HEERE zag Habel en zijn offer aan; [^4] Maar Kaïn en zijn offer zag Hij niet aan. Toen ontstak Kaïn zeer, en zijn aangezicht verviel. [^5] En de HEERE zeide tot Kaïn: Waarom zijt gij ontstoken, en waarom is uw aangezicht vervallen? [^6] Is er niet, indien gij weldoet, verhoging? en zo gij niet weldoet, de zonde ligt aan de deur. Zijn begeerte is toch tot u, en gij zult over hem heersen. [^7] En Kaïn sprak met zijn broeder Habel; en het geschiedde, als zij in het veld waren, dat Kaïn tegen zijn broeder Habel opstond, en sloeg hem dood. [^8] En de HEERE zeide tot Kaïn: Waar is Habel, uw broeder? En hij zeide: Ik weet het niet; ben ik mijns broeders hoeder? [^9] En Hij zeide: Wat hebt gij gedaan? daar is een stem des bloeds van uw broeder, dat tot Mij roept van den aardbodem. [^10] En nu zijt gij vervloekt van den aardbodem, die zijn mond heeft opengedaan, om uws broeders bloed van uw hand te ontvangen. [^11] Als gij den aardbodem bouwen zult, hij zal u zijn vermogen niet meer geven; gij zult zwervende en dolende zijn op aarde. [^12] En Kaïn zeide tot den HEERE: Mijn misdaad is groter, dan dat zij vergeven worde. [^13] Zie, Gij hebt mij heden verdreven van den aardbodem, en ik zal voor Uw aangezicht verborgen zijn; en ik zal zwervende en dolende zijn op de aarde, en het zal geschieden, dat al wie mij vindt, mij zal doodslaan. [^14] Doch de HEERE zeide tot hem: Daarom, al wie Kaïn doodslaat, zal zevenvoudig gewroken worden! En de HEERE stelde een teken aan Kaïn; opdat hem niet versloeg al wie hem vond. [^15] En Kaïn ging uit van het aangezicht des HEEREN; en hij woonde in het land Nod, ten oosten van Eden. [^16] En Kaïn bekende zijn huisvrouw, en zij werd bevrucht en baarde Henoch; en hij bouwde een stad, en noemde den naam dier stad naar den naam zijns zoons, Henoch. [^17] En aan Henoch werd Hirad geboren; en Hirad gewon Mechujaël; en Mechujaël gewon Methusaël; en Methusaël gewon Lamech. [^18] En Lamech nam zich twee vrouwen; de naam van de eerste was Ada, en de naam van de andere Zilla. [^19] En Ada baarde Jabal; deze is geweest een vader dergenen, die tenten bewoonden, en vee hadden. [^20] En de naam zijns broeders was Jubal; deze was de vader van allen, die harpen en orgelen handelen. [^21] En Zilla baarde ook Tubal-Kaïn, een leermeester van allen werker in koper en ijzer; en de zuster van Tubal-Kaïn was Naëma. [^22] En Lamech zeide tot zijn vrouwen Ada en Zilla: Hoort mijn stem, gij vrouwen van Lamech! neemt ter ore mijn rede! Voorwaar, ik sloeg wel een man dood, om mijn wonde, en een jongeling, om mijn buile! [^23] Want Kaïn zal zevenvoudig gewroken worden, maar Lamech zeventigmaal zevenmaal. [^24] En Adam bekende wederom zijn huisvrouw, en zij baarde een zoon, en zij noemde zijn naam Seth; want God heeft mij, sprak zij, een ander zaad gezet voor Habel; want Kaïn heeft hem doodgeslagen. [^25] En denzelven Seth werd ook een zoon geboren, en hij noemde zijn naam Enos. Toen begon men den Naam des HEEREN aan te roepen. [^26] 

[[Genesis - 3|<--]] Genesis - 4 [[Genesis - 5|-->]]

---
# Notes
