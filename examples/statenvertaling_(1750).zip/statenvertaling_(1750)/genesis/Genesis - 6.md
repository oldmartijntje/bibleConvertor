---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 6 - Statenvertaling (1750)"
---
[[Genesis - 5|<--]] Genesis - 6 [[Genesis - 7|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Genesis]]

# Genesis - 6

En het geschiedde, als de mensen op den aardbodem begonnen te vermenigvuldigen, en hun dochters geboren werden, [^1] Dat Gods zonen de dochteren der mensen aanzagen, dat zij schoon waren, en zij namen zich vrouwen uit allen, die zij verkozen hadden. [^2] Toen zeide de HEERE: Mijn Geest zal niet in eeuwigheid twisten met den mens, dewijl hij ook vlees is; doch zijn dagen zullen zijn honderd en twintig jaren. [^3] In die dagen waren er reuzen op de aarde, en ook daarna, als Gods zonen tot de dochteren der mensen ingegaan waren, en zich kinderen gewonnen hadden; deze zijn de geweldigen, die van ouds geweest zijn, mannen van name. [^4] En de HEERE zag, dat de boosheid des mensen menigvuldig was op de aarde, en al het gedichtsel der gedachten zijns harten te allen dage alleenlijk boos was. [^5] Toen berouwde het den HEERE, dat Hij den mens op de aarde gemaakt had, en het smartte Hem aan Zijn hart. [^6] En de HEERE zeide: Ik zal den mens, dien Ik geschapen heb, verdelgen van den aardbodem, van den mens tot het vee, tot het kruipend gedierte, en tot het gevogelte des hemels toe; want het berouwt Mij, dat Ik hen gemaakt heb. [^7] Maar Noach vond genade in de ogen des HEEREN. [^8] Dit zijn de geboorten van Noach. Noach was een rechtvaardig, oprecht man in zijn geslachten. Noach wandelde met God. [^9] En Noach gewon drie zonen: Sem, Cham en Jafeth. [^10] Maar de aarde was verdorven voor Gods aangezicht; en de aarde was vervuld met wrevel. [^11] Toen zag God de aarde, en ziet, zij was verdorven; want al het vlees had zijn weg verdorven op de aarde. [^12] Daarom zeide God tot Noach: Het einde van alle vlees is voor Mijn aangezicht gekomen; want de aarde is door hen vervuld met wrevel; en zie, Ik zal hen met de aarde verderven. [^13] Maak u een ark van goferhout; met kameren zult gij deze ark maken; en gij zult die bepekken van binnen en van buiten met pek. [^14] En aldus is het, dat gij haar maken zult: driehonderd ellen zij de lengte der ark, vijftig ellen haar breedte, en dertig ellen haar hoogte. [^15] Gij zult een venster aan de ark maken, en zult haar volmaken tot een elle van boven; en de deur der ark zult gij in haar zijde zetten; gij zult ze met onderste, tweede en derde verdiepingen maken. [^16] Want Ik, zie, Ik breng een watervloed over de aarde, om alle vlees, waarin een geest des levens is, van onder den hemel te verderven; al wat op de aarde is, zal den geest geven. [^17] Maar met u zal Ik Mijn verbond oprichten; en gij zult in de ark gaan, gij, en uw zonen, en uw huisvrouw, en de vrouwen uwer zonen met u. [^18] En gij zult van al wat leeft, van alle vlees, twee van elk, doen in de ark komen, om met u in het leven te behouden: mannetje en wijfje zullen zij zijn; [^19] Van het gevogelte naar zijn aard, en van het vee naar zijn aard, van al het kruipend gedierte des aardbodems naar zijn aard, twee van elk zullen tot u komen, om die in het leven te behouden. [^20] En gij, neem voor u van alle spijze, die gegeten wordt, en verzamel ze tot u, opdat zij u en hun tot spijze zij. [^21] En Noach deed het; naar al wat God hem geboden had, zo deed hij. [^22] 

[[Genesis - 5|<--]] Genesis - 6 [[Genesis - 7|-->]]

---
# Notes
