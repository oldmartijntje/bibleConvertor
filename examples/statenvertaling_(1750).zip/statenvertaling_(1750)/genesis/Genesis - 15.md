---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 15 - Statenvertaling (1750)"
---
[[Genesis - 14|<--]] Genesis - 15 [[Genesis - 16|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Genesis]]

# Genesis - 15

Na deze dingen geschiedde het woord des HEEREN tot Abram in een gezicht, zeggende: Vrees niet, Abram! Ik ben u een Schild, uw Loon zeer groot. [^1] Toen zeide Abram: Heere, HEERE! wat zult Gij mij geven, daar ik zonder kinderen heenga en de bezorger van mijn huis is deze Damaskener Eliëzer? [^2] Voorts zeide Abram: Zie, mij hebt Gij geen zaad gegeven, en zie, de zoon van mijn huis zal mijn erfgenaam zijn! [^3] En ziet, het woord des HEEREN was tot hem, zeggende: Deze zal uw erfgenaam niet zijn; maar die uit uw lijf voortkomen zal, die zal uw erfgenaam zijn. [^4] Toen leidde Hij hem uit naar buiten, en zeide: Zie nu op naar den hemel, en tel de sterren, indien gij ze tellen kunt; en Hij zeide tot hem: Zo zal uw zaad zijn! [^5] En hij geloofde in den HEERE; en Hij rekende het hem tot gerechtigheid. [^6] Voorts zeide Hij tot hem: Ik ben de HEERE, Die u uitgeleid heb uit Ur der Chaldeën, om u dit land te geven, om dat erfelijk te bezitten. [^7] En hij zeide: Heere, HEERE! waarbij zal ik weten, dat ik het erfelijk bezitten zal? [^8] En Hij zeide tot hem: Neem Mij een driejarige vaars, en een driejarige geit, en een driejarigen ram, en een tortelduif, en een jonge duif. [^9] En hij bracht Hem deze alle, en hij deelde ze middendoor, en hij legde elks deel tegen het andere over; maar het gevogelte deelde hij niet. [^10] En het wild gevogelte kwam neder op het aas; maar Abram joeg het weg. [^11] En het geschiedde, als de zon was aan het ondergaan, zo viel een diepe slaap op Abram; en ziet, een schrik, en grote duisternis viel op hem. [^12] Toen zeide Hij tot Abram: Weet voorzeker, dat uw zaad vreemd zal zijn in een land, dat het hunne niet is, en zij zullen hen dienen, en zij zullen hen verdrukken vierhonderd jaren. [^13] Doch Ik zal het volk ook rechten, hetwelk zij zullen dienen; en daarna zullen zij uittrekken met grote have. [^14] En gij zult tot uw vaderen gaan met vrede; gij zult in goeden ouderdom begraven worden. [^15] En het vierde geslacht zal herwaarts wederkeren; want de ongerechtigheid der Amorieten is tot nog toe niet volkomen. [^16] En het geschiedde, dat de zon onderging en het duister werd, en ziet, daar was een rokende oven en vurige fakkel, die tussen die stukken doorging. [^17] Ten zelfden dage maakte de HEERE een verbond met Abram, zeggende: Aan uw zaad heb Ik dit land gegeven, van de rivier van Egypte af, tot aan die grote rivier, de rivier Frath: [^18] Den Keniet, en den Keniziet, en den Kadmoniet, [^19] En den Hethiet, en den Fereziet, en de Refaïeten, [^20] En den Amoriet, en den Kanaäniet, en den Girgaziet, en den Jebusiet. [^21] 

[[Genesis - 14|<--]] Genesis - 15 [[Genesis - 16|-->]]

---
# Notes
