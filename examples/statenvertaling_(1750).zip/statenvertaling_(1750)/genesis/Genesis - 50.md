---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 50 - Statenvertaling (1750)"
---
[[Genesis - 49|<--]] Genesis - 50

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Genesis]]

# Genesis - 50

Toen viel Jozef op zijns vaders aangezicht, en hij weende over hem, en kuste hem. [^1] En Jozef gebood zijn knechten, den medicijnmeesters, dat zij zijn vader balsemen zouden; en de medicijnmeesters balsemden Israël. [^2] En veertig dagen werden aan hem vervuld; want alzo werden vervuld de dagen dergenen, die gebalsemd werden; en de Egyptenaars beweenden hem zeventig dagen. [^3] Als nu de dagen zijns bewenens over waren, zo sprak Jozef tot het huis van Farao, zeggende: Indien ik nu genade gevonden heb in uw ogen, spreekt toch voor de oren van Farao, zeggende: [^4] Mijn vader heeft mij doen zweren, zeggende: Zie, ik sterf; in mijn graf, dat ik mij in het land Kanaän gegraven heb, daar zult gij mij begraven! Nu dan, laat mij toch optrekken, dat ik mijn vader begrave, dan zal ik wederkomen. [^5] En Farao zeide: Trek op en begraaf uw vader, gelijk als hij u heeft doen zweren. [^6] En Jozef toog op, om zijn vader te begraven; en met hem togen op alle Farao’s knechten, de oudsten van zijn huis, en al de oudsten des lands van Egypte; [^7] Daartoe het ganse huis van Jozef, en zijn broeders, en het huis zijns vaders; alleen hun kleine kinderen, en hun schapen, en hun runderen lieten zij in het land Gosen. [^8] En met hem togen op, zo wagenen als ruiteren; en het was een zeer zwaar heir. [^9] Toen zij nu aan het plein van het doornbos kwamen, dat aan gene zijde van de Jordaan is, hielden zij daar een grote en zeer zware rouwklage; en hij maakte zijn vader een rouw van zeven dagen. [^10] Als de inwoners des lands, de Kanaänieten, dien rouw zagen op het plein van het doornbos, zo zeiden zij: Dit is een zware rouw der Egyptenaren; daarom noemde men haar naam Abel-Mizraïm, die aan het veer van de Jordaan is. [^11] En zijn zonen deden hem, gelijk als hij hun geboden had; [^12] Want zijn zonen voerden hem in het land Kanaän, en begroeven hem in de spelonk des akkers van Machpela, welke Abraham met den akker gekocht had tot een erfbegrafenis van Efron, den Hethiet, tegenover Mamre. [^13] Daarna keerde Jozef weder in Egypte, hij en zijn broeders, en allen, die met hem opgetogen waren, om zijn vader te begraven, nadat hij zijn vader begraven had. [^14] Toen Jozefs broeders zagen, dat hun vader dood was, zo zeiden zij: Misschien zal ons Jozef haten, en hij zal ons gewisselijk vergelden al het kwaad, dat wij hem aangedaan hebben. [^15] Daarom ontboden zij aan Jozef, zeggende: Uw vader heeft bevolen voor zijn dood, zeggende: [^16] Zo zult gij tot Jozef zeggen: Ei, vergeef toch de overtreding uwer broederen, en hun zonde; want zij hebben u kwaad aangedaan; maar nu vergeef toch de overtreding der dienaren van den God uws vaders! En Jozef weende, als zij tot hem spraken. [^17] Daarna kwamen ook zijn broeders, en vielen voor hem neder, en zeiden: Zie, wij zijn u tot knechten! [^18] En Jozef zeide tot hen: Vreest niet; want ben ik in de plaats van God? [^19] Gijlieden wel, gij hebt kwaad tegen mij gedacht; doch God heeft dat ten goede gedacht; opdat Hij deed, gelijk het te dezen dage is, om een groot volk in het leven te behouden. [^20] Nu dan, vreest niet! Ik zal u en uw kleine kinderen onderhouden. Zo troostte hij hen, en sprak naar hun hart. [^21] Jozef dan woonde in Egypte, hij en het huis zijns vaders; en Jozef leefde honderd en tien jaren. [^22] En Jozef zag van Efraïm kinderen, van het derde gelid; ook werden de zonen van Machir, den zoon van Manasse, op Jozefs knieën geboren. [^23] En Jozef zeide tot zijn broederen: Ik sterf; maar God zal u gewisselijk bezoeken, en Hij zal u doen optrekken uit dit land, in het land, hetwelk Hij aan Abraham, Izak en Jakob gezworen heeft. [^24] En Jozef deed de zonen van Israël zweren, zeggende: God zal u gewisselijk bezoeken, zo zult gij mijn beenderen van hier opvoeren! [^25] En Jozef stierf, honderd en tien jaren oud zijnde; en zij balsemden hem, en men legde hem in een kist in Egypte. [^26] 

[[Genesis - 49|<--]] Genesis - 50

---
# Notes
