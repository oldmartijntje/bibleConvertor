---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomium"
  - "#bible/testament/old"
aliases:
  - "Deuteronomium - 10 - Statenvertaling (1750)"
---
[[Deuteronomium - 9|<--]] Deuteronomium - 10 [[Deuteronomium - 11|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Deuteronomium]]

# Deuteronomium - 10

Ter zelver tijd zeide de HEERE tot mij: Houw u twee stenen tafelen, als de eerste, en klim tot Mij op dezen berg; daarna zult gij u een kist van hout maken. [^1] En Ik zal op die tafelen schrijven de woorden, die geweest zijn op de eerste tafelen, die gij gebroken hebt; en gij zult ze leggen in die kist. [^2] Alzo maakte ik een kist van sittimhout, en hieuw twee stenen tafelen als de eerste; en ik klom op den berg, en de twee tafelen waren in mijn hand. [^3] Toen schreef Hij op de tafelen, naar het eerste schrift, de tien woorden, die de HEERE, ten dage der verzameling, op den berg, uit het midden des vuurs, tot ulieden gesproken had; en de HEERE gaf ze mij. [^4] En ik keerde mij, en ging af van den berg, en legde de tafelen in de kist, die ik gemaakt had; en aldaar zijn zij, gelijk als de HEERE mij geboden heeft. [^5] (En de kinderen Israëls reisden van Beëroth-Bene-Jaäkan en Mosera. Aldaar stierf Aäron, en werd aldaar begraven; en zijn zoon Eleazar bediende het priesterambt in zijn plaats. [^6] Van daar reisden zij naar Gudgod, en van Gudgod naar Jotbath, een land van waterbeken.) [^7] Ter zelver tijd scheidde de HEERE den stam Levi uit, om de ark des verbonds des HEEREN te dragen, om voor het aangezicht des HEEREN te staan, om Hem te dienen, en om in Zijn Naam te zegenen, tot op dezen dag. [^8] Daarom heeft Levi geen deel noch erve met zijn broederen; de HEERE is zijn Erfdeel, gelijk als de HEERE, uw God, tot hem gesproken heeft. [^9] En ik stond op den berg, als de vorige dagen, veertig dagen en veertig nachten; en de HEERE verhoorde mij ook op datzelve maal; de HEERE heeft u niet willen verderven. [^10] Maar de HEERE zeide tot mij: Sta op, ga op de reize, voor het aangezicht des volks, dat zij inkomen, en erven het land, dat Ik hun vaderen gezworen heb, hun te geven. [^11] Nu dan, Israël! wat eist de HEERE, uw God van u dan den HEERE, uw God, te vrezen, in al Zijn wegen te wandelen, en Hem lief te hebben, en den HEERE, uw God, te dienen, met uw ganse hart en met uw ganse ziel; [^12] Om te houden de geboden des HEEREN, en Zijn inzettingen, die ik u heden gebiede, u ten goede. [^13] Ziet, des HEEREN, uws Gods, is de hemel, en de hemel der hemelen, de aarde, en al wat daarin is. [^14] Alleenlijk heeft de HEERE lust gehad aan uw vaderen, om die lief te hebben, en heeft hun zaad na hen, ulieden, uit al de volken verkoren, gelijk het te dezen dage is. [^15] Besnijdt dan de voorhuid uws harten, en verhardt uw nek niet meer. [^16] Want de HEERE, uw God, is een God der goden, en een Heere der heren; die grote, die machtige, en die vreselijke God, Die geen aangezicht aanneemt, noch geschenk ontvangt; [^17] Die het recht van den wees en van de weduwe doet; en den vreemdeling liefheeft, dat Hij hem brood en kleding geve. [^18] Daarom zult gijlieden den vreemdeling liefhebben, want gij zijt vreemdelingen geweest in Egypteland. [^19] Den HEERE, uw God, zult gij vrezen; Hem zult gij dienen, en Hem zult gij aanhangen, en bij Zijn Naam zweren. [^20] Hij is uw Lof, en Hij is uw God. Die bij u gedaan heeft deze grote en vreselijke dingen, die uw ogen gezien hebben. [^21] Uw vaderen togen af naar Egypte met zeventig zielen; en nu heeft u de HEERE, uw God, gesteld als de sterren des hemels in menigte. [^22] 

[[Deuteronomium - 9|<--]] Deuteronomium - 10 [[Deuteronomium - 11|-->]]

---
# Notes
