---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomium"
  - "#bible/testament/old"
aliases:
  - "Deuteronomium - 16 - Statenvertaling (1750)"
---
[[Deuteronomium - 15|<--]] Deuteronomium - 16 [[Deuteronomium - 17|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Deuteronomium]]

# Deuteronomium - 16

Neemt waar de maand Abib, dat gij den HEERE, uw God, pascha houdt; want in de maand Abib heeft u de HEERE, uw God, uit Egypteland uitgevoerd, bij nacht. [^1] Dan zult gij den HEERE, uw God, het pascha slachten, schapen en runderen, in de plaats, die de HEERE verkiezen zal, om Zijn Naam aldaar te doen wonen. [^2] Gij zult niets gedesemds op hetzelve eten; zeven dagen zult gij ongezuurde broden op hetzelve eten, een brood der ellende (want in der haast zijt gij uit Egypteland uitgetogen); opdat gij gedenkt aan den dag van uw uittrekken uit Egypteland, al de dagen uws levens. [^3] Er zal bij u in zeven dagen geen zuurdeeg gezien worden in enige uwer landpalen; ook zal van het vlees, dat gij aan den avond van den eersten dag geslacht zult hebben, niets tot den morgen overnachten. [^4] Gij zult het pascha niet mogen slachten in een uwer poorten, die de HEERE, uw God, u geeft. [^5] Maar aan de plaats, die de HEERE, uw God, verkiezen zal om daar Zijn Naam te doen wonen, aldaar zult gij het pascha slachten aan den avond, als de zon ondergaat, ter bestemder tijd van uw uittrekken uit Egypte. [^6] Dan zult gij het koken en eten in de plaats, die de HEERE, uw God, verkiezen zal; daarna zult gij u des morgens keren, en heengaan naar uw tenten. [^7] Zes dagen zult gij ongezuurde broden eten, en aan den zevenden dag is een verbodsdag den HEERE, uw God; dan zult gij geen werk doen. [^8] Zeven weken zult gij u tellen; van dat men met de sikkel begint in het staande koren, zult gij de zeven weken beginnen te tellen. [^9] Daarna zult gij den HEERE, uw God, het feest der weken houden; het zal een vrijwillige schatting uwer hand zijn, dat gij geven zult, naardat u de HEERE, uw God, zal gezegend hebben. [^10] En gij zult vrolijk zijn voor het aangezicht des HEEREN, uws Gods, gij, en uw zoon, en uw dochter, en uw dienstknecht, en uw dienstmaagd, en de Leviet, die in uw poorten is, en de vreemdeling, en de wees, en de weduwe, die in het midden van u zijn; in de plaats, die de HEERE, uw God, zal verkiezen, om Zijnen Naam aldaar te doen wonen. [^11] En gij zult gedenken, dat gij een dienstknecht geweest zijt in Egypte; en gij zult deze inzettingen houden en doen. [^12] Het feest der loofhutten zult gij u zeven dagen houden, als gij zult hebben ingezameld van uw dorsvloer en van uw wijnpers. [^13] En gij zult vrolijk zijn op uw feest, gij, en uw zoon, en uw dochter, en uw dienstknecht, en uw dienstmaagd, en de Leviet, en de vreemdeling, en de wees, en de weduwe, die in uw poorten zijn. [^14] Zeven dagen zult gij den HEERE, uw God, feest houden, in de plaats, die de HEERE verkiezen zal; want de HEERE, uw God, zal u zegenen in al uw inkomen, en in al het werk uwer handen; daarom zult gij immers vrolijk zijn. [^15] Driemaal in het jaar zal alles, wat mannelijk onder u is, voor het aangezicht des HEEREN, uws Gods, verschijnen, in de plaats, die Hij verkiezen zal: op het feest der ongezuurde broden, en op het feest der weken, en op het feest der loofhutten; maar het zal niet ledig voor het aangezicht des HEEREN verschijnen: [^16] Een ieder, naar de gave zijner hand, naar den zegen des HEEREN, uws Gods, dien Hij u gegeven heeft. [^17] Rechters en ambtlieden zult gij u stellen in al uw poorten, die de HEERE, uw God, u geven zal, onder uw stammen; dat zij het volk richten met een gericht der gerechtigheid. [^18] Gij zult het gericht niet buigen; gij zult het aangezicht niet kennen; ook zult gij geen geschenk nemen; want het geschenk verblindt de ogen der wijzen, en verkeert de woorden der rechtvaardigen. [^19] Gerechtigheid, gerechtigheid zult gij najagen; opdat gij leeft, en erfelijk bezit het land, dat u de HEERE, uw God, geven zal. [^20] Gij zult u geen bos planten van enig geboomte, bij het altaar des HEEREN, uws Gods, dat gij u maken zult. [^21] Ook zult gij u geen opgericht beeld stellen, hetwelk de HEERE, uw God, haat. [^22] 

[[Deuteronomium - 15|<--]] Deuteronomium - 16 [[Deuteronomium - 17|-->]]

---
# Notes
