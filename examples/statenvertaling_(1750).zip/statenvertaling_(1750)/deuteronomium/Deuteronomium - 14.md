---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomium"
  - "#bible/testament/old"
aliases:
  - "Deuteronomium - 14 - Statenvertaling (1750)"
---
[[Deuteronomium - 13|<--]] Deuteronomium - 14 [[Deuteronomium - 15|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Deuteronomium]]

# Deuteronomium - 14

Gijlieden zijt kinderen des HEEREN, uws Gods; gij zult uzelven niet snijden, noch kaalheid maken tussen uw ogen, over een dode. [^1] Want gij zijt een heilig volk den HEERE, uw God; en u heeft de HEERE verkoren, om Hem tot een volk des eigendoms te zijn, uit al de volken, die op den aardbodem zijn. [^2] Gij zult geen gruwel eten. [^3] Dit zijn de beesten, die gijlieden eten zult; een os, klein vee der schapen, en klein vee der geiten; [^4] Een hert, en een ree, en een buffel, en een steenbok, en een das, en een wilde os, en een gems. [^5] Alle beesten, die de klauwen verdelen, en de kloof in twee klauwen klieven, en herkauwen onder de beesten, die zult gij eten. [^6] Maar deze zult gij niet eten, van degenen, die alleen herkauwen, of van degenen, die den gekloofden klauw alleen verdelen: den kemel, en den haas, en het konijn; want deze herkauwen wel, maar zij verdelen den klauw niet; onrein zullen zij ulieden zijn. [^7] Ook het varken; want dat verdeelt zijn klauw wel, maar het herkauwt niet; onrein zal het ulieden zijn; van hun vlees zult gij niet eten, en hun dood aas zult gij niet aanroeren. [^8] Dit zult gij eten van alles, wat in de wateren is; al wat vinnen en schubben heeft, zult gij eten. [^9] Maar al wat geen vinnen en schubben heeft, zult gij niet eten; het zal ulieden onrein zijn. [^10] Allen reinen vogel zult gij eten. [^11] Maar deze zijn het, van dewelke gij niet zult eten: de arend, en de havik, en de zeearend; [^12] En de wouw, en de kraai, en de gier naar haar aard; [^13] En alle rave naar haar aard; [^14] En de struis, en de nachtuil, en de koekoek, en de sperwer naar zijn aard; [^15] En de steenuil, en de schuifuit, en de kauw, [^16] En de roerdomp, en de pelikaan, en het duikertje; [^17] En de ooievaar, en de reiger naar zijn aard; en de hop, en de vledermuis; [^18] Ook al het kruipend gevogelte zal ulieden onrein zijn; zij zullen niet gegeten worden. [^19] Al het rein gevogelte zult gij eten. [^20] Gij zult geen dood aas eten; den vreemdeling, die in uw poorten is, zult gij het geven, dat hij het ete, of verkoopt het den vreemde; want gij zijt een heilig volk den HEERE, uw God. Gij zult het bokje niet koken in de melk zijner moeder. [^21] Gij zult getrouwelijk vertienen al het inkomen uws zaads, dat elk jaar van het veld voortkomt. [^22] En voor het aangezicht des HEEREN, uws Gods, ter plaatse, die Hij verkiezen zal, om Zijn Naam aldaar te doen wonen, zult gij eten de tienden van uw koren, van uw most, en van uw olie, en de eerstgeboorten uwer runderen en uwer schapen; opdat gij den HEERE, uw God, leert vrezen alle dagen. [^23] Wanneer dan nog de weg voor u te veel zal zijn, dat gij zulks niet zoudt kunnen heendragen, omdat de plaats te verre van u zal zijn, die de HEERE, uw God, verkiezen zal, om Zijn Naam aldaar te stellen; wanneer de HEERE, uw God, u zal gezegend hebben; [^24] Zo maak het tot geld, en bindt het geld in uw hand, en gaat naar de plaats, die de HEERE, uw God, verkiezen zal; [^25] En geeft dat geld voor alles, wat uw ziel gelust, voor runderen en voor schapen, en voor wijn, en voor sterken drank, en voor alles, wat uw ziel van u begeren zal, en eet aldaar voor het aangezicht des HEEREN, uws Gods, en weest vrolijk, gij en uw huis. [^26] Maar den Leviet, die in uw poorten is, zult gij niet verlaten; want hij heeft geen deel noch erve met u. [^27] Ten einde van drie jaren zult gij voortbrengen alle tienden van uw inkomen, in hetzelve jaar, en gij zult ze wegleggen in uw poorten; [^28] Zo zal komen de Leviet, dewijl hij geen deel noch erve met u heeft, en de vreemdeling, en de wees en de weduwe, die in uw poorten zijn, en zullen eten en verzadigd worden; opdat u de HEERE, uw God, zegene in al het werk uwer hand, dat gij doen zult. [^29] 

[[Deuteronomium - 13|<--]] Deuteronomium - 14 [[Deuteronomium - 15|-->]]

---
# Notes
