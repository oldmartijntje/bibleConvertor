---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomium"
  - "#bible/testament/old"
aliases:
  - "Deuteronomium - 25 - Statenvertaling (1750)"
---
[[Deuteronomium - 24|<--]] Deuteronomium - 25 [[Deuteronomium - 26|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Deuteronomium]]

# Deuteronomium - 25

Wanneer er tussen lieden twist zal zijn, en zij tot het gerecht zullen toetreden, dat zij hen richten, zo zullen zij den rechtvaardige rechtvaardig spreken, en den onrechtvaardige verdoemen. [^1] En het zal geschieden, indien de onrechtvaardige slagen verdiend heeft, dat de rechter hem zal doen nedervallen, en hem doen slaan in zijn tegenwoordigheid, naar dat het voor zijn onrechtvaardigheid genoeg zal zijn, in getal. [^2] Met veertig slagen zal hij hem doen slaan, hij zal er niet toedoen; opdat niet misschien, zo hij voortvoere hem daarboven met meer slagen te doen slaan, uw broeder dan voor uw ogen verachtelijk gehouden worde. [^3] Een os zult gij niet muilbanden, als hij dorst. [^4] Wanneer broeders samenwonen, en een van hen sterft, en geen zoon heeft, zo zal de vrouw des verstorvenen aan geen vreemden man daarbuiten geworden; haar mans broeder zal tot haar ingaan, en nemen haar zich ter vrouw, en doen haar den plicht van eens mans broeder. [^5] En het zal geschieden, dat de eerstgeborene, dien zij zal baren, zal staan in den naam zijns broeders, des verstorvenen; opdat zijn naam niet uitgedelgd worde uit Israël. [^6] Maar indien dezen man zijns broeders vrouw niet bevallen zal te nemen, zo zal zijn broeders vrouw opgaan naar de poort tot de oudsten, en zeggen: Mijns mans broeder weigert zijn broeder een naam te verwekken in Israël; hij wil mij den plicht van eens mans broeders niet doen. [^7] Dan zullen hem de oudsten zijner stad roepen, en tot hem spreken; blijft hij dan daarbij staan, en zegt: Het bevalt mij niet haar te nemen; [^8] Zo zal zijns broeders vrouw voor de ogen der oudsten tot hem toetreden, en zijn schoen van zijn voet uittrekken, en spuwen in zijn aangezicht, en zal betuigen en zeggen: Alzo zal dien man gedaan worden, die zijns broeders huis niet zal bouwen. [^9] En zijn naam zal in Israël genoemd worden: Het huis desgenen, dien de schoen uitgetogen is. [^10] Wanneer mannen, de een met den ander, twisten, en de vrouw des enen toetreedt, om haar man uit de hand desgenen, die hem slaat, te redden, en haar hand uitstrekt, en zijn schamelheid aangrijpt; [^11] Zo zult gij haar hand afhouwen, uw oog zal niet verschonen. [^12] Gij zult geen tweeërlei weegstenen in uw zak hebben, een groten en een kleinen. [^13] Gij zult in uw huis geen tweeërlei efa hebben, een grote en een kleine. [^14] Gij zult een volkomen en gerechten weegsteen hebben; gij zult een volkomene en gerechte efa hebben; opdat uw dagen verlengd worden in het land, dat u de HEERE, uw God, geven zal. [^15] Want al wie zulks doet, is den HEERE, uw God, een gruwel; ja, al wie onrecht doet. [^16] Gedenkt, wat u Amalek gedaan heeft op den weg, als gij uit Egypte uittoogt; [^17] Hoe hij u op den weg ontmoette, en sloeg onder u in den staart al de zwakken achter u, als gij moede en mat waart; en hij vreesde God niet. [^18] Het zal dan geschieden, als u de HEERE, uw God, rust zal gegeven hebben, van al uw vijanden rondom, in het land, dat u de HEERE, uw God, ten erve geven zal, om hetzelve erfelijk te bezitten, dat gij de gedachtenis van Amalek van onder den hemel zult uitdelgen; vergeet het niet! [^19] 

[[Deuteronomium - 24|<--]] Deuteronomium - 25 [[Deuteronomium - 26|-->]]

---
# Notes
