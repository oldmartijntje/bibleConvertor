---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomium"
  - "#bible/testament/old"
aliases:
  - "Deuteronomium - 20 - Statenvertaling (1750)"
---
[[Deuteronomium - 19|<--]] Deuteronomium - 20 [[Deuteronomium - 21|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Deuteronomium]]

# Deuteronomium - 20

Wanneer gij zult uittrekken tot den strijd tegen uw vijanden, en zult zien paarden en wagenen, een volk, meerder dan gij, zo zult gij voor hen niet vrezen; want de HEERE, uw God, is met u, Die u uit Egypteland heeft opgevoerd. [^1] En het zal geschieden, als gijlieden tot den strijd nadert, zo zal de priester toetreden, en tot het volk spreken. [^2] En tot hen zeggen: Hoort, Israël! gijlieden zijt heden na aan den strijd tegen uw vijanden; uw hart worde niet week, vreest niet, en beeft niet, en verschrikt niet voor hun aangezicht. [^3] Want het is de HEERE, uw God, Die met u gaat, om voor u te strijden tegen uw vijanden, om u te verlossen. [^4] Dan zullen de ambtlieden tot het volk spreken, zeggende: Wie is de man, die een nieuw huis heeft gebouwd, en het niet heeft ingewijd? Die ga henen en kere weder naar zijn huis; opdat hij niet misschien sterve in den strijd, en iemand anders dat inwijde. [^5] En wie is de man, die een wijngaard geplant heeft, en deszelfs vrucht niet heeft genoten? Die ga henen en kere weder naar zijn huis, opdat hij niet misschien in den strijd sterve en iemand anders die geniete. [^6] En wie is de man, die een vrouw ondertrouwd heeft, en haar niet tot zich heeft genomen? Die ga henen en kere weder naar zijn huis; opdat hij niet misschien in den strijd sterve, en een ander man haar neme. [^7] Daarna zullen de ambtlieden voortvaren te spreken tot het volk, en zeggen: Wie is de man, die vreesachtig en week van hart is? Die ga henen en kere weder naar zijn huis; opdat het hart zijner broederen niet smelte, gelijk zijn hart. [^8] En het zal geschieden, als die ambtlieden geëindigd zullen hebben te spreken tot het volk, zo zullen zij oversten der heiren aan de spits des volks bestellen. [^9] Wanneer gij nadert tot een stad om tegen haar te strijden, zo zult gij haar den vrede toeroepen. [^10] En het zal geschieden, indien zij u vrede zal antwoorden, en u opendoen, zo zal al het volk, dat daarin gevonden wordt, u cijnsbaar zijn, en u dienen. [^11] Doch zo zij geen vrede met u zal maken, maar krijg tegen u voeren, zo zult gij haar belegeren. [^12] En de HEERE, uw God, zal haar in uw hand geven; en gij zult alles, wat mannelijk daarin is, slaan met de scherpte des zwaards; [^13] Behalve de vrouwen, en de kinderkens, en de beesten, en al wat in de stad zijn zal, al haar buit zult gij voor u roven; en gij zult eten den buit uwer vijanden, dien u de HEERE, uw God, gegeven heeft. [^14] Alzo zult gij aan alle steden doen, die zeer verre van u zijn, die niet zijn van de steden dezer volken. [^15] Maar van de steden dezer volken, die u de HEERE, uw God, ten erve geeft, zult gij niets laten leven, dat adem heeft. [^16] Maar gij zult ze ganselijk verbannen: de Hethieten, en de Amorieten, en de Kanaänieten, en de Ferezieten, de Hevieten, en de Jebusieten, gelijk als u de HEERE, uw God, geboden heeft; [^17] Opdat zij ulieden niet leren te doen naar al hun gruwelen, die zij hun goden gedaan hebben, en gij zondigt tegen den HEERE, uw God. [^18] Wanneer gij een stad vele dagen zult belegeren, strijdende tegen haar, om die in te nemen, zo zult gij haar geboomte niet verderven, de bijl daaraan drijvende; want gij zult daarvan eten; daarom zult gij dat niet afhouwen (want het geboomte van het veld is des mensen spijze), opdat het voor uw aangezicht kome tot een bolwerk. [^19] Maar het geboomte, hetwelk gij kennen zult, dat het geen geboomte ter spijze is, dat zult gij verderven en afhouwen; en gij zult een bolwerk bouwen tegen deze stad, dewelke tegen u krijg voert, totdat zij ten onderga. [^20] 

[[Deuteronomium - 19|<--]] Deuteronomium - 20 [[Deuteronomium - 21|-->]]

---
# Notes
