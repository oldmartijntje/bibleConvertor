---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomium"
  - "#bible/testament/old"
aliases:
  - "Deuteronomium - 27 - Statenvertaling (1750)"
---
[[Deuteronomium - 26|<--]] Deuteronomium - 27 [[Deuteronomium - 28|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Deuteronomium]]

# Deuteronomium - 27

En Mozes, te zamen met de oudsten van Israël, gebood het volk, zeggende: Behoudt al deze geboden, die ik ulieden heden gebiede. [^1] Het zal dan geschieden, ten dage als gij over de Jordaan zult gegaan zijn in het land, dat u de HEERE, uw God, geven zal, zo zult gij u grote stenen oprichten, en bestrijken ze met kalk; [^2] En gij zult daarop schrijven alle woorden dezer wet, als gij overgegaan zult zijn; opdat gij komt in het land, dat de HEERE, uw God, u geven zal, een land vloeiende van melk en honig, gelijk als de HEERE, uwer vaderen God, tot u gesproken heeft. [^3] Het zal dan geschieden, als gij over de Jordaan gegaan zult zijn, dat gij dezelve stenen, van dewelke ik u heden gebiede, zult oprichten op den berg Ebal, en gij zult ze met kalk bestrijken; [^4] En gij zult aldaar den HEERE, uw God, een altaar bouwen, een altaar van stenen; gij zult geen ijzer over hetzelve bewegen. [^5] Van gehele stenen zult gij het altaar des HEEREN, uws Gods, bouwen, en gij zult den HEERE, uw God, brandofferen daarop offeren. [^6] Ook zult gij dankofferen offeren, en zult aldaar eten, en vrolijk zijn voor het aangezicht des HEEREN, uws Gods. [^7] En gij zult op deze stenen schrijven alle woorden dezer wet, die wel uitdrukkende. [^8] Voorts sprak Mozes, te zamen met de Levietische priesteren, tot gans Israël, zeggende: Luistert toe en hoort o Israël! Op dezen dag zijt gij den HEERE, uw God, tot een volk geworden. [^9] Daarom zult gij der stem des HEEREN, uws Gods, gehoorzaam zijn, en gij zult doen Zijn geboden en Zijn inzettingen, die ik u heden gebiede. [^10] En Mozes gebood het volk te dien dage, zeggende: [^11] Dezen zullen staan, om het volk te zegenen op den berg Gerizim, als gij over de Jordaan gegaan zult zijn: Simeon, en Levi, en Juda, en Issaschar, en Jozef, en Benjamin. [^12] En dezen zullen staan over den vloek op den berg Ebal: Ruben, Gad en Aser, Zebulon, Dan en Nafthali. [^13] En de Levieten zullen betuigen en zeggen tot allen man van Israël, met verhevene stem: [^14] Vervloekt zij de man, die een gesneden of gegoten beeld, een gruwel des HEEREN, een werk van ‘s werkmeesters handen, zal maken, en zetten in het verborgene! En al het volk zal antwoorden en zeggen: Amen. [^15] Vervloekt zij, die zijn vader of zijn moeder veracht! En al het volk zal zeggen: Amen. [^16] Vervloekt zij, die zijns naasten landpale verrukt! En al het volk zal zeggen: Amen. [^17] Vervloekt zij, die een blinde op den weg doet dolen! En al het volk zal zeggen: Amen. [^18] Vervloekt zij, die het recht van den vreemdeling, van den wees en van de weduwe buigt! En al het volk zal zeggen: Amen. [^19] Vervloekt zij, die bij de vrouw zijns vaders ligt, omdat hij zijns vaders slippe ontdekt heeft! En al het volk zal zeggen: Amen. [^20] Vervloekt zij, die bij enig beest ligt! En al het volk zal zeggen: Amen. [^21] Vervloekt zij, die bij zijn zuster ligt, de dochter zijns vaders of de dochter zijner moeder! En al het volk zal zeggen: Amen. [^22] Vervloekt zij, die bij zijn schoonmoeder ligt! En al het volk zal zeggen: Amen. [^23] Vervloekt zij, die zijn naaste in het verborgene verslaat! En al het volk zal zeggen: Amen. [^24] Vervloekt zij, die geschenk neemt, om een ziel, het bloed eens onschuldigen, te verslaan! En al het volk zal zeggen: Amen. [^25] Vervloekt zij, die de woorden dezer wet niet zal bevestigen, doende dezelve! En al het volk zal zeggen: Amen. [^26] 

[[Deuteronomium - 26|<--]] Deuteronomium - 27 [[Deuteronomium - 28|-->]]

---
# Notes
