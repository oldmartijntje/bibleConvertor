---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomium"
  - "#bible/testament/old"
aliases:
  - "Deuteronomium - 6 - Statenvertaling (1750)"
---
[[Deuteronomium - 5|<--]] Deuteronomium - 6 [[Deuteronomium - 7|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Deuteronomium]]

# Deuteronomium - 6

Dit zijn dan de geboden, de inzettingen en de rechten, die de HEERE, uw God, geboden heeft om u te leren; opdat gij ze doet in het land, naar hetwelk gij heentrekt, om dat erfelijk te bezitten; [^1] Opdat gij den HEERE, uw God, vrezet, om te houden al Zijn inzettingen, en Zijn geboden, die ik u gebiede; gij, en uw kind, en kindskind, al de dagen uws levens; en opdat uw dagen verlengd worden. [^2] Hoor dan, Israël! en neem waar, dat gij ze doet, opdat het u welga, en opdat gij zeer vermenigvuldigdet (gelijk als u de HEERE, uwer vaderen God, gesproken heeft) in het land, dat van melk en honig is vloeiende. [^3] Hoor, Israël! de HEERE, onze God, is een enig HEERE! [^4] Zo zult gij den HEERE, uw God, liefhebben, met uw ganse hart, en met uw ganse ziel, en met al uw vermogen. [^5] En deze woorden, die ik u heden gebiede, zullen in uw hart zijn. [^6] En gij zult ze uw kinderen inscherpen, en daarvan spreken, als gij in uw huis zit, en als gij op den weg gaat, en als gij nederligt, en als gij opstaat. [^7] Ook zult gij ze tot een teken binden op uw hand, en zij zullen u tot voorhoofdspanselen zijn tussen uw ogen. [^8] En gij zult ze op de posten van uw huis, en aan uw poorten schrijven. [^9] Als het dan zal geschied zijn, dat de HEERE, uw God, u zal hebben ingebracht in dat land, dat Hij uw vaderen, Abraham, Izak en Jakob, gezworen heeft, u te zullen geven; grote en goede steden, die gij niet gebouwd hebt, [^10] En huizen, vol van alle goeds, die gij niet gevuld hebt, en uitgehouwen bornputten, die gij niet uitgehouwen hebt, wijngaarden en olijfgaarden, die gij niet geplant hebt, en gij gegeten hebt en verzadigd zijt; [^11] Zo wacht u, dat gij den HEERE niet vergeet, Die u uit Egypteland, uit het diensthuis heeft uitgevoerd. [^12] Gij zult den HEERE, uw God, vrezen, en Hem dienen; en gij zult bij Zijn Naam zweren. [^13] Gij zult andere goden niet navolgen, van de goden der volken, die rondom u zijn. [^14] Want de HEERE, uw God is een ijverig God in het midden van u; dat de toorn des HEEREN, uws Gods, tegen u niet ontsteke, en Hij u van den aardbodem verdelge. [^15] Gij zult den HEERE, uw God, niet verzoeken, gelijk als gij Hem verzocht hebt te Massa. [^16] Gij zult de geboden des HEEREN, uws Gods, vlijtig houden, mitsgaders Zijn getuigenissen, en Zijn inzettingen, die Hij u geboden heeft. [^17] En gij zult doen, wat recht en goed is in de ogen des HEEREN; opdat het u welga, en dat gij inkomt, en erft het goede land, dat de HEERE uw vaderen gezworen heeft; [^18] Om al uw vijanden voor uw aangezicht te verdrijven, gelijk als de HEERE gesproken heeft. [^19] Wanneer uw zoon u morgen zal vragen, zeggende: Wat zijn dat voor getuigenissen, en inzettingen, en rechten, die de HEERE, onze God, ulieden geboden heeft? [^20] Zo zult gij tot uw zoon zeggen: Wij waren dienstknechten van Farao in Egypte; maar de HEERE heeft ons door een sterke hand uit Egypte uitgevoerd. [^21] En de HEERE gaf tekenen, en grote en kwade wonderen, in Egypte, aan Farao en aan zijn ganse huis, voor onze ogen; [^22] En hij voerde ons van daar uit, opdat Hij ons inbracht, om ons het land te geven, dat Hij onzen vaderen gezworen had. [^23] En de HEERE gebood ons te doen al deze inzettingen, om te vrezen den HEERE, onzen God, ons voor altoos ten goede, om ons in het leven te behouden, gelijk het te dezen dage is. [^24] En het zal ons gerechtigheid zijn, als wij zullen waarnemen te doen al deze geboden, voor het aangezicht des HEEREN, onzes Gods, gelijk Hij ons geboden heeft. [^25] 

[[Deuteronomium - 5|<--]] Deuteronomium - 6 [[Deuteronomium - 7|-->]]

---
# Notes
