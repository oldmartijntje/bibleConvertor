---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomium"
  - "#bible/testament/old"
aliases:
  - "Deuteronomium - 23 - Statenvertaling (1750)"
---
[[Deuteronomium - 22|<--]] Deuteronomium - 23 [[Deuteronomium - 24|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Deuteronomium]]

# Deuteronomium - 23

Die door plettering verwond of uitgesneden is aan de mannelijkheid, zal in de vergadering des HEEREN niet komen. [^1] Geen bastaard zal in de vergadering des HEEREN komen; zelfs zijn tiende geslacht zal in de vergadering des HEEREN niet komen. [^2] Geen Ammoniet, noch Moabiet zal in de vergadering des HEEREN komen; zelfs hun tiende geslacht zal in de vergadering des HEEREN niet komen tot in eeuwigheid. [^3] Ter oorzake dat zij ulieden op den weg niet tegengekomen zijn met brood en met water, als gij uit Egypte uittoogt; en omdat hij tegen u gehuurd heeft Bileam, den zoon van Beor, van Pethor uit Mesopotamië, om u te vloeken. [^4] Doch de HEERE, uw God, heeft naar Bileam niet willen horen; maar de HEERE, uw God, heeft u den vloek in een zegen veranderd, omdat de HEERE, uw God, u liefhad. [^5] Gij zult hun vrede en hun best niet zoeken, al uw dagen in eeuwigheid. [^6] Den Edomiet zult gij voor geen gruwel houden, want hij is uw broeder; den Egyptenaar zult gij voor geen gruwel houden want gij zijt een vreemdeling geweest in zijn land. [^7] Aangaande de kinderen, die hun zullen geboren worden in het derde geslacht, elk van die zal in de vergadering des HEEREN komen. [^8] Wanneer het leger uittrekt tegen uw vijanden, zo zult gij u wachten voor alle kwade zaak. [^9] Wanneer iemand onder u is, die niet rein is, door enig toeval des nachts, die zal tot buiten het leger uitgaan; hij zal tot binnen het leger niet komen. [^10] Maar het zal geschieden, dat hij zich tegen het naken van den avond met water zal baden; en als de zon ondergegaan is, zal hij tot binnen het leger komen. [^11] Gij zult ook een plaats hebben buiten het leger, en daarhenen zult gij uitgaan naar buiten. [^12] En gij zult een schopje hebben, benevens uw gereedschap, en het zal geschieden, als gij buiten gezeten hebt, dan zult gij daarmede graven, en u omkeren, en bedekken wat van u uitgegaan is. [^13] Want de HEERE, uw God, wandelt in het midden van uw leger, om u te verlossen, en om uw vijanden voor uw aangezicht te geven; daarom zal uw leger heilig zijn, opdat Hij niets schandelijks onder u zie, en achterwaarts van u afkere. [^14] Gij zult een knecht aan zijn heer niet overleveren, die van zijn heer tot u ontkomen zal zijn. [^15] Hij zal bij u blijven in het midden van u, in de plaats, die hij zal verkiezen, in een van uw poorten, waar het goed voor hem is; gij zult hem niet verdrukken. [^16] Er zal geen hoer zijn onder de dochteren van Israël; en er zal geen schandjongen zijn onder de zonen van Israël. [^17] Gij zult geen hoerenloon noch hondenprijs in het huis des HEEREN, uws Gods, brengen, tot enige gelofte; want ook die beiden zijn den HEERE, uw God, een gruwel. [^18] Gij zult aan uw broeder niet woekeren, met woeker van geld, met woeker van spijze, met woeker van enig ding, waarmede men woekert. [^19] Aan den vreemde zult gij woekeren; maar aan uw broeder zult gij niet woekeren; opdat u de HEERE, uw God, zegene, in alles, waaraan gij uw hand slaat, in het land, waar gij naar toe gaat, om dat te erven. [^20] Wanneer gij den HEERE, uw God, een gelofte zult beloofd hebben, gij zult niet vertrekken die te betalen; want de HEERE, uw God, zal ze zekerlijk van u eisen, en zonde zou in u zijn. [^21] Maar als gij nalaat te beloven, zo zal het geen zonde in u zijn. [^22] Wat uit uw lippen gaat, zult gij houden en doen; gelijk als gij den HEERE, uw God, een vrijwillig offer beloofd hebt, dat gij met uw mond gesproken hebt. [^23] Wanneer gij gaan zult in uws naasten wijngaard, zo zult gij druiven eten naar uw lust, tot uw verzadiging; maar in uw vat zult gij niets doen. [^24] Wanneer gij zult gaan in uws naasten staande koren, zo zult gij de aren met uw hand afplukken; maar de sikkel zult gij aan uws naasten staande koren niet bewegen. [^25] 

[[Deuteronomium - 22|<--]] Deuteronomium - 23 [[Deuteronomium - 24|-->]]

---
# Notes
