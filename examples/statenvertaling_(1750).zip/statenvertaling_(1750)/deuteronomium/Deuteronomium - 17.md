---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomium"
  - "#bible/testament/old"
aliases:
  - "Deuteronomium - 17 - Statenvertaling (1750)"
---
[[Deuteronomium - 16|<--]] Deuteronomium - 17 [[Deuteronomium - 18|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Deuteronomium]]

# Deuteronomium - 17

Gij zult den HEERE, uw God, geen os of klein vee offeren, waaraan een gebrek zij of enig kwaad; want dat is den HEERE, uw God, een gruwel. [^1] Wanneer in het midden van u, in een uwer poorten, die de HEERE, uw God, u geeft, een man of vrouw gevonden zal worden, die doen zal, dat kwaad is in de ogen des HEEREN, uws Gods, overtredende Zijn verbond; [^2] Dat hij heengaat, en dient andere goden, en buigt zich voor die, of voor de zon, of voor de maan, of voor het ganse heir des hemels, hetwelk ik niet geboden heb; [^3] En het wordt u aangezegd, en gij hoort het; zo zult gij het wel onderzoeken; en ziet, het is de waarheid, de zaak is zeker, zulk een gruwel is in Israël gedaan; [^4] Zo zult gij dien man of die vrouw, die ditzelve boze stuk gedaan hebben, tot uw poorten uitbrengen, dien man zeg ik, of die vrouw; en gij zult hen met stenen stenigen, dat zij sterven. [^5] Op den mond van twee getuigen, of drie getuigen, zal hij gedood worden, die sterven zal; op den mond van een enigen getuige zal hij niet gedood worden. [^6] De hand der getuigen zal eerst tegen hem zijn, om hem te doden, en daarna de hand des gansen volks; zo zult gij het boze uit het midden van u wegdoen. [^7] Wanneer een zaak aan het gericht voor u te zwaar zal zijn, tussen bloed en bloed, tussen rechtshandel en rechtshandel, tussen plage en plage, zijnde twistzaken in uw poorten, zo zult gij u opmaken en opgaan naar de plaats, die de HEERE, uw God, verkiezen zal; [^8] En gij zult komen tot de Levietische priesters, en tot den rechter, die in die dagen zijn zal; en gij zult ondervragen, en zij zullen u de zaak des rechts aanzeggen. [^9] En gij zult doen naar het bevel des woords, dat zij u zullen aanzeggen, van diezelve plaats, die de HEERE verkiezen zal, en gij zult waarnemen te doen naar alles, wat zij u zullen leren. [^10] Naar het bevel der wet, die zij u zullen leren, en naar het oordeel, dat zij u zullen zeggen, zult gij doen; gij zult niet afwijken van het woord, dat zij u zullen aanzeggen, ter rechter- of ter linkerhand. [^11] De man nu, die trotselijk handelen zal, dat hij niet hore naar den priester, dewelke staat, om aldaar den HEERE, uw God, te dienen, of naar den rechter, dezelve man zal sterven; en gij zult het boze uit Israël wegdoen. [^12] Dat het al dat volk hore en vreze, en niet meer trotselijk handele. [^13] Wanneer gij zult gekomen zijn in het land, dat u de HEERE, uw God, geeft, en gij dat erfelijk zult bezitten en daarin wonen, en gij zeggen zult: Ik zal een koning over mij stellen, als al de volken, die rondom mij zijn; [^14] Zo zult gij ganselijk tot koning over u stellen, dien de HEERE, uw God, verkiezen zal; uit het midden uwer broederen zult gij een koning over u stellen; gij zult niet vermogen over u te zetten een vreemden man, die uw broeder niet zij. [^15] Maar hij zal voor zich de paarden niet vermenigvuldigen, en het volk niet doen wederkeren naar Egypte, om paarden te vermenigvuldigen; terwijl de HEERE ulieden gezegd heeft: Gij zult voortaan niet wederkeren door dezen weg. [^16] Ook zal hij voor zich de vrouwen niet vermenigvuldigen, opdat zijn hart niet afwijke; hij zal ook voor zich geen zilver en goud zeer vermenigvuldigen. [^17] Voorts zal het geschieden, als hij op den stoel zijns koninkrijks zal zitten, zo zal hij zich een dubbel van deze wet afschrijven in een boek, uit hetgeen voor het aangezicht der Levietische priesteren is; [^18] En het zal bij hem zijn, en hij zal daarin lezen al de dagen zijns levens; opdat hij den HEERE, zijn God, lere vrezen, om te bewaren al de woorden dezer wet en deze inzettingen, om die te doen; [^19] Dat zijn hart zich niet verheffe boven zijn broederen, en dat hij niet afwijke van het gebod, ter rechter- of ter linkerhand; opdat hij de dagen verlenge in zijn koninkrijk, hij en zijn zonen, in het midden van Israël. [^20] 

[[Deuteronomium - 16|<--]] Deuteronomium - 17 [[Deuteronomium - 18|-->]]

---
# Notes
