---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomium"
  - "#bible/testament/old"
aliases:
  - "Deuteronomium - 18 - Statenvertaling (1750)"
---
[[Deuteronomium - 17|<--]] Deuteronomium - 18 [[Deuteronomium - 19|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Deuteronomium]]

# Deuteronomium - 18

De Levietische priesteren, de ganse stam van Levi, zullen geen deel noch erve hebben met Israël; de vuuroffers des HEEREN en Zijn erfdeel zullen zij eten. [^1] Daarom zal hij geen erfdeel hebben in het midden zijner broederen; de HEERE is zijn Erfdeel, gelijk als Hij tot hem gesproken heeft. [^2] Dit nu zal het recht der priesters zijn van het volk, van hen, die een offerande offeren, hetzij een os, of klein vee: dat hij den priester zal geven den schouder, en beide kinnebakken, en de pens. [^3] De eerstelingen van uw koren, van uw most en van uw olie, en de eerstelingen van de beschering uwer schapen zult gij hem geven; [^4] Want de HEERE, uw God, heeft hem uit al uw stammen verkoren, dat hij sta, om te dienen in den Naam des HEEREN, hij en zijn zonen, te allen dage. [^5] Voorts wanneer een Leviet zal komen uit een uwer poorten, uit gans Israël, alwaar hij woont, en hij komt naar alle begeerte zijner ziel, tot de plaats, die de HEERE zal hebben verkoren; [^6] En hij dienen zal in den Naam des HEEREN, zijns Gods, als al zijn broederen, de Levieten, die aldaar voor het aangezicht des HEEREN staan; [^7] Zo zullen zij een gelijk deel eten, boven zijn verkoping bij de vaderen. [^8] Wanneer gij komt in het land, dat de HEERE, uw God, u geven zal, zo zult gij niet leren te doen naar de gruwelen van dezelve volken. [^9] Onder u zal niet gevonden worden, die zijn zoon of zijn dochter door het vuur doet doorgaan, die met waarzeggerijen omgaat, een guichelaar, of die op vogelgeschrei acht geeft, of tovenaar. [^10] Of een bezweerder, die met bezwering omgaat, of die een waarzeggenden geest vraagt, of een duivelskunstenaar, of die de doden vraagt. [^11] Want al wie zulks doet, is den HEERE een gruwel; en om dezer gruwelen wil verdrijft hen de HEERE, uw God, voor uw aangezicht, uit de bezitting. [^12] Oprecht zult gij zijn met den HEERE, uw God. [^13] Want deze volken, die gij zult erven, horen naar guichelaars en waarzeggers; maar u aangaande, de HEERE, uw God, heeft u zulks niet toegelaten. [^14] Een Profeet, uit het midden van u, uit uw broederen, als mij, zal u de HEERE, uw God, verwekken; naar Hem zult gij horen; [^15] Naar alles, wat gij van den HEERE, uw God, aan Horeb, ten dage der verzameling, geëist hebt, zeggende: Ik zal niet voortvaren te horen de stem des HEEREN, mijns Gods, en ditzelve grote vuur zal ik niet meer zien, dat ik niet sterve. [^16] Toen zeide de HEERE tot mij: Het is goed, wat zij gesproken hebben. [^17] Een Profeet zal Ik hun verwekken uit het midden hunner broederen, als u; en Ik zal Mijn woorden in Zijn mond geven, en Hij zal tot hen spreken alles, wat Ik Hem gebieden zal. [^18] En het zal geschieden, de man, die niet zal horen naar Mijn woorden, die Hij in Mijn Naam zal spreken, van dien zal Ik het zoeken. [^19] Maar de profeet, die hoogmoediglijk zal handelen, sprekende een woord in Mijn Naam, hetwelk Ik hem niet geboden heb te spreken, of die spreken zal in den naam van andere goden, dezelve profeet zal sterven. [^20] Zo gij dan in uw hart zoudt mogen zeggen: Hoe zullen wij het woord kennen, dat de HEERE niet gesproken heeft? [^21] Wanneer die profeet in den Naam des HEEREN zal hebben gesproken, en dat woord geschiedt niet, en komt niet; dat is het woord, dat de HEERE niet gesproken heeft; door trotsheid heeft die profeet dat gesproken; gij zult voor hem niet vrezen. [^22] 

[[Deuteronomium - 17|<--]] Deuteronomium - 18 [[Deuteronomium - 19|-->]]

---
# Notes
