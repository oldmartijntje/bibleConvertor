---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomium"
  - "#bible/testament/old"
aliases:
  - "Deuteronomium - 13 - Statenvertaling (1750)"
---
[[Deuteronomium - 12|<--]] Deuteronomium - 13 [[Deuteronomium - 14|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Deuteronomium]]

# Deuteronomium - 13

Wanneer een profeet, of dromen-dromer, in het midden van u zal opstaan, en u geven een teken of wonder; [^1] En dat teken of dat wonder komt, dat hij tot u gesproken had, zeggende: Laat ons andere goden, die gij niet gekend hebt, navolgen en hen dienen; [^2] Gij zult naar de woorden van dien profeet, of naar dien dromen-dromer niet horen; want de HEERE, uw God, verzoekt ulieden, om te weten, of gij den HEERE, uw God, liefhebt met uw ganse hart en met uw ganse ziel. [^3] Den HEERE, uw God, zult gij navolgen, en Hem vrezen, en Zijn geboden zult gij houden, en Zijn stem gehoorzaam zijn, en Hem dienen, en Hem aanhangen. [^4] En diezelve profeet, of dromen-dromer, zal gedood worden; want hij heeft tot een afval gesproken tegen den HEERE, uw God, Die ulieden uit Egypteland heeft uitgevoerd, en u uit het diensthuis verlost; om u af te drijven van den weg, dien u de HEERE, uw God, geboden heeft, om daarin te wandelen. Zo zult gij het boze uit het midden van u wegdoen. [^5] Wanneer uw broeder, de zoon uwer moeder, of uw zoon, of uw dochter, of de vrouw van uw schoot, of uw vriend, die als uw ziel is, u zal aanporren in het heimelijke, zeggende: Laat ons gaan, en dienen andere goden, die gij niet gekend hebt, gij noch uw vaderen; [^6] Van de goden der volken, die rondom u zijn, nabij u, of verre van u, van het ene einde der aarde tot aan het andere einde der aarde; [^7] Zo zult gij hem niet ter wille zijn, en naar hem niet horen; ook zal uw oog hem niet verschonen, en gij zult u niet ontfermen, noch hem verbergen; [^8] Maar gij zult hem zekerlijk doodslaan; uw hand zal eerst tegen hem zijn, om hem te doden, en daarna de hand des gansen volks. [^9] En gij zult hem met stenen stenigen, dat hij sterve; want hij heeft u gezocht af te drijven van den HEERE, uw God, Die u uit Egypteland, uit het diensthuis, uitgevoerd heeft. [^10] Opdat gans Israël het hore en vreze, en niet voortvare te doen naar dit boze stuk in het midden van u. [^11] Wanneer gij van een uwer steden, die de HEERE, uw God, u geeft, om aldaar te wonen, zult horen zeggen: [^12] Er zijn mannen, Belials-kinderen, uit het midden van u uitgegaan, en hebben de inwoners hunner stad aangedreven, zeggende: Laat ons gaan, en dienen andere goden, die gij niet gekend hebt; [^13] Zo zult gij onderzoeken, en naspeuren, en wel navragen; en ziet, het is de waarheid, de zaak is zeker, zulk een gruwel is in het midden van u gedaan; [^14] Zo zult gij de inwoners derzelver stad ganselijk slaan met de scherpte des zwaards, verbannende haar, en alles, wat daarin is, ook haar beesten, met de scherpte des zwaards. [^15] En al haar roof zult gij verzamelen in het midden van haar straat, en den HEERE, uw God, die stad en al haar roof ganselijk met vuur verbranden; en zij zal een hoop zijn eeuwiglijk, zij zal niet weder gebouwd worden. [^16] Ook zal er niets van het verbannene aan uw hand kleven, opdat de HEERE Zich wende van de hitte Zijns toorns, en u geve barmhartigheid, en Zich uwer erbarme, en u vermenigvuldige, gelijk als Hij uw vaderen gezworen heeft; [^17] Wanneer gij de stem des HEEREN, uws Gods, zult gehoorzaam zijn, om te houden al Zijn geboden, die ik u heden gebiede, om te doen wat recht is in de ogen des HEEREN, uws Gods. [^18] 

[[Deuteronomium - 12|<--]] Deuteronomium - 13 [[Deuteronomium - 14|-->]]

---
# Notes
