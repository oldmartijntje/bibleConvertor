---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomium"
  - "#bible/testament/old"
aliases:
  - "Deuteronomium - 8 - Statenvertaling (1750)"
---
[[Deuteronomium - 7|<--]] Deuteronomium - 8 [[Deuteronomium - 9|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Deuteronomium]]

# Deuteronomium - 8

Alle geboden, die ik u heden gebiede, zult gij waarnemen om te doen, opdat gij leeft, en vermenigvuldigt, en inkomt, en het land erft, dat de HEERE aan uw vaderen gezworen heeft. [^1] En gij zult gedenken aan al den weg, dien u de HEERE, uw God, deze veertig jaren in de woestijn geleid heeft; opdat Hij u verootmoedige, om u te verzoeken, om te weten, wat in uw hart was, of gij Zijn geboden zoudt houden, of niet. [^2] En Hij verootmoedigde u, en liet u hongeren, en spijsde u met het Man, dat gij niet kendet, noch uw vaderen gekend hadden; opdat Hij u bekend maakte, dat de mens niet alleen van het brood leeft, maar dat de mens leeft van alles, wat uit des HEEREN mond uitgaat. [^3] Uw kleding is aan u niet verouderd, en uw voet is niet gezwollen, deze veertig jaren. [^4] Bekent dan in uw hart, dat de HEERE, uw God, u kastijdt, gelijk als een man zijn zoon kastijdt. [^5] En houdt de geboden des HEEREN, uws Gods, om in Zijn wegen te wandelen, en om Hem te vrezen. [^6] Want de HEERE, uw God, brengt u in een goed land, een land van waterbeken, fonteinen en diepten, die in dalen en in bergen uitvlieten; [^7] Een land van tarwe en gerst, en wijnstokken, en vijgebomen, en granaatappelen; een land van olierijke olijfbomen, en van honig; [^8] Een land, waarin gij brood zonder schaarsheid eten zult, waarin u niets ontbreken zal; een land, welks stenen ijzer zijn, en uit welks bergen gij koper uithouwen zult. [^9] Als gij dan zult gegeten hebben, en verzadigd zijn, zo zult gij den HEERE, uw God, loven over dat goede land, dat Hij u zal hebben gegeven. [^10] Wacht u, dat gij den HEERE, uw God, niet vergeet, dat gij niet zoudt houden Zijn geboden, en Zijn rechten, en Zijn inzettingen, die ik u heden gebiede; [^11] Opdat niet misschien, als gij zult gegeten hebben, en verzadigd zijn, en goede huizen gebouwd hebben, en die bewonen, [^12] En uw runderen en uw schapen zullen vermeerderd zijn, ook zilver en goud u zal vermeerderd zijn, ja, al wat gij hebt vermeerderd zal zijn; [^13] Uw hart zich alsdan verheffe, dat gij vergeet den HEERE, uw God, Die u uit Egypteland, uit het diensthuis, uitgevoerd heeft; [^14] Die u geleid heeft in die grote en vreselijke woestijn, waar vurige slangen, en schorpioenen, en dorheid, waar geen water was; Die u water uit de keiachtige rots voortbracht; [^15] Die u in de woestijn spijsde met Man, dat uw vaderen niet gekend hadden; om u te verootmoedigen, en om u te verzoeken, opdat Hij u ten laatste weldeed; [^16] En gij in uw hart zegt: Mijn kracht, en de sterkte mijner hand heeft mij dit vermogen verkregen. [^17] Maar gij zult gedenken den HEERE, uw God, dat Hij het is, Die u kracht geeft om vermogen te verkrijgen; opdat Hij Zijn verbond bevestige, dat Hij aan uw vaderen gezworen heeft, gelijk het te dezen dage is. [^18] Maar indien het geschiedt, dat gij den HEERE, uw God, ganselijk vergeet, en andere goden navolgt, en hen dient, en u voor dezelve buigt, zo betuig ik heden tegen u, dat gij voorzeker zult vergaan. [^19] Gelijk de heidenen, die de HEERE voor uw aangezicht verdaan heeft, alzo zult gij vergaan, omdat gij de stem des HEEREN, uws Gods, niet gehoorzaam zult geweest zijn. [^20] 

[[Deuteronomium - 7|<--]] Deuteronomium - 8 [[Deuteronomium - 9|-->]]

---
# Notes
