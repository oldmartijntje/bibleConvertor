---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomium"
  - "#bible/testament/old"
aliases:
  - "Deuteronomium - 19 - Statenvertaling (1750)"
---
[[Deuteronomium - 18|<--]] Deuteronomium - 19 [[Deuteronomium - 20|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Deuteronomium]]

# Deuteronomium - 19

Wanneer de HEERE, uw God, de volken zal hebben uitgeroeid, welker land de HEERE, uw God, u geven zal, en gij die erfelijk zult bezitten, en in hun steden en in hun huizen wonen; [^1] Zo zult gij u drie steden uitscheiden, in het midden van uw land, hetwelk de HEERE, uw God, u geven zal, om dat erfelijk te bezitten. [^2] Gij zult u den weg bereiden, en de pale uws lands, dat u de HEERE, uw God, zal doen erven, in drieën delen; dit nu zal zijn, opdat ieder doodslager daarhenen vliede. [^3] En dit zij de zaak des doodslagers, die daarhenen vlieden zal, dat hij leve; die zijn naaste zal geslagen hebben door onwetendheid, dien hij toch van gisteren en eergisteren niet haatte; [^4] Als, dewelke met zijn naaste in het bos zal zijn gegaan, om hout te houwen, en zijn hand met de bijl wordt aangedreven, om hout af te houwen, en het ijzer schiet af van den steel, en treft zijn naaste, dat hij sterve; die zal in een dezer steden vluchten en leven; [^5] Opdat de bloedwreker den doodslager niet najage, als zijn hart verhit is, en hem achterhale, omdat de weg te verre zou zijn, en hem sla aan het leven; zo toch geen oordeel des doods aan hem is; want hij haatte hem niet van gisteren en eergisteren. [^6] Daarom gebiede ik u, zeggende: Gij zult u drie steden uitscheiden. [^7] En indien de HEERE, uw God, uw landpale zal verwijden, gelijk als Hij uw vaderen gezworen heeft, en u al dat land geven zal, hetwelk Hij uw vaderen te geven gesproken heeft; [^8] (Wanneer gij al ditzelve gebod zult waarnemen, om dat te doen, hetgeen ik u heden gebiede, den HEERE, uw God, liefhebbende, en alle dagen in Zijn wegen wandelende) zo zult gij u nog drie steden toedoen tot deze drie; [^9] Opdat het bloed des onschuldigen niet vergoten worde in het midden van uw land, dat u de HEERE, uw God, ten erve geeft, en bloedschulden op u zouden zijn. [^10] Maar wanneer er iemand zijn zal, die zijn naaste haat, en hem lagen legt, en staat tegen hem op, en slaat hem aan het leven, dat hij sterve; en vliedt tot een van die steden; [^11] Zo zullen de oudsten zijner stad zenden, en nemen hem van daar, en zij zullen hem in de hand des bloedwrekers geven, dat hij sterve. [^12] Uw oog zal hem niet verschonen; maar gij zult het bloed des onschuldigen uit Israël wegdoen, dat het u welga. [^13] Gij zult uws naasten landpale, die de voorvaderen gepaald hebben, niet verrukken in uw erfdeel, dat gij erven zult, in het land, hetwelk u de HEERE, uw God, geeft, om dat erfelijk te bezitten. [^14] Eén enig getuige zal tegen niemand opstaan over enige ongerechtigheid of over enige zonde, van alle zonde, die hij zou mogen zondigen; op den mond van twee getuigen, of op den mond van drie getuigen zal de zaak bestaan. [^15] Wanneer een wrevelige getuige tegen iemand zal opstaan, om een afwijking tegen hem te betuigen; [^16] Zo zullen die twee mannen, welke den twist hebben, staan voor het aangezicht des HEEREN, voor het aangezicht der priesters, en der rechters, die in diezelve dagen zullen zijn. [^17] En de rechters zullen wel onderzoeken; en ziet, de getuige is een vals getuige, hij heeft valsheid betuigd tegen zijn broeder; [^18] Zo zult gijlieden hem doen, gelijk als hij zijn broeder dacht te doen; alzo zult gij het boze uit het midden van u wegdoen; [^19] Dat de overgeblevenen het horen en vrezen, en niet voortvaren meer te doen naar dit boze stuk, in het midden van u. [^20] En uw oog zal niet verschonen; ziel om ziel, oog om oog, tand om tand, hand om hand, voet om voet. [^21] 

[[Deuteronomium - 18|<--]] Deuteronomium - 19 [[Deuteronomium - 20|-->]]

---
# Notes
