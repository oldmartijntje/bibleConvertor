---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomium"
  - "#bible/testament/old"
aliases:
  - "Deuteronomium - 30 - Statenvertaling (1750)"
---
[[Deuteronomium - 29|<--]] Deuteronomium - 30 [[Deuteronomium - 31|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Deuteronomium]]

# Deuteronomium - 30

Voorts zal het geschieden, wanneer al deze dingen over u zullen gekomen zijn, deze zegen of deze vloek, die ik u voorgesteld heb; zo zult gij het weder ter harte nemen, onder alle volken, waarheen u de HEERE, uw God, gedreven heeft; [^1] En gij zult u bekeren tot den HEERE, uw God, en Zijner stem gehoorzaam zijn, naar alles, wat ik u heden gebiede, gij en uw kinderen, met uw ganse hart en met uw ganse ziel. [^2] En de HEERE, uw God, zal uw gevangenis wenden, en Zich uwer ontfermen; en Hij zal u weder vergaderen uit al de volken, waarheen u de HEERE, uw God, verstrooid had. [^3] Al waren uw verdrevenen aan het einde des hemels, van daar zal u de HEERE, uw God, vergaderen, en van daar zal Hij u nemen. [^4] En de HEERE, uw God, zal u brengen in het land, dat uw vaderen erfelijk bezeten hebben, en gij zult dat erfelijk bezitten; en Hij zal u weldoen, en zal u vermenigvuldigen boven uw vaderen. [^5] En de HEERE, uw God, zal uw hart besnijden, en het hart van uw zaad, om den HEERE, uw God, lief te hebben met uw ganse hart en met uw ganse ziel, opdat gij levet. [^6] En de HEERE, uw God, zal al die vloeken leggen op uw vijanden en op uw haters, die u vervolgd hebben. [^7] Gij dan zult u bekeren, en der stemme des HEEREN gehoorzaam zijn, en gij zult doen al Zijn geboden, die ik u heden gebiede. [^8] En de HEERE, uw God, zal u doen overvloeien in al het werk uwer hand, in de vrucht uws buiks, en in de vrucht uwer beesten, en in de vrucht uws lands, ten goede; want de HEERE zal wederkeren, om Zich over u te verblijden ten goede, gelijk als Hij Zich over uw vaderen verblijd heeft; [^9] Wanneer gij der stemme des HEEREN, uws Gods, zult gehoorzaam zijn, houdende Zijn geboden en Zijn inzettingen, die in dit wetboek geschreven zijn; wanneer gij u zult bekeren tot den HEERE, uw God, met uw ganse hart en met uw ganse ziel. [^10] Want ditzelve gebod, hetwelk ik u heden gebiede, dat is van u niet verborgen, en dat is niet verre. [^11] Het is niet in den hemel, om te zeggen: Wie zal voor ons ten hemel varen, dat hij het voor ons hale, en ons hetzelve horen late, dat wij het doen? [^12] Het is ook niet op gene zijde der zee, om te zeggen: Wie zal voor ons overvaren aan gene zijde der zee, dat hij het voor ons hale, en ons hetzelve horen late, dat wij het doen? [^13] Want dit woord is zeer nabij u, in uw mond, en in uw hart, om dat te doen. [^14] Ziet, ik heb u heden voorgesteld het leven, en het goede, en den dood, en het kwade. [^15] Want ik gebiede u heden, den HEERE, uw God, lief te hebben, in Zijn wegen te wandelen, en te houden Zijn geboden, en Zijn inzettingen, en Zijn rechten, opdat gij levet en vermenigvuldiget, en de HEERE, uw God, u zegene in het land, waar gij naar toe gaat, om dat te erven. [^16] Maar indien uw hart zich zal afwenden, en gij niet horen zult, en gij gedreven zult worden, dat gij u voor andere goden buigt, en dezelve dient; [^17] Zo verkondig ik ulieden heden, dat gij voorzeker zult omkomen; gij zult de dagen niet verlengen op het land, naar hetwelk gij over de Jordaan zijt heengaande, om daarin te komen, dat gij het erfelijk bezit. [^18] Ik neem heden tegen ulieden tot getuigen den hemel en de aarde; het leven en den dood heb ik u voorgesteld, den zegen en den vloek! Kiest dan het leven, opdat gij levet, gij en uw zaad; [^19] Liefhebbende den HEERE, uw God, Zijner stem gehoorzaam zijnde, en Hem aanhangende; want Hij is uw leven en de lengte uwer dagen; opdat gij blijft in het land, dat de HEERE uw vaderen, Abraham, Izak en Jakob, gezworen heeft hun te zullen geven. [^20] 

[[Deuteronomium - 29|<--]] Deuteronomium - 30 [[Deuteronomium - 31|-->]]

---
# Notes
