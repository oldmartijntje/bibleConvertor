---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomium"
  - "#bible/testament/old"
aliases:
  - "Deuteronomium - 15 - Statenvertaling (1750)"
---
[[Deuteronomium - 14|<--]] Deuteronomium - 15 [[Deuteronomium - 16|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Deuteronomium]]

# Deuteronomium - 15

Ten einde van zeven jaren zult gij een vrijlating maken. [^1] Dit nu is de zaak der vrijlating, dat ieder schuldheer, die zijn naaste zal geleend hebben, vrijlate; hij zal zijn naaste of zijn broeder niet manen, dewijl men den HEERE een vrijlating heeft uitgeroepen. [^2] Den vreemde zult gij manen; maar wat gij bij uw broeder hebt, zal uw hand vrijlaten; [^3] Alleenlijk, omdat er geen bedelaar onder u zal zijn; want de HEERE zal u overvloediglijk zegenen in het land, dat u de HEERE, uw God, ten erve zal geven, om hetzelve erfelijk te bezitten; [^4] Indien gij slechts de stem des HEEREN, uws Gods, vlijtiglijk zult gehoorzamen, dat gij waarneemt te doen al deze geboden, die ik u heden gebiede. [^5] Want de HEERE, uw God, zal u zegenen, gelijk als Hij tot u heeft gesproken, zo zult gij aan vele volken lenen; maar gij zult niet ontlenen; en gij zult over vele volken heersen; maar over u zullen zij niet heersen. [^6] Wanneer er onder u een arme zal zijn, een uit uw broederen, in een uwer poorten, in uw land, dat de HEERE, uw God, u geven zal, zo zult gij uw hart niet verstijven, noch uw hand toesluiten voor uw broeder, die arm is; [^7] Maar gij zult hem uw hand mildelijk opendoen, en zult hem rijkelijk lenen, genoeg voor zijn gebrek, dat hem ontbreekt. [^8] Wacht u, dat in uw hart geen Belialswoord zij, om te zeggen: Het zevende jaar, het jaar der vrijlating, naakt; dat uw oog boos zij tegen uw broeder, die arm is, en dat gij hem niet gevet; en hij over u roepe tot den HEERE, en zonde in u zij. [^9] Gij zult hem mildelijk geven, en uw hart zal niet boos zijn, als gij hem geeft; want om dezer zake wil zal u de HEERE, uw God, zegenen in al uw werk, en in alles, waaraan gij uw hand slaat. [^10] Want de arme zal niet ophouden uit het midden des lands; daarom gebiede ik u, zeggende: Gij zult uw hand mildelijk opendoen aan uw broeder, aan uw bedrukte en aan uw arme in uw land. [^11] Wanneer uw broeder, een Hebreër of een Hebreïnne, aan u verkocht zal zijn, zo zal hij u zes jaren dienen; maar in het zevende jaar zult gij hem vrij van u laten gaan. [^12] En als gij hem vrij van u gaan laat, zo zult gij hem niet ledig laten gaan: [^13] Gij zult hem rijkelijk opleggen van uw kudde, en van uw dorsvloer, en van uw wijnpers; waarin u de HEERE, uw God, gezegend heeft, daarvan zult gij hem geven. [^14] En gij zult gedenken, dat gij een dienstknecht in Egypteland geweest zijt, en dat u de HEERE, uw God, verlost heeft; daarom gebiede ik u heden deze zake. [^15] Maar het zal geschieden, als hij tot u zeggen zal: Ik zal niet van u uitgaan, omdat hij u en uw huis liefheeft, dewijl het hem wel bij u is; [^16] Zo zult gij een priem nemen, en steken in zijn oor en in de deur, en hij zal eeuwiglijk uw dienstknecht zijn; en aan uw dienstmaagd zult gij ook alzo doen. [^17] Het zal niet hard zijn in uw ogen, als gij hem vrij van u gaan laat; want als een dubbel-loons-dagloner heeft hij u zes jaren gediend; zo zal u de HEERE, uw God, zegenen in alles, wat gij doen zult. [^18] Al het eerstgeborene, dat onder uw runderen en onder uw schapen zal geboren worden, zijnde een manneken, zult gij den HEERE, uw God, heiligen; gij zult niet arbeiden met den eerstgeborene van uw os, noch de eerstgeborene uwer schapen scheren. [^19] Voor het aangezicht des HEEREN, uws Gods, zult gij ze jaar op jaar eten in de plaats, die de HEERE zal verkiezen, gij en uw huis. [^20] Doch als enig gebrek daaraan zal zijn, hetzij mank of blind, of enig kwaad gebrek, zo zult gij het den HEERE, uw God, niet offeren; [^21] In uw poorten zult gij het eten; de onreine en de reine te zamen, als een ree, en als een hert, [^22] Zijn bloed alleen zult gij niet eten; gij zult het op de aarde uitgieten als water. [^23] 

[[Deuteronomium - 14|<--]] Deuteronomium - 15 [[Deuteronomium - 16|-->]]

---
# Notes
