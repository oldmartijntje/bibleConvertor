---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomium"
  - "#bible/testament/old"
aliases:
  - "Deuteronomium - 26 - Statenvertaling (1750)"
---
[[Deuteronomium - 25|<--]] Deuteronomium - 26 [[Deuteronomium - 27|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Deuteronomium]]

# Deuteronomium - 26

Voorts zal het geschieden, wanneer gij zult gekomen zijn in het land, dat u de HEERE, uw God, ten erve geven zal, en gij dat erfelijk zult bezitten, en daarin wonen; [^1] Zo zult gij nemen van de eerstelingen van alle vrucht des lands, die gij opbrengen zult van uw land, dat u de HEERE, uw God, geeft, en zult ze in een korf leggen; en gij zult heengaan tot de plaats, die de HEERE, uw God, verkoren zal hebben, om Zijn Naam aldaar te doen wonen; [^2] En gij zult komen tot den priester, dewelke in die dagen zijn zal, en tot hem zeggen: Ik verklaar heden voor den HEERE, uw God, dat ik gekomen ben in het land, hetwelk de HEERE onzen vaderen gezworen heeft ons te zullen geven. [^3] En de priester zal den korf van uw hand nemen, en hij zal dien voor het altaar des HEEREN, uws Gods, nederzetten. [^4] Dan zult gij voor het aangezicht des HEEREN, uws Gods, betuigen en zeggen: Mijn vader was een bedorven Syriër, en hij toog af naar Egypte, en verkeerde aldaar als vreemdeling met weinig volks; maar hij werd aldaar tot een groot, machtig en menigvuldig volk. [^5] Doch de Egyptenaars deden ons kwaad, en verdrukten ons, en legden ons een harden dienst op. [^6] Toen riepen wij tot den HEERE, den God onzer vaderen; en de HEERE verhoorde onze stem en zag onze ellende aan, en onzen arbeid, en onze onderdrukking. [^7] En de HEERE voerde ons uit Egypte, door een sterke hand, en door een uitgestrekten arm, en door groten schrik, en door tekenen, en door wonderen. [^8] En Hij heeft ons gebracht tot deze plaats; en Hij heeft ons dit land gegeven, een land vloeiende van melk en honig. [^9] En nu, zie, ik heb gebracht de eerstelingen van de vrucht dezes lands, dat Gij, HEERE, mij gegeven hebt! Dan zult gij ze nederzetten voor het aangezicht des HEEREN, uws Gods, en zult u buigen voor het aangezicht des HEEREN, uws Gods; [^10] En gij zult vrolijk zijn over al het goede, dat de HEERE, uw God, aan u en uw huis gegeven heeft; gij, en de Leviet, en de vreemdeling, die in het midden van u is. [^11] Wanneer gij zult geëindigd hebben alle tienden van uw inkomen te vertienen, in het derde jaar, zijnde een jaar der tienden; dan zult gij aan den Leviet, aan den vreemdeling, aan den wees en aan de weduwe geven, dat zij in uw poorten eten en verzadigd worden. [^12] En gij zult voor het aangezicht des HEEREN, uws Gods, zeggen: Ik heb het heilige uit het huis weggenomen, en heb het ook aan den Leviet en aan den vreemdeling, aan den wees en aan de weduwe gegeven, naar al Uw geboden, die Gij mij geboden hebt; ik heb niets van Uw geboden overtreden, en niets vergeten. [^13] Ik heb daarvan niets gegeten in mijn leed, en heb daarvan niets weggenomen tot iets onreins, noch daarvan gegeven tot een dode; ik ben der stem des HEEREN, mijns Gods, gehoorzaam geweest, ik heb gedaan naar alles, wat Gij mij geboden hebt. [^14] Zie nederwaarts van Uw heilige woning, van den hemel, en zegen Uw volk Israël, en het land, dat Gij ons gegeven hebt, gelijk als Gij onzen vaderen gezworen hebt, een land van melk en honig vloeiende. [^15] Te dezen dage gebiedt u de HEERE, uw God, deze inzettingen en rechten te doen; houdt dan en doet dezelve, met uw ganse hart en met uw ganse ziel. [^16] Heden hebt gij den HEERE doen zeggen, dat Hij u tot een God zal zijn, en dat gij zult wandelen in Zijn wegen, en houden Zijn inzettingen, en Zijn geboden, en Zijn rechten, en dat gij Zijner stem zult gehoorzaam zijn. [^17] En de HEERE heeft u heden doen zeggen, dat gij Hem tot een volk des eigendoms zult zijn, gelijk als Hij u gesproken heeft, en dat gij al Zijn geboden zult houden; [^18] Opdat Hij u alzo boven al de volken, die Hij gemaakt heeft, hoog zette, tot lof, en tot een naam, en tot heerlijkheid; en opdat gij een heilig volk zijt den HEERE, uw God, gelijk als Hij gesproken heeft. [^19] 

[[Deuteronomium - 25|<--]] Deuteronomium - 26 [[Deuteronomium - 27|-->]]

---
# Notes
