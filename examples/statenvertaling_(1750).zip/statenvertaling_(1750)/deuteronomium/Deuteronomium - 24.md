---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomium"
  - "#bible/testament/old"
aliases:
  - "Deuteronomium - 24 - Statenvertaling (1750)"
---
[[Deuteronomium - 23|<--]] Deuteronomium - 24 [[Deuteronomium - 25|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Deuteronomium]]

# Deuteronomium - 24

Wanneer een man een vrouw zal genomen en die getrouwd hebben, zo zal het geschieden, indien zij geen genade zal vinden in zijn ogen, omdat hij iets schandelijks aan haar gevonden heeft, dat hij haar een scheidbrief zal schrijven, en in haar hand geven, en ze laten gaan uit zijn huis. [^1] Zo zij dan, uit zijn huis uitgegaan zijnde, zal henengaan en een anderen man ter vrouwe worden, [^2] En deze laatste man haar gehaat, en haar een scheidbrief geschreven, en in haar hand gegeven, en haar uit zijn huis zal hebben laten gaan; of als deze laatste man, die ze voor zich tot een vrouw genomen heeft, zal gestorven zijn; [^3] Zo zal haar eerste man, die haar heeft laten gaan, haar niet mogen wedernemen, dat zij hem ter vrouwe zij, nadat zij is verontreinigd geworden; want dat is een gruwel voor het aangezicht des HEEREN; alzo zult gij het land niet doen zondigen, dat u de HEERE, uw God, ten erve geeft. [^4] Wanneer een man een nieuwe vrouw zal genomen hebben, die zal in het heir niet uittrekken, en men zal hem geen last opleggen; een jaar lang zal hij vrij zijn in zijn huis, en zijn vrouw, die hij genomen heeft, verheugen. [^5] Men zal beide molenstenen, immers den bovensten molensteen, niet te pand nemen; want hij neemt de ziel te pand. [^6] Wanneer iemand gevonden zal worden, die een ziel steelt uit zijn broederen, uit de kinderen Israëls, en drijft gewin met hem, en verkoopt hem; zo zal deze dief sterven, en gij zult het boze uit het midden van u wegdoen. [^7] Wacht u in de plaag der melaatsheid, dat gij naarstiglijk waarneemt en doet naar alles, wat de Levietische priesteren ulieden zullen leren; gelijk als ik hun geboden heb, zult gij waarnemen te doen. [^8] Gedenkt, wat de HEERE, uw God, gedaan heeft aan Mirjam, op den weg, als gij uit Egypte waart uitgetogen. [^9] Wanneer gij aan uw naaste iets zult geleend hebben, zo zult gij tot zijn huis niet ingaan, om zijn pand te pand te nemen; [^10] Buiten zult gij staan, en de man, dien gij geleend hebt, zal het pand naar buiten tot u uitbrengen. [^11] Doch indien hij een arm man is, zo zult gij met zijn pand niet nederliggen. [^12] Gij zult hem dat pand zekerlijk wedergeven, als de zon ondergaat, dat hij in zijn kleed nederligge, en u zegene; en het zal u gerechtigheid zijn voor het aangezicht des HEEREN, uws Gods. [^13] Gij zult den armen en nooddruftigen dagloner niet verdrukken, die uit uw broederen is, of uit uw vreemdelingen, die in uw land en in uw poorten zijn. [^14] Op zijn dag zult gij zijn loon geven, en de zon zal daarover niet ondergaan; want hij is arm, en zijn ziel verlangt daarnaar; dat hij tegen u niet roepe tot den HEERE, en zonde in u zij. [^15] De vaders zullen niet gedood worden voor de kinderen, en de kinderen zullen niet gedood worden voor de vaders; een ieder zal om zijn zonde gedood worden. [^16] Gij zult het recht van den vreemdeling en van den wees niet buigen, en gij zult het kleed der weduwe niet te pand nemen. [^17] Maar gij zult gedenken, dat gij een knecht in Egypte geweest zijt, en de HEERE, uw God, heeft u van daar verlost; daarom gebiede ik u deze zaak te doen. [^18] Wanneer gij uw oogst op uw akker afgeoogst, en een garf op den akker vergeten zult hebben, zo zult gij niet wederkeren, om die op te nemen; voor den vreemdeling, voor den wees en voor de weduwe zal zij zijn; opdat u de HEERE, uw God, zegene, in al het werk uwer handen. [^19] Wanneer gij uw olijfboom zult geschud hebben, zo zult gij de takken achter u niet nauw doorzoeken; voor den vreemdeling, voor den wees en voor de weduwe zal het zijn. [^20] Wanneer gij uw wijngaard zult afgelezen hebben, zo zult gij de druiven achter u niet nalezen; voor den vreemdeling, voor den wees en voor de weduwe zal het zijn. [^21] En gij zult gedenken, dat gij een knecht in Egypteland geweest zijt; daarom gebiede ik u deze zaak te doen. [^22] 

[[Deuteronomium - 23|<--]] Deuteronomium - 24 [[Deuteronomium - 25|-->]]

---
# Notes
