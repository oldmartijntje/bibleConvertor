---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomium"
  - "#bible/testament/old"
aliases:
  - "Deuteronomium - 34 - Statenvertaling (1750)"
---
[[Deuteronomium - 33|<--]] Deuteronomium - 34

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Deuteronomium]]

# Deuteronomium - 34

Toen ging Mozes op, uit de vlakke velden van Moab, naar den berg Nebo, op de hoogten van Pisga, welke recht tegenover Jericho is; en de HEERE wees hem dat ganse land, Gilead tot Dan toe; [^1] En het ganse Nafthali, en het land van Efraïm en Manasse, en het ganse land van Juda, tot aan de achterste zee; [^2] En het Zuiden, en het effen veld der vallei van Jericho, de palmstad, tot Zoar toe. [^3] En de HEERE zeide tot hem: Dit is het land, dat Ik Abraham, Izak en Jakob gezworen heb, zeggende: Aan uw zaad zal Ik het geven! Ik heb het u met uw ogen doen zien, maar gij zult daarheen niet overgaan. [^4] Alzo stierf Mozes, de knecht des HEEREN, aldaar in het land van Moab, naar des HEEREN mond. [^5] En Hij begroef hem in een dal, in het land van Moab, tegenover Beth-Peor; en niemand heeft zijn graf geweten, tot op dezen dag. [^6] Mozes nu was honderd en twintig jaren oud, als hij stierf; zijn oog was niet donker geworden, en zijn kracht was niet vergaan. [^7] En de kinderen Israëls beweenden Mozes, in de vlakke velden van Moab, dertig dagen; en de dagen des wenens, van den rouw over Mozes, werden voleindigd. [^8] Jozua nu, de zoon van Nun, was vol van de Geest der wijsheid; want Mozes had zijn handen op hem gelegd; zo hoorden de kinderen Israëls naar hem, en deden gelijk als de HEERE Mozes geboden had. [^9] En er stond geen profeet meer op in Israël, gelijk Mozes, dien de HEERE gekend had, van aangezicht tot aangezicht, [^10] In al de tekenen en de wonderen, waartoe hem de HEERE gezonden heeft, om die in Egypteland te doen aan Farao, en aan al zijn knechten, en aan al zijn land; [^11] En in al die sterke hand, en in al die grote verschrikking, die Mozes gedaan heeft voor de ogen van gans Israël. [^12] 

[[Deuteronomium - 33|<--]] Deuteronomium - 34

---
# Notes
