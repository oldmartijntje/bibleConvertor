---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 6 - Statenvertaling (1750)"
---
[[Esther - 5|<--]] Esther - 6 [[Esther - 7|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Esther]]

# Esther - 6

In denzelfden nacht was de slaap van den koning geweken, en hij zeide, dat men het boek der gedachtenissen, de kronieken, brengen zou; en zij werden in de tegenwoordigheid des konings gelezen. [^1] En men vond geschreven, dat Mordechai had te kennen gegeven van Bigthana en Theres, twee kamerlingen des konings, uit de dorpelwachters, die de hand zochten te leggen aan den koning Ahasveros. [^2] Toen zeide de koning: Wat eer en verhoging is Mordechai hierover gedaan? En de jongelingen des konings, zijn dienaars, zeiden: Aan hem is niets gedaan. [^3] Toen zeide de koning: Wie is in het voorhof? (Haman nu was gekomen in het buitenvoorhof van het huis des konings, om den koning te zeggen, dat men Mordechai zou hangen aan de galg, die hij hem had doen bereiden.) [^4] En des konings jongelingen zeiden tot hem: Zie, Haman staat in het voorhof. Toen zeide de koning: Dat hij inkome. [^5] Als Haman ingekomen was, zo zeide de koning tot hem: Wat zal men met dien man doen, tot wiens eer de koning een welbehagen heeft? Toen zeide Haman in zijn hart: Tot wien heeft de koning een welbehagen, om hem eer te doen, meer dan tot mij? [^6] Daarom zeide Haman tot den koning: Den man, tot wiens eer de koning een welbehagen heeft, [^7] Zal men het koninklijke kleed brengen, dat de koning pleegt aan te trekken, en het paard, waarop de koning pleegt te rijden; en dat de koninklijke kroon op zijn hoofd gezet worde. [^8] En men zal dat kleed en dat paard geven in de hand van een uit de vorsten des konings, van de grootste heren, en men zal het dien man aantrekken, tot wiens eer de koning een welbehagen heeft; en men zal hem op dat paard doen rijden door de straten der stad, en men zal voor hem roepen: Alzo zal men dien man doen, tot wiens eer de koning een welbehagen heeft! [^9] Toen zeide de koning tot Haman: Haast u, neem dat kleed, en dat paard, gelijk als gij gesproken hebt, en doe alzo aan Mordechai, den Jood, die aan de poort des konings zit; en laat niet een woord vallen van alles, wat gij gesproken hebt. [^10] En Haman nam dat kleed en dat paard, en trok het kleed Mordechai aan, en deed hem rijden door de straten der stad, en hij riep voor hem: Alzo zal men dien man doen, tot wiens eer de koning een welbehagen heeft! [^11] Daarna keerde Mordechai wederom tot de poort des konings; maar Haman werd voortgedreven naar zijn huis, treurig en met bedekten hoofde. [^12] En Haman vertelde aan zijn huisvrouw Zeres en al zijn vrienden al wat hem wedervaren was. Toen zeiden hem zijn wijzen, en Zeres, zijn huisvrouw: Indien Mordechai, voor wiens aangezicht gij hebt begonnen te vallen, van het zaad der Joden is, zo zult gij tegen hem niet vermogen; maar gij zult gewisselijk voor zijn aangezicht vallen. [^13] Toen zij nog met hem spraken, zo kwamen des konings kamerlingen nabij, en zij haastten Haman tot den maaltijd te brengen, dien Esther bereid had. [^14] 

[[Esther - 5|<--]] Esther - 6 [[Esther - 7|-->]]

---
# Notes
