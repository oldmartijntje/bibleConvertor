---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 4 - Statenvertaling (1750)"
---
[[Esther - 3|<--]] Esther - 4 [[Esther - 5|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Esther]]

# Esther - 4

Als Mordechai wist al wat er geschied was, zo verscheurde Mordechai zijn klederen, en hij trok een zak aan met as; en hij ging uit door het midden der stad, en hij riep met een groot en bitter geroep. [^1] En hij kwam tot voor de poort des konings; want niemand mocht in des konings poort inkomen, bekleed met een zak. [^2] En in alle en een ieder landschap en plaats, waar het woord des konings en zijn wet aankwam, was een grote rouw onder de Joden, met vasten, en geween, en misbaar; vele lagen in zakken en as. [^3] Toen kwamen Esthers jonge dochters en haar kamerlingen, en zij gaven het haar te kennen; en het deed de koningin zeer wee; en zij zond klederen om Mordechai aan te doen, en zijn zak van hem af te doen; maar hij nam ze niet aan. [^4] Toen riep Esther Hatach, een van de kamerlingen des konings, welke hij voor haar gesteld had, en zij gaf hem bevel aan Mordechai, om te weten wat dit, en waarom dit ware. [^5] Als Hatach uitging tot Mordechai, op de straat der stad, die voor de poort des konings was, [^6] Zo gaf Mordechai hem te kennen al wat hem wedervaren was, en de verklaring van het zilver, hetwelk Haman gezegd had te zullen wegen in de schatten des konings, voor de Joden, om dezelve om te brengen. [^7] En hij gaf hem het afschrift der geschrevene wet, die te Susan gegeven was, om hen te verdelgen, dat hij het Esther liet zien, en haar te kennen gaf, en haar gebood, dat zij tot den koning ging, om hem te smeken, en van hem te verzoeken voor haar volk. [^8] Hatach nu kwam, en gaf Esther de woorden van Mordechai te kennen. [^9] Toen zeide Esther tot Hatach, en gaf hem bevel aan Mordechai: [^10] Alle knechten des konings, en het volk, der landschappen des konings, weten wel dat al wie tot den koning ingaat, in het binnenste voorhof, die niet geroepen is, hij zij man of vrouw, zijn enig vonnis zij, dat men hem dode, tenzij dat de koning den gouden scepter hem toereike, opdat hij levend blijve; ik nu ben deze dertig dagen niet geroepen om tot den koning in te komen. [^11] En zij gaven de woorden van Esther aan Mordechai te kennen. [^12] Zo zeide Mordechai, dat men Esther wederom zeggen zou: Beeld u niet in, in uw ziel, dat gij zult ontkomen in het huis des konings, meer dan al de andere Joden. [^13] Want indien gij enigszins zwijgen zult te dezer tijd, zo zal den Joden verkwikking en verlossing uit een andere plaats ontstaan; maar gij en uws vaders huis zult omkomen; en wie weet, of gij niet om zulken tijd als deze is, tot dit koninkrijk geraakt zijt. [^14] Toen zeide Esther, dat men Mordechai weder aanzeggen zou: [^15] Ga, vergader al de Joden, die te Susan gevonden worden, en vast voor mij, en eet of drinkt niet, in drie dagen, nacht noch dag; ik en mijn jonge dochters zullen ook alzo vasten, en alzo zal ik tot den koning ingaan, hetwelk niet naar de wet is. Wanneer ik dan omkome, zo kom ik om. [^16] Toen ging Mordechai henen, en hij deed naar alles, wat Esther aan hem geboden had. [^17] 

[[Esther - 3|<--]] Esther - 4 [[Esther - 5|-->]]

---
# Notes
