---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 5 - Statenvertaling (1750)"
---
[[Esther - 4|<--]] Esther - 5 [[Esther - 6|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Esther]]

# Esther - 5

Het geschiedde nu aan den derden dag, dat Esther een koninklijk kleed aantrok, en stond in het binnenste voorhof van des konings huis, tegenover het huis des konings; de koning nu zat op zijn koninklijken troon, in het koninklijke huis, tegenover de deur van het huis. [^1] En het geschiedde, toen de koning de koningin Esther zag, staande in het voorhof, verkreeg zij genade in zijn ogen, zodat de koning den gouden scepter, die in zijn hand was, Esther toereikte; en Esther naderde, en roerde de spits des scepters aan. [^2] Toen zeide de koning tot haar: Wat is u, koningin Esther! of wat is uw verzoek? Het zal u gegeven worden, ook tot de helft des koninkrijks. [^3] Esther nu zeide: Indien het den koning goeddunkt, zo kome de koning met Haman heden tot den maaltijd, dien ik hem bereid heb. [^4] Toen zeide de koning: Doet Haman spoeden, dat hij het bevel van Esther doe. Als nu de koning met Haman tot den maaltijd, dien Esther bereid had, gekomen was, [^5] Zo zeide de koning tot Esther op den maaltijd des wijns: Wat is uw bede? en zij zal u gegeven worden; en wat is uw verzoek? Het zal geschieden, ook tot de helft des koninkrijks. [^6] Toen antwoordde Esther, en zeide: Mijn bede en verzoek is: [^7] Indien ik genade gevonden heb in de ogen des konings, en indien het den koning goeddunkt, mij te geven mijn bede, en mijn verzoek te doen, zo kome de koning met Haman tot den maaltijd, dien ik hem bereiden zal; zo zal ik morgen doen naar het bevel des konings. [^8] Toen ging Haman ten zelfden dage uit, vrolijk en goedsmoeds; maar toen Haman Mordechai zag in de poort des konings, en dat hij niet opstond, noch zich voor hem bewoog, zo werd Haman vervuld met grimmigheid op Mordechai. [^9] Doch Haman bedwong zich, en hij kwam tot zijn huis; en hij zond henen, en liet zijn vrienden komen, en Zeres, zijn huisvrouw. [^10] En Haman vertelde hun de heerlijkheid zijns rijkdoms, en de veelheid zijner zonen, en alles, waarin de koning hem groot gemaakt had, en waarin hij hem verheven had boven de vorsten en knechten des konings. [^11] Verder zeide Haman: Ook heeft de koningin Esther niemand met den koning doen komen tot den maaltijd, dien zij bereid heeft, dan mij; en ik ben ook tegen morgen van haar met den koning genodigd. [^12] Doch dit alles baat mij niet, zo langen tijd als ik den Jood Mordechai zie zitten in de poort des konings. [^13] Toen zeide zijn huisvrouw Zeres tot hem, mitsgaders al zijn vrienden: Men make een galg, vijftig ellen hoog, en zeg morgen aan den koning, dat men Mordechai daaraan hange; ga dan vrolijk met den koning tot dien maaltijd. Deze raad nu dacht Haman goed, en hij deed de galg maken. [^14] 

[[Esther - 4|<--]] Esther - 5 [[Esther - 6|-->]]

---
# Notes
