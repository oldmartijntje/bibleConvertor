---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 7 - Statenvertaling (1750)"
---
[[Esther - 6|<--]] Esther - 7 [[Esther - 8|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Esther]]

# Esther - 7

Toen de koning met Haman gekomen was, om te drinken met de koningin Esther; [^1] Zo zeide de koning tot Esther, ook op den tweeden dag, op den maaltijd des wijns: Wat is uw bede, koningin Esther! en zij zal u gegeven worden; en wat is uw verzoek? Het zal geschieden, ook tot de helft des koninkrijks. [^2] Toen antwoordde de koningin Esther, en zeide: Indien ik, o koning, genade in uw ogen gevonden heb, en indien het den koning goeddunkt, men geve mij mijn leven, om mijner bede wil, en mijn volk, om mijns verzoeks wil. [^3] Want wij zijn verkocht, ik en mijn volk, dat men ons verdelge, dode en ombrenge. Indien wij nog tot knechten en tot dienstmaagden waren verkocht geweest, ik zou gezwegen hebben, ofschoon de onderdrukker de schade des konings geenszins zou kunnen vergoeden. [^4] Toen sprak de koning Ahasveros, en zeide tot de koningin Esther: Wie is die, en waar is diezelve, die zijn hart vervuld heeft, om alzo te doen? [^5] En Esther zeide: De man, de onderdrukker en vijand, is deze boze Haman! Toen verschrikte Haman voor het aangezicht des konings en der koningin. [^6] En de koning stond op in zijn grimmigheid van den maaltijd des wijns, en ging naar den hof van het paleis. En Haman bleef staan, om van de koningin Esther, aangaande zijn leven verzoek te doen; want hij zag, dat het kwaad van de koning over hem ten volle besloten was. [^7] Toen de koning wederkwam uit den hof van het paleis in het huis van den maaltijd des wijns, zo was Haman gevallen op het bed, waarop Esther was. Toen zeide de koning: Zou hij ook wel de koningin verkrachten bij mij in het huis? Het woord ging uit des konings mond, en zij bedekten Hamans aangezicht. [^8] En Charbona, een van de kamerlingen, voor het aanschijn des konings staande, zeide: Ook zie, de galg, welke Haman gemaakt heeft voor Mordechai, die goed voor den koning gesproken heeft, staat bij Hamans huis, vijftig ellen hoog. Toen zeide de koning: Hang hem daaraan. [^9] Alzo hingen zij Haman aan de galg, die hij voor Mordechai had doen bereiden; en de grimmigheid des konings werd gestild. [^10] 

[[Esther - 6|<--]] Esther - 7 [[Esther - 8|-->]]

---
# Notes
