---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 10 - Statenvertaling (1750)"
---
[[Esther - 9|<--]] Esther - 10

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Esther]]

# Esther - 10

Daarna legde de koning Ahasveros schatting op het land, en de eilanden der zee. [^1] Al de werken nu zijner macht en zijns gewelds, en de verklaring der grootheid van Mordechai, denwelken de koning groot gemaakt heeft, zijn die niet geschreven in het boek der kronieken der koningen van Medië en Perzië? [^2] Want de Jood Mordechai was de tweede bij den koning Ahasveros, en groot bij de Joden, en aangenaam bij de menigte zijner broederen, zoekende het beste voor zijn volk, en sprekende voor den welstand van zijn ganse zaad. [^3] 

[[Esther - 9|<--]] Esther - 10

---
# Notes
