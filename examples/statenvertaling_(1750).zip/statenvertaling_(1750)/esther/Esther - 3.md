---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 3 - Statenvertaling (1750)"
---
[[Esther - 2|<--]] Esther - 3 [[Esther - 4|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Esther]]

# Esther - 3

Na deze geschiedenissen maakte de koning Ahasveros Haman groot, den zoon van Hammedatha, den Agagiet, en hij verhoogde hem, en hij zette zijn stoel boven al de vorsten, die bij hem waren. [^1] En al de knechten des konings, die in de poort des konings waren, neigden en bogen zich neder voor Haman; want de koning had alzo van hem bevolen; maar Mordechai neigde zich niet, en boog zich niet neder. [^2] Toen zeiden de knechten des konings, die in de poort des konings waren, tot Mordechai: Waarom overtreedt gij des konings gebod? [^3] Het geschiedde nu, toen zij dit van dag tot dag tot hem zeiden, en hij naar hen niet hoorde, zo gaven zij het Haman te kennen, opdat zij zagen, of de woorden van Mordechai bestaan zouden; want hij had hun te kennen gegeven, dat hij een Jood was. [^4] Toen Haman zag, dat Mordechai zich niet neigde, noch zich voor hem nederboog, zo werd Haman vervuld met grimmigheid. [^5] Doch hij verachtte in zijn ogen, dat hij aan Mordechai alleen de hand zou slaan (want men had hem het volk van Mordechai aangewezen); maar Haman zocht al de Joden, die in het ganse koninkrijk van Ahasveros waren, namelijk het volk van Mordechai, te verdelgen. [^6] In de eerste maand (deze is de maand Nisan) in het twaalfde jaar van den koning Ahasveros, wierp men het Pur, dat is, het lot, voor Hamans aangezicht, van dag tot dag, en van maand tot maand, tot de twaalfde maand toe; deze is de maand Adar. [^7] Want Haman had tot den koning Ahasveros gezegd: Er is één volk, verstrooid en verdeeld onder de volken in al de landschappen uws koninkrijks; en hun wetten zijn verscheiden van de wetten aller volken; ook doen zij des konings wetten niet; daarom is het den koning niet oorbaar hen te laten blijven. [^8] Indien het den koning goeddunkt, laat er geschreven worden, dat men hen verdoe; zo zal ik tien duizend talenten zilvers opwegen in de handen dergenen, die het werk doen, om in des konings schatten te brengen. [^9] Toen trok de koning zijn ring van zijn hand, en hij gaf hem aan Haman, den zoon van Hammedatha, den Agagiet, der Joden tegenpartijder. [^10] En de koning zeide tot Haman: Dat zilver zij u geschonken, ook dat volk, om daarmede te doen, naar dat het goed is in uw ogen. [^11] Toen werden de schrijvers des konings geroepen, in de eerste maand, op den dertienden dag derzelve, en er werd geschreven naar alles, wat Haman beval, aan de stadhouders des konings, en aan de landvoogden, die over elk landschap waren, en aan de vorsten van elk volk, elk landschap naar zijn schrift, en elk volk naar zijn spraak; er werd geschreven in den naam van den koning Ahasveros, en het werd met des konings ring verzegeld. [^12] De brieven nu werden gezonden door de hand der lopers tot al de landschappen des konings, dat men zou verdelgen, doden en verdoen al de Joden, van den jonge tot den oude toe, de kleine kinderen en de vrouwen, op één dag, op den dertienden der twaalfde maand (deze is de maand Adar), en dat men hun buit zou roven. [^13] De inhoud van het schrift was, dat er een wet zou gegeven worden in alle landschappen, openbaar aan alle volken, dat zij tegen denzelfden dag zouden gereed zijn. [^14] De lopers gingen uit, voortgedrongen zijnde door het woord des konings, en de wet werd uitgegeven in den burg Susan. En de koning en Haman zaten en dronken, doch de stad Susan was verward. [^15] 

[[Esther - 2|<--]] Esther - 3 [[Esther - 4|-->]]

---
# Notes
