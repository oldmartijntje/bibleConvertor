---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 8 - Statenvertaling (1750)"
---
[[Esther - 7|<--]] Esther - 8 [[Esther - 9|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Esther]]

# Esther - 8

Te dienzelfden dage gaf de koning Ahasveros aan de koningin Esther het huis van Haman, den vijand der Joden; en Mordechai kwam voor het aangezicht des konings, want Esther had te kennen gegeven, wat hij voor haar was. [^1] En de koning toog zijn ring af, dien hij van Haman genomen had, en gaf hem aan Mordechai; en Esther stelde Mordechai over het huis van Haman. [^2] En Esther sprak verder voor het aangezicht des konings, en zij viel voor zijn voeten, en zij weende, en zij smeekte hem, dat hij de boosheid van Haman, den Agagiet, en zijn gedachte, die hij tegen de Joden gedacht had, zou wegnemen. [^3] De koning nu reikte den gouden scepter Esther toe. Toen rees Esther op, en zij stond voor het aangezicht des konings. [^4] En zij zeide: Indien het den koning goeddunkt, en indien ik genade voor zijn aangezicht gevonden heb en deze zaak voor den koning recht is, en ik in zijn ogen aangenaam ben, dat er geschreven worde, dat de brieven en de gedachte van Haman, den zoon van Hammedatha, den Agagiet, wederroepen worden, welke hij geschreven heeft, om de Joden om te brengen, die in al de landschappen des konings zijn. [^5] Want hoe zal ik vermogen, dat ik aanzie het kwaad, dat mijn volk treffen zal? En hoe zal ik vermogen, dat ik aanzie het verderf van mijn geslacht? [^6] Toen zeide de koning Ahasveros tot de koningin Esther en tot Mordechai, den Jood: Ziet, het huis van Haman heb ik Esther gegeven, en hem heeft men aan de galg gehangen, omdat hij zijn hand aan de Joden geslagen had. [^7] Schrijft dan gijlieden voor de Joden, zoals het goed is in uw ogen, in des konings naam, en verzegelt het met des konings ring; want het schrift, dat in des konings naam geschreven, en met des konings ring verzegeld is, is niet te wederroepen. [^8] Toen werden des konings schrijvers geroepen, ter zelfder tijd, in de derde maand (zij is de maand Sivan), op den drie en twintigsten derzelve, en er werd geschreven naar alles, wat Mordechai gebood, aan de Joden, en aan de stadhouders, en landvoogden, en oversten der landschappen, die van Indië af tot aan Morenland strekken, honderd zeven en twintig landschappen, een ieder landschap naar zijn schrift, een ieder volk naar zijn spraak; ook aan de Joden naar hun schrift en naar hun spraak. [^9] En men schreef in den naam van den koning Ahasveros, en men verzegelde het met des konings ring; en men zond de brieven door de hand der lopers te paard, rijdende op snelle kemelen, op muildieren, van merriën geteeld; [^10] Dat de koning den Joden toeliet, die in elke stad waren, zich te vergaderen, en voor hun leven te staan, om te verdelgen, om te doden en om om te brengen alle macht des volks en des landschaps, die hen benauwen zou, de kleine kinderen en de vrouwen, en hun buit te roven; [^11] Op één dag in al de landschappen van den koning Ahasveros, op den dertienden der twaalfde maand; deze is de maand Adar. [^12] De inhoud van dit schrift was: dat een wet zou gegeven worden in alle landschappen, openbaar aan alle volken; en dat de Joden gereed zouden zijn tegen dien dag, om zich te wreken aan hun vijanden. [^13] De lopers, die op snelle kemelen reden en op muildieren, togen snellijk uit, aangedreven zijnde door het woord des konings. Deze wet nu werd gegeven op den burg Susan. [^14] En Mordechai ging uit van voor het aangezicht des konings in een hemelsblauw en wit koninklijk kleed, en met een grote gouden kroon, en met een opperkleed van fijn linnen en purper; en de stad Susan juichte en was vrolijk. [^15] Bij de Joden was licht, en blijdschap, en vreugde, en eer; [^16] Ook in alle en een ieder landschap, en in alle en een iedere stad, ter plaatse, waar des konings woord en zijn wet aankwam, daar was bij de Joden blijdschap en vreugde, maaltijden en vrolijke dagen; en velen uit de volken des lands werden Joden, want de vreze der Joden was op hen gevallen. [^17] 

[[Esther - 7|<--]] Esther - 8 [[Esther - 9|-->]]

---
# Notes
