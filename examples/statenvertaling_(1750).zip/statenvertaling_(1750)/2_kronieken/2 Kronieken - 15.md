---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kronieken"
  - "#bible/testament/old"
aliases:
  - "2 Kronieken - 15 - Statenvertaling (1750)"
---
[[2 Kronieken - 14|<--]] 2 Kronieken - 15 [[2 Kronieken - 16|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[2 Kronieken]]

# 2 Kronieken - 15

Toen kwam de Geest Gods op Azaria, den zoon van Oded. [^1] En hij ging uit, Asa tegen, en hij zeide tot hem: Hoort mij, Asa, en gans Juda, en Benjamin! De HEERE is met ulieden, terwijl gij met Hem zijt; en zo gij Hem zoekt, Hij zal van u gevonden worden; maar zo gij Hem verlaat, Hij zal u verlaten. [^2] Israël nu is vele dagen geweest zonder den waren God, en zonder een lerenden priester, en zonder de wet. [^3] Maar als zij zich in hun nood bekeerden tot den HEERE, den God Israëls, en Hem zochten, zo werd Hij van hen gevonden. [^4] En in die tijden was er geen vrede voor dengene, die uitging, en dengene, die inkwam; maar vele beroerten waren over al de inwoners van die landen; [^5] Dat volk tegen volk, en stad tegen stad in stukken gestoten werden; want God had hen met allen angst verschrikt. [^6] Daarom weest gij sterk, en laat uw handen niet verslappen; want er is loon naar uw werk. [^7] Als nu Asa deze woorden hoorde, en de profetie van den profeet Oded, sterkte hij zich, en hij deed weg de verfoeiselen uit het ganse land van Juda en Benjamin, en uit de steden, die hij van het gebergte van Efraïm genomen had, en vernieuwde het altaar des HEEREN, dat voor het voorhuis des HEEREN was. [^8] En hij vergaderde het ganse Juda en Benjamin, en de vreemdelingen met hen uit Efraïm, en Manasse, en uit Simeon; want uit Israël vielen zij tot hem in menigte, als zij zagen, dat de HEERE, zijn God, met hem was. [^9] En zij vergaderden zich te Jeruzalem, in de derde maand, in het vijftiende jaar van het koninkrijk van Asa. [^10] En zij offerden den HEERE ten zelfden dage van den roof, dien zij gebracht hadden, zevenhonderd runderen en zeven duizend schapen. [^11] En zij traden in een verbond, dat zij den HEERE, den God hunner vaderen, zoeken zouden met hun ganse hart en met hun ganse ziel. [^12] En al wie den HEERE, den God Israëls, niet zou zoeken, zou gedood worden, van den kleine tot den grote, en van den man tot de vrouw toe. [^13] En zij zwoeren den HEERE met luider stem en met gejuich, desgelijks met trompetten en met bazuinen. [^14] En gans Juda was verblijd over dezen eed; want zij hadden met hun ganse hart gezworen, en met hun gansen wil Hem gezocht; en Hij werd van hen gevonden, en de HEERE gaf hun rust rondom henen. [^15] Aangaande ook Maächa, de moeder van den koning Asa, hij zette haar af, dat zij geen koningin ware, omdat zij een afgrijselijken afgod in een bos gemaakt had; ook roeide Asa haar afgrijselijken afgod uit, en verbrijzelde en verbrandde hem aan de beek Kidron. [^16] De hoogten werden wel niet weggenomen uit Israël, het hart van Asa nochtans was volkomen al zijn dagen. [^17] En hij bracht in het huis Gods de geheiligde dingen zijns vaders, en zijn geheiligde dingen, zilver en goud, en vaten. [^18] En er was geen oorlog tot in het vijf en dertigste jaar van het koninkrijk van Asa. [^19] 

[[2 Kronieken - 14|<--]] 2 Kronieken - 15 [[2 Kronieken - 16|-->]]

---
# Notes
