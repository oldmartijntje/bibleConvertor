---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kronieken"
  - "#bible/testament/old"
aliases:
  - "2 Kronieken - 22 - Statenvertaling (1750)"
---
[[2 Kronieken - 21|<--]] 2 Kronieken - 22 [[2 Kronieken - 23|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[2 Kronieken]]

# 2 Kronieken - 22

En de inwoners van Jeruzalem maakten Ahazia, zijn kleinsten zoon, koning in zijn plaats; want een bende, die met de Arabieren in het leger gekomen was, had al de eersten gedood. Ahazia dan, de zoon van Joram, de koning van Juda, regeerde. [^1] Twee en veertig jaar was Ahazia oud, toen hij koning werd, en hij regeerde een jaar te Jeruzalem; en de naam zijner moeder was Athalia, een dochter van Omri. [^2] Hij wandelde ook in de wegen van het huis van Achab; want zijn moeder was zijn raadgeefster, om goddelooslijk te handelen. [^3] En hij deed dat kwaad was in de ogen des HEEREN, gelijk het huis van Achab; want zij waren zijn raadgevers, na den dood zijns vaders, hem ten verderve. [^4] Hij wandelde ook in hun raad, en toog henen met Joram, den zoon van Achab, den koning van Israël, tot den strijd tegen Hazaël, den koning van Syrië, bij Ramoth in Gilead; en de Syriërs sloegen Joram. [^5] En hij keerde weder om zich te laten genezen te Jizreël; want hij had wonden, die men hem bij Rama geslagen had, als hij streed tegen Hazaël, den koning van Syrië; en Azarja, de zoon van Joram, den koning van Juda, kwam af, om Joram, den zoon van Achab, te Jizreël te bezien, want hij was krank. [^6] De vertreding nu van Ahazia was van God, dat hij tot Joram kwam; want als hij gekomen was, toog hij met Joram uit tot Jehu, den zoon van Nimsi, denwelken de HEERE gezalfd had, om het huis van Achab uit te roeien. [^7] Zo geschiedde het, als Jehu oordeel uitvoerde tegen het huis van Achab, dat hij de vorsten van Juda en de zonen der broederen van Ahazia, die Ahazia dienden, vond, en die doodde. [^8] Daarna zocht hij Ahazia, en zij kregen hem (want hij was verstoken in Samaria), en zij brachten hem tot Jehu, en zij doodden hem, en begroeven hem; want zij zeiden: Hij is de zoon van Josafat, die den HEERE met zijn ganse hart gezocht heeft. Zo had het huis van Ahazia niemand, die kracht behield tot het koninkrijk. [^9] Toen Athalia, de moeder van Ahazia, zag, dat haar zoon dood was, zo maakte zij zich op, en bracht al het koninklijke zaad van het huis van Juda om. [^10] Maar Jozabath, de dochter des konings, nam Joas, den zoon van Ahazia, en stal hem uit het midden van des konings zonen, die gedood werden, en zette hem en zijn voedster in een slaapkamer; zo verborg hem Jozabath, de dochter van den koning Joram, de huisvrouw van den priester Jojada (want zij was de zuster van Ahazia), voor Athalia, dat zij hem niet doodde. [^11] En hij was bij hen verstoken in het huis Gods zes jaren; en Athalia regeerde over het land. [^12] 

[[2 Kronieken - 21|<--]] 2 Kronieken - 22 [[2 Kronieken - 23|-->]]

---
# Notes
