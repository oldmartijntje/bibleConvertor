---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kronieken"
  - "#bible/testament/old"
aliases:
  - "2 Kronieken - 1 - Statenvertaling (1750)"
---
2 Kronieken - 1 [[2 Kronieken - 2|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[2 Kronieken]]

# 2 Kronieken - 1

En Salomo, de zoon van David, werd versterkt in zijn koninkrijk, want de HEERE, zijn God, was met hem, en maakte hem ten hoogste groot. [^1] En Salomo sprak tot het ganse Israël, tot de oversten der duizenden en der honderden, en tot de richteren, en tot alle oversten in gans Israël, de hoofden der vaderen; [^2] En zij gingen henen, Salomo en de ganse gemeente met hem, naar de hoogte, die te Gibeon was; want daar was de tent der samenkomst Gods, die Mozes, de knecht des HEEREN, in de woestijn gemaakt had. [^3] (Maar de ark Gods had David van Kirjath-Jearim opgebracht, ter plaatse, die David voor haar bereid had; want hij had voor haar een tent te Jeruzalem gespannen.) [^4] Ook was het koperen altaar, dat Bezáleël, de zoon van Uri, den zoon van Hur, gemaakt had, aldaar voor den tabernakel des HEEREN; Salomo nu en de gemeente bezochten hetzelve. [^5] En Salomo offerde daar, voor het aangezicht des HEEREN, op het koperen altaar, dat aan de tent der samenkomst was; en hij offerde daarop duizend brandofferen. [^6] In dienzelfden nacht verscheen God aan Salomo; en Hij zeide tot hem: Begeer, wat Ik u geven zal. [^7] En Salomo zeide tot God: Gij hebt aan mijn vader David grote weldadigheid gedaan; en Gij hebt mij koning gemaakt in zijn plaats; [^8] Nu, HEERE God, laat Uw woord waar worden, gedaan aan mijn vader David; want Gij hebt mij koning gemaakt over een volk, menigvuldig als het stof der aarde; [^9] Geef mij nu wijsheid en wetenschap, dat ik voor het aangezicht van dit volk uitga en inga; want wie zou dit Uw groot volk kunnen richten? [^10] Toen zeide God tot Salomo: Daarom, dat dit in uw hart geweest is, en gij niet begeerd hebt rijkdom, goederen, noch eer, noch de ziel uwer haters, noch ook vele dagen begeerd hebt; maar wijsheid en wetenschap voor u begeerd hebt, opdat gij Mijn volk mocht richten, waarover Ik u koning gemaakt heb; [^11] De wijsheid, en de wetenschap is u gegeven; daartoe zal Ik u rijkdom, en goederen, en eer geven, dergelijke geen koningen, die voor u geweest zijn, gehad hebben, en na u zal dergelijke niet zijn. [^12] Alzo kwam Salomo te Jeruzalem, van de hoogte, die te Gibeon is, van voor de tent der samenkomst; en hij regeerde over Israël. [^13] En Salomo vergaderde wagenen en ruiteren, zodat hij duizend en vierhonderd wagenen, en twaalf duizend ruiteren had; en hij legde ze in de wagensteden, en bij den koning te Jeruzalem. [^14] En de koning maakte het zilver en het goud in Jeruzalem te zijn als stenen, en de cederen maakte hij te zijn als wilde vijgebomen, die in de laagten zijn, in menigte. [^15] En het uitbrengen der paarden was hetgeen Salomo uit Egypte had; en aangaande het linnengaren, de kooplieden des konings namen het linnengaren voor den prijs. [^16] En zij brachten op, en voerden een wagen uit van Egypte voor zeshonderd sikkelen zilvers, en een paard voor eenhonderd en vijftig; en alzo voerden zij die door hun hand uit, voor alle koningen der Hethieten, en voor de koningen van Syrië. [^17] 

2 Kronieken - 1 [[2 Kronieken - 2|-->]]

---
# Notes
