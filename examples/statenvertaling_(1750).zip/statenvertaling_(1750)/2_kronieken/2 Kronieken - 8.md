---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kronieken"
  - "#bible/testament/old"
aliases:
  - "2 Kronieken - 8 - Statenvertaling (1750)"
---
[[2 Kronieken - 7|<--]] 2 Kronieken - 8 [[2 Kronieken - 9|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[2 Kronieken]]

# 2 Kronieken - 8

Het geschiedde nu ten einde van twintig jaren, in dewelke Salomo het huis des HEEREN en zijn huis gebouwd had, [^1] Dat Salomo de steden, welke Huram hem gegeven had, bouwde, en de kinderen Israëls aldaar deed wonen. [^2] Daarna toog Salomo naar Hamath-Zoba, en hij overweldigde het. [^3] Hij bouwde ook Thadmor in de woestijn, en al de schatsteden, die hij bouwde in Hamath. [^4] Ook bouwde hij het hoge Beth-Horon en het neder Beth-Horon, vaste steden met muren, deuren en grendelen; [^5] Mitsgaders Baälath, en al de schatsteden, die Salomo had, en alle wagensteden, en de steden der ruiteren, en wat de begeerte van Salomo begeerd had te bouwen, in Jeruzalem, en in den Libanon, en in het ganse land zijner heerschappij. [^6] Aangaande al het volk, dat overgebleven was van de Hethieten, en de Amorieten, en de Ferezieten, en de Hevieten, en de Jebusieten, die niet uit Israël waren; [^7] Uit hun kinderen, die na hen in het land overgebleven waren, welke de kinderen Israëls niet verdaan hadden, die bracht Salomo op uitschot tot op dezen dag. [^8] Doch uit de kinderen Israëls, die Salomo niet maakte tot slaven in zijn werk; (want zij waren krijgslieden, en oversten zijner hoofdlieden, en oversten zijner wagenen en zijner ruiteren); [^9] Uit dezen dan waren oversten der bestelden, die de koning Salomo had, tweehonderd en vijftig, die over het volk heerschappij hadden. [^10] Salomo nu deed de dochter van Farao opkomen uit de stad Davids, tot het huis, dat hij voor haar gebouwd had; want hij zeide: Mijn vrouw zal in het huis van David, den koning van Israël, niet wonen, omdat de plaatsen heilig zijn, tot dewelke de ark des HEEREN gekomen is. [^11] Toen offerde Salomo den HEERE brandofferen op het altaar des HEEREN, hetwelk hij voor het voorhuis gebouwd had; [^12] Zelfs naar den eis van elken dag, offerende, naar het gebod van Mozes, op de sabbatten, en op de nieuwe maanden, en op de gezette hoogtijden, drie malen in het jaar; op het feest van de ongezuurde broden, en op het feest der weken, en op het feest der loofhutten. [^13] Hij stelde ook, naar de wijze zijns vaders Davids, de verdelingen der priesteren over hun dienst, en der Levieten over hun wachten, om God te prijzen, en voor de priesteren te dienen, naar den eis van elken dag; en de poortiers in hun verdelingen, aan elke poort; want alzo was het gebod van David, den man Gods. [^14] En men week niet van des konings gebod aan de priesteren en de Levieten, aangaande alle zaken, en aangaande de schatten. [^15] Alzo werd al het werk van Salomo bereid tot den dag der grondlegging van het huis des HEEREN, en tot het volbrengen van hetzelve, dat het huis des HEEREN volmaakt werd. [^16] Toen toog Salomo naar Ezeon-Geber, en naar Eloth, aan den oever der zee, in het land van Edom. [^17] En Huram zond hem, door de hand zijner knechten, schepen, mitsgaders knechten, kenners van de zee; en zij gingen met Salomo’s knechten naar Ofir, en zij haalden van daar vierhonderd en vijftig talenten gouds, dewelke zij brachten tot den koning Salomo. [^18] 

[[2 Kronieken - 7|<--]] 2 Kronieken - 8 [[2 Kronieken - 9|-->]]

---
# Notes
