---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kronieken"
  - "#bible/testament/old"
aliases:
  - "2 Kronieken - 11 - Statenvertaling (1750)"
---
[[2 Kronieken - 10|<--]] 2 Kronieken - 11 [[2 Kronieken - 12|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[2 Kronieken]]

# 2 Kronieken - 11

Toen nu Rehabeam te Jeruzalem gekomen was, vergaderde hij het huis van Juda en Benjamin, eenhonderd en tachtig duizend uitgelezenen, geoefend ten oorlog, om tegen Israël te strijden, opdat hij het koninkrijk weder aan Rehabeam bracht. [^1] Doch het woord des HEEREN geschiedde tot Semaja, den man Gods, zeggende: [^2] Zeg tot Rehabeam, den zoon van Salomo, den koning van Juda, en tot het ganse Israël in Juda en Benjamin, zeggende: [^3] Zo zegt de HEERE: Gij zult niet optrekken, noch strijden tegen uw broederen; een ieder kere weder tot zijn huis, want deze zaak is van Mij geschied. En zij hoorden de woorden des HEEREN, en zij keerden weder van tegen Jerobeam te trekken. [^4] Rehabeam nu woonde te Jeruzalem; en hij bouwde steden tot vastigheden in Juda. [^5] Hij bouwde nu Bethlehem, en Etham, en Thekoa, [^6] En Beth-Zur, en Socho, en Adullam, [^7] En Gath, en Maresa, en Zif, [^8] En Adoraïm, en Lachis, en Azeka, [^9] En Zora, en Ajalon, en Hebron; dewelke in Juda en in Benjamin de vaste steden waren. [^10] En hij sterkte deze vastigheden, en legde oversten daarin, en schatten van spijs, en olie, en wijn; [^11] En in elke stad rondassen en spiesen, en sterkte ze gans zeer; zo was Juda, en Benjamin zijne. [^12] Daartoe de priesteren en de Levieten, die in het ganse Israël waren, stelden zich bij hem uit al hun landpalen. [^13] Want de Levieten verlieten hun voorsteden en hun bezitting, en kwamen in Juda en in Jeruzalem; want Jerobeam en zijn zonen hadden hen verstoten, van het priesterdom des HEEREN te mogen bedienen. [^14] En hij had zich priesteren gesteld voor de hoogte, en voor de duivelen, en voor de kalveren, die hij gemaakt had. [^15] Na die kwamen ook uit alle stammen van Israël te Jeruzalem, die hun hart begaven, om den HEERE, den God Israëls, te zoeken, dat zij den HEERE, den God hunner vaderen, offerande deden. [^16] Alzo sterkten zij het koninkrijk van Juda, en bekrachtigden Rehabeam, den zoon van Salomo, drie jaren; want drie jaren wandelden zij in den weg van David, en Salomo. [^17] En Rehabeam nam zich, benevens Mahalath, de dochter van Jerimoth, den zoon van David, ter vrouwe Abihaïl, de dochter van Eliab, den zoon van Isaï, [^18] Dewelke hem zonen baarde, Jeüs, en Semaria, en Zaham. [^19] En na haar nam hij Maächa, de dochter van Absalom; deze baarde hem Abia, en Attai, en Ziza, en Selomith. [^20] En Rehabeam had Maächa, Absaloms dochter, liever dan al zijn vrouwen en zijn bijwijven; want hij had achttien vrouwen genomen, en zestig bijwijven; en hij gewon acht en twintig zonen en zestig dochteren. [^21] En Rehabeam stelde Abia, den zoon van Maächa, tot een hoofd, om een overste te zijn onder zijn broederen; want het was om hem koning te maken. [^22] En hij handelde verstandelijk, dat hij van al zijn zonen, door alle landen van Juda en Benjamin, in alle vaste steden verspreidde, denwelken hij spijze gaf in overvloed; en hij begeerde de veelheid van vrouwen. [^23] 

[[2 Kronieken - 10|<--]] 2 Kronieken - 11 [[2 Kronieken - 12|-->]]

---
# Notes
