---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kronieken"
  - "#bible/testament/old"
aliases:
  - "2 Kronieken - 10 - Statenvertaling (1750)"
---
[[2 Kronieken - 9|<--]] 2 Kronieken - 10 [[2 Kronieken - 11|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[2 Kronieken]]

# 2 Kronieken - 10

En Rehabeam toog naar Sichem; want het ganse Israël was te Sichem gekomen, om hem koning te maken. [^1] Het geschiedde nu, als Jerobeam, de zoon van Nebat, dat hoorde (dezelve nu was in Egypte, alwaar hij van het aangezicht van den koning Salomo gevloden was), dat Jerobeam uit Egypte wederkeerde; [^2] Want zij zonden henen, en lieten hem roepen; zo kwam Jerobeam met het ganse Israël, en zij spraken tot Rehabeam, zeggende: [^3] Uw vader heeft ons juk hard gemaakt, nu dan, maak gij uws vaders harden dienst, en zijn zwaar juk, dat hij ons opgelegd heeft, lichter, en wij zullen u dienen. [^4] En hij zeide tot hen: Komt over drie dagen weder tot mij. En het volk ging heen. [^5] En de koning Rehabeam hield raad met de oudsten, die gestaan hadden voor het aangezicht van zijn vader Salomo, als hij leefde, zeggende: Hoe raadt gijlieden, dat men dit volk antwoorden zal? [^6] En zij spraken tot hem, zeggende: Indien gij dit volk goedertieren en jegens hen goedwillig wezen zult, en tot hen goede woorden spreken, zo zullen zij te allen dage uw knechten zijn. [^7] Maar hij verliet den raad der oudsten, dien zij hem geraden hadden; en hij hield raad met de jongelingen, die met hem opgewassen waren, die voor zijn aangezicht stonden. [^8] En hij zeide tot hen: Wat raadt gijlieden, dat wij dit volk antwoorden zullen, die tot mij gesproken hebben, zeggende: Maak het juk, dat uw vader ons opgelegd heeft, lichter? [^9] En de jongelingen die met hem opgewassen waren, spraken tot hem, zeggende: Alzo zult gij zeggen tot dat volk, dat tot u gesproken heeft, zeggende: Uw vader heeft ons juk zwaar gemaakt, maar maak gij het over ons lichter; alzo zult gij tot hen spreken: Mijn kleinste vinger zal dikker zijn dan mijns vaders lenden. [^10] Indien nu mijn vader een zwaar juk op u heeft doen laden, zo zal ik boven uw juk nog daartoe doen; mijn vader heeft u met geselen gekastijd, maar ik zal u met schorpioenen kastijden. [^11] Zo kwam Jerobeam en al het volk tot Rehabeam, op den derden dag, gelijk als de koning gesproken had, zeggende: Komt weder tot mij op den derden dag. [^12] En de koning antwoordde hun hardelijk; want de koning Rehabeam verliet den raad der oudsten. [^13] En hij sprak tot hen naar den raad der jongelingen, zeggende: Mijn vader heeft uw juk zwaar gemaakt, maar ik zal nog daarboven toedoen; mijn vader heeft u met geselen gekastijd, maar ik zal u met schorpioenen kastijden. [^14] Alzo hoorde de koning naar het volk niet; want deze omwending was van God, opdat de HEERE Zijn woord bevestigde, hetwelk Hij door den dienst van Ahia, den Siloniet, gesproken had tot Jerobeam, den zoon van Nebat. [^15] Toen het ganse volk Israël zag, dat de koning naar hen niet hoorde, zo antwoordde het volk den koning, zeggende: Wat deel hebben wij aan David? Ja, geen erve hebben wij aan den zoon van Isaï; een ieder naar uw tenten, o Israël! Voorzie nu uw huis, o David! Zo ging het ganse Israël naar zijn tenten. [^16] Doch aangaande de kinderen van Israël, die in de steden van Juda woonden, over die regeerde Rehabeam ook. [^17] Toen zond de koning Rehabeam Hadoram, die over de schatting was; en de kinderen Israëls stenigden hem met stenen, dat hij stierf; maar de koning Rehabeam verkloekte zich, om op een wagen te klimmen, dat hij naar Jeruzalem vluchtte. [^18] Alzo vielen de Israëlieten van het huis van David af, tot op dezen dag. [^19] 

[[2 Kronieken - 9|<--]] 2 Kronieken - 10 [[2 Kronieken - 11|-->]]

---
# Notes
