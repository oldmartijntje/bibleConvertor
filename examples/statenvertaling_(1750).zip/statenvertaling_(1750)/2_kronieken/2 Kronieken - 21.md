---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kronieken"
  - "#bible/testament/old"
aliases:
  - "2 Kronieken - 21 - Statenvertaling (1750)"
---
[[2 Kronieken - 20|<--]] 2 Kronieken - 21 [[2 Kronieken - 22|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[2 Kronieken]]

# 2 Kronieken - 21

Daarna ontsliep Josafat met zijn vaderen, en werd begraven bij zijn vaderen in de stad Davids; en zijn zoon Joram werd koning in zijn plaats. [^1] En hij had broederen, Josafats zonen, Azarja, en Jehiël, en Zecharja, en Azarjahu, en Michaël, en Sefatja; deze allen waren zonen van Josafat, den koning van Israël. [^2] En hun vader had hun vele gaven gegeven van zilver, en van goud, en van kostelijkheden, met vaste steden in Juda; maar het koninkrijk gaf hij Joram, omdat hij de eerstgeborene was. [^3] Als Joram tot het koninkrijk zijns vaders opgekomen was, en zich versterkt had, zo doodde hij al zijn broederen met het zwaard, mitsgaders ook enige van de vorsten van Israël. [^4] Twee en dertig jaar was Joram oud, toen hij koning werd, en hij regeerde acht jaren te Jeruzalem. [^5] En hij wandelde in den weg der koningen van Israël, gelijk als het huis van Achab deed; want hij had de dochter van Achab tot een vrouw; en hij deed dat kwaad was in de ogen des HEEREN. [^6] Doch de HEERE wilde het huis Davids niet verderven, om des verbonds wil, dat Hij met David gemaakt had; en gelijk als Hij gezegd had, hem en zijn zonen te allen dage een lamp te zullen geven. [^7] In zijn dagen vielen de Edomieten af van onder het gebied van Juda, en zij maakten over zich een koning. [^8] Daarom toog Joram voort met zijn oversten, en al de wagenen met hem; en hij maakte zich des nachts op, en sloeg de Edomieten, die rondom hem waren, en de oversten der wagenen. [^9] Evenwel vielen de Edomieten af van onder het gebied van Juda, tot op dezen dag; toen ter zelfder tijd viel Libna af, van onder zijn gebied, want hij had den HEERE, den God zijner vaderen, verlaten. [^10] Ook maakte hij hoogten op de bergen van Juda; en hij deed de inwoners van Jeruzalem hoereren, ja, hij dreef Juda daartoe. [^11] Zo kwam een schrift tot hem van den profeet Elia, zeggende: Alzo zegt de HEERE, de God van uw vader David: Omdat gij in de wegen van uw vader Josafat, en in de wegen van Asa, den koning van Juda, niet gewandeld hebt; [^12] Maar hebt gewandeld in den weg der koningen van Israël, en hebt Juda en de inwoners van Jeruzalem doen hoereren, achtervolgens het hoereren van het huis van Achab; en ook uw broederen, van uws vaders huis, gedood hebt, die beter waren dan gij; [^13] Zie, de HEERE zal u plagen met een grote plage aan uw volk, en aan uw kinderen, en aan uw vrouwen, en aan al uw have. [^14] Gij zult ook in grote krankheden zijn, door de krankheid uwer ingewanden, totdat uw ingewanden uitgaan vanwege de krankheid, jaar op jaar. [^15] Zo verwekte de HEERE tegen Joram den geest der Filistijnen en der Arabieren, die aan de zijde der Moren zijn. [^16] Die togen op in Juda, en braken daarin, en voerden alle have weg, die in het huis des konings gevonden werd, zelfs ook zijn kinderen, en zijn vrouwen; zodat hem geen zoon overgelaten werd, dan Joahaz, de kleinste zijner zonen. [^17] En na dit alles plaagde hem de HEERE in zijn ingewand met een krankheid, daar geen genezen aan was. [^18] Dit geschiedde van jaar tot jaar, zodat, wanneer de tijd van het einde der twee jaren uitging, zijn ingewanden met de krankheid uitgingen, dat hij stierf van boze krankheden; en zijn volk maakte hem gene branding, als de branding zijner vaderen. [^19] Hij was twee en dertig jaren oud, als hij koning werd, en regeerde acht jaren te Jeruzalem; en hij ging henen zonder begeerd te zijn; en zij begroeven hem in de stad Davids, maar niet in de graven der koningen. [^20] 

[[2 Kronieken - 20|<--]] 2 Kronieken - 21 [[2 Kronieken - 22|-->]]

---
# Notes
