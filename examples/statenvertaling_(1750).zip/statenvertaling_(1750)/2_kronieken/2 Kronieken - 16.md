---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kronieken"
  - "#bible/testament/old"
aliases:
  - "2 Kronieken - 16 - Statenvertaling (1750)"
---
[[2 Kronieken - 15|<--]] 2 Kronieken - 16 [[2 Kronieken - 17|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[2 Kronieken]]

# 2 Kronieken - 16

In het zes en dertigste jaar van het koninkrijk van Asa, toog Baësa, de koning van Israël, op tegen Juda, en bouwde Rama, opdat hij niemand toeliet uit te gaan en in te komen tot Asa, den koning van Juda. [^1] Toen bracht Asa het zilver en het goud voort, uit de schatten van het huis des HEEREN en van het huis des konings, en zond tot Benhadad, den koning van Syrië, die te Damaskus woonde, zeggende: [^2] Er is een verbond tussen mij en tussen u, en tussen mijn vader en tussen uw vader; zie, ik zend u zilver en goud, ga heen, maak uw verbond te niet met Baësa, den koning van Israël, dat hij van tegen mij aftrekke. [^3] En Benhadad hoorde naar den koning Asa, en zond de oversten der heiren, die hij had, tegen de steden van Israël, en zij sloegen Ijon, en Dan, en Abel-Maïm, en alle schatsteden van Nafthali. [^4] En het geschiedde, als Baësa zulks hoorde, dat hij afliet van Rama te bouwen, en zijn werk staakte. [^5] Toen nam de koning Asa gans Juda, en zij droegen weg de stenen van Rama, en het hout daarvan, waarmede Baësa gebouwd had; en hij bouwde daarmede Geba en Mizpa. [^6] En in denzelfden tijd kwam de ziener Hanani tot Asa, den koning van Juda, en hij zeide tot hem: Omdat gij gesteund hebt op den koning van Syrië, en niet gesteund hebt op den HEERE, uw God, daarom is het heir des konings van Syrië uit uw hand ontkomen. [^7] Waren niet de Moren en de Libiërs een groot heir met zeer veel wagenen en ruiteren? Toen gij nochtans op den HEERE steundet, heeft Hij hen in uw hand gegeven. [^8] Want den HEERE aangaande, Zijn ogen doorlopen de ganse aarde, om Zich sterk te bewijzen aan degenen, welker hart volkomen is tot Hem; gij hebt hierin zottelijk gedaan; want van nu af zullen oorlogen tegen u zijn. [^9] Doch Asa werd toornig tegen den ziener, en leidde hem in het gevangenhuis; want hij was hierover tegen hem ontsteld; daartoe onderdrukte Asa enigen uit het volk ter zelfder tijd. [^10] En ziet, de geschiedenissen van Asa, de eerste met de laatste, ziet, zij zijn beschreven in het boek der koningen van Juda en Israël. [^11] Asa nu werd, in het negen en dertigste jaar van zijn koninkrijk, krank aan zijn voeten; tot op het hoogste toe was zijn krankheid; daartoe ook zocht hij den HEERE niet in zijn krankheid, maar de medicijnmeesters. [^12] Alzo ontsliep Asa met zijn vaderen; en hij stierf in het een en veertigste jaar zijner regering. [^13] En zij begroeven hem in zijn graf, dat hij voor zich gegraven had in de stad Davids, en legden hem op het bed, hetwelk hij gevuld had met specerijen, en dat van verscheidene soorten, naar apothekerskunst toebereid; en zij brandden over hem een gans grote branding. [^14] 

[[2 Kronieken - 15|<--]] 2 Kronieken - 16 [[2 Kronieken - 17|-->]]

---
# Notes
