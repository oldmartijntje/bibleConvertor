---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kronieken"
  - "#bible/testament/old"
aliases:
  - "2 Kronieken - 12 - Statenvertaling (1750)"
---
[[2 Kronieken - 11|<--]] 2 Kronieken - 12 [[2 Kronieken - 13|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[2 Kronieken]]

# 2 Kronieken - 12

Het geschiedde nu, als Rehabeam het koninkrijk bevestigd had, en hij sterk geworden was, dat hij de wet des HEEREN verliet, en gans Israël met hem. [^1] Daarom geschiedde het, in het vijfde jaar van den koning Rehabeam, dat Sisak, de koning van Egypte, tegen Jeruzalem optoog (want zij hadden overtreden tegen den HEERE), [^2] Met duizend en tweehonderd wagenen, en met zestig duizend ruiteren; en des volks was geen getal, dat met hem kwam uit Egypte, Libiërs, Suchieten en Moren; [^3] En hij nam de vaste steden in, die Juda had, en hij kwam tot Jeruzalem toe. [^4] Toen kwam Semaja, de profeet, tot Rehabeam en de oversten van Juda, die te Jeruzalem verzameld waren, uit oorzaak van Sisak, en hij zeide tot hen: Alzo zegt de HEERE: Gij hebt Mij verlaten, daarom heb Ik u ook verlaten in de hand van Sisak. [^5] Toen verootmoedigden zich de oversten van Israël en de koning, en zij zeiden: De HEERE is rechtvaardig. [^6] Als nu de HEERE zag, dat zij zich verootmoedigden, geschiedde het woord des HEEREN tot Semaja, zeggende: Zij hebben zich verootmoedigd, Ik zal hen niet verderven; maar Ik zal hun in kort ontkoming geven, dat Mijn grimmigheid over Jeruzalem door de hand van Sisak niet zal uitgegoten worden. [^7] Doch zij zullen hem tot knechten zijn, opdat zij onderkennen Mijn dienst, en den dienst van de koninkrijken der landen. [^8] Zo toog Sisak, de koning van Egypte, op tegen Jeruzalem; en hij nam de schatten van het huis des HEEREN en de schatten van het huis des konings weg; hij nam alles weg; hij nam ook al de gouden schilden weg, die Salomo gemaakt had. [^9] En de koning Rehabeam maakte, in plaats van die, koperen schilden; en hij beval die onder de hand van de oversten der trawanten, die de deur van het huis des konings bewaarden. [^10] En het geschiedde, zo wanneer de koning in het huis des HEEREN ging, dat de trawanten kwamen, en die droegen, en die wederbrachten in der trawanten wachtkamer. [^11] En als hij zich verootmoedigde, keerde de toorn des HEEREN van hem af, opdat Hij hem niet ten uiterste toe verdierf; ook waren in Juda nog goede dingen. [^12] Zo versterkte zich de koning Rehabeam in Jeruzalem, en regeerde; want Rehabeam was een en veertig jaren oud, als hij koning werd, en hij regeerde zeventien jaren in Jeruzalem, de stad, die de HEERE uit alle stammen van Israël verkoren had, om Zijn Naam daar te zetten; en de naam zijner moeder was Naäma, een Ammonietische. [^13] En hij deed dat kwaad was, dewijl hij zijn hart niet richtte, om den HEERE te zoeken. [^14] De geschiedenissen nu van Rehabeam, de eerste en de laatste, zijn die niet geschreven in de woorden van Semaja, den profeet, en Iddo, den ziener, verhalende de geslachtsregisteren; daartoe de krijgen van Rehabeam en Jerobeam in al hun dagen? [^15] En Rehabeam ontsliep met zijn vaderen, en werd begraven in de stad Davids; en zijn zoon Abia werd koning in zijn plaats. [^16] 

[[2 Kronieken - 11|<--]] 2 Kronieken - 12 [[2 Kronieken - 13|-->]]

---
# Notes
