---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kronieken"
  - "#bible/testament/old"
aliases:
  - "2 Kronieken - 14 - Statenvertaling (1750)"
---
[[2 Kronieken - 13|<--]] 2 Kronieken - 14 [[2 Kronieken - 15|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[2 Kronieken]]

# 2 Kronieken - 14

Zo ontsliep Abia met zijn vaderen, en zij begroeven hem in de stad Davids, en zijn zoon Asa werd koning in zijn plaats. In zijn dagen was het land tien jaren stil. [^1] En Asa deed dat goed en dat recht was in de ogen des HEEREN, zijns Gods. [^2] Want hij nam de altaren der vreemden, en de hoogten weg, en brak de opgerichte beelden, en hieuw de bossen af. [^3] En hij zeide tot Juda, dat zij den HEERE, den God hunner vaderen, zoeken, en dat zij de wet en het gebod doen zouden. [^4] Hij nam ook weg uit alle steden van Juda de hoogten en de zonnebeelden; en het koninkrijk was voor hem stil. [^5] Daartoe bouwde hij vaste steden in Juda; want het land was stil, en er was geen oorlog in die jaren tegen hem, dewijl de HEERE hem rust gaf. [^6] Want hij zeide tot Juda: Laat ons deze steden bouwen, en muren daarom trekken, en torens, deuren en grendelen, terwijl het land nog is voor ons aangezicht; want wij hebben den HEERE, onzen God, gezocht, wij hebben Hem gezocht, en Hij heeft ons rondom henen rust gegeven. Zo bouwden zij en hadden voorspoed. [^7] Asa nu had een heir van driehonderd duizend uit Juda, rondas en spies dragende, en tweehonderd en tachtig duizend uit Benjamin, het schild dragende en den boog spannende; al dezen waren kloeke helden. [^8] En Zerah, de Moor, kwam tegen hen uit, met een heir van duizend maal duizend, en driehonderd wagenen; en hij kwam tot Maresa toe. [^9] Toen toog Asa tegen hem uit; en zij stelden de slagorde in het dal Zefatha bij Maresa. [^10] En Asa riep tot den HEERE, zijn God, en zeide: HEERE, het is niets bij U, te helpen hetzij den machtige, hetzij den krachteloze; help ons, o HEERE, onze God! Want wij steunen op U, en in Uw Naam zijn wij gekomen tegen deze menigte; o HEERE! Gij zijt onze God; laat den sterfelijken mens tegen U niets vermogen. [^11] En de HEERE plaagde de Moren voor Asa en voor Juda; en de Moren vloden. [^12] Asa nu en het volk, dat met hem was, jaagden hen na tot Gerar toe; en zo velen vielen er van de Moren, dat er voor hen geen hervatting was; want zij waren verbroken voor den HEERE en voor Zijn leger; en zij droegen zeer veel roofs daarvan. [^13] En zij sloegen alle steden rondom Gerar; want de verschrikking des HEEREN was over hen; en zij beroofden al de steden, omdat veel roofs in dezelve was. [^14] En zij sloegen ook de tenten van het vee, en voerden weg schapen in menigte, en kemelen; en kwamen weder te Jeruzalem. [^15] 

[[2 Kronieken - 13|<--]] 2 Kronieken - 14 [[2 Kronieken - 15|-->]]

---
# Notes
