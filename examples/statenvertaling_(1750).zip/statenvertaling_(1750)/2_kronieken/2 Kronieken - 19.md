---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kronieken"
  - "#bible/testament/old"
aliases:
  - "2 Kronieken - 19 - Statenvertaling (1750)"
---
[[2 Kronieken - 18|<--]] 2 Kronieken - 19 [[2 Kronieken - 20|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[2 Kronieken]]

# 2 Kronieken - 19

En Josafat, de koning van Juda, keerde met vrede weder naar zijn huis te Jeruzalem. [^1] En Jehu, de zoon van Hanani, de ziener, ging uit, hem tegen, en zeide tot den koning Josafat: Zoudt gij den goddeloze helpen, en die den HEERE haten, liefhebben? Nu is daarom over u van het aangezicht des HEEREN grote toornigheid. [^2] Evenwel goede dingen zijn bij u gevonden; want gij hebt de bossen uit het land weggedaan, en uw hart gericht om God te zoeken. [^3] Josafat nu woonde te Jeruzalem; en hij toog wederom uit door het volk, van Berseba af tot het gebergte van Efraïm toe, en deed hen wederkeren tot den HEERE, hunner vaderen God. [^4] En hij stelde richters in het land, in alle vaste steden van Juda, van stad tot stad. [^5] En hij zeide tot de richters: Ziet wat gij doet, want gij houdt het gericht niet den mens, maar den HEERE; en Hij is bij u in de zaak van het gericht. [^6] Nu dan, de verschrikking des HEEREN zij op ulieden; neemt waar, en doet het; want bij den HEERE, onzen God, is geen onrecht, noch aanneming van personen, noch ontvanging van geschenken. [^7] Daartoe stelde Josafat ook te Jeruzalem enige van de Levieten, en van de priesteren, en van de hoofden der vaderen van Israël, over het gericht des HEEREN, en over rechtsgeschillen, als zij weder te Jeruzalem gekomen waren. [^8] En hij gebood hun, zeggende: Doet alzo in de vreze des HEEREN, met getrouwheid en met een volkomen hart. [^9] En in alle geschil, hetwelk van uw broederen, die in hun steden wonen, tot u zal komen, tussen bloed en bloed, tussen wet en gebod, en inzettingen en rechten, zo vermaant hen, dat zij niet schuldig worden aan den HEERE, en een grote toornigheid over u en over uw broederen zij; doet alzo, en gij zult niet schuldig worden. [^10] En ziet, Amarja, de hoofdpriester, is over u in alle zaak des HEEREN; en Zebadja, de zoon van Ismaël, de vorst van het huis van Juda, in alle zaak des konings; ook zijn de ambtlieden, de Levieten, voor uw aangezicht; weest sterk en doet het, en de HEERE zal met den goede zijn. [^11] 

[[2 Kronieken - 18|<--]] 2 Kronieken - 19 [[2 Kronieken - 20|-->]]

---
# Notes
