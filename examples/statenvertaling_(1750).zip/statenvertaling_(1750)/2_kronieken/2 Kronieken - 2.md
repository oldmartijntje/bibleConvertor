---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kronieken"
  - "#bible/testament/old"
aliases:
  - "2 Kronieken - 2 - Statenvertaling (1750)"
---
[[2 Kronieken - 1|<--]] 2 Kronieken - 2 [[2 Kronieken - 3|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[2 Kronieken]]

# 2 Kronieken - 2

Salomo nu dacht voor den Naam des HEEREN een huis te bouwen, en een huis voor zijn koninkrijk. [^1] En Salomo telde zeventig duizend lastdragende mannen, en tachtig duizend mannen, die houwen zouden in het gebergte; mitsgaders drie duizend en zeshonderd opzieners over dezelve. [^2] En Salomo zond tot Huram, den koning van Tyrus, zeggende: Gelijk als gij met mijn vader David gedaan hebt, en hebt hem cederen gezonden, om voor hem een huis te bouwen, om daarin te wonen, zo doe ook met mij. [^3] Zie, ik zal een huis voor den Naam des HEEREN, mijns Gods, bouwen, om Hem te heiligen, om reukwerk der welriekende specerijen voor Zijn aangezicht aan te steken, en voor de toerichting des gedurigen broods, en voor de brandofferen des morgens en des avonds, op de sabbatten, en op de nieuwe maanden, en op de gezette hoogtijden des HEEREN, onzes Gods; hetwelk voor eeuwig is in Israël. [^4] En het huis, dat ik zal bouwen, zal groot zijn; want onze God is groter dan alle goden. [^5] Doch wie zou de kracht hebben, om voor Hem een huis te bouwen, dewijl de hemelen, ja, de hemel der hemelen, Hem niet bevatten zouden? En wie ben ik, dat ik voor Hem een huis zou bouwen, ten ware om reukwerk voor Zijn aangezicht aan te steken? [^6] Zo zend mij nu een wijzen man, om te werken in goud, en in zilver, en in koper, en in ijzer, en in purper, en karmozijn, en hemelsblauw, en die weet graveerselen te graveren, met de wijzen, die bij mij zijn in Juda en in Jeruzalem, die mijn vader David beschikt heeft. [^7] Zend mij ook cederen, dennen, en algummimhout uit Libanon; want ik weet, dat uw knechten het hout van Libanon weten te houwen; en zie, mijn knechten zullen met uw knechten zijn. [^8] En dat om mij hout in menigte te bereiden; want het huis, dat ik zal bouwen, zal groot en wonderlijk zijn. [^9] En zie, ik zal uw knechten, den houwers, die het hout houwen, twintig duizend kor uitgeslagen tarwe, en twintig duizend kor gerst geven; daartoe twintig duizend bath wijn, en twintig duizend bath olie. [^10] Huram nu, de koning van Tyrus, antwoordde door schrift, en zond tot Salomo: Daarom dat de HEERE Zijn volk lief heeft, heeft Hij u over hen tot koning gesteld. [^11] Verder zeide Huram: Geloofd zij de HEERE, de God Israëls, Die den hemel en de aarde gemaakt heeft, dat Hij den koning David een wijzen zoon, kloek in voorzichtigheid en verstand, gegeven heeft, die een huis voor den HEERE, en een huis voor zijn koninkrijk bouwe! [^12] Zo zend ik nu een wijzen man, kloek van verstand, Huram Abi; [^13] Den zoon ener vrouw uit de dochteren van Dan, en wiens vader een man geweest is van Tyrus, die weet te werken in goud, en in zilver, in koper, in ijzer, in stenen, en in hout, in purper, in hemelsblauw, en in fijn linnen, en in karmozijn, en om alle graveersels te graveren, en om te bedenken allen vernuftigen vond, die hem zal voorgesteld worden, met uw wijzen, en de wijzen van mijn heer, uw vader David. [^14] Zo zende nu mijn heer zijn knechten de tarwe en de gerst, de olie en den wijn, die hij gezegd heeft. [^15] En wij zullen hout houwen uit den Libanon, naar al uw nooddruft, en zullen het tot u met vlotten, over de zee, naar Jafo brengen; en gij zult het laten ophalen naar Jeruzalem. [^16] En Salomo telde al de vreemde mannen, die in het land van Israël waren, achtervolgens de telling, met dewelke zijn vader David die geteld had; en er werden gevonden honderd drie en vijftig duizend en zeshonderd. [^17] En hij maakte uit dezelve zeventig duizend lastdragers, en tachtig duizend houwers in het gebergte, mitsgaders drie duizend en zeshonderd opzieners, om het volk te doen arbeiden. [^18] 

[[2 Kronieken - 1|<--]] 2 Kronieken - 2 [[2 Kronieken - 3|-->]]

---
# Notes
