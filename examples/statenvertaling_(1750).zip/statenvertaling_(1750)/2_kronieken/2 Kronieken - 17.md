---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kronieken"
  - "#bible/testament/old"
aliases:
  - "2 Kronieken - 17 - Statenvertaling (1750)"
---
[[2 Kronieken - 16|<--]] 2 Kronieken - 17 [[2 Kronieken - 18|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[2 Kronieken]]

# 2 Kronieken - 17

En zijn zoon Josafat werd koning in zijn plaats, en hij sterkte zich tegen Israël. [^1] En hij legde krijgsvolk in alle vaste steden van Juda, en legde bezettingen in het land van Juda, en in de steden van Efraïm, die zijn vader Asa ingenomen had. [^2] En de HEERE was met Josafat; want hij wandelde in de vorige wegen zijns vaders Davids, en zocht de Baäls niet. [^3] Maar hij zocht den God zijns vaders, en wandelde in Zijn geboden, en niet naar het doen van Israël. [^4] En de HEERE bevestigde het koninkrijk in zijn hand, en gans Juda gaf Josafat geschenken; en hij had rijkdom en eer in menigte. [^5] En zijn hart verhief zich in de wegen des HEEREN; en hij nam verder de hoogten en de bossen uit Juda weg. [^6] In het derde jaar nu zijner regering zond hij tot zijn vorsten, tot Ben-chaïl, en tot Obadja, en tot Zecharja, en tot Nathaneël, en tot Michaja, opdat men zou leren in de steden van Juda. [^7] En met hen de Levieten, Semaja en Nethanja, en Zebadja, en Asaël, en Semiramoth, en Jonathan, en Adonia, en Tobia, en Tob-Adonia, de Levieten, en met hen de priesters Elisama en Joram. [^8] En zij leerden in Juda, en het wetboek des HEEREN was bij hen; en zij gingen rondom in alle steden van Juda, en leerden onder het volk. [^9] En een verschrikking des HEEREN werd over alle koninkrijken der landen, die rondom Juda waren, dat zij niet krijgden tegen Josafat. [^10] En van de Filistijnen brachten zij Josafat geschenken met het opgelegde geld; ook brachten hem de Arabieren klein vee, zeven duizend en zevenhonderd rammen, en zeven duizend en zevenhonderd bokken. [^11] Alzo nam Josafat toe, en werd ten hoogste groot; daartoe bouwde hij in Juda burchten en schatsteden. [^12] En hij had veel werks in de steden van Juda, en krijgslieden, kloeke helden in Jeruzalem. [^13] Dit nu is hun telling, naar de huizen hunner vaderen. In Juda waren oversten der duizenden: Adna de overste, en met hem waren driehonderd duizend kloeke helden. [^14] Naast hem nu was de overste Johanan; en met hem waren tweehonderd en tachtig duizend; [^15] En naast hem was Amasia, de zoon van Zichri, die zich vrijwillig den HEERE overgegeven had; en met hem waren tweehonderd duizend kloeke helden. [^16] En uit Benjamin was Eljada, een kloek held; en met hem tweehonderd duizend, die met boog en schild gewapend waren. [^17] En naast hem was Jozabad; en met hem waren honderd en tachtig duizend, ten krijge toegerust. [^18] Dezen waren in den dienst des konings; behalve degenen, die de koning in de vaste steden door gans Juda gezet had. [^19] 

[[2 Kronieken - 16|<--]] 2 Kronieken - 17 [[2 Kronieken - 18|-->]]

---
# Notes
