---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kronieken"
  - "#bible/testament/old"
aliases:
  - "2 Kronieken - 5 - Statenvertaling (1750)"
---
[[2 Kronieken - 4|<--]] 2 Kronieken - 5 [[2 Kronieken - 6|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[2 Kronieken]]

# 2 Kronieken - 5

Alzo werd al het werk volbracht, dat Salomo aan het huis des HEEREN maakte. Daarna bracht Salomo de geheiligde dingen van zijn vader David; en het zilver, en het goud, en al de vaten legde hij onder de schatten van het huis Gods. [^1] Toen vergaderde Salomo de oudsten van Israël, en al de hoofden der stammen, de oversten der vaderen onder de kinderen Israëls, te Jeruzalem, om de ark des verbonds des HEEREN op te brengen uit de stad Davids, dewelke is Sion. [^2] En alle mannen van Israël verzamelden zich tot den koning op het feest, hetwelk was in de zevende maand. [^3] En al de oudsten van Israël kwamen, en de Levieten namen de ark op. [^4] En zij brachten de ark, en de tent der samenkomst opwaarts, mitsgaders al de heilige vaten, die in de tent waren; deze brachten de priesters en Levieten opwaarts. [^5] De koning Salomo nu, en de ganse vergadering van Israël, die bij hem vergaderd waren voor de ark, offerden schapen en runderen, die vanwege de menigte niet konden geteld noch gerekend worden. [^6] Alzo brachten de priesters de ark des verbonds des HEEREN tot haar plaats, tot de aanspraakplaats van het huis, tot het heilige der heiligen, tot onder de vleugelen der cherubim. [^7] Want de cherubim spreidden de beide vleugelen over de plaats der ark; en de cherubim overdekten de ark en haar handbomen van boven. [^8] Daarna schoven zij de handbomen verder uit, dat de hoofden der handbomen gezien werden uit de ark, voor aan de aanspraakplaats, maar buiten niet gezien werden; en zij was daar tot op dezen dag. [^9] Er was niets in de ark, dan alleen de twee tafelen, die Mozes bij Horeb daarin gedaan had als de HEERE een verbond maakte met de kinderen Israëls, toen zij uit Egypte uitgetogen waren. [^10] En het geschiedde, als de priesters uit het heilige uitgingen; (want al de priesters, die gevonden werden, hadden zich geheiligd, zonder de verdelingen te houden; [^11] En de Levieten, die zangers waren van hen allen, van Asaf, van Heman, van Jeduthun, en van hun zonen, en van hun broederen, in fijn linnen gekleed, met cimbalen, en met luiten, en harpen, stonden tegen het oosten des altaars, en met hen tot honderd en twintig priesteren toe, trompettende met trompetten.) [^12] Het geschiedde dan, als zij eenpariglijk trompetten en zongen, om een eenparige stem te laten horen, prijzende en lovende den HEERE; en als zij de stem verhieven met trompetten, en met cimbalen, en andere muzikale instrumenten, en als zij den HEERE prezen, dat Hij goed is, dat Zijn weldadigheid is tot in eeuwigheid; dat het huis met een wolk vervuld werd, namelijk het huis des HEEREN. [^13] En de priesters konden, vanwege die wolk, niet staan, om te dienen; want de heerlijkheid des HEEREN had het huis Gods vervuld. [^14] 

[[2 Kronieken - 4|<--]] 2 Kronieken - 5 [[2 Kronieken - 6|-->]]

---
# Notes
