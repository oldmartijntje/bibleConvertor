---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kronieken"
  - "#bible/testament/old"
aliases:
  - "2 Kronieken - 3 - Statenvertaling (1750)"
---
[[2 Kronieken - 2|<--]] 2 Kronieken - 3 [[2 Kronieken - 4|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[2 Kronieken]]

# 2 Kronieken - 3

En Salomo begon het huis des HEEREN te bouwen te Jeruzalem, op den berg Moria, die zijn vader David gewezen was, in de plaats, die David toebereid had, op den dorsvloer van Ornan, den Jebusiet. [^1] Hij begon nu te bouwen in de tweede maand, op den tweeden dag, in het vierde jaar van zijn koninkrijk. [^2] En deze zijn de grondleggingen van Salomo, om het huis Gods te bouwen: de lengte in ellen, naar de eerste mate, was zestig ellen, en de breedte twintig ellen. [^3] En het voorhuis, hetwelk vooraan was, was in de lengte, naar de breedte van het huis, twintig ellen, en de hoogte honderd en twintig; hetwelk hij van binnen overtrok met louter goud. [^4] Het grote huis nu overdekte hij met dennenhout; daarna overtoog hij dat met goed goud; en hij maakte daarop palmen en ketenwerk. [^5] Hij overtoog ook het huis met kostelijke stenen tot versiering; het goud nu was goud van Parvaïm. [^6] Daartoe overdekte hij aan het huis de balken, de posten en de wanden daarvan, en de deuren daarvan met goud; en hij graveerde cherubs aan de wanden. [^7] Verder maakte hij het huis van het heilige der heiligen, welks lengte, naar de breedte van het huis, was twintig ellen, en de breedte daarvan twintig ellen; en hij overtoog dat met goed goud, tot zeshonderd talenten. [^8] En het gewicht der nagelen was tot vijftig sikkelen gouds; en hij overtoog de opperzalen met goud. [^9] Ook maakte hij, in het huis van het heilige der heiligen, twee cherubim van uittrekkend werk, en hij overtoog die met goud. [^10] Aangaande de vleugelen der cherubim, hun lengte was twintig ellen; des enen vleugel was van vijf ellen, rakende aan den wand van het huis, en de andere vleugel van vijf ellen, rakende aan den vleugel des anderen cherubs. [^11] Insgelijks was de vleugel des anderen cherubs van vijf ellen, rakende aan den wand van het huis; en de andere vleugel was van vijf ellen, klevende aan den vleugel des anderen cherubs. [^12] De vleugelen dezer cherubim spreidden zich uit twintig ellen; en zij stonden op hun voeten, en hun aangezichten waren huiswaarts. [^13] Hij maakte ook den voorhang van hemelsblauw, en purper, en karmozijn, en fijn linnen; en hij maakte cherubs daarop. [^14] Nog maakte hij voor het huis twee pilaren, van vijf en dertig ellen in lengte; en het kapiteel, dat op derzelver hoofd was, was van vijf ellen. [^15] Ook maakte hij ketenen, als in de aanspraakplaats, en hij zette ze op de hoofden der pilaren; daartoe maakte hij honderd granaatappelen, en zette ze tussen de ketenen. [^16] En hij richtte de pilaren op voor aan den tempel, een ter rechterhand, en een ter linkerhand; en hij noemde den naam van den rechter Jachin, en den naam van den linker Boaz. [^17] 

[[2 Kronieken - 2|<--]] 2 Kronieken - 3 [[2 Kronieken - 4|-->]]

---
# Notes
