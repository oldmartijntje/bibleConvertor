---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kronieken"
  - "#bible/testament/old"
aliases:
  - "2 Kronieken - 4 - Statenvertaling (1750)"
---
[[2 Kronieken - 3|<--]] 2 Kronieken - 4 [[2 Kronieken - 5|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[2 Kronieken]]

# 2 Kronieken - 4

Hij maakte ook een koperen altaar, van twintig ellen in zijn lengte, en twintig ellen in zijn breedte, en tien ellen in zijn hoogte. [^1] Daartoe maakte hij de gegoten zee; van tien ellen was zij, van haar enen rand tot haar anderen rand, rondom rond, en van vijf ellen in haar hoogte, en een meetsnoer van dertig ellen omving ze rondom. [^2] Onder dezelve nu was de gelijkenis van runderen, rondom henen, die omsingelende, tien in een el, omringende de zee rondom; twee rijen dezer runderen waren in haar gieting gegoten. [^3] Zij stond op twaalf runderen, drie ziende naar het noorden, en drie ziende naar het westen, en drie ziende naar het zuiden, en drie ziende naar het oosten; en de zee was boven op dezelve; en al hun achterdelen waren inwaarts. [^4] Haar dikte nu was een hand breed, en haar rand als het werk van den rand eens bekers of ener leliebloem, bevattende vele bathen; zij hield drie duizend. [^5] En hij maakte tien wasvaten, en stelde vijf ter rechter- en vijf ter linkerhand, om daarin te wassen; wat ten brandoffer behoort, staken zij daarin; maar de zee was, opdat de priesters zich daarin zouden wassen. [^6] Hij maakte ook tien gouden kandelaren, naar hun wijze, en hij stelde ze in den tempel, vijf aan de rechterhand, en vijf aan de linkerhand. [^7] Ook maakte hij tien tafelen, en hij zette ze in den tempel, vijf aan de rechterhand, en vijf aan de linkerhand; en hij maakte honderd gouden sprengbekkens. [^8] Verder maakte hij het voorhof der priesteren, en het grote voorhof, mitsgaders de deuren voor het voorhof, en overtoog hun deuren met koper. [^9] De zee nu zette hij aan de rechterzijde, naar het oosten, tegenover het zuiden. [^10] Daartoe maakte Huram de potten, en de schoffelen, en de sprengbekkens; alzo voleindde Huram het werk te maken, dat hij voor den koning Salomo aan het huis Gods maakte. [^11] De twee pilaren, en de bollen, en de twee kapitelen, op het hoofd der pilaren; en de twee netten, om de twee bollen der kapitelen te bedekken, die op der pilaren hoofd waren; [^12] En de vierhonderd granaatappelen tot de twee netten: twee rijen van granaatappelen tot elk net, om de twee bollen der kapitelen te bedekken, die boven op de pilaren waren. [^13] Hij maakte ook de stellingen; en wasvaten maakte hij op de stellingen; [^14] Eén zee, en de twaalf runderen daaronder. [^15] Insgelijks de potten, en de schoffelen, en de krauwelen, en al hun vaten maakte Huram Abi voor den koning Salomo, voor het huis des HEEREN, van gepolijst koper. [^16] In de vlakte van de Jordaan goot ze de koning, in dichte aarde, tussen Sukkoth, en tussen Zeredatha. [^17] En Salomo maakte al deze vaten, in grote menigte; want het gewicht des kopers werd niet onderzocht. [^18] Ook maakte Salomo alle vaten, die voor het huis Gods waren, en het gouden altaar, en de tafelen, waarop de toonbroden zijn; [^19] En de kandelaren met hun lampen, van gesloten goud, om die naar de wijze aan te steken, voor de aanspraakplaats; [^20] En de bloemen, en de lampen, en de snuiters, van goud; het was het volmaaktste goud; [^21] Mitsgaders de gaffelen, en de sprengbekkens, en de rookschalen, en de wierookvaten, van gesloten goud; aangaande den ingang van het huis, zijn binnenste deuren, van het heilige der heiligen, en de deuren van het huis des tempels waren van goud. [^22] 

[[2 Kronieken - 3|<--]] 2 Kronieken - 4 [[2 Kronieken - 5|-->]]

---
# Notes
