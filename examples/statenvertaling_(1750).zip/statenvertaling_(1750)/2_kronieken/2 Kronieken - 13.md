---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kronieken"
  - "#bible/testament/old"
aliases:
  - "2 Kronieken - 13 - Statenvertaling (1750)"
---
[[2 Kronieken - 12|<--]] 2 Kronieken - 13 [[2 Kronieken - 14|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[2 Kronieken]]

# 2 Kronieken - 13

In het achttiende jaar van den koning Jerobeam, zo werd Abia koning over Juda. [^1] Hij regeerde drie jaren te Jeruzalem; en de naam zijner moeder was Michaja, de dochter van Uriël, van Gibea; en er was krijg tussen Abia en tussen Jerobeam. [^2] En Abia bond den strijd aan met een heir van strijdbare helden, vierhonderd duizend uitgelezen mannen; en Jerobeam stelde tegen hem de slagorde, met achthonderd duizend uitgelezen mannen, kloeke helden. [^3] En Abia maakte zich op van boven den berg Zemaraïm, dewelke is in het gebergte van Efraïm; en hij zeide: Hoort mij toe, Jerobeam, en gans Israël! [^4] Staat het u niet toe te weten, dat de HEERE, de God Israëls, het koninkrijk over Israël aan David gegeven heeft, tot in eeuwigheid, hem en zijn zonen, met een zoutverbond? [^5] Evenwel is Jerobeam, de zoon van Nebat, de knecht van Salomo, den zoon van David, opgestaan, en heeft gerebelleerd tegen zijn heer. [^6] Daartoe hebben zich ijdele mannen, kinderen Belials, tot hem vergaderd, en hebben zich sterk gemaakt tegen Rehabeam, den zoon van Salomo, als Rehabeam jong was en teder van hart, dat hij zich tegen hen niet kon versterken. [^7] En nu, gij denkt u te versterken tegen het koninkrijk des HEEREN, hetwelk in de hand is der zonen van David; gij zijt wel een grote menigte, maar gij hebt gouden kalveren bij u, die u Jerobeam tot goden gemaakt heeft. [^8] Hebt gij niet de priesteren des HEEREN, de zonen van Aäron, en de Levieten uitgedreven, en hebt u priesteren gemaakt, gelijk de volken der landen? Een iegelijk, die komt om zijn hand te vullen met een jong rund en zeven rammen, die wordt priester dergenen, die geen goden zijn. [^9] Maar ons aangaande, de HEERE is onze God, en wij hebben Hem niet verlaten; en de priesters, die den HEERE dienen, zijn de zonen van Aäron, en de Levieten zijn in het werk. [^10] En zij steken aan voor den HEERE brandofferen, op elken morgen en op elken avond, ook reukwerk van welriekende specerijen, nevens de toerichting des broods op de reine tafel, en den gouden kandelaar en zijn lampen, om die op elken avond te doen branden; want wij nemen waar de wacht des HEEREN, onzes Gods; maar gij hebt Hem verlaten. [^11] Daarom ziet, God is met ons aan de spitse, en Zijn priesteren met de trompetten des geklanks, om tegen u alarmgeklank te maken; o kinderen Israëls, strijdt niet tegen den HEERE, den God uwer vaderen, want gij zult geen voorspoed hebben. [^12] Maar Jerobeam deed een achterlage omwenden, om van achter hen te komen; zo waren zij voor het aangezicht van Juda, en de achterlage was achter hen. [^13] Toen nu Juda omzag, ziet, zo hadden zij den strijd voor en achter; en zij riepen tot den HEERE, en de priesters trompetten met de trompetten. [^14] En de mannen van Juda maakten een alarmgeschrei; en het geschiedde, als de mannen van Juda een alarmgeschrei maakten, dat God Jerobeam en het ganse Israël sloeg voor Abia en Juda. [^15] En de kinderen Israëls vloden voor het aangezicht van Juda; en God gaf hen in hun hand. [^16] Abia dan, en zijn volk, sloeg hen met een groten slag; want uit Israël vielen verslagen vijfhonderd duizend uitgelezen mannen. [^17] Alzo werden de kinderen Israëls vernederd te dier tijd; maar de kinderen van Juda werden machtig, dewijl zij op den HEERE, hunner vaderen God, gesteund hadden. [^18] En Abia jaagde Jerobeam achterna, en nam van hem de steden, Beth-El met haar onderhorige plaatsen, en Jesana met haar onderhorige plaatsen, en Efron met haar onderhorige plaatsen. [^19] En Jerobeam behield geen kracht meer in de dagen van Abia; maar de HEERE sloeg hem, dat hij stierf. [^20] Zo versterkte zich Abia; en hij nam zich veertien vrouwen, en gewon twee en twintig zonen en zestien dochteren. [^21] Het overige nu der geschiedenissen van Abia, zo zijn wegen als zijn woorden, zijn beschreven in de historie van den profeet Iddo. [^22] 

[[2 Kronieken - 12|<--]] 2 Kronieken - 13 [[2 Kronieken - 14|-->]]

---
# Notes
