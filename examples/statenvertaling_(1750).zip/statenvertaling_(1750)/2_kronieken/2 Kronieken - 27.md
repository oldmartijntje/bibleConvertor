---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kronieken"
  - "#bible/testament/old"
aliases:
  - "2 Kronieken - 27 - Statenvertaling (1750)"
---
[[2 Kronieken - 26|<--]] 2 Kronieken - 27 [[2 Kronieken - 28|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[2 Kronieken]]

# 2 Kronieken - 27

Jotham was vijf en twintig jaren oud, toen hij koning werd, en hij regeerde zestien jaren te Jeruzalem; en de naam zijner moeder was Jerusa, een dochter van Zadok. [^1] En hij deed dat recht was in de ogen des HEEREN, naar alles, wat zijn vader Uzzia gedaan had, behalve dat hij in den tempel des HEEREN niet ging; en het volk verdierf zich nog. [^2] Dezelve bouwde de hoge poort aan het huis des HEEREN; hij bouwde ook veel aan den muur van Ofel. [^3] Daartoe bouwde hij steden op het gebergte van Juda; en in de wouden bouwde hij burchten en torens. [^4] Hij krijgde ook tegen den koning der kinderen Ammons, en had de overhand over hen, zodat de kinderen Ammons in datzelfde jaar hem gaven honderd talenten zilvers, en tien duizend kor tarwe, en tien duizend gerst; dit brachten hem de kinderen Ammons wederom, ook in het tweede en in het derde jaar. [^5] Alzo versterkte zich Jotham; want hij richtte zijn wegen voor het aangezicht des HEEREN, zijns Gods. [^6] Het overige nu der geschiedenissen van Jotham, en al zijn krijgen, en zijn wegen, ziet, zij zijn geschreven in het boek der koningen van Israël en Juda. [^7] Hij was vijf en twintig jaren oud, toen hij koning werd; en hij regeerde zestien jaren te Jeruzalem. [^8] En Jotham ontsliep met zijn vaderen, en zij begroeven hem in de stad Davids; en zijn zoon Achaz werd koning in zijn plaats. [^9] 

[[2 Kronieken - 26|<--]] 2 Kronieken - 27 [[2 Kronieken - 28|-->]]

---
# Notes
