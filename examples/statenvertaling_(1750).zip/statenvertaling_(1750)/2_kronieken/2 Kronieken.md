---
translation: Statenvertaling (1750)
aliases:
  - "2 Kronieken - Statenvertaling (1750)"
tags:
  - "#bible/type/book"
  - "#bible/book/2_kronieken"
  - "#bible/testament/old"
---
[[1 Kronieken|<--]] 2 Kronieken [[Ezra|-->]]

# 2 Kronieken - Statenvertaling (1750)

The 2 Kronieken book has 36 chapters. It is part of the old testament.

## Chapters

- 2 Kronieken [[2 Kronieken - 1|chapter 1]]
- 2 Kronieken [[2 Kronieken - 2|chapter 2]]
- 2 Kronieken [[2 Kronieken - 3|chapter 3]]
- 2 Kronieken [[2 Kronieken - 4|chapter 4]]
- 2 Kronieken [[2 Kronieken - 5|chapter 5]]
- 2 Kronieken [[2 Kronieken - 6|chapter 6]]
- 2 Kronieken [[2 Kronieken - 7|chapter 7]]
- 2 Kronieken [[2 Kronieken - 8|chapter 8]]
- 2 Kronieken [[2 Kronieken - 9|chapter 9]]
- 2 Kronieken [[2 Kronieken - 10|chapter 10]]
- 2 Kronieken [[2 Kronieken - 11|chapter 11]]
- 2 Kronieken [[2 Kronieken - 12|chapter 12]]
- 2 Kronieken [[2 Kronieken - 13|chapter 13]]
- 2 Kronieken [[2 Kronieken - 14|chapter 14]]
- 2 Kronieken [[2 Kronieken - 15|chapter 15]]
- 2 Kronieken [[2 Kronieken - 16|chapter 16]]
- 2 Kronieken [[2 Kronieken - 17|chapter 17]]
- 2 Kronieken [[2 Kronieken - 18|chapter 18]]
- 2 Kronieken [[2 Kronieken - 19|chapter 19]]
- 2 Kronieken [[2 Kronieken - 20|chapter 20]]
- 2 Kronieken [[2 Kronieken - 21|chapter 21]]
- 2 Kronieken [[2 Kronieken - 22|chapter 22]]
- 2 Kronieken [[2 Kronieken - 23|chapter 23]]
- 2 Kronieken [[2 Kronieken - 24|chapter 24]]
- 2 Kronieken [[2 Kronieken - 25|chapter 25]]
- 2 Kronieken [[2 Kronieken - 26|chapter 26]]
- 2 Kronieken [[2 Kronieken - 27|chapter 27]]
- 2 Kronieken [[2 Kronieken - 28|chapter 28]]
- 2 Kronieken [[2 Kronieken - 29|chapter 29]]
- 2 Kronieken [[2 Kronieken - 30|chapter 30]]
- 2 Kronieken [[2 Kronieken - 31|chapter 31]]
- 2 Kronieken [[2 Kronieken - 32|chapter 32]]
- 2 Kronieken [[2 Kronieken - 33|chapter 33]]
- 2 Kronieken [[2 Kronieken - 34|chapter 34]]
- 2 Kronieken [[2 Kronieken - 35|chapter 35]]
- 2 Kronieken [[2 Kronieken - 36|chapter 36]]

[[1 Kronieken|<--]] 2 Kronieken [[Ezra|-->]]

---
# Notes
