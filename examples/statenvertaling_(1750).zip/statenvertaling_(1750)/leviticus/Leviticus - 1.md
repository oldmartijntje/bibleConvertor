---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 1 - Statenvertaling (1750)"
---
Leviticus - 1 [[Leviticus - 2|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Leviticus]]

# Leviticus - 1

En de HEERE riep Mozes, en sprak tot hem uit de tent der samenkomst, zeggende: [^1] Spreek tot de kinderen Israëls, en zeg tot hen: Als een mens uit u den HEERE een offerande zal offeren, gij zult uw offeranden offeren van het vee, van runderen en van schapen. [^2] Indien zijn offerande een brandoffer van runderen is, zo zal hij een volkomen mannetje offeren; aan de deur van de tent der samenkomst zal hij dat offeren, naar zijn welgevallen, voor het aangezicht des HEEREN. [^3] En hij zal zijn hand op het hoofd des brandoffers leggen, opdat het voor hem aangenaam zij, om hem te verzoenen. [^4] Daarna zal hij het jonge rund slachten voor het aangezicht des HEEREN; en de zonen van Aäron, de priesters, zullen het bloed offeren, en het bloed sprengen rondom dat altaar, hetwelk voor de deur van de tent der samenkomst is. [^5] Dan zal hij het brandoffer de huid aftrekken, en het in zijn stukken delen. [^6] En de zonen van Aäron, den priester, zullen vuur maken op het altaar, en zullen het hout op het vuur schikken. [^7] Ook zullen de zonen van Aäron, de priesters, de stukken, het hoofd en het smeer, schikken op het hout, dat op het vuur is, hetwelk op het altaar is. [^8] Doch zijn ingewand, en zijn schenkelen zal men met water wassen; en de priester zal dat alles aansteken op het altaar; het is een brandoffer, een vuuroffer, tot een liefelijken reuk den HEERE. [^9] En indien zijn offerande is van kleinvee, van schapen of van geiten, ten brandoffer, zal hij een volkomen mannetje offeren. [^10] En hij zal dat slachten aan de zijde van het altaar noordwaarts, voor het aangezicht des HEEREN; en de zonen van Aäron, de priesters, zullen zijn bloed rondom op het altaar sprengen. [^11] Daarna zal hij het in zijn stukken delen, mitsgaders zijn hoofd en zijn smeer; en de priester zal die schikken op het hout, dat op het vuur is, hetwelk op het altaar is. [^12] Doch het ingewand en de schenkelen zal men met water wassen; en de priester zal dat alles offeren en aansteken op het altaar; het is een brandoffer, een vuuroffer, tot een liefelijken reuk den HEERE. [^13] En indien zijn offerande voor den HEERE een brandoffer van gevogelte is, zo zal hij zijn offerande van tortelduiven, of van jonge duiven, offeren. [^14] En de priester zal die tot het altaar brengen, en deszelfs hoofd met zijn nagel splijten, en op het altaar aansteken; en zijn bloed zal aan den wand des altaars uitgeduwd worden. [^15] En zijn krop met zijn vederen zal hij wegdoen, en zal het werpen bij het altaar, oostwaarts, aan de plaats der as. [^16] Verder zal hij die met zijn vleugelen klieven, niet afscheiden; en de priester zal die aansteken op het altaar, op het hout, dat op het vuur is; het is een brandoffer, een vuuroffer, tot een liefelijken reuk den HEERE. [^17] 

Leviticus - 1 [[Leviticus - 2|-->]]

---
# Notes
