---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 9 - Statenvertaling (1750)"
---
[[Leviticus - 8|<--]] Leviticus - 9 [[Leviticus - 10|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Leviticus]]

# Leviticus - 9

En het geschiedde op den achtsten dag, dat Mozes riep Aäron en zijn zonen, en de oudsten van Israël; [^1] En hij zeide tot Aäron: Neem u een kalf, een jong rund, ten zondoffer, en een ram ten brandoffer, die volkomen zijn; en breng ze voor het aangezicht des HEEREN. [^2] Daarna spreek tot de kinderen Israëls, zeggende: Neemt een geitenbok ten zondoffer, en een kalf, en een lam, eenjarig, volkomen, ten brandoffer; [^3] Ook een os en ram ten dankoffer, om voor het aangezicht des HEEREN te offeren; en spijsoffer met olie gemengd; want heden zal de HEERE u verschijnen. [^4] Toen namen zij hetgeen Mozes geboden had, brengende dat tot voor aan de tent der samenkomst; en de gehele vergadering naderde, en stond voor het aangezicht des HEEREN. [^5] En Mozes zeide: Deze zaak, die de HEERE geboden heeft, zult gij doen; en de heerlijkheid des HEEREN zal u verschijnen. [^6] En Mozes zeide tot Aäron: Nader tot het altaar, en maak uw zondoffer, en uw brandoffer toe; en doe verzoening voor u en voor het volk; maak daarna de offerande des volks toe, en doe de verzoening voor hen, gelijk als de HEERE geboden heeft. [^7] Toen naderde Aäron tot het altaar, en slachtte het kalf des zondoffers, dat voor hem was. [^8] En de zonen van Aäron brachten het bloed tot hem, en hij doopte zijn vinger in dat bloed, en deed het op de hoornen des altaars; daarna goot hij het bloed uit aan den bodem des altaars. [^9] Maar het vet, en de nieren, en het net van de lever van het zondoffer heeft hij op het altaar aangestoken, gelijk als de HEERE Mozes geboden had. [^10] Doch het vlees, en de huid verbrandde hij met vuur buiten het leger. [^11] Daarna slachtte hij het brandoffer; en de zonen van Aäron leverden aan hem het bloed; en hij sprengde dat rondom op het altaar. [^12] Ook leverden zij aan hem het brandoffer in zijn stukken, met het hoofd; en hij stak het aan op het altaar. [^13] En hij wies het ingewand en de schenkelen; en hij stak ze aan op het brandoffer, op het altaar. [^14] Daarna deed hij de offerande des volks toebrengen; en nam den bok des zondoffers, die voor het volk was, en slachtte hem, en bereidde hem ten zondoffer, gelijk het eerste. [^15] Verder deed hij het brandoffer toebrengen, en maakte dat toe naar het recht. [^16] En hij deed het spijsoffer toebrengen, en vulde daarvan zijn hand, en stak het aan op het altaar, behalve het morgenbrandoffer. [^17] Daarna slachtte hij den os, en den ram ten dankoffer, dat voor het volk was; en de zonen van Aäron leverden het bloed aan hem, hetwelk hij rondom op het altaar sprengde; [^18] En het vet van den os, en van den ram, den staart, en wat het ingewand bedekt, en de nieren, en het net der lever; [^19] En zij legden het vet op de borsten; en hij stak dat vet aan op het altaar. [^20] Maar de borsten en den rechterschouder bewoog Aäron ten beweegoffer voor het aangezicht des HEEREN, gelijk als Mozes geboden had. [^21] Daarna hief Aäron zijn handen op tot het volk, en zegende hen; en hij kwam af, nadat hij het zondoffer, en brandoffer, en dankoffer gedaan had. [^22] Toen ging Mozes met Aäron in de tent der samenkomst; daarna kwamen zij uit, en zegenden het volk; en de heerlijkheid des HEEREN verscheen al het volk. [^23] Want een vuur ging uit van het aangezicht des HEEREN, en verteerde op het altaar het brandoffer, en het vet. Als het ganse volk dit zag, zo juichten zij, en vielen op hun aangezichten. [^24] 

[[Leviticus - 8|<--]] Leviticus - 9 [[Leviticus - 10|-->]]

---
# Notes
