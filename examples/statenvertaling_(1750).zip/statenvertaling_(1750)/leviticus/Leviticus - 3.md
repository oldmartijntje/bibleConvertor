---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 3 - Statenvertaling (1750)"
---
[[Leviticus - 2|<--]] Leviticus - 3 [[Leviticus - 4|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Leviticus]]

# Leviticus - 3

En indien zijn offerande een dankoffer is; zo hij ze van de runderen offert, hetzij mannetje of wijfje, volkomen zal hij die offeren, voor het aangezicht des HEEREN. [^1] En hij zal zijn hand op het hoofd zijner offerande leggen, en zal ze slachten voor de deur van de tent der samenkomst; en de zonen van Aäron, de priesters, zullen het bloed rondom op het altaar sprengen. [^2] Daarna zal hij van dat dankoffer een vuuroffer den HEERE offeren; het vet, dat het ingewand bedekt, en al het vet, hetwelk aan het ingewand is. [^3] Dan zal hij beide de nieren, en het vet, hetwelk daaraan is, dat aan de weekdarmen is; en het net over de lever, met de nieren, zal hij afnemen. [^4] En de zonen van Aäron zullen dat aansteken op het altaar, op het brandoffer, hetwelk op het hout zal zijn, dat op het vuur is; het is een vuuroffer, tot een liefelijken reuk den HEERE. [^5] En indien zijn offerande van klein vee is, den HEERE tot een dankoffer, hetzij mannetje of wijfje, volkomen zal hij die offeren. [^6] Indien hij een lam tot zijn offerande offert, zo zal hij het offeren voor het aangezicht des HEEREN. [^7] En hij zal zijn hand op het hoofd zijner offerande leggen, en hij zal die slachten voor de tent der samenkomst; en de zonen van Aäron zullen het bloed daarvan sprengen op het altaar rondom. [^8] Daarna zal hij van dat dankoffer een vuuroffer den HEERE offeren; zijn vet, den gehelen staart, dien hij dicht aan de ruggegraat zal afnemen, en het vet bedekkende het ingewand, en al het vet, dat aan het ingewand is; [^9] Ook beide de nieren, en het vet, dat daaraan is, dat aan de weekdarmen is; en het net over de lever met de nieren, zal hij afnemen. [^10] En de priester zal dat aansteken op het altaar; het is een spijs des vuuroffers den HEERE. [^11] Indien nu zijn offerande een geit is, zo zal hij die offeren voor het aangezicht des HEEREN. [^12] En hij zal zijn hand op haar hoofd leggen, en hij zal haar slachten voor de tent der samenkomst; en de zonen van Aäron zullen haar bloed op het altaar sprengen rondom. [^13] Dan zal hij daarvan zijn offerande offeren, een vuuroffer den HEERE; het vet bedekkende het ingewand, en al het vet, dat aan het ingewand is; [^14] Mitsgaders de beide nieren, en het vet, dat daaraan is, dat aan de weekdarmen is; en het net over de lever, met de nieren, zal hij afnemen. [^15] En de priester zal die aansteken op het altaar; het is een spijs des vuuroffers, tot een liefelijken reuk; alle vet zal des HEEREN zijn. [^16] Dit zij een eeuwige inzetting voor uw geslachten, in al uw woningen: geen vet noch bloed zult gij eten. [^17] 

[[Leviticus - 2|<--]] Leviticus - 3 [[Leviticus - 4|-->]]

---
# Notes
