---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 18 - Statenvertaling (1750)"
---
[[Leviticus - 17|<--]] Leviticus - 18 [[Leviticus - 19|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Leviticus]]

# Leviticus - 18

Verder sprak de HEERE tot Mozes, zeggende: [^1] Spreek tot de kinderen Israëls en zeg tot hen: Ik ben de HEERE, uw God! [^2] Gij zult niet doen naar de werken des Egyptischen lands, waarin gij gewoond hebt; en naar de werken des lands Kanaän, waarheen Ik u brenge, zult gij niet doen, en zult in hun inzettingen niet wandelen. [^3] Mijn rechten zult gij doen, en Mijn inzettingen zult gij houden, om in die te wandelen; Ik ben de HEERE, uw God! [^4] Ja, Mijn inzettingen en Mijn rechten zult gij houden; welk mens dezelve zal doen, die zal door dezelve leven; Ik ben de HEERE! [^5] Niemand zal tot enige nabestaande zijns vleses naderen, om de schaamte te ontdekken; Ik ben de HEERE! [^6] Gij zult de schaamte uws vaders en de schaamte uwer moeder niet ontdekken; zij is uw moeder; gij zult haar schaamte niet ontdekken. [^7] Gij zult de schaamte der huisvrouw uws vaders niet ontdekken; het is de schaamte uws vaders. [^8] De schaamte uwer zuster, der dochter uws vaders, of der dochter uwer moeder, te huis geboren of buiten geboren, haar schaamte zult gij niet ontdekken. [^9] De schaamte der dochter uws zoons, of der dochter uwer dochter, haar schaamte zult gij niet ontdekken; want zij zijn uw schaamte. [^10] De schaamte van de dochter der huisvrouw uws vaders, die uw vader geboren is (zij is uw zuster), haar schaamte zult gij niet ontdekken. [^11] Gij zult de schaamte van de zuster uws vaders niet ontdekken; zij is uws vaders nabestaande. [^12] Gij zult de schaamte van de zuster uwer moeder niet ontdekken; want zij is uwer moeder nabestaande. [^13] Gij zult de schaamte van den broeder uws vaders niet ontdekken; tot zijn huisvrouw zult gij niet naderen; zij is uw moei. [^14] Gij zult de schaamte uwer schoondochter niet ontdekken; zij is uws zoons huisvrouw; gij zult haar schaamte niet ontdekken. [^15] Gij zult de schaamte der huisvrouw uws broeders niet ontdekken; het is de schaamte uws broeders. [^16] Gij zult de schaamte ener vrouw en harer dochter niet ontdekken; de dochter haars zoons, noch de dochter van haar dochter zult gij nemen, om haar schaamte te ontdekken; zij zijn nabestaanden; het is een schandelijke daad. [^17] Gij zult ook geen vrouw tot haar zuster nemen, om haar te benauwen, mits haar schaamte nevens haar, in haar leven, te ontdekken. [^18] Ook zult gij tot de vrouw in de afzondering van haar onreinigheid niet naderen, om haar schaamte te ontdekken. [^19] En gij zult niet liggen bij uws naasten huisvrouw ter bezading, om met haar onrein te worden. [^20] En van uw zaad zult gij niet geven, om voor den Molech door het vuur te doen gaan; en den Naam uws Gods zult gij niet ontheiligen; Ik ben de HEERE! [^21] Bij een manspersoon zult gij niet liggen met vrouwelijke bijligging; dit is een gruwel. [^22] Insgelijks zult gij bij geen beest liggen, om daarmede onrein te worden; een vrouw zal ook niet staan voor een beest, om daarmede te doen te hebben; het is een gruwelijke vermenging. [^23] Verontreinigt u niet met enige van deze; want de heidenen, die Ik van uw aangezicht uitwerpe, zijn met alle deze verontreinigd; [^24] Zodat het land onrein is, en Ik over hetzelve zijn ongerechtigheid bezoeke, en het land zijn inwoners uitspuwt. [^25] Maar gij zult Mijn inzettingen en Mijn rechten onderhouden, en van al die gruwelen niets doen, inboorling noch vreemdeling, die in het midden van u als vreemdeling verkeert. [^26] Want de lieden dezes lands, die voor u geweest zijn, hebben al deze gruwelen gedaan; en het land is onrein geworden. [^27] Dat u dat land niet uitspuwe, als gij hetzelve zult verontreinigd hebben; gelijk als het het volk, dat voor u was, uitgespuwd heeft. [^28] Want al wie enige van deze gruwelen doen zal, die zielen, die ze doen, zullen uit het midden van haar volk uitgeroeid worden. [^29] Daarom zult gij Mijn bevel onderhouden, dat gij niet doet van die gruwelijke inzettingen, die voor u zijn gedaan geweest, en u daarmede niet verontreinigt; Ik ben de HEERE, uw God! [^30] 

[[Leviticus - 17|<--]] Leviticus - 18 [[Leviticus - 19|-->]]

---
# Notes
