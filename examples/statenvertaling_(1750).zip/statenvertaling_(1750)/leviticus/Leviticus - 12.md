---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 12 - Statenvertaling (1750)"
---
[[Leviticus - 11|<--]] Leviticus - 12 [[Leviticus - 13|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Leviticus]]

# Leviticus - 12

Verder sprak de HEERE tot Mozes, zeggende: [^1] Spreek tot de kinderen Israëls, zeggende: Wanneer een vrouw zaad gegeven, en een knechtje gebaard zal hebben, zo zal zij zeven dagen onrein zijn; volgens de dagen der afzondering harer krankheid zal zij onrein zijn. [^2] En op den achtsten dag zal het vlees zijner voorhuid besneden worden. [^3] Daarna zal zij drie en dertig dagen blijven in het bloed harer reiniging; niets heiligs zal zij aanroeren, en tot het heiligdom zal zij niet komen, totdat de dagen harer reiniging vervuld zijn. [^4] Maar indien zij een meisje gebaard zal hebben, zo zal zij twee weken onrein zijn, volgens haar afzondering; daarna zal zij zes en zestig dagen blijven in het bloed harer reiniging. [^5] En als de dagen harer reiniging voor den zoon, of voor de dochter, vervuld zullen zijn, zo zal zij een eenjarig lam ten brandoffer, en een jonge duif, of tortelduif, ten zondoffer brengen, voor de deur van de tent der samenkomst, tot den priester. [^6] Die zal dat offeren voor het aangezicht des HEEREN, en zal voor haar verzoening doen, zo zal zij rein zijn van den vloed haars bloeds. Dit is de wet dergene, die een knechtje of meisje gebaard heeft. [^7] Maar indien haar hand niet genoeg voor een lam vindt, zo zal zij twee tortelduiven, of twee jonge duiven nemen, een ten brandoffer, en een ten zondoffer; en de priester zal voor haar verzoening doen; zo zal zij rein zijn. [^8] 

[[Leviticus - 11|<--]] Leviticus - 12 [[Leviticus - 13|-->]]

---
# Notes
