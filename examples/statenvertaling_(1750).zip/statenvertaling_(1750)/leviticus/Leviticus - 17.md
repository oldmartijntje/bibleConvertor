---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 17 - Statenvertaling (1750)"
---
[[Leviticus - 16|<--]] Leviticus - 17 [[Leviticus - 18|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Leviticus]]

# Leviticus - 17

Verder sprak de HEERE tot Mozes, zeggende: [^1] Spreek tot Aäron, en tot zijn zonen, en tot al de kinderen Israëls, en zeg tot hen: Dit is het woord, hetwelk de HEERE geboden heeft, zeggende: [^2] Een ieder van het huis Israëls, die een os, of lam, of geit in het leger slachten zal, of die ze slachten zal buiten het leger; [^3] En dezelve aan de deur van de tent der samenkomst niet brengen zal, om een offerande den HEERE voor den tabernakel des HEEREN te offeren; het bloed zal dienzelven man toegerekend worden, hij heeft bloed vergoten; daarom zal dezelve man uit het midden zijns volks uitgeroeid worden; [^4] Opdat, wanneer de kinderen Israëls hun slachtofferen brengen, welke zij op het veld slachten, dat zij die den HEERE toebrengen, aan de deur van de tent der samenkomst tot den priester, en dezelve tot dankofferen den HEERE slachten. [^5] En de priester zal het bloed op het altaar des HEEREN, aan de deur van de tent der samenkomst, sprengen; en hij zal het vet aansteken, tot een liefelijken reuk den HEERE. [^6] En zij zullen ook niet meer hun slachtofferen den duivelen, welke zij nahoereren, offeren; dat zal hun een eeuwige inzetting zijn voor hun geslachten. [^7] Zeg dan tot hen: Een ieder van het huis Israëls, en van de vreemdelingen, die in het midden van hen als vreemdelingen verkeren, die een brandoffer of slachtoffer zal offeren, [^8] En dat tot de deur van de tent der samenkomst niet zal brengen, om hetzelve den HEERE te bereiden; diezelve man zal uit zijn volken uitgeroeid worden. [^9] En een ieder uit het huis Israëls, en uit de vreemdelingen, die in het midden van hen als vreemdelingen verkeren, die enig bloed zal gegeten hebben, tegen diens ziel, die dat bloed zal gegeten hebben, zal Ik Mijn aangezicht zetten, en zal die uit het midden haars volks uitroeien. [^10] Want de ziel van het vlees is in het bloed; daarom heb Ik het u op het altaar gegeven, om over uw zielen verzoening te doen; want het is het bloed, dat voor de ziel verzoening zal doen. [^11] Daarom heb Ik tot de kinderen Israëls gezegd: Geen ziel van u zal bloed eten; noch de vreemdeling, die als vreemdeling in het midden van u verkeert, zal bloed eten. [^12] Een ieder ook van de kinderen Israëls en van de vreemdelingen, die als vreemdelingen in het midden van hen verkeren, die enig wild gedierte, of gevogelte, dat gegeten wordt, in de jacht gevangen zal hebben; die zal deszelfs bloed vergieten, en zal dat met stof bedekken. [^13] Want het is de ziel van alle vlees; zijn bloed is voor zijn ziel; daarom heb Ik tot de kinderen Israëls gezegd: Gij zult geens vleses bloed eten; want de ziel van alle vlees, dat is zijn bloed; zo wie dat eet, zal uitgeroeid worden. [^14] En alle ziel onder de inboorlingen of onder de vreemdelingen, die een dood aas of het verscheurde zal gegeten hebben, die zal zijn klederen wassen, en zich met water baden, en onrein zijn tot aan den avond; daarna zal hij rein zijn. [^15] Maar indien hij die niet wast, en zijn vlees niet baadt, zo zal hij zijn ongerechtigheid dragen. [^16] 

[[Leviticus - 16|<--]] Leviticus - 17 [[Leviticus - 18|-->]]

---
# Notes
