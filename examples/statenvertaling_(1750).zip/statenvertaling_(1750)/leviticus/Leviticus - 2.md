---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 2 - Statenvertaling (1750)"
---
[[Leviticus - 1|<--]] Leviticus - 2 [[Leviticus - 3|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Leviticus]]

# Leviticus - 2

Als nu een ziel een offerande van spijsoffer den HEERE zal offeren, zijn offerande zal van meelbloem zijn; en hij zal olie daarop gieten, en wierook daarop leggen. [^1] En hij zal het brengen tot de zonen van Aäron, de priesters, een van welke daarvan zijn hand vol grijpen zal uit deszelfs meelbloem, en uit deszelfs olie, met al deszelfs wierook; en de priester zal deszelfs gedenkoffer aansteken op het altaar; het is een vuuroffer, tot een liefelijken reuk den HEERE. [^2] Wat nu overblijft van het spijsoffer, zal voor Aäron en zijn zonen zijn; het is een heiligheid der heiligheden van de vuurofferen des HEEREN. [^3] En als gij offeren zult een offerande van spijsoffer, een gebak des ovens; het zullen zijn ongezuurde koeken van meelbloem, met olie gemengd, en ongezuurde vladen, met olie bestreken. [^4] En indien uw offerande spijsoffer is, in de pan gekookt, zij zal zijn van ongezuurde meelbloem, met olie gemengd. [^5] Breekt ze in stukken, en giet olie daarop; het is een spijsoffer. [^6] En zo uw offerande een spijsoffer des ketels is, het zal van meelbloem met olie gemaakt worden. [^7] Dan zult gij dat spijsoffer, hetwelk daarvan zal gemaakt worden, den HEERE toebrengen; en men zal het tot den priester doen naderen, die het tot het altaar dragen zal. [^8] En de priester zal van dat spijsoffer deszelfs gedenkoffer opnemen, en op het altaar aansteken, het is een vuuroffer, tot een liefelijken reuk den HEERE. [^9] En wat overblijft van het spijsoffer, zal voor Aäron en zijn zonen zijn; het is een heiligheid der heiligheden van de vuurofferen des HEEREN. [^10] Geen spijsoffer, dat gij den HEERE zult offeren, zal met desem gemaakt worden; want van geen zuurdesem, en van geen honig zult gijlieden den HEERE vuuroffer aansteken. [^11] De offeranden der eerstelingen zult gij den HEERE offeren; maar op het altaar zullen zij niet komen tot een liefelijken reuk. [^12] En alle offerande uws spijsoffers zult gij met zout zouten, en het zout des verbonds van uw God van uw spijsoffer niet laten afblijven; met al uw offerande zult gij zout offeren. [^13] En zo gij den HEERE een spijsoffer der eerste vruchten offert, zult gij het spijsoffer uwer eerste vruchten van groene aren, bij het vuur gedord, dat is, het klein gebroken graan van volle groene aren, offeren. [^14] En gij zult olie daarop doen, en wierook daarop leggen; het is een spijsoffer. [^15] Zo zal de priester deszelfs gedenkoffer aansteken van zijn klein gebroken graan en van zijn olie, met al den wierook; het is een vuuroffer den HEERE. [^16] 

[[Leviticus - 1|<--]] Leviticus - 2 [[Leviticus - 3|-->]]

---
# Notes
