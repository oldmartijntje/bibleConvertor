---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 24 - Statenvertaling (1750)"
---
[[Leviticus - 23|<--]] Leviticus - 24 [[Leviticus - 25|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Leviticus]]

# Leviticus - 24

En de HEERE sprak tot Mozes, zeggende: [^1] Gebied den kinderen Israëls, dat zij tot u brengen zuivere gestoten olijfolie, voor den luchter, om de lampen gedurig aan te steken. [^2] Aäron zal die voor het aangezicht des HEEREN gedurig toerichten, van den avond tot den morgen, buiten den voorhang van de getuigenis, in de tent der samenkomst; het is een eeuwige inzetting voor uw geslachten. [^3] Hij zal op den louteren kandelaar die lampen voor het aangezicht des HEEREN gedurig toerichten. [^4] Gij zult ook meelbloem nemen, en twaalf koeken daarvan bakken; van twee tienden zal een koek zijn. [^5] En gij zult ze in twee rijen leggen, zes in een rij, op de reine tafel, voor het aangezicht des HEEREN. [^6] En op elke rij zult gij zuiveren wierook leggen, welke het brood ten gedenkoffer zal zijn; het is een vuuroffer den HEERE. [^7] Op elken sabbatdag gedurig zal men dat voor het aangezicht des HEEREN toerichten, vanwege de kinderen Israëls, tot een eeuwig verbond. [^8] En het zal voor Aäron en zijn zonen zijn, die dat in de heilige plaats zullen eten; want het is voor hem een heiligheid der heiligheden uit de vuurofferen des HEEREN, een eeuwige inzetting. [^9] En er ging de zoon ener Israëlietische vrouw uit, die, in het midden der kinderen Israëls, de zoon van een Egyptische man was; en de zoon van deze Israëlietische en een Israëlietisch man twistten in het leger. [^10] Toen lasterde de zoon der Israëlietische vrouw uitdrukkelijk den NAAM, en vloekte; daarom brachten zij hem tot Mozes; de naam nu zijner moeder was Selomith, de dochter van Dibri, van den stam Dan. [^11] En zij leidden hem in de gevangenis, opdat hem, naar den mond des HEEREN, verklaring geschieden zou. [^12] En de HEERE sprak tot Mozes, zeggende: [^13] Breng den vloeker uit tot buiten het leger, en allen, die het gehoord hebben, zullen hun handen op zijn hoofd leggen; daarna zal hem de gehele vergadering stenigen. [^14] En tot de kinderen Israëls zult gij spreken, zeggende: Een ieder, als hij zijn God gevloekt zal hebben, zo zal hij zijn zonde dragen. [^15] En wie den Naam des HEEREN gelasterd zal hebben, zal zekerlijk gedood worden; de ganse vergadering zal hem zekerlijk stenigen; alzo zal de vreemdeling zijn, gelijk de inboorling, als hij den NAAM zal gelasterd hebben, hij zal gedood worden. [^16] En als iemand enige ziel des mensen zal verslagen hebben, hij zal zekerlijk gedood worden. [^17] Maar wie de ziel van enig vee zal verslagen hebben, hij zal het wedergeven, ziel voor ziel. [^18] Als ook iemand aan zijn naaste een gebrek zal aangebracht hebben; gelijk als hij gedaan heeft, zo zal ook aan hem gedaan worden: [^19] Breuk voor breuk, oog voor oog, tand voor tand; gelijk als hij een gebrek een mens zal aangebracht hebben, zo zal ook hem aangebracht worden. [^20] Wie dan enig vee verslaat, die zal het wedergeven; maar wie een mens verslaat, die zal gedood worden. [^21] Enerlei recht zult gij hebben; zo zal de vreemdeling zijn, als de inboorling; want Ik ben de HEERE, uw God! [^22] En Mozes zeide tot de kinderen Israëls, dat zij den vloeker tot buiten het leger uitbrengen, en hem met stenen stenigen zouden. En de kinderen Israëls deden, gelijk als de HEERE Mozes geboden had. [^23] 

[[Leviticus - 23|<--]] Leviticus - 24 [[Leviticus - 25|-->]]

---
# Notes
