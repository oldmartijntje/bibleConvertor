---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 10 - Statenvertaling (1750)"
---
[[Leviticus - 9|<--]] Leviticus - 10 [[Leviticus - 11|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Leviticus]]

# Leviticus - 10

En de zonen van Aäron, Nadab en Abihu, namen een ieder zijn wierookvat, en deden vuur daarin, en legden reukwerk daarop, en brachten vreemd vuur voor het aangezicht des HEEREN, hetwelk Hij hun niet geboden had. [^1] Toen ging een vuur uit van het aangezicht des HEEREN, en verteerde hen; en zij stierven voor het aangezicht des HEEREN. [^2] En Mozes zeide tot Aäron: Dat is het, wat de HEERE gesproken heeft, zeggende: In degenen, die tot Mij naderen, zal Ik geheiligd worden, en voor het aangezicht van al het volk zal Ik verheerlijkt worden. Doch Aäron zweeg stil. [^3] En Mozes riep Misaël en Elzafan, de zonen van Uzziël, den oom van Aäron, en zeide tot hen: Treedt toe, draagt uw broederen weg, van voor het heiligdom tot buiten het leger. [^4] Toen traden zij toe, en droegen hen, in hun rokken, tot buiten het leger, gelijk als Mozes gesproken had. [^5] En Mozes zeide tot Aäron, en tot Eleazar, en tot Ithamar, zijn zonen: Gij zult uw hoofden niet ontbloten, noch uw klederen verscheuren, opdat gij niet sterft, en grote toorn over de ganse vergadering kome; maar uw broederen, het ganse huis van Israël, zullen dezen brand, dien de HEERE aan gestoken heeft, bewenen. [^6] Gij zult ook uit de deur van de tent der samenkomst niet uitgaan, opdat gij niet sterft; want de zalfolie des HEEREN is op u. En zij deden naar het woord van Mozes. [^7] En de HEERE sprak tot Aäron, zeggende: [^8] Wijn en sterken drank zult gij niet drinken, gij, noch uw zonen met u, als gij gaan zult in de tent der samenkomst, opdat gij niet sterft; het zij een eeuwige inzetting onder uw geslachten; [^9] En om onderscheid te maken tussen het heilige en tussen het onheilige, en tussen het onreine en tussen het reine; [^10] En om den kinderen Israëls te leren al de inzettingen, die de HEERE door den dienst van Mozes tot hen gesproken heeft. [^11] En Mozes sprak tot Aäron, en tot Eleazar, en tot Ithamar, zijn overgebleven zonen: Neemt het spijsoffer, dat van de vuurofferen des HEEREN overgebleven is, en eet hetzelve ongezuurd bij het altaar; want het is een heiligheid der heiligheden. [^12] Daarom zult gij dat eten in de heilige plaats, dewijl het uw bescheiden deel en het bescheiden deel uwer zonen uit des HEEREN vuurofferen is; want alzo is mij geboden. [^13] Ook de beweegborst en den hefschouder zult gij in een reine plaats eten, gij, en uw zonen, en uw dochteren met u; want tot uw bescheiden deel, en uwer zonen bescheiden deel, zijn zij uit de dankofferen der kinderen Israëls gegeven. [^14] Den hefschouder en de beweegborst zullen zij nevens de vuurofferen des vets toebrengen, om ten beweegoffer voor het aangezicht des HEEREN te bewegen; hetwelk, voor u en uw zonen met u, tot een eeuwige inzetting zijn zal, gelijk als de HEERE geboden heeft. [^15] En Mozes zocht zeer naarstiglijk den bok des zondoffers; en ziet, hij was verbrand. Dies was hij op Eleazar en op Ithamar, de overgebleven zonen van Aäron, zeer toornig, zeggende: [^16] Waarom hebt gij dat zondoffer niet gegeten in de heilige plaats? Want het is een heiligheid der heiligheden, en Hij heeft u dat gegeven, opdat gij de ongerechtigheid der vergadering zoudt dragen, om over die verzoening te doen voor het aangezicht des HEEREN. [^17] Ziet, deszelfs bloed is niet binnen in het heiligdom gedragen; gij moest dat ganselijk gegeten hebben in het heiligdom, gelijk als ik geboden heb. [^18] Toen sprak Aäron tot Mozes: Zie, heden hebben zij hun zondoffer en hun brandoffer voor het aangezicht des HEEREN geofferd, en zulke dingen zijn mij wedervaren; en had ik heden het zondoffer gegeten, zou dat goed geweest zijn in de ogen des HEEREN? [^19] Als Mozes dit hoorde, zo was het goed in zijn ogen. [^20] 

[[Leviticus - 9|<--]] Leviticus - 10 [[Leviticus - 11|-->]]

---
# Notes
