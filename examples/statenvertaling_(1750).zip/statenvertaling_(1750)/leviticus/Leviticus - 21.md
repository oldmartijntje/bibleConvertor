---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 21 - Statenvertaling (1750)"
---
[[Leviticus - 20|<--]] Leviticus - 21 [[Leviticus - 22|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Leviticus]]

# Leviticus - 21

Daarna zeide de HEERE tot Mozes: Spreek tot de priesters, de zonen van Aäron, en zeg tot hen: Over een dode zal een priester zich niet verontreinigen onder zijn volken. [^1] Behalve over zijn bloedvriend, die hem ten naaste bestaat, over zijn moeder en over zijn vader, en over zijn zoon, en over zijn dochter, en over zijn broeder. [^2] En over zijn zuster, die maagd is, hem nabestaande, die nog geen man toebehoord heeft; over die zal hij zich verontreinigen. [^3] Hij zal zich niet verontreinigen over een overste onder zijn volken, om zich te ontheiligen. [^4] Zij zullen op hun hoofd geen kaalheid maken, en zullen den hoek van hun baard niet afscheren, en in hun vlees zullen zij geen sneden snijden. [^5] Zij zullen hun God heilig zijn, en den Naam huns Gods zullen zij niet ontheiligen; want zij offeren de vuurofferen des HEEREN, de spijze huns Gods; daarom zullen zij heilig zijn. [^6] Zij zullen geen vrouw nemen, die een hoer of ontheiligde is, noch een vrouw nemen, die van haar man verstoten is; want hij is zijn God heilig. [^7] Daarom zult gij hem heiligen, omdat hij de spijze uws Gods offert; hij zal u heilig zijn, want Ik ben heilig; Ik ben de HEERE, Die u heilige! [^8] Als nu de dochter van enigen priester zal beginnen te hoereren, zij ontheiligt haar vader; met vuur zal zij verbrand worden. [^9] En hij, die de hogepriester onder zijn broederen is, op wiens hoofd de zalfolie gegoten is, en wiens hand men gevuld heeft, om die klederen aan te trekken, zal zijn hoofd niet ontbloten, noch zijn klederen scheuren. [^10] Hij zal ook bij geen dode lichamen komen; zelfs over zijn vader en over zijn moeder zal hij zich niet verontreinigen. [^11] En uit het heiligdom zal hij niet uitgaan, dat hij het heiligdom zijns Gods niet ontheilige, want de kroon der zalfolie zijns Gods is op hem; Ik ben de HEERE! [^12] Hij zal ook een vrouw in haar maagdom nemen. [^13] Een weduwe, of verstotene, of ontheiligde hoer, dezulke zal hij niet nemen; maar een maagd uit zijn volken zal hij tot een vrouw nemen. [^14] En hij zal zijn zaad onder zijn volken niet ontheiligen; want Ik ben de HEERE, Die hem heilige! [^15] Wijders sprak de HEERE tot Mozes, zeggende: [^16] Spreek tot Aäron, zeggende: Niemand uit uw zaad, naar hun geslachten, in wien een gebrek zal zijn, zal naderen, om de spijze zijns Gods te offeren. [^17] Want geen man, in wien een gebrek zal zijn, zal naderen, hij zij een blind man, of kreupel, of te kort, of te lang in leden; [^18] Of een man, in wien een breuk des voets, of een breuk der hand zal zijn; [^19] Of die bultachtig, of dwergachtig zal zijn, of een vel op zijn oog zal hebben, of droge schurftheid, of etterige schurftheid, of die gebroken zal zijn aan zijn gemacht. [^20] Geen man, uit het zaad van Aäron, den priester, in wien een gebrek is, zal toetreden om de vuurofferen des HEEREN te offeren; een gebrek is in hem, hij zal niet toetreden, om de spijs zijns Gods te offeren. [^21] De spijs zijns Gods, van de allerheiligste dingen, en van de heilige dingen, zal hij mogen eten; [^22] Doch tot den voorhang zal hij niet komen, en tot het altaar niet toetreden, omdat een gebrek in hem is; opdat hij Mijn heiligdommen niet ontheilige; want Ik ben de HEERE, Die hen heilige! [^23] En Mozes sprak zulks tot Aäron en tot zijn zonen, en tot al de kinderen Israëls. [^24] 

[[Leviticus - 20|<--]] Leviticus - 21 [[Leviticus - 22|-->]]

---
# Notes
