---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/rechters"
  - "#bible/testament/old"
aliases:
  - "Rechters - 12 - Statenvertaling (1750)"
---
[[Rechters - 11|<--]] Rechters - 12 [[Rechters - 13|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Rechters]]

# Rechters - 12

Toen werden de mannen van Efraïm bijeengeroepen, en trokken over naar het noorden; en zij zeiden tot Jeftha: Waarom zijt gij doorgetogen om te strijden tegen de kinderen Ammons, en hebt ons niet geroepen, om met u te gaan? wij zullen uw huis met u met vuur verbranden. [^1] En Jeftha zeide tot hen: Ik en mijn volk waren zeer twistig met de kinderen Ammons; en ik heb ulieden geroepen, maar gij hebt mij uit hun hand niet verlost. [^2] Als ik nu zag, dat gij niet verlostet, zo stelde ik mijn ziel in mijn hand, en toog door tot de kinderen Ammons, en de HEERE gaf hen in mijn hand; waarom zijt gij dan te dezen dage tot mij opgekomen, om tegen mij te strijden? [^3] En Jeftha vergaderde alle mannen van Gilead, en streed met Efraïm; en de mannen van Gilead sloegen Efraïm, want de Gileadieten, zijnde tussen Efraïm en tussen Manasse, zeiden: Gijlieden zijt vluchtelingen van Efraïm. [^4] Want de Gileadieten namen den Efraïmieten de veren van de Jordaan af; en het geschiedde, als de vluchtelingen van Efraïm zeiden: Laat mij overgaan; zo zeiden de mannen van Gilead tot hem: Zijt gij een Efraïmiet? wanneer hij zeide: Neen; [^5] Zo zeiden zij tot hem: Zeg nu Schibboleth; maar hij zeide: Sibbolet, en kon het alzo niet recht spreken; zo grepen zij hem, en versloegen hem aan de veren van de Jordaan, dat te dier tijd van Efraïm vielen twee en veertig duizend. [^6] Jeftha nu richtte Israël zes jaren; en Jeftha, de Gileadiet, stierf, en werd begraven in de steden van Gilead. [^7] En na hem richtte Israël Ebzan, van Bethlehem. [^8] En hij had dertig zonen; en hij zond dertig dochteren naar buiten, en bracht dertig dochteren van buiten in voor zijn zonen; en hij richtte Israël zeven jaren. [^9] Toen stierf Ebzan, en werd begraven te Bethlehem. [^10] En na hem richtte Israël Elon, de Zebuloniet, en hij richtte Israël tien jaren. [^11] En Elon, de Zebuloniet, stierf, en werd begraven te Ajalon, in het land van Zebulon. [^12] En na hem richtte Israël Abdon, een zoon van Hillel, de Pirhathoniet. [^13] En hij had veertig zonen, en dertig zoons zonen, rijdende op zeventig ezelveulens; en hij richtte Israël acht jaren. [^14] Toen stierf Abdon, een zoon van Hillel, de Pirhathoniet; en hij werd begraven te Pirhathon, in het land van Efraïm, op den berg van den Amalekiet. [^15] 

[[Rechters - 11|<--]] Rechters - 12 [[Rechters - 13|-->]]

---
# Notes
