---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/rechters"
  - "#bible/testament/old"
aliases:
  - "Rechters - 15 - Statenvertaling (1750)"
---
[[Rechters - 14|<--]] Rechters - 15 [[Rechters - 16|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Rechters]]

# Rechters - 15

En het geschiedde na sommige dagen, in de dagen van den tarweoogst, dat Simson zijn huisvrouw bezocht met een geitenbokje, en hij zeide: Laat mij tot mijn huisvrouw ingaan in de kamer; maar haar vader liet hem niet toe in te gaan. [^1] Want haar vader zeide: Ik sprak zeker, dat gij haar ganselijk haattet, zo heb ik haar aan uw metgezel gegeven. Is niet haar kleinste zuster schoner dan zij? Laat ze u toch zijn in de plaats van haar. [^2] Toen zeide Simson tot henlieden: Ik ben ditmaal onschuldig van de Filistijnen, wanneer ik aan hen kwaad doe. [^3] En Simson ging heen, en ving driehonderd vossen; en hij nam fakkelen, en keerde staart aan staart, en deed een fakkel tussen twee staarten in het midden. [^4] En hij stak de fakkelen aan met vuur, en liet ze lopen in het staande koren der Filistijnen; en hij stak in brand zowel de korenhopen als het staande koren, zelfs tot de wijngaarden en olijfbomen toe. [^5] Toen zeiden de Filistijnen: Wie heeft dit gedaan? En men zeide: Simson, de schoonzoon van den Thimniet, omdat hij zijn huisvrouw heeft genomen, en heeft haar aan zijn metgezel gegeven. Toen kwamen de Filistijnen op, en verbrandden haar en haar vader met vuur. [^6] Toen zeide Simson tot hen: Zoudt gij alzo doen? Zeker, als ik mij aan u gewroken heb, zo zal ik daarna ophouden. [^7] En hij sloeg hen, den schenkel en de heup, met een groten slag; en hij ging af, en woonde op de hoogte van de rots Etam. [^8] Toen togen de Filistijnen op, en legerden zich tegen Juda, en breidden zich uit in Lechi. [^9] En de mannen van Juda zeiden: Waarom zijt gijlieden tegen ons opgetogen? En zij zeiden: Wij zijn opgetogen om Simson te binden, om hem te doen, gelijk als hij ons gedaan heeft. [^10] Toen kwamen drie duizend mannen af uit Juda tot het hol der rots Etam, en zeiden tot Simson: Wist gij niet, dat de Filistijnen over ons heersen? Waarom hebt gij ons dan dit gedaan? En hij zeide tot hen: Gelijk als zij mij gedaan hebben, alzo heb ik hunlieden gedaan. [^11] En zij zeiden tot hem: Wij zijn afgekomen om u te binden, om u over te geven in de hand der Filistijnen. Toen zeide Simson tot hen: Zweert mij, dat gijlieden op mij niet zult aanvallen. [^12] En zij spraken tot hem, zeggende: Neen, maar wij zullen u wel binden, en u in hunlieder hand overgeven; doch wij zullen u geenszins doden. En zij bonden hem met twee nieuwe touwen, en voerden hem op van de rots. [^13] Als hij kwam tot Lechi, zo juichten de Filistijnen hem tegemoet; maar de Geest des HEEREN werd vaardig over hem; en de touwen, die aan zijn armen waren, werden als linnen draden, die van het vuur gebrand zijn, en zijn banden versmolten van zijn handen. [^14] En hij vond een vochtig ezelskinnebakken, en hij strekte zijn hand uit, en nam het, en sloeg daarmede duizend man. [^15] Toen zeide Simson: Met een ezelskinnebakken, een hoop, twee hopen, met een ezelskinnebakken heb ik duizend man geslagen. [^16] En het geschiedde, als hij geëindigd had te spreken, zo wierp hij het kinnebakken uit zijn hand, en hij noemde dezelve plaats Ramath-Lechi. [^17] Als hem nu zeer dorstte, zo riep hij tot den HEERE, en zeide: Gij hebt door de hand van Uw knecht dit grote heil gegeven; zou ik dan nu van dorst sterven, en vallen in de hand dezer onbesnedenen? [^18] Toen kloofde God de holle plaats, die in Lechi is, en er ging water uit van dezelve, en hij dronk. Toen kwam zijn geest weder, en hij werd levend. Daarom noemde hij haar naam: De fontein des aanroepers, die in Lechi is, tot op dezen dag. [^19] En hij richtte Israël, in de dagen der Filistijnen, twintig jaren. [^20] 

[[Rechters - 14|<--]] Rechters - 15 [[Rechters - 16|-->]]

---
# Notes
