---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/rechters"
  - "#bible/testament/old"
aliases:
  - "Rechters - 2 - Statenvertaling (1750)"
---
[[Rechters - 1|<--]] Rechters - 2 [[Rechters - 3|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Rechters]]

# Rechters - 2

En een Engel des HEEREN kwam opwaarts van Gilgal tot Bochim, en Hij zeide: Ik heb ulieden uit Egypte opgevoerd, en u gebracht in het land, dat Ik uw vaderen gezworen heb, en gezegd: Ik zal Mijn verbond met ulieden niet verbreken in eeuwigheid. [^1] En ulieden aangaande, gij zult geen verbond maken met de inwoners dezes lands; hun altaren zult gij afbreken. Maar gij zijt Mijner stem niet gehoorzaam geweest; waarom hebt gij dit gedaan? [^2] Daarom heb Ik ook gezegd: Ik zal hen voor uw aangezicht niet uitdrijven; maar zij zullen u aan de zijden zijn, en hun goden zullen u tot een strik zijn. [^3] En het geschiedde, als de Engel des HEEREN deze woorden tot alle kinderen Israëls gesproken had, zo hief het volk zijn stem op en weende. [^4] Daarom noemden zij den naam dier plaats Bochim; en zij offerden aldaar den HEERE. [^5] Als Jozua het volk had laten gaan, zo waren de kinderen Israëls heengegaan, een ieder tot zijn erfdeel, om het land erfelijk te bezitten. [^6] En het volk diende den HEERE, al de dagen van Jozua, en al de dagen der oudsten, die lang geleefd hadden na Jozua; die gezien hadden al dat grote werk des HEEREN, dat Hij aan Israël gedaan had. [^7] Maar als Jozua, de zoon van Nun, de knecht des HEEREN, gestorven was, honderd en tien jaren oud zijnde; [^8] En zij hem begraven hadden in de landpale zijns erfdeels, te Timnath-Heres, op een berg van Efraïm, tegen het noorden van den berg Gaäs; [^9] En al datzelve geslacht ook tot zijn vaderen vergaderd was; zo stond er een ander geslacht na hen op, dat den HEERE niet kende, noch ook het werk, dat Hij aan Israël gedaan had. [^10] Toen deden de kinderen Israëls, dat kwaad was in de ogen des HEEREN, en zij dienden de Baäls. [^11] En zij verlieten den HEERE, hunner vaderen God, Die hen uit Egypteland had uitgevoerd, en volgden andere goden na, van de goden der volken, die rondom hen waren, en bogen zich voor die, en zij verwekten den HEERE tot toorn. [^12] Want zij verlieten den HEERE, en dienden den Baäl en Astharoth. [^13] Zo ontstak des HEEREN toorn tegen Israël, en Hij gaf hen in de hand der rovers, die hen beroofden; en Hij verkocht hen in de hand hunner vijanden rondom; en zij konden niet meer bestaan voor het aangezicht hunner vijanden. [^14] Overal, waarheen zij uittogen, was de hand des HEEREN tegen hen, ten kwade, gelijk als de HEERE gesproken, en gelijk als de HEERE hun gezworen had; en hun was zeer bang. [^15] En de HEERE verwekte richteren, die hen verlosten uit de hand dergenen, die hen beroofden; [^16] Doch zij hoorden ook niet naar hun richteren, maar hoereerden andere goden na, en bogen zich voor die; haast weken zij af van den weg, dien hun vaders gewandeld hadden, horende de geboden des HEEREN; alzo deden zij niet. [^17] En wanneer de HEERE hun richteren verwekte, zo was de HEERE met den richter, en verloste hen uit de hand hunner vijanden, al de dagen des richters; want het berouwde den HEERE, huns zuchtens halve vanwege degenen, die hen drongen en die hen drukten. [^18] Maar het geschiedde met het versterven des richters, dat zij omkeerden, en verdierven het meer dan hun vaderen, navolgende andere goden, dezelve dienende, en zich voor die buigende; zij lieten niets vallen van hun werken, noch van dezen hun harden weg. [^19] Daarom ontstak de toorn des HEEREN tegen Israël, dat Hij zeide: Omdat dit volk Mijn verbond heeft overtreden, dat Ik hun vaderen geboden heb, en zij naar Mijn stem niet gehoord hebben; [^20] Zo zal Ik ook niet voortvaren voor hun aangezicht iemand uit de bezitting te verdrijven, van de heidenen, die Jozua heeft achtergelaten, als hij stierf; [^21] Opdat Ik Israël door hen verzoeke, of zij den weg des HEEREN zullen houden, om daarin te wandelen, gelijk als hun vaderen gehouden hebben, of niet. [^22] Alzo liet de HEERE deze heidenen blijven, dat Hij hen niet haastelijk uit de bezitting verdreef; die Hij in de hand van Jozua niet had overgegeven. [^23] 

[[Rechters - 1|<--]] Rechters - 2 [[Rechters - 3|-->]]

---
# Notes
