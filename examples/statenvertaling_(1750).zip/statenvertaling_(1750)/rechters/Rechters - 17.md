---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/rechters"
  - "#bible/testament/old"
aliases:
  - "Rechters - 17 - Statenvertaling (1750)"
---
[[Rechters - 16|<--]] Rechters - 17 [[Rechters - 18|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Rechters]]

# Rechters - 17

En er was een man van het gebergte van Efraïm, wiens naam was Micha. [^1] Die zeide tot zijn moeder: De duizend en honderd zilverlingen, die u ontnomen zijn, om dewelke gij gevloekt hebt, en ook voor mijn oren gesproken hebt, zie, dat geld is bij mij, ik heb dat genomen. Toen zeide zijn moeder: Gezegend zij mijn zoon den HEERE! [^2] Alzo gaf hij aan zijn moeder de duizend en honderd zilverlingen weder. Doch zijn moeder zeide: Ik heb dat geld den HEERE ganselijk geheiligd van mijn hand, voor mijn zoon, om een gesneden beeld en een gegoten beeld te maken; zo zal ik het u nu wedergeven. [^3] Maar hij gaf dat geld aan zijn moeder weder. En zijn moeder nam tweehonderd zilverlingen, en gaf ze den goudsmid, die maakte daarvan een gesneden beeld en een gegoten beeld; dat was in het huis van Micha. [^4] En de man Micha had een godshuis; en hij maakte een efod, en terafim, en vulde de hand van een uit zijn zonen, dat hij hem tot een priester ware. [^5] In diezelve dagen was er geen koning in Israël; een iegelijk deed, wat recht was in zijn ogen. [^6] Nu was er een jongeling van Bethlehem-Juda, van het geslacht van Juda; deze was een Leviet, en verkeerde aldaar als vreemdeling. [^7] En deze man was uit die stad, uit Bethlehem-Juda getogen, om te verkeren, waar hij gelegenheid zou vinden. Als hij nu kwam aan het gebergte van Efraïm tot aan het huis van Micha, om zijn weg te gaan, [^8] Zo zeide Micha tot hem: Van waar komt gij? En hij zeide tot hem: Ik ben een Leviet, van Bethlehem-Juda, en ik wandel, om te verkeren, waar ik gelegenheid zal vinden. [^9] Toen zeide Micha tot hem: Blijf bij mij, en wees mij tot een vader en tot een priester; en ik zal u jaarlijks geven tien zilverlingen, en orde van klederen, en uw leeftocht; alzo ging de Leviet met hem. [^10] En de Leviet bewilligde bij dien man te blijven; en de jongeling was hem als een van zijn zonen. [^11] En Micha vulde de hand van den Leviet, dat hij hem tot een priester wierd; alzo was hij in het huis van Micha. [^12] Toen zeide Micha: Nu weet ik, dat de HEERE mij weldoen zal, omdat ik dezen Leviet tot een priester heb. [^13] 

[[Rechters - 16|<--]] Rechters - 17 [[Rechters - 18|-->]]

---
# Notes
