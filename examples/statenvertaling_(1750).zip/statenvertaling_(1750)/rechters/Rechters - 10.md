---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/rechters"
  - "#bible/testament/old"
aliases:
  - "Rechters - 10 - Statenvertaling (1750)"
---
[[Rechters - 9|<--]] Rechters - 10 [[Rechters - 11|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Rechters]]

# Rechters - 10

Na Abimelech nu stond op, om Israël te behouden, Thola, een zoon van Pua, zoon van Dodo, een man van Issaschar; en hij woonde te Samir, op het gebergte van Efraïm. [^1] En hij richtte Israël drie en twintig jaren; en hij stierf, en werd begraven te Samir. [^2] En na hem stond op Jaïr, de Gileadiet; en hij richtte Israël twee en twintig jaren. [^3] En hij had dertig zonen, rijdende op dertig ezelveulens, en die hadden dertig steden, die zij noemden Havvoth-Jaïr, tot op dezen dag, dewelke in het land van Gilead zijn. [^4] En Jaïr stierf, en werd begraven te Kamon. [^5] Toen voeren de kinderen Israëls voort te doen, dat kwaad was in de ogen des HEEREN, en dienden de Baäls, en Astharoth, en de goden van Syrië, en de goden van Sidon, en de goden van Moab, en de goden der kinderen Ammons, mitsgaders de goden der Filistijnen; en zij verlieten den HEERE, en dienden Hem niet. [^6] Zo ontstak de toorn des HEEREN tegen Israël; en Hij verkocht hen in de hand der Filistijnen, en in de hand der kinderen Ammons. [^7] En zij onderdrukten en vertraden de kinderen Israëls in datzelve jaar; achttien jaren onderdrukten zij al de kinderen Israëls, die aan gene zijde van de Jordaan waren, in het land der Amorieten, dat in Gilead is. [^8] Daartoe togen de kinderen Ammons over de Jordaan, om te krijgen, zelfs tegen Juda, en tegen Benjamin, en tegen het huis van Efraïm; zodat het Israël zeer bang werd. [^9] Toen riepen de kinderen Israëls tot den HEERE, zeggende: Wij hebben tegen U gezondigd, zo omdat wij onzen God hebben verlaten, als dat wij de Baäls gediend hebben. [^10] Maar de HEERE zeide tot de kinderen Israëls: Heb Ik u niet van de Egyptenaren, en van de Amorieten, en van de kinderen Ammons, en van de Filistijnen, [^11] En de Sidoniërs, en Amalekieten, en Maonieten, die u onderdrukten, toen gij tot Mij riept, alsdan uit hun hand verlost? [^12] Nochtans hebt gij Mij verlaten, en andere goden gediend; daarom zal Ik u niet meer verlossen. [^13] Gaat henen, roept tot de goden, die gij verkoren hebt; laten die u verlossen, ter tijd uwer benauwdheid. [^14] Maar de kinderen Israëls zeiden tot den HEERE: Wij hebben gezondigd; doe Gij ons, naar alles, wat goed is in Uw ogen; alleenlijk verlos ons toch te dezen dage! [^15] En zij deden de vreemde goden uit hun midden weg, en dienden den HEERE. Toen werd Zijn ziel verdrietig over den arbeid van Israël. [^16] En de kinderen Ammons werden bijeengeroepen, en legerden zich in Gilead; daarentegen werden de kinderen Israëls vergaderd, en legerden zich te Mizpa. [^17] Toen zeide het volk, de oversten van Gilead, de een tot den ander: Wie is de man, die beginnen zal te strijden tegen de kinderen Ammons? die zal tot een hoofd zijn over alle inwoners van Gilead. [^18] 

[[Rechters - 9|<--]] Rechters - 10 [[Rechters - 11|-->]]

---
# Notes
