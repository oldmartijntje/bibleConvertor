---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/nehemia"
  - "#bible/testament/old"
aliases:
  - "Nehemia - 10 - Statenvertaling (1750)"
---
[[Nehemia - 9|<--]] Nehemia - 10 [[Nehemia - 11|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Nehemia]]

# Nehemia - 10

Tot de verzegelingen nu waren: Nehemia Hattirsatha, zoon van Hachalja, en Zidkia, [^1] Seraja, Azarja, Jeremia, [^2] Pashur, Amarja, Malchia, [^3] Hattus, Sebanja, Malluch, [^4] Harim, Meremoth, Obadja, [^5] Daniël, Ginnethon, Baruch, [^6] Mesullam, Abia, Mijamin, [^7] Maäzia, Bilgai, Semaja. Dit waren de priesters. [^8] En de Levieten, namelijk: Jesua, zoon van Azanja, Binnui; van de zonen van Henadad, Kadmiël; [^9] En hun broederen: Sebanja, Hodia, Kelita, Pelaja, Hanan, [^10] Micha, Rehob, Hasabja, [^11] Zakkur, Serebja, Sebanja, [^12] Hodia, Bani, Beninu; [^13] De hoofden des volks: Parhos, Pahath-Moab, Elam, Zatthu, Bani, [^14] Bunni, Azgad, Bebai, [^15] Adonia, Bigvai, Adin, [^16] Ater, Hizkia, Azzur, [^17] Hodia, Hasum, Bezai, [^18] Harif, Anathoth, Nebai, [^19] Magpias, Mesullam, Hezir, [^20] Mesezabeël, Zadok, Jaddua, [^21] Pelatja, Hanan, Anaja, [^22] Hoséa, Hananja, Hassub, [^23] Hallohes, Pilha, Sobek, [^24] Rehum, Hasabna, Maäseja, [^25] En Ahia, Hanan, Anan, [^26] Malluch, Harim, Baäna. [^27] En het overige des volks, de priesteren, de Levieten, de poortiers, de zangers, de Nethinim, en al wie zich van de volken der landen had afgescheiden tot Gods wet, hun vrouwen, hun zonen en hun dochteren, al wie wetenschap en verstand had; [^28] Die hielden zich aan hun broederen, hun voortreffelijken, en kwamen in den vloek en in den eed, dat zij zouden wandelen in de wet Gods, die gegeven is door de hand van den knecht Gods, Mozes; en dat zij zouden houden, en dat zij zouden doen al de geboden des HEEREN, onzes Heeren, en Zijn rechten en Zijn inzettingen; [^29] En dat wij onze dochteren niet zouden geven aan de volken des lands, noch hun dochteren nemen voor onze zonen. [^30] Ook als de volken des lands waren en alle koren op den sabbatdag ten verkoop brengen, dat wij op den sabbat, of op een anderen heiligen dag van hen niet zouden nemen; en dat wij het zevende jaar zouden vrij laten, mitsgaders allerhande bezwaarnis. [^31] Voorts zetten wij ons geboden op, ons opleggende een derde deel van een sikkel in het jaar, tot den dienst van het huis onzes Gods; [^32] Tot het brood der toerichting, en het gedurig spijsoffer, en tot het gedurig brandoffer, der sabbatten, der nieuwe maanden, tot de gezette hoogtijden, en tot de heilige dingen, en tot de zondofferen, om verzoening te doen over Israël; en tot alle werk van het huis onzes Gods. [^33] Ook wierpen wij de loten, onder de priesters, de Levieten en het volk, over het offer van het hout, dat men brengen zou ten huize onzes Gods, naar het huis onzer vaderen, op bestemde tijden, jaar op jaar, om te branden op het altaar des HEEREN, onzes Gods, gelijk het in de wet geschreven is; [^34] Dat wij ook de eerstelingen onzes lands en de eerstelingen van alle vrucht van al het geboomte, jaar op jaar, zouden brengen ten huize des HEEREN; [^35] En de eerstgeborenen onzer zonen en onzer beesten, gelijk het in de wet geschreven is; en dat wij de eerstgeborenen onzer runderen en onzer schapen zouden brengen ten huize onzes Gods, tot de priesteren, die in het huis onzes Gods dienen. [^36] En dat wij de eerstelingen onzes deegs, en onze hefofferen, en de vrucht aller bomen, most en olie, zouden brengen tot de priesteren, in de kameren van het huis onzes Gods, en de tienden onzes lands tot de Levieten; en dat dezelfde Levieten de tienden zouden hebben in alle steden onzer landbouwerij; [^37] En dat er een priester, een zoon van Aäron, bij de Levieten zou zijn, als de Levieten de tienden ontvangen; en dat de Levieten de tienden zouden opbrengen ten huize onzes Gods, in de kameren van het schathuis. [^38] Want de kinderen Israëls en de kinderen van Levi moeten hefoffer van koren, most en olie in die kameren brengen, omdat aldaar de vaten des heiligdoms zijn, en de priesteren, die dienen, en de poortiers, en de zangers; dat wij alzo het huis onzes Gods niet zouden verlaten. [^39] 

[[Nehemia - 9|<--]] Nehemia - 10 [[Nehemia - 11|-->]]

---
# Notes
