---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/nehemia"
  - "#bible/testament/old"
aliases:
  - "Nehemia - 1 - Statenvertaling (1750)"
---
Nehemia - 1 [[Nehemia - 2|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Nehemia]]

# Nehemia - 1

De geschiedenissen van Nehemia, zoon van Hachalja. En het geschiedde in de maand Chisleu, in het twintigste jaar, als ik te Susan in het paleis was; [^1] Zo kwam Hanani, een van mijn broederen, hij en sommige mannen uit Juda, en ik vraagde hen naar de Joden, die ontkomen waren (die overgebleven waren van de gevangenis), en naar Jeruzalem. [^2] En zij zeiden tot mij: De overgeblevenen, die van de gevangenis aldaar in het landschap zijn overgebleven, zijn in grote ellende en in versmaadheid; en Jeruzalems muur is verscheurd, en haar poorten zijn met vuur verbrand. [^3] En het geschiedde, als ik deze woorden hoorde, zo zat ik neder, en weende, en bedreef rouw, enige dagen; en ik was vastende en biddende voor het aangezicht van den God des hemels. [^4] En ik zeide: Och, HEERE, God des hemels, Gij, grote en vreselijke God! Die het verbond en de goedertierenheid houdt dien, die Hem liefhebben, en Zijn geboden houden. [^5] Laat toch Uw oor opmerkende, en Uw ogen open zijn, om te horen naar het gebed Uws knechts, dat ik heden voor Uw aangezicht bid, dag en nacht, voor de kinderen Israëls, Uw knechten; en ik doe belijdenis over de zonden der kinderen Israëls, die wij tegen U gezondigd hebben; ook ik en mijns vaders huis, wij hebben gezondigd. [^6] Wij hebben het ganselijk tegen U verdorven; en wij hebben niet gehouden de geboden, noch de inzettingen, noch de rechten, die Gij Uw knecht Mozes geboden hebt. [^7] Gedenk toch des woords, dat Gij Uw knecht Mozes geboden hebt, zeggende: Gijlieden zult overtreden, Ik zal u onder de volken verstrooien. [^8] En gij zult u tot Mij bekeren, en Mijn geboden houden, en die doen; al waren uw verdrevenen aan het einde des hemels, Ik zal hen vandaar verzamelen, en zal ze brengen tot de plaats, die Ik verkoren heb, om Mijn Naam aldaar te doen wonen. [^9] Zij zijn toch Uw knechten en Uw volk, dat Gij verlost hebt door Uw grote kracht en door Uw sterke hand. [^10] Och, Heere, laat toch Uw oor opmerkende zijn op het gebed Uws knechts, en op het gebed Uwer knechten, die lust hebben Uw Naam te vrezen; en doe het toch Uw knecht heden wel gelukken, en geef hem barmhartigheid voor het aangezicht dezes mans. Ik nu was des konings schenker. [^11] 

Nehemia - 1 [[Nehemia - 2|-->]]

---
# Notes
