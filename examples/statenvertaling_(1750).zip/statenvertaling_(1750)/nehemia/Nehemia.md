---
translation: Statenvertaling (1750)
aliases:
  - "Nehemia - Statenvertaling (1750)"
tags:
  - "#bible/type/book"
  - "#bible/book/nehemia"
  - "#bible/testament/old"
---
[[Ezra|<--]] Nehemia [[Esther|-->]]

# Nehemia - Statenvertaling (1750)

The Nehemia book has 13 chapters. It is part of the old testament.

## Chapters

- Nehemia [[Nehemia - 1|chapter 1]]
- Nehemia [[Nehemia - 2|chapter 2]]
- Nehemia [[Nehemia - 3|chapter 3]]
- Nehemia [[Nehemia - 4|chapter 4]]
- Nehemia [[Nehemia - 5|chapter 5]]
- Nehemia [[Nehemia - 6|chapter 6]]
- Nehemia [[Nehemia - 7|chapter 7]]
- Nehemia [[Nehemia - 8|chapter 8]]
- Nehemia [[Nehemia - 9|chapter 9]]
- Nehemia [[Nehemia - 10|chapter 10]]
- Nehemia [[Nehemia - 11|chapter 11]]
- Nehemia [[Nehemia - 12|chapter 12]]
- Nehemia [[Nehemia - 13|chapter 13]]

[[Ezra|<--]] Nehemia [[Esther|-->]]

---
# Notes
