---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/nehemia"
  - "#bible/testament/old"
aliases:
  - "Nehemia - 6 - Statenvertaling (1750)"
---
[[Nehemia - 5|<--]] Nehemia - 6 [[Nehemia - 7|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Nehemia]]

# Nehemia - 6

Voorts is het geschied, als van Sanballat, en Tobia, en van Gesem, den Arabier, en van onze andere vijanden gehoord was, dat ik den muur gebouwd had, en dat geen scheur daarin was overgelaten; ook had ik tot dezen tijd toe de deuren niet opgezet in de poorten; [^1] Zo zond Sanballat, en Gesem, tot mij, om te zeggen: Kom en laat ons te zamen vergaderen in de dorpen, in het dal Ono. Maar zij dachten mij kwaad te doen. [^2] En ik zond boden tot hen, om te zeggen: Ik doe een groot werk, zodat ik niet zal kunnen afkomen; waarom zou dit werk ophouden, terwijl ik het zou nalaten, en tot ulieden afkomen? [^3] Zij zonden nu wel viermaal tot mij, op dezelfde wijze. En ik antwoordde hun op dezelfde wijze. [^4] Toen zond Sanballat tot mij op dezelfde wijze, ten vijfden male, zijn jongen, met een open brief in zijn hand. [^5] Daarin was geschreven: Het is onder de volken gehoord, en Gasmu zegt: Gij en de Joden denkt te rebelleren, daarom bouwt gij den muur, en gij zult hun ten koning zijn; naar dat deze zaken zijn. [^6] Dat gij ook profeten hebt besteld, om van u te Jeruzalem uit te roepen, zeggende: Hij is koning in Juda. Nu zal het van den koning gehoord worden, naar dat deze zaken zijn; kom dan nu, en laat ons te zamen raadslaan. [^7] Doch ik zond tot hem, om te zeggen: Er is van al zulke zaken, als gij zegt, niets geschied; maar gij versiert ze uit uw hart. [^8] Want zij allen zochten ons vreesachtig te maken, zeggende: Hun handen zullen van het werk aflaten, dat het niet zal gedaan worden; nu dan, sterk mijn handen! [^9] Als ik nu kwam in het huis van Semaja, den zoon van Delaja, den zoon van Mehetabeël (hij nu was besloten), zo zeide hij: Laat ons samenkomen in het huis Gods, in het midden des tempels, en laat ons de deuren des tempels toesluiten; want zij zullen komen om u te doden, ja, bij nacht zullen zij komen, om u te doden. [^10] Maar ik zeide: Zou een man, als ik, vlieden? En wie is er, zijnde als ik, die in den tempel zou gaan, dat hij levend bleve? Ik zal er niet ingaan. [^11] Want ik merkte, en ziet, God had hem niet gezonden; maar hij sprak deze profetie tegen mij, omdat Tobia en Sanballat hem gehuurd hadden. [^12] Daarom was hij gehuurd, opdat ik zou vrezen, en alzo doen, en zondigen; opdat zij iets zouden hebben tot een kwaden naam, opdat zij mij zouden honen. [^13] Gedenk, mijn God, aan Tobia en aan Sanballat, naar deze zijn werken; en ook aan de profetes Noadja, en aan de andere profeten, die mij gezocht hebben vreesachtig te maken. [^14] De muur nu werd volbracht, op den vijf en twintigsten van Elul, in twee en vijftig dagen. [^15] En het geschiedde, als al onze vijanden dit hoorden, zo vreesden al de heidenen, die rondom ons waren, en zij vervielen zeer in hun ogen; want zij merkten, dat dit werk van onzen God gedaan was. [^16] Ook schreven in die dagen edelen van Juda vele brieven, die naar Tobia gingen; en die van Tobia kwamen tot hen. [^17] Want velen in Juda hadden hem gezworen, omdat hij was een schoonzoon van Sechanja, den zoon van Arah; en zijn zoon Johanan had genomen de dochter van Mesullam, den zoon van Berechja. [^18] Ook verhaalden zij zijn goeddadigheden voor mijn aangezicht, en mijn woorden brachten zij uit tot hem. Tobia dan zond brieven, om mij vreesachtig te maken. [^19] 

[[Nehemia - 5|<--]] Nehemia - 6 [[Nehemia - 7|-->]]

---
# Notes
