---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/nehemia"
  - "#bible/testament/old"
aliases:
  - "Nehemia - 8 - Statenvertaling (1750)"
---
[[Nehemia - 7|<--]] Nehemia - 8 [[Nehemia - 9|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Nehemia]]

# Nehemia - 8

Als nu de zevende maand aankwam, en de kinderen Israëls in hun steden waren, [^1] Zo verzamelde zich al het volk als een enig man op de straat voor de Waterpoort; en zij zeiden tot Ezra, den schriftgeleerde, dat hij het boek der wet van Mozes zou halen, die de HEERE Israël geboden had. [^2] En Ezra, de priester, bracht de wet voor de gemeente, beiden mannen en vrouwen, en allen, die verstandig waren om te horen, op den eersten dag der zevende maand. [^3] En hij las daarin voor de straat, die voor de Waterpoort is, van het morgen licht aan tot op den middag, voor de mannen en vrouwen, en de verstandigen; en de oren des gansen volks waren naar het wetboek. [^4] En Ezra, de schriftgeleerde, stond op een hogen houten stoel, dien zij tot die zaak gemaakt hadden, en nevens hem stond Mattithja, en Sema, en Anaja, en Uria, en Hilkia, en Maäseja, aan zijn rechterhand; en aan zijn linkerhand Pedaja, en Misaël, en Malchia, en Hasum, en Hasbaddana, Zacharja en Mesullam. [^5] En Ezra opende het boek voor de ogen des gansen volks, want hij was boven al het volk; en als hij het opende, stond al het volk. [^6] En Ezra loofde den HEERE, den groten God; en al het volk antwoordde: Amen, amen! met opheffing hunner handen, en neigden zich, en aanbaden den HEERE, met de aangezichten ter aarde. [^7] Jesua nu, en Bani, en Serebja, Jamin, Akkub, Sabbethai, Hodia, Maäseja, Kelita, Azaria, Jozabad, Hanan, Pelaja, en de Levieten onderwezen het volk in de wet. En het volk stond op zijn standplaats. [^8] En zij lazen in het boek, in de wet Gods, duidelijk; en den zin verklarende, zo maakten zij, dat men het verstond in het lezen. [^9] En Nehemia (dezelve is Hattirsatha) en Ezra, de priester, de schriftgeleerde, en de Levieten, die het volk onderwezen, zeiden tot al het volk: Deze dag is den HEERE, uw God, heilig; bedrijft dan geen rouw, en weent niet; want al het volk weende, als zij de woorden der wet hoorden. [^10] Voorts zeide hij tot hen: Gaat, eet het vette, en drinkt het zoete, en zendt delen dengenen, voor welken niets bereid is, want deze dag is onzen Heere heilig; zo bedroeft u niet, want de blijdschap des HEEREN, die is uw sterkte. [^11] En de Levieten stilden al het volk, zeggende: Zwijgt, want deze dag is heilig, daarom bedroeft u niet. [^12] Toen ging al het volk henen om te eten, en om te drinken, en om delen te zenden, en om grote blijdschap te maken; want zij hadden de woorden verstaan, die men hun had bekend gemaakt. [^13] En des anderen daags verzamelden zich de hoofden der vaderen van het ganse volk, de priesters en de Levieten, tot Ezra, den schriftgeleerde, en dat, om verstand te bekomen in de woorden der wet. [^14] En zij vonden in de wet geschreven, dat de HEERE door de hand van Mozes geboden had, dat de kinderen Israëls in loofhutten zouden wonen, op het feest in de zevende maand; [^15] En dat zij het zouden luidbaar maken, en een stem laten doorgaan door al hun steden, en te Jeruzalem, zeggende: Gaat uit op het gebergte, en haalt takken van olijfbomen, en takken van andere olieachtige bomen, en takken van mirtebomen, en takken van palmbomen, en takken van andere dichte bomen, om loofhutten te maken, als er geschreven is. [^16] Alzo ging het volk uit en haalden ze, en maakten zich loofhutten, een iegelijk op zijn dak, en in hun voorhoven, en in de voorhoven van Gods huis, en op de straat der Waterpoort, en op de straat van Efraïmspoort. [^17] En de ganse gemeente dergenen, die uit de gevangenis waren wedergekomen, maakten loofhutten, en woonden in die loofhutten; want de kinderen Israëls hadden alzo niet gedaan sinds de dagen van Jesua, den zoon van Nun, tot op dezen dag toe; en er was zeer grote blijdschap. [^18] En men las in het wetboek Gods dag bij dag, van den eersten dag tot den laatsten dag. En zij hielden het feest zeven dagen, en op den achtsten dag den verbodsdag, naar het recht. [^19] 

[[Nehemia - 7|<--]] Nehemia - 8 [[Nehemia - 9|-->]]

---
# Notes
