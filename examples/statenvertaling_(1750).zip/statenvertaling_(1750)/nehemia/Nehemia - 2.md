---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/nehemia"
  - "#bible/testament/old"
aliases:
  - "Nehemia - 2 - Statenvertaling (1750)"
---
[[Nehemia - 1|<--]] Nehemia - 2 [[Nehemia - 3|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Nehemia]]

# Nehemia - 2

Toen geschiedde het in de maand Nisan, in het twintigste jaar van den koning Arthahsasta, als er wijn voor zijn aangezicht was, dat ik den wijn opnam, en gaf hem den koning; nu was ik nooit treurig geweest voor zijn aangezicht. [^1] Zo zeide de koning tot mij: Waarom is uw aangezicht treurig, zo gij toch niet krank zijt? Dit is niet dan treurigheid des harten. Toen vreesde ik gans zeer. [^2] En ik zeide tot den koning: De koning leve in eeuwigheid! Hoe zou mijn aangezicht niet treurig zijn, daar de stad, de plaats der begrafenissen mijner vaderen, woest is, en haar poorten met vuur verteerd zijn? [^3] En de koning zeide tot mij: Wat verzoekt gij nu? Toen bad ik tot God van den hemel. [^4] En ik zeide tot den koning: Zo het den koning goeddunkt, en zo uw knecht voor uw aangezicht aangenaam is, dat gij mij zendt naar Juda, naar de stad der begrafenissen mijner vaderen, dat ik ze bouwe. [^5] Toen zeide de koning tot mij, daar de koningin nevens hem zat: Hoe lang zal uw reis wezen, en wanneer zult gij wederkomen? En het behaagde den koning, dat hij mij zond, als ik hem zekeren tijd gesteld had. [^6] Voorts zeide ik tot den koning: Zo het den koning goeddunkt, dat men mij brieven geve aan de landvoogden aan gene zijde der rivier, dat zij mij overgeleiden, totdat ik in Juda zal gekomen zijn; [^7] Ook een brief aan Asaf, den bewaarder van den lusthof, denwelken de koning heeft, dat hij mij hout geve om te zolderen de poorten van het paleis, dat aan het huis is, en tot den stadsmuur, en tot het huis, waar ik intrekken zal. En de koning gaf ze mij, naar de goede hand mijns Gods over mij. [^8] Toen kwam ik tot de landvoogden aan gene zijde der rivier, en gaf hun de brieven des konings. En de koning had oversten des heirs en ruiteren met mij gezonden. [^9] Toen nu Sanballat, de Horoniet, en Tobia, de Ammonietische knecht dat hoorden, mishaagde het hun met groot mishagen, dat er een mens gekomen was, om wat goeds te zoeken voor de kinderen Israëls. [^10] En ik kwam te Jeruzalem, en was daar drie dagen. [^11] Daarna maakte ik mij des nachts op, ik en weinig mannen met mij, en ik gaf geen mens te kennen, wat mijn God in mijn hart gegeven had, om aan Jeruzalem te doen; en er was geen dier met mij, dan het dier, waarop ik reed. [^12] En ik trok uit bij nacht door de Dalpoort, en voorbij de Drakenfontein, en naar de Mistpoort, en ik brak aan de muren van Jeruzalem, dewelke verscheurd waren, en haar poorten met vuur verteerd. [^13] En ik ging voort naar de Fonteinpoort, en naar des konings vijver; doch daar was geen plaats voor het dier, om onder mij voort te gaan. [^14] Toen ging ik op, des nachts, door de beek, en ik brak aan den muur; en ik keerde weder, en kwam in door de Dalpoort; alzo keerde ik wederom. [^15] En de overheden wisten niet, waar ik heengegaan was, en wat ik deed; want ik had tot nog toe den Joden, en den priesteren, en den edelen, en overheden, en den anderen, die het werk deden, niets te kennen gegeven. [^16] Toen zeide ik tot hen: Gijlieden ziet de ellende, waarin wij zijn, dat Jeruzalem woest is, en haar poorten met vuur verbrand zijn; komt, en laat ons Jeruzalems muur opbouwen; opdat wij niet meer een versmaadheid zijn. [^17] En ik gaf hun te kennen de hand mijns Gods, Die goed over mij geweest was, als ook de woorden des konings, die hij tot mij gesproken had. Toen zeiden zij: Laat ons op zijn, dat wij bouwen; en zij sterkten hun handen ten goede. [^18] Als nu Sanballat, de Horoniet, en Tobia, de Ammonietische knecht, en Gesem, de Arabier, dit hoorden, zo bespotten zij ons, en verachtten ons; en zij zeiden: Wat is dit voor een ding, dat gijlieden doet? Wilt gijlieden tegen den koning rebelleren? [^19] Toen gaf ik hun tot antwoord, en zeide tot hen: God van den hemel, Die zal het ons doen gelukken, en wij, Zijn knechten, zullen ons opmaken en bouwen; maar gijlieden hebt geen deel, noch gerechtigheid, noch gedachtenis in Jeruzalem. [^20] 

[[Nehemia - 1|<--]] Nehemia - 2 [[Nehemia - 3|-->]]

---
# Notes
