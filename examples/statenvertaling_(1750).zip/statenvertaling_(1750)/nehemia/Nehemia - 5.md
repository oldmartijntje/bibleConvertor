---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/nehemia"
  - "#bible/testament/old"
aliases:
  - "Nehemia - 5 - Statenvertaling (1750)"
---
[[Nehemia - 4|<--]] Nehemia - 5 [[Nehemia - 6|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Nehemia]]

# Nehemia - 5

Maar het geroep des volks en hunner vrouwen was groot, tegen hun broederen, de Joden. [^1] Want er waren, die zeiden: Onze zonen, en onze dochteren, wij zijn velen; daarom hebben wij koren opgenomen, opdat wij eten en leven. [^2] Ook waren er, die zeiden: Wij verpanden onze akkers, en onze wijngaarden, en onze huizen, opdat wij in dezen honger koren mogen opnemen. [^3] Desgelijks waren er, die zeiden: Wij hebben geld ontleend tot des konings cijns, op onze akkers en onze wijngaarden. [^4] Nu is toch ons vlees als het vlees onzer broederen, onze kinderen zijn als hun kinderen; en ziet, wij onderwerpen onze zonen en onze dochteren tot dienstknechten; ja, er zijn enige van onze dochteren onderworpen, dat zij in de macht onzer handen niet zijn; en anderen hebben onze akkers en onze wijngaarden. [^5] Toen ik nu hun geroep en deze woorden hoorde, ontstak ik zeer. [^6] En mijn hart beraadslaagde in mij; daarna twistte ik met de edelen, en met de overheden, en zeide tot hen: Gijlieden vordert een last, een iegelijk van zijn broeder. Voorts belegde ik een grote vergadering tegen hen. [^7] En ik zeide tot hen: Wij hebben onze broederen, de Joden, die aan de heidenen verkocht waren, naar ons vermogen wedergekocht; en zoudt gijlieden ook uw broederen verkopen, of zouden zij aan ons verkocht worden? Toen zwegen zij, en vonden geen antwoord. [^8] Voorts zeide ik: De zaak is niet goed, die gijlieden doet; zoudt gij niet wandelen in de vreze onzes Gods, om de versmading der heidenen, onze vijanden? [^9] Ik, mijn broederen, en mijn jongens, vorderen wij ook geld en koren van hen? Laat ons toch dezen last nalaten. [^10] Geeft hun toch als heden weder hun akkers, hun wijngaarden, hun olijfgaarden en hun huizen; en het honderdste deel van het geld, en van het koren, den most en de olie, die gij hun hebt afgevorderd. [^11] Toen zeiden zij: Wij zullen het wedergeven, en van hen niets zoeken; wij zullen alzo doen, als gij zegt. En ik riep de priesteren, en deed hen zweren, dat zij doen zouden naar dit woord. [^12] Ook schudde ik mijn boezem uit, en zeide: Alzo schudde God uit allen man, die dit woord niet zal bevestigen, uit zijn huis en uit zijn arbeid, en hij zij alzo uitgeschud en ledig. En de ganse gemeente zeide: Amen! En zij prezen den HEERE. En het volk deed naar dit woord. [^13] Ook van dien dag af, dat hij mij bevolen heeft hun landvoogd te zijn in het land Juda, van het twintigste jaar af, tot het twee en dertigste jaar van den koning Arthahsasta, zijnde twaalf jaren, heb ik, met mijn broederen, het brood des landvoogds niet gegeten. [^14] En de vorige landvoogden, die voor mij geweest zijn, hebben het volk bezwaard, en van hen genomen aan brood en wijn, daarna veertig zilveren sikkelen; ook heersten hun jongens over het volk; maar ik heb alzo niet gedaan, om der vreze Gods wil. [^15] Daartoe heb ik ook aan het werk dezes muurs verbeterd, en wij hebben geen land gekocht; en al mijn jongens zijn aldaar verzameld geweest tot het werk. [^16] Ook zijn van de Joden en van de overheden honderd en vijftig man, en die van de heidenen, die rondom ons zijn, tot ons kwamen, aan mijn tafel geweest. [^17] En wat voor een dag bereid werd, was één os en zes uitgelezen schapen; ook werden mij vogelen bereid, en binnen tien dagen van allen wijn zeer veel; nog heb ik bij dezen het brood des landvoogds niet gezocht, omdat de dienstbaarheid zwaar was over dit volk. [^18] Gedenk mijner, mijn God, ten goede, alles, wat ik aan dit volk gedaan heb. [^19] 

[[Nehemia - 4|<--]] Nehemia - 5 [[Nehemia - 6|-->]]

---
# Notes
