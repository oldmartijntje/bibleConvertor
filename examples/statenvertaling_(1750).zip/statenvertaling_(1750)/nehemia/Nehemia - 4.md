---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/nehemia"
  - "#bible/testament/old"
aliases:
  - "Nehemia - 4 - Statenvertaling (1750)"
---
[[Nehemia - 3|<--]] Nehemia - 4 [[Nehemia - 5|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[Nehemia]]

# Nehemia - 4

Maar het geschiedde, als Sanballat gehoord had, dat wij den muur bouwden, zo ontstak hij, en werd zeer toornig; en hij bespotte de Joden. [^1] En sprak in de tegenwoordigheid zijner broederen en van het heir van Samaria, en zeide: Wat doen deze amechtige Joden? Zal men hen laten geworden? Zullen zij offeren? Zullen zij het in een dag voleinden? Zullen zij de steentjes uit de stofhopen levend maken, daar zij verbrand zijn? [^2] En Tobia, de Ammoniet, was bij hem, en zeide: Al is het, dat zij bouwen, zo er een vos opkwame, hij zou hun stenen muur wel verscheuren. [^3] Hoor, o onze God! dat wij zeer veracht zijn, en keer hun versmaadheid weder op hun hoofd, en geef hen over tot een roof in een land der gevangenis. [^4] En dek hun ongerechtigheid niet toe; en hun zonde worde niet uitgedelgd van voor Uw aangezicht, want zij hebben U getergd, staande tegenover de bouwlieden. [^5] Doch wij bouwden den muur, zodat de ganse muur samengevoegd werd tot zijn helft toe; want het hart des volks was om te werken. [^6] En het geschiedde, als Sanballat, en Tobia, en de Arabieren, en de Ammonieten, en de Asdodieten hoorden, dat de verbetering aan de muren van Jeruzalem toenam, dat de scheuren begonnen gestopt te worden, zo ontstaken zij zeer; [^7] En zij maakten allen te zamen een verbintenis, dat zij zouden komen om tegen Jeruzalem te strijden, en een verbijstering daarin te maken. [^8] Maar wij baden tot onzen God, en zetten wacht tegen hen, dag en nacht, hunnenthalve. [^9] Toen zeide Juda: De kracht der dragers is vervallen, en des stofs is veel, zodat wij aan den muur niet zullen kunnen bouwen. [^10] Nu hadden onze vijanden gezegd: Zij zullen het niet weten, noch zien, totdat wij in het midden van hen komen, en slaan hen dood; alzo zullen wij het werk doen ophouden. [^11] En het geschiedde, als de Joden, die bij hen woonden, kwamen, dat zij het ons wel tienmaal zeiden, uit al de plaatsen, door dewelke gij tot ons wederkeert. [^12] Daarom zette ik in de benedenste plaatsen achter den muur, en op de hoogten, en ik zette het volk naar de geslachten, met hun zwaarden, hun spiesen en hun bogen. [^13] En ik zag toe, en maakte mij op, en zeide tot de edelen, en tot de overheden, en tot het overige des volks: Vreest niet voor hun aangezicht; denkt aan dien groten en vreselijken Heere, en strijdt voor uw broederen, uw zonen en uw dochteren, uw vrouwen en uw huizen. [^14] Daarna geschiedde het, als onze vijanden hoorden, dat het ons bekend was geworden, en God hun raad te niet gemaakt had, zo keerden wij allen weder tot den muur, een iegelijk tot zijn werk. [^15] En het geschiedde van dien dag af, dat de helft mijner jongens doende waren aan het werk, en de helft van hen hielden de spiesen, en de schilden, en de bogen, en de pantsiers; en de oversten waren achter het ganse huis van Juda. [^16] Die aan den muur bouwden, en die den last droegen, en die oplaadden, waren een ieder met zijn ene hand doende aan het werk, en de andere hield het geweer. [^17] En de bouwers hadden een iegelijk zijn zwaard aan zijn lenden gegord, en bouwden; maar die met de bazuin blies, was bij mij. [^18] En ik zeide tot de edelen, en tot de overheden, en tot het overige des volks: Het werk is groot en wijd; en wij zijn op den muur afgezonderd, de een ver van den ander; [^19] Ter plaatse, waar gij het geluid der bazuin zult horen, daarheen zult gij u tot ons verzamelen; onze God zal voor ons strijden. [^20] Alzo waren wij doende aan het werk; en de helft van hen hielden de spiesen, van het opgaan des dageraads tot het voortkomen der sterren toe. [^21] Ook zeide ik te dier tijd tot het volk: Een iegelijk vernachte met zijn jongen binnen Jeruzalem, opdat zij ons des nachts ter wacht zijn, en des daags aan het werk. [^22] Voorts noch ik, noch mijn broederen, noch mijn jongelingen, noch de mannen van de wacht, die achter mij waren, wij trokken onze klederen niet uit; een iegelijk had zijn geweer en water. [^23] 

[[Nehemia - 3|<--]] Nehemia - 4 [[Nehemia - 5|-->]]

---
# Notes
