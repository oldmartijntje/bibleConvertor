---
translation: Statenvertaling (1750)
aliases:
  - "1 Koningen - Statenvertaling (1750)"
tags:
  - "#bible/type/book"
  - "#bible/book/1_koningen"
  - "#bible/testament/old"
---
[[2 Samuel|<--]] 1 Koningen [[2 Koningen|-->]]

# 1 Koningen - Statenvertaling (1750)

The 1 Koningen book has 22 chapters. It is part of the old testament.

## Chapters

- 1 Koningen [[1 Koningen - 1|chapter 1]]
- 1 Koningen [[1 Koningen - 2|chapter 2]]
- 1 Koningen [[1 Koningen - 3|chapter 3]]
- 1 Koningen [[1 Koningen - 4|chapter 4]]
- 1 Koningen [[1 Koningen - 5|chapter 5]]
- 1 Koningen [[1 Koningen - 6|chapter 6]]
- 1 Koningen [[1 Koningen - 7|chapter 7]]
- 1 Koningen [[1 Koningen - 8|chapter 8]]
- 1 Koningen [[1 Koningen - 9|chapter 9]]
- 1 Koningen [[1 Koningen - 10|chapter 10]]
- 1 Koningen [[1 Koningen - 11|chapter 11]]
- 1 Koningen [[1 Koningen - 12|chapter 12]]
- 1 Koningen [[1 Koningen - 13|chapter 13]]
- 1 Koningen [[1 Koningen - 14|chapter 14]]
- 1 Koningen [[1 Koningen - 15|chapter 15]]
- 1 Koningen [[1 Koningen - 16|chapter 16]]
- 1 Koningen [[1 Koningen - 17|chapter 17]]
- 1 Koningen [[1 Koningen - 18|chapter 18]]
- 1 Koningen [[1 Koningen - 19|chapter 19]]
- 1 Koningen [[1 Koningen - 20|chapter 20]]
- 1 Koningen [[1 Koningen - 21|chapter 21]]
- 1 Koningen [[1 Koningen - 22|chapter 22]]

[[2 Samuel|<--]] 1 Koningen [[2 Koningen|-->]]

---
# Notes
