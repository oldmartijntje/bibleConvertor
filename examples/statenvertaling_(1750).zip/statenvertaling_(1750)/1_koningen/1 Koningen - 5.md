---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_koningen"
  - "#bible/testament/old"
aliases:
  - "1 Koningen - 5 - Statenvertaling (1750)"
---
[[1 Koningen - 4|<--]] 1 Koningen - 5 [[1 Koningen - 6|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[1 Koningen]]

# 1 Koningen - 5

En Hiram, de koning van Tyrus, zond zijn knechten tot Salomo (want hij had gehoord, dat zij Salomo tot koning gezalfd hadden in zijns vaders plaats), dewijl Hiram David altijd bemind had. [^1] Daarna zond Salomo tot Hiram, zeggende: [^2] Gij weet, dat mijn vader David den Naam des HEEREN, zijns Gods, geen huis kon bouwen, vanwege den oorlog, waarmede zij hem omsingelden, totdat de HEERE hen onder zijn voetzolen gaf. [^3] Maar nu heeft de HEERE, mijn God, mij van rondom rust gegeven; er is geen tegenpartijder, en geen bejegening van kwaad. [^4] En zie, ik denk voor den Naam van den HEERE, mijn God, een huis te bouwen; gelijk als de HEERE gesproken heeft tot mijn vader David, zeggende: Uw zoon, dien Ik in uw plaats op uw troon zetten zal, die zal Mijn Naam dat huis bouwen. [^5] Zo gebied nu, dat men mij cederen uit den Libanon houwe, en mijn knechten zullen met uw knechten zijn, en het loon uwer knechten zal ik u geven, naar al wat gij zeggen zult; want gij weet, dat onder ons niemand is, die weet hout te houwen, gelijk de Sidoniërs. [^6] En het geschiedde, als Hiram de woorden van Salomo gehoord had, dat hij zich zeer verblijdde, en zeide: Gezegend zij de HEERE heden, Die David een wijzen zoon gegeven heeft over dit grote volk! [^7] En Hiram zond tot Salomo, zeggende: Ik heb gehoord, waarom gij tot mij gezonden hebt; ik zal al uw wil doen met het cederenhout, en met het dennenhout. [^8] Mijn knechten zullen het afbrengen van den Libanon aan de zee; en ik zal het op vlotten over de zee doen voeren, tot die plaats, die gij aan mij ontbieden zult, en zal het aldaar los maken, en gij zult het wegnemen; gij zult ook mijn wil doen, dat gij mijn huis spijze geeft. [^9] Alzo gaf Hiram aan Salomo cederenhout en dennenhout, naar al zijn wil. [^10] En Salomo gaf Hiram twintig duizend kor tarwe, tot spijze van zijn huis, en twintig kor gestoten olie; zulks gaf Salomo aan Hiram jaar op jaar. [^11] De HEERE dan gaf Salomo wijsheid, gelijk als Hij tot hem gesproken had; en er was vrede tussen Hiram en tussen Salomo, en zij beiden maakten een verbond. [^12] En de koning Salomo deed een uitschot opkomen uit gans Israël; en het uitschot was dertig duizend man. [^13] En hij zond hen naar den Libanon, tien duizend des maands bij beurten; een maand waren zij in den Libanon; twee maanden elk in zijn huis; en Adoniram was over dit uitschot. [^14] Daartoe had Salomo zeventig duizend, die last droegen, en tachtig duizend houwers op het gebergte. [^15] Behalve de oversten van Salomo’s bestelden, die over dat werk waren, drie duizend en driehonderd, die heerschappij hadden over het volk, hetwelk dat werk deed. [^16] Als de koning het nu gebood, zo voerden zij grote stenen toe, kostelijke stenen, gehouwen stenen, om den grond van dat huis te leggen. [^17] En de bouwlieden van Salomo, en de bouwlieden van Hiram, en de Giblieten behieuwen ze, en bereidden het hout toe, en de stenen, om dat huis te bouwen. [^18] 

[[1 Koningen - 4|<--]] 1 Koningen - 5 [[1 Koningen - 6|-->]]

---
# Notes
