---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_koningen"
  - "#bible/testament/old"
aliases:
  - "1 Koningen - 19 - Statenvertaling (1750)"
---
[[1 Koningen - 18|<--]] 1 Koningen - 19 [[1 Koningen - 20|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[1 Koningen]]

# 1 Koningen - 19

En Achab zeide Izébel aan al wat Elia gedaan had, en allen, die hij gedood had, te weten al de profeten, met het zwaard. [^1] Toen zond Izébel een bode tot Elia, om te zeggen: Zo doen mij de goden, en doen zo daartoe, voorzeker, ik zal morgen omtrent dezen tijd uw ziel stellen, als de ziel van een hunner. [^2] Toen hij dat zag, maakte hij zich op, en ging heen, om zijns levens wil, en kwam te Berseba, dat in Juda is, en liet zijn jongen aldaar. [^3] Maar hij zelf ging henen in de woestijn een dagreis, en kwam, en zat onder een jeneverboom; en bad, dat zijn ziel stierve, en zeide: Het is genoeg; neem nu, HEERE, mijn ziel, want ik ben niet beter dan mijn vaderen. [^4] En hij legde zich neder, en sliep onder een jeneverboom; en ziet, toen roerde hem een engel aan, en zeide tot hem: Sta op, eet; [^5] En hij zag om, en ziet, aan zijn hoofdeinde was een koek op de kolen gebakken, en een fles met water; alzo at hij, en dronk, en legde zich wederom neder. [^6] En de engel des HEEREN kwam ten anderen male weder, en roerde hem aan, en zeide: Sta op, eet, want de weg zou te veel voor u zijn. [^7] Zo stond hij op, en at, en dronk; en hij ging, door de kracht derzelver spijs, veertig dagen en veertig nachten, tot aan den berg Gods, Horeb. [^8] En hij kwam aldaar in een spelonk, en vernachtte aldaar; en ziet, het woord des HEEREN geschiedde tot hem, en zeide tot hem: Wat maakt gij hier, Elia? [^9] En hij zeide: Ik heb zeer geijverd voor den HEERE, den God der heirscharen; want de kinderen Israëls hebben Uw verbond verlaten, Uw altaren afgebroken en Uw profeten met het zwaard gedood; en ik alleen ben overgebleven, en zij zoeken mijn ziel, om die weg te nemen. [^10] En Hij zeide: Ga uit, en sta op dezen berg, voor het aangezicht des HEEREN. En ziet, de HEERE ging voorbij, en een grote en sterke wind, scheurende de bergen, en brekende de steenrotsen, voor den HEERE henen; doch de HEERE was in den wind niet; en na dezen wind een aardbeving; de HEERE was ook in de aardbeving niet; [^11] En na de aardbeving een vuur; de HEERE was ook in het vuur niet; en na het vuur het suizen van een zachte stilte. [^12] En het geschiedde, als Elia dat hoorde, dat hij zijn aangezicht bewond met zijn mantel, en uitging, en stond in den ingang der spelonk. En ziet, een stem kwam tot hem, die zeide: Wat maakt gij hier, Elia? [^13] En hij zeide: Ik heb zeer geijverd voor den HEERE, den God der heirscharen; want de kinderen Israëls hebben Uw verbond verlaten, Uw altaren afgebroken en Uw profeten met het zwaard gedood; en ik alleen ben overgebleven, en zij zoeken mijn ziel, om die weg te nemen. [^14] En de HEERE zeide tot hem: Ga, keer weder op uwen weg, naar de woestijn van Damaskus; en ga daar in, en zalf Hazaël ten koning over Syrië. [^15] Daartoe zult gij Jehu, den zoon van Nimsi, zalven ten koning over Israël; en Elisa, den zoon van Safat, van Abel-Mehola, zult gij tot profeet zalven in uw plaats. [^16] En het zal geschieden, dat Jehu hem, die van het zwaard van Hazaël ontkomt, doden zal; en die van het zwaard van Jehu ontkomt, dien zal Elisa doden. [^17] Ook heb Ik in Israël doen overblijven zeven duizend, alle knieën, die zich niet gebogen hebben voor Baäl, en allen mond, die hem niet gekust heeft. [^18] Zo ging hij van daar, en vond Elisa, den zoon van Safat; dezelve ploegde met twaalf juk runderen voor zich henen, en hij was bij het twaalfde; en Elia ging over tot hem, en wierp zijn mantel op hem. [^19] En hij verliet de runderen, en liep Elia na, en zeide: Dat ik toch mijn vader en mijn moeder kusse, daarna zal ik u navolgen. En hij zeide tot hem: Ga, keer weder; want wat heb ik u gedaan? [^20] Zo keerde hij weder van achter hem af, en nam een juk runderen, en slachtte het, en met het gereedschap der runderen zood hij hun vlees, hetwelk hij aan het volk gaf; en zij aten. Daarna stond hij op, en volgde Elia na, en diende hem. [^21] 

[[1 Koningen - 18|<--]] 1 Koningen - 19 [[1 Koningen - 20|-->]]

---
# Notes
