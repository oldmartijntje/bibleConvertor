---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_koningen"
  - "#bible/testament/old"
aliases:
  - "1 Koningen - 17 - Statenvertaling (1750)"
---
[[1 Koningen - 16|<--]] 1 Koningen - 17 [[1 Koningen - 18|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[1 Koningen]]

# 1 Koningen - 17

En Elia, de Thisbiet, van de inwoneren van Gilead, zeide tot Achab: Zo waarachtig als de HEERE, de God Israëls, leeft, voor Wiens aangezicht ik sta, indien deze jaren dauw of regen zijn zal, tenzij dan naar mijn woord! [^1] Daarna geschiedde het woord des HEEREN tot hem, zeggende: [^2] Ga weg van hier, en wend u naar het oosten, en verberg u aan de beek Krith, die voor aan de Jordaan is. [^3] En het zal geschieden, dat gij uit de beek drinken zult; en Ik heb de raven geboden, dat zij u daar onderhouden zullen. [^4] Hij ging dan heen, en deed naar het woord des HEEREN; want hij ging en woonde bij de beek Krith, die voor aan de Jordaan is. [^5] En de raven brachten hem des morgens brood en vlees, desgelijks brood en vlees des avonds; en hij dronk uit de beek. [^6] En het geschiedde ten einde van vele dagen, dat de beek uitdroogde; want geen regen was in het land geweest. [^7] Toen geschiedde het woord des HEEREN tot hem, zeggende: [^8] Maak u op, ga heen naar Zarfath, dat bij Sidon is, en woon aldaar; zie, Ik heb daar een weduwvrouw geboden, dat zij u onderhoude. [^9] Toen maakte hij zich op, en ging naar Zarfath. Als hij nu aan de poort der stad kwam, ziet, zo was daar een weduwvrouw, hout lezende; en hij riep tot haar, en zeide: Haal mij toch een weinig waters in dit vat, dat ik drinke. [^10] Toen zij nu heenging om te halen, zo riep hij tot haar, en zeide: Haal mij toch ook een bete broods in uw hand. [^11] Maar zij zeide: Zo waarachtig als de HEERE, uw God, leeft, indien ik een koek heb, dan alleen een hand vol meels in de kruik, en een weinig olie in de fles! En zie ik heb een paar houten gelezen, en ik ga heen, en zal het voor mij en voor mijn zoon bereiden, dat wij het eten, en sterven. [^12] En Elia zeide tot haar: Vrees niet, ga heen, doe naar uw woord; maar maak mij vooreerst een kleinen koek daarvan, en breng mij dien hier uit; doch voor u en uw zoon zult gij daarna wat maken. [^13] Want zo zegt de HEERE, de God Israëls: Het meel van de kruik zal niet verteerd worden, en de olie der fles zal niet ontbreken, tot op den dag, dat de HEERE regen op den aardbodem geven zal. [^14] En zij ging heen, en deed naar het woord van Elia; zo at zij, en hij, en haar huis, vele dagen. [^15] Het meel van de kruik werd niet verteerd, en de olie van de fles ontbrak niet, naar het woord des HEEREN, dat Hij gesproken had door den dienst van Elia. [^16] En het geschiedde na deze dingen, dat de zoon dezer vrouw, der waardin van het huis, krank werd; en zijn krankheid werd zeer sterk, totdat geen adem in hem overgebleven was. [^17] En zij zeide tot Elia: Wat heb ik met u te doen, gij man Gods? Zijt gij bij mij ingekomen, om mijn ongerechtigheid in gedachtenis te brengen, en om mijn zoon te doden? [^18] En hij zeide tot haar: Geef mij uw zoon. En hij nam hem van haar schoot, en droeg hem boven in de opperzaal, waar hij zelf woonde, en hij legde hem neder op zijn bed. [^19] En hij riep den HEERE aan, en zeide: HEERE, mijn God, hebt Gij dan ook deze weduwe, bij dewelke ik herberge, zo kwalijk gedaan, dat Gij haar zoon gedood hebt? [^20] En hij mat zich driemaal uit over dat kind, en riep den HEERE aan, en zeide: HEERE, mijn God, laat toch de ziel van dit kind in hem wederkomen. [^21] En de HEERE verhoorde de stem van Elia; en de ziel van het kind kwam weder in hem, dat het weder levend werd. [^22] En Elia nam het kind, en bracht het af van de opperzaal in het huis, en gaf het aan zijn moeder; en Elia zeide: Zie, uw zoon leeft. [^23] Toen zeide die vrouw tot Elia: Nu weet ik, dat gij een man Gods zijt, en dat het woord des HEEREN in uw mond waarheid is. [^24] 

[[1 Koningen - 16|<--]] 1 Koningen - 17 [[1 Koningen - 18|-->]]

---
# Notes
