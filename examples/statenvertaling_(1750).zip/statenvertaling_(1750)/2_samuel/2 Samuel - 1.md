---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 1 - Statenvertaling (1750)"
---
2 Samuel - 1 [[2 Samuel - 2|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[2 Samuel]]

# 2 Samuel - 1

Voorts geschiedde het na Sauls dood, als David van den slag der Amalekieten was wedergekomen, en David twee dagen te Ziklag gebleven was; [^1] Zo geschiedde het op den derden dag, dat, ziet, uit het heirleger van Saul, een man kwam, wiens klederen gescheurd waren, en aarde was op zijn hoofd; en het geschiedde, als hij tot David kwam, zo viel hij ter aarde en boog zich neder. [^2] En David zeide tot hem: Van waar komt gij? En hij zeide tot hem: Ik ben ontkomen uit het heirleger van Israël. [^3] Voorts zeide David tot hem: Wat is de zaak? Verhaal het mij toch. En hij zeide, dat het volk uit den strijd gevloden was, en dat er ook velen van het volk gevallen en gestorven waren, dat ook Saul en zijn zoon Jonathan dood waren. [^4] En David zeide tot den jongen, die hem de boodschap bracht: Hoe weet gij, dat Saul dood is, en zijn zoon Jonathan? [^5] Toen zeide de jongen, die hem de boodschap bracht: Ik kwam bij geval op het gebergte van Gilboa; en ziet, Saul leunde op zijn spies; en ziet, de wagens en ritmeesters hielden dicht op hem. [^6] Zo zag hij achter zich om, en zag mij, en hij riep mij, en ik zeide: Zie, hier ben ik. [^7] En hij zeide tot mij: Wie zijt gij? En ik zeide tot hem: Ik ben een Amalekiet. [^8] Toen zeide hij tot mij: Sta toch bij mij, en dood mij; want deze maliënkolder heeft mij opgehouden; want mijn leven is nog gans in mij. [^9] Zo stond ik bij hem, en doodde hem; want ik wist, dat hij na zijn val niet leven zou; en ik nam de kroon, die op zijn hoofd was, en het armgesmijde, dat aan zijn arm was, en heb ze hier tot mijn heer gebracht. [^10] Toen vatte David zijn klederen en scheurde ze; desgelijks ook al de mannen, die met hem waren. [^11] En zij weeklaagden, en weenden, en vastten tot op den avond, over Saul en over Jonathan, zijn zoon, en over het volk des HEEREN, en over het huis Israëls, omdat zij door het zwaard gevallen waren. [^12] Voorts zeide David tot den jongen, die hem de boodschap gebracht had: Van waar zijt gij? En hij zeide: Ik ben de zoon van een vreemden man, van een Amalekiet. [^13] En David zeide tot hem: Hoe, hebt gij niet gevreesd uw hand uit te strekken, om den gezalfde des HEEREN te verderven? [^14] En David riep een van de jongens, en zeide: Treed toe, val op hem aan. En hij sloeg hem, dat hij stierf. [^15] En David zeide tot hem: Uw bloed zij op uw hoofd; want uw mond heeft tegen u getuigd, zeggende: ik heb den gezalfde des HEEREN gedood. [^16] David nu klaagde deze klage over Saul en over Jonathan, zijn zoon; [^17] Als hij gezegd had, dat men den kinderen van Juda den boog zou leren; ziet, het is geschreven in het boek des Oprechten. [^18] O Sieraad van Israël, op uw hoogten is hij verslagen; hoe zijn de helden gevallen! [^19] Verkondigt het niet te Gath, boodschapt het niet op de straten van Askelon; opdat de dochters der Filistijnen zich niet verblijden, opdat de dochters der onbesnedenen niet opspringen van vreugde. [^20] Gij, bergen van Gilboa, noch dauw noch regen moet zijn op u, noch velden der hefofferen; want aldaar is der helden schild smadelijk weggeworpen, het schild van Saul, alsof hij niet gezalfd ware geweest met olie. [^21] Van het bloed der verslagenen, van het vette der helden, werd Jonathans boog niet achterwaarts gedreven; en Sauls zwaard keerde niet ledig weder. [^22] Saul en Jonathan, die beminden, en die liefelijken in hun leven, zijn ook in hun dood niet gescheiden; zij waren lichter dan arenden, zij waren sterker dan leeuwen. [^23] Gij, dochteren Israëls, weent over Saul; die u kleedde met scharlaken, met weelde; die u sieraad van goud deed dragen over uw kleding. [^24] Hoe zijn de helden gevallen in het midden van den strijd! Jonathan is verslagen op uw hoogten! [^25] Ik ben benauwd om uwentwil, mijn broeder Jonathan! Gij waart mij zeer liefelijk; uw liefde was mij wonderlijker dan liefde der vrouwen. [^26] Hoe zijn de helden gevallen, en de krijgswapenen verloren! [^27] 

2 Samuel - 1 [[2 Samuel - 2|-->]]

---
# Notes
