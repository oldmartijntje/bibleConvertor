---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 10 - Statenvertaling (1750)"
---
[[2 Samuel - 9|<--]] 2 Samuel - 10 [[2 Samuel - 11|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[2 Samuel]]

# 2 Samuel - 10

En het geschiedde daarna, dat de koning der kinderen Ammons stierf, en zijn zoon Hanun werd koning in zijn plaats. [^1] Toen zeide David: Ik zal weldadigheid doen aan Hanun, den zoon van Nahas, gelijk als zijn vader weldadigheid aan mij gedaan heeft. Zo zond David heen, om hem door den dienst zijner knechten te troosten over zijn vader. En de knechten van David kwamen in het land van de kinderen Ammons. [^2] Toen zeiden de vorsten der kinderen Ammons tot hun heer Hanun: Eert David uw vader in uw ogen, omdat hij troosters tot u gezonden heeft? Heeft David zijn knechten niet daarom tot u gezonden, dat hij deze stad doorzoeke, en die verspiede, en die omkere? [^3] Toen nam Hanun Davids knechten, en schoor hun baard half af, en sneed hun klederen half af, tot aan hun billen; en hij liet hen gaan. [^4] Als zij dit David lieten weten, zo zond hij hun tegemoet; want deze mannen waren zeer beschaamd. En de koning zeide: Blijft te Jericho, totdat uw baard weder gewassen zal zijn, komt dan weder. [^5] Toen nu de kinderen Ammons zagen, dat zij zich bij David stinkende gemaakt hadden, zonden de kinderen Ammons heen, en huurden van de Syriërs van Beth-Rechob, en van de Syriërs van Zoba, twintig duizend voetvolks, en van den koning van Maächa duizend man, en van de mannen van Tob twaalf duizend man. [^6] Als David dit hoorde, zond hij Joab heen, en het ganse heir met de helden. [^7] En de kinderen Ammons togen uit, en stelden de slagorde voor de deur der poort; maar de Syriërs van Zoba, en Rechob, en de mannen van Tob en Maächa waren bijzonder in het veld. [^8] Als nu Joab zag, dat de spits der slagorde tegen hem was, van voren en van achteren, zo verkoos hij uit alle uitgelezenen van Israël, en stelde hen in orde tegen de Syriërs aan; [^9] En het overige des volks gaf hij onder de hand van zijn broeder Abisaï, die het in orde stelde tegen de kinderen Ammons aan. [^10] En hij zeide: Zo de Syriërs mij te sterk zullen zijn, zo zult gij mij komen verlossen; en zo de kinderen Ammons u te sterk zullen zijn, zo zal ik komen om u te verlossen. [^11] Wees sterk, en laat ons sterk zijn voor ons volk, en voor de steden onzes Gods; de HEERE nu doe, wat goed is in Zijn ogen. [^12] Toen naderde Joab, en het volk, dat bij hem was, tot den strijd tegen de Syriërs; en zij vloden voor zijn aangezicht. [^13] Als de kinderen Ammons zagen, dat de Syriërs vloden, vloden zij ook voor het aangezicht van Abisaï, en kwamen in de stad. En Joab keerde weder van de kinderen Ammons, en kwam te Jeruzalem. [^14] Toen nu de Syriërs zagen, dat zij voor Israëls aangezicht geslagen waren, zo vergaderden zij zich weder te zamen. [^15] En Hadadezer zond heen, en deed de Syriërs uitkomen, die op gene zijde der rivier zijn, en zij kwamen te Helam; en Sobach, Hadadezers krijgsoverste, toog voor hun aangezicht heen. [^16] Als dat David werd aangezegd, verzamelde hij gans Israël, en toog over de Jordaan, en kwam te Helam, en de Syriërs stelden de slagorde tegen David aan, en streden met hem. [^17] Maar de Syriërs vloden voor Israëls aangezicht, en David versloeg van de Syriërs zevenhonderd wagenen, en veertig duizend ruiteren; daartoe sloeg hij Sobach, hun krijgsoverste, dat hij aldaar stierf. [^18] Toen nu al de koningen, die Hadadezers knechten waren, zagen, dat zij voor Israëls aangezicht geslagen waren, maakten zij vrede met Israël, en dienden hen; en de Syriërs vreesden de kinderen Ammons meer te verlossen. [^19] 

[[2 Samuel - 9|<--]] 2 Samuel - 10 [[2 Samuel - 11|-->]]

---
# Notes
