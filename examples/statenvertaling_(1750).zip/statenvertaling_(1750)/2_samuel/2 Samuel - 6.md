---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 6 - Statenvertaling (1750)"
---
[[2 Samuel - 5|<--]] 2 Samuel - 6 [[2 Samuel - 7|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[2 Samuel]]

# 2 Samuel - 6

Daarna verzamelde David wederom alle uitgelezenen in Israël, dertig duizend. [^1] En David maakte zich op, en ging heen met al het volk, dat bij hem was, van Baälim-Juda, om van daar op te brengen de ark Gods, bij dewelke de Naam wordt aangeroepen, de Naam van den HEERE der heirscharen, Die daarop woont tussen de cherubim. [^2] En zij voerden de ark Gods op een nieuwen wagen, en haalden ze uit het huis van Abinadab, dat op een heuvel is; en Uza en Ahio, zonen van Abinadab, leidden den nieuwen wagen. [^3] Toen zij hem nu uit het huis van Abinadab, dat op den heuvel is, met de ark Gods, wegvoerden, zo ging Ahio voor de ark henen. [^4] En David en het ganse huis Israëls speelden voor het aangezicht des HEEREN, met allerlei snarenspel van dennenhout, als met harpen, en met luiten, en met trommelen, ook met schellen, en met cimbalen. [^5] Als zij nu kwamen tot aan Nachons dorsvloer, zo strekte Uza zijn hand uit aan de ark Gods, en hield ze, want de runderen struikelden. [^6] Toen ontstak de toorn des HEEREN tegen Uza, en God sloeg hem aldaar, om deze onbedachtzaamheid; en hij stierf aldaar bij de ark Gods. [^7] En David ontstak, omdat de HEERE een scheur gescheurd had aan Uza; en hij noemde dezelve plaats Perez-Uza, tot op dezen dag. [^8] En David vreesde den HEERE ten zelven dage; en hij zeide: Hoe zal de ark des HEEREN tot mij komen? [^9] David dan wilde de ark des HEEREN niet tot zich laten overbrengen in de stad Davids; maar David deed ze afwijken in het huis van Obed-Edom, den Gethiet. [^10] En de ark des HEEREN bleef in het huis van Obed-Edom, den Gethiet, drie maanden; en de HEERE zegende Obed-Edom en zijn ganse huis. [^11] Toen boodschapte men den koning David, zeggende: De HEERE heeft het huis van Obed-Edom, en al wat hij heeft, gezegend om der ark Gods wil; zo ging David heen en haalde de ark Gods uit het huis van Obed-Edom opwaarts in de stad Davids, met vreugde. [^12] En het geschiedde, als zij, die de ark des HEEREN droegen, zes treden voortgetreden waren, dat hij ossen en gemest vee offerde. [^13] En David huppelde met alle macht voor het aangezicht des HEEREN; en David was omgord met een linnen lijfrok. [^14] Alzo brachten David en het ganse huis Israëls de ark des HEEREN op, met gejuich en met geluid der bazuin. [^15] En het geschiedde, als de ark des HEEREN in de stad Davids kwam, dat Michal, Sauls dochter, door het venster uitzag. Als zij nu den koning David zag, springende en huppelende voor het aangezicht des HEEREN, verachtte zij hem in haar hart. [^16] Toen zij nu de ark des HEEREN inbrachten, stelden zij die in haar plaats, in het midden der tent, die David voor haar gespannen had; en David offerde brandofferen voor des HEEREN aangezicht, en dankofferen. [^17] Als David geëindigd had het brandoffer en de dankofferen te offeren, zo zegende hij het volk in den Naam des HEEREN der heirscharen. [^18] En hij deelde uit aan het ganse volk, aan de ganse menigte van Israël, van de mannen tot de vrouwen toe, aan een iegelijk een broodkoek, en een schoon stuk vlees, en een fles wijn. Toen ging al dat volk heen, een iegelijk naar zijn huis. [^19] Als nu David wederkwam, om zijn huis te zegenen, ging Michal, Sauls dochter, uit, David tegemoet, en zeide: Hoe is heden de koning van Israël verheerlijkt, die zich heden voor de ogen van de dienstmaagden zijner dienstknechten heeft ontbloot, gelijk een van de ijdele lieden zich onbeschaamdelijk ontbloot? [^20] Maar David zeide tot Michal: Voor het aangezicht des HEEREN, Die mij verkoren heeft voor uw vader en voor zijn ganse huis, mij instellende tot een voorganger over het volk des HEEREN, over Israël; ja, ik zal spelen voor het aangezicht des HEEREN. [^21] Ook zal ik mij nog geringer houden dan alzo, en zal nederig zijn in mijn ogen, en met de dienstmaagden, waarvan gij gezegd hebt, met dezelve zal ik verheerlijkt worden. [^22] Michal nu, Sauls dochter, had geen kind, tot den dag van haar dood toe. [^23] 

[[2 Samuel - 5|<--]] 2 Samuel - 6 [[2 Samuel - 7|-->]]

---
# Notes
