---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 5 - Statenvertaling (1750)"
---
[[2 Samuel - 4|<--]] 2 Samuel - 5 [[2 Samuel - 6|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[2 Samuel]]

# 2 Samuel - 5

Toen kwamen alle stammen van Israël tot David te Hebron; en zij spraken, zeggende: Zie, wij, uw gebeente en uw vlees zijn wij. [^1] Daartoe ook te voren, toen Saul koning over ons was, waart gij Israël uitvoerende en inbrengende; ook heeft de HEERE tot u gezegd: Gij zult Mijn volk Israël weiden, en gij zult tot een voorganger zijn over Israël. [^2] Alzo kwamen alle oudsten van Israël tot den koning te Hebron; en de koning David maakte een verbond met hen te Hebron, voor het aangezicht des HEEREN; en zij zalfden David tot koning over Israël. [^3] Dertig jaar was David oud, als hij koning werd; veertig jaren heeft hij geregeerd. [^4] Te Hebron regeerde hij over Juda zeven jaren en zes maanden; en te Jeruzalem regeerde hij drie en dertig jaren over gans Israël en Juda. [^5] En de koning toog met zijn mannen naar Jeruzalem, tegen de Jebusieten, die in dat land woonden. En zij spraken tot David, zeggende: Gij zult hier niet inkomen, maar de blinden en kreupelen zullen u afdrijven; dat is te zeggen: David zal hier niet inkomen. [^6] Maar David nam den burg Sion in; dezelve is de stad Davids. [^7] Want David zeide ten zelfden dage: Al wie de Jebusieten slaat, en geraakt aan die watergoot, en die kreupelen, en die blinden, die van Davids ziel gehaat zijn, die zal tot een hoofd en tot een overste zijn; daarom zegt men: Een blinde en kreupele zal in het huis niet komen. [^8] Alzo woonde David in den burg en noemde dien Davids stad. En David bouwde rondom van Millo af en binnenwaarts. [^9] David nu ging geduriglijk voort, en werd groot; want de HEERE, de God der heirscharen, was met hem. [^10] En Hiram, de koning van Tyrus, zond boden tot David, en cederenhout, en timmerlieden, en metselaars; en zij bouwden David een huis. [^11] En David merkte, dat de HEERE hem tot een koning over Israël bevestigd had, en dat Hij zijn koninkrijk verheven had, om Zijns volks Israëls wil. [^12] En David nam meer bijwijven, en vrouwen van Jeruzalem, nadat hij van Hebron gekomen was; en David werden meer zonen en dochteren geboren. [^13] En dit zijn de namen dergenen, die hem te Jeruzalem geboren zijn: Schammua, en Schobab, en Nathan, en Salomo. [^14] En Ibchar, en Elischua en Nefeg, en Jafia, [^15] En Elischama, en Eljada, en Elifeleth. [^16] Als nu de Filistijnen hoorden, dat zij David ten koning over Israël gezalfd hadden, zo togen alle Filistijnen op om David te zoeken; en David, dat horende, toog af, naar den burg. [^17] En de Filistijnen kwamen en verspreidden zich in het dal Refaïm. [^18] Zo vraagde David den HEERE, zeggende: Zal ik optrekken tegen de Filistijnen? Zult Gij ze in mijn hand geven? En de HEERE zeide tot David: Trek op, want Ik zal de Filistijnen zekerlijk in uw hand geven. [^19] Toen kwam David te Baäl-Perazim; en David sloeg hen aldaar, en zeide: De HEERE heeft mijn vijanden voor mijn aangezicht gescheurd, als een scheur der wateren; daarom noemde hij den naam derzelve plaats, Baäl-Perazim. [^20] En zij lieten hun afgoden aldaar; en David en zijn mannen namen ze op. [^21] Daarna togen de Filistijnen weder op; en zij verspreidden zich in het dal Refaïm. [^22] En David vraagde den HEERE, Dewelke zeide: Gij zult niet optrekken; maar trek om tot achter hen, dat gij aan hen komt van tegenover de moerbeziënbomen; [^23] En het geschiede, als gij hoort het geruis van een gang in de toppen der moerbeziënbomen, dan rep u; want alsdan is de HEERE voor uw aangezicht uitgegaan, om het heirleger der Filistijnen te slaan. [^24] En David deed alzo, gelijk als de HEERE hem geboden had; en hij sloeg de Filistijnen van Geba af, totdat gij komt te Gezer. [^25] 

[[2 Samuel - 4|<--]] 2 Samuel - 5 [[2 Samuel - 6|-->]]

---
# Notes
