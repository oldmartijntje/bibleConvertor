---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 9 - Statenvertaling (1750)"
---
[[2 Samuel - 8|<--]] 2 Samuel - 9 [[2 Samuel - 10|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[2 Samuel]]

# 2 Samuel - 9

En David zeide: Is er nog iemand die overgebleven is van het huis van Saul, dat ik weldadigheid aan hem doe, om Jonathans wil? [^1] Het huis van Saul nu had een knecht, wiens naam was Ziba; en zij riepen hem tot David. En de koning zeide tot hem: Zijt gij Ziba? En hij zeide: Uw knecht. [^2] En de koning zeide: Is er nog iemand van het huis van Saul, dat ik Gods weldadigheid bij hem doe? Toen zeide Ziba tot den koning: Er is nog een zoon van Jonathan, die geslagen is aan beide voeten. [^3] En de koning zeide tot hem: Waar is hij? En Ziba zeide tot den koning: Zie, hij is in het huis van Machir, den zoon van Ammiël, te Lodebar. [^4] Toen zond de koning David heen, en hij nam hem uit het huis van Machir, den zoon van Ammiël, van Lodebar. [^5] Als nu Mefiboseth, de zoon van Jonathan, den zoon van Saul, tot David inkwam, zo viel hij op zijn aangezicht, en boog zich neder. En David zeide: Mefiboseth! En hij zeide: Zie, hier is uw knecht. [^6] En David zeide tot hem: Vrees niet, want ik zal zekerlijk weldadigheid bij u doen, om uws vaders Jonathans wil; en ik zal u alle akkers van uw vader Saul wedergeven; en gij zult geduriglijk brood eten aan mijn tafel. [^7] Toen boog hij zich, en zeide: Wat is uw knecht, dat gij omgezien hebt naar een doden hond, als ik ben? [^8] Toen riep de koning Ziba, Sauls jongen, en zeide tot hem: Al wat Saul gehad heeft, en zijn ganse huis, heb ik den zoon uws heren gegeven. [^9] Daarom zult gij voor hem het land bearbeiden, gij, en uw zonen, en uw knechten, en zult de vruchten inbrengen, opdat de zoon uws heren brood hebbe, dat hij ete; en Mefiboseth, de zoon uws heren, zal geduriglijk brood eten aan mijn tafel. Ziba nu had vijftien zonen en twintig knechten. [^10] En Ziba zeide tot den koning: Naar alles, wat mijn heer de koning zijn knecht gebiedt, alzo zal uw knecht doen. Ook zou Mefiboseth, etende aan mijn tafel, als een van des konings zonen zijn. [^11] Mefiboseth nu had een kleinen zoon, wiens naam was Micha; en allen, die in het huis van Ziba woonden, waren knechten van Mefiboseth. [^12] Alzo woonde Mefiboseth te Jeruzalem, omdat hij geduriglijk at aan des konings tafel; en hij was kreupel aan beide zijn voeten. [^13] 

[[2 Samuel - 8|<--]] 2 Samuel - 9 [[2 Samuel - 10|-->]]

---
# Notes
