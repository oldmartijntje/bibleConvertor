---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 16 - Statenvertaling (1750)"
---
[[2 Samuel - 15|<--]] 2 Samuel - 16 [[2 Samuel - 17|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[2 Samuel]]

# 2 Samuel - 16

Als nu David een weinig van de hoogte was voortgegaan, ziet, toen ontmoette hem Ziba, Mefiboseths jongen, met een paar gezadelde ezelen, en daarop tweehonderd broden, met honderd stukken rozijnen, en honderd stukken zomervruchten, en een lederen zak wijns. [^1] En de koning zeide tot Ziba: Wat zult gij daarmede? En Ziba zeide: De ezels zijn voor het huis des konings, om op te rijden en het brood en de zomervruchten, om te eten voor de jongens; en de wijn, opdat de moeden in de woestijn drinken. [^2] Toen zeide de koning: Waar is dan de zoon uws heren? En Ziba zeide tot den koning: Zie, hij blijft te Jeruzalem, want hij zeide: Heden zal mij het huis Israëls mijns vaders koninkrijk wedergeven. [^3] Zo zeide de koning tot Ziba: Zie, het zal het uwe zijn alles wat Mefiboseth heeft. En Ziba zeide: Ik buig mij neder, laat mij genade vinden in uw ogen, mijn heer koning! [^4] Als nu de koning David tot aan Bahurim kwam, ziet, toen kwam van daar een man uit, van het geslacht van het huis van Saul, wiens naam was Simeï, de zoon van Gera; hij ging steeds voort, en vloekte. [^5] En hij wierp David met stenen, mitsgaders alle knechten van den koning David, hoewel al het volk en al de helden aan zijn rechter- en aan zijn linkerhand waren. [^6] Aldus nu zeide Simeï in zijn vloeken: Ga uit, ga uit, gij, man des bloeds, en gij, Belials man! [^7] De HEERE heeft op u doen wederkomen al het bloed van Sauls huis, in wiens plaats gij geregeerd hebt; nu heeft de HEERE het koninkrijk gegeven in de hand van Absalom, uw zoon; zie nu, gij zijt in uw ongeluk, omdat gij een man des bloeds zijt. [^8] Toen zeide Abisaï, de zoon van Zeruja, tot den koning: Waarom zou deze dode hond mijn heer den koning vloeken? Laat mij toch overgaan en zijn kop wegnemen. [^9] Maar de koning zeide: Wat heb ik met u te doen, gij zonen van Zeruja? Ja, laat hem vloeken; want de HEERE toch heeft tot hem gezegd: Vloek David; wie zou dan zeggen: Waarom hebt gij alzo gedaan? [^10] Voorts zeide David tot Abisaï en tot al zijn knechten: Ziet, mijn zoon, die van mijn lijf is voortgekomen, zoekt mijn ziel; hoeveel te meer dan nu deze zoon van Jemini? Laat hem geworden, dat hij vloeke, want de HEERE heeft het hem gezegd. [^11] Misschien zal de HEERE mijn ellende aanzien; en de HEERE zal mij goed vergelden voor zijn vloek, te dezen dage. [^12] Alzo ging David met zijn lieden op den weg; en Simeï ging al voort langs de zijde des bergs tegen hem over, en vloekte, en wierp met stenen van tegenover hem, en stoof met stof. [^13] En de koning kwam in, en al het volk, dat met hem was, moede zijnde; en hij verkwikte zich aldaar. [^14] Absalom nu en al het volk, de mannen van Israël, kwamen te Jeruzalem, en Achitofel met hem. [^15] En het geschiedde, als Husai, de Archiet, Davids vriend, tot Absalom kwam, dat Husai tot Absalom zeide: De koning leve, de koning leve! [^16] Maar Absalom zeide tot Husai: Is dit uw weldadigheid aan uw vriend? Waarom zijt gij niet met uw vriend getogen? [^17] En Husai zeide tot Absalom: Neen, maar welken de HEERE verkiest, en al dit volk, en alle mannen van Israël, diens zal ik zijn, en bij hem zal ik blijven. [^18] En ten andere, wien zou ik dienen? Zou het niet zijn voor het aangezicht zijns zoons? Gelijk als ik voor het aangezicht uws vaders gediend heb, alzo zal ik voor uw aangezicht zijn. [^19] Toen zeide Absalom tot Achitofel: Geeft onder ulieden raad, wat zullen wij doen? [^20] En Achitofel zeide tot Absalom: Ga in tot de bijwijven uws vaders, die hij gelaten heeft om het huis te bewaren; zo zal gans Israël horen, dat gij bij uw vader stinkende zijt geworden, en de handen van allen, die met u zijn, zullen gesterkt worden. [^21] Zo spanden zij Absalom een tent op het dak; en Absalom ging in tot de bijwijven zijns vaders, voor de ogen van het ganse Israël. [^22] En in die dagen was Achitofels raad, dien hij raadde, als of men naar Gods woord gevraagd had; alzo was alle raad van Achitofel, zo bij David als bij Absalom. [^23] 

[[2 Samuel - 15|<--]] 2 Samuel - 16 [[2 Samuel - 17|-->]]

---
# Notes
