---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 8 - Statenvertaling (1750)"
---
[[2 Samuel - 7|<--]] 2 Samuel - 8 [[2 Samuel - 9|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[2 Samuel]]

# 2 Samuel - 8

En het geschiedde daarna, dat David de Filistijnen sloeg, en bracht hen ten onder; en David nam Meteg-Amma uit der Filistijnen hand. [^1] Ook sloeg hij de Moabieten, en mat hen met een snoer, doende hen ter aarde nederliggen; en hij mat met twee snoeren om te doden, en met een vol snoer om in het leven te laten. Alzo werden de Moabieten David tot knechten, brengende geschenken. [^2] David sloeg ook Hadadezer, den zoon van Rechob, den koning van Zoba, toen hij heentoog, om zijn hand te wenden naar de rivier Frath. [^3] En David nam hem duizend wagens af, en zevenhonderd ruiteren, en twintig duizend man te voet; en David ontzenuwde alle wagenpaarden, en hield daarvan honderd wagenen over. [^4] En de Syriërs van Damaskus kwamen om Hadadezer, den koning van Zoba, te helpen; maar David sloeg van de Syriërs twee en twintig duizend man. [^5] En David legde bezettingen in Syrië van Damaskus, en de Syriërs werden David tot knechten, brengende geschenken; en de HEERE behoedde David overal, waar hij heentoog. [^6] En David nam de gouden schilden die bij Hadadezers knechten geweest waren, en bracht ze te Jeruzalem. [^7] Daartoe nam de koning David zeer veel kopers uit Betach, en uit Berothai, steden van Hadadezer. [^8] Als nu Thoï, de koning van Hamath, hoorde, dat David het ganse heir van Hadadezer geslagen had; [^9] Zo zond Thoï zijn zoon Joram tot den koning David, om hem te vragen naar zijn welstand, en om hem te zegenen, vanwege dat hij tegen Hadadezer gekrijgd en hem geslagen had (want Hadadezer voerde steeds krijg tegen Thoï); en in zijn hand waren zilveren vaten, en gouden vaten, en koperen vaten; [^10] Welke de koning David ook den HEERE heiligde, met het zilver en het goud, dat hij geheiligd had van alle heidenen, die hij zich onderworpen had; [^11] Van Syrië, en van Moab, en van de kinderen Ammons, en van de Filistijnen, en van Amalek, en van den roof van Hadadezer, den zoon van Rechob, den koning van Zoba. [^12] Ook maakte zich David een naam, als hij wederkwam, nadat hij de Syriërs geslagen had, in het Zoutdal, achttien duizend. [^13] En hij legde bezettingen in Edom; in gans Edom legde hij bezettingen; en alle Edomieten werden David tot knechten; en de HEERE behoedde David overal, waar hij heentoog. [^14] Alzo regeerde David over gans Israël, en David deed aan zijn ganse volk recht en gerechtigheid. [^15] Joab nu, de zoon van Zeruja, was over het heir; en Josafat, zoon van Achilud, was kanselier. [^16] En Zadok, zoon van Ahitub, en Achimelech, zoon van Abjathar, waren priesters; en Seraja was schrijver. [^17] Er was ook Benaja, zoon van Jojada, met de Krethi en de Plethi; maar Davids zonen waren prinsen. [^18] 

[[2 Samuel - 7|<--]] 2 Samuel - 8 [[2 Samuel - 9|-->]]

---
# Notes
