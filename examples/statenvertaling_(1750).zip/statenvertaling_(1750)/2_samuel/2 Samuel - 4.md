---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 4 - Statenvertaling (1750)"
---
[[2 Samuel - 3|<--]] 2 Samuel - 4 [[2 Samuel - 5|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[2 Samuel]]

# 2 Samuel - 4

Als nu Sauls zoon hoorde, dat Abner te Hebron gestorven was, werden zijn handen slap, en gans Israël werd verschrikt. [^1] En Sauls zoon had twee mannen, oversten van benden; de naam des enen was Baëna, en de naam des anderen Rechab, zonen van Rimmon, den Beërothiet, van de kinderen van Benjamin; want ook Beëroth werd aan Benjamin gerekend. [^2] En de Beërothieten waren gevloden naar Gitthaïm, en waren aldaar vreemdelingen tot op dezen dag. [^3] En Jonathan, Sauls zoon, had een zoon, die geslagen was aan beide voeten; vijf jaren was hij oud als het gerucht van Saul en Jonathan uit Jizreël kwam; en zijn voedster hem opnam, en vluchtte; en het geschiedde, als zij haastte, om te vluchten, dat hij viel en kreupel werd; en zijn naam was Mefiboseth. [^4] En de zonen van Rimmon: den Beërothiet, Rechab en Baëna, gingen heen, en kwamen ten huize van Isboseth, als de dag heet geworden was; en hij lag op de slaapstede, in den middag. [^5] En zij kwamen daarin tot het midden des huizes, als zullende tarwe halen; en zij sloegen hem aan de vijfde rib; en Rechab en zijn broeder Baëna ontkwamen. [^6] Want zij kwamen in huis, als hij op zijn bed lag, in zijn slaapkamer, en sloegen hem, en doodden hem, en hieuwen zijn hoofd af; en zij namen zijn hoofd, en gingen henen, den weg op het vlakke veld, den gansen nacht. [^7] En zij brachten het hoofd van Isboseth tot David te Hebron, en zeiden tot den koning: Zie, daar is het hoofd van Isboseth, den zoon van Saul, uw vijand, die uw ziel zocht, alzo heeft de HEERE mijn heer den koning te dezen dage wrake gegeven van Saul en van zijn zaad. [^8] Maar David antwoordde Rechab en zijn broeder Baëna, den zonen van Rimmon, den Beërothiet, en zeide tot hen: Zo waarachtig als de HEERE leeft, Die mijn ziel uit alle benauwdheid verlost heeft! [^9] Dewijl ik hem, die mij boodschapte, zeggende: Zie, Saul is dood; daar hij in zijn ogen was als een, die goede boodschap bracht, nochtans gegrepen en te Ziklag gedood heb, hoewel hij meende, dat ik hem bodenloon zou geven; [^10] Hoeveel te meer, wanneer goddeloze mannen een rechtvaardigen man in zijn huis op zijn slaapstede hebben gedood? Nu dan, zou ik zijn bloed van uw handen niet eisen, en u van de aarde wegdoen? [^11] En David gebood zijn jongens, en zij doodden hen, en hieuwen hun handen en hun voeten af, en hingen ze op bij den vijver te Hebron, maar het hoofd van Isboseth namen zij, en begroeven het in Abners graf te Hebron. [^12] 

[[2 Samuel - 3|<--]] 2 Samuel - 4 [[2 Samuel - 5|-->]]

---
# Notes
