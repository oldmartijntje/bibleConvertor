---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 21 - Statenvertaling (1750)"
---
[[1 Samuel - 20|<--]] 1 Samuel - 21 [[1 Samuel - 22|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[1 Samuel]]

# 1 Samuel - 21

Toen kwam David te Nob, tot den priester Achimelech; en Achimelech kwam bevende David tegemoet, en hij zeide tot hem: Waarom zijt gij alleen, en geen man met u? [^1] En David zeide tot den priester Achimelech: De koning heeft mij een zaak bevolen, en zeide tot mij: Laat niemand iets van de zaak weten, om dewelke ik u gezonden heb, en die ik u geboden heb; den jongelingen nu heb ik de plaats van zulk een te kennen gegeven. [^2] En nu wat is er onder uw hand? Geef mij vijf broden in mijn hand, of wat er gevonden wordt. [^3] En de priester antwoordde David, en zeide: Er is geen gemeen brood onder mijn hand; maar er is heilig brood, wanneer zich de jongelingen slechts van de vrouwen onthouden hebben. [^4] David nu antwoordde den priester, en zeide tot hem: Ja trouwens, de vrouwen zijn ons onthouden geweest gisteren en eergisteren, toen ik uitging, en de vaten der jongelingen zijn heilig; en het is enigerwijze gemeen brood, te meer dewijl heden ander in de vaten zal geheiligd worden. [^5] Toen gaf de priester hem dat heilige brood, dewijl er geen brood was dan de toonbroden, die van voor het aangezicht des HEEREN weggenomen waren, dat men er warm brood legde, ten dage als dat weggenomen werd. [^6] Daar was nu een man van de knechten van Saul, te dienzelven dage opgehouden voor het aangezicht des HEEREN, en zijn naam was Doëg, een Edomiet, de machtigste onder de herderen, die Saul had. [^7] En David zeide tot Achimelech: Is hier onder uw hand geen spies of zwaard? Want ik heb noch mijn zwaard noch ook mijn wapenen in mijn hand genomen, dewijl de zaak des konings haastig was. [^8] Toen zeide de priester: Het zwaard van Goliath, den Filistijn, denwelken gij sloegt in het eikendal, zie, dat is hier, gewonden in een kleed, achter den efod; indien gij u dat nemen wilt, zo neem het, want hier is geen ander dan dit. David nu zeide: Er is zijns gelijke niet; geef het mij. [^9] En David maakte zich op, en vluchtte te dien dage van het aangezicht van Saul; en hij kwam tot Achis, den koning van Gath. [^10] Doch de knechten van Achis zeiden tot hem: Is deze niet David, de koning des lands? Zong men niet van dezen in de reien, zeggende: Saul heeft zijn duizenden verslagen, maar David zijn tienduizenden? [^11] En David legde deze woorden in zijn hart; en hij was zeer bevreesd voor het aangezicht van Achis, den koning van Gath. [^12] Daarom veranderde hij zijn gelaat voor hun ogen, en hij maakte zichzelven gek onder hun handen; en hij bekrabbelde de deuren der poort, en hij liet zijn zever in zijn baard aflopen. [^13] Toen zeide Achis tot zijn knechten: Ziet, gij ziet, dat de man razende is, waarom hebt gij hem tot mij gebracht? [^14] Heb ik razenden gebrek, dat gij dezen gebracht hebt, om voor mij te razen? Zal deze in mijn huis komen? [^15] 

[[1 Samuel - 20|<--]] 1 Samuel - 21 [[1 Samuel - 22|-->]]

---
# Notes
