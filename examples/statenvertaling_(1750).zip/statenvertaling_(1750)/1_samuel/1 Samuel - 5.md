---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 5 - Statenvertaling (1750)"
---
[[1 Samuel - 4|<--]] 1 Samuel - 5 [[1 Samuel - 6|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[1 Samuel]]

# 1 Samuel - 5

De Filistijnen nu namen de ark Gods, en zij brachten ze van Eben-Haëzer tot Asdod. [^1] En de Filistijnen namen de ark Gods, en zij brachten ze in het huis van Dagon, en stelden ze bij Dagon. [^2] Maar als die van Asdod des anderen daags vroeg opstonden, ziet, zo was Dagon op zijn aangezicht ter aarde gevallen voor de ark des HEEREN. En zij namen Dagon en zetten hem weder op zijn plaats. [^3] Toen zij nu des anderen daags des morgens vroeg opstonden, ziet, Dagon lag op zijn aangezicht ter aarde gevallen voor de ark des HEEREN; maar het hoofd van Dagon, en de beide palmen zijner handen afgehouwen, aan den dorpel; alleenlijk was Dagon daarop overgebleven. [^4] Daarom treden de priesters van Dagon, en allen, die in het huis van Dagon komen, niet op den dorpel van Dagon te Asdod, tot op dezen dag. [^5] Doch de hand des HEEREN was zwaar over die van Asdod, en verwoestte hen; en Hij sloeg ze met spenen, Asdod en haar landpalen. [^6] Toen nu de mannen te Asdod zagen, dat het alzo toeging, zo zeiden zij: Dat de ark des Gods van Israël bij ons niet blijve; want Zijn hand is hard over ons, en over Dagon, onzen god. [^7] Daarom zonden zij heen, en verzamelden tot zich al de vorsten der Filistijnen, en zij zeiden: Wat zullen wij met de ark des Gods van Israël doen? En die zeiden: Dat de ark des Gods van Israël rondom Gath ga. Alzo droegen zij de ark des Gods van Israël rondom. [^8] En het geschiedde, nadat zij die hadden rondom gedragen, zo was de hand des HEEREN tegen die stad met een zeer grote kwelling; want Hij sloeg de lieden dier stad van den kleine tot den grote, en zij hadden spenen in de verborgene plaatsen. [^9] Toen zonden zij de ark Gods naar Ekron; maar het geschiedde, als de ark Gods te Ekron kwam, zo riepen die van Ekron, zeggende: Zij hebben de ark des Gods van Israël tot mij rondom gebracht, om mij en mijn volk te doden. [^10] En zij zonden heen, en vergaderden al de vorsten der Filistijnen, en zeiden: Zendt de ark des Gods van Israël heen, dat zij wederkere tot haar plaats, opdat zij mij en mijn volk niet dode; want er was een dodelijke kwelling in de ganse stad, en de hand Gods was er zeer zwaar. [^11] En de mensen, die niet stierven, werden geslagen met spenen, zodat het geschrei der stad opklom naar den hemel. [^12] 

[[1 Samuel - 4|<--]] 1 Samuel - 5 [[1 Samuel - 6|-->]]

---
# Notes
