---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 7 - Statenvertaling (1750)"
---
[[1 Samuel - 6|<--]] 1 Samuel - 7 [[1 Samuel - 8|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[1 Samuel]]

# 1 Samuel - 7

Toen kwamen de mannen van Kirjath-Jearim, en haalden de ark des HEEREN op, en zij brachten ze in het huis van Abinadab, op den heuvel; en zij heiligden zijn zoon Eleazar, dat hij de ark des HEEREN bewaarde. [^1] En het geschiedde, van dien dag af, dat de ark des Heeren te Kirjath-Jearim bleef, en de dagen werden vermenigvuldigd, en het werden twintig jaren; en het ganse huis van Israël klaagde den HEERE achterna. [^2] Toen sprak Samuël tot het ganse huis van Israël, zeggende: Indien gijlieden u met uw ganse hart tot den HEERE bekeert, zo doet de vreemde goden uit het midden van u weg, ook de Astharoths; en richt uw hart tot den HEERE, en dient Hem alleen, zo zal Hij u uit de hand der Filistijnen rukken. [^3] De kinderen Israëls nu deden de Baäls en de Astharoths weg, en zij dienden den HEERE alleen. [^4] Verder zeide Samuël: Vergadert het ganse Israël naar Mizpa, en ik zal den HEERE voor u bidden. [^5] En zij werden vergaderd te Mizpa, en zij schepten water, en goten het uit voor het aangezicht des HEEREN; en zij vastten te dien dage, en zeiden aldaar: Wij hebben tegen den HEERE gezondigd. Alzo richtte Samuël de kinderen Israëls te Mizpa. [^6] Toen de Filistijnen hoorden, dat de kinderen Israëls zich vergaderd hadden te Mizpa, zo kwamen de oversten der Filistijnen op tegen Israël. Als de kinderen Israëls dat hoorden, zo vreesden zij voor het aangezicht der Filistijnen. [^7] En de kinderen Israëls zeiden tot Samuël: Zwijg niet van onzentwege, dat gij niet zoudt roepen tot den HEERE, onzen God, opdat Hij ons verlosse uit de hand der Filistijnen. [^8] Toen nam Samuël een melklam, en hij offerde het geheel den HEERE ten brandoffer; en Samuël riep tot den HEERE voor Israël; en de HEERE verhoorde hem. [^9] En het geschiedde, toen Samuël dat brandoffer offerde, zo kwamen de Filistijnen aan ten strijde tegen Israël; en de HEERE donderde te dien dage met een groten donder over de Filistijnen, en Hij verschrikte hen, zodat zij verslagen werden voor het aangezicht van Israël. [^10] En de mannen van Israël togen uit van Mizpa, en vervolgden de Filistijnen, en zij sloegen hen tot onder Beth-kar. [^11] Samuël nu nam een steen, en stelde dien tussen Mizpa en tussen Sen, en hij noemde diens naam Eben-Haëzer; en hij zeide: Tot hiertoe heeft ons de HEERE geholpen. [^12] Alzo werden de Filistijnen vernederd, en kwamen niet meer in de landpalen van Israël; want de hand des HEEREN was tegen de Filistijnen al de dagen van Samuël. [^13] En de steden, welke de Filistijnen van Israël genomen hadden kwamen weder aan Israël, van Ekron tot Gath toe; ook rukte Israël derzelver landpale uit de hand der Filistijnen; en er was vrede tussen Israël en tussen de Amorieten. [^14] Samuël nu richtte Israël al de dagen zijns levens. [^15] En hij toog van jaar tot jaar, en ging rondom naar Beth-El, en Gilgal, en Mizpa; en hij richtte Israël in al die plaatsen. [^16] Doch hij keerde weder naar Rama; want daar was zijn huis, en daar richtte hij Israël; en hij bouwde aldaar den HEERE een altaar. [^17] 

[[1 Samuel - 6|<--]] 1 Samuel - 7 [[1 Samuel - 8|-->]]

---
# Notes
