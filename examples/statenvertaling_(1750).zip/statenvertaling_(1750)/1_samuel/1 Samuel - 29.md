---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 29 - Statenvertaling (1750)"
---
[[1 Samuel - 28|<--]] 1 Samuel - 29 [[1 Samuel - 30|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[1 Samuel]]

# 1 Samuel - 29

De Filistijnen nu hadden al hun legers vergaderd te Afek; en de Israëlieten legerden zich bij de fontein, die bij Jizreël is. [^1] En de vorsten der Filistijnen togen daarheen met honderden, en met duizenden; doch David met zijn mannen togen met Achis in den achtertocht. [^2] Toen zeiden de oversten der Filistijnen: Wat zullen deze Hebreën? Zo zeide Achis tot de oversten der Filistijnen: Is deze niet David, de knecht van Saul, den koning van Israël, die deze dagen of deze jaren bij mij geweest is? En ik heb in hem niets gevonden van dien dag af, dat hij afgevallen is tot dezen dag toe. [^3] Doch de oversten der Filistijnen werden zeer toornig op hem, en de oversten der Filistijnen zeiden tot hem: Doe den man wederkeren, dat hij tot zijn plaats wederkere, waar gij hem besteld hebt, en dat hij niet met ons aftrekke in den strijd, opdat hij ons niet tot een tegenpartijder worde in den strijd; want waarmede zou deze zich bij zijn heer aangenaam maken? Is het niet met de hoofden dezer mannen? [^4] Is dit niet die David, van denwelken zij in den rei elkander antwoordden, zeggende: Saul heeft zijn duizenden geslagen, maar David zijn tienduizenden? [^5] Toen riep Achis David, en zeide tot hem: Het is zo waarachtig als de HEERE leeft, dat gij oprecht zijt, en uw uitgang en uw ingang met mij in het leger is goed in mijn ogen; want ik heb geen kwaad bij u gevonden, van dien dag af, dat gij tot mij zijt gekomen, tot dezen dag toe; maar gij zijt niet aangenaam in de ogen der vorsten. [^6] Zo keer nu om, en ga in vrede, opdat gij geen kwaad doet in de ogen van de vorsten der Filistijnen. [^7] Toen zeide David tot Achis: Maar wat heb ik gedaan? Of wat hebt gij in uw knecht gevonden, van dien dag af, dat ik voor uw aangezicht geweest ben, tot dezen dag toe, dat ik niet zal gaan en strijden tegen de vijanden van mijn heer, den koning? [^8] Achis nu antwoordde en zeide tot David: Ik weet het; voorwaar, gij zijt aangenaam in mijn ogen, als een engel Gods; maar de oversten der Filistijnen hebben gezegd: Laat hem met ons in dezen strijd niet optrekken. [^9] Nu dan, maak u morgen vroeg op met de knechten uws heren, die met u gekomen zijn; en als gijlieden u morgen vroeg zult opgemaakt hebben, en het ulieden licht geworden is, zo gaat heen. [^10] Toen maakte zich David vroeg op, hij en zijn mannen, dat zij des morgens weggingen, om weder te keren in het land der Filistijnen; de Filistijnen daarentegen togen op naar Jizreël. [^11] 

[[1 Samuel - 28|<--]] 1 Samuel - 29 [[1 Samuel - 30|-->]]

---
# Notes
