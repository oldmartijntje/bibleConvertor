---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 13 - Statenvertaling (1750)"
---
[[1 Samuel - 12|<--]] 1 Samuel - 13 [[1 Samuel - 14|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[1 Samuel]]

# 1 Samuel - 13

Saul was een jaar in zijn regering geweest, en het tweede jaar regeerde hij over Israël. [^1] Toen verkoos zich Saul drie duizend mannen uit Israël; en er waren bij Saul twee duizend te Michmas en op het gebergte van Beth-El, en duizend waren er bij Jonathan te Gibea-Benjamins; en het overige des volks liet hij gaan, een iegelijk naar zijn tent. [^2] Doch Jonathan sloeg de bezetting der Filistijnen, die te Geba was, hetwelk de Filistijnen hoorden. Daarom blies Saul met de bazuin in het ganse land, zeggende: Laat het de Hebreën horen. [^3] Toen hoorde het ganse Israël zeggen: Saul heeft de bezetting der Filistijnen geslagen, en ook is Israël stinkende geworden bij de Filistijnen. Toen werd het volk samengeroepen achter Saul, naar Gilgal. [^4] En de Filistijnen werden verzameld om te strijden tegen Israël, dertig duizend wagens, en zes duizend ruiters, en volk in menigte als het zand, dat aan den oever der zee is; en zij togen op, en legerden zich te Michmas, tegen het oosten van Beth-aven. [^5] Toen de mannen van Israël zagen, dat zij in nood waren (want het volk was benauwd), zo verborg zich het volk in de spelonken, en in de doornbossen, en in de steenklippen, en in de vestingen, en in de putten. [^6] De Hebreën nu gingen over de Jordaan in het land van Gad en Gilead. Toen Saul nog zelf te Gilgal was, zo kwam al het volk bevende achter hem. [^7] En hij vertoefde zeven dagen, tot den tijd, dien Samuël bestemd had. Als Samuël te Gilgal niet opkwam, zo verstrooide het volk van hem. [^8] Toen zeide Saul: Brengt tot mij herwaarts een brandoffer, en dankofferen; en hij offerde brandoffer. [^9] En het geschiedde, toen hij geëindigd had het brandoffer te offeren, ziet, zo kwam Samuël; en Saul ging uit hem tegemoet, om hem te zegenen. [^10] Toen zeide Samuël: Wat hebt gij gedaan? Saul nu zeide: Omdat ik zag, dat zich het volk van mij verstrooide, en gij op den bestemden tijd der dagen niet kwaamt, en de Filistijnen te Michmas vergaderd waren, [^11] Zo zeide ik: Nu zullen de Filistijnen tot mij afkomen te Gilgal, en ik heb het aangezicht des HEEREN niet ernstelijk aangebeden, zo dwong ik mijzelven, en heb brandoffer geofferd. [^12] Toen zeide Samuël tot Saul: Gij hebt zottelijk gedaan; gij hebt het gebod van den HEERE, uw God, niet gehouden, dat Hij u geboden heeft; want de HEERE zou nu uw rijk over Israël bevestigd hebben tot in eeuwigheid. [^13] Maar nu zal uw rijk niet bestaan. De HEERE heeft Zich een man gezocht naar Zijn hart, en de HEERE heeft hem geboden een voorganger te zijn over Zijn volk, omdat gij niet gehouden hebt, wat u de HEERE geboden had. [^14] Toen maakte zich Samuël op, en hij ging op van Gilgal naar Gibea-Benjamins; en Saul telde het volk, dat bij hem gevonden werd, omtrent zeshonderd man. [^15] En Saul en zijn zoon Jonathan, en het volk, dat bij hen gevonden was, bleven te Gibea-Benjamins; maar de Filistijnen waren te Michmas gelegerd. [^16] En de verdervers gingen uit het leger der Filistijnen, in drie hopen; de ene hoop keerde zich op den weg naar Ofra, naar het land Sual; [^17] En een hoop keerde zich naar den weg van Beth-Horon; en een hoop keerde zich naar den weg der landpale, die naar het dal Zeboïm naar de woestijn uitziet. [^18] En er werd geen smid gevonden in het ganse land van Israël; want de Filistijnen hadden gezegd: Opdat de Hebreën geen zwaard noch spies maken. [^19] Daarom moest gans Israël tot de Filistijnen aftrekken, opdat een iegelijk zijn ploegijzer, of zijn spade, of zijn bijl, of zijn houweel scherpen liet. [^20] Maar zij hadden tandige vijlen tot hun houwelen, en tot hun spaden, en tot de drietandige vorken, en tot de bijlen, en tot het stellen der prikkelen. [^21] En het geschiedde ten dage des strijds, dat er geen zwaard noch spies gevonden werd in de hand van het ganse volk, dat bij Saul en bij Jonathan was; doch bij Saul en bij Jonathan, zijn zoon, werden zij gevonden. [^22] En der Filistijnen leger toog naar den doortocht van Michmas. [^23] 

[[1 Samuel - 12|<--]] 1 Samuel - 13 [[1 Samuel - 14|-->]]

---
# Notes
