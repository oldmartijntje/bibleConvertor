---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 8 - Statenvertaling (1750)"
---
[[1 Samuel - 7|<--]] 1 Samuel - 8 [[1 Samuel - 9|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[1 Samuel]]

# 1 Samuel - 8

Het geschiedde nu, toen Samuël oud geworden was, zo stelde hij zijn zonen tot richters over Israël. [^1] De naam van zijn eerstgeborenen zoon nu was Joël, en de naam van zijn tweeden was Abia; zij waren richters te Berseba. [^2] Doch zijn zonen wandelden niet in zijn wegen; maar zij neigden zich tot de gierigheid, en namen geschenken, en bogen het recht. [^3] Toen vergaderden zich alle oudsten van Israël, en zij kwamen tot Samuël te Rama; [^4] En zij zeiden tot hem: Zie, gij zijt oud geworden, en uw zonen wandelen niet in uw wegen; zo zet nu een koning over ons, om ons te richten, gelijk al de volken hebben. [^5] Maar dit woord was kwaad in de ogen van Samuël, als zij zeiden: Geef ons een koning, om ons te richten. En Samuël bad den HEERE aan. [^6] Doch de HEERE zeide tot Samuël: Hoor naar de stem des volks in alles, wat zij tot u zeggen zullen; want zij hebben u niet verworpen, maar zij hebben Mij verworpen, dat Ik geen Koning over hen zal zijn. [^7] Naar al de werken, die zij gedaan hebben, van dien dag af, toen Ik hen uit Egypte geleid heb, tot op dezen dag toe, en hebben Mij verlaten en andere goden gediend; alzo doen zij u ook. [^8] Hoor dan nu naar hun stem; doch als gij hen op het hoogste zult betuigd hebben, zo zult gij hen te kennen geven de wijze des konings, die over hen regeren zal. [^9] Samuël nu zeide al de woorden des HEEREN het volk aan, hetwelk een koning van hem begeerde. [^10] En zeide: Dit zal des konings wijze zijn, die over u regeren zal: hij zal uw zonen nemen, dat hij hen zich stelle tot zijn wagen, en tot zijn ruiteren, dat zij voor zijn wagen henen lopen; [^11] En dat hij hen zich stelle tot oversten der duizenden, en tot oversten der vijftigen; en dat zij zijn akker ploegen, en dat zij zijn oogst oogsten, en dat zij zijn krijgswapenen maken, mitsgaders zijn wapentuig. [^12] En uw dochteren zal hij nemen tot apothekeressen, en tot keukenmaagden, en tot baksters. [^13] En uw akkers, en uw wijngaarden, en uw olijfgaarden, die de beste zijn, zal hij nemen, en zal ze aan zijn knechten geven. [^14] En uw zaad, en uw wijngaarden zal hij vertienen, en hij zal ze aan zijn hovelingen, en aan zijn knechten geven. [^15] En hij zal uw knechten, en uw dienstmaagden, en uw beste jongelingen, en uw ezelen nemen, en hij zal zijn werk daarmede doen. [^16] Hij zal uw kudden vertienen; en gij zult hem tot knechten zijn. [^17] Gij zult wel te dien dage roepen, vanwege uw koning, dien gij u zult verkoren hebben, maar de HEERE zal u te dien dage niet verhoren. [^18] Doch het volk weigerde Samuëls stem te horen; en zij zeiden: Neen, maar er zal een koning over ons zijn. [^19] En wij zullen ook zijn gelijk al de volken; en onze koning zal ons richten, en hij zal voor onze aangezichten uitgaan, en hij zal onze krijgen voeren. [^20] Als Samuël al de woorden des volks gehoord had, zo sprak hij dezelve voor de oren des HEEREN. [^21] De HEERE nu zeide tot Samuël: Hoor naar hun stem, en stel hun een koning. Toen zeide Samuël tot de mannen van Israël: Gaat heen, een iegelijk naar zijn stad. [^22] 

[[1 Samuel - 7|<--]] 1 Samuel - 8 [[1 Samuel - 9|-->]]

---
# Notes
