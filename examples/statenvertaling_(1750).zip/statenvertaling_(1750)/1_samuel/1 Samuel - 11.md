---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 11 - Statenvertaling (1750)"
---
[[1 Samuel - 10|<--]] 1 Samuel - 11 [[1 Samuel - 12|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[1 Samuel]]

# 1 Samuel - 11

Toen toog Nahas, de Ammoniet, op, en belegerde Jabes in Gilead. En al de mannen van Jabes zeiden tot Nahas: Maak een verbond met ons, zo zullen wij u dienen. [^1] Doch Nahas, de Ammoniet, zeide tot hen: Mits dezen zal ik een verbond met ulieden maken, dat ik u allen het rechteroog uitsteke; en dat ik deze schande op gans Israël legge. [^2] Toen zeiden tot hem de oudsten van Jabes: Laat zeven dagen van ons af, dat wij boden zenden in al de landpalen van Israël; is er dan niemand, die ons verlost, zo zullen wij tot u uitgaan. [^3] Als de boden te Gibea-Sauls kwamen, zo spraken zij deze woorden voor de oren van het volk. Toen hief al het volk zijn stem op, en weende. [^4] En ziet, Saul kwam achter de runderen uit het veld, en Saul zeide: Wat is den volke, dat zij wenen? Toen vertelden zij hem de woorden der mannen van Jabes. [^5] Toen werd de Geest Gods vaardig over Saul, als hij deze woorden hoorde; en zijn toorn ontstak zeer. [^6] En hij nam een paar runderen, en hieuw ze in stukken, en hij zond ze in alle landpalen van Israël door de hand der boden, zeggende: Die niet zelf uittrekt achter Saul en achter Samuël, alzo zal men zijn runderen doen. Toen viel de vreze des HEEREN op het volk, en zij gingen uit als een enig man. [^7] En hij telde hen te Bezek; en van de kinderen Israëls waren driehonderd duizend, en van de mannen van Juda dertig duizend. [^8] Toen zeiden zij tot de boden, die gekomen waren: Aldus zult gijlieden den mannen te Jabes in Gilead zeggen: Morgen zal u verlossing geschieden, als de zon heet worden zal. Als de boden kwamen, en verkondigden dat aan de mannen te Jabes, zo werden zij verblijd. [^9] En de mannen van Jabes zeiden: Morgen zullen wij tot ulieden uitgaan, en gij zult ons doen naar alles, wat goed is in uw ogen. [^10] Het geschiedde nu des anderen daags, dat Saul het volk stelde in drie hopen, en zij kwamen in het midden des legers, in de morgenwake, en zij sloegen Ammon, totdat de dag heet werd; en het geschiedde, dat de overigen alzo verstrooid werden, dat er onder hen geen twee te zamen bleven. [^11] Toen zeide het volk tot Samuël: Wie is hij, die zeide: Zou Saul over ons regeren? Geeft hier die mannen, dat wij hen doden. [^12] Maar Saul zeide: Er zal te dezen dage geen man gedood worden, want de HEERE heeft heden een verlossing in Israël gedaan. [^13] Verder zeide Samuël tot het volk: Komt en laat ons naar Gilgal gaan, en het koninkrijk aldaar vernieuwen. [^14] Toen ging al het volk naar Gilgal, en maakte Saul aldaar koning voor het aangezicht des HEEREN te Gilgal; en zij offerden aldaar dankofferen voor het aangezicht des HEEREN; en Saul verheugde zich aldaar gans zeer, met al de mannen van Israël. [^15] 

[[1 Samuel - 10|<--]] 1 Samuel - 11 [[1 Samuel - 12|-->]]

---
# Notes
