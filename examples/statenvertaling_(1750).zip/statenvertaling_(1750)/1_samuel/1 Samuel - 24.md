---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 24 - Statenvertaling (1750)"
---
[[1 Samuel - 23|<--]] 1 Samuel - 24 [[1 Samuel - 25|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[1 Samuel]]

# 1 Samuel - 24

En David toog van daar op, en hij bleef in de vestingen van En-gedi. [^1] En het geschiedde, nadat Saul wedergekeerd was van achter de Filistijnen, zo gaf men hem te kennen, zeggende: Zie, David is in de woestijn van En-gedi. [^2] Toen nam Saul drie duizend uitgelezen mannen uit gans Israël, en hij toog heen, om David en zijn mannen te zoeken boven op de rotsstenen der steenbokken. [^3] En hij kwam tot de schaapskooien aan den weg, waar een spelonk was; en Saul ging daarin, om zijn voeten te dekken. David nu en zijn mannen zaten aan de zijden der spelonk. [^4] Toen zeiden de mannen van David tot hem: Zie den dag, in welken de HEERE tot u zegt: Zie, Ik geef uw vijand in uw hand, en gij zult hem doen, gelijk als het goed zal zijn in uw ogen. En David stond op, en sneed stilletjes een slip van Sauls mantel. [^5] Doch het geschiedde daarna, dat Davids hart hem sloeg, omdat hij de slip van Saul afgesneden had. [^6] En hij zeide tot zijn mannen: Dat late de HEERE ver van mij zijn, dat ik die zaak doen zou aan mijn heer, den gezalfde des HEEREN, dat ik mijn hand tegen hem uitsteken zou; want hij is de gezalfde des HEEREN! [^7] En David scheidde zijn mannen met woorden, en liet hun niet toe, dat zij opstonden tegen Saul. En Saul maakte zich op uit de spelonk, en ging op den weg. [^8] Daarna maakte zich David ook op, en ging uit de spelonk, en hij riep Saul achterna, zeggende: Mijn heer koning! Toen zag Saul achter zich om, en David boog zich met het aangezicht ter aarde en neigde zich. [^9] En David zeide tot Saul: Waarom hoort gij de woorden der mensen, zeggende: Zie, David zoekt uw kwaad? [^10] Zie, te dezen dage hebben uw ogen gezien, dat de HEERE u heden in mijn hand gegeven heeft in deze spelonk, en men zeide, dat ik u doden zou; doch mijn hand verschoonde u, want ik zeide: Ik zal mijn hand niet uitsteken tegen mijn heer, want hij is de gezalfde des HEEREN. [^11] Zie toch, mijn vader, ja, zie de slip uws mantels in mijn hand; want als ik de slip uws mantels afgesneden heb, zo heb ik u niet gedood; beken en zie, dat er in mijn hand geen kwaad, noch overtreding is, en ik tegen u niet gezondigd heb; nochtans jaagt gij mijn ziel, dat gij ze wegneemt. [^12] De HEERE zal richten tussen mij en tussen u, en de HEERE zal mij wreken aan u; maar mijn hand zal niet tegen u zijn. [^13] Gelijk als het spreekwoord der ouden zegt: Van de goddelozen komt goddeloosheid voort; maar mijn hand zal niet tegen u zijn. [^14] Naar wien is de koning van Israël uitgegaan? Wien jaagt gij na? Naar een doden hond, naar een enige vlo! [^15] Doch de HEERE zal zijn tot Rechter, en richten tussen mij en tussen u, en zien daarin, en twisten mijn twist, en richten mij van uw hand. [^16] En het geschiedde, toen David geëindigd had al deze woorden tot Saul te spreken, zo zeide Saul: Is dit uw stem, mijn zoon David? Toen hief Saul zijn stem op en weende. [^17] En hij zeide tot David: Gij zijt rechtvaardiger dan ik; want gij hebt mij goed vergolden, en ik heb u kwaad vergolden. [^18] En gij hebt mij heden aangewezen, dat gij mij goed gedaan hebt; want de HEERE had mij in uw hand besloten, en gij hebt mij niet gedood. [^19] Zo wanneer iemand zijn vijand gevonden heeft, zal hij hem op een goeden weg laten gaan? De HEERE nu vergelde u het goede, voor dezen dag, dien gij mij heden gemaakt hebt. [^20] En nu, zie, ik weet, dat gij voorzeker koning worden zult, en dat het koninkrijk van Israël in uw hand bestaan zal. [^21] Zo zweer mij dan nu bij den HEERE, zo gij mijn zaad na mij zult uitroeien, en mijn naam zult uitdelgen van mijns vaders huis! [^22] Toen zwoer David aan Saul; en Saul ging in zijn huis, maar David en zijn mannen gingen op in de vesting. [^23] 

[[1 Samuel - 23|<--]] 1 Samuel - 24 [[1 Samuel - 25|-->]]

---
# Notes
