---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 27 - Statenvertaling (1750)"
---
[[1 Samuel - 26|<--]] 1 Samuel - 27 [[1 Samuel - 28|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[1 Samuel]]

# 1 Samuel - 27

David nu zeide in zijn hart: Nu zal ik een der dagen door Sauls hand omkomen; mij is niet beter, dan dat ik haastelijk ontkome in het land der Filistijnen, opdat Saul van mij de hoop verlieze, om mij meer te zoeken in de ganse landpale van Israël; zo zal ik ontkomen uit zijn hand. [^1] Toen maakte zich David op, en hij ging door, hij en de zeshonderd mannen, die bij hem waren, tot Achis, den zoon van Maoch, den koning van Gath. [^2] En David bleef bij Achis te Gath, hij en zijn mannen, een iegelijk met zijn huis; David met zijn beide vrouwen, Ahinoam, de Jizreëlietische, en Abigaïl, de huisvrouw van Nabal, de Karmelietische. [^3] Toen aan Saul geboodschapt werd, dat David gevlucht was naar Gath, zo voer hij niet meer voort hem te zoeken. [^4] En David zeide tot Achis: Indien ik nu genade in uw ogen gevonden heb, men geve mij een plaats in een van de steden des lands, dat ik daar wone; want waarom zou uw knecht in de koninklijke stad bij u wonen? [^5] Toen gaf hem Achis te dien dage Ziklag; daarom is Ziklag van de koningen van Juda geweest tot op dezen dag. [^6] Het getal nu der dagen, die David in het land der Filistijnen woonde, was een jaar en vier maanden. [^7] David nu toog op met zijn mannen, en zij overvielen de Gesurieten, en de Girzieten, en de Amalekieten (want deze zijn van ouds geweest de inwoners des lands), daar gij gaat naar Sur, en tot aan Egypteland. [^8] En David sloeg dat land, en liet noch man noch vrouw leven; ook nam hij de schapen en runderen, en de ezelen, en kemels, en klederen, en keerde weder en kwam tot Achis. [^9] Als Achis zeide: Waar zijt gijlieden heden ingevallen? zo zeide David: Tegen het zuiden van Juda, en tegen het zuiden der Jerahmeëlieten, en tegen het zuiden der Kenieten. [^10] En David liet noch man noch vrouw leven, om te Gath te brengen, zeggende: Dat zij misschien van ons niet boodschappen, zeggende: Alzo heeft David gedaan! En alzo was zijn wijze al de dagen, die hij in der Filistijnen land gewoond heeft. [^11] En Achis geloofde David, zeggende: Hij heeft zich ten enenmaal stinkende gemaakt bij zijn volk, in Israël; daarom zal hij eeuwiglijk mij tot een knecht zijn. [^12] 

[[1 Samuel - 26|<--]] 1 Samuel - 27 [[1 Samuel - 28|-->]]

---
# Notes
