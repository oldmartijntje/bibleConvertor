---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 3 - Statenvertaling (1750)"
---
[[1 Samuel - 2|<--]] 1 Samuel - 3 [[1 Samuel - 4|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[1 Samuel]]

# 1 Samuel - 3

En de jongeling Samuël diende den HEERE voor het aangezicht van Eli; en het woord des HEEREN was dierbaar in die dagen; er was geen openbaar gezicht. [^1] En het geschiedde te dien dage, als Eli op zijn plaats nederlag (en zijn ogen begonnen donker te worden, dat hij niet zien kon), [^2] En Samuël zich ook nedergelegd had, eer de lampe Gods uitgedaan werd, in den tempel des HEEREN, waar de ark Gods was, [^3] Dat de HEERE Samuël riep; en hij zeide: Zie, hier ben ik. [^4] En hij liep tot Eli en zeide: Zie, hier ben ik, want gij hebt mij geroepen. Doch hij zeide: Ik heb niet geroepen, keer weder, leide u neder. En hij ging heen en legde zich neder. [^5] Toen riep de HEERE Samuël wederom; en Samuël stond op; en ging tot Eli, en zeide: Zie, hier ben ik, want gij hebt mij geroepen. Hij dan zeide: Ik heb niet geroepen, mijn zoon; keer weder, leg u neder. [^6] Doch Samuël kende den HEERE nog niet; en het woord des HEEREN was aan hem nog niet geopenbaard. [^7] Toen riep de HEERE Samuël wederom, ten derden maal; en hij stond op, en ging tot Eli, en zeide: Zie, hier ben ik, want gij hebt mij geroepen. Toen verstond Eli, dat de HEERE den jongeling riep. [^8] Daarom zeide Eli tot Samuël: Ga heen, leg u neder, en het zal geschieden, zo Hij u roept, zo zult gij zeggen: Spreek, HEERE, want Uw knecht hoort. Toen ging Samuël heen en legde zich aan zijn plaats. [^9] Toen kwam de HEERE, en stelde Zich daar, en riep gelijk de andere malen: Samuël, Samuël! En Samuël zeide: Spreek, want Uw knecht hoort. [^10] En de HEERE zeide tot Samuël: Zie, Ik doe een ding in Israël, dat al wie het horen zal, dien zullen zijn beide oren klinken. [^11] Te dienzelven dage zal Ik verwekken over Eli alles, wat Ik tegen zijn huis gesproken heb; Ik zal het beginnen en voleinden. [^12] Want Ik heb hem te kennen gegeven, dat Ik zijn huis rechten zal tot in eeuwigheid, om der ongerechtigheids wil, die hij geweten heeft; want als zijn zonen zich hebben vervloekt gemaakt, zo heeft hij hen niet eens zuur aangezien. [^13] Daarom dan heb Ik het huis van Eli gezworen: Zo de ongerechtigheid van het huis van Eli tot in eeuwigheid zal verzoend worden door slachtoffer of door spijsoffer! [^14] Samuël nu lag tot aan den morgen; toen deed hij de deuren van het huis des HEEREN open; doch Samuël vreesde dit gezicht aan Eli te kennen te geven. [^15] Toen riep Eli Samuël, en zeide: Mijn zoon Samuël! Hij dan zeide: Zie, hier ben ik. [^16] En hij zeide: Wat is het woord, dat Hij tot u gesproken heeft? Verberg het toch niet voor mij; God doe u zo, en zo doe Hij daartoe, indien gij een woord voor mij verbergt van al de woorden, die Hij tot u gesproken heeft! [^17] Toen gaf hem Samuël te kennen al die woorden, en verborg ze voor hem niet. En hij zeide: Hij is de HEERE; Hij doe, wat goed is in Zijn ogen! [^18] Samuël nu werd groot; en de HEERE was met hem, en liet niet een van al Zijn woorden op de aarde vallen. [^19] En gans Israël, van Dan tot Berseba toe, bekende, dat Samuël bevestigd was tot een profeet des HEEREN. [^20] En de HEERE voer voort te verschijnen te Silo; want de HEERE openbaarde Zich aan Samuël te Silo, door het woord des HEEREN. [^21] 

[[1 Samuel - 2|<--]] 1 Samuel - 3 [[1 Samuel - 4|-->]]

---
# Notes
