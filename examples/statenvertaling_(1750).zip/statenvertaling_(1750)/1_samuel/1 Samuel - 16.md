---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 16 - Statenvertaling (1750)"
---
[[1 Samuel - 15|<--]] 1 Samuel - 16 [[1 Samuel - 17|-->]]

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[1 Samuel]]

# 1 Samuel - 16

Toen zeide de HEERE tot Samuël: Hoe lang draagt gij leed om Saul, dien Ik toch verworpen heb, dat hij geen koning zij over Israël? Vul uw hoorn met olie, en ga heen; Ik zal u zenden tot Isaï, den Bethlehemiet; want Ik heb Mij een koning onder zijn zonen uitgezien. [^1] Maar Samuël zeide: Hoe zou ik heengaan? Saul zal het toch horen en mij doden. Toen zeide de HEERE: Neem een kalf van de runderen met u, en zeg: Ik ben gekomen, om den HEERE offerande te doen. [^2] En gij zult Isaï ten offer nodigen, en Ik zal u te kennen geven, wat gij doen zult, en gij zult Mij zalven, dien Ik u zeggen zal. [^3] Samuël nu deed, hetgeen de HEERE gesproken had, en hij kwam te Bethlehem. Toen kwamen de oudsten der stad bevende hem tegemoet, en zeiden: Is uw komst met vrede? [^4] Hij dan zeide: Met vrede; ik ben gekomen om den HEERE offerande te doen; heiligt u, en komt met mij ten offer; en hij heiligde Isaï en zijn zonen, en hij nodigde hen ten offer. [^5] En het geschiedde, toen zij inkwamen, zo zag hij Eliab aan, en dacht: Zekerlijk, is deze voor den HEERE, Zijn gezalfde. [^6] Doch de HEERE zeide tot Samuël: Zie zijn gestalte niet aan, noch de hoogte zijner statuur, want Ik heb hem verworpen; want het is niet gelijk de mens ziet; want de mens ziet aan, wat voor ogen is, maar de HEERE ziet het hart aan. [^7] Toen riep Isaï Abinadab, en hij deed hem voorbij het aangezicht van Samuël gaan; doch hij zeide: Dezen heeft de HEERE ook niet verkoren. [^8] Daarna liet Isaï Samma voorbijgaan; doch hij zeide: Dezen heeft de HEERE ook niet verkoren. [^9] Alzo liet Isaï zijn zeven zonen voorbij het aangezicht van Samuël gaan; doch Samuël zeide tot Isaï: De HEERE heeft dezen niet verkoren. [^10] Voorts zeide Samuël tot Isaï: Zijn dit al de jongelingen? En hij zeide: De kleinste is nog overig, en zie, hij weidt de schapen. Samuël nu zeide tot Isaï: Zend heen en laat hem halen; want wij zullen niet rondom aanzitten, totdat hij hier zal gekomen zijn. [^11] Toen zond hij heen, en bracht hem in; hij nu was roodachtig, mitsgaders schoon van ogen en schoon van aanzien; en de HEERE zeide: Sta op, zalf hem, want deze is het. [^12] Toen nam Samuël den oliehoorn, en hij zalfde hem in het midden zijner broederen. En de Geest des HEEREN werd vaardig over David van dien dag af en voortaan. Daarna stond Samuël op, en hij ging naar Rama. [^13] En de Geest des HEEREN week van Saul; en een boze geest van den HEERE verschrikte hem. [^14] Toen zeiden Sauls knechten tot hem: Zie toch, een boze geest Gods verschrikt u. [^15] Onze heer zegge toch tot uw knechten, die voor uw aangezicht staan, dat zij een man zoeken, die op de harp spelen kan; en het zal geschieden, als de boze geest Gods op u is, dat hij met zijn hand spele, dat het beter met u worde. [^16] Toen zeide Saul tot zijn knechten: Ziet mij toch naar een man uit, die wel spelen kan, en brengt hem tot mij. [^17] Toen antwoordde een van de jongelingen, en zeide: Zie, ik heb gezien een zoon van Isaï, den Bethlehemiet, die spelen kan, en hij is een dapper held, en een krijgsman, en verstandig in zaken, en een schoon man, en de HEERE is met hem. [^18] Saul nu zond boden tot Isaï, en zeide: Zend uw zoon David tot mij, die bij de schapen is. [^19] Toen nam Isaï een ezel met brood, en een lederen zak met wijn, en een geitenbokje; en hij zond ze door de hand van zijn zoon David aan Saul. [^20] Alzo kwam David tot Saul, en hij stond voor zijn aangezicht; en hij beminde hem zeer, en hij werd zijn wapendrager. [^21] Daarna zond Saul tot Isaï, om te zeggen: Laat toch David voor mijn aangezicht staan, want hij heeft genade in mijn ogen gevonden. [^22] En het geschiedde, als de geest Gods over Saul was, zo nam David de harp, en hij speelde met zijn hand; dat was voor Saul een verademing, en het werd beter met hem, en de boze geest week van hem. [^23] 

[[1 Samuel - 15|<--]] 1 Samuel - 16 [[1 Samuel - 17|-->]]

---
# Notes
