---
translation: Statenvertaling (1750)
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 31 - Statenvertaling (1750)"
---
[[1 Samuel - 30|<--]] 1 Samuel - 31

Translation: [[bible - Statenvertaling (1750)|Statenvertaling (1750)]]
Book: [[1 Samuel]]

# 1 Samuel - 31

De Filistijnen dan streden tegen Israël; en de mannen Israëls vloden voor het aangezicht der Filistijnen, en vielen verslagen op het gebergte Gilboa. [^1] En de Filistijnen hielden dicht op Saul en zijn zonen; en de Filistijnen sloegen Jonathan, en Abinadab, en Malchisua, de zonen van Saul. [^2] En de strijd werd zwaar tegen Saul; en de mannen, die met den boog schieten, troffen hem aan, en hij vreesde zeer voor de schutters. [^3] Toen zeide Saul tot zijn wapendrager: Trek uw zwaard uit, en doorsteek mij daarmede, dat misschien deze onbesnedenen niet komen, en mij doorsteken, en met mij den spot drijven. Maar zijn wapendrager wilde niet, want hij vreesde zeer. Toen nam Saul het zwaard, en viel daarin. [^4] Toen zijn wapendrager zag, dat Saul dood was, zo viel hij ook in zijn zwaard en stierf met hem. [^5] Alzo stierf Saul, en zijn drie zonen, en zijn wapendrager, ook al zijn mannen, te dienzelven dage te gelijk. [^6] Als de mannen van Israël, die aan deze zijde van het dal waren, en die aan deze zijde der Jordaan waren, zagen, dat de mannen van Israël gevloden waren, en dat Saul en zijn zonen dood waren, zo verlieten zij de steden, en zij vloden. Toen kwamen de Filistijnen en woonden daarin. [^7] Het geschiedde nu des anderen daags, als de Filistijnen kwamen, om de verslagenen te plunderen, zo vonden zij Saul en zijn drie zonen, liggende op het gebergte Gilboa. [^8] En zij hieuwen zijn hoofd af, en zij togen zijn wapenen uit, en zij zonden ze in der Filistijnen land rondom, om te boodschappen in het huis hunner afgoden, en onder het volk. [^9] En zij legden zijn wapenen in het huis van Astharoth; en zijn lichaam hechtten zij aan den muur te Beth-San. [^10] Als de inwoners van Jabes in Gilead daarvan hoorden, wat de Filistijnen Saul gedaan hadden; [^11] Zo maakten zich op alle strijdbare mannen, en gingen den gehelen nacht, en zij namen het lichaam van Saul, en de lichamen zijner zonen, van den muur te Beth-San; en zij kwamen te Jabes, en brandden ze aldaar. [^12] En zij namen hun beenderen, en begroeven ze onder het geboomte te Jabes; en zij vastten zeven dagen. [^13] 

[[1 Samuel - 30|<--]] 1 Samuel - 31

---
# Notes
