---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/nehemiah"
  - "#bible/testament/old"
aliases:
  - "Nehemiah - 2 - King James Version"
---
[[Nehemiah - 1|<--]] Nehemiah - 2 [[Nehemiah - 3|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Nehemiah]]

# Nehemiah - 2

And it came to pass in the month Nisan, in the twentieth year of Artaxerxes the king, that wine was before him: and I took up the wine, and gave it unto the king. Now I had not been beforetime sad in his presence. [^1] Wherefore the king said unto me, Why is thy countenance sad, seeing thou art not sick? this is nothing else but sorrow of heart. Then I was very sore afraid, [^2] and said unto the king, Let the king live for ever: why should not my countenance be sad, when the city, the place of my fathers' sepulchres, lieth waste, and the gates thereof are consumed with fire? [^3] Then the king said unto me, For what dost thou make request? So I prayed to the God of heaven. [^4] And I said unto the king, If it please the king, and if thy servant have found favour in thy sight, that thou wouldest send me unto Judah, unto the city of my fathers' sepulchres, that I may build it. [^5] And the king said unto me, (the queen also sitting by him,) For how long shall thy journey be? and when wilt thou return? So it pleased the king to send me; and I set him a time. [^6] Moreover I said unto the king, If it please the king, let letters be given me to the governors beyond the river, that they may convey me over till I come into Judah; [^7] and a letter unto Asaph the keeper of the king's forest, that he may give me timber to make beams for the gates of the palace which appertained to the house, and for the wall of the city, and for the house that I shall enter into. And the king granted me, according to the good hand of my God upon me. [^8] Then I came to the governors beyond the river, and gave them the king's letters. Now the king had sent captains of the army and horsemen with me. [^9] When Sanballat the Horonite, and Tobiah the servant, the Ammonite, heard of it grieved them exceedingly that there was come a man to seek the welfare of the children of Israel. [^10] So I came to Jerusalem, and was there three days. [^11] And I arose in the night, I and some few men with me; neither told I any man what my God had put in my heart to do at Jerusalem: neither was there any beast with me, save the beast that I rode upon. [^12] And I went out by night by the gate of the valley, even before the dragon well, and to the dung port, and viewed the walls of Jerusalem, which were broken down, and the gates thereof were consumed with fire. [^13] Then I went on to the gate of the fountain, and to the king's pool: but there was no place for the beast that was under me to pass. [^14] Then went I up in the night by the brook, and viewed the wall, and turned back, and entered by the gate of the valley, and so returned. [^15] And the rulers knew not whither I went, or what I did; neither had I as yet told it to the Jews, nor to the priests, nor to the nobles, nor to the rulers, nor to the rest that did the work. [^16] Then said I unto them, Ye see the distress that we are in, how Jerusalem lieth waste, and the gates thereof are burned with fire: come, and let us build up the wall of Jerusalem, that we be no more a reproach. [^17] Then I told them of the hand of my God which was good upon me; as also the king's words that he had spoken unto me. And they said, Let us rise up and build. So they strengthened their hands for this good work. [^18] But when Sanballat the Horonite, and Tobiah the servant, the Ammonite, and Geshem the Arabian, heard it, they laughed us to scorn, and despised us, and said, What is this thing that ye do? will ye rebel against the king? [^19] Then answered I them, and said unto them, The God of heaven, he will prosper us; therefore we his servants will arise and build: but ye have no portion, nor right, nor memorial, in Jerusalem. [^20] 

[[Nehemiah - 1|<--]] Nehemiah - 2 [[Nehemiah - 3|-->]]

---
# Notes
