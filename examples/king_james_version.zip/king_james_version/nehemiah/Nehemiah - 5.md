---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/nehemiah"
  - "#bible/testament/old"
aliases:
  - "Nehemiah - 5 - King James Version"
---
[[Nehemiah - 4|<--]] Nehemiah - 5 [[Nehemiah - 6|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Nehemiah]]

# Nehemiah - 5

And there was a great cry of the people and of their wives against their brethren the Jews. [^1] For there were that said, We, our sons, and our daughters, are many: therefore we take up corn for them, that we may eat, and live. [^2] Some also there were that said, We have mortgaged our lands, vineyards, and houses, that we might buy corn, because of the dearth. [^3] There were also that said, We have borrowed money for the king's tribute, and that upon our lands and vineyards. [^4] Yet now our flesh is as the flesh of our brethren, our children as their children: and, lo, we bring into bondage our sons and our daughters to be servants, and some of our daughters are brought unto bondage already: neither is it in our power to redeem them; for other men have our lands and vineyards. [^5] And I was very angry when I heard their cry and these words. [^6] Then I consulted with myself, and I rebuked the nobles, and the rulers, and said unto them, Ye exact usury, every one of his brother. And I set a great assembly against them. [^7] And I said unto them, We after our ability have redeemed our brethren the Jews, which were sold unto the heathen; and will ye even sell your brethren? or shall they be sold unto us? Then held they their peace, and found nothing to answer. [^8] Also I said, It is not good that ye do: ought ye not to walk in the fear of our God because of the reproach of the heathen our enemies? [^9] I likewise, and my brethren, and my servants, might exact of them money and corn: I pray you, let us leave off this usury. [^10] Restore, I pray you, to them, even this day, their lands, their vineyards, their oliveyards, and their houses, also the hundredth part of the money, and of the corn, the wine, and the oil, that ye exact of them. [^11] Then said they, We will restore them, and will require nothing of them; so will we do as thou sayest. Then I called the priests, and took an oath of them, that they should do according to this promise. [^12] Also I shook my lap, and said, So God shake out every man from his house, and from his labour, that performeth not this promise, even thus be he shaken out, and emptied. And all the congregation said, Amen, and praised the LORD. And the people did according to this promise. [^13] Moreover from the time that I was appointed to be their governor in the land of Judah, from the twentieth year even unto the two and thirtieth year of Artaxerxes the king, that is, twelve years, I and my brethren have not eaten the bread of the governor. [^14] But the former governors that had been before me were chargeable unto the people, and had taken of them bread and wine, beside forty shekels of silver; yea, even their servants bare rule over the people: but so did not I, because of the fear of God. [^15] Yea, also I continued in the work of this wall, neither bought we any land: and all my servants were gathered thither unto the work. [^16] Moreover there were at my table an hundred and fifty of the Jews and rulers, beside those that came unto us from among the heathen that are about us. [^17] Now that which was prepared for me daily was one ox and six choice sheep; also fowls were prepared for me, and once in ten days store of all sorts of wine: yet for all this required not I the bread of the governor, because the bondage was heavy upon this people. [^18] Think upon me, my God, for good, according to all that I have done for this people. [^19] 

[[Nehemiah - 4|<--]] Nehemiah - 5 [[Nehemiah - 6|-->]]

---
# Notes
