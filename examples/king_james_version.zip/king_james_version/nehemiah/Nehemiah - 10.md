---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/nehemiah"
  - "#bible/testament/old"
aliases:
  - "Nehemiah - 10 - King James Version"
---
[[Nehemiah - 9|<--]] Nehemiah - 10 [[Nehemiah - 11|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Nehemiah]]

# Nehemiah - 10

Now those that sealed were, Nehemiah, the Tirshatha, the son of Hachaliah, and Zidkijah, [^1] Seraiah, Azariah, Jeremiah, [^2] Pashur, Amariah, Malchijah, [^3] Hattush, Shebaniah, Malluch, [^4] Harim, Meremoth, Obadiah, [^5] Daniel, Ginnethon, Baruch, [^6] Meshullam, Abijah, Mijamin, [^7] Maaziah, Bilgai, Shemaiah: these were the priests. [^8] And the Levites: both Jeshua the son of Azaniah, Binnui of the sons of Henadad, Kadmiel; [^9] and their brethren, Shebaniah, Hodijah, Kelita, Pelaiah, Hanan, [^10] Micha, Rehob, Hashabiah, [^11] Zaccur, Sherebiah, Shebaniah, [^12] Hodijah, Bani, Beninu. [^13] The chief of the people; Parosh, Pahath-moab, Elam, Zatthu, Bani, [^14] Bunni, Azgad, Bebai, [^15] Adonijah, Bigvai, Adin, [^16] Ater, Hizkijah, Azzur, [^17] Hodijah, Hashum, Bezai, [^18] Hariph, Anathoth, Nebai, [^19] Magpiash, Meshullam, Hezir, [^20] Meshezabeel, Zadok, Jaddua, [^21] Pelatiah, Hanan, Anaiah, [^22] Hoshea, Hananiah, Hashub, [^23] Hallohesh, Pileha, Shobek, [^24] Rehum, Hashabnah, Maaseiah, [^25] and Ahijah, Hanan, Anan, [^26] Malluch, Harim, Baanah. [^27] And the rest of the people, the priests, the Levites, the porters, the singers, the Nethinims, and all they that had separated themselves from the people of the lands unto the law of God, their wives, their sons, and their daughters, every one having knowledge, and having understanding; [^28] they clave to their brethren, their nobles, and entered into a curse, and into an oath, to walk in God's law, which was given by Moses the servant of God, and to observe and do all the commandments of the LORD our Lord, and his judgments and his statutes; [^29] and that we would not give our daughters unto the people of the land, nor take their daughters for our sons: [^30] and if the people of the land bring ware or any victuals on the sabbath day to sell, that we would not buy it of them on the sabbath, or on the holy day: and that we would leave the seventh year, and the exaction of every debt. [^31] Also we made ordinances for us, to charge ourselves yearly with the third part of a shekel for the service of the house of our God; [^32] for the shewbread, and for the continual meat offering, and for the continual burnt offering, of the sabbaths, of the new moons, for the set feasts, and for the holy things, and for the sin offerings to make an atonement for Israel, and for all the work of the house of our God. [^33] And we cast the lots among the priests, the Levites, and the people, for the wood offering, to bring it into the house of our God, after the houses of our fathers, at times appointed year by year, to burn upon the altar of the LORD our God, as it is written in the law: [^34] and to bring the firstfruits of our ground, and the firstfruits of all fruit of all trees, year by year, unto the house of the LORD: [^35] also the firstborn of our sons, and of our cattle, as it is written in the law, and the firstlings of our herds and of our flocks, to bring to the house of our God, unto the priests that minister in the house of our God: [^36] and that we should bring the firstfruits of our dough, and our offerings, and the fruit of all manner of trees, of wine and of oil, unto the priests, to the chambers of the house of our God; and the tithes of our ground unto the Levites, that the same Levites might have the tithes in all the cities of our tillage. [^37] And the priest the son of Aaron shall be with the Levites, when the Levites take tithes: and the Levites shall bring up the tithe of the tithes unto the house of our God, to the chambers, into the treasure house. [^38] For the children of Israel and the children of Levi shall bring the offering of the corn, of the new wine, and the oil, unto the chambers, where are the vessels of the sanctuary, and the priests that minister, and the porters, and the singers: and we will not forsake the house of our God. [^39] 

[[Nehemiah - 9|<--]] Nehemiah - 10 [[Nehemiah - 11|-->]]

---
# Notes
