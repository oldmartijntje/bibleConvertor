---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 38 - King James Version"
---
[[Job - 37|<--]] Job - 38 [[Job - 39|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 38

Then the LORD answered Job out of the whirlwind, and said, [^1] Who is this that darkeneth counselBy words without knowledge? [^2] Gird up now thy loins like a man;For I will demand of thee, and answer thou me. [^3] Where wast thou when I laid the foundations of the earth?Declare, if thou hast understanding. [^4] Who hath laid the measures thereof, if thou knowest?Or who hath stretched the line upon it? [^5] Whereupon are the foundations thereof fastened?Or who laid the corner stone thereof; [^6] When the morning stars sang together,And all the sons of God shouted for joy? [^7] Or who shut up the sea with doors,When it brake forth, as if it had issued out of the womb? [^8] When I made the cloud the garment thereof,And thick darkness a swaddlingband for it, [^9] And brake up for it my decreed place,And set bars and doors, [^10] And said, Hitherto shalt thou come, but no further:And here shall thy proud waves be stayed? [^11] Hast thou commanded the morning since thy days;And caused the dayspring to know his place; [^12] That it might take hold of the ends of the earth,That the wicked might be shaken out of it? [^13] It is turned as clay to the seal;And they stand as a garment. [^14] And from the wicked their light is withholden,And the high arm shall be broken. [^15] Hast thou entered into the springs of the sea?Or hast thou walked in the search of the depth? [^16] Have the gates of death been opened unto thee?Or hast thou seen the doors of the shadow of death? [^17] Hast thou perceived the breadth of the earth?Declare if thou knowest it all. [^18] Where is the way where light dwelleth?And as for darkness, where is the place thereof, [^19] That thou shouldest take it to the bound thereof,And that thou shouldest know the paths to the house thereof? [^20] Knowest thou it, because thou wast then born?Or because the number of thy days is great? [^21] Hast thou entered into the treasures of the snow?Or hast thou seen the treasures of the hail, [^22] Which I have reserved against the time of trouble,Against the day of battle and war? [^23] By what way is the light parted,Which scattereth the east wind upon the earth? [^24] Who hath divided a watercourse for the overflowing of waters,Or a way for the lightning of thunder; [^25] To cause it to rain on the earth, where no man is;On the wilderness, wherein there is no man; [^26] To satisfy the desolate and waste ground;And to cause the bud of the tender herb to spring forth? [^27] Hath the rain a father?Or who hath begotten the drops of dew? [^28] Out of whose womb came the ice?And the hoary frost of heaven, who hath gendered it? [^29] The waters are hid as with a stone,And the face of the deep is frozen. [^30] Canst thou bind the sweet influences of Pleiades,Or loose the bands of Orion? [^31] Canst thou bring forth Mazzaroth in his season?Or canst thou guide Arcturus with his sons? [^32] Knowest thou the ordinances of heaven?Canst thou set the dominion thereof in the earth? [^33] Canst thou lift up thy voice to the clouds,That abundance of waters may cover thee? [^34] Canst thou send lightnings, that they may go,And say unto thee, Here we are? [^35] Who hath put wisdom in the inward parts?Or who hath given understanding to the heart? [^36] Who can number the clouds in wisdom?Or who can stay the bottles of heaven, [^37] When the dust groweth into hardness,And the clods cleave fast together? [^38] Wilt thou hunt the prey for the lion?Or fill the appetite of the young lions, [^39] When they couch in their dens,And abide in the covert to lie in wait? [^40] Who provideth for the raven his food?When his young ones cry unto God,They wander for lack of meat. [^41] 

[[Job - 37|<--]] Job - 38 [[Job - 39|-->]]

---
# Notes
