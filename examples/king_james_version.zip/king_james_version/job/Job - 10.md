---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 10 - King James Version"
---
[[Job - 9|<--]] Job - 10 [[Job - 11|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 10

My soul is weary of my life;I will leave my complaint upon myself;I will speak in the bitterness of my soul. [^1] I will say unto God, Do not condemn me;Shew me wherefore thou contendest with me. [^2] Is it good unto thee that thou shouldest oppress,That thou shouldest despise the work of thine hands,And shine upon the counsel of the wicked? [^3] Hast thou eyes of flesh?Or seest thou as man seeth? [^4] Are thy days as the days of man?Are thy years as man's days, [^5] That thou enquirest after mine iniquity,And searchest after my sin? [^6] Thou knowest that I am not wicked;And there is none that can deliver out of thine hand. [^7] Thine hands have made me and fashioned meTogether round about; yet thou dost destroy me. [^8] Remember, I beseech thee, that thou hast made me as the clay;And wilt thou bring me into dust again? [^9] Hast thou not poured me out as milk,And curdled me like cheese? [^10] Thou hast clothed me with skin and flesh,And hast fenced me with bones and sinews. [^11] Thou hast granted me life and favour,And thy visitation hath preserved my spirit. [^12] And these things hast thou hid in thine heart:I know that this is with thee. [^13] If I sin, then thou markest me,And thou wilt not acquit me from mine iniquity. [^14] If I be wicked, woe unto me;And if I be righteous, yet will I not lift up my head.I am full of confusion;Therefore see thou mine affliction; [^15] For it increaseth. Thou huntest me as a fierce lion:And again thou shewest thyself marvellous upon me. [^16] Thou renewest thy witnesses against me,And increasest thine indignation upon me;Changes and war are against me. [^17] Wherefore then hast thou brought me forth out of the womb?Oh that I had given up the ghost, and no eye had seen me! [^18] I should have been as though I had not been;I should have been carried from the womb to the grave. [^19] Are not my days few? Cease then,And let me alone, that I may take comfort a little, [^20] Before I go whence I shall not return,Even to the land of darkness and the shadow of death; [^21] A land of darkness, as darkness itself;And of the shadow of death, without any order,And where the light is as darkness. [^22] 

[[Job - 9|<--]] Job - 10 [[Job - 11|-->]]

---
# Notes
