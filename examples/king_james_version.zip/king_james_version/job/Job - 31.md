---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 31 - King James Version"
---
[[Job - 30|<--]] Job - 31 [[Job - 32|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 31

I made a covenant with mine eyes;Why then should I think upon a maid? [^1] For what portion of God is there from above?And what inheritance of the Almighty from on high? [^2] Is not destruction to the wicked?And a strange punishment to the workers of iniquity? [^3] Doth not he see my ways,And count all my steps? [^4] If I have walked with vanity,Or if my foot hath hasted to deceit; [^5] Let me be weighed in an even balance,That God may know mine integrity. [^6] If my step hath turned out of the way,And mine heart walked after mine eyes,And if any blot hath cleaved to mine hands; [^7] Then let me sow, and let another eat;Yea, let my offspring be rooted out. [^8] If mine heart have been deceived by a woman,Or if I have laid wait at my neighbour's door; [^9] Then let my wife grind unto another,And let others bow down upon her. [^10] For this is an heinous crime;Yea, it is an iniquity to be punished by the judges. [^11] For it is a fire that consumeth to destruction,And would root out all mine increase. [^12] If I did despise the cause of my manservant or of my maidservant,When they contended with me; [^13] What then shall I do when God riseth up?And when he visiteth, what shall I answer him? [^14] Did not he that made me in the womb make him?And did not one fashion us in the womb? [^15] If I have withheld the poor from their desire,Or have caused the eyes of the widow to fail; [^16] Or have eaten my morsel myself alone,And the fatherless hath not eaten thereof; [^17] (For from my youth he was brought up with me, as with a father,And I have guided her from my mother's womb;) [^18] If I have seen any perish for want of clothing,Or any poor without covering; [^19] If his loins have not blessed me,And if he were not warmed with the fleece of my sheep; [^20] If I have lifted up my hand against the fatherless,When I saw my help in the gate: [^21] Then let mine arm fall from my shoulder blade,And mine arm be broken from the bone. [^22] For destruction from God was a terror to me,And by reason of his highness I could not endure. [^23] If I have made gold my hope,Or have said to the fine gold, Thou art my confidence; [^24] If I rejoiced because my wealth was great,And because mine hand had gotten much; [^25] If I beheld the sun when it shined,Or the moon walking in brightness; [^26] And my heart hath been secretly enticed,Or my mouth hath kissed my hand: [^27] This also were an iniquity to be punished by the judge:For I should have denied the God that is above. [^28] If I rejoiced at the destruction of him that hated me,Or lifted up myself when evil found him: [^29] Neither have I suffered my mouth to sinBy wishing a curse to his soul. [^30] If the men of my tabernacle said not,Oh that we had of his flesh! we cannot be satisfied. [^31] The stranger did not lodge in the street:But I opened my doors to the traveller. [^32] If I covered my transgressions as Adam,By hiding mine iniquity in my bosom: [^33] Did I fear a great multitude,Or did the contempt of families terrify me,That I kept silence, and went not out of the door? [^34] Oh that one would hear me!Behold, my desire is, that the Almighty would answer me,And that mine adversary had written a book. [^35] Surely I would take it upon my shoulder,And bind it as a crown to me. [^36] I would declare unto him the number of my steps;As a prince would I go near unto him. [^37] If my land cry against me,Or that the furrows likewise thereof complain; [^38] If I have eaten the fruits thereof without money,Or have caused the owners thereof to lose their life: [^39] Let thistles grow instead of wheat,And cockle instead of barley.The words of Job are ended. [^40] 

[[Job - 30|<--]] Job - 31 [[Job - 32|-->]]

---
# Notes
