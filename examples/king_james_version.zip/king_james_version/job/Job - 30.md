---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 30 - King James Version"
---
[[Job - 29|<--]] Job - 30 [[Job - 31|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 30

But now they that are younger than I have me in derision,Whose fathers I would have disdained to have set with the dogs of my flock. [^1] Yea, whereto might the strength of their hands profit me,In whom old age was perished? [^2] For want and famine they were solitary;Fleeing into the wilderness in former time desolate and waste. [^3] Who cut up mallows by the bushes,And juniper roots for their meat. [^4] They were driven forth from among men,(They cried after them as after a thief;) [^5] To dwell in the cliffs of the valleys,in caves of the earth, and in the rocks. [^6] Among the bushes they brayed;Under the nettles they were gathered together. [^7] They were children of fools, yea, children of base men:They were viler than the earth. [^8] And now am I their song,Yea, I am their byword. [^9] They abhor me, they flee far from me,And spare not to spit in my face. [^10] Because he hath loosed my cord, and afflicted me,They have also let loose the bridle before me. [^11] Upon my right hand rise the youth;They push away my feet,And they raise up against me the ways of their destruction. [^12] They mar my path,They set forward my calamity,They have no helper. [^13] They came upon me as a wide breaking in of waters:In the desolation they rolled themselves upon me. [^14] Terrors are turned upon me:They pursue my soul as the wind:And my welfare passeth away as a cloud. [^15] And now my soul is poured out upon me;The days of affliction have taken hold upon me. [^16] My bones are pierced in me in the night season:And my sinews take no rest. [^17] By the great force of my disease is my garment changed:It bindeth me about as the collar of my coat. [^18] He hath cast me into the mire,And I am become like dust and ashes. [^19] I cry unto thee, and thou dost not hear me:I stand up, and thou regardest me not. [^20] Thou art become cruel to me:With thy strong hand thou opposest thyself against me. [^21] Thou liftest me up to the wind; thou causest me to ride upon it,And dissolvest my substance. [^22] For I know that thou wilt bring me to death,And to the house appointed for all living. [^23] Howbeit he will not stretch out his hand to the grave,Though they cry in his destruction. [^24] Did not I weep for him that was in trouble?Was not my soul grieved for the poor? [^25] When I looked for good, then evil came unto me:And when I waited for light, there came darkness. [^26] My bowels boiled, and rested not:The days of affliction prevented me. [^27] I went mourning without the sun:I stood up, and I cried in the congregation. [^28] I am a brother to dragons,And a companion to owls. [^29] My skin is black upon me,And my bones are burned with heat. [^30] My harp also is turned to mourning,And my organ into the voice of them that weep. [^31] 

[[Job - 29|<--]] Job - 30 [[Job - 31|-->]]

---
# Notes
