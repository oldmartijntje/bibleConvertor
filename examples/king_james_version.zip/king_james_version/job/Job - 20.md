---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 20 - King James Version"
---
[[Job - 19|<--]] Job - 20 [[Job - 21|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 20

Then answered Zophar the Naamathite, and said, [^1] Therefore do my thoughts cause me to answer,And for this I make haste. [^2] I have heard the check of my reproach,And the spirit of my understanding causeth me to answer. [^3] Knowest thou not this of old,Since man was placed upon earth, [^4] That the triumphing of the wicked is short,And the joy of the hypocrite but for a moment? [^5] Though his excellency mount up to the heavens,And his head reach unto the clouds; [^6] Yet he shall perish for ever like his own dung:They which have seen him shall say, Where is he? [^7] He shall fly away as a dream, and shall not be found:Yea, he shall be chased away as a vision of the night. [^8] The eye also which saw him shall see him no more;Neither shall his place any more behold him. [^9] His children shall seek to please the poor,And his hands shall restore their goods. [^10] His bones are full of the sin of his youth,Which shall lie down with him in the dust. [^11] Though wickedness be sweet in his mouth,Though he hide it under his tongue; [^12] Though he spare it, and forsake it not;But keep it still within his mouth: [^13] Yet his meat in his bowels is turned,It is the gall of asps within him. [^14] He hath swallowed down riches, and he shall vomit them up again:God shall cast them out of his belly. [^15] He shall suck the poison of asps:The viper's tongue shall slay him. [^16] He shall not see the rivers,The floods, the brooks of honey and butter. [^17] That which he laboured for shall he restore,And shall not swallow it down:According to his substance shall the restitution be,and he shall not rejoice therein. [^18] Because he hath oppressed and hath forsaken the poor;Because he hath violently taken away an house which he builded not; [^19] Surely he shall not feel quietness in his belly,He shall not save of that which he desired. [^20] There shall none of his meat be left;Therefore shall no man look for his goods. [^21] In the fulness of his sufficiency he shall be in straits:Every hand of the wicked shall come upon him. [^22] When he is about to fill his belly,God shall cast the fury of his wrath upon him,And shall rain it upon him while he is eating. [^23] He shall flee from the iron weapon,And the bow of steel shall strike him through. [^24] It is drawn, and cometh out of the body;Yea, the glittering sword cometh out of his gall:Terrors are upon him. [^25] All darkness shall be hid in his secret places:A fire not blown shall consume him;It shall go ill with him that is left in his tabernacle. [^26] The heaven shall reveal his iniquity;And the earth shall rise up against him. [^27] The increase of his house shall depart,And his goods shall flow away in the day of his wrath. [^28] This is the portion of a wicked man from God,And the heritage appointed unto him by God. [^29] 

[[Job - 19|<--]] Job - 20 [[Job - 21|-->]]

---
# Notes
