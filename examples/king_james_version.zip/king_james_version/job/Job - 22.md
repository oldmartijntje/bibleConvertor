---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 22 - King James Version"
---
[[Job - 21|<--]] Job - 22 [[Job - 23|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 22

Then Eliphaz the Temanite answered and said, [^1] Can a man be profitable unto God,As he that is wise may be profitable unto himself? [^2] Is it any pleasure to the Almighty, that thou art righteous?Or is it gain to him, that thou makest thy ways perfect? [^3] Will he reprove thee for fear of thee?Will he enter with thee into judgment? [^4] Is not thy wickedness great?And thine iniquities infinite? [^5] For thou hast taken a pledge from thy brother for nought,And stripped the naked of their clothing. [^6] Thou hast not given water to the weary to drink,And thou hast withholden bread from the hungry. [^7] But as for the mighty man, he had the earth;And the honourable man dwelt in it. [^8] Thou hast sent widows away empty,And the arms of the fatherless have been broken. [^9] Therefore snares are round about thee,And sudden fear troubleth thee; [^10] Or darkness, that thou canst not see;And abundance of waters cover thee. [^11] Is not God in the height of heaven?And behold the height of the stars, how high they are! [^12] And thou sayest, How doth God know?Can he judge through the dark cloud? [^13] Thick clouds are a covering to him, that he seeth not;And he walketh in the circuit of heaven. [^14] Hast thou marked the old wayWhich wicked men have trodden? [^15] Which were cut down out of time,Whose foundation was overflown with a flood: [^16] Which said unto God, Depart from us:And what can the Almighty do for them? [^17] Yet he filled their houses with good things:But the counsel of the wicked is far from me. [^18] The righteous see it, and are glad:And the innocent laugh them to scorn. [^19] Whereas our substance is not cut down,But the remnant of them the fire consumeth. [^20] Acquaint now thyself with him, and be at peace:Thereby good shall come unto thee. [^21] Receive, I pray thee, the law from his mouth,And lay up his words in thine heart. [^22] If thou return to the Almighty, thou shalt be built up,Thou shalt put away iniquity far from thy tabernacles. [^23] Then shalt thou lay up gold as dust,And the gold of Ophir as the stones of the brooks. [^24] Yea, the Almighty shall be thy defence,And thou shalt have plenty of silver. [^25] For then shalt thou have thy delight in the Almighty,And shalt lift up thy face unto God. [^26] Thou shalt make thy prayer unto him, and he shall hear thee,And thou shalt pay thy vows. [^27] Thou shalt also decree a thing, and it shall be established unto thee:And the light shall shine upon thy ways. [^28] When men are cast down, then thou shalt say, there is lifting up;And he shall save the humble person. [^29] He shall deliver the island of the innocent:And it is delivered by the pureness of thine hands. [^30] 

[[Job - 21|<--]] Job - 22 [[Job - 23|-->]]

---
# Notes
