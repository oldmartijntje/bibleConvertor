---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 34 - King James Version"
---
[[Job - 33|<--]] Job - 34 [[Job - 35|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 34

Furthermore Elihu answered and said, [^1] Hear my words, O ye wise men;And give ear unto me, ye that have knowledge. [^2] For the ear trieth words,As the mouth tasteth meat. [^3] Let us choose to us judgment:Let us know among ourselves what is good. [^4] For Job hath said, I am righteous:And God hath taken away my judgment. [^5] Should I lie against my right?My wound is incurable without transgression. [^6] What man is like Job,Who drinketh up scorning like water? [^7] Which goeth in company with the workers of iniquity,And walketh with wicked men. [^8] For he hath said, It profiteth a man nothingThat he should delight himself with God. [^9] Therefore hearken unto me, ye men of understanding:Far be it from God, that he should do wickedness;And from the Almighty, that he should commit iniquity. [^10] For the work of a man shall he render unto him,And cause every man to find according to his ways. [^11] Yea, surely God will not do wickedly,Neither will the Almighty pervert judgment. [^12] Who hath given him a charge over the earth?Or who hath disposed the whole world? [^13] If he set his heart upon man,If he gather unto himself his spirit and his breath; [^14] All flesh shall perish together,And man shall turn again unto dust. [^15] If now thou hast understanding, hear this:Hearken to the voice of my words. [^16] Shall even he that hateth right govern?And wilt thou condemn him that is most just? [^17] Is it fit to say to a king, Thou art wicked?and to princes, Ye are ungodly? [^18] How much less to him that accepteth not the persons of princes,Nor regardeth the rich more than the poor?For they all are the work of his hands. [^19] In a moment shall they die,And the people shall be troubled at midnight, and pass away:And the mighty shall be taken away without hand. [^20] For his eyes are upon the ways of man,And he seeth all his goings. [^21] There is no darkness, nor shadow of death,Where the workers of iniquity may hide themselves. [^22] For he will not lay upon man more than right;That he should enter into judgment with God. [^23] He shall break in pieces mighty men without number,And set others in their stead. [^24] Therefore he knoweth their works,And he overturneth them in the night, so that they are destroyed. [^25] He striketh them as wicked menIn the open sight of others; [^26] Because they turned back from him,And would not consider any of his ways: [^27] So that they cause the cry of the poor to come unto him,And he heareth the cry of the afflicted. [^28] When he giveth quietness, who then can make trouble?And when he hideth his face, who then can behold him?Whether it be done against a nation, or against a man only: [^29] That the hypocrite reign not,Lest the people be ensnared. [^30] Surely it is meet to be said unto God,I have borne chastisement, I will not offend any more: [^31] That which I see not teach thou me:If I have done iniquity, I will do no more. [^32] Should it be according to thy mind?He will recompense it, whether thou refuse,Or whether thou choose; and not I:Therefore speak what thou knowest. [^33] Let men of understanding tell me,And let a wise man hearken unto me. [^34] Job hath spoken without knowledge,And his words were without wisdom. [^35] My desire is that Job may be tried unto the endBecause of his answers for wicked men. [^36] For he addeth rebellion unto his sin,He clappeth his hands among us,And multiplieth his words against God. [^37] 

[[Job - 33|<--]] Job - 34 [[Job - 35|-->]]

---
# Notes
