---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 19 - King James Version"
---
[[Job - 18|<--]] Job - 19 [[Job - 20|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 19

Then Job answered and said, [^1] How long will ye vex my soul,And break me in pieces with words? [^2] These ten times have ye reproached me:Ye are not ashamed that ye make yourselves strange to me. [^3] And be it indeed that I have erred,Mine error remaineth with myself. [^4] If indeed ye will magnify yourselves against me,And plead against me my reproach: [^5] Know now that God hath overthrown me,And hath compassed me with his net. [^6] Behold, I cry out of wrong, but I am not heard:I cry aloud, but there is no judgment. [^7] He hath fenced up my way that I cannot pass,And he hath set darkness in my paths. [^8] He hath stripped me of my glory,And taken the crown from my head. [^9] He hath destroyed me on every side, and I am gone:And mine hope hath he removed like a tree. [^10] He hath also kindled his wrath against me,And he counteth me unto him as one of his enemies. [^11] His troops come together,And raise up their way against me,And encamp round about my tabernacle. [^12] He hath put my brethren far from me,And mine acquaintance are verily estranged from me. [^13] My kinsfolk have failed, and my familiar friends have forgotten me. [^14] They that dwell in mine house,And my maids, count me for a stranger:I am an alien in their sight. [^15] I called my servant, and he gave me no answer;I intreated him with my mouth. [^16] My breath is strange to my wife,Though I intreated for the children's sake of mine own body. [^17] Yea, young children despised me;I arose, and they spake against me. [^18] All my inward friends abhorred me:And they whom I loved are turned against me. [^19] My bone cleaveth to my skin and to my flesh,And I am escaped with the skin of my teeth. [^20] Have pity upon me, have pity upon me, O ye my friends;For the hand of God hath touched me. [^21] Why do ye persecute me as God,And are not satisfied with my flesh? [^22] Oh that my words were now written!Oh that they were printed in a book! [^23] That they were graven with an iron pen and leadIn the rock for ever! [^24] For I know that my redeemer liveth,And that he shall stand at the latter day upon the earth: [^25] And though after my skin worms destroy this body,Yet in my flesh shall I see God: [^26] Whom I shall see for myself,And mine eyes shall behold, and not another;Though my reins be consumed within me. [^27] But ye should say, Why persecute we him,Seeing the root of the matter is found in me? [^28] Be ye afraid of the sword:For wrath bringeth the punishments of the sword,That ye may know there is a judgment. [^29] 

[[Job - 18|<--]] Job - 19 [[Job - 20|-->]]

---
# Notes
