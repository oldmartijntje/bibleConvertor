---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 16 - King James Version"
---
[[Job - 15|<--]] Job - 16 [[Job - 17|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 16

Then Job answered and said, [^1] I have heard many such things:Miserable comforters are ye all. [^2] Shall vain words have an end?Or what emboldeneth thee that thou answerest? [^3] I also could speak as ye do:If your soul were in my soul's stead,I could heap up words against you,And shake mine head at you. [^4] But I would strengthen you with my mouth,And the moving of my lips should asswage your grief. [^5] Though I speak, my grief is not asswaged:And though I forbear, what am I eased? [^6] But now he hath made me weary:Thou hast made desolate all my company. [^7] And thou hast filled me with wrinkles, which is a witness against me:And my leanness rising up in me beareth witness to my face. [^8] He teareth me in his wrath, who hateth me:He gnasheth upon me with his teeth;Mine enemy sharpeneth his eyes upon me. [^9] They have gaped upon me with their mouth;They have smitten me upon the cheek reproachfully;They have gathered themselves together against me. [^10] God hath delivered me to the ungodly,And turned me over into the hands of the wicked. [^11] I was at ease, but he hath broken me asunder:He hath also taken me by my neck, and shaken me to pieces,And set me up for his mark. [^12] His archers compass me round about,He cleaveth my reins asunder, and doth not spare;He poureth out my gall upon the ground. [^13] He breaketh me with breach upon breach,He runneth upon me like a giant. [^14] I have sewed sackcloth upon my skin,And defiled my horn in the dust. [^15] My face is foul with weeping,And on my eyelids is the shadow of death; [^16] Not for any injustice in mine hands:Also my prayer is pure. [^17] O earth, cover not thou my blood,And let my cry have no place. [^18] Also now, behold, my witness is in heaven,And my record is on high. [^19] My friends scorn me:but mine eye poureth out tears unto God. [^20] O that one might plead for a man with God,As a man pleadeth for his neighbour! [^21] When a few years are come,Then I shall go the way whence I shall not return. [^22] 

[[Job - 15|<--]] Job - 16 [[Job - 17|-->]]

---
# Notes
