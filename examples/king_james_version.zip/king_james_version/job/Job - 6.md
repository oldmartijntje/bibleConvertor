---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 6 - King James Version"
---
[[Job - 5|<--]] Job - 6 [[Job - 7|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 6

But Job answered and said, [^1] Oh that my grief were throughly weighed,And my calamity laid in the balances together! [^2] For now it would be heavier than the sand of the sea:Therefore my words are swallowed up. [^3] For the arrows of the Almighty are within me,The poison whereof drinketh up my spirit:The terrors of God do set themselves in array against me. [^4] Doth the wild ass bray when he hath grass?Or loweth the ox over his fodder? [^5] Can that which is unsavoury be eaten without salt?Or is there any taste in the white of an egg? [^6] The things that my soul refused to touchAre as my sorrowful meat. [^7] Oh that I might have my request;And that God would grant me the thing that I long for! [^8] Even that it would please God to destroy me;That he would let loose his hand, and cut me off! [^9] Then should I yet have comfort;Yea, I would harden myself in sorrow: let him not spare;For I have not concealed the words of the Holy One. [^10] What is my strength, that I should hope?And what is mine end, that I should prolong my life? [^11] Is my strength the strength of stones?Or is my flesh of brass? [^12] Is not my help in me?And is wisdom driven quite from me? [^13] To him that is afflicted pity should be shewed from his friend;But he forsaketh the fear of the Almighty. [^14] My brethren have dealt deceitfully as a brook,And as the stream of brooks they pass away; [^15] Which are blackish by reason of the ice,And wherein the snow is hid: [^16] What time they wax warm, they vanish:When it is hot, they are consumed out of their place. [^17] The paths of their way are turned aside;They go to nothing, and perish. [^18] The troops of Tema looked,The companies of Sheba waited for them. [^19] They were confounded because they had hoped;They came thither, and were ashamed. [^20] For now ye are nothing;Ye see my casting down, and are afraid. [^21] Did I say, Bring unto me?Or, Give a reward for me of your substance? [^22] Or, Deliver me from the enemy's hand?Or, Redeem me from the hand of the mighty? [^23] Teach me, and I will hold my tongue:And cause me to understand wherein I have erred. [^24] How forcible are right words!But what doth your arguing reprove? [^25] Do ye imagine to reprove words,And the speeches of one that is desperate, which are as wind? [^26] Yea, ye overwhelm the fatherless,And ye dig a pit for your friend. [^27] Now therefore be content, look upon me;For it is evident unto you if I lie. [^28] Return, I pray you, let it not be iniquity;Yea, return again, my righteousness is in it. [^29] Is there iniquity in my tongue?Cannot my taste discern perverse things? [^30] 

[[Job - 5|<--]] Job - 6 [[Job - 7|-->]]

---
# Notes
