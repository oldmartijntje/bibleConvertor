---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 29 - King James Version"
---
[[Job - 28|<--]] Job - 29 [[Job - 30|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 29

Moreover Job continued his parable, and said, [^1] Oh that I were as in months past,As in the days when God preserved me; [^2] When his candle shined upon my head,And when by his light I walked through darkness; [^3] As I was in the days of my youth,When the secret of God was upon my tabernacle; [^4] When the Almighty was yet with me,When my children were about me; [^5] When I washed my steps with butter,And the rock poured me out rivers of oil; [^6] When I went out to the gate through the city,When I prepared my seat in the street! [^7] The young men saw me, and hid themselves:And the aged arose, and stood up. [^8] The princes refrained talking,And laid their hand on their mouth. [^9] The nobles held their peace,And their tongue cleaved to the roof of their mouth. [^10] When the ear heard me, then it blessed me;And when the eye saw me, it gave witness to me: [^11] Because I delivered the poor that cried,And the fatherless, and him that had none to help him. [^12] The blessing of him that was ready to perish came upon me:And I caused the widow's heart to sing for joy. [^13] I put on righteousness, and it clothed me:My judgment was as a robe and a diadem. [^14] I was eyes to the blind,And feet was I to the lame. [^15] I was a father to the poor:And the cause which I knew not I searched out. [^16] And I brake the jaws of the wicked,And plucked the spoil out of his teeth. [^17] Then I said, I shall die in my nest,And I shall multiply my days as the sand. [^18] My root was spread out by the waters,And the dew lay all night upon my branch. [^19] My glory was fresh in me,And my bow was renewed in my hand. [^20] Unto me men gave ear, and waited,And kept silence at my counsel. [^21] After my words they spake not again;And my speech dropped upon them. [^22] And they waited for me as for the rain;And they opened their mouth wide as for the latter rain. [^23] If I laughed on them, they believed it not;And the light of my countenance they cast not down. [^24] I chose out their way, and sat chief,And dwelt as a king in the army,As one that comforteth the mourners. [^25] 

[[Job - 28|<--]] Job - 29 [[Job - 30|-->]]

---
# Notes
