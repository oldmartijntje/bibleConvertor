---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 17 - King James Version"
---
[[Job - 16|<--]] Job - 17 [[Job - 18|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 17

My breath is corrupt, my days are extinct,The graves are ready for me. [^1] Are there not mockers with me?And doth not mine eye continue in their provocation? [^2] Lay down now, put me in a surety with thee;Who is he that will strike hands with me? [^3] For thou hast hid their heart from understanding:Therefore shalt thou not exalt them. [^4] He that speaketh flattery to his friends,Even the eyes of his children shall fail. [^5] He hath made me also a byword of the people;And aforetime I was as a tabret. [^6] Mine eye also is dim by reason of sorrow,And all my members are as a shadow. [^7] Upright men shall be astonied at this,And the innocent shall stir up himself against the hypocrite. [^8] The righteous also shall hold on his way,And he that hath clean hands shall be stronger and stronger. [^9] But as for you all, do ye return, and come now:For I cannot find one wise man among you. [^10] My days are past, my purposes are broken off,Even the thoughts of my heart. [^11] They change the night into day:The light is short because of darkness. [^12] If I wait, the grave is mine house:I have made my bed in the darkness. [^13] I have said to corruption, Thou art my father:To the worm, Thou art my mother, and my sister. [^14] And where is now my hope?As for my hope, who shall see it? [^15] They shall go down to the bars of the pit,When our rest together is in the dust. [^16] 

[[Job - 16|<--]] Job - 17 [[Job - 18|-->]]

---
# Notes
