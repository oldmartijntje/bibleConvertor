---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 35 - King James Version"
---
[[Job - 34|<--]] Job - 35 [[Job - 36|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 35

Elihu spake moreover, and said, [^1] Thinkest thou this to be right,That thou saidst, My righteousness is more than God's? [^2] For thou saidst, What advantage will it be unto thee?And, What profit shall I have, if I be cleansed from my sin? [^3] I will answer thee,And thy companions with thee. [^4] Look unto the heavens, and see;And behold the clouds which are higher than thou. [^5] If thou sinnest, what doest thou against him?Or if thy transgressions be multiplied, what doest thou unto him? [^6] If thou be righteous, what givest thou him?Or what receiveth he of thine hand? [^7] Thy wickedness may hurt a man as thou art;And thy righteousness may profit the son of man. [^8] By reason of the multitude of oppressions they make the oppressed to cry:They cry out by reason of the arm of the mighty. [^9] But none saith, Where is God my maker,Who giveth songs in the night; [^10] Who teacheth us more than the beasts of the earth,And maketh us wiser than the fowls of heaven? [^11] There they cry, but none giveth answer,Because of the pride of evil men. [^12] Surely God will not hear vanity,Neither will the Almighty regard it. [^13] Although thou sayest thou shalt not see him,Yet judgment is before him; therefore trust thou in him. [^14] But now, because it is not so, he hath visited in his anger;Yet he knoweth it not in great extremity: [^15] Therefore doth Job open his mouth in vain;He multiplieth words without knowledge. [^16] 

[[Job - 34|<--]] Job - 35 [[Job - 36|-->]]

---
# Notes
