---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 39 - King James Version"
---
[[Job - 38|<--]] Job - 39 [[Job - 40|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 39

Knowest thou the time when the wild goats of the rock bring forth?Or canst thou mark when the hinds do calve? [^1] Canst thou number the months that they fulfil?Or knowest thou the time when they bring forth? [^2] They bow themselves, they bring forth their young ones,They cast out their sorrows. [^3] Their young ones are in good liking, they grow up with corn;They go forth, and return not unto them. [^4] Who hath sent out the wild ass free?Or who hath loosed the bands of the wild ass? [^5] Whose house I have made the wilderness,And the barren land his dwellings. [^6] He scorneth the multitude of the city,Neither regardeth he the crying of the driver. [^7] The range of the mountains is his pasture,And he searcheth after every green thing. [^8] Will the unicorn be willing to serve thee,Or abide by thy crib? [^9] Canst thou bind the unicorn with his band in the furrow?Or will he harrow the valleys after thee? [^10] Wilt thou trust him, because his strength is great?Or wilt thou leave thy labour to him? [^11] Wilt thou believe him, that he will bring home thy seed,And gather it into thy barn? [^12] Gavest thou the goodly wings unto the peacocks?Or wings and feathers unto the ostrich? [^13] Which leaveth her eggs in the earth,And warmeth them in dust, [^14] And forgetteth that the foot may crush them,Or that the wild beast may break them. [^15] She is hardened against her young ones, as though they were not her's:Her labour is in vain without fear; [^16] Because God hath deprived her of wisdom,Neither hath he imparted to her understanding. [^17] What time she lifteth up herself on high,She scorneth the horse and his rider. [^18] Hast thou given the horse strength?Hast thou clothed his neck with thunder? [^19] Canst thou make him afraid as a grasshopper?The glory of his nostrils is terrible. [^20] He paweth in the valley, and rejoiceth in his strength:He goeth on to meet the armed men. [^21] He mocketh at fear, and is not affrighted;Neither turneth he back from the sword. [^22] The quiver rattleth against him,The glittering spear and the shield. [^23] He swalloweth the ground with fierceness and rage:Neither believeth he that it is the sound of the trumpet. [^24] He saith among the trumpets, Ha, ha;And he smelleth the battle afar off,The thunder of the captains, and the shouting. [^25] Doth the hawk fly by thy wisdom,And stretch her wings toward the south? [^26] Doth the eagle mount up at thy command,And make her nest on high? [^27] She dwelleth and abideth on the rock,Upon the crag of the rock, and the strong place. [^28] From thence she seeketh the prey,And her eyes behold afar off. [^29] Her young ones also suck up blood:And where the slain are, there is she. [^30] 

[[Job - 38|<--]] Job - 39 [[Job - 40|-->]]

---
# Notes
