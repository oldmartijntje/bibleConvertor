---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 37 - King James Version"
---
[[Job - 36|<--]] Job - 37 [[Job - 38|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 37

At this also my heart trembleth,And is moved out of his place. [^1] Hear attentively the noise of his voice,And the sound that goeth out of his mouth. [^2] He directeth it under the whole heaven,And his lightning unto the ends of the earth. [^3] After it a voice roareth:He thundereth with the voice of his excellency;And he will not stay them when his voice is heard. [^4] God thundereth marvellously with his voice;Great things doeth he, which we cannot comprehend. [^5] For he saith to the snow, Be thou on the earth;Likewise to the small rain,And to the great rain of his strength. [^6] He sealeth up the hand of every man;That all men may know his work. [^7] Then the beasts go into dens,And remain in their places. [^8] Out of the south cometh the whirlwind:And cold out of the north. [^9] By the breath of God frost is given:And the breadth of the waters is straitened. [^10] Also by watering he wearieth the thick cloud:He scattereth his bright cloud: [^11] And it is turned round about by his counsels:That they may do whatsoever he commandeth themUpon the face of the world in the earth. [^12] He causeth it to come, whether for correction, or for his land, or for mercy. [^13] Hearken unto this, O Job:Stand still, and consider the wondrous works of God. [^14] Dost thou know when God disposed them,And caused the light of his cloud to shine? [^15] Dost thou know the balancings of the clouds,The wondrous works of him which is perfect in knowledge? [^16] How thy garments are warm,When he quieteth the earth by the south wind? [^17] Hast thou with him spread out the sky,Which is strong, and as a molten looking glass? [^18] Teach us what we shall say unto him;For we cannot order our speech by reason of darkness. [^19] Shall it be told him that I speak?If a man speak, surely he shall be swallowed up. [^20] And now men see not the bright lightWhich is in the clouds:But the wind passeth, and cleanseth them. [^21] Fair weather cometh out of the north:With God is terrible majesty. [^22] Touching the Almighty, we cannot find him out:He is excellent in power, and in judgment,And in plenty of justice: he will not afflict. [^23] Men do therefore fear him:He respecteth not any that are wise of heart. [^24] 

[[Job - 36|<--]] Job - 37 [[Job - 38|-->]]

---
# Notes
