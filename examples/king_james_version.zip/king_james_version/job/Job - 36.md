---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 36 - King James Version"
---
[[Job - 35|<--]] Job - 36 [[Job - 37|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 36

Elihu also proceeded, and said, [^1] Suffer me a little, and I will shew theeThat I have yet to speak on God's behalf. [^2] I will fetch my knowledge from afar,And will ascribe righteousness to my Maker. [^3] For truly my words shall not be false:He that is perfect in knowledge is with thee. [^4] Behold, God is mighty, and despiseth not any:He is mighty in strength and wisdom. [^5] He preserveth not the life of the wicked:But giveth right to the poor. [^6] He withdraweth not his eyes from the righteous:But with kings are they on the throne;Yea, he doth establish them for ever, and they are exalted. [^7] And if they be bound in fetters,And be holden in cords of affliction; [^8] Then he sheweth them their work,And their transgressions that they have exceeded. [^9] He openeth also their ear to discipline,And commandeth that they return from iniquity. [^10] If they obey and serve him,They shall spend their days in prosperity,And their years in pleasures. [^11] But if they obey not, they shall perish by the sword,And they shall die without knowledge. [^12] But the hypocrites in heart heap up wrath:They cry not when he bindeth them. [^13] They die in youth,And their life is among the unclean. [^14] He delivereth the poor in his affliction,And openeth their ears in oppression. [^15] Even so would he have removed thee out of the straitInto a broad place, where there is no straitness;And that which should be set on thy table should be full of fatness. [^16] But thou hast fulfilled the judgment of the wicked:Judgment and justice take hold on thee. [^17] Because there is wrath, beware lest he take thee away with his stroke:Then a great ransom cannot deliver thee. [^18] Will he esteem thy riches? no, not gold,Nor all the forces of strength. [^19] Desire not the night,When people are cut off in their place. [^20] Take heed, regard not iniquity:For this hast thou chosen rather than affliction. [^21] Behold, God exalteth by his power:Who teacheth like him? [^22] Who hath enjoined him his way?Or who can say, Thou hast wrought iniquity? [^23] Remember that thou magnify his work,Which men behold. [^24] Every man may see it;Man may behold it afar off. [^25] Behold, God is great, and we know him not,Neither can the number of his years be searched out. [^26] For he maketh small the drops of water:They pour down rain according to the vapour thereof: [^27] Which the clouds do dropAnd distil upon man abundantly. [^28] Also can any understand the spreadings of the clouds,Or the noise of his tabernacle? [^29] Behold, he spreadeth his light upon it,And covereth the bottom of the sea. [^30] For by them judgeth he the people;He giveth meat in abundance. [^31] With clouds he covereth the light;And commandeth it not to shine by the cloud that cometh betwixt. [^32] The noise thereof sheweth concerning it,The cattle also concerning the vapour. [^33] 

[[Job - 35|<--]] Job - 36 [[Job - 37|-->]]

---
# Notes
