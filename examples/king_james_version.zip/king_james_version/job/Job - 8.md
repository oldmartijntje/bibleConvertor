---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 8 - King James Version"
---
[[Job - 7|<--]] Job - 8 [[Job - 9|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 8

Then answered Bildad the Shuhite, and said, [^1] How long wilt thou speak these things?And how long shall the words of thy mouth be like a strong wind? [^2] Doth God pervert judgment?Or doth the Almighty pervert justice? [^3] If thy children have sinned against him,And he have cast them away for their transgression; [^4] If thou wouldest seek unto God betimes,And make thy supplication to the Almighty; [^5] If thou wert pure and upright;Surely now he would awake for thee,And make the habitation of thy righteousness prosperous. [^6] Though thy beginning was small,Yet thy latter end should greatly increase. [^7] For enquire, I pray thee, of the former age,And prepare thyself to the search of their fathers: [^8] (For we are but of yesterday, and know nothing,Because our days upon earth are a shadow:) [^9] Shall not they teach thee, and tell thee,And utter words out of their heart? [^10] Can the rush grow up without mire?Can the flag grow without water? [^11] Whilst it is yet in his greenness, and not cut down,It withereth before any other herb. [^12] So are the paths of all that forget God;And the hypocrite's hope shall perish: [^13] Whose hope shall be cut off,And whose trust shall be a spider's web. [^14] He shall lean upon his house, but it shall not stand:He shall hold it fast, but it shall not endure. [^15] He is green before the sun,And his branch shooteth forth in his garden. [^16] His roots are wrapped about the heap,And seeth the place of stones. [^17] If he destroy him from his place,Then it shall deny him, saying,I have not seen thee. [^18] Behold, this is the joy of his way,And out of the earth shall others grow. [^19] Behold, God will not cast away a perfect man,Neither will he help the evil doers: [^20] Till he fill thy mouth with laughing,And thy lips with rejoicing. [^21] They that hate thee shall be clothed with shame;And the dwelling place of the wicked shall come to nought. [^22] 

[[Job - 7|<--]] Job - 8 [[Job - 9|-->]]

---
# Notes
