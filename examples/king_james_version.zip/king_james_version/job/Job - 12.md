---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 12 - King James Version"
---
[[Job - 11|<--]] Job - 12 [[Job - 13|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 12

And Job answered and said, [^1] No doubt but ye are the people,And wisdom shall die with you. [^2] But I have understanding as well as you;I am not inferior to you:Yea, who knoweth not such things as these? [^3] I am as one mocked of his neighbour,Who calleth upon God, and he answereth him:The just upright man is laughed to scorn. [^4] He that is ready to slip with his feetIs as a lamp despised in the thought of him that is at ease. [^5] The tabernacles of robbers prosper,And they that provoke God are secure;Into whose hand God bringeth abundantly. [^6] But ask now the beasts, and they shall teach thee;And the fowls of the air, and they shall tell thee: [^7] Or speak to the earth, and it shall teach thee:And the fishes of the sea shall declare unto thee. [^8] Who knoweth not in all theseThat the hand of the LORD hath wrought this? [^9] In whose hand is the soul of every living thing,And the breath of all mankind. [^10] Doth not the ear try words?And the mouth taste his meat? [^11] With the ancient is wisdom;And in length of days understanding. [^12] With him is wisdom and strength,He hath counsel and understanding. [^13] Behold, he breaketh down, and it cannot be built again:He shutteth up a man, and there can be no opening. [^14] Behold, he withholdeth the waters, and they dry up:Also he sendeth them out, and they overturn the earth. [^15] With him is strength and wisdom:The deceived and the deceiver are his. [^16] He leadeth counsellors away spoiled,And maketh the judges fools. [^17] He looseth the bond of kings,And girdeth their loins with a girdle. [^18] He leadeth princes away spoiled,And overthroweth the mighty. [^19] He removeth away the speech of the trusty,And taketh away the understanding of the aged. [^20] He poureth contempt upon princes,And weakeneth the strength of the mighty. [^21] He discovereth deep things out of darkness,And bringeth out to light the shadow of death. [^22] He increaseth the nations, and destroyeth them:He enlargeth the nations, and straiteneth them again. [^23] He taketh away the heart of the chief of the people of the earth,And causeth them to wander in a wilderness where there is no way. [^24] They grope in the dark without light,And he maketh them to stagger like a drunken man. [^25] 

[[Job - 11|<--]] Job - 12 [[Job - 13|-->]]

---
# Notes
