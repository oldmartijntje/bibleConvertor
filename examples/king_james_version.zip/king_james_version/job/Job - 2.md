---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 2 - King James Version"
---
[[Job - 1|<--]] Job - 2 [[Job - 3|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 2

Again there was a day when the sons of God came to present themselves before the LORD, and Satan came also among them to present himself before the LORD. [^1] And the LORD said unto Satan, From whence comest thou? And Satan answered the LORD, and said, From going to and fro in the earth, and from walking up and down in it. [^2] And the LORD said unto Satan, Hast thou considered my servant Job, that there is none like him in the earth, a perfect and an upright man, one that feareth God, and escheweth evil? and still he holdeth fast his integrity, although thou movedst me against him, to destroy him without cause. [^3] And Satan answered the LORD, and said, Skin for skin, yea, all that a man hath will he give for his life. [^4] But put forth thine hand now, and touch his bone and his flesh, and he will curse thee to thy face. [^5] And the LORD said unto Satan, Behold, he is in thine hand; but save his life. [^6] So went Satan forth from the presence of the LORD, and smote Job with sore boils from the sole of his foot unto his crown. [^7] And he took him a potsherd to scrape himself withal; and he sat down among the ashes. [^8] Then said his wife unto him, Dost thou still retain thine integrity? curse God, and die. [^9] But he said unto her, Thou speakest as one of the foolish women speaketh. What? shall we receive good at the hand of God, and shall we not receive evil? In all this did not Job sin with his lips. [^10] Now when Job's three friends heard of all this evil that was come upon him, they came every one from his own place; Eliphaz the Temanite, and Bildad the Shuhite, and Zophar the Naamathite: for they had made an appointment together to come to mourn with him and to comfort him. [^11] And when they lifted up their eyes afar off, and knew him not, they lifted up their voice, and wept; and they rent every one his mantle, and sprinkled dust upon their heads toward heaven. [^12] So they sat down with him upon the ground seven days and seven nights, and none spake a word unto him: for they saw that his grief was very great. [^13] 

[[Job - 1|<--]] Job - 2 [[Job - 3|-->]]

---
# Notes
