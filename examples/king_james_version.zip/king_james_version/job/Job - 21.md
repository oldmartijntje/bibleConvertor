---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 21 - King James Version"
---
[[Job - 20|<--]] Job - 21 [[Job - 22|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 21

But Job answered and said, [^1] Hear diligently my speech,And let this be your consolations. [^2] Suffer me that I may speak;And after that I have spoken, mock on. [^3] As for me, is my complaint to man?And if it were so, why should not my spirit be troubled? [^4] Mark me, and be astonished,And lay your hand upon your mouth. [^5] Even when I remember I am afraid,And trembling taketh hold on my flesh. [^6] Wherefore do the wicked live,Become old, yea, are mighty in power? [^7] Their seed is established in their sight with them,And their offspring before their eyes. [^8] Their houses are safe from fear,Neither is the rod of God upon them. [^9] Their bull gendereth, and faileth not;Their cow calveth, and casteth not her calf. [^10] They send forth their little ones like a flock,And their children dance. [^11] They take the timbrel and harp,And rejoice at the sound of the organ. [^12] They spend their days in wealth,And in a moment go down to the grave. [^13] Therefore they say unto God, Depart from us;For we desire not the knowledge of thy ways. [^14] What is the Almighty, that we should serve him?And what profit should we have, if we pray unto him? [^15] Lo, their good is not in their hand:The counsel of the wicked is far from me. [^16] How oft is the candle of the wicked put out!And how oft cometh their destruction upon them!God distributeth sorrows in his anger. [^17] They are as stubble before the wind,And as chaff that the storm carrieth away. [^18] God layeth up his iniquity for his children:He rewardeth him, and he shall know it. [^19] His eyes shall see his destruction,And he shall drink of the wrath of the Almighty. [^20] For what pleasure hath he in his house after him,When the number of his months is cut off in the midst? [^21] Shall any teach God knowledge?Seeing he judgeth those that are high. [^22] One dieth in his full strength,Being wholly at ease and quiet. [^23] His breasts are full of milk,And his bones are moistened with marrow. [^24] And another dieth in the bitterness of his soul,And never eateth with pleasure. [^25] They shall lie down alike in the dust,And the worms shall cover them. [^26] Behold, I know your thoughts,And the devices which ye wrongfully imagine against me. [^27] For ye say, Where is the house of the prince?And where are the dwelling places of the wicked? [^28] Have ye not asked them that go by the way?And do ye not know their tokens, [^29] That the wicked is reserved to the day of destruction?They shall be brought forth to the day of wrath. [^30] Who shall declare his way to his face?And who shall repay him what he hath done? [^31] Yet shall he be brought to the grave,And shall remain in the tomb. [^32] The clods of the valley shall be sweet unto him,And every man shall draw after him,As there are innumerable before him. [^33] How then comfort ye me in vain,Seeing in your answers there remaineth falsehood? [^34] 

[[Job - 20|<--]] Job - 21 [[Job - 22|-->]]

---
# Notes
