---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 3 - King James Version"
---
[[Job - 2|<--]] Job - 3 [[Job - 4|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 3

After this opened Job his mouth, and cursed his day. [^1] And Job spake, and said, [^2] Let the day perish wherein I was born,And the night in which it was said,There is a man child conceived. [^3] Let that day be darkness;Let not God regard it from above,Neither let the light shine upon it. [^4] Let darkness and the shadow of death stain it;Let a cloud dwell upon it;Let the blackness of the day terrify it. [^5] As for that night, let darkness seize upon it;Let it not be joined unto the days of the year,Let it not come into the number of the months. [^6] Lo, let that night be solitary,Let no joyful voice come therein. [^7] Let them curse it that curse the day,Who are ready to raise up their mourning. [^8] Let the stars of the twilight thereof be dark;Let it look for light, but have none;Neither let it see the dawning of the day: [^9] Because it shut not up the doors of my mother's womb,Nor hid sorrow from mine eyes. [^10] Why died I not from the womb?Why did I not give up the ghostWhen I came out of the belly? [^11] Why did the knees prevent me?Or why the breasts that I should suck? [^12] For now should I have lain still and been quiet,I should have slept: then had I been at rest, [^13] With kings and counsellors of the earth,Which built desolate places for themselves; [^14] Or with princes that had gold,Who filled their houses with silver: [^15] Or as an hidden untimely birth I had not been;As infants which never saw light. [^16] There the wicked cease from troubling;And there the weary be at rest. [^17] There the prisoners rest together;They hear not the voice of the oppressor. [^18] The small and great are there;And the servant is free from his master. [^19] Wherefore is light given to him that is in misery,And life unto the bitter in soul; [^20] Which long for death, but it cometh not;And dig for it more than for hid treasures; [^21] Which rejoice exceedingly,And are glad, when they can find the grave? [^22] Why is light given to a man whose way is hid,And whom God hath hedged in? [^23] For my sighing cometh before I eat,And my roarings are poured out like the waters. [^24] For the thing which I greatly feared is come upon me,And that which I was afraid of is come unto me. [^25] I was not in safety, neither had I rest, neither was I quiet;Yet trouble came. [^26] 

[[Job - 2|<--]] Job - 3 [[Job - 4|-->]]

---
# Notes
