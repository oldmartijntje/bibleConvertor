---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 14 - King James Version"
---
[[Job - 13|<--]] Job - 14 [[Job - 15|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 14

Man that is born of a womanIs of few days, and full of trouble. [^1] He cometh forth like a flower, and is cut down:He fleeth also as a shadow, and continueth not. [^2] And dost thou open thine eyes upon such an one,And bringest me into judgment with thee? [^3] Who can bring a clean thing out of an unclean?Not one. [^4] Seeing his days are determined, the number of his months are with thee,Thou hast appointed his bounds that he cannot pass; [^5] Turn from him, that he may rest,Till he shall accomplish, as an hireling, his day. [^6] For there is hope of a tree,If it be cut down, that it will sprout again,And that the tender branch thereof will not cease. [^7] Though the root thereof wax old in the earth,And the stock thereof die in the ground; [^8] Yet through the scent of water it will bud,And bring forth boughs like a plant. [^9] But man dieth, and wasteth away:Yea, man giveth up the ghost, and where is he? [^10] As the waters fail from the sea,And the flood decayeth and drieth up: [^11] So man lieth down, and riseth not:Till the heavens be no more, they shall not awake,Nor be raised out of their sleep. [^12] O that thou wouldest hide me in the grave,That thou wouldest keep me secret, until thy wrath be past,That thou wouldest appoint me a set time, and remember me! [^13] If a man die, shall he live again?All the days of my appointed time will I wait,Till my change come. [^14] Thou shalt call, and I will answer thee:Thou wilt have a desire to the work of thine hands. [^15] For now thou numberest my steps:Dost thou not watch over my sin? [^16] My transgression is sealed up in a bag,And thou sewest up mine iniquity. [^17] And surely the mountain falling cometh to nought,And the rock is removed out of his place. [^18] The waters wear the stones:Thou washest away the things which grow out of the dust of the earth;And thou destroyest the hope of man. [^19] Thou prevailest for ever against him, and he passeth:Thou changest his countenance, and sendest him away. [^20] His sons come to honour, and he knoweth it not;And they are brought low, but he perceiveth it not of them. [^21] But his flesh upon him shall have pain,And his soul within him shall mourn. [^22] 

[[Job - 13|<--]] Job - 14 [[Job - 15|-->]]

---
# Notes
