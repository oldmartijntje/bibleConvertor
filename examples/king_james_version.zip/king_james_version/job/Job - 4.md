---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 4 - King James Version"
---
[[Job - 3|<--]] Job - 4 [[Job - 5|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 4

Then Eliphaz the Temanite answered and said, [^1] If we assay to commune with thee, wilt thou be grieved?But who can withhold himself from speaking? [^2] Behold, thou hast instructed many,And thou hast strengthened the weak hands. [^3] Thy words have upholden him that was falling,And thou hast strengthened the feeble knees. [^4] But now it is come upon thee, and thou faintest;It toucheth thee, and thou art troubled. [^5] Is not this thy fear, thy confidence,Thy hope, and the uprightness of thy ways? [^6] Remember, I pray thee, who ever perished, being innocent?Or where were the righteous cut off? [^7] Even as I have seen, they that plow iniquity,And sow wickedness, reap the same. [^8] By the blast of God they perish,And by the breath of his nostrils are they consumed. [^9] The roaring of the lion, and the voice of the fierce lion,And the teeth of the young lions, are broken. [^10] The old lion perisheth for lack of prey,And the stout lion's whelps are scattered abroad. [^11] Now a thing was secretly brought to me,And mine ear received a little thereof. [^12] In thoughts from the visions of the night,When deep sleep falleth on men, [^13] Fear came upon me, and trembling,Which made all my bones to shake. [^14] Then a spirit passed before my face;The hair of my flesh stood up: [^15] It stood still,But I could not discern the form thereof:An image was before mine eyes,There was silence, and I heard a voice, saying, [^16] Shall mortal man be more just than God?Shall a man be more pure than his maker? [^17] Behold, he put no trust in his servants;And his angels he charged with folly: [^18] How much less in them that dwell in houses of clay,Whose foundation is in the dust,Which are crushed before the moth? [^19] They are destroyed from morning to evening:They perish for ever without any regarding it. [^20] Doth not their excellency which is in them go away?They die, even without wisdom. [^21] 

[[Job - 3|<--]] Job - 4 [[Job - 5|-->]]

---
# Notes
