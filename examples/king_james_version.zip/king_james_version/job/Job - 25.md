---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 25 - King James Version"
---
[[Job - 24|<--]] Job - 25 [[Job - 26|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 25

Then answered Bildad the Shuhite, and said, [^1] Dominion and fear are with him,He maketh peace in his high places. [^2] Is there any number of his armies?And upon whom doth not his light arise? [^3] How then can man be justified with God?Or how can he be clean that is born of a woman? [^4] Behold even to the moon, and it shineth not;Yea, the stars are not pure in his sight. [^5] How much less man, that is a worm?And the son of man, which is a worm? [^6] 

[[Job - 24|<--]] Job - 25 [[Job - 26|-->]]

---
# Notes
