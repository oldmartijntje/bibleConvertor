---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 24 - King James Version"
---
[[Job - 23|<--]] Job - 24 [[Job - 25|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 24

Why, seeing times are not hidden from the Almighty,Do they that know him not see his days? [^1] Some remove the landmarks;They violently take away flocks, and feed thereof. [^2] They drive away the ass of the fatherless,They take the widow's ox for a pledge. [^3] They turn the needy out of the way:The poor of the earth hide themselves together. [^4] Behold, as wild asses in the desert,Go they forth to their work; rising betimes for a prey:The wilderness yieldeth food for them and for their children. [^5] They reap every one his corn in the field:And they gather the vintage of the wicked. [^6] They cause the naked to lodge without clothing,That they have no covering in the cold. [^7] They are wet with the showers of the mountains,And embrace the rock for want of a shelter. [^8] They pluck the fatherless from the breast,And take a pledge of the poor. [^9] They cause him to go naked without clothing,And they take away the sheaf from the hungry; [^10] Which make oil within their walls,And tread their winepresses, and suffer thirst. [^11] Men groan from out of the city,And the soul of the wounded crieth out:Yet God layeth not folly to them. [^12] They are of those that rebel against the light;They know not the ways thereof,Nor abide in the paths thereof. [^13] The murderer rising with the light killeth the poor and needy,And in the night is as a thief. [^14] The eye also of the adulterer waiteth for the twilight,Saying, No eye shall see me:And disguiseth his face. [^15] In the dark they dig through houses,Which they had marked for themselves in the daytime:They know not the light. [^16] For the morning is to them even as the shadow of death:If one know them, they are in the terrors of the shadow of death. [^17] He is swift as the waters;Their portion is cursed in the earth:He beholdeth not the way of the vineyards. [^18] Drought and heat consume the snow waters:So doth the grave those which have sinned. [^19] The womb shall forget him; the worm shall feed sweetly on him;He shall be no more remembered;And wickedness shall be broken as a tree. [^20] He evil entreateth the barren that beareth not:And doeth not good to the widow. [^21] He draweth also the mighty with his power:He riseth up, and no man is sure of life. [^22] Though it be given him to be in safety, whereon he resteth;Yet his eyes are upon their ways. [^23] They are exalted for a little while, but are goneAnd brought low; they are taken out of the way as all other,And cut off as the tops of the ears of corn. [^24] And if it be not so now, who will make me a liar,And make my speech nothing worth? [^25] 

[[Job - 23|<--]] Job - 24 [[Job - 25|-->]]

---
# Notes
