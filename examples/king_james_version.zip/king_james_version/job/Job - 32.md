---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 32 - King James Version"
---
[[Job - 31|<--]] Job - 32 [[Job - 33|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 32

So these three men ceased to answer Job, because he was righteous in his own eyes. [^1] Then was kindled the wrath of Elihu the son of Barachel the Buzite, of the kindred of Ram: against Job was his wrath kindled, because he justified himself rather than God. [^2] Also against his three friends was his wrath kindled, because they had found no answer, and yet had condemned Job. [^3] Now Elihu had waited till Job had spoken, because they were elder than he. [^4] When Elihu saw that there was no answer in the mouth of these three men, then his wrath was kindled. [^5] And Elihu the son of Barachel the Buzite answered and said,I am young, and ye are very old;Wherefore I was afraid, and durst not shew you mine opinion. [^6] I said, Days should speak,And multitude of years should teach wisdom. [^7] But there is a spirit in man:And the inspiration of the Almighty giveth them understanding. [^8] Great men are not always wise:Neither do the aged understand judgment. [^9] Therefore I said, Hearken to me;I also will shew mine opinion. [^10] Behold, I waited for your words;I gave ear to your reasons,Whilst ye searched out what to say. [^11] Yea, I attended unto you,And, behold, there was none of you that convinced Job,Or that answered his words: [^12] Lest ye should say, We have found out wisdom:God thrusteth him down, not man. [^13] Now he hath not directed his words against me:Neither will I answer him with your speeches. [^14] They were amazed, they answered no more:They left off speaking. [^15] When I had waited, (for they spake not,But stood still, and answered no more;) [^16] I said, I will answer also my part,I also will shew mine opinion. [^17] For I am full of matter,The spirit within me constraineth me. [^18] Behold, my belly is as wine which hath no vent;It is ready to burst like new bottles. [^19] I will speak, that I may be refreshed:I will open my lips and answer. [^20] Let me not, I pray you, accept any man's person,Neither let me give flattering titles unto man. [^21] For I know not to give flattering titles;In so doing my Maker would soon take me away. [^22] 

[[Job - 31|<--]] Job - 32 [[Job - 33|-->]]

---
# Notes
