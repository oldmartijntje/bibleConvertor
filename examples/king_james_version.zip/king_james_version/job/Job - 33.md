---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 33 - King James Version"
---
[[Job - 32|<--]] Job - 33 [[Job - 34|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 33

Wherefore, Job, I pray thee, hear my speeches,And hearken to all my words. [^1] Behold, now I have opened my mouth,My tongue hath spoken in my mouth. [^2] My words shall be of the uprightness of my heart:And my lips shall utter knowledge clearly. [^3] The Spirit of God hath made me,And the breath of the Almighty hath given me life. [^4] If thou canst answer me,Set thy words in order before me, stand up. [^5] Behold, I am according to thy wish in God's stead:I also am formed out of the clay. [^6] Behold, my terror shall not make thee afraid,Neither shall my hand be heavy upon thee. [^7] Surely thou hast spoken in mine hearing,And I have heard the voice of thy words, saying, [^8] I am clean without transgression,I am innocent; neither is there iniquity in me. [^9] Behold, he findeth occasions against me,He counteth me for his enemy, [^10] He putteth my feet in the stocks,He marketh all my paths. [^11] Behold, in this thou art not just: I will answer thee,that God is greater than man. [^12] Why dost thou strive against him?For he giveth not account of any of his matters. [^13] For God speaketh once,Yea twice, yet man perceiveth it not. [^14] In a dream, in a vision of the night,When deep sleep falleth upon men,In slumberings upon the bed; [^15] Then he openeth the ears of men,And sealeth their instruction, [^16] That he may withdraw man from his purpose,And hide pride from man. [^17] He keepeth back his soul from the pit,And his life from perishing by the sword. [^18] He is chastened also with pain upon his bed,And the multitude of his bones with strong pain: [^19] So that his life abhorreth bread,And his soul dainty meat. [^20] His flesh is consumed away, that it cannot be seen;And his bones that were not seen stick out. [^21] Yea, his soul draweth near unto the grave,And his life to the destroyers. [^22] If there be a messenger with him,An interpreter, one among a thousand,To shew unto man his uprightness: [^23] Then he is gracious unto him, and saith,Deliver him from going down to the pit:I have found a ransom. [^24] His flesh shall be fresher than a child's:He shall return to the days of his youth: [^25] He shall pray unto God, and he will be favourable unto him:And he shall see his face with joy:For he will render unto man his righteousness. [^26] He looketh upon men, and if any say,I have sinned, and perverted that which was right,And it profited me not; [^27] He will deliver his soul from going into the pit,And his life shall see the light. [^28] Lo, all these things worketh GodOftentimes with man, [^29] To bring back his soul from the pit,To be enlightened with the light of the living. [^30] Mark well, O Job, hearken unto me:Hold thy peace, and I will speak. [^31] If thou hast any thing to say, answer me:Speak, for I desire to justify thee. [^32] If not, hearken unto me:Hold thy peace, and I shall teach thee wisdom. [^33] 

[[Job - 32|<--]] Job - 33 [[Job - 34|-->]]

---
# Notes
