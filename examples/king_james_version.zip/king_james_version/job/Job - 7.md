---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 7 - King James Version"
---
[[Job - 6|<--]] Job - 7 [[Job - 8|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 7

Is there not an appointed time to man upon earth?Are not his days also like the days of an hireling? [^1] As a servant earnestly desireth the shadow,And as an hireling looketh for the reward of his work: [^2] So am I made to possess months of vanity,And wearisome nights are appointed to me. [^3] When I lie down, I say,When shall I arise, and the night be gone?And I am full of tossings to and fro unto the dawning of the day. [^4] My flesh is clothed with worms and clods of dust;My skin is broken, and become loathsome. [^5] My days are swifter than a weaver's shuttle,And are spent without hope. [^6] O remember that my life is wind:Mine eye shall no more see good. [^7] The eye of him that hath seen me shall see me no more:Thine eyes are upon me, and I am not. [^8] As the cloud is consumed and vanisheth away:So he that goeth down to the grave shall come up no more. [^9] He shall return no more to his house,Neither shall his place know him any more. [^10] Therefore I will not refrain my mouth;I will speak in the anguish of my spirit;I will complain in the bitterness of my soul. [^11] Am I a sea, or a whale,That thou settest a watch over me? [^12] When I say, My bed shall comfort me,My couch shall ease my complaint; [^13] Then thou scarest me with dreams,And terrifiest me through visions: [^14] So that my soul chooseth strangling,And death rather than my life. [^15] I loathe it; I would not live alway:Let me alone; for my days are vanity. [^16] What is man, that thou shouldest magnify him?And that thou shouldest set thine heart upon him? [^17] And that thou shouldest visit him every morning,And try him every moment? [^18] How long wilt thou not depart from me,Nor let me alone till I swallow down my spittle? [^19] I have sinned; what shall I do unto thee, O thou preserver of men?Why hast thou set me as a mark against thee,So that I am a burden to myself? [^20] And why dost thou not pardon my transgression,And take away mine iniquity?For now shall I sleep in the dust;And thou shalt seek me in the morning,but I shall not be. [^21] 

[[Job - 6|<--]] Job - 7 [[Job - 8|-->]]

---
# Notes
