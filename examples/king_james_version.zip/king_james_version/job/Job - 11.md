---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 11 - King James Version"
---
[[Job - 10|<--]] Job - 11 [[Job - 12|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 11

Then answered Zophar the Naamathite, and said, [^1] Should not the multitude of words be answered?And should a man full of talk be justified? [^2] Should thy lies make men hold their peace?And when thou mockest, shall no man make thee ashamed? [^3] For thou hast said, My doctrine is pure,And I am clean in thine eyes. [^4] But oh that God would speak,And open his lips against thee; [^5] And that he would shew thee the secrets of wisdom,That they are double to that which is!Know therefore that God exacteth of thee less than thine iniquity deserveth. [^6] Canst thou by searching find out God?Canst thou find out the Almighty unto perfection? [^7] It is as high as heaven; what canst thou do?Deeper than hell; what canst thou know? [^8] The measure thereof is longer than the earth,And broader than the sea. [^9] If he cut off, and shut up,Or gather together, then who can hinder him? [^10] For he knoweth vain men:He seeth wickedness also; will he not then consider it? [^11] For vain man would be wise,Though man be born like a wild ass's colt. [^12] If thou prepare thine heart,And stretch out thine hands toward him; [^13] If iniquity be in thine hand, put it far away,And let not wickedness dwell in thy tabernacles. [^14] For then shalt thou lift up thy face without spot;Yea, thou shalt be stedfast, and shalt not fear: [^15] Because thou shalt forget thy misery,And remember it as waters that pass away: [^16] And thine age shall be clearer than the noonday;Thou shalt shine forth, thou shalt be as the morning. [^17] And thou shalt be secure, because there is hope;Yea, thou shalt dig about thee, and thou shalt take thy rest in safety. [^18] Also thou shalt lie down, and none shall make thee afraid;Yea, many shall make suit unto thee. [^19] But the eyes of the wicked shall fail,And they shall not escape,And their hope shall be as the giving up of the ghost. [^20] 

[[Job - 10|<--]] Job - 11 [[Job - 12|-->]]

---
# Notes
