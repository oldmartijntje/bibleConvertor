---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 26 - King James Version"
---
[[Job - 25|<--]] Job - 26 [[Job - 27|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 26

But Job answered and said, [^1] How hast thou helped him that is without power?How savest thou the arm that hath no strength? [^2] How hast thou counselled him that hath no wisdom?And how hast thou plentifully declared the thing as it is? [^3] To whom hast thou uttered words?And whose spirit came from thee? [^4] Dead things are formedFrom under the waters, and the inhabitants thereof. [^5] Hell is naked before him,And destruction hath no covering. [^6] He stretcheth out the north over the empty place,And hangeth the earth upon nothing. [^7] He bindeth up the waters in his thick clouds;And the cloud is not rent under them. [^8] He holdeth back the face of his throne,And spreadeth his cloud upon it. [^9] He hath compassed the waters with bounds,Until the day and night come to an end. [^10] The pillars of heaven trembleAnd are astonished at his reproof. [^11] He divideth the sea with his power,And by his understanding he smiteth through the proud. [^12] By his spirit he hath garnished the heavens;His hand hath formed the crooked serpent. [^13] Lo, these are parts of his ways:But how little a portion is heard of him?But the thunder of his power who can understand? [^14] 

[[Job - 25|<--]] Job - 26 [[Job - 27|-->]]

---
# Notes
