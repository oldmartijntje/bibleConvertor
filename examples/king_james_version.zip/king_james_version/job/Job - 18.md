---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 18 - King James Version"
---
[[Job - 17|<--]] Job - 18 [[Job - 19|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 18

Then answered Bildad the Shuhite, and said, [^1] How long will it be ere ye make an end of words?Mark, and afterwards we will speak. [^2] Wherefore are we counted as beasts,And reputed vile in your sight? [^3] He teareth himself in his anger:Shall the earth be forsaken for thee?And shall the rock be removed out of his place? [^4] Yea, the light of the wicked shall be put out,And the spark of his fire shall not shine. [^5] The light shall be dark in his tabernacle,And his candle shall be put out with him. [^6] The steps of his strength shall be straitened,And his own counsel shall cast him down. [^7] For he is cast into a net by his own feet,And he walketh upon a snare. [^8] The gin shall take him by the heel,And the robber shall prevail against him. [^9] The snare is laid for him in the ground,And a trap for him in the way. [^10] Terrors shall make him afraid on every side,And shall drive him to his feet. [^11] His strength shall be hungerbitten,And destruction shall be ready at his side. [^12] It shall devour the strength of his skin:Even the firstborn of death shall devour his strength. [^13] His confidence shall be rooted out of his tabernacle,And it shall bring him to the king of terrors. [^14] It shall dwell in his tabernacle, because it is none of his:Brimstone shall be scattered upon his habitation. [^15] His roots shall be dried up beneath,And above shall his branch be cut off. [^16] His remembrance shall perish from the earth,And he shall have no name in the street. [^17] He shall be driven from light into darkness,And chased out of the world. [^18] He shall neither have son nor nephew among his people,Nor any remaining in his dwellings. [^19] They that come after him shall be astonied at his day,As they that went before were affrighted. [^20] Surely such are the dwellings of the wicked,And this is the place of him that knoweth not God. [^21] 

[[Job - 17|<--]] Job - 18 [[Job - 19|-->]]

---
# Notes
