---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 40 - King James Version"
---
[[Job - 39|<--]] Job - 40 [[Job - 41|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 40

Moreover the LORD answered Job, and said, [^1] Shall he that contendeth with the Almighty instruct him?He that reproveth God, let him answer it. [^2] Then Job answered the LORD, and said, [^3] Behold, I am vile; what shall I answer thee?I will lay mine hand upon my mouth. [^4] Once have I spoken; but I will not answer:Yea, twice; but I will proceed no further. [^5] Then answered the LORD unto Job out of the whirlwind, and said, [^6] Gird up thy loins now like a man:I will demand of thee, and declare thou unto me. [^7] Wilt thou also disannul my judgment?Wilt thou condemn me, that thou mayest be righteous? [^8] Hast thou an arm like God?Or canst thou thunder with a voice like him? [^9] Deck thyself now with majesty and excellency;And array thyself with glory and beauty. [^10] Cast abroad the rage of thy wrath:And behold every one that is proud, and abase him. [^11] Look on every one that is proud, and bring him low;And tread down the wicked in their place. [^12] Hide them in the dust together;And bind their faces in secret. [^13] Then will I also confess unto theeThat thine own right hand can save thee. [^14] Behold now behemoth,Which I made with thee;He eateth grass as an ox. [^15] Lo now, his strength is in his loins,And his force is in the navel of his belly. [^16] He moveth his tail like a cedar:The sinews of his stones are wrapped together. [^17] His bones are as strong pieces of brass;His bones are like bars of iron. [^18] He is the chief of the ways of God:He that made him can make his sword to approach unto him. [^19] Surely the mountains bring him forth food,Where all the beasts of the field play. [^20] He lieth under the shady trees,In the covert of the reed, and fens. [^21] The shady trees cover him with their shadow;The willows of the brook compass him about. [^22] Behold, he drinketh up a river, and hasteth not:He trusteth that he can draw up Jordan into his mouth. [^23] He taketh it with his eyes:His nose pierceth through snares. [^24] 

[[Job - 39|<--]] Job - 40 [[Job - 41|-->]]

---
# Notes
