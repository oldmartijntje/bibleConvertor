---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 28 - King James Version"
---
[[Job - 27|<--]] Job - 28 [[Job - 29|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 28

Surely there is a vein for the silver,And a place for gold where they fine it. [^1] Iron is taken out of the earth,And brass is molten out of the stone. [^2] He setteth an end to darkness,And searcheth out all perfection:The stones of darkness, and the shadow of death. [^3] The flood breaketh out from the inhabitant;Even the waters forgotten of the foot:They are dried up, they are gone away from men. [^4] As for the earth, out of it cometh bread:And under it is turned up as it were fire. [^5] The stones of it are the place of sapphires:And it hath dust of gold. [^6] There is a path which no fowl knoweth,And which the vulture's eye hath not seen: [^7] The lion's whelps have not trodden it,Nor the fierce lion passed by it. [^8] He putteth forth his hand upon the rock;He overturneth the mountains by the roots. [^9] He cutteth out rivers among the rocks;And his eye seeth every precious thing. [^10] He bindeth the floods from overflowing;And the thing that is hid bringeth he forth to light. [^11] But where shall wisdom be found?And where is the place of understanding? [^12] Man knoweth not the price thereof;Neither is it found in the land of the living. [^13] The depth saith, It is not in me:And the sea saith, It is not with me. [^14] It cannot be gotten for gold,Neither shall silver be weighed for the price thereof. [^15] It cannot be valued with the gold of Ophir,With the precious onyx, or the sapphire. [^16] The gold and the crystal cannot equal it:And the exchange of it shall not be for jewels of fine gold. [^17] No mention shall be made of coral, or of pearls:For the price of wisdom is above rubies. [^18] The topaz of Ethiopia shall not equal it,Neither shall it be valued with pure gold. [^19] Whence then cometh wisdom?And where is the place of understanding? [^20] Seeing it is hid from the eyes of all living,And kept close from the fowls of the air. [^21] Destruction and death say,We have heard the fame thereof with our ears. [^22] God understandeth the way thereof,And he knoweth the place thereof. [^23] For he looketh to the ends of the earth,And seeth under the whole heaven; [^24] To make the weight for the winds;And he weigheth the waters by measure. [^25] When he made a decree for the rain,And a way for the lightning of the thunder: [^26] Then did he see it, and declare it;He prepared it, yea, and searched it out. [^27] And unto man he said,Behold, the fear of the Lord, that is wisdom;And to depart from evil is understanding. [^28] 

[[Job - 27|<--]] Job - 28 [[Job - 29|-->]]

---
# Notes
