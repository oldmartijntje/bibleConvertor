---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 9 - King James Version"
---
[[Job - 8|<--]] Job - 9 [[Job - 10|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 9

Then Job answered and said, [^1] I know it is so of a truth:But how should man be just with God? [^2] If he will contend with him,He cannot answer him one of a thousand. [^3] He is wise in heart, and mighty in strength:Who hath hardened himself against him, and hath prospered? [^4] Which removeth the mountains, and they know not:Which overturneth them in his anger. [^5] Which shaketh the earth out of her place,And the pillars thereof tremble. [^6] Which commandeth the sun, and it riseth not;And sealeth up the stars. [^7] Which alone spreadeth out the heavens,And treadeth upon the waves of the sea. [^8] Which maketh Arcturus, Orion, and Pleiades,And the chambers of the south. [^9] Which doeth great things past finding out;Yea, and wonders without number. [^10] Lo, he goeth by me, and I see him not:He passeth on also, but I perceive him not. [^11] Behold, he taketh away, who can hinder him?Who will say unto him, What doest thou? [^12] If God will not withdraw his anger,The proud helpers do stoop under him. [^13] How much less shall I answer him,And choose out my words to reason with him? [^14] Whom, though I were righteous, yet would I not answer,But I would make supplication to my judge. [^15] If I had called, and he had answered me;Yet would I not believe that he had hearkened unto my voice. [^16] For he breaketh me with a tempest,And multiplieth my wounds without cause. [^17] He will not suffer me to take my breath,But filleth me with bitterness. [^18] If I speak of strength, lo, he is strong:And if of judgment, who shall set me a time to plead? [^19] If I justify myself, mine own mouth shall condemn me:If I say, I am perfect, it shall also prove me perverse. [^20] Though I were perfect, yet would I not know my soul:I would despise my life. [^21] This is one thing, therefore I said it,He destroyeth the perfect and the wicked. [^22] If the scourge slay suddenly,He will laugh at the trial of the innocent. [^23] The earth is given into the hand of the wicked:He covereth the faces of the judges thereof;If not, where, and who is he? [^24] Now my days are swifter than a post:They flee away, they see no good. [^25] They are passed away as the swift ships:As the eagle that hasteth to the prey. [^26] If I say, I will forget my complaint,I will leave off my heaviness, and comfort myself: [^27] I am afraid of all my sorrows,I know that thou wilt not hold me innocent. [^28] If I be wicked,Why then labour I in vain? [^29] If I wash myself with snow water,And make my hands never so clean; [^30] Yet shalt thou plunge me in the ditch,And mine own clothes shall abhor me. [^31] For he is not a man, as I am, that I should answer him,And we should come together in judgment. [^32] Neither is there any daysman betwixt us,That might lay his hand upon us both. [^33] Let him take his rod away from me,And let not his fear terrify me: [^34] Then would I speak, and not fear him;But it is not so with me. [^35] 

[[Job - 8|<--]] Job - 9 [[Job - 10|-->]]

---
# Notes
