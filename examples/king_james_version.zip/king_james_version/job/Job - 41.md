---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 41 - King James Version"
---
[[Job - 40|<--]] Job - 41 [[Job - 42|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 41

Canst thou draw out leviathan with an hook?Or his tongue with a cord which thou lettest down? [^1] Canst thou put an hook into his nose?Or bore his jaw through with a thorn? [^2] Will he make many supplications unto thee?Will he speak soft words unto thee? [^3] Will he make a covenant with thee?Wilt thou take him for a servant for ever? [^4] Wilt thou play with him as with a bird?Or wilt thou bind him for thy maidens? [^5] Shall the companions make a banquet of him?Shall they part him among the merchants? [^6] Canst thou fill his skin with barbed irons?Or his head with fish spears? [^7] Lay thine hand upon him,Remember the battle, do no more. [^8] Behold, the hope of him is in vain:Shall not one be cast down even at the sight of him? [^9] None is so fierce that dare stir him up:Who then is able to stand before me? [^10] Who hath prevented me, that I should repay him?Whatsoever is under the whole heaven is mine. [^11] I will not conceal his parts,Nor his power, nor his comely proportion. [^12] Who can discover the face of his garment?Or who can come to him with his double bridle? [^13] Who can open the doors of his face?His teeth are terrible round about. [^14] His scales are his pride,Shut up together as with a close seal. [^15] One is so near to another,That no air can come between them. [^16] They are joined one to another,They stick together, that they cannot be sundered. [^17] By his neesings a light doth shine,And his eyes are like the eyelids of the morning. [^18] Out of his mouth go burning lamps,And sparks of fire leap out. [^19] Out of his nostrils goeth smoke,As out of a seething pot or caldron. [^20] His breath kindleth coals,And a flame goeth out of his mouth. [^21] In his neck remaineth strength,And sorrow is turned into joy before him. [^22] The flakes of his flesh are joined together:They are firm in themselves; they cannot be moved. [^23] His heart is as firm as a stone;Yea, as hard as a piece of the nether millstone. [^24] When he raiseth up himself, the mighty are afraid:By reason of breakings they purify themselves. [^25] The sword of him that layeth at him cannot hold:The spear, the dart, nor the habergeon. [^26] He esteemeth iron as straw,And brass as rotten wood. [^27] The arrow cannot make him flee:Slingstones are turned with him into stubble. [^28] Darts are counted as stubble:He laugheth at the shaking of a spear. [^29] Sharp stones are under him:He spreadeth sharp pointed things upon the mire. [^30] He maketh the deep to boil like a pot:He maketh the sea like a pot of ointment. [^31] He maketh a path to shine after him;One would think the deep to be hoary. [^32] Upon earth there is not his like,Who is made without fear. [^33] He beholdeth all high things:He is a king over all the children of pride. [^34] 

[[Job - 40|<--]] Job - 41 [[Job - 42|-->]]

---
# Notes
