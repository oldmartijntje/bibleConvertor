---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 5 - King James Version"
---
[[Job - 4|<--]] Job - 5 [[Job - 6|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 5

Call now, if there be any that will answer thee;And to which of the saints wilt thou turn? [^1] For wrath killeth the foolish man,And envy slayeth the silly one. [^2] I have seen the foolish taking root:But suddenly I cursed his habitation. [^3] His children are far from safety,And they are crushed in the gate,Neither is there any to deliver them. [^4] Whose harvest the hungry eateth up,And taketh it even out of the thorns,And the robber swalloweth up their substance. [^5] Although affliction cometh not forth of the dust,Neither doth trouble spring out of the ground; [^6] Yet man is born unto trouble,As the sparks fly upward. [^7] I would seek unto God,And unto God would I commit my cause: [^8] Which doeth great things and unsearchable;Marvellous things without number: [^9] Who giveth rain upon the earth,And sendeth waters upon the fields: [^10] To set up on high those that be low;That those which mourn may be exalted to safety. [^11] He disappointeth the devices of the crafty,So that their hands cannot perform their enterprise. [^12] He taketh the wise in their own craftiness:And the counsel of the froward is carried headlong. [^13] They meet with darkness in the daytime,And grope in the noonday as in the night. [^14] But he saveth the poor from the sword, from their mouth,And from the hand of the mighty. [^15] So the poor hath hope,And iniquity stoppeth her mouth. [^16] Behold, happy is the man whom God correcteth:Therefore despise not thou the chastening of the Almighty: [^17] For he maketh sore, and bindeth up:He woundeth, and his hands make whole. [^18] He shall deliver thee in six troubles:Yea, in seven there shall no evil touch thee. [^19] In famine he shall redeem thee from death:And in war from the power of the sword. [^20] Thou shalt be hid from the scourge of the tongue:Neither shalt thou be afraid of destruction when it cometh. [^21] At destruction and famine thou shalt laugh:Neither shalt thou be afraid of the beasts of the earth. [^22] For thou shalt be in league with the stones of the field:And the beasts of the field shall be at peace with thee. [^23] And thou shalt know that thy tabernacle shall be in peace;And thou shalt visit thy habitation, and shalt not sin. [^24] Thou shalt know also that thy seed shall be great,And thine offspring as the grass of the earth. [^25] Thou shalt come to thy grave in a full age,Like as a shock of corn cometh in in his season. [^26] Lo this, we have searched it, so it is;Hear it, and know thou it for thy good. [^27] 

[[Job - 4|<--]] Job - 5 [[Job - 6|-->]]

---
# Notes
