---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/job"
  - "#bible/testament/old"
aliases:
  - "Job - 15 - King James Version"
---
[[Job - 14|<--]] Job - 15 [[Job - 16|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Job]]

# Job - 15

Then answered Eliphaz the Temanite, and said, [^1] Should a wise man utter vain knowledge,And fill his belly with the east wind? [^2] Should he reason with unprofitable talk?Or with speeches wherewith he can do no good? [^3] Yea, thou castest off fear,And restrainest prayer before God. [^4] For thy mouth uttereth thine iniquity,And thou choosest the tongue of the crafty. [^5] Thine own mouth condemneth thee, and not I:Yea, thine own lips testify against thee. [^6] Art thou the first man that was born?Or wast thou made before the hills? [^7] Hast thou heard the secret of God?And dost thou restrain wisdom to thyself? [^8] What knowest thou, that we know not?What understandest thou, which is not in us? [^9] With us are both the grayheaded and very aged men,Much elder than thy father. [^10] Are the consolations of God small with thee?Is there any secret thing with thee? [^11] Why doth thine heart carry thee away?And what do thy eyes wink at, [^12] That thou turnest thy spirit against God,And lettest such words go out of thy mouth? [^13] What is man, that he should be clean?And he which is born of a woman, that he should be righteous? [^14] Behold, he putteth no trust in his saints;Yea, the heavens are not clean in his sight. [^15] How much more abominable and filthy is man,Which drinketh iniquity like water? [^16] I will shew thee, hear me;And that which I have seen I will declare; [^17] Which wise men have toldFrom their fathers, and have not hid it: [^18] Unto whom alone the earth was given,And no stranger passed among them. [^19] The wicked man travaileth with pain all his days,And the number of years is hidden to the oppressor. [^20] A dreadful sound is in his ears:In prosperity the destroyer shall come upon him. [^21] He believeth not that he shall return out of darkness,And he is waited for of the sword. [^22] He wandereth abroad for bread, saying, Where is it?He knoweth that the day of darkness is ready at his hand. [^23] Trouble and anguish shall make him afraid;They shall prevail against him, as a king ready to the battle. [^24] For he stretcheth out his hand against God,And strengtheneth himself against the Almighty. [^25] He runneth upon him, even on his neck,Upon the thick bosses of his bucklers: [^26] Because he covereth his face with his fatness,And maketh collops of fat on his flanks. [^27] And he dwelleth in desolate cities,And in houses which no man inhabiteth,Which are ready to become heaps. [^28] He shall not be rich, neither shall his substance continue,Neither shall he prolong the perfection thereof upon the earth. [^29] He shall not depart out of darkness;The flame shall dry up his branches,And by the breath of his mouth shall he go away. [^30] Let not him that is deceived trust in vanity:For vanity shall be his recompence. [^31] It shall be accomplished before his time,And his branch shall not be green. [^32] He shall shake off his unripe grape as the vine,And shall cast off his flower as the olive. [^33] For the congregation of hypocrites shall be desolate,And fire shall consume the tabernacles of bribery. [^34] They conceive mischief, and bring forth vanity,And their belly prepareth deceit. [^35] 

[[Job - 14|<--]] Job - 15 [[Job - 16|-->]]

---
# Notes
