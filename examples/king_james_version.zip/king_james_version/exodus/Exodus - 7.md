---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 7 - King James Version"
---
[[Exodus - 6|<--]] Exodus - 7 [[Exodus - 8|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Exodus]]

# Exodus - 7

And the LORD said unto Moses, See, I have made thee a god to Pharaoh: and Aaron thy brother shall be thy prophet. [^1] Thou shalt speak all that I command thee: and Aaron thy brother shall speak unto Pharaoh, that he send the children of Israel out of his land. [^2] And I will harden Pharaoh's heart, and multiply my signs and my wonders in the land of Egypt. [^3] But Pharaoh shall not hearken unto you, that I may lay my hand upon Egypt, and bring forth mine armies, and my people the children of Israel, out of the land of Egypt by great judgments. [^4] And the Egyptians shall know that I am the LORD, when I stretch forth mine hand upon Egypt, and bring out the children of Israel from among them. [^5] And Moses and Aaron did as the LORD commanded them, so did they. [^6] And Moses was fourscore years old, and Aaron fourscore and three years old, when they spake unto Pharaoh. [^7] And the LORD spake unto Moses and unto Aaron, saying, [^8] When Pharaoh shall speak unto you, saying, Shew a miracle for you: then thou shalt say unto Aaron, Take thy rod, and cast it before Pharaoh, and it shall become a serpent. [^9] And Moses and Aaron went in unto Pharaoh, and they did so as the LORD had commanded: and Aaron cast down his rod before Pharaoh, and before his servants, and it became a serpent. [^10] Then Pharaoh also called the wise men and the sorcerers: now the magicians of Egypt, they also did in like manner with their enchantments. [^11] For they cast down every man his rod, and they became serpents: but Aaron's rod swallowed up their rods. [^12] And he hardened Pharaoh's heart, that he hearkened not unto them; as the LORD had said. [^13] And the LORD said unto Moses, Pharaoh's heart is hardened, he refuseth to let the people go. [^14] Get thee unto Pharaoh in the morning; lo, he goeth out unto the water; and thou shalt stand by the river's brink against he come; and the rod which was turned to a serpent shalt thou take in thine hand. [^15] And thou shalt say unto him, The LORD God of the Hebrews hath sent me unto thee, saying, Let my people go, that they may serve me in the wilderness: and, behold, hitherto thou wouldest not hear. [^16] Thus saith the LORD, In this thou shalt know that I am the LORD: behold, I will smite with the rod that is in mine hand upon the waters which are in the river, and they shall be turned to blood. [^17] And the fish that is in the river shall die, and the river shall stink; and the Egyptians shall lothe to drink of the water of the river. [^18] And the LORD spake unto Moses, Say unto Aaron, Take thy rod, and stretch out thine hand upon the waters of Egypt, upon their streams, upon their rivers, and upon their ponds, and upon all their pools of water, that they may become blood; and that there may be blood throughout all the land of Egypt, both in vessels of wood, and in vessels of stone. [^19] And Moses and Aaron did so, as the LORD commanded; and he lifted up the rod, and smote the waters that were in the river, in the sight of Pharaoh, and in the sight of his servants; and all the waters that were in the river were turned to blood. [^20] And the fish that was in the river died; and the river stank, and the Egyptians could not drink of the water of the river; and there was blood throughout all the land of Egypt. [^21] And the magicians of Egypt did so with their enchantments: and Pharaoh's heart was hardened, neither did he hearken unto them; as the LORD had said. [^22] And Pharaoh turned and went into his house, neither did he set his heart to this also. [^23] And all the Egyptians digged round about the river for water to drink; for they could not drink of the water of the river. [^24] And seven days were fulfilled, after that the LORD had smitten the river. [^25] 

[[Exodus - 6|<--]] Exodus - 7 [[Exodus - 8|-->]]

---
# Notes
