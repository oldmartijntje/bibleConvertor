---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 17 - King James Version"
---
[[Exodus - 16|<--]] Exodus - 17 [[Exodus - 18|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Exodus]]

# Exodus - 17

And all the congregation of the children of Israel journeyed from the wilderness of Sin, after their journeys, according to the commandment of the LORD, and pitched in Rephidim: and there was no water for the people to drink. [^1] Wherefore the people did chide with Moses, and said, Give us water that we may drink. And Moses said unto them, Why chide ye with me? wherefore do ye tempt the LORD? [^2] And the people thirsted there for water; and the people murmured against Moses, and said, Wherefore is this that thou hast brought us up out of Egypt, to kill us and our children and our cattle with thirst? [^3] And Moses cried unto the LORD, saying, What shall I do unto this people? they be almost ready to stone me. [^4] And the LORD said unto Moses, Go on before the people, and take with thee of the elders of Israel; and thy rod, wherewith thou smotest the river, take in thine hand, and go. [^5] Behold, I will stand before thee there upon the rock in Horeb; and thou shalt smite the rock, and there shall come water out of it, that the people may drink. And Moses did so in the sight of the elders of Israel. [^6] And he called the name of the place Massah, and Meribah, because of the chiding of the children of Israel, and because they tempted the LORD, saying, Is the LORD among us, or not? [^7] Then came Amalek, and fought with Israel in Rephidim. [^8] And Moses said unto Joshua, Choose us out men, and go out, fight with Amalek: to morrow I will stand on the top of the hill with the rod of God in mine hand. [^9] So Joshua did as Moses had said to him, and fought with Amalek: and Moses, Aaron, and Hur went up to the top of the hill. [^10] And it came to pass, when Moses held up his hand, that Israel prevailed: and when he let down his hand, Amalek prevailed. [^11] But Moses' hands were heavy; and they took a stone, and put it under him, and he sat thereon; and Aaron and Hur stayed up his hands, the one on the one side, and the other on the other side; and his hands were steady until the going down of the sun. [^12] And Joshua discomfited Amalek and his people with the edge of the sword. [^13] And the LORD said unto Moses, Write this for a memorial in a book, and rehearse it in the ears of Joshua: for I will utterly put out the remembrance of Amalek from under heaven. [^14] And Moses built an altar, and called the name of it Jehovah-nissi: [^15] for he said, Because the LORD hath sworn that the LORD  will have war with Amalek from generation to generation. [^16] 

[[Exodus - 16|<--]] Exodus - 17 [[Exodus - 18|-->]]

---
# Notes
