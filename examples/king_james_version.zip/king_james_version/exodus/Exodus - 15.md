---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 15 - King James Version"
---
[[Exodus - 14|<--]] Exodus - 15 [[Exodus - 16|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Exodus]]

# Exodus - 15

Then sang Moses and the children of Israel this song unto the LORD, and spake, saying,I will sing unto the LORD, for he hath triumphed gloriously:The horse and his rider hath he thrown into the sea. [^1] The LORD  is my strength and song,And he is become my salvation:He is my God, and I will prepare him an habitation;My father's God, and I will exalt him. [^2] The LORD  is a man of war:The LORD  is his name. [^3] Pharaoh's chariots and his host hath he cast into the sea:His chosen captains also are drowned in the Red sea. [^4] The depths have covered them:They sank into the bottom as a stone. [^5] Thy right hand, O LORD, is become glorious in power:Thy right hand, O LORD, hath dashed in pieces the enemy. [^6] And in the greatness of thine excellency thou hast overthrown them that rose up against thee:Thou sentest forth thy wrath, which consumed them as stubble. [^7] And with the blast of thy nostrils the waters were gathered together,The floods stood upright as an heap,And the depths were congealed in the heart of the sea. [^8] The enemy said,I will pursue, I will overtake, I will divide the spoil;My lust shall be satisfied upon them;I will draw my sword, my hand shall destroy them. [^9] Thou didst blow with thy wind, the sea covered them:They sank as lead in the mighty waters. [^10] Who is like unto thee, O LORD, among the gods?Who is like thee, glorious in holiness,Fearful in praises, doing wonders? [^11] Thou stretchedst out thy right hand,The earth swallowed them. [^12] Thou in thy mercy hast led forth the people which thou hast redeemed:Thou hast guided them in thy strength unto thy holy habitation. [^13] The people shall hear, and be afraid:Sorrow shall take hold on the inhabitants of Palestina. [^14] Then the dukes of Edom shall be amazed;The mighty men of Moab, trembling shall take hold upon them;All the inhabitants of Canaan shall melt away. [^15] Fear and dread shall fall upon them;By the greatness of thine arm they shall be as still as a stone;Till thy people pass over, O LORD,Till the people pass over, which thou hast purchased. [^16] Thou shalt bring them in, and plant them in the mountain of thine inheritance,In the place, O LORD, which thou hast made for thee to dwell in,In the sanctuary, O LORD, which thy hands have established. [^17] The LORD shall reign for ever and ever. [^18] For the horse of Pharaoh went in with his chariots and with his horsemen into the sea, and the LORD brought again the waters of the sea upon them; but the children of Israel went on dry land in the midst of the sea. [^19] And Miriam the prophetess, the sister of Aaron, took a timbrel in her hand; and all the women went out after her with timbrels and with dances. [^20] And Miriam answered them,Sing ye to the LORD, for he hath triumphed gloriously:The horse and his rider hath he thrown into the sea. [^21] So Moses brought Israel from the Red sea, and they went out into the wilderness of Shur; and they went three days in the wilderness, and found no water. [^22] And when they came to Marah, they could not drink of the waters of Marah, for they were bitter: therefore the name of it was called Marah. [^23] And the people murmured against Moses, saying, What shall we drink? [^24] And he cried unto the LORD; and the LORD shewed him a tree, which when he had cast into the waters, the waters were made sweet: there he made for them a statute and an ordinance, and there he proved them, [^25] and said, If thou wilt diligently hearken to the voice of the LORD thy God, and wilt do that which is right in his sight, and wilt give ear to his commandments, and keep all his statutes, I will put none of these diseases upon thee, which I have brought upon the Egyptians: for I am the LORD that healeth thee. [^26] And they came to Elim, where were twelve wells of water, and threescore and ten palm trees: and they encamped there by the waters. [^27] 

[[Exodus - 14|<--]] Exodus - 15 [[Exodus - 16|-->]]

---
# Notes
