---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 11 - King James Version"
---
[[Exodus - 10|<--]] Exodus - 11 [[Exodus - 12|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Exodus]]

# Exodus - 11

And the LORD said unto Moses, Yet will I bring one plague more upon Pharaoh, and upon Egypt; afterwards he will let you go hence: when he shall let you go, he shall surely thrust you out hence altogether. [^1] Speak now in the ears of the people, and let every man borrow of his neighbour, and every woman of her neighbour, jewels of silver, and jewels of gold. [^2] And the LORD gave the people favour in the sight of the Egyptians. Moreover the man Moses was very great in the land of Egypt, in the sight of Pharaoh's servants, and in the sight of the people. [^3] And Moses said, Thus saith the LORD, About midnight will I go out into the midst of Egypt: [^4] and all the firstborn in the land of Egypt shall die, from the firstborn of Pharaoh that sitteth upon his throne, even unto the firstborn of the maidservant that is behind the mill; and all the firstborn of beasts. [^5] And there shall be a great cry throughout all the land of Egypt, such as there was none like it, nor shall be like it any more. [^6] But against any of the children of Israel shall not a dog move his tongue, against man or beast: that ye may know how that the LORD doth put a difference between the Egyptians and Israel. [^7] And all these thy servants shall come down unto me, and bow down themselves unto me, saying, Get thee out, and all the people that follow thee: and after that I will go out. And he went out from Pharaoh in a great anger. [^8] And the LORD said unto Moses, Pharaoh shall not hearken unto you; that my wonders may be multiplied in the land of Egypt. [^9] And Moses and Aaron did all these wonders before Pharaoh: and the LORD hardened Pharaoh's heart, so that he would not let the children of Israel go out of his land. [^10] 

[[Exodus - 10|<--]] Exodus - 11 [[Exodus - 12|-->]]

---
# Notes
