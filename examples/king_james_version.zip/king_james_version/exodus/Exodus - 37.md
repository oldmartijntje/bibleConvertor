---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 37 - King James Version"
---
[[Exodus - 36|<--]] Exodus - 37 [[Exodus - 38|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Exodus]]

# Exodus - 37

And Bezaleel made the ark of shittim wood: two cubits and a half was the length of it, and a cubit and a half the breadth of it, and a cubit and a half the height of it: [^1] and he overlaid it with pure gold within and without, and made a crown of gold to it round about. [^2] And he cast for it four rings of gold, to be set by the four corners of it; even two rings upon the one side of it, and two rings upon the other side of it. [^3] And he made staves of shittim wood, and overlaid them with gold. [^4] And he put the staves into the rings by the sides of the ark, to bear the ark. [^5] And he made the mercy seat of pure gold: two cubits and a half was the length thereof, and one cubit and a half the breadth thereof. [^6] And he made two cherubims of gold, beaten out of one piece made he them, on the two ends of the mercy seat; [^7] one cherub on the end on this side, and another cherub on the other end on that side: out of the mercy seat made he the cherubims on the two ends thereof. [^8] And the cherubims spread out their wings on high, and covered with their wings over the mercy seat, with their faces one to another; even to the mercy seatward were the faces of the cherubims. [^9] And he made the table of shittim wood: two cubits was the length thereof, and a cubit the breadth thereof, and a cubit and a half the height thereof: [^10] and he overlaid it with pure gold, and made thereunto a crown of gold round about. [^11] Also he made thereunto a border of an handbreadth round about; and made a crown of gold for the border thereof round about. [^12] And he cast for it four rings of gold, and put the rings upon the four corners that were in the four feet thereof. [^13] Over against the border were the rings, the places for the staves to bear the table. [^14] And he made the staves of shittim wood, and overlaid them with gold, to bear the table. [^15] And he made the vessels which were upon the table, his dishes, and his spoons, and his bowls, and his covers to cover withal, of pure gold. [^16] And he made the candlestick of pure gold: of beaten work made he the candlestick; his shaft, and his branch, his bowls, his knops, and his flowers, were of the same: [^17] and six branches going out of the sides thereof; three branches of the candlestick out of the one side thereof, and three branches of the candlestick out of the other side thereof: [^18] three bowls made after the fashion of almonds in one branch, a knop and a flower; and three bowls made like almonds in another branch, a knop and a flower: so throughout the six branches going out of the candlestick. [^19] And in the candlestick were four bowls made like almonds, his knops, and his flowers: [^20] and a knop under two branches of the same, and a knop under two branches of the same, and a knop under two branches of the same, according to the six branches going out of it. [^21] Their knops and their branches were of the same: all of it was one beaten work of pure gold. [^22] And he made his seven lamps, and his snuffers, and his snuffdishes, of pure gold. [^23] Of a talent of pure gold made he it, and all the vessels thereof. [^24] And he made the incense altar of shittim wood: the length of it was a cubit, and the breadth of it a cubit; it was foursquare; and two cubits was the height of it; the horns thereof were of the same. [^25] And he overlaid it with pure gold, both the top of it, and the sides thereof round about, and the horns of it: also he made unto it a crown of gold round about. [^26] And he made two rings of gold for it under the crown thereof, by the two corners of it, upon the two sides thereof, to be places for the staves to bear it withal. [^27] And he made the staves of shittim wood, and overlaid them with gold. [^28] And he made the holy anointing oil, and the pure incense of sweet spices, according to the work of the apothecary. [^29] 

[[Exodus - 36|<--]] Exodus - 37 [[Exodus - 38|-->]]

---
# Notes
