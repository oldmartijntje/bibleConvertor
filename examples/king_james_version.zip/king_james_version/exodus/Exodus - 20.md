---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 20 - King James Version"
---
[[Exodus - 19|<--]] Exodus - 20 [[Exodus - 21|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Exodus]]

# Exodus - 20

And God spake all these words, saying, [^1] I am the LORD thy God, which have brought thee out of the land of Egypt, out of the house of bondage. [^2] Thou shalt have no other gods before me. [^3] Thou shalt not make unto thee any graven image, or any likeness of any thing that is in heaven above, or that is in the earth beneath, or that is in the water under the earth: [^4] thou shalt not bow down thyself to them, nor serve them: for I the LORD thy God am a jealous God, visiting the iniquity of the fathers upon the children unto the third and fourth generation of them that hate me; [^5] and shewing mercy unto thousands of them that love me, and keep my commandments. [^6] Thou shalt not take the name of the LORD thy God in vain; for the LORD will not hold him guiltless that taketh his name in vain. [^7] Remember the sabbath day, to keep it holy. [^8] Six days shalt thou labour, and do all thy work: [^9] but the seventh day is the sabbath of the LORD thy God: in it thou shalt not do any work, thou, nor thy son, nor thy daughter, thy manservant, nor thy maidservant, nor thy cattle, nor thy stranger that is within thy gates: [^10] for in six days the LORD made heaven and earth, the sea, and all that in them is, and rested the seventh day: wherefore the LORD blessed the sabbath day, and hallowed it. [^11] Honour thy father and thy mother: that thy days may be long upon the land which the LORD thy God giveth thee. [^12] Thou shalt not kill. [^13] Thou shalt not commit adultery. [^14] Thou shalt not steal. [^15] Thou shalt not bear false witness against thy neighbour. [^16] Thou shalt not covet thy neighbour's house, thou shalt not covet thy neighbour's wife, nor his manservant, nor his maidservant, nor his ox, nor his ass, nor any thing that is thy neighbour's. [^17] And all the people saw the thunderings, and the lightnings, and the noise of the trumpet, and the mountain smoking: and when the people saw it, they removed, and stood afar off. [^18] And they said unto Moses, Speak thou with us, and we will hear: but let not God speak with us, lest we die. [^19] And Moses said unto the people, Fear not: for God is come to prove you, and that his fear may be before your faces, that ye sin not. [^20] And the people stood afar off, and Moses drew near unto the thick darkness where God was. [^21] And the LORD said unto Moses, Thus thou shalt say unto the children of Israel, Ye have seen that I have talked with you from heaven. [^22] Ye shall not make with me gods of silver, neither shall ye make unto you gods of gold. [^23] An altar of earth thou shalt make unto me, and shalt sacrifice thereon thy burnt offerings, and thy peace offerings, thy sheep, and thine oxen: in all places where I record my name I will come unto thee, and I will bless thee. [^24] And if thou wilt make me an altar of stone, thou shalt not build it of hewn stone: for if thou lift up thy tool upon it, thou hast polluted it. [^25] Neither shalt thou go up by steps unto mine altar, that thy nakedness be not discovered thereon. [^26] 

[[Exodus - 19|<--]] Exodus - 20 [[Exodus - 21|-->]]

---
# Notes
