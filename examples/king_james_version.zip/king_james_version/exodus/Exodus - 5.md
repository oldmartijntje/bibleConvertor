---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 5 - King James Version"
---
[[Exodus - 4|<--]] Exodus - 5 [[Exodus - 6|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Exodus]]

# Exodus - 5

And afterward Moses and Aaron went in, and told Pharaoh, Thus saith the LORD God of Israel, Let my people go, that they may hold a feast unto me in the wilderness. [^1] And Pharaoh said, Who is the LORD, that I should obey his voice to let Israel go? I know not the LORD, neither will I let Israel go. [^2] And they said, The God of the Hebrews hath met with us: let us go, we pray thee, three days' journey into the desert, and sacrifice unto the LORD our God; lest he fall upon us with pestilence, or with the sword. [^3] And the king of Egypt said unto them, Wherefore do ye, Moses and Aaron, let the people from their works? get you unto your burdens. [^4] And Pharaoh said, Behold, the people of the land now are many, and ye make them rest from their burdens. [^5] And Pharaoh commanded the same day the taskmasters of the people, and their officers, saying, [^6] Ye shall no more give the people straw to make brick, as heretofore: let them go and gather straw for themselves. [^7] And the tale of the bricks, which they did make heretofore, ye shall lay upon them; ye shall not diminish ought thereof: for they be idle; therefore they cry, saying, Let us go and sacrifice to our God. [^8] Let there more work be laid upon the men, that they may labour therein; and let them not regard vain words. [^9] And the taskmasters of the people went out, and their officers, and they spake to the people, saying, Thus saith Pharaoh, I will not give you straw. [^10] Go ye, get you straw where ye can find it: yet not ought of your work shall be diminished. [^11] So the people were scattered abroad throughout all the land of Egypt to gather stubble instead of straw. [^12] And the taskmasters hasted them, saying, Fulfil your works, your daily tasks, as when there was straw. [^13] And the officers of the children of Israel, which Pharaoh's taskmasters had set over them, were beaten, and demanded, Wherefore have ye not fulfilled your task in making brick both yesterday and to day, as heretofore? [^14] Then the officers of the children of Israel came and cried unto Pharaoh, saying, Wherefore dealest thou thus with thy servants? [^15] There is no straw given unto thy servants, and they say to us, Make brick: and, behold, thy servants are beaten; but the fault is in thine own people. [^16] But he said, Ye are idle, ye are idle: therefore ye say, Let us go and do sacrifice to the LORD. [^17] Go therefore now, and work; for there shall no straw be given you, yet shall ye deliver the tale of bricks. [^18] And the officers of the children of Israel did see that they were in evil case, after it was said, Ye shall not minish ought from your bricks of your daily task. [^19] And they met Moses and Aaron, who stood in the way, as they came forth from Pharaoh: [^20] and they said unto them, The LORD look upon you, and judge; because ye have made our savour to be abhorred in the eyes of Pharaoh, and in the eyes of his servants, to put a sword in their hand to slay us. [^21] And Moses returned unto the LORD, and said, Lord, wherefore hast thou so evil entreated this people? why is it that thou hast sent me? [^22] For since I came to Pharaoh to speak in thy name, he hath done evil to this people; neither hast thou delivered thy people at all. [^23] 

[[Exodus - 4|<--]] Exodus - 5 [[Exodus - 6|-->]]

---
# Notes
