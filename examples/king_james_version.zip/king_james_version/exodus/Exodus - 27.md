---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/exodus"
  - "#bible/testament/old"
aliases:
  - "Exodus - 27 - King James Version"
---
[[Exodus - 26|<--]] Exodus - 27 [[Exodus - 28|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Exodus]]

# Exodus - 27

And thou shalt make an altar of shittim wood, five cubits long, and five cubits broad; the altar shall be foursquare: and the height thereof shall be three cubits. [^1] And thou shalt make the horns of it upon the four corners thereof: his horns shall be of the same: and thou shalt overlay it with brass. [^2] And thou shalt make his pans to receive his ashes, and his shovels, and his basons, and his fleshhooks, and his firepans: all the vessels thereof thou shalt make of brass. [^3] And thou shalt make for it a grate of network of brass; and upon the net shalt thou make four brasen rings in the four corners thereof. [^4] And thou shalt put it under the compass of the altar beneath, that the net may be even to the midst of the altar. [^5] And thou shalt make staves for the altar, staves of shittim wood, and overlay them with brass. [^6] And the staves shall be put into the rings, and the staves shall be upon the two sides of the altar, to bear it. [^7] Hollow with boards shalt thou make it: as it was shewed thee in the mount, so shall they make it. [^8] And thou shalt make the court of the tabernacle: for the south side southward there shall be hangings for the court of fine twined linen of an hundred cubits long for one side: [^9] and the twenty pillars thereof and their twenty sockets shall be of brass; the hooks of the pillars and their fillets shall be of silver. [^10] And likewise for the north side in length there shall be hangings of an hundred cubits long, and his twenty pillars and their twenty sockets of brass; the hooks of the pillars and their fillets of silver. [^11] And for the breadth of the court on the west side shall be hangings of fifty cubits: their pillars ten, and their sockets ten. [^12] And the breadth of the court on the east side eastward shall be fifty cubits. [^13] The hangings of one side of the gate shall be fifteen cubits: their pillars three, and their sockets three. [^14] And on the other side shall be hangings fifteen cubits: their pillars three, and their sockets three. [^15] And for the gate of the court shall be an hanging of twenty cubits, of blue, and purple, and scarlet, and fine twined linen, wrought with needlework: and their pillars shall be four, and their sockets four. [^16] All the pillars round about the court shall be filleted with silver; their hooks shall be of silver, and their sockets of brass. [^17] The length of the court shall be an hundred cubits, and the breadth fifty every where, and the height five cubits of fine twined linen, and their sockets of brass. [^18] All the vessels of the tabernacle in all the service thereof, and all the pins thereof, and all the pins of the court, shall be of brass. [^19] And thou shalt command the children of Israel, that they bring thee pure oil olive beaten for the light, to cause the lamp to burn always. [^20] In the tabernacle of the congregation without the vail, which is before the testimony, Aaron and his sons shall order it from evening to morning before the LORD: it shall be a statute for ever unto their generations on the behalf of the children of Israel. [^21] 

[[Exodus - 26|<--]] Exodus - 27 [[Exodus - 28|-->]]

---
# Notes
