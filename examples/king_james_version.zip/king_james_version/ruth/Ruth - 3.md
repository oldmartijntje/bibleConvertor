---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/ruth"
  - "#bible/testament/old"
aliases:
  - "Ruth - 3 - King James Version"
---
[[Ruth - 2|<--]] Ruth - 3 [[Ruth - 4|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Ruth]]

# Ruth - 3

Then Naomi her mother in law said unto her, My daughter, shall I not seek rest for thee, that it may be well with thee? [^1] And now is not Boaz of our kindred, with whose maidens thou wast? Behold, he winnoweth barley to night in the threshingfloor. [^2] Wash thyself therefore, and anoint thee, and put thy raiment upon thee, and get thee down to the floor: but make not thyself known unto the man, until he shall have done eating and drinking. [^3] And it shall be, when he lieth down, that thou shalt mark the place where he shall lie, and thou shalt go in, and uncover his feet, and lay thee down; and he will tell thee what thou shalt do. [^4] And she said unto her, All that thou sayest unto me I will do. [^5] And she went down unto the floor, and did according to all that her mother in law bade her. [^6] And when Boaz had eaten and drunk, and his heart was merry, he went to lie down at the end of the heap of corn: and she came softly, and uncovered his feet, and laid her down. [^7] And it came to pass at midnight, that the man was afraid, and turned himself: and, behold, a woman lay at his feet. [^8] And he said, Who art thou? And she answered, I am Ruth thine handmaid: spread therefore thy skirt over thine handmaid; for thou art a near kinsman. [^9] And he said, Blessed be thou of the LORD, my daughter: for thou hast shewed more kindness in the latter end than at the beginning, inasmuch as thou followedst not young men, whether poor or rich. [^10] And now, my daughter, fear not; I will do to thee all that thou requirest: for all the city of my people doth know that thou art a virtuous woman. [^11] And now it is true that I am thy near kinsman: howbeit there is a kinsman nearer than I. [^12] Tarry this night, and it shall be in the morning, that if he will perform unto thee the part of a kinsman, well; let him do the kinsman's part: but if he will not do the part of a kinsman to thee, then will I do the part of a kinsman to thee, as the LORD liveth: lie down until the morning. [^13] And she lay at his feet until the morning: and she rose up before one could know another. And he said, Let it not be known that a woman came into the floor. [^14] Also he said, Bring the vail that thou hast upon thee, and hold it. And when she held it, he measured six measures of barley, and laid it on her: and she went into the city. [^15] And when she came to her mother in law, she said, Who art thou, my daughter? And she told her all that the man had done to her. [^16] And she said, These six measures of barley gave he me; for he said to me, Go not empty unto thy mother in law. [^17] Then said she, Sit still, my daughter, until thou know how the matter will fall: for the man will not be in rest, until he have finished the thing this day. [^18] 

[[Ruth - 2|<--]] Ruth - 3 [[Ruth - 4|-->]]

---
# Notes
