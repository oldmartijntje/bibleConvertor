---
translation: King James Version
aliases:
  - "Ruth - King James Version"
tags:
  - "#bible/type/book"
  - "#bible/book/ruth"
  - "#bible/testament/old"
---
[[Judges|<--]] Ruth [[1 Samuel|-->]]

# Ruth - King James Version

The Ruth book has 4 chapters. It is part of the old testament.

## Chapters

- Ruth [[Ruth - 1|chapter 1]]
- Ruth [[Ruth - 2|chapter 2]]
- Ruth [[Ruth - 3|chapter 3]]
- Ruth [[Ruth - 4|chapter 4]]

[[Judges|<--]] Ruth [[1 Samuel|-->]]

---
# Notes
