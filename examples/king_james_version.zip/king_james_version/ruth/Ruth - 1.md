---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/ruth"
  - "#bible/testament/old"
aliases:
  - "Ruth - 1 - King James Version"
---
Ruth - 1 [[Ruth - 2|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Ruth]]

# Ruth - 1

Now it came to pass in the days when the judges ruled, that there was a famine in the land. And a certain man of Beth-lehem-judah went to sojourn in the country of Moab, he, and his wife, and his two sons. [^1] And the name of the man was Elimelech, and the name of his wife Naomi, and the name of his two sons Mahlon and Chilion, Ephrathites of Beth-lehem-judah. And they came into the country of Moab, and continued there. [^2] And Elimelech Naomi's husband died; and she was left, and her two sons. [^3] And they took them wives of the women of Moab; the name of the one was Orpah, and the name of the other Ruth: and they dwelled there about ten years. [^4] And Mahlon and Chilion died also both of them; and the woman was left of her two sons and her husband. [^5] Then she arose with her daughters in law, that she might return from the country of Moab: for she had heard in the country of Moab how that the LORD had visited his people in giving them bread. [^6] Wherefore she went forth out of the place where she was, and her two daughters in law with her; and they went on the way to return unto the land of Judah. [^7] And Naomi said unto her two daughters in law, Go, return each to her mother's house: the LORD deal kindly with you, as ye have dealt with the dead, and with me. [^8] The LORD grant you that ye may find rest, each of you in the house of her husband. Then she kissed them; and they lifted up their voice, and wept. [^9] And they said unto her, Surely we will return with thee unto thy people. [^10] And Naomi said, Turn again, my daughters: why will ye go with me? are there yet any more sons in my womb, that they may be your husbands? [^11] Turn again, my daughters, go your way; for I am too old to have an husband. If I should say, I have hope, if I should have an husband also to night, and should also bear sons; [^12] would ye tarry for them till they were grown? would ye stay for them from having husbands? nay, my daughters; for it grieveth me much for your sakes that the hand of the LORD is gone out against me. [^13] And they lifted up their voice, and wept again: and Orpah kissed her mother in law; but Ruth clave unto her. [^14] And she said, Behold, thy sister in law is gone back unto her people, and unto her gods: return thou after thy sister in law. [^15] And Ruth said, Intreat me not to leave thee, or to return from following after thee: for whither thou goest, I will go; and where thou lodgest, I will lodge: thy people shall be my people, and thy God my God: [^16] where thou diest, will I die, and there will I be buried: the LORD do so to me, and more also, if ought but death part thee and me. [^17] When she saw that she was stedfastly minded to go with her, then she left speaking unto her. [^18] So they two went until they came to Beth-lehem. And it came to pass, when they were come to Beth-lehem, that all the city was moved about them, and they said, Is this Naomi? [^19] And she said unto them, Call me not Naomi, call me Mara: for the Almighty hath dealt very bitterly with me. [^20] I went out full, and the LORD hath brought me home again empty: why then call ye me Naomi, seeing the LORD hath testified against me, and the Almighty hath afflicted me? [^21] So Naomi returned, and Ruth the Moabitess, her daughter in law, with her, which returned out of the country of Moab: and they came to Beth-lehem in the beginning of barley harvest. [^22] 

Ruth - 1 [[Ruth - 2|-->]]

---
# Notes
