---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 12 - King James Version"
---
[[2 Kings - 11|<--]] 2 Kings - 12 [[2 Kings - 13|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[2 Kings]]

# 2 Kings - 12

In the seventh year of Jehu Jehoash began to reign; and forty years reigned he in Jerusalem. And his mother's name was Zibiah of Beer-sheba. [^1] And Jehoash did that which was right in the sight of the LORD all his days wherein Jehoiada the priest instructed him. [^2] But the high places were not taken away: the people still sacrificed and burnt incense in the high places. [^3] And Jehoash said to the priests, All the money of the dedicated things that is brought into the house of the LORD, even the money of every one that passeth the account, the money that every man is set at, and all the money that cometh into any man's heart to bring into the house of the LORD, [^4] let the priests take it to them, every man of his acquaintance: and let them repair the breaches of the house, wheresoever any breach shall be found. [^5] But it was so, that in the three and twentieth year of king Jehoash the priests had not repaired the breaches of the house. [^6] Then king Jehoash called for Jehoiada the priest, and the other priests, and said unto them, Why repair ye not the breaches of the house? now therefore receive no more money of your acquaintance, but deliver it for the breaches of the house. [^7] And the priests consented to receive no more money of the people, neither to repair the breaches of the house. [^8] But Jehoiada the priest took a chest, and bored a hole in the lid of it, and set it beside the altar, on the right side as one cometh into the house of the LORD: and the priests that kept the door put therein all the money that was brought into the house of the LORD. [^9] And it was so, when they saw that there was much money in the chest, that the king's scribe and the high priest came up, and they put up in bags, and told the money that was found in the house of the LORD. [^10] And they gave the money, being told, into the hands of them that did the work, that had the oversight of the house of the LORD: and they laid it out to the carpenters and builders, that wrought upon the house of the LORD, [^11] and to masons, and hewers of stone, and to buy timber and hewed stone to repair the breaches of the house of the LORD, and for all that was laid out for the house to repair it. [^12] Howbeit there were not made for the house of the LORD bowls of silver, snuffers, basons, trumpets, any vessels of gold, or vessels of silver, of the money that was brought into the house of the LORD: [^13] but they gave that to the workmen, and repaired therewith the house of the LORD. [^14] Moreover they reckoned not with the men, into whose hand they delivered the money to be bestowed on workmen: for they dealt faithfully. [^15] The trespass money and sin money was not brought into the house of the LORD: it was the priests'. [^16] Then Hazael king of Syria went up, and fought against Gath, and took it: and Hazael set his face to go up to Jerusalem. [^17] And Jehoash king of Judah took all the hallowed things that Jehoshaphat, and Jehoram, and Ahaziah, his fathers, kings of Judah, had dedicated, and his own hallowed things, and all the gold that was found in the treasures of the house of the LORD, and in the king's house, and sent it to Hazael king of Syria: and he went away from Jerusalem. [^18] And the rest of the acts of Joash, and all that he did, are they not written in the book of the chronicles of the kings of Judah? [^19] And his servants arose, and made a conspiracy, and slew Joash in the house of Millo, which goeth down to Silla. [^20] For Jozachar the son of Shimeath, and Jehozabad the son of Shomer, his servants, smote him, and he died; and they buried him with his fathers in the city of David: and Amaziah his son reigned in his stead. [^21] 

[[2 Kings - 11|<--]] 2 Kings - 12 [[2 Kings - 13|-->]]

---
# Notes
