---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_kings"
  - "#bible/testament/old"
aliases:
  - "2 Kings - 11 - King James Version"
---
[[2 Kings - 10|<--]] 2 Kings - 11 [[2 Kings - 12|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[2 Kings]]

# 2 Kings - 11

And when Athaliah the mother of Ahaziah saw that her son was dead, she arose and destroyed all the seed royal. [^1] But Jehosheba, the daughter of king Joram, sister of Ahaziah, took Joash the son of Ahaziah, and stole him from among the king's sons which were slain; and they hid him, even him and his nurse, in the bedchamber from Athaliah, so that he was not slain. [^2] And he was with her hid in the house of the LORD six years. And Athaliah did reign over the land. [^3] And the seventh year Jehoiada sent and fetched the rulers over hundreds, with the captains and the guard, and brought them to him into the house of the LORD, and made a covenant with them, and took an oath of them in the house of the LORD, and shewed them the king's son. [^4] And he commanded them, saying, This is the thing that ye shall do; A third part of you that enter in on the sabbath shall even be keepers of the watch of the king's house; [^5] and a third part shall be at the gate of Sur; and a third part at the gate behind the guard: so shall ye keep the watch of the house, that it be not broken down. [^6] And two parts of all you that go forth on the sabbath, even they shall keep the watch of the house of the LORD about the king. [^7] And ye shall compass the king round about, every man with his weapons in his hand: and he that cometh within the ranges, let him be slain: and be ye with the king as he goeth out and as he cometh in. [^8] And the captains over the hundreds did according to all things that Jehoiada the priest commanded: and they took every man his men that were to come in on the sabbath, with them that should go out on the sabbath, and came to Jehoiada the priest. [^9] And to the captains over hundreds did the priest give king David's spears and shields, that were in the temple of the LORD. [^10] And the guard stood, every man with his weapons in his hand, round about the king, from the right corner of the temple to the left corner of the temple, along by the altar and the temple. [^11] And he brought forth the king's son, and put the crown upon him, and gave him the testimony; and they made him king, and anointed him; and they clapped their hands, and said, God save the king. [^12] And when Athaliah heard the noise of the guard and of the people, she came to the people into the temple of the LORD. [^13] And when she looked, behold, the king stood by a pillar, as the manner was, and the princes and the trumpeters by the king, and all the people of the land rejoiced, and blew with trumpets: and Athaliah rent her clothes, and cried, Treason, Treason. [^14] But Jehoiada the priest commanded the captains of the hundreds, the officers of the host, and said unto them, Have her forth without the ranges: and him that followeth her kill with the sword. For the priest had said, Let her not be slain in the house of the LORD. [^15] And they laid hands on her; and she went by the way by the which the horses came into the king's house: and there was she slain. [^16] And Jehoiada made a covenant between the LORD and the king and the people, that they should be the LORD's people; between the king also and the people. [^17] And all the people of the land went into the house of Baal, and brake it down; his altars and his images brake they in pieces thoroughly, and slew Mattan the priest of Baal before the altars. And the priest appointed officers over the house of the LORD. [^18] And he took the rulers over hundreds, and the captains, and the guard, and all the people of the land; and they brought down the king from the house of the LORD, and came by the way of the gate of the guard to the king's house. And he sat on the throne of the kings. [^19] And all the people of the land rejoiced, and the city was in quiet: and they slew Athaliah with the sword beside the king's house. [^20] Seven years old was Jehoash when he began to reign. [^21] 

[[2 Kings - 10|<--]] 2 Kings - 11 [[2 Kings - 12|-->]]

---
# Notes
