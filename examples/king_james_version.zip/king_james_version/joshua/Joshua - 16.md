---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 16 - King James Version"
---
[[Joshua - 15|<--]] Joshua - 16 [[Joshua - 17|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Joshua]]

# Joshua - 16

And the lot of the children of Joseph fell from Jordan by Jericho, unto the water of Jericho on the east, to the wilderness that goeth up from Jericho throughout mount Beth-el, [^1] and goeth out from Beth-el to Luz, and passeth along unto the borders of Archi to Ataroth, [^2] and goeth down westward to the coast of Japhleti, unto the coast of Beth-horon the nether, and to Gezer: and the goings out thereof are at the sea. [^3] So the children of Joseph, Manasseh and Ephraim, took their inheritance. [^4] And the border of the children of Ephraim according to their families was thus: even the border of their inheritance on the east side was Ataroth-addar, unto Beth-horon the upper; [^5] and the border went out toward the sea to Michmethah on the north side; and the border went about eastward unto Taanath-shiloh, and passed by it on the east to Janohah; [^6] and it went down from Janohah to Ataroth, and to Naarath, and came to Jericho, and went out at Jordan. [^7] The border went out from Tappuah westward unto the river Kanah; and the goings out thereof were at the sea. This is the inheritance of the tribe of the children of Ephraim by their families. [^8] And the separate cities for the children of Ephraim were among the inheritance of the children of Manasseh, all the cities with their villages. [^9] And they drave not out the Canaanites that dwelt in Gezer: but the Canaanites dwell among the Ephraimites unto this day, and serve under tribute. [^10] 

[[Joshua - 15|<--]] Joshua - 16 [[Joshua - 17|-->]]

---
# Notes
