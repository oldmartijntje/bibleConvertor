---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 14 - King James Version"
---
[[Joshua - 13|<--]] Joshua - 14 [[Joshua - 15|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Joshua]]

# Joshua - 14

And these are the countries which the children of Israel inherited in the land of Canaan, which Eleazar the priest, and Joshua the son of Nun, and the heads of the fathers of the tribes of the children of Israel, distributed for inheritance to them. [^1] By lot was their inheritance, as the LORD commanded by the hand of Moses, for the nine tribes, and for the half tribe. [^2] For Moses had given the inheritance of two tribes and an half tribe on the other side Jordan: but unto the Levites he gave none inheritance among them. [^3] For the children of Joseph were two tribes, Manasseh and Ephraim: therefore they gave no part unto the Levites in the land, save cities to dwell in, with their suburbs for their cattle and for their substance. [^4] As the LORD commanded Moses, so the children of Israel did, and they divided the land. [^5] Then the children of Judah came unto Joshua in Gilgal: and Caleb the son of Jephunneh the Kenezite said unto him, Thou knowest the thing that the LORD said unto Moses the man of God concerning me and thee in Kadesh-barnea. [^6] Forty years old was I when Moses the servant of the LORD sent me from Kadesh-barnea to espy out the land; and I brought him word again as it was in mine heart. [^7] Nevertheless my brethren that went up with me made the heart of the people melt: but I wholly followed the LORD my God. [^8] And Moses sware on that day, saying, Surely the land whereon thy feet have trodden shall be thine inheritance, and thy children's for ever, because thou hast wholly followed the LORD my God. [^9] And now, behold, the LORD hath kept me alive, as he said, these forty and five years, even since the LORD spake this word unto Moses, while the children of Israel wandered in the wilderness: and now, lo, I am this day fourscore and five years old. [^10] As yet I am as strong this day as I was in the day that Moses sent me: as my strength was then, even so is my strength now, for war, both to go out, and to come in. [^11] Now therefore give me this mountain, whereof the LORD spake in that day; for thou heardest in that day how the Anakims were there, and that the cities were great and fenced: if so be the LORD  will be with me, then I shall be able to drive them out, as the LORD said. [^12] And Joshua blessed him, and gave unto Caleb the son of Jephunneh Hebron for an inheritance. [^13] Hebron therefore became the inheritance of Caleb the son of Jephunneh the Kenezite unto this day, because that he wholly followed the LORD God of Israel. [^14] And the name of Hebron before was Kirjath-arba; which Arba was a great man among the Anakims. And the land had rest from war. [^15] 

[[Joshua - 13|<--]] Joshua - 14 [[Joshua - 15|-->]]

---
# Notes
