---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 4 - King James Version"
---
[[Joshua - 3|<--]] Joshua - 4 [[Joshua - 5|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Joshua]]

# Joshua - 4

And it came to pass, when all the people were clean passed over Jordan, that the LORD spake unto Joshua, saying, [^1] Take you twelve men out of the people, out of every tribe a man, [^2] and command ye them, saying, Take you hence out of the midst of Jordan, out of the place where the priests' feet stood firm, twelve stones, and ye shall carry them over with you, and leave them in the lodging place, where ye shall lodge this night. [^3] Then Joshua called the twelve men, whom he had prepared of the children of Israel, out of every tribe a man: [^4] and Joshua said unto them, Pass over before the ark of the LORD your God into the midst of Jordan, and take you up every man of you a stone upon his shoulder, according unto the number of the tribes of the children of Israel: [^5] that this may be a sign among you, that when your children ask their fathers in time to come, saying, What mean ye by these stones? [^6] Then ye shall answer them, That the waters of Jordan were cut off before the ark of the covenant of the LORD; when it passed over Jordan, the waters of Jordan were cut off: and these stones shall be for a memorial unto the children of Israel for ever. [^7] And the children of Israel did so as Joshua commanded, and took up twelve stones out of the midst of Jordan, as the LORD spake unto Joshua, according to the number of the tribes of the children of Israel, and carried them over with them unto the place where they lodged, and laid them down there. [^8] And Joshua set up twelve stones in the midst of Jordan, in the place where the feet of the priests which bare the ark of the covenant stood: and they are there unto this day. [^9] For the priests which bare the ark stood in the midst of Jordan, until every thing was finished that the LORD commanded Joshua to speak unto the people, according to all that Moses commanded Joshua: and the people hasted and passed over. [^10] And it came to pass, when all the people were clean passed over, that the ark of the LORD passed over, and the priests, in the presence of the people. [^11] And the children of Reuben, and the children of Gad, and half the tribe of Manasseh, passed over armed before the children of Israel, as Moses spake unto them: [^12] about forty thousand prepared for war passed over before the LORD unto battle, to the plains of Jericho. [^13] On that day the LORD magnified Joshua in the sight of all Israel; and they feared him, as they feared Moses, all the days of his life. [^14] And the LORD spake unto Joshua, saying, [^15] Command the priests that bear the ark of the testimony, that they come up out of Jordan. [^16] Joshua therefore commanded the priests, saying, Come ye up out of Jordan. [^17] And it came to pass, when the priests that bare the ark of the covenant of the LORD were come up out of the midst of Jordan, and the soles of the priests' feet were lifted up unto the dry land, that the waters of Jordan returned unto their place, and flowed over all his banks, as they did before. [^18] And the people came up out of Jordan on the tenth day of the first month, and encamped in Gilgal, in the east border of Jericho. [^19] And those twelve stones, which they took out of Jordan, did Joshua pitch in Gilgal. [^20] And he spake unto the children of Israel, saying, When your children shall ask their fathers in time to come, saying, What mean these stones? [^21] Then ye shall let your children know, saying, Israel came over this Jordan on dry land. [^22] For the LORD your God dried up the waters of Jordan from before you, until ye were passed over, as the LORD your God did to the Red sea, which he dried up from before us, until we were gone over: [^23] that all the people of the earth might know the hand of the LORD, that it is mighty: that ye might fear the LORD your God for ever. [^24] 

[[Joshua - 3|<--]] Joshua - 4 [[Joshua - 5|-->]]

---
# Notes
