---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 11 - King James Version"
---
[[Joshua - 10|<--]] Joshua - 11 [[Joshua - 12|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Joshua]]

# Joshua - 11

And it came to pass, when Jabin king of Hazor had heard those things, that he sent to Jobab king of Madon, and to the king of Shimron, and to the king of Achshaph, [^1] and to the kings that were on the north of the mountains, and of the plains south of Chinneroth, and in the valley, and in the borders of Dor on the west, [^2] and to the Canaanite on the east and on the west, and to the Amorite, and the Hittite, and the Perizzite, and the Jebusite in the mountains, and to the Hivite under Hermon in the land of Mizpeh. [^3] And they went out, they and all their hosts with them, much people, even as the sand that is upon the sea shore in multitude, with horses and chariots very many. [^4] And when all these kings were met together, they came and pitched together at the waters of Merom, to fight against Israel. [^5] And the LORD said unto Joshua, Be not afraid because of them: for to morrow about this time will I deliver them up all slain before Israel: thou shalt hough their horses, and burn their chariots with fire. [^6] So Joshua came, and all the people of war with him, against them by the waters of Merom suddenly; and they fell upon them. [^7] And the LORD delivered them into the hand of Israel, who smote them, and chased them unto great Zidon, and unto Misrephoth-maim, and unto the valley of Mizpeh eastward; and they smote them, until they left them none remaining. [^8] And Joshua did unto them as the LORD bade him: he houghed their horses, and burnt their chariots with fire. [^9] And Joshua at that time turned back, and took Hazor, and smote the king thereof with the sword: for Hazor beforetime was the head of all those kingdoms. [^10] And they smote all the souls that were therein with the edge of the sword, utterly destroying them: there was not any left to breathe: and he burnt Hazor with fire. [^11] And all the cities of those kings, and all the kings of them, did Joshua take, and smote them with the edge of the sword, and he utterly destroyed them, as Moses the servant of the LORD commanded. [^12] But as for the cities that stood still in their strength, Israel burned none of them, save Hazor only; that did Joshua burn. [^13] And all the spoil of these cities, and the cattle, the children of Israel took for a prey unto themselves; but every man they smote with the edge of the sword, until they had destroyed them, neither left they any to breathe. [^14] As the LORD commanded Moses his servant, so did Moses command Joshua, and so did Joshua; he left nothing undone of all that the LORD commanded Moses. [^15] So Joshua took all that land, the hills, and all the south country, and all the land of Goshen, and the valley, and the plain, and the mountain of Israel, and the valley of the same; [^16] even from the mount Halak, that goeth up to Seir, even unto Baal-gad in the valley of Lebanon under mount Hermon: and all their kings he took, and smote them, and slew them. [^17] Joshua made war a long time with all those kings. [^18] There was not a city that made peace with the children of Israel, save the Hivites the inhabitants of Gibeon: all other they took in battle. [^19] For it was of the LORD to harden their hearts, that they should come against Israel in battle, that he might destroy them utterly, and that they might have no favour, but that he might destroy them, as the LORD commanded Moses. [^20] And at that time came Joshua, and cut off the Anakims from the mountains, from Hebron, from Debir, from Anab, and from all the mountains of Judah, and from all the mountains of Israel: Joshua destroyed them utterly with their cities. [^21] There was none of the Anakims left in the land of the children of Israel: only in Gaza, in Gath, and in Ashdod, there remained. [^22] So Joshua took the whole land, according to all that the LORD said unto Moses; and Joshua gave it for an inheritance unto Israel according to their divisions by their tribes. And the land rested from war. [^23] 

[[Joshua - 10|<--]] Joshua - 11 [[Joshua - 12|-->]]

---
# Notes
