---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 3 - King James Version"
---
[[Joshua - 2|<--]] Joshua - 3 [[Joshua - 4|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Joshua]]

# Joshua - 3

And Joshua rose early in the morning; and they removed from Shittim, and came to Jordan, he and all the children of Israel, and lodged there before they passed over. [^1] And it came to pass after three days, that the officers went through the host; [^2] and they commanded the people, saying, When ye see the ark of the covenant of the LORD your God, and the priests the Levites bearing it, then ye shall remove from your place, and go after it. [^3] Yet there shall be a space between you and it, about two thousand cubits by measure: come not near unto it, that ye may know the way by which ye must go: for ye have not passed this way heretofore. [^4] And Joshua said unto the people, Sanctify yourselves: for to morrow the LORD will do wonders among you. [^5] And Joshua spake unto the priests, saying, Take up the ark of the covenant, and pass over before the people. And they took up the ark of the covenant, and went before the people. [^6] And the LORD said unto Joshua, This day will I begin to magnify thee in the sight of all Israel, that they may know that, as I was with Moses, so I will be with thee. [^7] And thou shalt command the priests that bear the ark of the covenant, saying, When ye are come to the brink of the water of Jordan, ye shall stand still in Jordan. [^8] And Joshua said unto the children of Israel, Come hither, and hear the words of the LORD your God. [^9] And Joshua said, Hereby ye shall know that the living God is among you, and that he will without fail drive out from before you the Canaanites, and the Hittites, and the Hivites, and the Perizzites, and the Girgashites, and the Amorites, and the Jebusites. [^10] Behold, the ark of the covenant of the Lord of all the earth passeth over before you into Jordan. [^11] Now therefore take you twelve men out of the tribes of Israel, out of every tribe a man. [^12] And it shall come to pass, as soon as the soles of the feet of the priests that bear the ark of the LORD, the Lord of all the earth, shall rest in the waters of Jordan, that the waters of Jordan shall be cut off from the waters that come down from above; and they shall stand upon an heap. [^13] And it came to pass, when the people removed from their tents, to pass over Jordan, and the priests bearing the ark of the covenant before the people; [^14] and as they that bare the ark were come unto Jordan, and the feet of the priests that bare the ark were dipped in the brim of the water, (for Jordan overfloweth all his banks all the time of harvest,) [^15] that the waters which came down from above stood and rose up upon an heap very far from the city Adam, that is beside Zaretan: and those that came down toward the sea of the plain, even the salt sea, failed, and were cut off: and the people passed over right against Jericho. [^16] And the priests that bare the ark of the covenant of the LORD stood firm on dry ground in the midst of Jordan, and all the Israelites passed over on dry ground, until all the people were passed clean over Jordan. [^17] 

[[Joshua - 2|<--]] Joshua - 3 [[Joshua - 4|-->]]

---
# Notes
