---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/joshua"
  - "#bible/testament/old"
aliases:
  - "Joshua - 12 - King James Version"
---
[[Joshua - 11|<--]] Joshua - 12 [[Joshua - 13|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Joshua]]

# Joshua - 12

Now these are the kings of the land, which the children of Israel smote, and possessed their land on the other side Jordan toward the rising of the sun, from the river Arnon unto mount Hermon, and all the plain on the east: [^1] Sihon king of the Amorites, who dwelt in Heshbon, and ruled from Aroer, which is upon the bank of the river Arnon, and from the middle of the river, and from half Gilead, even unto the river Jabbok, which is the border of the children of Ammon; [^2] and from the plain to the sea of Chinneroth on the east, and unto the sea of the plain, even the salt sea on the east, the way to Beth-jeshimoth; and from the south, under Ashdoth-pisgah: [^3] and the coast of Og king of Bashan, which was of the remnant of the giants, that dwelt at Ashtaroth and at Edrei, [^4] and reigned in mount Hermon, and in Salcah, and in all Bashan, unto the border of the Geshurites and the Maachathites, and half Gilead, the border of Sihon king of Heshbon. [^5] Them did Moses the servant of the LORD and the children of Israel smite: and Moses the servant of the LORD gave it for a possession unto the Reubenites, and the Gadites, and the half tribe of Manasseh. [^6] And these are the kings of the country which Joshua and the children of Israel smote on this side Jordan on the west, from Baal-gad in the valley of Lebanon even unto the mount Halak, that goeth up to Seir; which Joshua gave unto the tribes of Israel for a possession according to their divisions; [^7] in the mountains, and in the valleys, and in the plains, and in the springs, and in the wilderness, and in the south country; the Hittites, the Amorites, and the Canaanites, the Perizzites, the Hivites, and the Jebusites: [^8] the king of Jericho, one; the king of Ai, which is beside Beth-el, one; [^9] the king of Jerusalem, one; the king of Hebron, one; [^10] the king of Jarmuth, one; the king of Lachish, one; [^11] the king of Eglon, one; the king of Gezer, one; [^12] the king of Debir, one; the king of Geder, one; [^13] the king of Hormah, one; the king of Arad, one; [^14] the king of Libnah, one; the king of Adullam, one; [^15] the king of Makkedah, one; the king of Beth-el, one; [^16] the king of Tappuah, one; the king of Hepher, one; [^17] the king of Aphek, one; the king of Lasharon, one; [^18] the king of Madon, one; the king of Hazor, one; [^19] the king of Shimron-meron, one; the king of Achshaph, one; [^20] the king of Taanach, one; the king of Megiddo, one; [^21] the king of Kedesh, one; the king of Jokneam of Carmel, one; [^22] the king of Dor in the coast of Dor, one; the king of the nations of Gilgal, one; [^23] the king of Tirzah, one: all the kings thirty and one. [^24] 

[[Joshua - 11|<--]] Joshua - 12 [[Joshua - 13|-->]]

---
# Notes
