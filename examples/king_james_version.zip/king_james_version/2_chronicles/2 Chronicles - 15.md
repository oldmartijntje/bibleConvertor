---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 15 - King James Version"
---
[[2 Chronicles - 14|<--]] 2 Chronicles - 15 [[2 Chronicles - 16|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[2 Chronicles]]

# 2 Chronicles - 15

And the Spirit of God came upon Azariah the son of Oded: [^1] and he went out to meet Asa, and said unto him, Hear ye me, Asa, and all Judah and Benjamin; The LORD  is with you, while ye be with him; and if ye seek him, he will be found of you; but if ye forsake him, he will forsake you. [^2] Now for a long season Israel hath been without the true God, and without a teaching priest, and without law. [^3] But when they in their trouble did turn unto the LORD God of Israel, and sought him, he was found of them. [^4] And in those times there was no peace to him that went out, nor to him that came in, but great vexations were upon all the inhabitants of the countries. [^5] And nation was destroyed of nation, and city of city: for God did vex them with all adversity. [^6] Be ye strong therefore, and let not your hands be weak: for your work shall be rewarded. [^7] And when Asa heard these words, and the prophecy of Oded the prophet, he took courage, and put away the abominable idols out of all the land of Judah and Benjamin, and out of the cities which he had taken from mount Ephraim, and renewed the altar of the LORD, that was before the porch of the LORD. [^8] And he gathered all Judah and Benjamin, and the strangers with them out of Ephraim and Manasseh, and out of Simeon: for they fell to him out of Israel in abundance, when they saw that the LORD his God was with him. [^9] So they gathered themselves together at Jerusalem in the third month, in the fifteenth year of the reign of Asa. [^10] And they offered unto the LORD the same time, of the spoil which they had brought, seven hundred oxen and seven thousand sheep. [^11] And they entered into a covenant to seek the LORD God of their fathers with all their heart and with all their soul; [^12] that whosoever would not seek the LORD God of Israel should be put to death, whether small or great, whether man or woman. [^13] And they sware unto the LORD with a loud voice, and with shouting, and with trumpets, and with cornets. [^14] And all Judah rejoiced at the oath: for they had sworn with all their heart, and sought him with their whole desire; and he was found of them: and the LORD gave them rest round about. [^15] And also concerning Maachah the mother of Asa the king, he removed her from being queen, because she had made an idol in a grove: and Asa cut down her idol, and stamped it, and burnt it at the brook Kidron. [^16] But the high places were not taken away out of Israel: nevertheless the heart of Asa was perfect all his days. [^17] And he brought into the house of God the things that his father had dedicated, and that he himself had dedicated, silver, and gold, and vessels. [^18] And there was no more war unto the five and thirtieth year of the reign of Asa. [^19] 

[[2 Chronicles - 14|<--]] 2 Chronicles - 15 [[2 Chronicles - 16|-->]]

---
# Notes
