---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 27 - King James Version"
---
[[2 Chronicles - 26|<--]] 2 Chronicles - 27 [[2 Chronicles - 28|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[2 Chronicles]]

# 2 Chronicles - 27

Jotham was twenty and five years old when he began to reign, and he reigned sixteen years in Jerusalem. His mother's name also was Jerushah, the daughter of Zadok. [^1] And he did that which was right in the sight of the LORD, according to all that his father Uzziah did: howbeit he entered not into the temple of the LORD. And the people did yet corruptly. [^2] He built the high gate of the house of the LORD, and on the wall of Ophel he built much. [^3] Moreover he built cities in the mountains of Judah, and in the forests he built castles and towers. [^4] He fought also with the king of the Ammonites, and prevailed against them. And the children of Ammon gave him the same year an hundred talents of silver, and ten thousand measures of wheat, and ten thousand of barley. So much did the children of Ammon pay unto him, both the second year, and the third. [^5] So Jotham became mighty, because he prepared his ways before the LORD his God. [^6] Now the rest of the acts of Jotham, and all his wars, and his ways, lo, they are written in the book of the kings of Israel and Judah. [^7] He was five and twenty years old when he began to reign, and reigned sixteen years in Jerusalem. [^8] And Jotham slept with his fathers, and they buried him in the city of David: and Ahaz his son reigned in his stead. [^9] 

[[2 Chronicles - 26|<--]] 2 Chronicles - 27 [[2 Chronicles - 28|-->]]

---
# Notes
