---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 22 - King James Version"
---
[[2 Chronicles - 21|<--]] 2 Chronicles - 22 [[2 Chronicles - 23|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[2 Chronicles]]

# 2 Chronicles - 22

And the inhabitants of Jerusalem made Ahaziah his youngest son king in his stead: for the band of men that came with the Arabians to the camp had slain all the eldest. So Ahaziah the son of Jehoram king of Judah reigned. [^1] Forty and two years old was Ahaziah when he began to reign, and he reigned one year in Jerusalem. His mother's name also was Athaliah the daughter of Omri. [^2] He also walked in the ways of the house of Ahab: for his mother was his counsellor to do wickedly. [^3] Wherefore he did evil in the sight of the LORD like the house of Ahab: for they were his counsellors after the death of his father to his destruction. [^4] He walked also after their counsel, and went with Jehoram the son of Ahab king of Israel to war against Hazael king of Syria at Ramoth-gilead: and the Syrians smote Joram. [^5] And he returned to be healed in Jezreel because of the wounds which were given him at Ramah, when he fought with Hazael king of Syria. And Azariah the son of Jehoram king of Judah went down to see Jehoram the son of Ahab at Jezreel, because he was sick. [^6] And the destruction of Ahaziah was of God by coming to Joram: for when he was come, he went out with Jehoram against Jehu the son of Nimshi, whom the LORD had anointed to cut off the house of Ahab. [^7] And it came to pass, that, when Jehu was executing judgment upon the house of Ahab, and found the princes of Judah, and the sons of the brethren of Ahaziah, that ministered to Ahaziah, he slew them. [^8] And he sought Ahaziah: and they caught him, (for he was hid in Samaria,) and brought him to Jehu: and when they had slain him, they buried him: Because, said they, he is the son of Jehoshaphat, who sought the LORD with all his heart. So the house of Ahaziah had no power to keep still the kingdom. [^9] But when Athaliah the mother of Ahaziah saw that her son was dead, she arose and destroyed all the seed royal of the house of Judah. [^10] But Jehoshabeath, the daughter of the king, took Joash the son of Ahaziah, and stole him from among the king's sons that were slain, and put him and his nurse in a bedchamber. So Jehoshabeath, the daughter of king Jehoram, the wife of Jehoiada the priest, (for she was the sister of Ahaziah,) hid him from Athaliah, so that she slew him not. [^11] And he was with them hid in the house of God six years: and Athaliah reigned over the land. [^12] 

[[2 Chronicles - 21|<--]] 2 Chronicles - 22 [[2 Chronicles - 23|-->]]

---
# Notes
