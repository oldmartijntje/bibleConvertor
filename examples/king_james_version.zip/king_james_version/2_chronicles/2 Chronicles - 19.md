---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 19 - King James Version"
---
[[2 Chronicles - 18|<--]] 2 Chronicles - 19 [[2 Chronicles - 20|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[2 Chronicles]]

# 2 Chronicles - 19

And Jehoshaphat the king of Judah returned to his house in peace to Jerusalem. [^1] And Jehu the son of Hanani the seer went out to meet him, and said to king Jehoshaphat, Shouldest thou help the ungodly, and love them that hate the LORD? therefore is wrath upon thee from before the LORD. [^2] Nevertheless there are good things found in thee, in that thou hast taken away the groves out of the land, and hast prepared thine heart to seek God. [^3] And Jehoshaphat dwelt at Jerusalem: and he went out again through the people from Beer-sheba to mount Ephraim, and brought them back unto the LORD God of their fathers. [^4] And he set judges in the land throughout all the fenced cities of Judah, city by city, [^5] and said to the judges, Take heed what ye do: for ye judge not for man, but for the LORD, who is with you in the judgment. [^6] Wherefore now let the fear of the LORD be upon you; take heed and do it: for there is no iniquity with the LORD our God, nor respect of persons, nor taking of gifts. [^7] Moreover in Jerusalem did Jehoshaphat set of the Levites, and of the priests, and of the chief of the fathers of Israel, for the judgment of the LORD, and for controversies, when they returned to Jerusalem. [^8] And he charged them, saying, Thus shall ye do in the fear of the LORD, faithfully, and with a perfect heart. [^9] And what cause soever shall come to you of your brethren that dwell in their cities, between blood and blood, between law and commandment, statutes and judgments, ye shall even warn them that they trespass not against the LORD, and so wrath come upon you, and upon your brethren: this do, and ye shall not trespass. [^10] And, behold, Amariah the chief priest is over you in all matters of the LORD; and Zebadiah the son of Ishmael, the ruler of the house of Judah, for all the king's matters: also the Levites shall be officers before you. Deal courageously, and the LORD shall be with the good. [^11] 

[[2 Chronicles - 18|<--]] 2 Chronicles - 19 [[2 Chronicles - 20|-->]]

---
# Notes
