---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 21 - King James Version"
---
[[2 Chronicles - 20|<--]] 2 Chronicles - 21 [[2 Chronicles - 22|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[2 Chronicles]]

# 2 Chronicles - 21

Now Jehoshaphat slept with his fathers, and was buried with his fathers in the city of David. And Jehoram his son reigned in his stead. [^1] And he had brethren the sons of Jehoshaphat, Azariah, and Jehiel, and Zechariah, and Azariah, and Michael, and Shephatiah: all these were the sons of Jehoshaphat king of Israel. [^2] And their father gave them great gifts of silver, and of gold, and of precious things, with fenced cities in Judah: but the kingdom gave he to Jehoram; because he was the firstborn. [^3] Now when Jehoram was risen up to the kingdom of his father, he strengthened himself, and slew all his brethren with the sword, and divers also of the princes of Israel. [^4] Jehoram was thirty and two years old when he began to reign, and he reigned eight years in Jerusalem. [^5] And he walked in the way of the kings of Israel, like as did the house of Ahab: for he had the daughter of Ahab to wife: and he wrought that which was evil in the eyes of the LORD. [^6] Howbeit the LORD would not destroy the house of David, because of the covenant that he had made with David, and as he promised to give a light to him and to his sons for ever. [^7] In his days the Edomites revolted from under the dominion of Judah, and made themselves a king. [^8] Then Jehoram went forth with his princes, and all his chariots with him: and he rose up by night, and smote the Edomites which compassed him in, and the captains of the chariots. [^9] So the Edomites revolted from under the hand of Judah unto this day. The same time also did Libnah revolt from under his hand; because he had forsaken the LORD God of his fathers. [^10] Moreover he made high places in the mountains of Judah, and caused the inhabitants of Jerusalem to commit fornication, and compelled Judah thereto. [^11] And there came a writing to him from Elijah the prophet, saying, Thus saith the LORD God of David thy father, Because thou hast not walked in the ways of Jehoshaphat thy father, nor in the ways of Asa king of Judah, [^12] but hast walked in the way of the kings of Israel, and hast made Judah and the inhabitants of Jerusalem to go a whoring, like to the whoredoms of the house of Ahab, and also hast slain thy brethren of thy father's house, which were better than thyself: [^13] behold, with a great plague will the LORD smite thy people, and thy children, and thy wives, and all thy goods: [^14] and thou shalt have great sickness by disease of thy bowels, until thy bowels fall out by reason of the sickness day by day. [^15] Moreover the LORD stirred up against Jehoram the spirit of the Philistines, and of the Arabians, that were near the Ethiopians: [^16] and they came up into Judah, and brake into it, and carried away all the substance that was found in the king's house, and his sons also, and his wives; so that there was never a son left him, save Jehoahaz, the youngest of his sons. [^17] And after all this the LORD smote him in his bowels with an incurable disease. [^18] And it came to pass, that in process of time, after the end of two years, his bowels fell out by reason of his sickness: so he died of sore diseases. And his people made no burning for him, like the burning of his fathers. [^19] Thirty and two years old was he when he began to reign, and he reigned in Jerusalem eight years, and departed without being desired. Howbeit they buried him in the city of David, but not in the sepulchres of the kings. [^20] 

[[2 Chronicles - 20|<--]] 2 Chronicles - 21 [[2 Chronicles - 22|-->]]

---
# Notes
