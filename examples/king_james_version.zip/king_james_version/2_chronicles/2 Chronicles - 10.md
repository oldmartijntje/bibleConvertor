---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 10 - King James Version"
---
[[2 Chronicles - 9|<--]] 2 Chronicles - 10 [[2 Chronicles - 11|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[2 Chronicles]]

# 2 Chronicles - 10

And Rehoboam went to Shechem: for to Shechem were all Israel come to make him king. [^1] And it came to pass, when Jeroboam the son of Nebat, who was in Egypt, whither he had fled from the presence of Solomon the king, heard it, that Jeroboam returned out of Egypt. [^2] And they sent and called him. So Jeroboam and all Israel came and spake to Rehoboam, saying, [^3] Thy father made our yoke grievous: now therefore ease thou somewhat the grievous servitude of thy father, and his heavy yoke that he put upon us, and we will serve thee. [^4] And he said unto them, Come again unto me after three days. And the people departed. [^5] And king Rehoboam took counsel with the old men that had stood before Solomon his father while he yet lived, saying, What counsel give ye me to return answer to this people? [^6] And they spake unto him, saying, If thou be kind to this people, and please them, and speak good words to them, they will be thy servants for ever. [^7] But he forsook the counsel which the old men gave him, and took counsel with the young men that were brought up with him, that stood before him. [^8] And he said unto them, What advice give ye that we may return answer to this people, which have spoken to me, saying, Ease somewhat the yoke that thy father did put upon us? [^9] And the young men that were brought up with him spake unto him, saying, Thus shalt thou answer the people that spake unto thee, saying, Thy father made our yoke heavy, but make thou it somewhat lighter for us; thus shalt thou say unto them, My little finger shall be thicker than my father's loins. [^10] For whereas my father put a heavy yoke upon you, I will put more to your yoke: my father chastised you with whips, but I will chastise you with scorpions. [^11] So Jeroboam and all the people came to Rehoboam on the third day, as the king bade, saying, Come again to me on the third day. [^12] And the king answered them roughly; and king Rehoboam forsook the counsel of the old men, [^13] and answered them after the advice of the young men, saying, My father made your yoke heavy, but I will add thereto: my father chastised you with whips, but I will chastise you with scorpions. [^14] So the king hearkened not unto the people: for the cause was of God, that the LORD might perform his word, which he spake by the hand of Ahijah the Shilonite to Jeroboam the son of Nebat. [^15] And when all Israel saw that the king would not hearken unto them, the people answered the king, saying, What portion have we in David? and we have none inheritance in the son of Jesse: every man to your tents, O Israel: and now, David, see to thine own house. So all Israel went to their tents. [^16] But as for the children of Israel that dwelt in the cities of Judah, Rehoboam reigned over them. [^17] Then king Rehoboam sent Hadoram that was over the tribute; and the children of Israel stoned him with stones, that he died. But king Rehoboam made speed to get him up to his chariot, to flee to Jerusalem. [^18] And Israel rebelled against the house of David unto this day. [^19] 

[[2 Chronicles - 9|<--]] 2 Chronicles - 10 [[2 Chronicles - 11|-->]]

---
# Notes
