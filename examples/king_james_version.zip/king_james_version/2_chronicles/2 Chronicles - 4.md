---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 4 - King James Version"
---
[[2 Chronicles - 3|<--]] 2 Chronicles - 4 [[2 Chronicles - 5|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[2 Chronicles]]

# 2 Chronicles - 4

Moreover he made an altar of brass, twenty cubits the length thereof, and twenty cubits the breadth thereof, and ten cubits the height thereof. [^1] Also he made a molten sea of ten cubits from brim to brim, round in compass, and five cubits the height thereof; and a line of thirty cubits did compass it round about. [^2] And under it was the similitude of oxen, which did compass it round about: ten in a cubit, compassing the sea round about. Two rows of oxen were cast, when it was cast. [^3] It stood upon twelve oxen, three looking toward the north, and three looking toward the west, and three looking toward the south, and three looking toward the east: and the sea was set above upon them, and all their hinder parts were inward. [^4] And the thickness of it was an handbreadth, and the brim of it like the work of the brim of a cup, with flowers of lilies; and it received and held three thousand baths. [^5] He made also ten lavers, and put five on the right hand, and five on the left, to wash in them: such things as they offered for the burnt offering they washed in them; but the sea was for the priests to wash in. [^6] And he made ten candlesticks of gold according to their form, and set them in the temple, five on the right hand, and five on the left. [^7] He made also ten tables, and placed them in the temple, five on the right side, and five on the left. And he made an hundred basons of gold. [^8] Furthermore he made the court of the priests, and the great court, and doors for the court, and overlaid the doors of them with brass. [^9] And he set the sea on the right side of the east end, over against the south. [^10] And Huram made the pots, and the shovels, and the basons.And Huram finished the work that he was to make for king Solomon for the house of God; [^11] to wit, the two pillars, and the pommels, and the chapiters which were on the top of the two pillars, and the two wreaths to cover the two pommels of the chapiters which were on the top of the pillars; [^12] and four hundred pomegranates on the two wreaths; two rows of pomegranates on each wreath, to cover the two pommels of the chapiters which were upon the pillars. [^13] He made also bases, and lavers made he upon the bases; [^14] one sea, and twelve oxen under it. [^15] The pots also, and the shovels, and the fleshhooks, and all their instruments, did Huram his father make to king Solomon for the house of the LORD of bright brass. [^16] In the plain of Jordan did the king cast them, in the clay ground between Succoth and Zeredathah. [^17] Thus Solomon made all these vessels in great abundance: for the weight of the brass could not be found out. [^18] And Solomon made all the vessels that were for the house of God, the golden altar also, and the tables whereon the shewbread was set; [^19] moreover the candlesticks with their lamps, that they should burn after the manner before the oracle, of pure gold; [^20] and the flowers, and the lamps, and the tongs, made he of gold, and that perfect gold; [^21] and the snuffers, and the basons, and the spoons, and the censers, of pure gold: and the entry of the house, the inner doors thereof for the most holy place, and the doors of the house of the temple, were of gold. [^22] 

[[2 Chronicles - 3|<--]] 2 Chronicles - 4 [[2 Chronicles - 5|-->]]

---
# Notes
