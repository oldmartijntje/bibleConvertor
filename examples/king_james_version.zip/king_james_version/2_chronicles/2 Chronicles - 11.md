---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 11 - King James Version"
---
[[2 Chronicles - 10|<--]] 2 Chronicles - 11 [[2 Chronicles - 12|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[2 Chronicles]]

# 2 Chronicles - 11

And when Rehoboam was come to Jerusalem, he gathered of the house of Judah and Benjamin an hundred and fourscore thousand chosen men, which were warriors, to fight against Israel, that he might bring the kingdom again to Rehoboam. [^1] But the word of the LORD came to Shemaiah the man of God, saying, [^2] Speak unto Rehoboam the son of Solomon, king of Judah, and to all Israel in Judah and Benjamin, saying, [^3] Thus saith the LORD, Ye shall not go up, nor fight against your brethren: return every man to his house: for this thing is done of me. And they obeyed the words of the LORD, and returned from going against Jeroboam. [^4] And Rehoboam dwelt in Jerusalem, and built cities for defence in Judah. [^5] He built even Beth-lehem, and Etam, and Tekoa, [^6] and Beth-zur, and Shoco, and Adullam, [^7] and Gath, and Mareshah, and Ziph, [^8] and Adoraim, and Lachish, and Azekah, [^9] and Zorah, and Aijalon, and Hebron, which are in Judah and in Benjamin fenced cities. [^10] And he fortified the strong holds, and put captains in them, and store of victual, and of oil and wine. [^11] And in every several city he put shields and spears, and made them exceeding strong, having Judah and Benjamin on his side. [^12] And the priests and the Levites that were in all Israel resorted to him out of all their coasts. [^13] For the Levites left their suburbs and their possession, and came to Judah and Jerusalem: for Jeroboam and his sons had cast them off from executing the priest's office unto the LORD: [^14] and he ordained him priests for the high places, and for the devils, and for the calves which he had made. [^15] And after them out of all the tribes of Israel such as set their hearts to seek the LORD God of Israel came to Jerusalem, to sacrifice unto the LORD God of their fathers. [^16] So they strengthened the kingdom of Judah, and made Rehoboam the son of Solomon strong, three years: for three years they walked in the way of David and Solomon. [^17] And Rehoboam took him Mahalath the daughter of Jerimoth the son of David to wife, and Abihail the daughter of Eliab the son of Jesse; [^18] which bare him children; Jeush, and Shemariah, and Zaham. [^19] And after her he took Maachah the daughter of Absalom; which bare him Abijah, and Attai, and Ziza, and Shelomith. [^20] And Rehoboam loved Maachah the daughter of Absalom above all his wives and his concubines: (for he took eighteen wives, and threescore concubines; and begat twenty and eight sons, and threescore daughters.) [^21] And Rehoboam made Abijah the son of Maachah the chief, to be ruler among his brethren: for he thought to make him king. [^22] And he dealt wisely, and dispersed of all his children throughout all the countries of Judah and Benjamin, unto every fenced city: and he gave them victual in abundance. And he desired many wives. [^23] 

[[2 Chronicles - 10|<--]] 2 Chronicles - 11 [[2 Chronicles - 12|-->]]

---
# Notes
