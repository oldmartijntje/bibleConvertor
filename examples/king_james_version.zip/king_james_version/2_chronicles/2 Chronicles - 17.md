---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 17 - King James Version"
---
[[2 Chronicles - 16|<--]] 2 Chronicles - 17 [[2 Chronicles - 18|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[2 Chronicles]]

# 2 Chronicles - 17

And Jehoshaphat his son reigned in his stead, and strengthened himself against Israel. [^1] And he placed forces in all the fenced cities of Judah, and set garrisons in the land of Judah, and in the cities of Ephraim, which Asa his father had taken. [^2] And the LORD was with Jehoshaphat, because he walked in the first ways of his father David, and sought not unto Baalim; [^3] but sought to the LORD God of his father, and walked in his commandments, and not after the doings of Israel. [^4] Therefore the LORD stablished the kingdom in his hand; and all Judah brought to Jehoshaphat presents; and he had riches and honour in abundance. [^5] And his heart was lifted up in the ways of the LORD: moreover he took away the high places and groves out of Judah. [^6] Also in the third year of his reign he sent to his princes, even to Ben-hail, and to Obadiah, and to Zechariah, and to Nethaneel, and to Michaiah, to teach in the cities of Judah. [^7] And with them he sent Levites, even Shemaiah, and Nethaniah, and Zebadiah, and Asahel, and Shemiramoth, and Jehonathan, and Adonijah, and Tobijah, and Tob-adonijah, Levites; and with them Elishama and Jehoram, priests. [^8] And they taught in Judah, and had the book of the law of the LORD with them, and went about throughout all the cities of Judah, and taught the people. [^9] And the fear of the LORD fell upon all the kingdoms of the lands that were round about Judah, so that they made no war against Jehoshaphat. [^10] Also some of the Philistines brought Jehoshaphat presents, and tribute silver; and the Arabians brought him flocks, seven thousand and seven hundred rams, and seven thousand and seven hundred he goats. [^11] And Jehoshaphat waxed great exceedingly; and he built in Judah castles, and cities of store. [^12] And he had much business in the cities of Judah: and the men of war, mighty men of valour, were in Jerusalem. [^13] And these are the numbers of them according to the house of their fathers: Of Judah, the captains of thousands; Adnah the chief, and with him mighty men of valour three hundred thousand. [^14] And next to him was Jehohanan the captain, and with him two hundred and fourscore thousand. [^15] And next him was Amasiah the son of Zichri, who willingly offered himself unto the LORD; and with him two hundred thousand mighty men of valour. [^16] And of Benjamin; Eliada a mighty man of valour, and with him armed men with bow and shield two hundred thousand. [^17] And next him was Jehozabad, and with him an hundred and fourscore thousand ready prepared for the war. [^18] These waited on the king, beside those whom the king put in the fenced cities throughout all Judah. [^19] 

[[2 Chronicles - 16|<--]] 2 Chronicles - 17 [[2 Chronicles - 18|-->]]

---
# Notes
