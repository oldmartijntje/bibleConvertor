---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 1 - King James Version"
---
2 Chronicles - 1 [[2 Chronicles - 2|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[2 Chronicles]]

# 2 Chronicles - 1

And Solomon the son of David was strengthened in his kingdom, and the LORD his God was with him, and magnified him exceedingly. [^1] Then Solomon spake unto all Israel, to the captains of thousands and of hundreds, and to the judges, and to every governor in all Israel, the chief of the fathers. [^2] So Solomon, and all the congregation with him, went to the high place that was at Gibeon; for there was the tabernacle of the congregation of God, which Moses the servant of the LORD had made in the wilderness. [^3] But the ark of God had David brought up from Kirjath-jearim to the place which David had prepared for it: for he had pitched a tent for it at Jerusalem. [^4] Moreover the brasen altar, that Bezaleel the son of Uri, the son of Hur, had made, he put before the tabernacle of the LORD: and Solomon and the congregation sought unto it. [^5] And Solomon went up thither to the brasen altar before the LORD, which was at the tabernacle of the congregation, and offered a thousand burnt offerings upon it. [^6] In that night did God appear unto Solomon, and said unto him, Ask what I shall give thee. [^7] And Solomon said unto God, Thou hast shewed great mercy unto David my father, and hast made me to reign in his stead. [^8] Now, O LORD God, let thy promise unto David my father be established: for thou hast made me king over a people like the dust of the earth in multitude. [^9] Give me now wisdom and knowledge, that I may go out and come in before this people: for who can judge this thy people, that is so great? [^10] And God said to Solomon, Because this was in thine heart, and thou hast not asked riches, wealth, or honour, nor the life of thine enemies, neither yet hast asked long life; but hast asked wisdom and knowledge for thyself, that thou mayest judge my people, over whom I have made thee king: [^11] wisdom and knowledge is granted unto thee; and I will give thee riches, and wealth, and honour, such as none of the kings have had that have been before thee, neither shall there any after thee have the like. [^12] Then Solomon came from his journey to the high place that was at Gibeon to Jerusalem, from before the tabernacle of the congregation, and reigned over Israel. [^13] And Solomon gathered chariots and horsemen: and he had a thousand and four hundred chariots, and twelve thousand horsemen, which he placed in the chariot cities, and with the king at Jerusalem. [^14] And the king made silver and gold at Jerusalem as plenteous as stones, and cedar trees made he as the sycomore trees that are in the vale for abundance. [^15] And Solomon had horses brought out of Egypt, and linen yarn: the king's merchants received the linen yarn at a price. [^16] And they fetched up, and brought forth out of Egypt a chariot for six hundred shekels of silver, and an horse for an hundred and fifty: and so brought they out horses for all the kings of the Hittites, and for the kings of Syria, by their means. [^17] 

2 Chronicles - 1 [[2 Chronicles - 2|-->]]

---
# Notes
