---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 5 - King James Version"
---
[[2 Chronicles - 4|<--]] 2 Chronicles - 5 [[2 Chronicles - 6|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[2 Chronicles]]

# 2 Chronicles - 5

Thus all the work that Solomon made for the house of the LORD was finished: and Solomon brought in all the things that David his father had dedicated; and the silver, and the gold, and all the instruments, put he among the treasures of the house of God. [^1] Then Solomon assembled the elders of Israel, and all the heads of the tribes, the chief of the fathers of the children of Israel, unto Jerusalem, to bring up the ark of the covenant of the LORD out of the city of David, which is Zion. [^2] Wherefore all the men of Israel assembled themselves unto the king in the feast which was in the seventh month. [^3] And all the elders of Israel came; and the Levites took up the ark. [^4] And they brought up the ark, and the tabernacle of the congregation, and all the holy vessels that were in the tabernacle, these did the priests and the Levites bring up. [^5] Also king Solomon, and all the congregation of Israel that were assembled unto him before the ark, sacrificed sheep and oxen, which could not be told nor numbered for multitude. [^6] And the priests brought in the ark of the covenant of the LORD unto his place, to the oracle of the house, into the most holy place, even under the wings of the cherubims: [^7] for the cherubims spread forth their wings over the place of the ark, and the cherubims covered the ark and the staves thereof above. [^8] And they drew out the staves of the ark, that the ends of the staves were seen from the ark before the oracle; but they were not seen without. And there it is unto this day. [^9] There was nothing in the ark save the two tables which Moses put therein at Horeb, when the LORD made a covenant with the children of Israel, when they came out of Egypt. [^10] And it came to pass, when the priests were come out of the holy place: (for all the priests that were present were sanctified, and did not then wait by course: [^11] also the Levites which were the singers, all of them of Asaph, of Heman, of Jeduthun, with their sons and their brethren, being arrayed in white linen, having cymbals and psalteries and harps, stood at the east end of the altar, and with them an hundred and twenty priests sounding with trumpets:) [^12] it came even to pass, as the trumpeters and singers were as one, to make one sound to be heard in praising and thanking the LORD; and when they lifted up their voice with the trumpets and cymbals and instruments of musick, and praised the LORD, saying, For he is good; for his mercy endureth for ever: that then the house was filled with a cloud, even the house of the LORD; [^13] so that the priests could not stand to minister by reason of the cloud: for the glory of the LORD had filled the house of God. [^14] 

[[2 Chronicles - 4|<--]] 2 Chronicles - 5 [[2 Chronicles - 6|-->]]

---
# Notes
