---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 8 - King James Version"
---
[[2 Chronicles - 7|<--]] 2 Chronicles - 8 [[2 Chronicles - 9|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[2 Chronicles]]

# 2 Chronicles - 8

And it came to pass at the end of twenty years, wherein Solomon had built the house of the LORD, and his own house, [^1] that the cities which Huram had restored to Solomon, Solomon built them, and caused the children of Israel to dwell there. [^2] And Solomon went to Hamath-zobah, and prevailed against it. [^3] And he built Tadmor in the wilderness, and all the store cities, which he built in Hamath. [^4] Also he built Beth-horon the upper, and Beth-horon the nether, fenced cities, with walls, gates, and bars; [^5] and Baalath, and all the store cities that Solomon had, and all the chariot cities, and the cities of the horsemen, and all that Solomon desired to build in Jerusalem, and in Lebanon, and throughout all the land of his dominion. [^6] As for all the people that were left of the Hittites, and the Amorites, and the Perizzites, and the Hivites, and the Jebusites, which were not of Israel, [^7] but of their children, who were left after them in the land, whom the children of Israel consumed not, them did Solomon make to pay tribute until this day. [^8] But of the children of Israel did Solomon make no servants for his work; but they were men of war, and chief of his captains, and captains of his chariots and horsemen. [^9] And these were the chief of king Solomon's officers, even two hundred and fifty, that bare rule over the people. [^10] And Solomon brought up the daughter of Pharaoh out of the city of David unto the house that he had built for her: for he said, My wife shall not dwell in the house of David king of Israel, because the places are holy, whereunto the ark of the LORD hath come. [^11] Then Solomon offered burnt offerings unto the LORD on the altar of the LORD, which he had built before the porch, [^12] even after a certain rate every day, offering according to the commandment of Moses, on the sabbaths, and on the new moons, and on the solemn feasts, three times in the year, even in the feast of unleavened bread, and in the feast of weeks, and in the feast of tabernacles. [^13] And he appointed, according to the order of David his father, the courses of the priests to their service, and the Levites to their charges, to praise and minister before the priests, as the duty of every day required: the porters also by their courses at every gate: for so had David the man of God commanded. [^14] And they departed not from the commandment of the king unto the priests and Levites concerning any matter, or concerning the treasures. [^15] Now all the work of Solomon was prepared unto the day of the foundation of the house of the LORD, and until it was finished. So the house of the LORD was perfected. [^16] Then went Solomon to Ezion-geber, and to Eloth, at the sea side in the land of Edom. [^17] And Huram sent him by the hands of his servants ships, and servants that had knowledge of the sea; and they went with the servants of Solomon to Ophir, and took thence four hundred and fifty talents of gold, and brought them to king Solomon. [^18] 

[[2 Chronicles - 7|<--]] 2 Chronicles - 8 [[2 Chronicles - 9|-->]]

---
# Notes
