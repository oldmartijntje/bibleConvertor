---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 12 - King James Version"
---
[[2 Chronicles - 11|<--]] 2 Chronicles - 12 [[2 Chronicles - 13|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[2 Chronicles]]

# 2 Chronicles - 12

And it came to pass, when Rehoboam had established the kingdom, and had strengthened himself, he forsook the law of the LORD, and all Israel with him. [^1] And it came to pass, that in the fifth year of king Rehoboam Shishak king of Egypt came up against Jerusalem, because they had transgressed against the LORD, [^2] with twelve hundred chariots, and threescore thousand horsemen: and the people were without number that came with him out of Egypt; the Lubims, the Sukkiims, and the Ethiopians. [^3] And he took the fenced cities which pertained to Judah, and came to Jerusalem. [^4] Then came Shemaiah the prophet to Rehoboam, and to the princes of Judah, that were gathered together to Jerusalem because of Shishak, and said unto them, Thus saith the LORD, Ye have forsaken me, and therefore have I also left you in the hand of Shishak. [^5] Whereupon the princes of Israel and the king humbled themselves; and they said, The LORD  is righteous. [^6] And when the LORD saw that they humbled themselves, the word of the LORD came to Shemaiah, saying, They have humbled themselves; therefore I will not destroy them, but I will grant them some deliverance; and my wrath shall not be poured out upon Jerusalem by the hand of Shishak. [^7] Nevertheless they shall be his servants; that they may know my service, and the service of the kingdoms of the countries. [^8] So Shishak king of Egypt came up against Jerusalem, and took away the treasures of the house of the LORD, and the treasures of the king's house; he took all: he carried away also the shields of gold which Solomon had made. [^9] Instead of which king Rehoboam made shields of brass, and committed them to the hands of the chief of the guard, that kept the entrance of the king's house. [^10] And when the king entered into the house of the LORD, the guard came and fetched them, and brought them again into the guard chamber. [^11] And when he humbled himself, the wrath of the LORD turned from him, that he would not destroy him altogether: and also in Judah things went well. [^12] So king Rehoboam strengthened himself in Jerusalem, and reigned: for Rehoboam was one and forty years old when he began to reign, and he reigned seventeen years in Jerusalem, the city which the LORD had chosen out of all the tribes of Israel, to put his name there. And his mother's name was Naamah an Ammonitess. [^13] And he did evil, because he prepared not his heart to seek the LORD. [^14] Now the acts of Rehoboam, first and last, are they not written in the book of Shemaiah the prophet, and of Iddo the seer concerning genealogies? And there were wars between Rehoboam and Jeroboam continually. [^15] And Rehoboam slept with his fathers, and was buried in the city of David: and Abijah his son reigned in his stead. [^16] 

[[2 Chronicles - 11|<--]] 2 Chronicles - 12 [[2 Chronicles - 13|-->]]

---
# Notes
