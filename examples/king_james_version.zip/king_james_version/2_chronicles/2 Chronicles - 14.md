---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_chronicles"
  - "#bible/testament/old"
aliases:
  - "2 Chronicles - 14 - King James Version"
---
[[2 Chronicles - 13|<--]] 2 Chronicles - 14 [[2 Chronicles - 15|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[2 Chronicles]]

# 2 Chronicles - 14

So Abijah slept with his fathers, and they buried him in the city of David: and Asa his son reigned in his stead. In his days the land was quiet ten years. [^1] And Asa did that which was good and right in the eyes of the LORD his God: [^2] for he took away the altars of the strange gods, and the high places, and brake down the images, and cut down the groves: [^3] and commanded Judah to seek the LORD God of their fathers, and to do the law and the commandment. [^4] Also he took away out of all the cities of Judah the high places and the images: and the kingdom was quiet before him. [^5] And he built fenced cities in Judah: for the land had rest, and he had no war in those years; because the LORD had given him rest. [^6] Therefore he said unto Judah, Let us build these cities, and make about them walls, and towers, gates, and bars, while the land is yet before us; because we have sought the LORD our God, we have sought him, and he hath given us rest on every side. So they built and prospered. [^7] And Asa had an army of men that bare targets and spears, out of Judah three hundred thousand; and out of Benjamin, that bare shields and drew bows, two hundred and fourscore thousand: all these were mighty men of valour. [^8] And there came out against them Zerah the Ethiopian with an host of a thousand thousand, and three hundred chariots; and came unto Mareshah. [^9] Then Asa went out against him, and they set the battle in array in the valley of Zephathah at Mareshah. [^10] And Asa cried unto the LORD his God, and said, LORD, it is nothing with thee to help, whether with many, or with them that have no power: help us, O LORD our God; for we rest on thee, and in thy name we go against this multitude. O LORD, thou art our God; let not man prevail against thee. [^11] So the LORD smote the Ethiopians before Asa, and before Judah; and the Ethiopians fled. [^12] And Asa and the people that were with him pursued them unto Gerar: and the Ethiopians were overthrown, that they could not recover themselves; for they were destroyed before the LORD, and before his host; and they carried away very much spoil. [^13] And they smote all the cities round about Gerar; for the fear of the LORD came upon them: and they spoiled all the cities; for there was exceeding much spoil in them. [^14] They smote also the tents of cattle, and carried away sheep and camels in abundance, and returned to Jerusalem. [^15] 

[[2 Chronicles - 13|<--]] 2 Chronicles - 14 [[2 Chronicles - 15|-->]]

---
# Notes
