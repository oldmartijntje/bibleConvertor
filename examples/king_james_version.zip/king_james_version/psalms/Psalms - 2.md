---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/psalms"
  - "#bible/testament/old"
aliases:
  - "Psalms - 2 - King James Version"
---
[[Psalms - 1|<--]] Psalms - 2 [[Psalms - 3|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Psalms]]

# Psalms - 2

Why do the heathen rage,And the people imagine a vain thing? [^1] The kings of the earth set themselves, and the rulers take counsel together,Against the LORD, and against his anointed, saying, [^2] Let us break their bands asunder,And cast away their cords from us. [^3] He that sitteth in the heavens shall laugh:The Lord shall have them in derision. [^4] Then shall he speak unto them in his wrath,And vex them in his sore displeasure. [^5] Yet have I set my king upon my holy hill of Zion. [^6] I will declare the decree: the LORD hath said unto me,Thou art my Son; this day have I begotten thee. [^7] Ask of me, and I shall give thee the heathen for thine inheritance,And the uttermost parts of the earth for thy possession. [^8] Thou shalt break them with a rod of iron;Thou shalt dash them in pieces like a potter's vessel. [^9] Be wise now therefore, O ye kings:Be instructed, ye judges of the earth. [^10] Serve the LORD with fear,And rejoice with trembling. [^11] Kiss the Son, lest he be angry, and ye perish from the way,When his wrath is kindled but a little. Blessed are all they that put their trust in him. [^12] 

[[Psalms - 1|<--]] Psalms - 2 [[Psalms - 3|-->]]

---
# Notes
