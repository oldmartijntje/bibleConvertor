---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/psalms"
  - "#bible/testament/old"
aliases:
  - "Psalms - 1 - King James Version"
---
Psalms - 1 [[Psalms - 2|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Psalms]]

# Psalms - 1

Blessed is the man that walketh not in the counsel of the ungodly, nor standeth in the way of sinners,Nor sitteth in the seat of the scornful. [^1] But his delight is in the law of the LORD;And in his law doth he meditate day and night. [^2] And he shall be like a tree planted by the rivers of water,That bringeth forth his fruit in his season;His leaf also shall not wither;And whatsoever he doeth shall prosper. [^3] The ungodly are not so:But are like the chaff which the wind driveth away. [^4] Therefore the ungodly shall not stand in the judgment,Nor sinners in the congregation of the righteous. [^5] For the LORD knoweth the way of the righteous:But the way of the ungodly shall perish. [^6] 

Psalms - 1 [[Psalms - 2|-->]]

---
# Notes
