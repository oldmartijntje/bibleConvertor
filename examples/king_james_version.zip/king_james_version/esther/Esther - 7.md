---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 7 - King James Version"
---
[[Esther - 6|<--]] Esther - 7 [[Esther - 8|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Esther]]

# Esther - 7

So the king and Haman came to banquet with Esther the queen. [^1] And the king said again unto Esther on the second day at the banquet of wine, What is thy petition, queen Esther? and it shall be granted thee: and what is thy request? and it shall be performed, even to the half of the kingdom. [^2] Then Esther the queen answered and said, If I have found favour in thy sight, O king, and if it please the king, let my life be given me at my petition, and my people at my request: [^3] for we are sold, I and my people, to be destroyed, to be slain, and to perish. But if we had been sold for bondmen and bondwomen, I had held my tongue, although the enemy could not countervail the king's damage. [^4] Then the king Ahasuerus answered and said unto Esther the queen, Who is he, and where is he, that durst presume in his heart to do so? [^5] And Esther said, The adversary and enemy is this wicked Haman. Then Haman was afraid before the king and the queen. [^6] And the king arising from the banquet of wine in his wrath went into the palace garden: and Haman stood up to make request for his life to Esther the queen; for he saw that there was evil determined against him by the king. [^7] Then the king returned out of the palace garden into the place of the banquet of wine; and Haman was fallen upon the bed whereon Esther was. Then said the king, Will he force the queen also before me in the house? As the word went out of the king's mouth, they covered Haman's face. [^8] And Harbonah, one of the chamberlains, said before the king, Behold also, the gallows fifty cubits high, which Haman had made for Mordecai, who had spoken good for the king, standeth in the house of Haman. Then the king said, Hang him thereon. [^9] So they hanged Haman on the gallows that he had prepared for Mordecai. Then was the king's wrath pacified. [^10] 

[[Esther - 6|<--]] Esther - 7 [[Esther - 8|-->]]

---
# Notes
