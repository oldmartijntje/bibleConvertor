---
translation: King James Version
aliases:
  - "Esther - King James Version"
tags:
  - "#bible/type/book"
  - "#bible/book/esther"
  - "#bible/testament/old"
---
[[Nehemiah|<--]] Esther [[Job|-->]]

# Esther - King James Version

The Esther book has 10 chapters. It is part of the old testament.

## Chapters

- Esther [[Esther - 1|chapter 1]]
- Esther [[Esther - 2|chapter 2]]
- Esther [[Esther - 3|chapter 3]]
- Esther [[Esther - 4|chapter 4]]
- Esther [[Esther - 5|chapter 5]]
- Esther [[Esther - 6|chapter 6]]
- Esther [[Esther - 7|chapter 7]]
- Esther [[Esther - 8|chapter 8]]
- Esther [[Esther - 9|chapter 9]]
- Esther [[Esther - 10|chapter 10]]

[[Nehemiah|<--]] Esther [[Job|-->]]

---
# Notes
