---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 5 - King James Version"
---
[[Esther - 4|<--]] Esther - 5 [[Esther - 6|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Esther]]

# Esther - 5

Now it came to pass on the third day, that Esther put on her royal apparel, and stood in the inner court of the king's house, over against the king's house: and the king sat upon his royal throne in the royal house, over against the gate of the house. [^1] And it was so, when the king saw Esther the queen standing in the court, that she obtained favour in his sight: and the king held out to Esther the golden sceptre that was in his hand. So Esther drew near, and touched the top of the sceptre. [^2] Then said the king unto her, What wilt thou, queen Esther? and what is thy request? it shall be even given thee to the half of the kingdom. [^3] And Esther answered, If it seem good unto the king, let the king and Haman come this day unto the banquet that I have prepared for him. [^4] Then the king said, Cause Haman to make haste, that he may do as Esther hath said. So the king and Haman came to the banquet that Esther had prepared. [^5] And the king said unto Esther at the banquet of wine, What is thy petition? and it shall be granted thee: and what is thy request? even to the half of the kingdom it shall be performed. [^6] Then answered Esther, and said, My petition and my request is; [^7] if I have found favour in the sight of the king, and if it please the king to grant my petition, and to perform my request, let the king and Haman come to the banquet that I shall prepare for them, and I will do to morrow as the king hath said. [^8] Then went Haman forth that day joyful and with a glad heart: but when Haman saw Mordecai in the king's gate, that he stood not up, nor moved for him, he was full of indignation against Mordecai. [^9] Nevertheless Haman refrained himself: and when he came home, he sent and called for his friends, and Zeresh his wife. [^10] And Haman told them of the glory of his riches, and the multitude of his children, and all the things wherein the king had promoted him, and how he had advanced him above the princes and servants of the king. [^11] Haman said moreover, Yea, Esther the queen did let no man come in with the king unto the banquet that she had prepared but myself; and to morrow am I invited unto her also with the king. [^12] Yet all this availeth me nothing, so long as I see Mordecai the Jew sitting at the king's gate. [^13] Then said Zeresh his wife and all his friends unto him, Let a gallows be made of fifty cubits high, and to morrow speak thou unto the king that Mordecai may be hanged thereon: then go thou in merrily with the king unto the banquet. And the thing pleased Haman; and he caused the gallows to be made. [^14] 

[[Esther - 4|<--]] Esther - 5 [[Esther - 6|-->]]

---
# Notes
