---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 4 - King James Version"
---
[[Esther - 3|<--]] Esther - 4 [[Esther - 5|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Esther]]

# Esther - 4

When Mordecai perceived all that was done, Mordecai rent his clothes, and put on sackcloth with ashes, and went out into the midst of the city, and cried with a loud and a bitter cry; [^1] and came even before the king's gate: for none might enter into the king's gate clothed with sackcloth. [^2] And in every province, whithersoever the king's commandment and his decree came, there was great mourning among the Jews, and fasting, and weeping, and wailing; and many lay in sackcloth and ashes. [^3] So Esther's maids and her chamberlains came and told it her. Then was the queen exceedingly grieved; and she sent raiment to clothe Mordecai, and to take away his sackcloth from him: but he received it not. [^4] Then called Esther for Hatach, one of the king's chamberlains, whom he had appointed to attend upon her, and gave him a commandment to Mordecai, to know what it was, and why it was. [^5] So Hatach went forth to Mordecai unto the street of the city, which was before the king's gate. [^6] And Mordecai told him of all that had happened unto him, and of the sum of the money that Haman had promised to pay to the king's treasuries for the Jews, to destroy them. [^7] Also he gave him the copy of the writing of the decree that was given at Shushan to destroy them, to shew it unto Esther, and to declare it unto her, and to charge her that she should go in unto the king, to make supplication unto him, and to make request before him for her people. [^8] And Hatach came and told Esther the words of Mordecai. [^9] Again Esther spake unto Hatach, and gave him commandment unto Mordecai; [^10] all the king's servants, and the people of the king's provinces, do know, that whosoever, whether man or woman, shall come unto the king into the inner court, who is not called, there is one law of his to put him to death, except such to whom the king shall hold out the golden sceptre, that he may live: but I have not been called to come in unto the king these thirty days. [^11] And they told to Mordecai Esther's words. [^12] Then Mordecai commanded to answer Esther, Think not with thyself that thou shalt escape in the king's house, more than all the Jews. [^13] For if thou altogether holdest thy peace at this time, then shall there enlargement and deliverance arise to the Jews from another place; but thou and thy father's house shall be destroyed: and who knoweth whether thou art come to the kingdom for such a time as this? [^14] Then Esther bade them return Mordecai this answer, [^15] Go, gather together all the Jews that are present in Shushan, and fast ye for me, and neither eat nor drink three days, night or day: I also and my maidens will fast likewise; and so will I go in unto the king, which is not according to the law: and if I perish, I perish. [^16] So Mordecai went his way, and did according to all that Esther had commanded him. [^17] 

[[Esther - 3|<--]] Esther - 4 [[Esther - 5|-->]]

---
# Notes
