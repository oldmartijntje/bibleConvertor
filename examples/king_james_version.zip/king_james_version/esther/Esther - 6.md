---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 6 - King James Version"
---
[[Esther - 5|<--]] Esther - 6 [[Esther - 7|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Esther]]

# Esther - 6

On that night could not the king sleep, and he commanded to bring the book of records of the chronicles; and they were read before the king. [^1] And it was found written, that Mordecai had told of Bigthana and Teresh, two of the king's chamberlains, the keepers of the door, who sought to lay hand on the king Ahasuerus. [^2] And the king said, What honour and dignity hath been done to Mordecai for this? Then said the king's servants that ministered unto him, There is nothing done for him. [^3] And the king said, Who is in the court? Now Haman was come into the outward court of the king's house, to speak unto the king to hang Mordecai on the gallows that he had prepared for him. [^4] And the king's servants said unto him, Behold, Haman standeth in the court. And the king said, Let him come in. [^5] So Haman came in. And the king said unto him, What shall be done unto the man whom the king delighteth to honour? Now Haman thought in his heart, To whom would the king delight to do honour more than to myself? [^6] And Haman answered the king, For the man whom the king delighteth to honour, [^7] let the royal apparel be brought which the king useth to wear, and the horse that the king rideth upon, and the crown royal which is set upon his head: [^8] and let this apparel and horse be delivered to the hand of one of the king's most noble princes, that they may array the man withal whom the king delighteth to honour, and bring him on horseback through the street of the city, and proclaim before him, Thus shall it be done to the man whom the king delighteth to honour. [^9] Then the king said to Haman, Make haste, and take the apparel and the horse, as thou hast said, and do even so to Mordecai the Jew, that sitteth at the king's gate: let nothing fail of all that thou hast spoken. [^10] Then took Haman the apparel and the horse, and arrayed Mordecai, and brought him on horseback through the street of the city, and proclaimed before him, Thus shall it be done unto the man whom the king delighteth to honour. [^11] And Mordecai came again to the king's gate. But Haman hasted to his house mourning, and having his head covered. [^12] And Haman told Zeresh his wife and all his friends every thing that had befallen him. Then said his wise men and Zeresh his wife unto him, If Mordecai be of the seed of the Jews, before whom thou hast begun to fall, thou shalt not prevail against him, but shalt surely fall before him. [^13] And while they were yet talking with him, came the king's chamberlains, and hasted to bring Haman unto the banquet that Esther had prepared. [^14] 

[[Esther - 5|<--]] Esther - 6 [[Esther - 7|-->]]

---
# Notes
