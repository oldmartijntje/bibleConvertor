---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 10 - King James Version"
---
[[Esther - 9|<--]] Esther - 10

Translation: [[bible - King James Version|King James Version]]
Book: [[Esther]]

# Esther - 10

And the king Ahasuerus laid a tribute upon the land, and upon the isles of the sea. [^1] And all the acts of his power and of his might, and the declaration of the greatness of Mordecai, whereunto the king advanced him, are they not written in the book of the chronicles of the kings of Media and Persia? [^2] For Mordecai the Jew was next unto king Ahasuerus, and great among the Jews, and accepted of the multitude of his brethren, seeking the wealth of his people, and speaking peace to all his seed. [^3] 

[[Esther - 9|<--]] Esther - 10

---
# Notes
