---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 1 - King James Version"
---
Esther - 1 [[Esther - 2|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Esther]]

# Esther - 1

Now it came to pass in the days of Ahasuerus, (this is Ahasuerus which reigned, from India even unto Ethiopia, over an hundred and seven and twenty provinces:) [^1] that in those days, when the king Ahasuerus sat on the throne of his kingdom, which was in Shushan the palace, [^2] in the third year of his reign, he made a feast unto all his princes and his servants; the power of Persia and Media, the nobles and princes of the provinces, being before him: [^3] when he shewed the riches of his glorious kingdom and the honour of his excellent majesty many days, even an hundred and fourscore days. [^4] And when these days were expired, the king made a feast unto all the people that were present in Shushan the palace, both unto great and small, seven days, in the court of the garden of the king's palace; [^5] where were white, green, and blue, hangings, fastened with cords of fine linen and purple to silver rings and pillars of marble: the beds were of gold and silver, upon a pavement of red, and blue, and white, and black, marble. [^6] And they gave them drink in vessels of gold, (the vessels being diverse one from another,) and royal wine in abundance, according to the state of the king. [^7] And the drinking was according to the law; none did compel: for so the king had appointed to all the officers of his house, that they should do according to every man's pleasure. [^8] Also Vashti the queen made a feast for the women in the royal house which belonged to king Ahasuerus. [^9] On the seventh day, when the heart of the king was merry with wine, he commanded Mehuman, Biztha, Harbona, Bigtha, and Abagtha, Zethar, and Carcas, the seven chamberlains that served in the presence of Ahasuerus the king, [^10] to bring Vashti the queen before the king with the crown royal, to shew the people and the princes her beauty: for she was fair to look on. [^11] But the queen Vashti refused to come at the king's commandment by his chamberlains: therefore was the king very wroth, and his anger burned in him. [^12] Then the king said to the wise men, which knew the times, (for so was the king's manner toward all that knew law and judgment: [^13] and the next unto him was Carshena, Shethar, Admatha, Tarshish, Meres, Marsena, and Memucan, the seven princes of Persia and Media, which saw the king's face, and which sat the first in the kingdom;) [^14] what shall we do unto the queen Vashti according to law, because she hath not performed the commandment of the king Ahasuerus by the chamberlains? [^15] And Memucan answered before the king and the princes, Vashti the queen hath not done wrong to the king only, but also to all the princes, and to all the people that are in all the provinces of the king Ahasuerus. [^16] For this deed of the queen shall come abroad unto all women, so that they shall despise their husbands in their eyes, when it shall be reported, The king Ahasuerus commanded Vashti the queen to be brought in before him, but she came not. [^17] Likewise shall the ladies of Persia and Media say this day unto all the king's princes, which have heard of the deed of the queen. Thus shall there arise too much contempt and wrath. [^18] If it please the king, let there go a royal commandment from him, and let it be written among the laws of the Persians and the Medes, that it be not altered, That Vashti come no more before king Ahasuerus; and let the king give her royal estate unto another that is better than she. [^19] And when the king's decree which he shall make shall be published throughout all his empire, (for it is great,) all the wives shall give to their husbands honour, both to great and small. [^20] And the saying pleased the king and the princes; and the king did according to the word of Memucan: [^21] for he sent letters into all the king's provinces, into every province according to the writing thereof, and to every people after their language, that every man should bear rule in his own house, and that it should be published according to the language of every people. [^22] 

Esther - 1 [[Esther - 2|-->]]

---
# Notes
