---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/esther"
  - "#bible/testament/old"
aliases:
  - "Esther - 3 - King James Version"
---
[[Esther - 2|<--]] Esther - 3 [[Esther - 4|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Esther]]

# Esther - 3

After these things did king Ahasuerus promote Haman the son of Hammedatha the Agagite, and advanced him, and set his seat above all the princes that were with him. [^1] And all the king's servants, that were in the king's gate, bowed, and reverenced Haman: for the king had so commanded concerning him. But Mordecai bowed not, nor did him reverence. [^2] Then the king's servants, which were in the king's gate, said unto Mordecai, Why transgressest thou the king's commandment? [^3] Now it came to pass, when they spake daily unto him, and he hearkened not unto them, that they told Haman, to see whether Mordecai's matters would stand: for he had told them that he was a Jew. [^4] And when Haman saw that Mordecai bowed not, nor did him reverence, then was Haman full of wrath. [^5] And he thought scorn to lay hands on Mordecai alone; for they had shewed him the people of Mordecai: wherefore Haman sought to destroy all the Jews that were throughout the whole kingdom of Ahasuerus, even the people of Mordecai. [^6] In the first month, that is, the month Nisan, in the twelfth year of king Ahasuerus, they cast Pur, that is, the lot, before Haman from day to day, and from month to month, to the twelfth month, that is, the month Adar. [^7] And Haman said unto king Ahasuerus, There is a certain people scattered abroad and dispersed among the people in all the provinces of thy kingdom; and their laws are diverse from all people; neither keep they the king's laws: therefore it is not for the king's profit to suffer them. [^8] If it please the king, let it be written that they may be destroyed: and I will pay ten thousand talents of silver to the hands of those that have the charge of the business, to bring it into the king's treasuries. [^9] And the king took his ring from his hand, and gave it unto Haman the son of Hammedatha the Agagite, the Jews' enemy. [^10] And the king said unto Haman, The silver is given to thee, the people also, to do with them as it seemeth good to thee. [^11] Then were the king's scribes called on the thirteenth day of the first month, and there was written according to all that Haman had commanded unto the king's lieutenants, and to the governors that were over every province, and to the rulers of every people of every province according to the writing thereof, and to every people after their language; in the name of king Ahasuerus was it written, and sealed with the king's ring. [^12] And the letters were sent by posts into all the king's provinces, to destroy, to kill, and to cause to perish, all Jews, both young and old, little children and women, in one day, even upon the thirteenth day of the twelfth month, which is the month Adar, and to take the spoil of them for a prey. [^13] The copy of the writing for a commandment to be given in every province was published unto all people, that they should be ready against that day. [^14] The posts went out, being hastened by the king's commandment, and the decree was given in Shushan the palace. And the king and Haman sat down to drink; but the city Shushan was perplexed. [^15] 

[[Esther - 2|<--]] Esther - 3 [[Esther - 4|-->]]

---
# Notes
