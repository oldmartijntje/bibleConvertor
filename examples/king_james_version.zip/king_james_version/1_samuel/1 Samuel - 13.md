---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 13 - King James Version"
---
[[1 Samuel - 12|<--]] 1 Samuel - 13 [[1 Samuel - 14|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[1 Samuel]]

# 1 Samuel - 13

Saul reigned one year; and when he had reigned two years over Israel, [^1] Saul chose him three thousand men of Israel; whereof two thousand were with Saul in Michmash and in mount Beth-el, and a thousand were with Jonathan in Gibeah of Benjamin: and the rest of the people he sent every man to his tent. [^2] And Jonathan smote the garrison of the Philistines that was in Geba, and the Philistines heard of it. And Saul blew the trumpet throughout all the land, saying, Let the Hebrews hear. [^3] And all Israel heard say that Saul had smitten a garrison of the Philistines, and that Israel also was had in abomination with the Philistines. And the people were called together after Saul to Gilgal. [^4] And the Philistines gathered themselves together to fight with Israel, thirty thousand chariots, and six thousand horsemen, and people as the sand which is on the sea shore in multitude: and they came up, and pitched in Michmash, eastward from Beth-aven. [^5] When the men of Israel saw that they were in a strait, (for the people were distressed,) then the people did hide themselves in caves, and in thickets, and in rocks, and in high places, and in pits. [^6] And some of the Hebrews went over Jordan to the land of Gad and Gilead. As for Saul, he was yet in Gilgal, and all the people followed him trembling. [^7] And he tarried seven days, according to the set time that Samuel had appointed: but Samuel came not to Gilgal; and the people were scattered from him. [^8] And Saul said, Bring hither a burnt offering to me, and peace offerings. And he offered the burnt offering. [^9] And it came to pass, that as soon as he had made an end of offering the burnt offering, behold, Samuel came; and Saul went out to meet him, that he might salute him. [^10] And Samuel said, What hast thou done? And Saul said, Because I saw that the people were scattered from me, and that thou camest not within the days appointed, and that the Philistines gathered themselves together at Michmash; [^11] therefore said I, The Philistines will come down now upon me to Gilgal, and I have not made supplication unto the LORD: I forced myself therefore, and offered a burnt offering. [^12] And Samuel said to Saul, Thou hast done foolishly: thou hast not kept the commandment of the LORD thy God, which he commanded thee: for now would the LORD have established thy kingdom upon Israel for ever. [^13] But now thy kingdom shall not continue: the LORD hath sought him a man after his own heart, and the LORD hath commanded him to be captain over his people, because thou hast not kept that which the LORD commanded thee. [^14] And Samuel arose, and gat him up from Gilgal unto Gibeah of Benjamin. And Saul numbered the people that were present with him, about six hundred men. [^15] And Saul, and Jonathan his son, and the people that were present with them, abode in Gibeah of Benjamin: but the Philistines encamped in Michmash. [^16] And the spoilers came out of the camp of the Philistines in three companies: one company turned unto the way that leadeth to Ophrah, unto the land of Shual: [^17] and another company turned the way to Beth-horon: and another company turned to the way of the border that looketh to the valley of Zeboim toward the wilderness. [^18] Now there was no smith found throughout all the land of Israel: for the Philistines said, Lest the Hebrews make them swords or spears: [^19] but all the Israelites went down to the Philistines, to sharpen every man his share, and his coulter, and his axe, and his mattock. [^20] Yet they had a file for the mattocks, and for the coulters, and for the forks, and for the axes, and to sharpen the goads. [^21] So it came to pass in the day of battle, that there was neither sword nor spear found in the hand of any of the people that were with Saul and Jonathan: but with Saul and with Jonathan his son was there found. [^22] And the garrison of the Philistines went out to the passage of Michmash. [^23] 

[[1 Samuel - 12|<--]] 1 Samuel - 13 [[1 Samuel - 14|-->]]

---
# Notes
