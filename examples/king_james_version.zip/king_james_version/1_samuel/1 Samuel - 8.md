---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 8 - King James Version"
---
[[1 Samuel - 7|<--]] 1 Samuel - 8 [[1 Samuel - 9|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[1 Samuel]]

# 1 Samuel - 8

And it came to pass, when Samuel was old, that he made his sons judges over Israel. [^1] Now the name of his firstborn was Joel; and the name of his second, Abiah: they were judges in Beer-sheba. [^2] And his sons walked not in his ways, but turned aside after lucre, and took bribes, and perverted judgment. [^3] Then all the elders of Israel gathered themselves together, and came to Samuel unto Ramah, [^4] and said unto him, Behold, thou art old, and thy sons walk not in thy ways: now make us a king to judge us like all the nations. [^5] But the thing displeased Samuel, when they said, Give us a king to judge us. And Samuel prayed unto the LORD. [^6] And the LORD said unto Samuel, Hearken unto the voice of the people in all that they say unto thee: for they have not rejected thee, but they have rejected me, that I should not reign over them. [^7] According to all the works which they have done since the day that I brought them up out of Egypt even unto this day, wherewith they have forsaken me, and served other gods, so do they also unto thee. [^8] Now therefore hearken unto their voice: howbeit yet protest solemnly unto them, and shew them the manner of the king that shall reign over them. [^9] And Samuel told all the words of the LORD unto the people that asked of him a king. [^10] And he said, This will be the manner of the king that shall reign over you: He will take your sons, and appoint them for himself, for his chariots, and to be his horsemen; and some shall run before his chariots. [^11] And he will appoint him captains over thousands, and captains over fifties; and will set them to ear his ground, and to reap his harvest, and to make his instruments of war, and instruments of his chariots. [^12] And he will take your daughters to be confectionaries, and to be cooks, and to be bakers. [^13] And he will take your fields, and your vineyards, and your oliveyards, even the best of them, and give them to his servants. [^14] And he will take the tenth of your seed, and of your vineyards, and give to his officers, and to his servants. [^15] And he will take your menservants, and your maidservants, and your goodliest young men, and your asses, and put them to his work. [^16] He will take the tenth of your sheep: and ye shall be his servants. [^17] And ye shall cry out in that day because of your king which ye shall have chosen you; and the LORD will not hear you in that day. [^18] Nevertheless the people refused to obey the voice of Samuel; and they said, Nay; but we will have a king over us; [^19] that we also may be like all the nations; and that our king may judge us, and go out before us, and fight our battles. [^20] And Samuel heard all the words of the people, and he rehearsed them in the ears of the LORD. [^21] And the LORD said to Samuel, Hearken unto their voice, and make them a king. And Samuel said unto the men of Israel, Go ye every man unto his city. [^22] 

[[1 Samuel - 7|<--]] 1 Samuel - 8 [[1 Samuel - 9|-->]]

---
# Notes
