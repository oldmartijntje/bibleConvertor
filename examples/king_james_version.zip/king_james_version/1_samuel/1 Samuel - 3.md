---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 3 - King James Version"
---
[[1 Samuel - 2|<--]] 1 Samuel - 3 [[1 Samuel - 4|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[1 Samuel]]

# 1 Samuel - 3

And the child Samuel ministered unto the LORD before Eli. And the word of the LORD was precious in those days; there was no open vision. [^1] And it came to pass at that time, when Eli was laid down in his place, and his eyes began to wax dim, that he could not see; [^2] and ere the lamp of God went out in the temple of the LORD, where the ark of God was, and Samuel was laid down to sleep; [^3] that the LORD called Samuel: and he answered, Here am I. [^4] And he ran unto Eli, and said, Here am I; for thou calledst me. And he said, I called not; lie down again. And he went and lay down. [^5] And the LORD called yet again, Samuel. And Samuel arose and went to Eli, and said, Here am I; for thou didst call me. And he answered, I called not, my son; lie down again. [^6] Now Samuel did not yet know the LORD, neither was the word of the LORD yet revealed unto him. [^7] And the LORD called Samuel again the third time. And he arose and went to Eli, and said, Here am I; for thou didst call me. And Eli perceived that the LORD had called the child. [^8] Therefore Eli said unto Samuel, Go, lie down: and it shall be, if he call thee, that thou shalt say, Speak, LORD; for thy servant heareth. So Samuel went and lay down in his place. [^9] And the LORD came, and stood, and called as at other times, Samuel, Samuel. Then Samuel answered, Speak; for thy servant heareth. [^10] And the LORD said to Samuel, Behold, I will do a thing in Israel, at which both the ears of every one that heareth it shall tingle. [^11] In that day I will perform against Eli all things which I have spoken concerning his house: when I begin, I will also make an end. [^12] For I have told him that I will judge his house for ever for the iniquity which he knoweth; because his sons made themselves vile, and he restrained them not. [^13] And therefore I have sworn unto the house of Eli, that the iniquity of Eli's house shall not be purged with sacrifice nor offering for ever. [^14] And Samuel lay until the morning, and opened the doors of the house of the LORD. And Samuel feared to shew Eli the vision. [^15] Then Eli called Samuel, and said, Samuel, my son. And he answered, Here am I. [^16] And he said, What is the thing that the LORD hath said unto thee? I pray thee hide it not from me: God do so to thee, and more also, if thou hide any thing from me of all the things that he said unto thee. [^17] And Samuel told him every whit, and hid nothing from him. And he said, It is the LORD: let him do what seemeth him good. [^18] And Samuel grew, and the LORD was with him, and did let none of his words fall to the ground. [^19] And all Israel from Dan even to Beer-sheba knew that Samuel was established to be a prophet of the LORD. [^20] And the LORD appeared again in Shiloh: for the LORD revealed himself to Samuel in Shiloh by the word of the LORD. [^21] 

[[1 Samuel - 2|<--]] 1 Samuel - 3 [[1 Samuel - 4|-->]]

---
# Notes
