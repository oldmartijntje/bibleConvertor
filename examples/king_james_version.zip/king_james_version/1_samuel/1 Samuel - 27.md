---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 27 - King James Version"
---
[[1 Samuel - 26|<--]] 1 Samuel - 27 [[1 Samuel - 28|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[1 Samuel]]

# 1 Samuel - 27

And David said in his heart, I shall now perish one day by the hand of Saul: there is nothing better for me than that I should speedily escape into the land of the Philistines; and Saul shall despair of me, to seek me any more in any coast of Israel: so shall I escape out of his hand. [^1] And David arose, and he passed over with the six hundred men that were with him unto Achish, the son of Maoch, king of Gath. [^2] And David dwelt with Achish at Gath, he and his men, every man with his household, even David with his two wives, Ahinoam the Jezreelitess, and Abigail the Carmelitess, Nabal's wife. [^3] And it was told Saul that David was fled to Gath: and he sought no more again for him. [^4] And David said unto Achish, If I have now found grace in thine eyes, let them give me a place in some town in the country, that I may dwell there: for why should thy servant dwell in the royal city with thee? [^5] Then Achish gave him Ziklag that day: wherefore Ziklag pertaineth unto the kings of Judah unto this day. [^6] And the time that David dwelt in the country of the Philistines was a full year and four months. [^7] And David and his men went up, and invaded the Geshurites, and the Gezrites, and the Amalekites: for those nations were of old the inhabitants of the land, as thou goest to Shur, even unto the land of Egypt. [^8] And David smote the land, and left neither man nor woman alive, and took away the sheep, and the oxen, and the asses, and the camels, and the apparel, and returned, and came to Achish. [^9] And Achish said, Whither have ye made a road to day? And David said, Against the south of Judah, and against the south of the Jerahmeelites, and against the south of the Kenites. [^10] And David saved neither man nor woman alive, to bring tidings to Gath, saying, Lest they should tell on us, saying, So did David, and so will be his manner all the while he dwelleth in the country of the Philistines. [^11] And Achish believed David, saying, He hath made his people Israel utterly to abhor him; therefore he shall be my servant for ever. [^12] 

[[1 Samuel - 26|<--]] 1 Samuel - 27 [[1 Samuel - 28|-->]]

---
# Notes
