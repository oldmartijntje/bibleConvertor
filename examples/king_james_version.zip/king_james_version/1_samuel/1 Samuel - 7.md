---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 7 - King James Version"
---
[[1 Samuel - 6|<--]] 1 Samuel - 7 [[1 Samuel - 8|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[1 Samuel]]

# 1 Samuel - 7

And the men of Kirjath-jearim came, and fetched up the ark of the LORD, and brought it into the house of Abinadab in the hill, and sanctified Eleazar his son to keep the ark of the LORD. [^1] And it came to pass, while the ark abode in Kirjath-jearim, that the time was long; for it was twenty years: and all the house of Israel lamented after the LORD. [^2] And Samuel spake unto all the house of Israel, saying, If ye do return unto the LORD with all your hearts, then put away the strange gods and Ashtaroth from among you, and prepare your hearts unto the LORD, and serve him only: and he will deliver you out of the hand of the Philistines. [^3] Then the children of Israel did put away Baalim and Ashtaroth, and served the LORD only. [^4] And Samuel said, Gather all Israel to Mizpeh, and I will pray for you unto the LORD. [^5] And they gathered together to Mizpeh, and drew water, and poured it out before the LORD, and fasted on that day, and said there, We have sinned against the LORD. And Samuel judged the children of Israel in Mizpeh. [^6] And when the Philistines heard that the children of Israel were gathered together to Mizpeh, the lords of the Philistines went up against Israel. And when the children of Israel heard it, they were afraid of the Philistines. [^7] And the children of Israel said to Samuel, Cease not to cry unto the LORD our God for us, that he will save us out of the hand of the Philistines. [^8] And Samuel took a sucking lamb, and offered it for a burnt offering wholly unto the LORD: and Samuel cried unto the LORD for Israel; and the LORD heard him. [^9] And as Samuel was offering up the burnt offering, the Philistines drew near to battle against Israel: but the LORD thundered with a great thunder on that day upon the Philistines, and discomfited them; and they were smitten before Israel. [^10] And the men of Israel went out of Mizpeh, and pursued the Philistines, and smote them, until they came under Beth-car. [^11] Then Samuel took a stone, and set it between Mizpeh and Shen, and called the name of it Eben-ezer, saying, Hitherto hath the LORD helped us. [^12] So the Philistines were subdued, and they came no more into the coast of Israel: and the hand of the LORD was against the Philistines all the days of Samuel. [^13] And the cities which the Philistines had taken from Israel were restored to Israel, from Ekron even unto Gath; and the coasts thereof did Israel deliver out of the hands of the Philistines. And there was peace between Israel and the Amorites. [^14] And Samuel judged Israel all the days of his life. [^15] And he went from year to year in circuit to Beth-el, and Gilgal, and Mizpeh, and judged Israel in all those places. [^16] And his return was to Ramah; for there was his house; and there he judged Israel; and there he built an altar unto the LORD. [^17] 

[[1 Samuel - 6|<--]] 1 Samuel - 7 [[1 Samuel - 8|-->]]

---
# Notes
