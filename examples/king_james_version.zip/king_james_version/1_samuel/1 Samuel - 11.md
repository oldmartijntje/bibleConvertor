---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_samuel"
  - "#bible/testament/old"
aliases:
  - "1 Samuel - 11 - King James Version"
---
[[1 Samuel - 10|<--]] 1 Samuel - 11 [[1 Samuel - 12|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[1 Samuel]]

# 1 Samuel - 11

Then Nahash the Ammonite came up, and encamped against Jabesh-gilead: and all the men of Jabesh said unto Nahash, Make a covenant with us, and we will serve thee. [^1] And Nahash the Ammonite answered them, On this condition will I make a covenant with you, that I may thrust out all your right eyes, and lay it for a reproach upon all Israel. [^2] And the elders of Jabesh said unto him, Give us seven days' respite, that we may send messengers unto all the coasts of Israel: and then, if there be no man to save us, we will come out to thee. [^3] Then came the messengers to Gibeah of Saul, and told the tidings in the ears of the people: and all the people lifted up their voices, and wept. [^4] And, behold, Saul came after the herd out of the field; and Saul said, What aileth the people that they weep? And they told him the tidings of the men of Jabesh. [^5] And the Spirit of God came upon Saul when he heard those tidings, and his anger was kindled greatly. [^6] And he took a yoke of oxen, and hewed them in pieces, and sent them throughout all the coasts of Israel by the hands of messengers, saying, Whosoever cometh not forth after Saul and after Samuel, so shall it be done unto his oxen. And the fear of the LORD fell on the people, and they came out with one consent. [^7] And when he numbered them in Bezek, the children of Israel were three hundred thousand, and the men of Judah thirty thousand. [^8] And they said unto the messengers that came, Thus shall ye say unto the men of Jabesh-gilead, To morrow, by that time the sun be hot, ye shall have help. And the messengers came and shewed it to the men of Jabesh; and they were glad. [^9] Therefore the men of Jabesh said, To morrow we will come out unto you, and ye shall do with us all that seemeth good unto you. [^10] And it was so on the morrow, that Saul put the people in three companies; and they came into the midst of the host in the morning watch, and slew the Ammonites until the heat of the day: and it came to pass, that they which remained were scattered, so that two of them were not left together. [^11] And the people said unto Samuel, Who is he that said, Shall Saul reign over us? bring the men, that we may put them to death. [^12] And Saul said, There shall not a man be put to death this day: for to day the LORD hath wrought salvation in Israel. [^13] Then said Samuel to the people, Come, and let us go to Gilgal, and renew the kingdom there. [^14] And all the people went to Gilgal; and there they made Saul king before the LORD in Gilgal; and there they sacrificed sacrifices of peace offerings before the LORD; and there Saul and all the men of Israel rejoiced greatly. [^15] 

[[1 Samuel - 10|<--]] 1 Samuel - 11 [[1 Samuel - 12|-->]]

---
# Notes
