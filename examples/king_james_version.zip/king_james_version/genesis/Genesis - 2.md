---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 2 - King James Version"
---
[[Genesis - 1|<--]] Genesis - 2 [[Genesis - 3|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Genesis]]

# Genesis - 2

Thus the heavens and the earth were finished, and all the host of them. [^1] And on the seventh day God ended his work which he had made; and he rested on the seventh day from all his work which he had made. [^2] And God blessed the seventh day, and sanctified it: because that in it he had rested from all his work which God created and made. [^3] These are the generations of the heavens and of the earth when they were created, in the day that the LORD God made the earth and the heavens, [^4] and every plant of the field before it was in the earth, and every herb of the field before it grew: for the LORD God had not caused it to rain upon the earth, and there was not a man to till the ground. [^5] But there went up a mist from the earth, and watered the whole face of the ground. [^6] And the LORD God formed man of the dust of the ground, and breathed into his nostrils the breath of life; and man became a living soul. [^7] And the LORD God planted a garden eastward in Eden; and there he put the man whom he had formed. [^8] And out of the ground made the LORD God to grow every tree that is pleasant to the sight, and good for food; the tree of life also in the midst of the garden, and the tree of knowledge of good and evil. [^9] And a river went out of Eden to water the garden; and from thence it was parted, and became into four heads. [^10] The name of the first is Pison: that is it which compasseth the whole land of Havilah, where there is gold; [^11] and the gold of that land is good: there is bdellium and the onyx stone. [^12] And the name of the second river is Gihon: the same is it that compasseth the whole land of Ethiopia. [^13] And the name of the third river is Hiddekel: that is it which goeth toward the east of Assyria. And the fourth river is Euphrates. [^14] And the LORD God took the man, and put him into the garden of Eden to dress it and to keep it. [^15] And the LORD God commanded the man, saying, Of every tree of the garden thou mayest freely eat: [^16] but of the tree of the knowledge of good and evil, thou shalt not eat of it: for in the day that thou eatest thereof thou shalt surely die. [^17] And the LORD God said, It is not good that the man should be alone; I will make him an help meet for him. [^18] And out of the ground the LORD God formed every beast of the field, and every fowl of the air; and brought them unto Adam to see what he would call them: and whatsoever Adam called every living creature, that was the name thereof. [^19] And Adam gave names to all cattle, and to the fowl of the air, and to every beast of the field; but for Adam there was not found an help meet for him. [^20] And the LORD God caused a deep sleep to fall upon Adam, and he slept: and he took one of his ribs, and closed up the flesh instead thereof; [^21] and the rib, which the LORD God had taken from man, made he a woman, and brought her unto the man. [^22] And Adam said, This is now bone of my bones, and flesh of my flesh: she shall be called Woman, because she was taken out of Man. [^23] Therefore shall a man leave his father and his mother, and shall cleave unto his wife: and they shall be one flesh. [^24] And they were both naked, the man and his wife, and were not ashamed. [^25] 

[[Genesis - 1|<--]] Genesis - 2 [[Genesis - 3|-->]]

---
# Notes
