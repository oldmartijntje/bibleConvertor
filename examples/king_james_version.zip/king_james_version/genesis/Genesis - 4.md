---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 4 - King James Version"
---
[[Genesis - 3|<--]] Genesis - 4 [[Genesis - 5|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Genesis]]

# Genesis - 4

And Adam knew Eve his wife; and she conceived, and bare Cain, and said, I have gotten a man from the LORD. [^1] And she again bare his brother Abel. And Abel was a keeper of sheep, but Cain was a tiller of the ground. [^2] And in process of time it came to pass, that Cain brought of the fruit of the ground an offering unto the LORD. [^3] And Abel, he also brought of the firstlings of his flock and of the fat thereof. And the LORD had respect unto Abel and to his offering: [^4] but unto Cain and to his offering he had not respect. And Cain was very wroth, and his countenance fell. [^5] And the LORD said unto Cain, Why art thou wroth? and why is thy countenance fallen? [^6] If thou doest well, shalt thou not be accepted? and if thou doest not well, sin lieth at the door. And unto thee shall be his desire, and thou shalt rule over him. [^7] And Cain talked with Abel his brother: and it came to pass, when they were in the field, that Cain rose up against Abel his brother, and slew him. [^8] And the LORD said unto Cain, Where is Abel thy brother? And he said, I know not: Am I my brother's keeper? [^9] And he said, What hast thou done? the voice of thy brother's blood crieth unto me from the ground. [^10] And now art thou cursed from the earth, which hath opened her mouth to receive thy brother's blood from thy hand; [^11] when thou tillest the ground, it shall not henceforth yield unto thee her strength; a fugitive and a vagabond shalt thou be in the earth. [^12] And Cain said unto the LORD, My punishment is greater than I can bear. [^13] Behold, thou hast driven me out this day from the face of the earth; and from thy face shall I be hid; and I shall be a fugitive and a vagabond in the earth; and it shall come to pass, that every one that findeth me shall slay me. [^14] And the LORD said unto him, Therefore whosoever slayeth Cain, vengeance shall be taken on him sevenfold. And the LORD set a mark upon Cain, lest any finding him should kill him. [^15] And Cain went out from the presence of the LORD, and dwelt in the land of Nod, on the east of Eden. [^16] And Cain knew his wife; and she conceived, and bare Enoch: and he builded a city, and called the name of the city, after the name of his son, Enoch. [^17] And unto Enoch was born Irad: and Irad begat Mehujael: and Mehujael begat Methusael: and Methusael begat Lamech. [^18] And Lamech took unto him two wives: the name of the one was Adah, and the name of the other Zillah. [^19] And Adah bare Jabal: he was the father of such as dwell in tents, and of such as have cattle. [^20] And his brother's name was Jubal: he was the father of all such as handle the harp and organ. [^21] And Zillah, she also bare Tubal-cain, an instructer of every artificer in brass and iron: and the sister of Tubal-cain was Naamah. [^22] And Lamech said unto his wives,Adah and Zillah, Hear my voice;Ye wives of Lamech, hearken unto my speech:For I have slain a man to my wounding,And a young man to my hurt. [^23] If Cain shall be avenged sevenfold,Truly Lamech seventy and sevenfold. [^24] And Adam knew his wife again; and she bare a son, and called his name Seth: For God, said she, hath appointed me another seed instead of Abel, whom Cain slew. [^25] And to Seth, to him also there was born a son; and he called his name Enos: then began men to call upon the name of the LORD. [^26] 

[[Genesis - 3|<--]] Genesis - 4 [[Genesis - 5|-->]]

---
# Notes
