---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 22 - King James Version"
---
[[Genesis - 21|<--]] Genesis - 22 [[Genesis - 23|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Genesis]]

# Genesis - 22

And it came to pass after these things, that God did tempt Abraham, and said unto him, Abraham: and he said, Behold, here I am. [^1] And he said, Take now thy son, thine only son Isaac, whom thou lovest, and get thee into the land of Moriah; and offer him there for a burnt offering upon one of the mountains which I will tell thee of. [^2] And Abraham rose up early in the morning, and saddled his ass, and took two of his young men with him, and Isaac his son, and clave the wood for the burnt offering, and rose up, and went unto the place of which God had told him. [^3] Then on the third day Abraham lifted up his eyes, and saw the place afar off. [^4] And Abraham said unto his young men, Abide ye here with the ass; and I and the lad will go yonder and worship, and come again to you. [^5] And Abraham took the wood of the burnt offering, and laid it upon Isaac his son; and he took the fire in his hand, and a knife; and they went both of them together. [^6] And Isaac spake unto Abraham his father, and said, My father: and he said, Here am I, my son. And he said, Behold the fire and the wood: but where is the lamb for a burnt offering? [^7] And Abraham said, My son, God will provide himself a lamb for a burnt offering: so they went both of them together. [^8] And they came to the place which God had told him of; and Abraham built an altar there, and laid the wood in order, and bound Isaac his son, and laid him on the altar upon the wood. [^9] And Abraham stretched forth his hand, and took the knife to slay his son. [^10] And the angel of the LORD called unto him out of heaven, and said, Abraham, Abraham: and he said, Here am I. [^11] And he said, Lay not thine hand upon the lad, neither do thou any thing unto him: for now I know that thou fearest God, seeing thou hast not withheld thy son, thine only son from me. [^12] And Abraham lifted up his eyes, and looked, and behold behind him a ram caught in a thicket by his horns: and Abraham went and took the ram, and offered him up for a burnt offering in the stead of his son. [^13] And Abraham called the name of that place Jehovah-jireh: as it is said to this day, In the mount of the LORD it shall be seen. [^14] And the angel of the LORD called unto Abraham out of heaven the second time, [^15] and said, By myself have I sworn, saith the LORD, for because thou hast done this thing, and hast not withheld thy son, thine only son: [^16] that in blessing I will bless thee, and in multiplying I will multiply thy seed as the stars of the heaven, and as the sand which is upon the sea shore; and thy seed shall possess the gate of his enemies; [^17] and in thy seed shall all the nations of the earth be blessed; because thou hast obeyed my voice. [^18] So Abraham returned unto his young men, and they rose up and went together to Beer-sheba; and Abraham dwelt at Beer-sheba. [^19] And it came to pass after these things, that it was told Abraham, saying, Behold, Milcah, she hath also born children unto thy brother Nahor; [^20] Huz his firstborn, and Buz his brother, and Kemuel the father of Aram, [^21] and Chesed, and Hazo, and Pildash, and Jidlaph, and Bethuel. [^22] And Bethuel begat Rebekah: these eight Milcah did bear to Nahor, Abraham's brother. [^23] And his concubine, whose name was Reumah, she bare also Tebah, and Gaham, and Thahash, and Maachah. [^24] 

[[Genesis - 21|<--]] Genesis - 22 [[Genesis - 23|-->]]

---
# Notes
