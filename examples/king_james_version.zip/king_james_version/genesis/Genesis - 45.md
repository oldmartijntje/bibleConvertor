---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 45 - King James Version"
---
[[Genesis - 44|<--]] Genesis - 45 [[Genesis - 46|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Genesis]]

# Genesis - 45

Then Joseph could not refrain himself before all them that stood by him; and he cried, Cause every man to go out from me. And there stood no man with him, while Joseph made himself known unto his brethren. [^1] And he wept aloud: and the Egyptians and the house of Pharaoh heard. [^2] And Joseph said unto his brethren, I am Joseph; doth my father yet live? And his brethren could not answer him; for they were troubled at his presence. [^3] And Joseph said unto his brethren, Come near to me, I pray you. And they came near. And he said, I am Joseph your brother, whom ye sold into Egypt. [^4] Now therefore be not grieved, nor angry with yourselves, that ye sold me hither: for God did send me before you to preserve life. [^5] For these two years hath the famine been in the land: and yet there are five years, in the which there shall neither be earing nor harvest. [^6] And God sent me before you to preserve you a posterity in the earth, and to save your lives by a great deliverance. [^7] So now it was not you that sent me hither, but God: and he hath made me a father to Pharaoh, and lord of all his house, and a ruler throughout all the land of Egypt. [^8] Haste ye, and go up to my father, and say unto him, Thus saith thy son Joseph, God hath made me lord of all Egypt: come down unto me, tarry not: [^9] and thou shalt dwell in the land of Goshen, and thou shalt be near unto me, thou, and thy children, and thy children's children, and thy flocks, and thy herds, and all that thou hast: [^10] and there will I nourish thee; for yet there are five years of famine; lest thou, and thy household, and all that thou hast, come to poverty. [^11] And, behold, your eyes see, and the eyes of my brother Benjamin, that it is my mouth that speaketh unto you. [^12] And ye shall tell my father of all my glory in Egypt, and of all that ye have seen; and ye shall haste and bring down my father hither. [^13] And he fell upon his brother Benjamin's neck, and wept; and Benjamin wept upon his neck. [^14] Moreover he kissed all his brethren, and wept upon them: and after that his brethren talked with him. [^15] And the fame thereof was heard in Pharaoh's house, saying, Joseph's brethren are come: and it pleased Pharaoh well, and his servants. [^16] And Pharaoh said unto Joseph, Say unto thy brethren, This do ye; lade your beasts, and go, get you unto the land of Canaan; [^17] and take your father and your households, and come unto me: and I will give you the good of the land of Egypt, and ye shall eat the fat of the land. [^18] Now thou art commanded, this do ye; take you wagons out of the land of Egypt for your little ones, and for your wives, and bring your father, and come. [^19] Also regard not your stuff; for the good of all the land of Egypt is your's. [^20] And the children of Israel did so: and Joseph gave them wagons, according to the commandment of Pharaoh, and gave them provision for the way. [^21] To all of them he gave each man changes of raiment; but to Benjamin he gave three hundred pieces of silver, and five changes of raiment. [^22] And to his father he sent after this manner; ten asses laden with the good things of Egypt, and ten she asses laden with corn and bread and meat for his father by the way. [^23] So he sent his brethren away, and they departed: and he said unto them, See that ye fall not out by the way. [^24] And they went up out of Egypt, and came into the land of Canaan unto Jacob their father, [^25] and told him, saying, Joseph is yet alive, and he is governor over all the land of Egypt. And Jacob's heart fainted, for he believed them not. [^26] And they told him all the words of Joseph, which he had said unto them: and when he saw the wagons which Joseph had sent to carry him, the spirit of Jacob their father revived: [^27] and Israel said, It is enough; Joseph my son is yet alive: I will go and see him before I die. [^28] 

[[Genesis - 44|<--]] Genesis - 45 [[Genesis - 46|-->]]

---
# Notes
