---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 16 - King James Version"
---
[[Genesis - 15|<--]] Genesis - 16 [[Genesis - 17|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Genesis]]

# Genesis - 16

Now Sarai Abram's wife bare him no children: and she had an handmaid, an Egyptian, whose name was Hagar. [^1] And Sarai said unto Abram, Behold now, the LORD hath restrained me from bearing: I pray thee, go in unto my maid; it may be that I may obtain children by her. And Abram hearkened to the voice of Sarai. [^2] And Sarai Abram's wife took Hagar her maid the Egyptian, after Abram had dwelt ten years in the land of Canaan, and gave her to her husband Abram to be his wife. [^3] And he went in unto Hagar, and she conceived: and when she saw that she had conceived, her mistress was despised in her eyes. [^4] And Sarai said unto Abram, My wrong be upon thee: I have given my maid into thy bosom; and when she saw that she had conceived, I was despised in her eyes: the LORD judge between me and thee. [^5] But Abram said unto Sarai, Behold, thy maid is in thy hand; do to her as it pleaseth thee. And when Sarai dealt hardly with her, she fled from her face. [^6] And the angel of the LORD found her by a fountain of water in the wilderness, by the fountain in the way to Shur. [^7] And he said, Hagar, Sarai's maid, whence camest thou? and whither wilt thou go? And she said, I flee from the face of my mistress Sarai. [^8] And the angel of the LORD said unto her, Return to thy mistress, and submit thyself under her hands. [^9] And the angel of the LORD said unto her, I will multiply thy seed exceedingly, that it shall not be numbered for multitude. [^10] And the angel of the LORD said unto her, Behold, thou art with child, and shalt bear a son, and shalt call his name Ishmael; because the LORD hath heard thy affliction. [^11] And he will be a wild man; his hand will be against every man, and every man's hand against him; and he shall dwell in the presence of all his brethren. [^12] And she called the name of the LORD that spake unto her, Thou God seest me: for she said, Have I also here looked after him that seeth me? [^13] Wherefore the well was called Beer-lahai-roi; behold, it is between Kadesh and Bered. [^14] And Hagar bare Abram a son: and Abram called his son's name, which Hagar bare, Ishmael. [^15] And Abram was fourscore and six years old, when Hagar bare Ishmael to Abram. [^16] 

[[Genesis - 15|<--]] Genesis - 16 [[Genesis - 17|-->]]

---
# Notes
