---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 25 - King James Version"
---
[[Genesis - 24|<--]] Genesis - 25 [[Genesis - 26|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Genesis]]

# Genesis - 25

Then again Abraham took a wife, and her name was Keturah. [^1] And she bare him Zimran, and Jokshan, and Medan, and Midian, and Ishbak, and Shuah. [^2] And Jokshan begat Sheba, and Dedan. And the sons of Dedan were Asshurim, and Letushim, and Leummim. [^3] And the sons of Midian; Ephah, and Epher, and Hanoch, and Abidah, and Eldaah. All these were the children of Keturah. [^4] And Abraham gave all that he had unto Isaac. [^5] But unto the sons of the concubines, which Abraham had, Abraham gave gifts, and sent them away from Isaac his son, while he yet lived, eastward, unto the east country. [^6] And these are the days of the years of Abraham's life which he lived, an hundred threescore and fifteen years. [^7] Then Abraham gave up the ghost, and died in a good old age, an old man, and full of years; and was gathered to his people. [^8] And his sons Isaac and Ishmael buried him in the cave of Machpelah, in the field of Ephron the son of Zohar the Hittite, which is before Mamre; [^9] the field which Abraham purchased of the sons of Heth: there was Abraham buried, and Sarah his wife. [^10] And it came to pass after the death of Abraham, that God blessed his son Isaac; and Isaac dwelt by the well Lahai-roi. [^11] Now these are the generations of Ishmael, Abraham's son, whom Hagar the Egyptian, Sarah's handmaid, bare unto Abraham: [^12] and these are the names of the sons of Ishmael, by their names, according to their generations: the firstborn of Ishmael, Nebajoth; and Kedar, and Adbeel, and Mibsam, [^13] and Mishma, and Dumah, and Massa, [^14] Hadar, and Tema, Jetur, Naphish, and Kedemah: [^15] these are the sons of Ishmael, and these are their names, by their towns, and by their castles; twelve princes according to their nations. [^16] And these are the years of the life of Ishmael, an hundred and thirty and seven years: and he gave up the ghost and died; and was gathered unto his people. [^17] And they dwelt from Havilah unto Shur, that is before Egypt, as thou goest toward Assyria: and he died in the presence of all his brethren. [^18] And these are the generations of Isaac, Abraham's son: Abraham begat Isaac: [^19] and Isaac was forty years old when he took Rebekah to wife, the daughter of Bethuel the Syrian of Padan-aram, the sister to Laban the Syrian. [^20] And Isaac intreated the LORD for his wife, because she was barren: and the LORD was intreated of him, and Rebekah his wife conceived. [^21] And the children struggled together within her; and she said, If it be so, why am I thus? And she went to enquire of the LORD. [^22] And the LORD said unto her,Two nations are in thy womb,And two manner of people shall be separated from thy bowels;And the one people shall be stronger than the other people;And the elder shall serve the younger. [^23] And when her days to be delivered were fulfilled, behold, there were twins in her womb. [^24] And the first came out red, all over like an hairy garment; and they called his name Esau. [^25] And after that came his brother out, and his hand took hold on Esau's heel; and his name was called Jacob: and Isaac was threescore years old when she bare them. [^26] And the boys grew: and Esau was a cunning hunter, a man of the field; and Jacob was a plain man, dwelling in tents. [^27] And Isaac loved Esau, because he did eat of his venison: but Rebekah loved Jacob. [^28] And Jacob sod pottage: and Esau came from the field, and he was faint: [^29] and Esau said to Jacob, Feed me, I pray thee, with that same red pottage; for I am faint: therefore was his name called Edom. [^30] And Jacob said, Sell me this day thy birthright. [^31] And Esau said, Behold, I am at the point to die: and what profit shall this birthright do to me? [^32] And Jacob said, Swear to me this day; and he sware unto him: and he sold his birthright unto Jacob. [^33] Then Jacob gave Esau bread and pottage of lentiles; and he did eat and drink, and rose up, and went his way: thus Esau despised his birthright. [^34] 

[[Genesis - 24|<--]] Genesis - 25 [[Genesis - 26|-->]]

---
# Notes
