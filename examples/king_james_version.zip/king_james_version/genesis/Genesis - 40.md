---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 40 - King James Version"
---
[[Genesis - 39|<--]] Genesis - 40 [[Genesis - 41|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Genesis]]

# Genesis - 40

And it came to pass after these things, that the butler of the king of Egypt and his baker had offended their lord the king of Egypt. [^1] And Pharaoh was wroth against two of his officers, against the chief of the butlers, and against the chief of the bakers. [^2] And he put them in ward in the house of the captain of the guard, into the prison, the place where Joseph was bound. [^3] And the captain of the guard charged Joseph with them, and he served them: and they continued a season in ward. [^4] And they dreamed a dream both of them, each man his dream in one night, each man according to the interpretation of his dream, the butler and the baker of the king of Egypt, which were bound in the prison. [^5] And Joseph came in unto them in the morning, and looked upon them, and, behold, they were sad. [^6] And he asked Pharaoh's officers that were with him in the ward of his lord's house, saying, Wherefore look ye so sadly to day? [^7] And they said unto him, We have dreamed a dream, and there is no interpreter of it. And Joseph said unto them, Do not interpretations belong to God? tell me them, I pray you. [^8] And the chief butler told his dream to Joseph, and said to him, In my dream, behold, a vine was before me; [^9] and in the vine were three branches: and it was as though it budded, and her blossoms shot forth; and the clusters thereof brought forth ripe grapes: [^10] and Pharaoh's cup was in my hand: and I took the grapes, and pressed them into Pharaoh's cup, and I gave the cup into Pharaoh's hand. [^11] And Joseph said unto him, This is the interpretation of it: The three branches are three days: [^12] yet within three days shall Pharaoh lift up thine head, and restore thee unto thy place: and thou shalt deliver Pharaoh's cup into his hand, after the former manner when thou wast his butler. [^13] But think on me when it shall be well with thee, and shew kindness, I pray thee, unto me, and make mention of me unto Pharaoh, and bring me out of this house: [^14] for indeed I was stolen away out of the land of the Hebrews: and here also have I done nothing that they should put me into the dungeon. [^15] When the chief baker saw that the interpretation was good, he said unto Joseph, I also was in my dream, and, behold, I had three white baskets on my head: [^16] and in the uppermost basket there was of all manner of bakemeats for Pharaoh; and the birds did eat them out of the basket upon my head. [^17] And Joseph answered and said, This is the interpretation thereof: The three baskets are three days: [^18] yet within three days shall Pharaoh lift up thy head from off thee, and shall hang thee on a tree; and the birds shall eat thy flesh from off thee. [^19] And it came to pass the third day, which was Pharaoh's birthday, that he made a feast unto all his servants: and he lifted up the head of the chief butler and of the chief baker among his servants. [^20] And he restored the chief butler unto his butlership again; and he gave the cup into Pharaoh's hand: [^21] but he hanged the chief baker: as Joseph had interpreted to them. [^22] Yet did not the chief butler remember Joseph, but forgat him. [^23] 

[[Genesis - 39|<--]] Genesis - 40 [[Genesis - 41|-->]]

---
# Notes
