---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 5 - King James Version"
---
[[Genesis - 4|<--]] Genesis - 5 [[Genesis - 6|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Genesis]]

# Genesis - 5

This is the book of the generations of Adam. In the day that God created man, in the likeness of God made he him; [^1] male and female created he them; and blessed them, and called their name Adam, in the day when they were created. [^2] And Adam lived an hundred and thirty years, and begat a son in his own likeness, after his image; and called his name Seth: [^3] and the days of Adam after he had begotten Seth were eight hundred years: and he begat sons and daughters: [^4] and all the days that Adam lived were nine hundred and thirty years: and he died. [^5] And Seth lived an hundred and five years, and begat Enos: [^6] and Seth lived after he begat Enos eight hundred and seven years, and begat sons and daughters: [^7] and all the days of Seth were nine hundred and twelve years: and he died. [^8] And Enos lived ninety years, and begat Cainan: [^9] and Enos lived after he begat Cainan eight hundred and fifteen years, and begat sons and daughters: [^10] and all the days of Enos were nine hundred and five years: and he died. [^11] And Cainan lived seventy years, and begat Mahalaleel: [^12] and Cainan lived after he begat Mahalaleel eight hundred and forty years, and begat sons and daughters: [^13] and all the days of Cainan were nine hundred and ten years: and he died. [^14] And Mahalaleel lived sixty and five years, and begat Jared: [^15] and Mahalaleel lived after he begat Jared eight hundred and thirty years, and begat sons and daughters: [^16] and all the days of Mahalaleel were eight hundred ninety and five years: and he died. [^17] And Jared lived an hundred sixty and two years, and he begat Enoch: [^18] and Jared lived after he begat Enoch eight hundred years, and begat sons and daughters: [^19] and all the days of Jared were nine hundred sixty and two years: and he died. [^20] And Enoch lived sixty and five years, and begat Methuselah: [^21] and Enoch walked with God after he begat Methuselah three hundred years, and begat sons and daughters: [^22] and all the days of Enoch were three hundred sixty and five years: [^23] and Enoch walked with God: and he was not; for God took him. [^24] And Methuselah lived an hundred eighty and seven years, and begat Lamech: [^25] and Methuselah lived after he begat Lamech seven hundred eighty and two years, and begat sons and daughters: [^26] and all the days of Methuselah were nine hundred sixty and nine years: and he died. [^27] And Lamech lived an hundred eighty and two years, and begat a son: [^28] and he called his name Noah, saying, This same shall comfort us concerning our work and toil of our hands, because of the ground which the LORD hath cursed. [^29] And Lamech lived after he begat Noah five hundred ninety and five years, and begat sons and daughters: [^30] and all the days of Lamech were seven hundred seventy and seven years: and he died. [^31] And Noah was five hundred years old: and Noah begat Shem, Ham, and Japheth. [^32] 

[[Genesis - 4|<--]] Genesis - 5 [[Genesis - 6|-->]]

---
# Notes
