---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 20 - King James Version"
---
[[Genesis - 19|<--]] Genesis - 20 [[Genesis - 21|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Genesis]]

# Genesis - 20

And Abraham journeyed from thence toward the south country, and dwelled between Kadesh and Shur, and sojourned in Gerar. [^1] And Abraham said of Sarah his wife, She is my sister: and Abimelech king of Gerar sent, and took Sarah. [^2] But God came to Abimelech in a dream by night, and said to him, Behold, thou art but a dead man, for the woman which thou hast taken; for she is a man's wife. [^3] But Abimelech had not come near her: and he said, Lord, wilt thou slay also a righteous nation? [^4] Said he not unto me, She is my sister? and she, even she herself said, He is my brother: in the integrity of my heart and innocency of my hands have I done this. [^5] And God said unto him in a dream, Yea, I know that thou didst this in the integrity of thy heart; for I also withheld thee from sinning against me: therefore suffered I thee not to touch her. [^6] Now therefore restore the man his wife; for he is a prophet, and he shall pray for thee, and thou shalt live: and if thou restore her not, know thou that thou shalt surely die, thou, and all that are thine. [^7] Therefore Abimelech rose early in the morning, and called all his servants, and told all these things in their ears: and the men were sore afraid. [^8] Then Abimelech called Abraham, and said unto him, What hast thou done unto us? and what have I offended thee, that thou hast brought on me and on my kingdom a great sin? thou hast done deeds unto me that ought not to be done. [^9] And Abimelech said unto Abraham, What sawest thou, that thou hast done this thing? [^10] And Abraham said, Because I thought, Surely the fear of God is not in this place; and they will slay me for my wife's sake. [^11] And yet indeed she is my sister; she is the daughter of my father, but not the daughter of my mother; and she became my wife. [^12] And it came to pass, when God caused me to wander from my father's house, that I said unto her, This is thy kindness which thou shalt shew unto me; at every place whither we shall come, say of me, He is my brother. [^13] And Abimelech took sheep, and oxen, and menservants, and womenservants, and gave them unto Abraham, and restored him Sarah his wife. [^14] And Abimelech said, Behold, my land is before thee: dwell where it pleaseth thee. [^15] And unto Sarah he said, Behold, I have given thy brother a thousand pieces of silver: behold, he is to thee a covering of the eyes, unto all that are with thee, and with all other: thus she was reproved. [^16] So Abraham prayed unto God: and God healed Abimelech, and his wife, and his maidservants; and they bare children. [^17] For the LORD had fast closed up all the wombs of the house of Abimelech, because of Sarah Abraham's wife. [^18] 

[[Genesis - 19|<--]] Genesis - 20 [[Genesis - 21|-->]]

---
# Notes
