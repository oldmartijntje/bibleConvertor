---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 50 - King James Version"
---
[[Genesis - 49|<--]] Genesis - 50

Translation: [[bible - King James Version|King James Version]]
Book: [[Genesis]]

# Genesis - 50

And Joseph fell upon his father's face, and wept upon him, and kissed him. [^1] And Joseph commanded his servants the physicians to embalm his father: and the physicians embalmed Israel. [^2] And forty days were fulfilled for him; for so are fulfilled the days of those which are embalmed: and the Egyptians mourned for him threescore and ten days. [^3] And when the days of his mourning were past, Joseph spake unto the house of Pharaoh, saying, If now I have found grace in your eyes, speak, I pray you, in the ears of Pharaoh, saying, [^4] My father made me swear, saying, Lo, I die: in my grave which I have digged for me in the land of Canaan, there shalt thou bury me. Now therefore let me go up, I pray thee, and bury my father, and I will come again. [^5] And Pharaoh said, Go up, and bury thy father, according as he made thee swear. [^6] And Joseph went up to bury his father: and with him went up all the servants of Pharaoh, the elders of his house, and all the elders of the land of Egypt, [^7] and all the house of Joseph, and his brethren, and his father's house: only their little ones, and their flocks, and their herds, they left in the land of Goshen. [^8] And there went up with him both chariots and horsemen: and it was a very great company. [^9] And they came to the threshingfloor of Atad, which is beyond Jordan, and there they mourned with a great and very sore lamentation: and he made a mourning for his father seven days. [^10] And when the inhabitants of the land, the Canaanites, saw the mourning in the floor of Atad, they said, This is a grievous mourning to the Egyptians: wherefore the name of it was called Abel-mizraim, which is beyond Jordan. [^11] And his sons did unto him according as he commanded them: [^12] for his sons carried him into the land of Canaan, and buried him in the cave of the field of Machpelah, which Abraham bought with the field for a possession of a buryingplace of Ephron the Hittite, before Mamre. [^13] And Joseph returned into Egypt, he, and his brethren, and all that went up with him to bury his father, after he had buried his father. [^14] And when Joseph's brethren saw that their father was dead, they said, Joseph will peradventure hate us, and will certainly requite us all the evil which we did unto him. [^15] And they sent a messenger unto Joseph, saying, Thy father did command before he died, saying, [^16] So shall ye say unto Joseph, Forgive, I pray thee now, the trespass of thy brethren, and their sin; for they did unto thee evil: and now, we pray thee, forgive the trespass of the servants of the God of thy father. And Joseph wept when they spake unto him. [^17] And his brethren also went and fell down before his face; and they said, Behold, we be thy servants. [^18] And Joseph said unto them, Fear not: for am I in the place of God? [^19] But as for you, ye thought evil against me; but God meant it unto good, to bring to pass, as it is this day, to save much people alive. [^20] Now therefore fear ye not: I will nourish you, and your little ones. And he comforted them, and spake kindly unto them. [^21] And Joseph dwelt in Egypt, he, and his father's house: and Joseph lived an hundred and ten years. [^22] And Joseph saw Ephraim's children of the third generation: the children also of Machir the son of Manasseh were brought up upon Joseph's knees. [^23] And Joseph said unto his brethren, I die: and God will surely visit you, and bring you out of this land unto the land which he sware to Abraham, to Isaac, and to Jacob. [^24] And Joseph took an oath of the children of Israel, saying, God will surely visit you, and ye shall carry up my bones from hence. [^25] So Joseph died, being an hundred and ten years old: and they embalmed him, and he was put in a coffin in Egypt. [^26] 

[[Genesis - 49|<--]] Genesis - 50

---
# Notes
