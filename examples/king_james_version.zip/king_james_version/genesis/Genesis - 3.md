---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 3 - King James Version"
---
[[Genesis - 2|<--]] Genesis - 3 [[Genesis - 4|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Genesis]]

# Genesis - 3

Now the serpent was more subtil than any beast of the field which the LORD God had made. And he said unto the woman, Yea, hath God said, Ye shall not eat of every tree of the garden? [^1] And the woman said unto the serpent, We may eat of the fruit of the trees of the garden: [^2] but of the fruit of the tree which is in the midst of the garden, God hath said, Ye shall not eat of it, neither shall ye touch it, lest ye die. [^3] And the serpent said unto the woman, Ye shall not surely die: [^4] for God doth know that in the day ye eat thereof, then your eyes shall be opened, and ye shall be as gods, knowing good and evil. [^5] And when the woman saw that the tree was good for food, and that it was pleasant to the eyes, and a tree to be desired to make one wise, she took of the fruit thereof, and did eat, and gave also unto her husband with her; and he did eat. [^6] And the eyes of them both were opened, and they knew that they were naked; and they sewed fig leaves together, and made themselves aprons. [^7] And they heard the voice of the LORD God walking in the garden in the cool of the day: and Adam and his wife hid themselves from the presence of the LORD God amongst the trees of the garden. [^8] And the LORD God called unto Adam, and said unto him, Where art thou? [^9] And he said, I heard thy voice in the garden, and I was afraid, because I was naked; and I hid myself. [^10] And he said, Who told thee that thou wast naked? Hast thou eaten of the tree, whereof I commanded thee that thou shouldest not eat? [^11] And the man said, The woman whom thou gavest to be with me, she gave me of the tree, and I did eat. [^12] And the LORD God said unto the woman, What is this that thou hast done? And the woman said, The serpent beguiled me, and I did eat. [^13] And the LORD God said unto the serpent, Because thou hast done this, thou art cursed above all cattle, and above every beast of the field; upon thy belly shalt thou go, and dust shalt thou eat all the days of thy life: [^14] and I will put enmity between thee and the woman, and between thy seed and her seed; it shall bruise thy head, and thou shalt bruise his heel. [^15] Unto the woman he said, I will greatly multiply thy sorrow and thy conception; in sorrow thou shalt bring forth children; and thy desire shall be to thy husband, and he shall rule over thee. [^16] And unto Adam he said, Because thou hast hearkened unto the voice of thy wife, and hast eaten of the tree, of which I commanded thee, saying, Thou shalt not eat of it: cursed is the ground for thy sake; in sorrow shalt thou eat of it all the days of thy life; [^17] thorns also and thistles shall it bring forth to thee; and thou shalt eat the herb of the field; [^18] in the sweat of thy face shalt thou eat bread, till thou return unto the ground; for out of it wast thou taken: for dust thou art, and unto dust shalt thou return. [^19] And Adam called his wife's name Eve; because she was the mother of all living. [^20] Unto Adam also and to his wife did the LORD God make coats of skins, and clothed them. [^21] And the LORD God said, Behold, the man is become as one of us, to know good and evil: and now, lest he put forth his hand, and take also of the tree of life, and eat, and live for ever: [^22] therefore the LORD God sent him forth from the garden of Eden, to till the ground from whence he was taken. [^23] So he drove out the man; and he placed at the east of the garden of Eden Cherubims, and a flaming sword which turned every way, to keep the way of the tree of life. [^24] 

[[Genesis - 2|<--]] Genesis - 3 [[Genesis - 4|-->]]

---
# Notes
