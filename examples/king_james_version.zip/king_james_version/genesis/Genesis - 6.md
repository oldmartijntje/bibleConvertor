---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 6 - King James Version"
---
[[Genesis - 5|<--]] Genesis - 6 [[Genesis - 7|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Genesis]]

# Genesis - 6

And it came to pass, when men began to multiply on the face of the earth, and daughters were born unto them, [^1] that the sons of God saw the daughters of men that they were fair; and they took them wives of all which they chose. [^2] And the LORD said, My spirit shall not always strive with man, for that he also is flesh: yet his days shall be an hundred and twenty years. [^3] There were giants in the earth in those days; and also after that, when the sons of God came in unto the daughters of men, and they bare children to them, the same became mighty men which were of old, men of renown. [^4] And GOD saw that the wickedness of man was great in the earth, and that every imagination of the thoughts of his heart was only evil continually. [^5] And it repented the LORD that he had made man on the earth, and it grieved him at his heart. [^6] And the LORD said, I will destroy man whom I have created from the face of the earth; both man, and beast, and the creeping thing, and the fowls of the air; for it repenteth me that I have made them. [^7] But Noah found grace in the eyes of the LORD. [^8] These are the generations of Noah: Noah was a just man and perfect in his generations, and Noah walked with God. [^9] And Noah begat three sons, Shem, Ham, and Japheth. [^10] The earth also was corrupt before God, and the earth was filled with violence. [^11] And God looked upon the earth, and, behold, it was corrupt; for all flesh had corrupted his way upon the earth. [^12] And God said unto Noah, The end of all flesh is come before me; for the earth is filled with violence through them; and, behold, I will destroy them with the earth. [^13] Make thee an ark of gopher wood; rooms shalt thou make in the ark, and shalt pitch it within and without with pitch. [^14] And this is the fashion which thou shalt make it of: The length of the ark shall be three hundred cubits, the breadth of it fifty cubits, and the height of it thirty cubits. [^15] A window shalt thou make to the ark, and in a cubit shalt thou finish it above; and the door of the ark shalt thou set in the side thereof; with lower, second, and third stories shalt thou make it. [^16] And, behold, I, even I, do bring a flood of waters upon the earth, to destroy all flesh, wherein is the breath of life, from under heaven; and every thing that is in the earth shall die. [^17] But with thee will I establish my covenant; and thou shalt come into the ark, thou, and thy sons, and thy wife, and thy sons' wives with thee. [^18] And of every living thing of all flesh, two of every sort shalt thou bring into the ark, to keep them alive with thee; they shall be male and female. [^19] Of fowls after their kind, and of cattle after their kind, of every creeping thing of the earth after his kind, two of every sort shall come unto thee, to keep them alive. [^20] And take thou unto thee of all food that is eaten, and thou shalt gather it to thee; and it shall be for food for thee, and for them. [^21] Thus did Noah; according to all that God commanded him, so did he. [^22] 

[[Genesis - 5|<--]] Genesis - 6 [[Genesis - 7|-->]]

---
# Notes
