---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 8 - King James Version"
---
[[Genesis - 7|<--]] Genesis - 8 [[Genesis - 9|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Genesis]]

# Genesis - 8

And God remembered Noah, and every living thing, and all the cattle that was with him in the ark: and God made a wind to pass over the earth, and the waters asswaged; [^1] the fountains also of the deep and the windows of heaven were stopped, and the rain from heaven was restrained; [^2] and the waters returned from off the earth continually: and after the end of the hundred and fifty days the waters were abated. [^3] And the ark rested in the seventh month, on the seventeenth day of the month, upon the mountains of Ararat. [^4] And the waters decreased continually until the tenth month: in the tenth month, on the first day of the month, were the tops of the mountains seen. [^5] And it came to pass at the end of forty days, that Noah opened the window of the ark which he had made: [^6] and he sent forth a raven, which went forth to and fro, until the waters were dried up from off the earth. [^7] Also he sent forth a dove from him, to see if the waters were abated from off the face of the ground; [^8] but the dove found no rest for the sole of her foot, and she returned unto him into the ark, for the waters were on the face of the whole earth: then he put forth his hand, and took her, and pulled her in unto him into the ark. [^9] And he stayed yet other seven days; and again he sent forth the dove out of the ark; [^10] and the dove came in to him in the evening; and, lo, in her mouth was an olive leaf pluckt off: so Noah knew that the waters were abated from off the earth. [^11] And he stayed yet other seven days; and sent forth the dove; which returned not again unto him any more. [^12] And it came to pass in the six hundredth and first year, in the first month, the first day of the month, the waters were dried up from off the earth: and Noah removed the covering of the ark, and looked, and, behold, the face of the ground was dry. [^13] And in the second month, on the seven and twentieth day of the month, was the earth dried. [^14] And God spake unto Noah, saying, [^15] Go forth of the ark, thou, and thy wife, and thy sons, and thy sons' wives with thee. [^16] Bring forth with thee every living thing that is with thee, of all flesh, both of fowl, and of cattle, and of every creeping thing that creepeth upon the earth; that they may breed abundantly in the earth, and be fruitful, and multiply upon the earth. [^17] And Noah went forth, and his sons, and his wife, and his sons' wives with him: [^18] every beast, every creeping thing, and every fowl, and whatsoever creepeth upon the earth, after their kinds, went forth out of the ark. [^19] And Noah builded an altar unto the LORD; and took of every clean beast, and of every clean fowl, and offered burnt offerings on the altar. [^20] And the LORD smelled a sweet savour; and the LORD said in his heart, I will not again curse the ground any more for man's sake; for the imagination of man's heart is evil from his youth; neither will I again smite any more every thing living, as I have done. [^21] While the earth remaineth, seedtime and harvest, and cold and heat, and summer and winter, and day and night shall not cease. [^22] 

[[Genesis - 7|<--]] Genesis - 8 [[Genesis - 9|-->]]

---
# Notes
