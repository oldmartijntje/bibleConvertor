---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 33 - King James Version"
---
[[Genesis - 32|<--]] Genesis - 33 [[Genesis - 34|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Genesis]]

# Genesis - 33

And Jacob lifted up his eyes, and looked, and, behold, Esau came, and with him four hundred men. And he divided the children unto Leah, and unto Rachel, and unto the two handmaids. [^1] And he put the handmaids and their children foremost, and Leah and her children after, and Rachel and Joseph hindermost. [^2] And he passed over before them, and bowed himself to the ground seven times, until he came near to his brother. [^3] And Esau ran to meet him, and embraced him, and fell on his neck, and kissed him: and they wept. [^4] And he lifted up his eyes, and saw the women and the children; and said, Who are those with thee? And he said, The children which God hath graciously given thy servant. [^5] Then the handmaidens came near, they and their children, and they bowed themselves. [^6] And Leah also with her children came near, and bowed themselves: and after came Joseph near and Rachel, and they bowed themselves. [^7] And he said, What meanest thou by all this drove which I met? And he said, These are to find grace in the sight of my lord. [^8] And Esau said, I have enough, my brother; keep that thou hast unto thyself. [^9] And Jacob said, Nay, I pray thee, if now I have found grace in thy sight, then receive my present at my hand: for therefore I have seen thy face, as though I had seen the face of God, and thou wast pleased with me. [^10] Take, I pray thee, my blessing that is brought to thee; because God hath dealt graciously with me, and because I have enough. And he urged him, and he took it. [^11] And he said, Let us take our journey, and let us go, and I will go before thee. [^12] And he said unto him, My lord knoweth that the children are tender, and the flocks and herds with young are with me: and if men should overdrive them one day, all the flock will die. [^13] Let my lord, I pray thee, pass over before his servant: and I will lead on softly, according as the cattle that goeth before me and the children be able to endure, until I come unto my lord unto Seir. [^14] And Esau said, Let me now leave with thee some of the folk that are with me. And he said, What needeth it? let me find grace in the sight of my lord. [^15] So Esau returned that day on his way unto Seir. [^16] And Jacob journeyed to Succoth, and built him an house, and made booths for his cattle: therefore the name of the place is called Succoth. [^17] And Jacob came to Shalem, a city of Shechem, which is in the land of Canaan, when he came from Padan-aram; and pitched his tent before the city. [^18] And he bought a parcel of a field, where he had spread his tent, at the hand of the children of Hamor, Shechem's father, for an hundred pieces of money. [^19] And he erected there an altar, and called it El-elohe-Israel. [^20] 

[[Genesis - 32|<--]] Genesis - 33 [[Genesis - 34|-->]]

---
# Notes
