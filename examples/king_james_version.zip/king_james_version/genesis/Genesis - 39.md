---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 39 - King James Version"
---
[[Genesis - 38|<--]] Genesis - 39 [[Genesis - 40|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Genesis]]

# Genesis - 39

And Joseph was brought down to Egypt; and Potiphar, an officer of Pharaoh, captain of the guard, an Egyptian, bought him of the hands of the Ishmeelites, which had brought him down thither. [^1] And the LORD was with Joseph, and he was a prosperous man; and he was in the house of his master the Egyptian. [^2] And his master saw that the LORD  was with him, and that the LORD made all that he did to prosper in his hand. [^3] And Joseph found grace in his sight, and he served him: and he made him overseer over his house, and all that he had he put into his hand. [^4] And it came to pass from the time that he had made him overseer in his house, and over all that he had, that the LORD blessed the Egyptian's house for Joseph's sake; and the blessing of the LORD was upon all that he had in the house, and in the field. [^5] And he left all that he had in Joseph's hand; and he knew not ought he had, save the bread which he did eat. And Joseph was a goodly person, and well favoured. [^6] And it came to pass after these things, that his master's wife cast her eyes upon Joseph; and she said, Lie with me. [^7] But he refused, and said unto his master's wife, Behold, my master wotteth not what is with me in the house, and he hath committed all that he hath to my hand; [^8] there is none greater in this house than I; neither hath he kept back any thing from me but thee, because thou art his wife: how then can I do this great wickedness, and sin against God? [^9] And it came to pass, as she spake to Joseph day by day, that he hearkened not unto her, to lie by her, or to be with her. [^10] And it came to pass about this time, that Joseph went into the house to do his business; and there was none of the men of the house there within. [^11] And she caught him by his garment, saying, Lie with me: and he left his garment in her hand, and fled, and got him out. [^12] And it came to pass, when she saw that he had left his garment in her hand, and was fled forth, [^13] that she called unto the men of her house, and spake unto them, saying, See, he hath brought in an Hebrew unto us to mock us; he came in unto me to lie with me, and I cried with a loud voice: [^14] and it came to pass, when he heard that I lifted up my voice and cried, that he left his garment with me, and fled, and got him out. [^15] And she laid up his garment by her, until his lord came home. [^16] And she spake unto him according to these words, saying, The Hebrew servant, which thou hast brought unto us, came in unto me to mock me: [^17] and it came to pass, as I lifted up my voice and cried, that he left his garment with me, and fled out. [^18] And it came to pass, when his master heard the words of his wife, which she spake unto him, saying, After this manner did thy servant to me; that his wrath was kindled. [^19] And Joseph's master took him, and put him into the prison, a place where the king's prisoners were bound: and he was there in the prison. [^20] But the LORD was with Joseph, and shewed him mercy, and gave him favour in the sight of the keeper of the prison. [^21] And the keeper of the prison committed to Joseph's hand all the prisoners that were in the prison; and whatsoever they did there, he was the doer of it. [^22] The keeper of the prison looked not to any thing that was under his hand; because the LORD was with him, and that which he did, the LORD made it to prosper. [^23] 

[[Genesis - 38|<--]] Genesis - 39 [[Genesis - 40|-->]]

---
# Notes
