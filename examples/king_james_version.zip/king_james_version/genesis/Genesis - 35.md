---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/genesis"
  - "#bible/testament/old"
aliases:
  - "Genesis - 35 - King James Version"
---
[[Genesis - 34|<--]] Genesis - 35 [[Genesis - 36|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Genesis]]

# Genesis - 35

And God said unto Jacob, Arise, go up to Beth-el, and dwell there: and make there an altar unto God, that appeared unto thee when thou fleddest from the face of Esau thy brother. [^1] Then Jacob said unto his household, and to all that were with him, Put away the strange gods that are among you, and be clean, and change your garments: [^2] and let us arise, and go up to Beth-el; and I will make there an altar unto God, who answered me in the day of my distress, and was with me in the way which I went. [^3] And they gave unto Jacob all the strange gods which were in their hand, and all their earrings which were in their ears; and Jacob hid them under the oak which was by Shechem. [^4] And they journeyed: and the terror of God was upon the cities that were round about them, and they did not pursue after the sons of Jacob. [^5] So Jacob came to Luz, which is in the land of Canaan, that is, Beth-el, he and all the people that were with him. [^6] And he built there an altar, and called the place El-beth-el: because there God appeared unto him, when he fled from the face of his brother. [^7] But Deborah Rebekah's nurse died, and she was buried beneath Beth-el under an oak: and the name of it was called Allon-bachuth. [^8] And God appeared unto Jacob again, when he came out of Padan-aram, and blessed him. [^9] And God said unto him, Thy name is Jacob: thy name shall not be called any more Jacob, but Israel shall be thy name: and he called his name Israel. [^10] And God said unto him, I am God Almighty: be fruitful and multiply; a nation and a company of nations shall be of thee, and kings shall come out of thy loins; [^11] and the land which I gave Abraham and Isaac, to thee I will give it, and to thy seed after thee will I give the land. [^12] And God went up from him in the place where he talked with him. [^13] And Jacob set up a pillar in the place where he talked with him, even a pillar of stone: and he poured a drink offering thereon, and he poured oil thereon. [^14] And Jacob called the name of the place where God spake with him, Beth-el. [^15] And they journeyed from Beth-el; and there was but a little way to come to Ephrath: and Rachel travailed, and she had hard labour. [^16] And it came to pass, when she was in hard labour, that the midwife said unto her, Fear not; thou shalt have this son also. [^17] And it came to pass, as her soul was in departing, (for she died) that she called his name Ben-oni: but his father called him Benjamin. [^18] And Rachel died, and was buried in the way to Ephrath, which is Beth-lehem. [^19] And Jacob set a pillar upon her grave: that is the pillar of Rachel's grave unto this day. [^20] And Israel journeyed, and spread his tent beyond the tower of Edar. [^21] And it came to pass, when Israel dwelt in that land, that Reuben went and lay with Bilhah his father's concubine: and Israel heard it. Now the sons of Jacob were twelve: [^22] the sons of Leah; Reuben, Jacob's firstborn, and Simeon, and Levi, and Judah, and Issachar, and Zebulun: [^23] the sons of Rachel; Joseph, and Benjamin: [^24] and the sons of Bilhah, Rachel's handmaid; Dan, and Naphtali: [^25] and the sons of Zilpah, Leah's handmaid; Gad, and Asher: these are the sons of Jacob, which were born to him in Padan-aram. [^26] And Jacob came unto Isaac his father unto Mamre, unto the city of Arbah, which is Hebron, where Abraham and Isaac sojourned. [^27] And the days of Isaac were an hundred and fourscore years. [^28] And Isaac gave up the ghost, and died, and was gathered unto his people, being old and full of days: and his sons Esau and Jacob buried him. [^29] 

[[Genesis - 34|<--]] Genesis - 35 [[Genesis - 36|-->]]

---
# Notes
