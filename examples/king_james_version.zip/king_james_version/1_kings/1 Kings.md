---
translation: King James Version
aliases:
  - "1 Kings - King James Version"
tags:
  - "#bible/type/book"
  - "#bible/book/1_kings"
  - "#bible/testament/old"
---
[[2 Samuel|<--]] 1 Kings [[2 Kings|-->]]

# 1 Kings - King James Version

The 1 Kings book has 22 chapters. It is part of the old testament.

## Chapters

- 1 Kings [[1 Kings - 1|chapter 1]]
- 1 Kings [[1 Kings - 2|chapter 2]]
- 1 Kings [[1 Kings - 3|chapter 3]]
- 1 Kings [[1 Kings - 4|chapter 4]]
- 1 Kings [[1 Kings - 5|chapter 5]]
- 1 Kings [[1 Kings - 6|chapter 6]]
- 1 Kings [[1 Kings - 7|chapter 7]]
- 1 Kings [[1 Kings - 8|chapter 8]]
- 1 Kings [[1 Kings - 9|chapter 9]]
- 1 Kings [[1 Kings - 10|chapter 10]]
- 1 Kings [[1 Kings - 11|chapter 11]]
- 1 Kings [[1 Kings - 12|chapter 12]]
- 1 Kings [[1 Kings - 13|chapter 13]]
- 1 Kings [[1 Kings - 14|chapter 14]]
- 1 Kings [[1 Kings - 15|chapter 15]]
- 1 Kings [[1 Kings - 16|chapter 16]]
- 1 Kings [[1 Kings - 17|chapter 17]]
- 1 Kings [[1 Kings - 18|chapter 18]]
- 1 Kings [[1 Kings - 19|chapter 19]]
- 1 Kings [[1 Kings - 20|chapter 20]]
- 1 Kings [[1 Kings - 21|chapter 21]]
- 1 Kings [[1 Kings - 22|chapter 22]]

[[2 Samuel|<--]] 1 Kings [[2 Kings|-->]]

---
# Notes
