---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_kings"
  - "#bible/testament/old"
aliases:
  - "1 Kings - 19 - King James Version"
---
[[1 Kings - 18|<--]] 1 Kings - 19 [[1 Kings - 20|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[1 Kings]]

# 1 Kings - 19

And Ahab told Jezebel all that Elijah had done, and withal how he had slain all the prophets with the sword. [^1] Then Jezebel sent a messenger unto Elijah, saying, So let the gods do to me, and more also, if I make not thy life as the life of one of them by to morrow about this time. [^2] And when he saw that, he arose, and went for his life, and came to Beer-sheba, which belongeth to Judah, and left his servant there. [^3] But he himself went a day's journey into the wilderness, and came and sat down under a juniper tree: and he requested for himself that he might die; and said, It is enough; now, O LORD, take away my life; for I am not better than my fathers. [^4] And as he lay and slept under a juniper tree, behold, then an angel touched him, and said unto him, Arise and eat. [^5] And he looked, and, behold, there was a cake baken on the coals, and a cruse of water at his head. And he did eat and drink, and laid him down again. [^6] And the angel of the LORD came again the second time, and touched him, and said, Arise and eat; because the journey is too great for thee. [^7] And he arose, and did eat and drink, and went in the strength of that meat forty days and forty nights unto Horeb the mount of God. [^8] And he came thither unto a cave, and lodged there; and, behold, the word of the LORD  came to him, and he said unto him, What doest thou here, Elijah? [^9] And he said, I have been very jealous for the LORD God of hosts: for the children of Israel have forsaken thy covenant, thrown down thine altars, and slain thy prophets with the sword; and I, even I only, am left; and they seek my life, to take it away. [^10] And he said, Go forth, and stand upon the mount before the LORD. And, behold, the LORD passed by, and a great and strong wind rent the mountains, and brake in pieces the rocks before the LORD; but the LORD  was not in the wind: and after the wind an earthquake; but the LORD  was not in the earthquake: [^11] and after the earthquake a fire; but the LORD  was not in the fire: and after the fire a still small voice. [^12] And it was so, when Elijah heard it, that he wrapped his face in his mantle, and went out, and stood in the entering in of the cave. And, behold, there came a voice unto him, and said, What doest thou here, Elijah? [^13] And he said, I have been very jealous for the LORD God of hosts: because the children of Israel have forsaken thy covenant, thrown down thine altars, and slain thy prophets with the sword; and I, even I only, am left; and they seek my life, to take it away. [^14] And the LORD said unto him, Go, return on thy way to the wilderness of Damascus: and when thou comest, anoint Hazael to be king over Syria: [^15] and Jehu the son of Nimshi shalt thou anoint to be king over Israel: and Elisha the son of Shaphat of Abel-meholah shalt thou anoint to be prophet in thy room. [^16] And it shall come to pass, that him that escapeth the sword of Hazael shall Jehu slay: and him that escapeth from the sword of Jehu shall Elisha slay. [^17] Yet I have left me seven thousand in Israel, all the knees which have not bowed unto Baal, and every mouth which hath not kissed him. [^18] So he departed thence, and found Elisha the son of Shaphat, who was plowing with twelve yoke of oxen before him, and he with the twelfth: and Elijah passed by him, and cast his mantle upon him. [^19] And he left the oxen, and ran after Elijah, and said, Let me, I pray thee, kiss my father and my mother, and then I will follow thee. And he said unto him, Go back again: for what have I done to thee? [^20] And he returned back from him, and took a yoke of oxen, and slew them, and boiled their flesh with the instruments of the oxen, and gave unto the people, and they did eat. Then he arose, and went after Elijah, and ministered unto him. [^21] 

[[1 Kings - 18|<--]] 1 Kings - 19 [[1 Kings - 20|-->]]

---
# Notes
