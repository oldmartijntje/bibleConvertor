---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 6 - King James Version"
---
[[Deuteronomy - 5|<--]] Deuteronomy - 6 [[Deuteronomy - 7|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Deuteronomy]]

# Deuteronomy - 6

Now these are the commandments, the statutes, and the judgments, which the LORD your God commanded to teach you, that ye might do them in the land whither ye go to possess it: [^1] that thou mightest fear the LORD thy God, to keep all his statutes and his commandments, which I command thee, thou, and thy son, and thy son's son, all the days of thy life; and that thy days may be prolonged. [^2] Hear therefore, O Israel, and observe to do it; that it may be well with thee, and that ye may increase mightily, as the LORD God of thy fathers hath promised thee, in the land that floweth with milk and honey. [^3] Hear, O Israel: The LORD our God is one LORD: [^4] and thou shalt love the LORD thy God with all thine heart, and with all thy soul, and with all thy might. [^5] And these words, which I command thee this day, shall be in thine heart: [^6] and thou shalt teach them diligently unto thy children, and shalt talk of them when thou sittest in thine house, and when thou walkest by the way, and when thou liest down, and when thou risest up. [^7] And thou shalt bind them for a sign upon thine hand, and they shall be as frontlets between thine eyes. [^8] And thou shalt write them upon the posts of thy house, and on thy gates. [^9] And it shall be, when the LORD thy God shall have brought thee into the land which he sware unto thy fathers, to Abraham, to Isaac, and to Jacob, to give thee great and goodly cities, which thou buildedst not, [^10] and houses full of all good things, which thou filledst not, and wells digged, which thou diggedst not, vineyards and olive trees, which thou plantedst not; when thou shalt have eaten and be full; [^11] then beware lest thou forget the LORD, which brought thee forth out of the land of Egypt, from the house of bondage. [^12] Thou shalt fear the LORD thy God, and serve him, and shalt swear by his name. [^13] Ye shall not go after other gods, of the gods of the people which are round about you; [^14] (for the LORD thy God is a jealous God among you) lest the anger of the LORD thy God be kindled against thee, and destroy thee from off the face of the earth. [^15] Ye shall not tempt the LORD your God, as ye tempted him in Massah. [^16] Ye shall diligently keep the commandments of the LORD your God, and his testimonies, and his statutes, which he hath commanded thee. [^17] And thou shalt do that which is right and good in the sight of the LORD: that it may be well with thee, and that thou mayest go in and possess the good land which the LORD sware unto thy fathers, [^18] to cast out all thine enemies from before thee, as the LORD hath spoken. [^19] And when thy son asketh thee in time to come, saying, What mean the testimonies, and the statutes, and the judgments, which the LORD our God hath commanded you? [^20] Then thou shalt say unto thy son, We were Pharaoh's bondmen in Egypt; and the LORD brought us out of Egypt with a mighty hand: [^21] and the LORD shewed signs and wonders, great and sore, upon Egypt, upon Pharaoh, and upon all his household, before our eyes: [^22] and he brought us out from thence, that he might bring us in, to give us the land which he sware unto our fathers. [^23] And the LORD commanded us to do all these statutes, to fear the LORD our God, for our good always, that he might preserve us alive, as it is at this day. [^24] And it shall be our righteousness, if we observe to do all these commandments before the LORD our God, as he hath commanded us. [^25] 

[[Deuteronomy - 5|<--]] Deuteronomy - 6 [[Deuteronomy - 7|-->]]

---
# Notes
