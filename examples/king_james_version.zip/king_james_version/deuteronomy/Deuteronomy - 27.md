---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 27 - King James Version"
---
[[Deuteronomy - 26|<--]] Deuteronomy - 27 [[Deuteronomy - 28|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Deuteronomy]]

# Deuteronomy - 27

And Moses with the elders of Israel commanded the people, saying, Keep all the commandments which I command you this day. [^1] And it shall be on the day when ye shall pass over Jordan unto the land which the LORD thy God giveth thee, that thou shalt set thee up great stones, and plaister them with plaister: [^2] and thou shalt write upon them all the words of this law, when thou art passed over, that thou mayest go in unto the land which the LORD thy God giveth thee, a land that floweth with milk and honey; as the LORD God of thy fathers hath promised thee. [^3] Therefore it shall be when ye be gone over Jordan, that ye shall set up these stones, which I command you this day, in mount Ebal, and thou shalt plaister them with plaister. [^4] And there shalt thou build an altar unto the LORD thy God, an altar of stones: thou shalt not lift up any iron tool upon them. [^5] Thou shalt build the altar of the LORD thy God of whole stones: and thou shalt offer burnt offerings thereon unto the LORD thy God: [^6] and thou shalt offer peace offerings, and shalt eat there, and rejoice before the LORD thy God. [^7] And thou shalt write upon the stones all the words of this law very plainly. [^8] And Moses and the priests the Levites spake unto all Israel, saying, Take heed, and hearken, O Israel; this day thou art become the people of the LORD thy God. [^9] Thou shalt therefore obey the voice of the LORD thy God, and do his commandments and his statutes, which I command thee this day. [^10] And Moses charged the people the same day, saying, [^11] These shall stand upon mount Gerizim to bless the people, when ye are come over Jordan; Simeon, and Levi, and Judah, and Issachar, and Joseph, and Benjamin: [^12] and these shall stand upon mount Ebal to curse; Reuben, Gad, and Asher, and Zebulun, Dan, and Naphtali. [^13] And the Levites shall speak, and say unto all the men of Israel with a loud voice, [^14] Cursed be the man that maketh any graven or molten image, an abomination unto the LORD, the work of the hands of the craftsman, and putteth it in a secret place. And all the people shall answer and say, Amen. [^15] Cursed be he that setteth light by his father or his mother. And all the people shall say, Amen. [^16] Cursed be he that removeth his neighbour's landmark. And all the people shall say, Amen. [^17] Cursed be he that maketh the blind to wander out of the way. And all the people shall say, Amen. [^18] Cursed be he that perverteth the judgment of the stranger, fatherless, and widow. And all the people shall say, Amen. [^19] Cursed be he that lieth with his father's wife; because he uncovereth his father's skirt. And all the people shall say, Amen. [^20] Cursed be he that lieth with any manner of beast. And all the people shall say, Amen. [^21] Cursed be he that lieth with his sister, the daughter of his father, or the daughter of his mother. And all the people shall say, Amen. [^22] Cursed be he that lieth with his mother in law. And all the people shall say, Amen. [^23] Cursed be he that smiteth his neighbour secretly. And all the people shall say, Amen. [^24] Cursed be he that taketh reward to slay an innocent person. And all the people shall say, Amen. [^25] Cursed be he that confirmeth not all the words of this law to do them. And all the people shall say, Amen. [^26] 

[[Deuteronomy - 26|<--]] Deuteronomy - 27 [[Deuteronomy - 28|-->]]

---
# Notes
