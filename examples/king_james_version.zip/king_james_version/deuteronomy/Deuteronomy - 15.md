---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 15 - King James Version"
---
[[Deuteronomy - 14|<--]] Deuteronomy - 15 [[Deuteronomy - 16|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Deuteronomy]]

# Deuteronomy - 15

At the end of every seven years thou shalt make a release. [^1] And this is the manner of the release: Every creditor that lendeth ought unto his neighbour shall release it; he shall not exact it of his neighbour, or of his brother; because it is called the LORD's release. [^2] Of a foreigner thou mayest exact it again: but that which is thine with thy brother thine hand shall release; [^3] save when there shall be no poor among you; for the LORD shall greatly bless thee in the land which the LORD thy God giveth thee for an inheritance to possess it: [^4] only if thou carefully hearken unto the voice of the LORD thy God, to observe to do all these commandments which I command thee this day. [^5] For the LORD thy God blesseth thee, as he promised thee: and thou shalt lend unto many nations, but thou shalt not borrow; and thou shalt reign over many nations, but they shall not reign over thee. [^6] If there be among you a poor man of one of thy brethren within any of thy gates in thy land which the LORD thy God giveth thee, thou shalt not harden thine heart, nor shut thine hand from thy poor brother: [^7] but thou shalt open thine hand wide unto him, and shalt surely lend him sufficient for his need, in that which he wanteth. [^8] Beware that there be not a thought in thy wicked heart, saying, The seventh year, the year of release, is at hand; and thine eye be evil against thy poor brother, and thou givest him nought; and he cry unto the LORD against thee, and it be sin unto thee. [^9] Thou shalt surely give him, and thine heart shall not be grieved when thou givest unto him: because that for this thing the LORD thy God shall bless thee in all thy works, and in all that thou puttest thine hand unto. [^10] For the poor shall never cease out of the land: therefore I command thee, saying, Thou shalt open thine hand wide unto thy brother, to thy poor, and to thy needy, in thy land. [^11] And if thy brother, an Hebrew man, or an Hebrew woman, be sold unto thee, and serve thee six years; then in the seventh year thou shalt let him go free from thee. [^12] And when thou sendest him out free from thee, thou shalt not let him go away empty: [^13] thou shalt furnish him liberally out of thy flock, and out of thy floor, and out of thy winepress: of that wherewith the LORD thy God hath blessed thee thou shalt give unto him. [^14] And thou shalt remember that thou wast a bondman in the land of Egypt, and the LORD thy God redeemed thee: therefore I command thee this thing to day. [^15] And it shall be, if he say unto thee, I will not go away from thee; because he loveth thee and thine house, because he is well with thee; [^16] then thou shalt take an aul, and thrust it through his ear unto the door, and he shall be thy servant for ever. And also unto thy maidservant thou shalt do likewise. [^17] It shall not seem hard unto thee, when thou sendest him away free from thee; for he hath been worth a double hired servant to thee, in serving thee six years: and the LORD thy God shall bless thee in all that thou doest. [^18] All the firstling males that come of thy herd and of thy flock thou shalt sanctify unto the LORD thy God: thou shalt do no work with the firstling of thy bullock, nor shear the firstling of thy sheep. [^19] Thou shalt eat it before the LORD thy God year by year in the place which the LORD shall choose, thou and thy household. [^20] And if there be any blemish therein, as if it be lame, or blind, or have any ill blemish, thou shalt not sacrifice it unto the LORD thy God. [^21] Thou shalt eat it within thy gates: the unclean and the clean person shall eat it alike, as the roebuck, and as the hart. [^22] Only thou shalt not eat the blood thereof; thou shalt pour it upon the ground as water. [^23] 

[[Deuteronomy - 14|<--]] Deuteronomy - 15 [[Deuteronomy - 16|-->]]

---
# Notes
