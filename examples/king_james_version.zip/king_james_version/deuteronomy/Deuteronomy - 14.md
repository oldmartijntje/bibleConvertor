---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 14 - King James Version"
---
[[Deuteronomy - 13|<--]] Deuteronomy - 14 [[Deuteronomy - 15|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Deuteronomy]]

# Deuteronomy - 14

Ye are the children of the LORD your God: ye shall not cut yourselves, nor make any baldness between your eyes for the dead. [^1] For thou art an holy people unto the LORD thy God, and the LORD hath chosen thee to be a peculiar people unto himself, above all the nations that are upon the earth. [^2] Thou shalt not eat any abominable thing. [^3] These are the beasts which ye shall eat: the ox, the sheep, and the goat, [^4] the hart, and the roebuck, and the fallow deer, and the wild goat, and the pygarg, and the wild ox, and the chamois. [^5] And every beast that parteth the hoof, and cleaveth the cleft into two claws, and cheweth the cud among the beasts, that ye shall eat. [^6] Nevertheless these ye shall not eat of them that chew the cud, or of them that divide the cloven hoof; as the camel, and the hare, and the coney: for they chew the cud, but divide not the hoof; therefore they are unclean unto you. [^7] And the swine, because it divideth the hoof, yet cheweth not the cud, it is unclean unto you: ye shall not eat of their flesh, nor touch their dead carcase. [^8] These ye shall eat of all that are in the waters: all that have fins and scales shall ye eat: [^9] and whatsoever hath not fins and scales ye may not eat; it is unclean unto you. [^10] Of all clean birds ye shall eat. [^11] But these are they of which ye shall not eat: the eagle, and the ossifrage, and the ospray, [^12] and the glede, and the kite, and the vulture after his kind, [^13] and every raven after his kind, [^14] and the owl, and the night hawk, and the cuckow, and the hawk after his kind, [^15] the little owl, and the great owl, and the swan, [^16] and the pelican, and the gier eagle, and the cormorant, [^17] and the stork, and the heron after her kind, and the lapwing, and the bat. [^18] And every creeping thing that flieth is unclean unto you: they shall not be eaten. [^19] But of all clean fowls ye may eat. [^20] Ye shall not eat of any thing that dieth of itself: thou shalt give it unto the stranger that is in thy gates, that he may eat it; or thou mayest sell it unto an alien: for thou art an holy people unto the LORD thy God. Thou shalt not seethe a kid in his mother's milk. [^21] Thou shalt truly tithe all the increase of thy seed, that the field bringeth forth year by year. [^22] And thou shalt eat before the LORD thy God, in the place which he shall choose to place his name there, the tithe of thy corn, of thy wine, and of thine oil, and the firstlings of thy herds and of thy flocks; that thou mayest learn to fear the LORD thy God always. [^23] And if the way be too long for thee, so that thou art not able to carry it; or if the place be too far from thee, which the LORD thy God shall choose to set his name there, when the LORD thy God hath blessed thee: [^24] then shalt thou turn it into money, and bind up the money in thine hand, and shalt go unto the place which the LORD thy God shall choose: [^25] and thou shalt bestow that money for whatsoever thy soul lusteth after, for oxen, or for sheep, or for wine, or for strong drink, or for whatsoever thy soul desireth: and thou shalt eat there before the LORD thy God, and thou shalt rejoice, thou, and thine household, [^26] and the Levite that is within thy gates; thou shalt not forsake him; for he hath no part nor inheritance with thee. [^27] At the end of three years thou shalt bring forth all the tithe of thine increase the same year, and shalt lay it up within thy gates: [^28] and the Levite, (because he hath no part nor inheritance with thee,) and the stranger, and the fatherless, and the widow, which are within thy gates, shall come, and shall eat and be satisfied; that the LORD thy God may bless thee in all the work of thine hand which thou doest. [^29] 

[[Deuteronomy - 13|<--]] Deuteronomy - 14 [[Deuteronomy - 15|-->]]

---
# Notes
