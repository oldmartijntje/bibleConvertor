---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 21 - King James Version"
---
[[Deuteronomy - 20|<--]] Deuteronomy - 21 [[Deuteronomy - 22|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Deuteronomy]]

# Deuteronomy - 21

If one be found slain in the land which the LORD thy God giveth thee to possess it, lying in the field, and it be not known who hath slain him: [^1] then thy elders and thy judges shall come forth, and they shall measure unto the cities which are round about him that is slain: [^2] and it shall be, that the city which is next unto the slain man, even the elders of that city shall take an heifer, which hath not been wrought with, and which hath not drawn in the yoke; [^3] and the elders of that city shall bring down the heifer unto a rough valley, which is neither eared nor sown, and shall strike off the heifer's neck there in the valley: [^4] and the priests the sons of Levi shall come near; for them the LORD thy God hath chosen to minister unto him, and to bless in the name of the LORD; and by their word shall every controversy and every stroke be tried: [^5] and all the elders of that city, that are next unto the slain man, shall wash their hands over the heifer that is beheaded in the valley: [^6] and they shall answer and say, Our hands have not shed this blood, neither have our eyes seen it. [^7] Be merciful, O LORD, unto thy people Israel, whom thou hast redeemed, and lay not innocent blood unto thy people of Israel's charge. And the blood shall be forgiven them. [^8] So shalt thou put away the guilt of innocent blood from among you, when thou shalt do that which is right in the sight of the LORD. [^9] When thou goest forth to war against thine enemies, and the LORD thy God hath delivered them into thine hands, and thou hast taken them captive, [^10] and seest among the captives a beautiful woman, and hast a desire unto her, that thou wouldest have her to thy wife; [^11] then thou shalt bring her home to thine house; and she shall shave her head, and pare her nails; [^12] and she shall put the raiment of her captivity from off her, and shall remain in thine house, and bewail her father and her mother a full month: and after that thou shalt go in unto her, and be her husband, and she shall be thy wife. [^13] And it shall be, if thou have no delight in her, then thou shalt let her go whither she will; but thou shalt not sell her at all for money, thou shalt not make merchandise of her, because thou hast humbled her. [^14] If a man have two wives, one beloved, and another hated, and they have born him children, both the beloved and the hated; and if the firstborn son be her's that was hated: [^15] then it shall be, when he maketh his sons to inherit that which he hath, that he may not make the son of the beloved firstborn before the son of the hated, which is indeed the firstborn: [^16] but he shall acknowledge the son of the hated for the firstborn, by giving him a double portion of all that he hath: for he is the beginning of his strength; the right of the firstborn is his. [^17] If a man have a stubborn and rebellious son, which will not obey the voice of his father, or the voice of his mother, and that, when they have chastened him, will not hearken unto them: [^18] then shall his father and his mother lay hold on him, and bring him out unto the elders of his city, and unto the gate of his place; [^19] and they shall say unto the elders of his city, This our son is stubborn and rebellious, he will not obey our voice; he is a glutton, and a drunkard. [^20] And all the men of his city shall stone him with stones, that he die: so shalt thou put evil away from among you; and all Israel shall hear, and fear. [^21] And if a man have committed a sin worthy of death, and he be to be put to death, and thou hang him on a tree: [^22] his body shall not remain all night upon the tree, but thou shalt in any wise bury him that day; (for he that is hanged is accursed of God;) that thy land be not defiled, which the LORD thy God giveth thee for an inheritance. [^23] 

[[Deuteronomy - 20|<--]] Deuteronomy - 21 [[Deuteronomy - 22|-->]]

---
# Notes
