---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 18 - King James Version"
---
[[Deuteronomy - 17|<--]] Deuteronomy - 18 [[Deuteronomy - 19|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Deuteronomy]]

# Deuteronomy - 18

The priests the Levites, and all the tribe of Levi, shall have no part nor inheritance with Israel: they shall eat the offerings of the LORD made by fire, and his inheritance. [^1] Therefore shall they have no inheritance among their brethren: the LORD  is their inheritance, as he hath said unto them. [^2] And this shall be the priest's due from the people, from them that offer a sacrifice, whether it be ox or sheep; and they shall give unto the priest the shoulder, and the two cheeks, and the maw. [^3] The firstfruit also of thy corn, of thy wine, and of thine oil, and the first of the fleece of thy sheep, shalt thou give him. [^4] For the LORD thy God hath chosen him out of all thy tribes, to stand to minister in the name of the LORD, him and his sons for ever. [^5] And if a Levite come from any of thy gates out of all Israel, where he sojourned, and come with all the desire of his mind unto the place which the LORD shall choose; [^6] then he shall minister in the name of the LORD his God, as all his brethren the Levites do, which stand there before the LORD. [^7] They shall have like portions to eat, beside that which cometh of the sale of his patrimony. [^8] When thou art come into the land which the LORD thy God giveth thee, thou shalt not learn to do after the abominations of those nations. [^9] There shall not be found among you any one that maketh his son or his daughter to pass through the fire, or that useth divination, or an observer of times, or an enchanter, or a witch, [^10] or a charmer, or a consulter with familiar spirits, or a wizard, or a necromancer. [^11] For all that do these things are an abomination unto the LORD: and because of these abominations the LORD thy God doth drive them out from before thee. [^12] Thou shalt be perfect with the LORD thy God. [^13] For these nations, which thou shalt possess, hearkened unto observers of times, and unto diviners: but as for thee, the LORD thy God hath not suffered thee so to do. [^14] The LORD thy God will raise up unto thee a Prophet from the midst of thee, of thy brethren, like unto me; unto him ye shall hearken; [^15] according to all that thou desiredst of the LORD thy God in Horeb in the day of the assembly, saying, Let me not hear again the voice of the LORD my God, neither let me see this great fire any more, that I die not. [^16] And the LORD said unto me, They have well spoken that which they have spoken. [^17] I will raise them up a Prophet from among their brethren, like unto thee, and will put my words in his mouth; and he shall speak unto them all that I shall command him. [^18] And it shall come to pass, that whosoever will not hearken unto my words which he shall speak in my name, I will require it of him. [^19] But the prophet, which shall presume to speak a word in my name, which I have not commanded him to speak, or that shall speak in the name of other gods, even that prophet shall die. [^20] And if thou say in thine heart, How shall we know the word which the LORD hath not spoken? [^21] When a prophet speaketh in the name of the LORD, if the thing follow not, nor come to pass, that is the thing which the LORD hath not spoken, but the prophet hath spoken it presumptuously: thou shalt not be afraid of him. [^22] 

[[Deuteronomy - 17|<--]] Deuteronomy - 18 [[Deuteronomy - 19|-->]]

---
# Notes
