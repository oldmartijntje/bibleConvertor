---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 24 - King James Version"
---
[[Deuteronomy - 23|<--]] Deuteronomy - 24 [[Deuteronomy - 25|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Deuteronomy]]

# Deuteronomy - 24

When a man hath taken a wife, and married her, and it come to pass that she find no favour in his eyes, because he hath found some uncleanness in her: then let him write her a bill of divorcement, and give it in her hand, and send her out of his house. [^1] And when she is departed out of his house, she may go and be another man's wife. [^2] And if the latter husband hate her, and write her a bill of divorcement, and giveth it in her hand, and sendeth her out of his house; or if the latter husband die, which took her to be his wife; [^3] her former husband, which sent her away, may not take her again to be his wife, after that she is defiled; for that is abomination before the LORD: and thou shalt not cause the land to sin, which the LORD thy God giveth thee for an inheritance. [^4] When a man hath taken a new wife, he shall not go out to war, neither shall he be charged with any business: but he shall be free at home one year, and shall cheer up his wife which he hath taken. [^5] No man shall take the nether or the upper millstone to pledge: for he taketh a man's life to pledge. [^6] If a man be found stealing any of his brethren of the children of Israel, and maketh merchandise of him, or selleth him; then that thief shall die; and thou shalt put evil away from among you. [^7] Take heed in the plague of leprosy, that thou observe diligently, and do according to all that the priests the Levites shall teach you: as I commanded them, so ye shall observe to do. [^8] Remember what the LORD thy God did unto Miriam by the way, after that ye were come forth out of Egypt. [^9] When thou dost lend thy brother any thing, thou shalt not go into his house to fetch his pledge. [^10] Thou shalt stand abroad, and the man to whom thou dost lend shall bring out the pledge abroad unto thee. [^11] And if the man be poor, thou shalt not sleep with his pledge: [^12] in any case thou shalt deliver him the pledge again when the sun goeth down, that he may sleep in his own raiment, and bless thee: and it shall be righteousness unto thee before the LORD thy God. [^13] Thou shalt not oppress an hired servant that is poor and needy, whether he be of thy brethren, or of thy strangers that are in thy land within thy gates: [^14] at his day thou shalt give him his hire, neither shall the sun go down upon it; for he is poor, and setteth his heart upon it: lest he cry against thee unto the LORD, and it be sin unto thee. [^15] The fathers shall not be put to death for the children, neither shall the children be put to death for the fathers: every man shall be put to death for his own sin. [^16] Thou shalt not pervert the judgment of the stranger, nor of the fatherless; nor take a widow's raiment to pledge: [^17] but thou shalt remember that thou wast a bondman in Egypt, and the LORD thy God redeemed thee thence: therefore I command thee to do this thing. [^18] When thou cuttest down thine harvest in thy field, and hast forgot a sheaf in the field, thou shalt not go again to fetch it: it shall be for the stranger, for the fatherless, and for the widow: that the LORD thy God may bless thee in all the work of thine hands. [^19] When thou beatest thine olive tree, thou shalt not go over the boughs again: it shall be for the stranger, for the fatherless, and for the widow. [^20] When thou gatherest the grapes of thy vineyard, thou shalt not glean it afterward: it shall be for the stranger, for the fatherless, and for the widow. [^21] And thou shalt remember that thou wast a bondman in the land of Egypt: therefore I command thee to do this thing. [^22] 

[[Deuteronomy - 23|<--]] Deuteronomy - 24 [[Deuteronomy - 25|-->]]

---
# Notes
