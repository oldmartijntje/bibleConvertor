---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 10 - King James Version"
---
[[Deuteronomy - 9|<--]] Deuteronomy - 10 [[Deuteronomy - 11|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Deuteronomy]]

# Deuteronomy - 10

At that time the LORD said unto me, Hew thee two tables of stone like unto the first, and come up unto me into the mount, and make thee an ark of wood. [^1] And I will write on the tables the words that were in the first tables which thou brakest, and thou shalt put them in the ark. [^2] And I made an ark of shittim wood, and hewed two tables of stone like unto the first, and went up into the mount, having the two tables in mine hand. [^3] And he wrote on the tables, according to the first writing, the ten commandments, which the LORD spake unto you in the mount out of the midst of the fire in the day of the assembly: and the LORD gave them unto me. [^4] And I turned myself and came down from the mount, and put the tables in the ark which I had made; and there they be, as the LORD commanded me. [^5] And the children of Israel took their journey from Beeroth of the children of Jaakan to Mosera: there Aaron died, and there he was buried; and Eleazar his son ministered in the priest's office in his stead. [^6] From thence they journeyed unto Gudgodah; and from Gudgodah to Jotbath, a land of rivers of waters. [^7] At that time the LORD separated the tribe of Levi, to bear the ark of the covenant of the LORD, to stand before the LORD to minister unto him, and to bless in his name, unto this day. [^8] Wherefore Levi hath no part nor inheritance with his brethren; the LORD  is his inheritance, according as the LORD thy God promised him. [^9] And I stayed in the mount, according to the first time, forty days and forty nights; and the LORD hearkened unto me at that time also, and the LORD would not destroy thee. [^10] And the LORD said unto me, Arise, take thy journey before the people, that they may go in and possess the land, which I sware unto their fathers to give unto them. [^11] And now, Israel, what doth the LORD thy God require of thee, but to fear the LORD thy God, to walk in all his ways, and to love him, and to serve the LORD thy God with all thy heart and with all thy soul, [^12] to keep the commandments of the LORD, and his statutes, which I command thee this day for thy good? [^13] Behold, the heaven and the heaven of heavens is the LORD's thy God, the earth also, with all that therein is. [^14] Only the LORD had a delight in thy fathers to love them, and he chose their seed after them, even you above all people, as it is this day. [^15] Circumcise therefore the foreskin of your heart, and be no more stiffnecked. [^16] For the LORD your God is God of gods, and Lord of lords, a great God, a mighty, and a terrible, which regardeth not persons, nor taketh reward: [^17] he doth execute the judgment of the fatherless and widow, and loveth the stranger, in giving him food and raiment. [^18] Love ye therefore the stranger: for ye were strangers in the land of Egypt. [^19] Thou shalt fear the LORD thy God; him shalt thou serve, and to him shalt thou cleave, and swear by his name. [^20] He is thy praise, and he is thy God, that hath done for thee these great and terrible things, which thine eyes have seen. [^21] Thy fathers went down into Egypt with threescore and ten persons; and now the LORD thy God hath made thee as the stars of heaven for multitude. [^22] 

[[Deuteronomy - 9|<--]] Deuteronomy - 10 [[Deuteronomy - 11|-->]]

---
# Notes
