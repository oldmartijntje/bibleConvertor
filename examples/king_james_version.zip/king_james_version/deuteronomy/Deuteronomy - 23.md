---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/deuteronomy"
  - "#bible/testament/old"
aliases:
  - "Deuteronomy - 23 - King James Version"
---
[[Deuteronomy - 22|<--]] Deuteronomy - 23 [[Deuteronomy - 24|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Deuteronomy]]

# Deuteronomy - 23

He that is wounded in the stones, or hath his privy member cut off, shall not enter into the congregation of the LORD. [^1] A bastard shall not enter into the congregation of the LORD; even to his tenth generation shall he not enter into the congregation of the LORD. [^2] An Ammonite or Moabite shall not enter into the congregation of the LORD; even to their tenth generation shall they not enter into the congregation of the LORD for ever: [^3] because they met you not with bread and with water in the way, when ye came forth out of Egypt; and because they hired against thee Balaam the son of Beor of Pethor of Mesopotamia, to curse thee. [^4] Nevertheless the LORD thy God would not hearken unto Balaam; but the LORD thy God turned the curse into a blessing unto thee, because the LORD thy God loved thee. [^5] Thou shalt not seek their peace nor their prosperity all thy days for ever. [^6] Thou shalt not abhor an Edomite; for he is thy brother: thou shalt not abhor an Egyptian; because thou wast a stranger in his land. [^7] The children that are begotten of them shall enter into the congregation of the LORD in their third generation. [^8] When the host goeth forth against thine enemies, then keep thee from every wicked thing. [^9] If there be among you any man, that is not clean by reason of uncleanness that chanceth him by night, then shall he go abroad out of the camp, he shall not come within the camp: [^10] but it shall be, when evening cometh on, he shall wash himself with water: and when the sun is down, he shall come into the camp again. [^11] Thou shalt have a place also without the camp, whither thou shalt go forth abroad: [^12] and thou shalt have a paddle upon thy weapon; and it shall be, when thou wilt ease thyself abroad, thou shalt dig therewith, and shalt turn back and cover that which cometh from thee: [^13] for the LORD thy God walketh in the midst of thy camp, to deliver thee, and to give up thine enemies before thee; therefore shall thy camp be holy: that he see no unclean thing in thee, and turn away from thee. [^14] Thou shalt not deliver unto his master the servant which is escaped from his master unto thee: [^15] he shall dwell with thee, even among you, in that place which he shall choose in one of thy gates, where it liketh him best: thou shalt not oppress him. [^16] There shall be no whore of the daughters of Israel, nor a sodomite of the sons of Israel. [^17] Thou shalt not bring the hire of a whore, or the price of a dog, into the house of the LORD thy God for any vow: for even both these are abomination unto the LORD thy God. [^18] Thou shalt not lend upon usury to thy brother; usury of money, usury of victuals, usury of any thing that is lent upon usury: [^19] unto a stranger thou mayest lend upon usury; but unto thy brother thou shalt not lend upon usury: that the LORD thy God may bless thee in all that thou settest thine hand to in the land whither thou goest to possess it. [^20] When thou shalt vow a vow unto the LORD thy God, thou shalt not slack to pay it: for the LORD thy God will surely require it of thee; and it would be sin in thee. [^21] But if thou shalt forbear to vow, it shall be no sin in thee. [^22] That which is gone out of thy lips thou shalt keep and perform; even a freewill offering, according as thou hast vowed unto the LORD thy God, which thou hast promised with thy mouth. [^23] When thou comest into thy neighbour's vineyard, then thou mayest eat grapes thy fill at thine own pleasure; but thou shalt not put any in thy vessel. [^24] When thou comest into the standing corn of thy neighbour, then thou mayest pluck the ears with thine hand; but thou shalt not move a sickle unto thy neighbour's standing corn. [^25] 

[[Deuteronomy - 22|<--]] Deuteronomy - 23 [[Deuteronomy - 24|-->]]

---
# Notes
