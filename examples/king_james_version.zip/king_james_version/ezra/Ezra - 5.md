---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/ezra"
  - "#bible/testament/old"
aliases:
  - "Ezra - 5 - King James Version"
---
[[Ezra - 4|<--]] Ezra - 5 [[Ezra - 6|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Ezra]]

# Ezra - 5

Then the prophets, Haggai the prophet, and Zechariah the son of Iddo, prophesied unto the Jews that were in Judah and Jerusalem in the name of the God of Israel, even unto them. [^1] Then rose up Zerubbabel the son of Shealtiel, and Jeshua the son of Jozadak, and began to build the house of God which is at Jerusalem: and with them were the prophets of God helping them. [^2] At the same time came to them Tatnai, governor on this side the river, and Shethar-boznai, and their companions, and said thus unto them, Who hath commanded you to build this house, and to make up this wall? [^3] Then said we unto them after this manner, What are the names of the men that make this building? [^4] But the eye of their God was upon the elders of the Jews, that they could not cause them to cease, till the matter came to Darius: and then they returned answer by letter concerning this matter. [^5] The copy of the letter that Tatnai, governor on this side the river, and Shethar-boznai, and his companions the Apharsachites, which were on this side the river, sent unto Darius the king: [^6] they sent a letter unto him, wherein was written thus; Unto Darius the king, all peace. [^7] Be it known unto the king, that we went into the province of Judea, to the house of the great God, which is builded with great stones, and timber is laid in the walls, and this work goeth fast on, and prospereth in their hands. [^8] Then asked we those elders, and said unto them thus, Who commanded you to build this house, and to make up these walls? [^9] We asked their names also, to certify thee, that we might write the names of the men that were the chief of them. [^10] And thus they returned us answer, saying, We are the servants of the God of heaven and earth, and build the house that was builded these many years ago, which a great king of Israel builded and set up. [^11] But after that our fathers had provoked the God of heaven unto wrath, he gave them into the hand of Nebuchadnezzar the king of Babylon, the Chaldean, who destroyed this house, and carried the people away into Babylon. [^12] But in the first year of Cyrus the king of Babylon the same king Cyrus made a decree to build this house of God. [^13] And the vessels also of gold and silver of the house of God, which Nebuchadnezzar took out of the temple that was in Jerusalem, and brought them into the temple of Babylon, those did Cyrus the king take out of the temple of Babylon, and they were delivered unto one, whose name was Sheshbazzar, whom he had made governor; [^14] and said unto him, Take these vessels, go, carry them into the temple that is in Jerusalem, and let the house of God be builded in his place. [^15] Then came the same Sheshbazzar, and laid the foundation of the house of God which is in Jerusalem: and since that time even until now hath it been in building, and yet it is not finished. [^16] Now therefore, if it seem good to the king, let there be search made in the king's treasure house, which is there at Babylon, whether it be so, that a decree was made of Cyrus the king to build this house of God at Jerusalem, and let the king send his pleasure to us concerning this matter. [^17] 

[[Ezra - 4|<--]] Ezra - 5 [[Ezra - 6|-->]]

---
# Notes
