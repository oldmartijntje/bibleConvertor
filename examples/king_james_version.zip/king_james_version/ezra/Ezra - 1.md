---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/ezra"
  - "#bible/testament/old"
aliases:
  - "Ezra - 1 - King James Version"
---
Ezra - 1 [[Ezra - 2|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Ezra]]

# Ezra - 1

Now in the first year of Cyrus king of Persia, that the word of the LORD by the mouth of Jeremiah might be fulfilled, the LORD stirred up the spirit of Cyrus king of Persia, that he made a proclamation throughout all his kingdom, and put it also in writing, saying, [^1] Thus saith Cyrus king of Persia, The LORD God of heaven hath given me all the kingdoms of the earth; and he hath charged me to build him an house at Jerusalem, which is in Judah. [^2] Who is there among you of all his people? his God be with him, and let him go up to Jerusalem, which is in Judah, and build the house of the LORD God of Israel, (he is the God,) which is in Jerusalem. [^3] And whosoever remaineth in any place where he sojourneth, let the men of his place help him with silver, and with gold, and with goods, and with beasts, beside the freewill offering for the house of God that is in Jerusalem. [^4] Then rose up the chief of the fathers of Judah and Benjamin, and the priests, and the Levites, with all them whose spirit God had raised, to go up to build the house of the LORD which is in Jerusalem. [^5] And all they that were about them strengthened their hands with vessels of silver, with gold, with goods, and with beasts, and with precious things, beside all that was willingly offered. [^6] Also Cyrus the king brought forth the vessels of the house of the LORD, which Nebuchadnezzar had brought forth out of Jerusalem, and had put them in the house of his gods; [^7] even those did Cyrus king of Persia bring forth by the hand of Mithredath the treasurer, and numbered them unto Sheshbazzar, the prince of Judah. [^8] And this is the number of them: thirty chargers of gold, a thousand chargers of silver, nine and twenty knives, [^9] thirty basons of gold, silver basons of a second sort four hundred and ten, and other vessels a thousand. [^10] All the vessels of gold and of silver were five thousand and four hundred. All these did Sheshbazzar bring up with them of the captivity that were brought up from Babylon unto Jerusalem. [^11] 

Ezra - 1 [[Ezra - 2|-->]]

---
# Notes
