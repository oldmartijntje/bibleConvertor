---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 12 - King James Version"
---
[[Numbers - 11|<--]] Numbers - 12 [[Numbers - 13|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Numbers]]

# Numbers - 12

And Miriam and Aaron spake against Moses because of the Ethiopian woman whom he had married: for he had married an Ethiopian woman. [^1] And they said, Hath the LORD indeed spoken only by Moses? hath he not spoken also by us? And the LORD heard it. [^2] (Now the man Moses was very meek, above all the men which were upon the face of the earth.) [^3] And the LORD spake suddenly unto Moses, and unto Aaron, and unto Miriam, Come out ye three unto the tabernacle of the congregation. And they three came out. [^4] And the LORD came down in the pillar of the cloud, and stood in the door of the tabernacle, and called Aaron and Miriam: and they both came forth. [^5] And he said, Hear now my words: If there be a prophet among you, I the LORD will make myself known unto him in a vision, and will speak unto him in a dream. [^6] My servant Moses is not so, who is faithful in all mine house. [^7] With him will I speak mouth to mouth, even apparently, and not in dark speeches; and the similitude of the LORD shall he behold: wherefore then were ye not afraid to speak against my servant Moses? [^8] And the anger of the LORD was kindled against them; and he departed. [^9] And the cloud departed from off the tabernacle; and, behold, Miriam became leprous, white as snow: and Aaron looked upon Miriam, and, behold, she was leprous. [^10] And Aaron said unto Moses, Alas, my lord, I beseech thee, lay not the sin upon us, wherein we have done foolishly, and wherein we have sinned. [^11] Let her not be as one dead, of whom the flesh is half consumed when he cometh out of his mother's womb. [^12] And Moses cried unto the LORD, saying, Heal her now, O God, I beseech thee. [^13] And the LORD said unto Moses, If her father had but spit in her face, should she not be ashamed seven days? let her be shut out from the camp seven days, and after that let her be received in again. [^14] And Miriam was shut out from the camp seven days: and the people journeyed not till Miriam was brought in again. [^15] And afterward the people removed from Hazeroth, and pitched in the wilderness of Paran. [^16] 

[[Numbers - 11|<--]] Numbers - 12 [[Numbers - 13|-->]]

---
# Notes
