---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 34 - King James Version"
---
[[Numbers - 33|<--]] Numbers - 34 [[Numbers - 35|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Numbers]]

# Numbers - 34

And the LORD spake unto Moses, saying, [^1] Command the children of Israel, and say unto them, When ye come into the land of Canaan; (this is the land that shall fall unto you for an inheritance, even the land of Canaan with the coasts thereof:) [^2] then your south quarter shall be from the wilderness of Zin along by the coast of Edom, and your south border shall be the outmost coast of the salt sea eastward: [^3] and your border shall turn from the south to the ascent of Akrabbim, and pass on to Zin: and the going forth thereof shall be from the south to Kadesh-barnea, and shall go on to Hazar-addar, and pass on to Azmon: [^4] and the border shall fetch a compass from Azmon unto the river of Egypt, and the goings out of it shall be at the sea. [^5] And as for the western border, ye shall even have the great sea for a border: this shall be your west border. [^6] And this shall be your north border: from the great sea ye shall point out for you mount Hor: [^7] from mount Hor ye shall point out your border unto the entrance of Hamath; and the goings forth of the border shall be to Zedad: [^8] and the border shall go on to Ziphron, and the goings out of it shall be at Hazar-enan: this shall be your north border. [^9] And ye shall point out your east border from Hazar-enan to Shepham: [^10] and the coast shall go down from Shepham to Riblah, on the east side of Ain; and the border shall descend, and shall reach unto the side of the sea of Chinnereth eastward: [^11] and the border shall go down to Jordan, and the goings out of it shall be at the salt sea: this shall be your land with the coasts thereof round about. [^12] And Moses commanded the children of Israel, saying, This is the land which ye shall inherit by lot, which the LORD commanded to give unto the nine tribes, and to the half tribe: [^13] for the tribe of the children of Reuben according to the house of their fathers, and the tribe of the children of Gad according to the house of their fathers, have received their inheritance; and half the tribe of Manasseh have received their inheritance: [^14] the two tribes and the half tribe have received their inheritance on this side Jordan near Jericho eastward, toward the sunrising. [^15] And the LORD spake unto Moses, saying, [^16] These are the names of the men which shall divide the land unto you: Eleazar the priest, and Joshua the son of Nun. [^17] And ye shall take one prince of every tribe, to divide the land by inheritance. [^18] And the names of the men are these: Of the tribe of Judah, Caleb the son of Jephunneh. [^19] And of the tribe of the children of Simeon, Shemuel the son of Ammihud. [^20] Of the tribe of Benjamin, Elidad the son of Chislon. [^21] And the prince of the tribe of the children of Dan, Bukki the son of Jogli. [^22] The prince of the children of Joseph, for the tribe of the children of Manasseh, Hanniel the son of Ephod. [^23] And the prince of the tribe of the children of Ephraim, Kemuel the son of Shiphtan. [^24] And the prince of the tribe of the children of Zebulun, Elizaphan the son of Parnach. [^25] And the prince of the tribe of the children of Issachar, Paltiel the son of Azzan. [^26] And the prince of the tribe of the children of Asher, Ahihud the son of Shelomi. [^27] And the prince of the tribe of the children of Naphtali, Pedahel the son of Ammihud. [^28] These are they whom the LORD commanded to divide the inheritance unto the children of Israel in the land of Canaan. [^29] 

[[Numbers - 33|<--]] Numbers - 34 [[Numbers - 35|-->]]

---
# Notes
