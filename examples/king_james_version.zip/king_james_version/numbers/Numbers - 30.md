---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 30 - King James Version"
---
[[Numbers - 29|<--]] Numbers - 30 [[Numbers - 31|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Numbers]]

# Numbers - 30

And Moses spake unto the heads of the tribes concerning the children of Israel, saying, This is the thing which the LORD hath commanded. [^1] If a man vow a vow unto the LORD, or swear an oath to bind his soul with a bond; he shall not break his word, he shall do according to all that proceedeth out of his mouth. [^2] If a woman also vow a vow unto the LORD, and bind herself by a bond, being in her father's house in her youth; [^3] and her father hear her vow, and her bond wherewith she hath bound her soul, and her father shall hold his peace at her: then all her vows shall stand, and every bond wherewith she hath bound her soul shall stand. [^4] But if her father disallow her in the day that he heareth; not any of her vows, or of her bonds wherewith she hath bound her soul, shall stand: and the LORD shall forgive her, because her father disallowed her. [^5] And if she had at all an husband, when she vowed, or uttered ought out of her lips, wherewith she bound her soul; [^6] and her husband heard it, and held his peace at her in the day that he heard it: then her vows shall stand, and her bonds wherewith she bound her soul shall stand. [^7] But if her husband disallowed her on the day that he heard it; then he shall make her vow which she vowed, and that which she uttered with her lips, wherewith she bound her soul, of none effect: and the LORD shall forgive her. [^8] But every vow of a widow, and of her that is divorced, wherewith they have bound their souls, shall stand against her. [^9] And if she vowed in her husband's house, or bound her soul by a bond with an oath; [^10] and her husband heard it, and held his peace at her, and disallowed her not: then all her vows shall stand, and every bond wherewith she bound her soul shall stand. [^11] But if her husband hath utterly made them void on the day he heard them; then whatsoever proceeded out of her lips concerning her vows, or concerning the bond of her soul, shall not stand: her husband hath made them void; and the LORD shall forgive her. [^12] Every vow, and every binding oath to afflict the soul, her husband may establish it, or her husband may make it void. [^13] But if her husband altogether hold his peace at her from day to day; then he establisheth all her vows, or all her bonds, which are upon her: he confirmeth them, because he held his peace at her in the day that he heard them. [^14] But if he shall any ways make them void after that he hath heard them; then he shall bear her iniquity. [^15] These are the statutes, which the LORD commanded Moses, between a man and his wife, between the father and his daughter, being yet in her youth in her father's house. [^16] 

[[Numbers - 29|<--]] Numbers - 30 [[Numbers - 31|-->]]

---
# Notes
