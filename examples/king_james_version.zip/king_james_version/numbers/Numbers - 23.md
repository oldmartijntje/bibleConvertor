---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 23 - King James Version"
---
[[Numbers - 22|<--]] Numbers - 23 [[Numbers - 24|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Numbers]]

# Numbers - 23

And Balaam said unto Balak, Build me here seven altars, and prepare me here seven oxen and seven rams. [^1] And Balak did as Balaam had spoken; and Balak and Balaam offered on every altar a bullock and a ram. [^2] And Balaam said unto Balak, Stand by thy burnt offering, and I will go: peradventure the LORD will come to meet me: and whatsoever he sheweth me I will tell thee. And he went to an high place. [^3] And God met Balaam: and he said unto him, I have prepared seven altars, and I have offered upon every altar a bullock and a ram. [^4] And the LORD put a word in Balaam's mouth, and said, Return unto Balak, and thus thou shalt speak. [^5] And he returned unto him, and, lo, he stood by his burnt sacrifice, he, and all the princes of Moab. [^6] And he took up his parable, and said,Balak the king of Moab hath brought me from Aram,Out of the mountains of the east,Saying, Come, curse me Jacob,And come, defy Israel. [^7] How shall I curse, whom God hath not cursed?Or how shall I defy, whom the LORD hath not defied? [^8] For from the top of the rocks I see him,And from the hills I behold him:Lo, the people shall dwell alone,And shall not be reckoned among the nations. [^9] Who can count the dust of Jacob,And the number of the fourth part of Israel?Let me die the death of the righteous,And let my last end be like his! [^10] And Balak said unto Balaam, What hast thou done unto me? I took thee to curse mine enemies, and, behold, thou hast blessed them altogether. [^11] And he answered and said, Must I not take heed to speak that which the LORD hath put in my mouth? [^12] And Balak said unto him, Come, I pray thee, with me unto another place, from whence thou mayest see them: thou shalt see but the utmost part of them, and shalt not see them all: and curse me them from thence. [^13] And he brought him into the field of Zophim, to the top of Pisgah, and built seven altars, and offered a bullock and a ram on every altar. [^14] And he said unto Balak, Stand here by thy burnt offering, while I meet the LORD yonder. [^15] And the LORD met Balaam, and put a word in his mouth, and said, Go again unto Balak, and say thus. [^16] And when he came to him, behold, he stood by his burnt offering, and the princes of Moab with him. And Balak said unto him, What hath the LORD spoken? [^17] And he took up his parable, and said,Rise up, Balak, and hear;Hearken unto me, thou son of Zippor: [^18] God is not a man, that he should lie;Neither the son of man, that he should repent:Hath he said, and shall he not do it?Or hath he spoken, and shall he not make it good? [^19] Behold, I have received commandment to bless:And he hath blessed; and I cannot reverse it. [^20] He hath not beheld iniquity in Jacob,Neither hath he seen perverseness in Israel:The LORD his God is with him,And the shout of a king is among them. [^21] God brought them out of Egypt;He hath as it were the strength of an unicorn. [^22] Surely there is no enchantment against Jacob,Neither is there any divination against Israel:According to this time it shall be said of Jacob and of Israel,What hath God wrought! [^23] Behold, the people shall rise up as a great lion,And lift up himself as a young lion:He shall not lie down until he eat of the prey,And drink the blood of the slain. [^24] And Balak said unto Balaam, Neither curse them at all, nor bless them at all. [^25] But Balaam answered and said unto Balak, Told not I thee, saying, All that the LORD speaketh, that I must do? [^26] And Balak said unto Balaam, Come, I pray thee, I will bring thee unto another place; peradventure it will please God that thou mayest curse me them from thence. [^27] And Balak brought Balaam unto the top of Peor, that looketh toward Jeshimon. [^28] And Balaam said unto Balak, Build me here seven altars, and prepare me here seven bullocks and seven rams. [^29] And Balak did as Balaam had said, and offered a bullock and a ram on every altar. [^30] 

[[Numbers - 22|<--]] Numbers - 23 [[Numbers - 24|-->]]

---
# Notes
