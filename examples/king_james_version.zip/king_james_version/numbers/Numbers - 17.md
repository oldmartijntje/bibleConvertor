---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 17 - King James Version"
---
[[Numbers - 16|<--]] Numbers - 17 [[Numbers - 18|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Numbers]]

# Numbers - 17

And the LORD spake unto Moses, saying, [^1] Speak unto the children of Israel, and take of every one of them a rod according to the house of their fathers, of all their princes according to the house of their fathers twelve rods: write thou every man's name upon his rod. [^2] And thou shalt write Aaron's name upon the rod of Levi: for one rod shall be for the head of the house of their fathers. [^3] And thou shalt lay them up in the tabernacle of the congregation before the testimony, where I will meet with you. [^4] And it shall come to pass, that the man's rod, whom I shall choose, shall blossom: and I will make to cease from me the murmurings of the children of Israel, whereby they murmur against you. [^5] And Moses spake unto the children of Israel, and every one of their princes gave him a rod apiece, for each prince one, according to their fathers' houses, even twelve rods: and the rod of Aaron was among their rods. [^6] And Moses laid up the rods before the LORD in the tabernacle of witness. [^7] And it came to pass, that on the morrow Moses went into the tabernacle of witness; and, behold, the rod of Aaron for the house of Levi was budded, and brought forth buds, and bloomed blossoms, and yielded almonds. [^8] And Moses brought out all the rods from before the LORD unto all the children of Israel: and they looked, and took every man his rod. [^9] And the LORD said unto Moses, Bring Aaron's rod again before the testimony, to be kept for a token against the rebels; and thou shalt quite take away their murmurings from me, that they die not. [^10] And Moses did so: as the LORD commanded him, so did he. [^11] And the children of Israel spake unto Moses, saying, Behold, we die, we perish, we all perish. [^12] Whosoever cometh any thing near unto the tabernacle of the LORD shall die: shall we be consumed with dying? [^13] 

[[Numbers - 16|<--]] Numbers - 17 [[Numbers - 18|-->]]

---
# Notes
