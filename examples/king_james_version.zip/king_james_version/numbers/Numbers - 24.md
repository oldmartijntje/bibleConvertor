---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 24 - King James Version"
---
[[Numbers - 23|<--]] Numbers - 24 [[Numbers - 25|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Numbers]]

# Numbers - 24

And when Balaam saw that it pleased the LORD to bless Israel, he went not, as at other times, to seek for enchantments, but he set his face toward the wilderness. [^1] And Balaam lifted up his eyes, and he saw Israel abiding in his tents according to their tribes; and the spirit of God came upon him. [^2] And he took up his parable, and said,Balaam the son of Beor hath said,And the man whose eyes are open hath said: [^3] He hath said, which heard the words of God,Which saw the vision of the Almighty,Falling into a trance, but having his eyes open: [^4] How goodly are thy tents, O Jacob,And thy tabernacles, O Israel! [^5] As the valleys are they spread forth,As gardens by the river's side,As the trees of lign aloes which the LORD hath planted,And as cedar trees beside the waters. [^6] He shall pour the water out of his buckets,And his seed shall be in many waters,And his king shall be higher than Agag,And his kingdom shall be exalted. [^7] God brought him forth out of Egypt;He hath as it were the strength of an unicorn:He shall eat up the nations his enemies,And shall break their bones,And pierce them through with his arrows. [^8] He couched, he lay down as a lion,And as a great lion: who shall stir him up?Blessed is he that blesseth thee,And cursed is he that curseth thee. [^9] And Balak's anger was kindled against Balaam, and he smote his hands together: and Balak said unto Balaam, I called thee to curse mine enemies, and, behold, thou hast altogether blessed them these three times. [^10] Therefore now flee thou to thy place: I thought to promote thee unto great honour; but, lo, the LORD hath kept thee back from honour. [^11] And Balaam said unto Balak, Spake I not also to thy messengers which thou sentest unto me, saying, [^12] If Balak would give me his house full of silver and gold, I cannot go beyond the commandment of the LORD, to do either good or bad of mine own mind; but what the LORD saith, that will I speak? [^13] And now, behold, I go unto my people: come therefore, and I will advertise thee what this people shall do to thy people in the latter days. [^14] And he took up his parable, and said,Balaam the son of Beor hath said,And the man whose eyes are open hath said: [^15] He hath said, which heard the words of God,And knew the knowledge of the Most High,Which saw the vision of the Almighty,Falling into a trance, but having his eyes open: [^16] I shall see him, but not now:I shall behold him, but not nigh:There shall come a Star out of Jacob,And a Sceptre shall rise out of Israel,And shall smite the corners of Moab,And destroy all the children of Sheth. [^17] And Edom shall be a possession,Seir also shall be a possession for his enemies;And Israel shall do valiantly. [^18] Out of Jacob shall come he that shall have dominion,And shall destroy him that remaineth of the city. [^19] And when he looked on Amalek, he took up his parable, and said,Amalek was the first of the nations;But his latter end shall be that he perish for ever. [^20] And he looked on the Kenites, and took up his parable, and said,Strong is thy dwellingplace,And thou puttest thy nest in a rock. [^21] Nevertheless the Kenite shall be wasted,Until Asshur shall carry thee away captive. [^22] And he took up his parable, and said,Alas, who shall live when God doeth this! [^23] And ships shall come from the coast of Chittim,And shall afflict Asshur, and shall afflict Eber,And he also shall perish for ever. [^24] And Balaam rose up, and went and returned to his place: and Balak also went his way. [^25] 

[[Numbers - 23|<--]] Numbers - 24 [[Numbers - 25|-->]]

---
# Notes
