---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 8 - King James Version"
---
[[Numbers - 7|<--]] Numbers - 8 [[Numbers - 9|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Numbers]]

# Numbers - 8

And the LORD spake unto Moses, saying, [^1] Speak unto Aaron, and say unto him, When thou lightest the lamps, the seven lamps shall give light over against the candlestick. [^2] And Aaron did so; he lighted the lamps thereof over against the candlestick, as the LORD commanded Moses. [^3] And this work of the candlestick was of beaten gold, unto the shaft thereof, unto the flowers thereof, was beaten work: according unto the pattern which the LORD had shewed Moses, so he made the candlestick. [^4] And the LORD spake unto Moses, saying, [^5] Take the Levites from among the children of Israel, and cleanse them. [^6] And thus shalt thou do unto them, to cleanse them: Sprinkle water of purifying upon them, and let them shave all their flesh, and let them wash their clothes, and so make themselves clean. [^7] Then let them take a young bullock with his meat offering, even fine flour mingled with oil, and another young bullock shalt thou take for a sin offering. [^8] And thou shalt bring the Levites before the tabernacle of the congregation: and thou shalt gather the whole assembly of the children of Israel together: [^9] and thou shalt bring the Levites before the LORD: and the children of Israel shall put their hands upon the Levites: [^10] and Aaron shall offer the Levites before the LORD  for an offering of the children of Israel, that they may execute the service of the LORD. [^11] And the Levites shall lay their hands upon the heads of the bullocks: and thou shalt offer the one for a sin offering, and the other for a burnt offering, unto the LORD, to make an atonement for the Levites. [^12] And thou shalt set the Levites before Aaron, and before his sons, and offer them for an offering unto the LORD. [^13] Thus shalt thou separate the Levites from among the children of Israel: and the Levites shall be mine. [^14] And after that shall the Levites go in to do the service of the tabernacle of the congregation: and thou shalt cleanse them, and offer them for an offering. [^15] For they are wholly given unto me from among the children of Israel; instead of such as open every womb, even instead of the firstborn of all the children of Israel, have I taken them unto me. [^16] For all the firstborn of the children of Israel are mine, both man and beast: on the day that I smote every firstborn in the land of Egypt I sanctified them for myself. [^17] And I have taken the Levites for all the firstborn of the children of Israel. [^18] And I have given the Levites as a gift to Aaron and to his sons from among the children of Israel, to do the service of the children of Israel in the tabernacle of the congregation, and to make an atonement for the children of Israel: that there be no plague among the children of Israel, when the children of Israel come nigh unto the sanctuary. [^19] And Moses, and Aaron, and all the congregation of the children of Israel, did to the Levites according unto all that the LORD commanded Moses concerning the Levites, so did the children of Israel unto them. [^20] And the Levites were purified, and they washed their clothes; and Aaron offered them as an offering before the LORD; and Aaron made an atonement for them to cleanse them. [^21] And after that went the Levites in to do their service in the tabernacle of the congregation before Aaron, and before his sons: as the LORD had commanded Moses concerning the Levites, so did they unto them. [^22] And the LORD spake unto Moses, saying, [^23] This is it that belongeth unto the Levites: from twenty and five years old and upward they shall go in to wait upon the service of the tabernacle of the congregation: [^24] and from the age of fifty years they shall cease waiting upon the service thereof, and shall serve no more: [^25] but shall minister with their brethren in the tabernacle of the congregation, to keep the charge, and shall do no service. Thus shalt thou do unto the Levites touching their charge. [^26] 

[[Numbers - 7|<--]] Numbers - 8 [[Numbers - 9|-->]]

---
# Notes
