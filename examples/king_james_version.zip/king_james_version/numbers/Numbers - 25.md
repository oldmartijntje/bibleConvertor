---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 25 - King James Version"
---
[[Numbers - 24|<--]] Numbers - 25 [[Numbers - 26|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Numbers]]

# Numbers - 25

And Israel abode in Shittim, and the people began to commit whoredom with the daughters of Moab. [^1] And they called the people unto the sacrifices of their gods: and the people did eat, and bowed down to their gods. [^2] And Israel joined himself unto Baal-peor: and the anger of the LORD was kindled against Israel. [^3] And the LORD said unto Moses, Take all the heads of the people, and hang them up before the LORD against the sun, that the fierce anger of the LORD may be turned away from Israel. [^4] And Moses said unto the judges of Israel, Slay ye every one his men that were joined unto Baal-peor. [^5] And, behold, one of the children of Israel came and brought unto his brethren a Midianitish woman in the sight of Moses, and in the sight of all the congregation of the children of Israel, who were weeping before the door of the tabernacle of the congregation. [^6] And when Phinehas, the son of Eleazar, the son of Aaron the priest, saw it, he rose up from among the congregation, and took a javelin in his hand; [^7] and he went after the man of Israel into the tent, and thrust both of them through, the man of Israel, and the woman through her belly. So the plague was stayed from the children of Israel. [^8] And those that died in the plague were twenty and four thousand. [^9] And the LORD spake unto Moses, saying, [^10] Phinehas, the son of Eleazar, the son of Aaron the priest, hath turned my wrath away from the children of Israel, while he was zealous for my sake among them, that I consumed not the children of Israel in my jealousy. [^11] Wherefore say, Behold, I give unto him my covenant of peace: [^12] and he shall have it, and his seed after him, even the covenant of an everlasting priesthood; because he was zealous for his God, and made an atonement for the children of Israel. [^13] Now the name of the Israelite that was slain, even that was slain with the Midianitish woman, was Zimri, the son of Salu, a prince of a chief house among the Simeonites. [^14] And the name of the Midianitish woman that was slain was Cozbi, the daughter of Zur; he was head over a people, and of a chief house in Midian. [^15] And the LORD spake unto Moses, saying, [^16] Vex the Midianites, and smite them: [^17] for they vex you with their wiles, wherewith they have beguiled you in the matter of Peor, and in the matter of Cozbi, the daughter of a prince of Midian, their sister, which was slain in the day of the plague for Peor's sake. [^18] 

[[Numbers - 24|<--]] Numbers - 25 [[Numbers - 26|-->]]

---
# Notes
