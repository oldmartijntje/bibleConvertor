---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 13 - King James Version"
---
[[Numbers - 12|<--]] Numbers - 13 [[Numbers - 14|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Numbers]]

# Numbers - 13

And the LORD spake unto Moses, saying, [^1] Send thou men, that they may search the land of Canaan, which I give unto the children of Israel: of every tribe of their fathers shall ye send a man, every one a ruler among them. [^2] And Moses by the commandment of the LORD sent them from the wilderness of Paran: all those men were heads of the children of Israel. [^3] And these were their names: of the tribe of Reuben, Shammua the son of Zaccur. [^4] Of the tribe of Simeon, Shaphat the son of Hori. [^5] Of the tribe of Judah, Caleb the son of Jephunneh. [^6] Of the tribe of Issachar, Igal the son of Joseph. [^7] Of the tribe of Ephraim, Oshea the son of Nun. [^8] Of the tribe of Benjamin, Palti the son of Raphu. [^9] Of the tribe of Zebulun, Gaddiel the son of Sodi. [^10] Of the tribe of Joseph, namely, of the tribe of Manasseh, Gaddi the son of Susi. [^11] Of the tribe of Dan, Ammiel the son of Gemalli. [^12] Of the tribe of Asher, Sethur the son of Michael. [^13] Of the tribe of Naphtali, Nahbi the son of Vophsi. [^14] Of the tribe of Gad, Geuel the son of Machi. [^15] These are the names of the men which Moses sent to spy out the land. And Moses called Oshea the son of Nun Jehoshua. [^16] And Moses sent them to spy out the land of Canaan, and said unto them, Get you up this way southward, and go up into the mountain: [^17] and see the land, what it is; and the people that dwelleth therein, whether they be strong or weak, few or many; [^18] and what the land is that they dwell in, whether it be good or bad; and what cities they be that they dwell in, whether in tents, or in strong holds; [^19] and what the land is, whether it be fat or lean, whether there be wood therein, or not. And be ye of good courage, and bring of the fruit of the land. Now the time was the time of the firstripe grapes. [^20] So they went up, and searched the land from the wilderness of Zin unto Rehob, as men come to Hamath. [^21] And they ascended by the south, and came unto Hebron; where Ahiman, Sheshai, and Talmai, the children of Anak, were. (Now Hebron was built seven years before Zoan in Egypt.) [^22] And they came unto the brook of Eshcol, and cut down from thence a branch with one cluster of grapes, and they bare it between two upon a staff; and they brought of the pomegranates, and of the figs. [^23] The place was called the brook Eshcol, because of the cluster of grapes which the children of Israel cut down from thence. [^24] And they returned from searching of the land after forty days. [^25] And they went and came to Moses, and to Aaron, and to all the congregation of the children of Israel, unto the wilderness of Paran, to Kadesh; and brought back word unto them, and unto all the congregation, and shewed them the fruit of the land. [^26] And they told him, and said, We came unto the land whither thou sentest us, and surely it floweth with milk and honey; and this is the fruit of it. [^27] Nevertheless the people be strong that dwell in the land, and the cities are walled, and very great: and moreover we saw the children of Anak there. [^28] The Amalekites dwell in the land of the south: and the Hittites, and the Jebusites, and the Amorites, dwell in the mountains: and the Canaanites dwell by the sea, and by the coast of Jordan. [^29] And Caleb stilled the people before Moses, and said, Let us go up at once, and possess it; for we are well able to overcome it. [^30] But the men that went up with him said, We be not able to go up against the people; for they are stronger than we. [^31] And they brought up an evil report of the land which they had searched unto the children of Israel, saying, The land, through which we have gone to search it, is a land that eateth up the inhabitants thereof; and all the people that we saw in it are men of a great stature. [^32] And there we saw the giants, the sons of Anak, which come of the giants: and we were in our own sight as grasshoppers, and so we were in their sight. [^33] 

[[Numbers - 12|<--]] Numbers - 13 [[Numbers - 14|-->]]

---
# Notes
