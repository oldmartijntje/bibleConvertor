---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/numbers"
  - "#bible/testament/old"
aliases:
  - "Numbers - 27 - King James Version"
---
[[Numbers - 26|<--]] Numbers - 27 [[Numbers - 28|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Numbers]]

# Numbers - 27

Then came the daughters of Zelophehad, the son of Hepher, the son of Gilead, the son of Machir, the son of Manasseh, of the families of Manasseh the son of Joseph: and these are the names of his daughters; Mahlah, Noah, and Hoglah, and Milcah, and Tirzah. [^1] And they stood before Moses, and before Eleazar the priest, and before the princes and all the congregation, by the door of the tabernacle of the congregation, saying, [^2] Our father died in the wilderness, and he was not in the company of them that gathered themselves together against the LORD in the company of Korah; but died in his own sin, and had no sons. [^3] Why should the name of our father be done away from among his family, because he hath no son? Give unto us therefore a possession among the brethren of our father. [^4] And Moses brought their cause before the LORD. [^5] And the LORD spake unto Moses, saying, [^6] The daughters of Zelophehad speak right: thou shalt surely give them a possession of an inheritance among their father's brethren; and thou shalt cause the inheritance of their father to pass unto them. [^7] And thou shalt speak unto the children of Israel, saying, If a man die, and have no son, then ye shall cause his inheritance to pass unto his daughter. [^8] And if he have no daughter, then ye shall give his inheritance unto his brethren. [^9] And if he have no brethren, then ye shall give his inheritance unto his father's brethren. [^10] And if his father have no brethren, then ye shall give his inheritance unto his kinsman that is next to him of his family, and he shall possess it: and it shall be unto the children of Israel a statute of judgment, as the LORD commanded Moses. [^11] And the LORD said unto Moses, Get thee up into this mount Abarim, and see the land which I have given unto the children of Israel. [^12] And when thou hast seen it, thou also shalt be gathered unto thy people, as Aaron thy brother was gathered. [^13] For ye rebelled against my commandment in the desert of Zin, in the strife of the congregation, to sanctify me at the water before their eyes: that is the water of Meribah in Kadesh in the wilderness of Zin. [^14] And Moses spake unto the LORD, saying, [^15] Let the LORD, the God of the spirits of all flesh, set a man over the congregation, [^16] which may go out before them, and which may go in before them, and which may lead them out, and which may bring them in; that the congregation of the LORD be not as sheep which have no shepherd. [^17] And the LORD said unto Moses, Take thee Joshua the son of Nun, a man in whom is the spirit, and lay thine hand upon him; [^18] and set him before Eleazar the priest, and before all the congregation; and give him a charge in their sight. [^19] And thou shalt put some of thine honour upon him, that all the congregation of the children of Israel may be obedient. [^20] And he shall stand before Eleazar the priest, who shall ask counsel for him after the judgment of Urim before the LORD: at his word shall they go out, and at his word they shall come in, both he, and all the children of Israel with him, even all the congregation. [^21] And Moses did as the LORD commanded him: and he took Joshua, and set him before Eleazar the priest, and before all the congregation: [^22] and he laid his hands upon him, and gave him a charge, as the LORD commanded by the hand of Moses. [^23] 

[[Numbers - 26|<--]] Numbers - 27 [[Numbers - 28|-->]]

---
# Notes
