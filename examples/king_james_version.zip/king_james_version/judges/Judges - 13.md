---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 13 - King James Version"
---
[[Judges - 12|<--]] Judges - 13 [[Judges - 14|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Judges]]

# Judges - 13

And the children of Israel did evil again in the sight of the LORD; and the LORD delivered them into the hand of the Philistines forty years. [^1] And there was a certain man of Zorah, of the family of the Danites, whose name was Manoah; and his wife was barren, and bare not. [^2] And the angel of the LORD appeared unto the woman, and said unto her, Behold now, thou art barren, and bearest not: but thou shalt conceive, and bear a son. [^3] Now therefore beware, I pray thee, and drink not wine nor strong drink, and eat not any unclean thing: [^4] for, lo, thou shalt conceive, and bear a son; and no razor shall come on his head: for the child shall be a Nazarite unto God from the womb: and he shall begin to deliver Israel out of the hand of the Philistines. [^5] Then the woman came and told her husband, saying, A man of God came unto me, and his countenance was like the countenance of an angel of God, very terrible: but I asked him not whence he was, neither told he me his name: [^6] but he said unto me, Behold, thou shalt conceive, and bear a son; and now drink no wine nor strong drink, neither eat any unclean thing: for the child shall be a Nazarite to God from the womb to the day of his death. [^7] Then Manoah intreated the LORD, and said, O my Lord, let the man of God which thou didst send come again unto us, and teach us what we shall do unto the child that shall be born. [^8] And God hearkened to the voice of Manoah; and the angel of God came again unto the woman as she sat in the field: but Manoah her husband was not with her. [^9] And the woman made haste, and ran, and shewed her husband, and said unto him, Behold, the man hath appeared unto me, that came unto me the other day. [^10] And Manoah arose, and went after his wife, and came to the man, and said unto him, Art thou the man that spakest unto the woman? And he said, I am. [^11] And Manoah said, Now let thy words come to pass. How shall we order the child, and how shall we do unto him? [^12] And the angel of the LORD said unto Manoah, Of all that I said unto the woman let her beware. [^13] She may not eat of any thing that cometh of the vine, neither let her drink wine or strong drink, nor eat any unclean thing: all that I commanded her let her observe. [^14] And Manoah said unto the angel of the LORD, I pray thee, let us detain thee, until we shall have made ready a kid for thee. [^15] And the angel of the LORD said unto Manoah, Though thou detain me, I will not eat of thy bread: and if thou wilt offer a burnt offering, thou must offer it unto the LORD. For Manoah knew not that he was an angel of the LORD. [^16] And Manoah said unto the angel of the LORD, What is thy name, that when thy sayings come to pass we may do thee honour? [^17] And the angel of the LORD said unto him, Why askest thou thus after my name, seeing it is secret? [^18] So Manoah took a kid with a meat offering, and offered it upon a rock unto the LORD: and the angel did wondrously; and Manoah and his wife looked on. [^19] For it came to pass, when the flame went up toward heaven from off the altar, that the angel of the LORD ascended in the flame of the altar. And Manoah and his wife looked on it, and fell on their faces to the ground. [^20] But the angel of the LORD did no more appear to Manoah and to his wife. Then Manoah knew that he was an angel of the LORD. [^21] And Manoah said unto his wife, We shall surely die, because we have seen God. [^22] But his wife said unto him, If the LORD were pleased to kill us, he would not have received a burnt offering and a meat offering at our hands, neither would he have shewed us all these things, nor would as at this time have told us such things as these. [^23] And the woman bare a son, and called his name Samson: and the child grew, and the LORD blessed him. [^24] And the Spirit of the LORD began to move him at times in the camp of Dan between Zorah and Eshtaol. [^25] 

[[Judges - 12|<--]] Judges - 13 [[Judges - 14|-->]]

---
# Notes
