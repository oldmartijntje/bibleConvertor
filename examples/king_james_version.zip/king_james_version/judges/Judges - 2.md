---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 2 - King James Version"
---
[[Judges - 1|<--]] Judges - 2 [[Judges - 3|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Judges]]

# Judges - 2

And an angel of the LORD came up from Gilgal to Bochim, and said, I made you to go up out of Egypt, and have brought you unto the land which I sware unto your fathers; and I said, I will never break my covenant with you. [^1] And ye shall make no league with the inhabitants of this land; ye shall throw down their altars: but ye have not obeyed my voice: why have ye done this? [^2] Wherefore I also said, I will not drive them out from before you; but they shall be as thorns in your sides, and their gods shall be a snare unto you. [^3] And it came to pass, when the angel of the LORD spake these words unto all the children of Israel, that the people lifted up their voice, and wept. [^4] And they called the name of that place Bochim: and they sacrificed there unto the LORD. [^5] And when Joshua had let the people go, the children of Israel went every man unto his inheritance to possess the land. [^6] And the people served the LORD all the days of Joshua, and all the days of the elders that outlived Joshua, who had seen all the great works of the LORD, that he did for Israel. [^7] And Joshua the son of Nun, the servant of the LORD, died, being an hundred and ten years old. [^8] And they buried him in the border of his inheritance in Timnath-heres, in the mount of Ephraim, on the north side of the hill Gaash. [^9] And also all that generation were gathered unto their fathers: and there arose another generation after them, which knew not the LORD, nor yet the works which he had done for Israel. [^10] And the children of Israel did evil in the sight of the LORD, and served Baalim: [^11] and they forsook the LORD God of their fathers, which brought them out of the land of Egypt, and followed other gods, of the gods of the people that were round about them, and bowed themselves unto them, and provoked the LORD to anger. [^12] And they forsook the LORD, and served Baal and Ashtaroth. [^13] And the anger of the LORD was hot against Israel, and he delivered them into the hands of spoilers that spoiled them, and he sold them into the hands of their enemies round about, so that they could not any longer stand before their enemies. [^14] Whithersoever they went out, the hand of the LORD was against them for evil, as the LORD had said, and as the LORD had sworn unto them: and they were greatly distressed. [^15] Nevertheless the LORD raised up judges, which delivered them out of the hand of those that spoiled them. [^16] And yet they would not hearken unto their judges, but they went a whoring after other gods, and bowed themselves unto them: they turned quickly out of the way which their fathers walked in, obeying the commandments of the LORD; but they did not so. [^17] And when the LORD raised them up judges, then the LORD was with the judge, and delivered them out of the hand of their enemies all the days of the judge: for it repented the LORD because of their groanings by reason of them that oppressed them and vexed them. [^18] And it came to pass, when the judge was dead, that they returned, and corrupted themselves more than their fathers, in following other gods to serve them, and to bow down unto them; they ceased not from their own doings, nor from their stubborn way. [^19] And the anger of the LORD was hot against Israel; and he said, Because that this people hath transgressed my covenant which I commanded their fathers, and have not hearkened unto my voice; [^20] I also will not henceforth drive out any from before them of the nations which Joshua left when he died: [^21] that through them I may prove Israel, whether they will keep the way of the LORD to walk therein, as their fathers did keep it, or not. [^22] Therefore the LORD left those nations, without driving them out hastily; neither delivered he them into the hand of Joshua. [^23] 

[[Judges - 1|<--]] Judges - 2 [[Judges - 3|-->]]

---
# Notes
