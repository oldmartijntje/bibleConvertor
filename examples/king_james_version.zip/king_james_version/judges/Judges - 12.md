---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 12 - King James Version"
---
[[Judges - 11|<--]] Judges - 12 [[Judges - 13|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Judges]]

# Judges - 12

And the men of Ephraim gathered themselves together, and went northward, and said unto Jephthah, Wherefore passedst thou over to fight against the children of Ammon, and didst not call us to go with thee? we will burn thine house upon thee with fire. [^1] And Jephthah said unto them, I and my people were at great strife with the children of Ammon; and when I called you, ye delivered me not out of their hands. [^2] And when I saw that ye delivered me not, I put my life in my hands, and passed over against the children of Ammon, and the LORD delivered them into my hand: wherefore then are ye come up unto me this day, to fight against me? [^3] Then Jephthah gathered together all the men of Gilead, and fought with Ephraim: and the men of Gilead smote Ephraim, because they said, Ye Gileadites are fugitives of Ephraim among the Ephraimites, and among the Manassites. [^4] And the Gileadites took the passages of Jordan before the Ephraimites: and it was so, that when those Ephraimites which were escaped said, Let me go over; that the men of Gilead said unto him, Art thou an Ephraimite? If he said, Nay; [^5] then said they unto him, Say now Shibboleth: and he said Sibboleth: for he could not frame to pronounce it right. Then they took him, and slew him at the passages of Jordan: and there fell at that time of the Ephraimites forty and two thousand. [^6] And Jephthah judged Israel six years. Then died Jephthah the Gileadite, and was buried in one of the cities of Gilead. [^7] And after him Ibzan of Beth-lehem judged Israel. [^8] And he had thirty sons, and thirty daughters, whom he sent abroad, and took in thirty daughters from abroad for his sons. And he judged Israel seven years. [^9] Then died Ibzan, and was buried at Beth-lehem. [^10] And after him Elon, a Zebulonite, judged Israel; and he judged Israel ten years. [^11] And Elon the Zebulonite died, and was buried in Aijalon in the country of Zebulun. [^12] And after him Abdon the son of Hillel, a Pirathonite, judged Israel. [^13] And he had forty sons and thirty nephews, that rode on threescore and ten ass colts: and he judged Israel eight years. [^14] And Abdon the son of Hillel the Pirathonite died, and was buried in Pirathon in the land of Ephraim, in the mount of the Amalekites. [^15] 

[[Judges - 11|<--]] Judges - 12 [[Judges - 13|-->]]

---
# Notes
