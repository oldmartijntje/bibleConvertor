---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 17 - King James Version"
---
[[Judges - 16|<--]] Judges - 17 [[Judges - 18|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Judges]]

# Judges - 17

And there was a man of mount Ephraim, whose name was Micah. [^1] And he said unto his mother, The eleven hundred shekels of silver that were taken from thee, about which thou cursedst, and spakest of also in mine ears, behold, the silver is with me; I took it. And his mother said, Blessed be thou of the LORD, my son. [^2] And when he had restored the eleven hundred shekels of silver to his mother, his mother said, I had wholly dedicated the silver unto the LORD from my hand for my son, to make a graven image and a molten image: now therefore I will restore it unto thee. [^3] Yet he restored the money unto his mother; and his mother took two hundred shekels of silver, and gave them to the founder, who made thereof a graven image and a molten image: and they were in the house of Micah. [^4] And the man Micah had an house of gods, and made an ephod, and teraphim, and consecrated one of his sons, who became his priest. [^5] In those days there was no king in Israel, but every man did that which was right in his own eyes. [^6] And there was a young man out of Beth-lehem-judah of the family of Judah, who was a Levite, and he sojourned there. [^7] And the man departed out of the city from Beth-lehem-judah to sojourn where he could find a place: and he came to mount Ephraim to the house of Micah, as he journeyed. [^8] And Micah said unto him, Whence comest thou? And he said unto him, I am a Levite of Beth-lehem-judah, and I go to sojourn where I may find a place. [^9] And Micah said unto him, Dwell with me, and be unto me a father and a priest, and I will give thee ten shekels of silver by the year, and a suit of apparel, and thy victuals. So the Levite went in. [^10] And the Levite was content to dwell with the man; and the young man was unto him as one of his sons. [^11] And Micah consecrated the Levite; and the young man became his priest, and was in the house of Micah. [^12] Then said Micah, Now know I that the LORD will do me good, seeing I have a Levite to my priest. [^13] 

[[Judges - 16|<--]] Judges - 17 [[Judges - 18|-->]]

---
# Notes
