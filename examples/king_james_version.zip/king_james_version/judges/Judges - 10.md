---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 10 - King James Version"
---
[[Judges - 9|<--]] Judges - 10 [[Judges - 11|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Judges]]

# Judges - 10

And after Abimelech there arose to defend Israel Tola the son of Puah, the son of Dodo, a man of Issachar; and he dwelt in Shamir in mount Ephraim. [^1] And he judged Israel twenty and three years, and died, and was buried in Shamir. [^2] And after him arose Jair, a Gileadite, and judged Israel twenty and two years. [^3] And he had thirty sons that rode on thirty ass colts, and they had thirty cities, which are called Havoth-jair unto this day, which are in the land of Gilead. [^4] And Jair died, and was buried in Camon. [^5] And the children of Israel did evil again in the sight of the LORD, and served Baalim, and Ashtaroth, and the gods of Syria, and the gods of Zidon, and the gods of Moab, and the gods of the children of Ammon, and the gods of the Philistines, and forsook the LORD, and served not him. [^6] And the anger of the LORD was hot against Israel, and he sold them into the hands of the Philistines, and into the hands of the children of Ammon. [^7] And that year they vexed and oppressed the children of Israel: eighteen years, all the children of Israel that were on the other side Jordan in the land of the Amorites, which is in Gilead. [^8] Moreover the children of Ammon passed over Jordan to fight also against Judah, and against Benjamin, and against the house of Ephraim; so that Israel was sore distressed. [^9] And the children of Israel cried unto the LORD, saying, We have sinned against thee, both because we have forsaken our God, and also served Baalim. [^10] And the LORD said unto the children of Israel, Did not I deliver you from the Egyptians, and from the Amorites, from the children of Ammon, and from the Philistines? [^11] The Zidonians also, and the Amalekites, and the Maonites, did oppress you; and ye cried to me, and I delivered you out of their hand. [^12] Yet ye have forsaken me, and served other gods: wherefore I will deliver you no more. [^13] Go and cry unto the gods which ye have chosen; let them deliver you in the time of your tribulation. [^14] And the children of Israel said unto the LORD, We have sinned: do thou unto us whatsoever seemeth good unto thee; deliver us only, we pray thee, this day. [^15] And they put away the strange gods from among them, and served the LORD: and his soul was grieved for the misery of Israel. [^16] Then the children of Ammon were gathered together, and encamped in Gilead. And the children of Israel assembled themselves together, and encamped in Mizpeh. [^17] And the people and princes of Gilead said one to another, What man is he that will begin to fight against the children of Ammon? he shall be head over all the inhabitants of Gilead. [^18] 

[[Judges - 9|<--]] Judges - 10 [[Judges - 11|-->]]

---
# Notes
