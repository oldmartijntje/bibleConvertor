---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 21 - King James Version"
---
[[Judges - 20|<--]] Judges - 21

Translation: [[bible - King James Version|King James Version]]
Book: [[Judges]]

# Judges - 21

Now the men of Israel had sworn in Mizpeh, saying, There shall not any of us give his daughter unto Benjamin to wife. [^1] And the people came to the house of God, and abode there till even before God, and lifted up their voices, and wept sore; [^2] and said, O LORD God of Israel, why is this come to pass in Israel, that there should be to day one tribe lacking in Israel? [^3] And it came to pass on the morrow, that the people rose early, and built there an altar, and offered burnt offerings and peace offerings. [^4] And the children of Israel said, Who is there among all the tribes of Israel that came not up with the congregation unto the LORD? For they had made a great oath concerning him that came not up to the LORD to Mizpeh, saying, He shall surely be put to death. [^5] And the children of Israel repented them for Benjamin their brother, and said, There is one tribe cut off from Israel this day. [^6] How shall we do for wives for them that remain, seeing we have sworn by the LORD that we will not give them of our daughters to wives? [^7] And they said, What one is there of the tribes of Israel that came not up to Mizpeh to the LORD? And, behold, there came none to the camp from Jabesh-gilead to the assembly. [^8] For the people were numbered, and, behold, there were none of the inhabitants of Jabesh-gilead there. [^9] And the congregation sent thither twelve thousand men of the valiantest, and commanded them, saying, Go and smite the inhabitants of Jabesh-gilead with the edge of the sword, with the women and the children. [^10] And this is the thing that ye shall do, Ye shall utterly destroy every male, and every woman that hath lain by man. [^11] And they found among the inhabitants of Jabesh-gilead four hundred young virgins, that had known no man by lying with any male: and they brought them unto the camp to Shiloh, which is in the land of Canaan. [^12] And the whole congregation sent some to speak to the children of Benjamin that were in the rock Rimmon, and to call peaceably unto them. [^13] And Benjamin came again at that time; and they gave them wives which they had saved alive of the women of Jabesh-gilead: and yet so they sufficed them not. [^14] And the people repented them for Benjamin, because that the LORD had made a breach in the tribes of Israel. [^15] Then the elders of the congregation said, How shall we do for wives for them that remain, seeing the women are destroyed out of Benjamin? [^16] And they said, There must be an inheritance for them that be escaped of Benjamin, that a tribe be not destroyed out of Israel. [^17] Howbeit we may not give them wives of our daughters: for the children of Israel have sworn, saying, Cursed be he that giveth a wife to Benjamin. [^18] Then they said, Behold, there is a feast of the LORD in Shiloh yearly in a place which is on the north side of Beth-el, on the east side of the highway that goeth up from Beth-el to Shechem, and on the south of Lebonah. [^19] Therefore they commanded the children of Benjamin, saying, Go and lie in wait in the vineyards; [^20] and see, and, behold, if the daughters of Shiloh come out to dance in dances, then come ye out of the vineyards, and catch you every man his wife of the daughters of Shiloh, and go to the land of Benjamin. [^21] And it shall be, when their fathers or their brethren come unto us to complain, that we will say unto them, Be favourable unto them for our sakes: because we reserved not to each man his wife in the war: for ye did not give unto them at this time, that ye should be guilty. [^22] And the children of Benjamin did so, and took them wives, according to their number, of them that danced, whom they caught: and they went and returned unto their inheritance, and repaired the cities, and dwelt in them. [^23] And the children of Israel departed thence at that time, every man to his tribe and to his family, and they went out from thence every man to his inheritance. [^24] In those days there was no king in Israel: every man did that which was right in his own eyes. [^25] 

[[Judges - 20|<--]] Judges - 21

---
# Notes
