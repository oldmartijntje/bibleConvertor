---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 14 - King James Version"
---
[[Judges - 13|<--]] Judges - 14 [[Judges - 15|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Judges]]

# Judges - 14

And Samson went down to Timnath, and saw a woman in Timnath of the daughters of the Philistines. [^1] And he came up, and told his father and his mother, and said, I have seen a woman in Timnath of the daughters of the Philistines: now therefore get her for me to wife. [^2] Then his father and his mother said unto him, Is there never a woman among the daughters of thy brethren, or among all my people, that thou goest to take a wife of the uncircumcised Philistines? And Samson said unto his father, Get her for me; for she pleaseth me well. [^3] But his father and his mother knew not that it was of the LORD, that he sought an occasion against the Philistines: for at that time the Philistines had dominion over Israel. [^4] Then went Samson down, and his father and his mother, to Timnath, and came to the vineyards of Timnath: and, behold, a young lion roared against him. [^5] And the Spirit of the LORD came mightily upon him, and he rent him as he would have rent a kid, and he had nothing in his hand: but he told not his father or his mother what he had done. [^6] And he went down, and talked with the woman; and she pleased Samson well. [^7] And after a time he returned to take her, and he turned aside to see the carcase of the lion: and, behold, there was a swarm of bees and honey in the carcase of the lion. [^8] And he took thereof in his hands, and went on eating, and came to his father and mother, and he gave them, and they did eat: but he told not them that he had taken the honey out of the carcase of the lion. [^9] So his father went down unto the woman: and Samson made there a feast; for so used the young men to do. [^10] And it came to pass, when they saw him, that they brought thirty companions to be with him. [^11] And Samson said unto them, I will now put forth a riddle unto you: if ye can certainly declare it me within the seven days of the feast, and find it out, then I will give you thirty sheets and thirty change of garments: [^12] but if ye cannot declare it me, then shall ye give me thirty sheets and thirty change of garments. And they said unto him, Put forth thy riddle, that we may hear it. [^13] And he said unto them,Out of the eater came forth meat,And out of the strong came forth sweetness.And they could not in three days expound the riddle. [^14] And it came to pass on the seventh day, that they said unto Samson's wife, Entice thy husband, that he may declare unto us the riddle, lest we burn thee and thy father's house with fire: have ye called us to take that we have? is it not so? [^15] And Samson's wife wept before him, and said, Thou dost but hate me, and lovest me not: thou hast put forth a riddle unto the children of my people, and hast not told it me. And he said unto her, Behold, I have not told it my father nor my mother, and shall I tell it thee? [^16] And she wept before him the seven days, while their feast lasted: and it came to pass on the seventh day, that he told her, because she lay sore upon him: and she told the riddle to the children of her people. [^17] And the men of the city said unto him on the seventh day before the sun went down, What is sweeter than honey? And what is stronger than a lion? And he said unto them,If ye had not plowed with my heifer,Ye had not found out my riddle. [^18] And the Spirit of the LORD came upon him, and he went down to Ashkelon, and slew thirty men of them, and took their spoil, and gave change of garments unto them which expounded the riddle. And his anger was kindled, and he went up to his father's house. [^19] But Samson's wife was given to his companion, whom he had used as his friend. [^20] 

[[Judges - 13|<--]] Judges - 14 [[Judges - 15|-->]]

---
# Notes
