---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/judges"
  - "#bible/testament/old"
aliases:
  - "Judges - 15 - King James Version"
---
[[Judges - 14|<--]] Judges - 15 [[Judges - 16|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Judges]]

# Judges - 15

But it came to pass within a while after, in the time of wheat harvest, that Samson visited his wife with a kid; and he said, I will go in to my wife into the chamber. But her father would not suffer him to go in. [^1] And her father said, I verily thought that thou hadst utterly hated her; therefore I gave her to thy companion: is not her younger sister fairer than she? take her, I pray thee, instead of her. [^2] And Samson said concerning them, Now shall I be more blameless than the Philistines, though I do them a displeasure. [^3] And Samson went and caught three hundred foxes, and took firebrands, and turned tail to tail, and put a firebrand in the midst between two tails. [^4] And when he had set the brands on fire, he let them go into the standing corn of the Philistines, and burnt up both the shocks, and also the standing corn, with the vineyards and olives. [^5] Then the Philistines said, Who hath done this? And they answered, Samson, the son in law of the Timnite, because he had taken his wife, and given her to his companion. And the Philistines came up, and burnt her and her father with fire. [^6] And Samson said unto them, Though ye have done this, yet will I be avenged of you, and after that I will cease. [^7] And he smote them hip and thigh with a great slaughter: and he went down and dwelt in the top of the rock Etam. [^8] Then the Philistines went up, and pitched in Judah, and spread themselves in Lehi. [^9] And the men of Judah said, Why are ye come up against us? And they answered, To bind Samson are we come up, to do to him as he hath done to us. [^10] Then three thousand men of Judah went to the top of the rock Etam, and said to Samson, Knowest thou not that the Philistines are rulers over us? what is this that thou hast done unto us? And he said unto them, As they did unto me, so have I done unto them. [^11] And they said unto him, We are come down to bind thee, that we may deliver thee into the hand of the Philistines. And Samson said unto them, Swear unto me, that ye will not fall upon me yourselves. [^12] And they spake unto him, saying, No; but we will bind thee fast, and deliver thee into their hand: but surely we will not kill thee. And they bound him with two new cords, and brought him up from the rock. [^13] And when he came unto Lehi, the Philistines shouted against him: and the Spirit of the LORD came mightily upon him, and the cords that were upon his arms became as flax that was burnt with fire, and his bands loosed from off his hands. [^14] And he found a new jawbone of an ass, and put forth his hand, and took it, and slew a thousand men therewith. [^15] And Samson said,With the jawbone of an ass, heaps upon heaps,With the jaw of an ass have I slain a thousand men. [^16] And it came to pass, when he had made an end of speaking, that he cast away the jawbone out of his hand, and called that place Ramath-lehi. [^17] And he was sore athirst, and called on the LORD, and said, Thou hast given this great deliverance into the hand of thy servant: and now shall I die for thirst, and fall into the hand of the uncircumcised? [^18] But God clave an hollow place that was in the jaw, and there came water thereout; and when he had drunk, his spirit came again, and he revived: wherefore he called the name thereof En-hakkore, which is in Lehi unto this day. [^19] And he judged Israel in the days of the Philistines twenty years. [^20] 

[[Judges - 14|<--]] Judges - 15 [[Judges - 16|-->]]

---
# Notes
