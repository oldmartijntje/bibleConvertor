---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 24 - King James Version"
---
[[Leviticus - 23|<--]] Leviticus - 24 [[Leviticus - 25|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Leviticus]]

# Leviticus - 24

And the LORD spake unto Moses, saying, [^1] Command the children of Israel, that they bring unto thee pure oil olive beaten for the light, to cause the lamps to burn continually. [^2] Without the vail of the testimony, in the tabernacle of the congregation, shall Aaron order it from the evening unto the morning before the LORD continually: it shall be a statute for ever in your generations. [^3] He shall order the lamps upon the pure candlestick before the LORD continually. [^4] And thou shalt take fine flour, and bake twelve cakes thereof: two tenth deals shall be in one cake. [^5] And thou shalt set them in two rows, six on a row, upon the pure table before the LORD. [^6] And thou shalt put pure frankincense upon each row, that it may be on the bread for a memorial, even an offering made by fire unto the LORD. [^7] Every sabbath he shall set it in order before the LORD continually, being taken from the children of Israel by an everlasting covenant. [^8] And it shall be Aaron's and his sons'; and they shall eat it in the holy place: for it is most holy unto him of the offerings of the LORD made by fire by a perpetual statute. [^9] And the son of an Israelitish woman, whose father was an Egyptian, went out among the children of Israel: and this son of the Israelitish woman and a man of Israel strove together in the camp; [^10] and the Israelitish woman's son blasphemed the name of the LORD, and cursed. And they brought him unto Moses: (and his mother's name was Shelomith, the daughter of Dibri, of the tribe of Dan:) [^11] and they put him in ward, that the mind of the LORD might be shewed them. [^12] And the LORD spake unto Moses, saying, [^13] Bring forth him that hath cursed without the camp; and let all that heard him lay their hands upon his head, and let all the congregation stone him. [^14] And thou shalt speak unto the children of Israel, saying, Whosoever curseth his God shall bear his sin. [^15] And he that blasphemeth the name of the LORD, he shall surely be put to death, and all the congregation shall certainly stone him: as well the stranger, as he that is born in the land, when he blasphemeth the name of the LORD, shall be put to death. [^16] And he that killeth any man shall surely be put to death. [^17] And he that killeth a beast shall make it good; beast for beast. [^18] And if a man cause a blemish in his neighbour; as he hath done, so shall it be done to him; [^19] breach for breach, eye for eye, tooth for tooth: as he hath caused a blemish in a man, so shall it be done to him again. [^20] And he that killeth a beast, he shall restore it: and he that killeth a man, he shall be put to death. [^21] Ye shall have one manner of law, as well for the stranger, as for one of your own country: for I am the LORD your God. [^22] And Moses spake to the children of Israel, that they should bring forth him that had cursed out of the camp, and stone him with stones. And the children of Israel did as the LORD commanded Moses. [^23] 

[[Leviticus - 23|<--]] Leviticus - 24 [[Leviticus - 25|-->]]

---
# Notes
