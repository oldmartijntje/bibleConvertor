---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 9 - King James Version"
---
[[Leviticus - 8|<--]] Leviticus - 9 [[Leviticus - 10|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Leviticus]]

# Leviticus - 9

And it came to pass on the eighth day, that Moses called Aaron and his sons, and the elders of Israel; [^1] and he said unto Aaron, Take thee a young calf for a sin offering, and a ram for a burnt offering, without blemish, and offer them before the LORD. [^2] And unto the children of Israel thou shalt speak, saying, Take ye a kid of the goats for a sin offering; and a calf and a lamb, both of the first year, without blemish, for a burnt offering; [^3] also a bullock and a ram for peace offerings, to sacrifice before the LORD; and a meat offering mingled with oil: for to day the LORD will appear unto you. [^4] And they brought that which Moses commanded before the tabernacle of the congregation: and all the congregation drew near and stood before the LORD. [^5] And Moses said, This is the thing which the LORD commanded that ye should do: and the glory of the LORD shall appear unto you. [^6] And Moses said unto Aaron, Go unto the altar, and offer thy sin offering, and thy burnt offering, and make an atonement for thyself, and for the people: and offer the offering of the people, and make an atonement for them; as the LORD commanded. [^7] Aaron therefore went unto the altar, and slew the calf of the sin offering, which was for himself. [^8] And the sons of Aaron brought the blood unto him: and he dipped his finger in the blood, and put it upon the horns of the altar, and poured out the blood at the bottom of the altar: [^9] but the fat, and the kidneys, and the caul above the liver of the sin offering, he burnt upon the altar; as the LORD commanded Moses. [^10] And the flesh and the hide he burnt with fire without the camp. [^11] And he slew the burnt offering; and Aaron's sons presented unto him the blood, which he sprinkled round about upon the altar. [^12] And they presented the burnt offering unto him, with the pieces thereof, and the head: and he burnt them upon the altar. [^13] And he did wash the inwards and the legs, and burnt them upon the burnt offering on the altar. [^14] And he brought the people's offering, and took the goat, which was the sin offering for the people, and slew it, and offered it for sin, as the first. [^15] And he brought the burnt offering, and offered it according to the manner. [^16] And he brought the meat offering, and took an handful thereof, and burnt it upon the altar, beside the burnt sacrifice of the morning. [^17] He slew also the bullock and the ram for a sacrifice of peace offerings, which was for the people: and Aaron's sons presented unto him the blood, which he sprinkled upon the altar round about, [^18] and the fat of the bullock and of the ram, the rump, and that which covereth the inwards, and the kidneys, and the caul above the liver: [^19] and they put the fat upon the breasts, and he burnt the fat upon the altar: [^20] and the breasts and the right shoulder Aaron waved for a wave offering before the LORD; as Moses commanded. [^21] And Aaron lifted up his hand toward the people, and blessed them, and came down from offering of the sin offering, and the burnt offering, and peace offerings. [^22] And Moses and Aaron went into the tabernacle of the congregation, and came out, and blessed the people: and the glory of the LORD appeared unto all the people. [^23] And there came a fire out from before the LORD, and consumed upon the altar the burnt offering and the fat: which when all the people saw, they shouted, and fell on their faces. [^24] 

[[Leviticus - 8|<--]] Leviticus - 9 [[Leviticus - 10|-->]]

---
# Notes
