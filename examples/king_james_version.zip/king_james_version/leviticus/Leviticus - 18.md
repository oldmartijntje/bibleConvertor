---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 18 - King James Version"
---
[[Leviticus - 17|<--]] Leviticus - 18 [[Leviticus - 19|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Leviticus]]

# Leviticus - 18

And the LORD spake unto Moses, saying, [^1] Speak unto the children of Israel, and say unto them, I am the LORD your God. [^2] After the doings of the land of Egypt, wherein ye dwelt, shall ye not do: and after the doings of the land of Canaan, whither I bring you, shall ye not do: neither shall ye walk in their ordinances. [^3] Ye shall do my judgments, and keep mine ordinances, to walk therein: I am the LORD your God. [^4] Ye shall therefore keep my statutes, and my judgments: which if a man do, he shall live in them: I am the LORD. [^5] None of you shall approach to any that is near of kin to him, to uncover their nakedness: I am the LORD. [^6] The nakedness of thy father, or the nakedness of thy mother, shalt thou not uncover: she is thy mother; thou shalt not uncover her nakedness. [^7] The nakedness of thy father's wife shalt thou not uncover: it is thy father's nakedness. [^8] The nakedness of thy sister, the daughter of thy father, or daughter of thy mother, whether she be born at home, or born abroad, even their nakedness thou shalt not uncover. [^9] The nakedness of thy son's daughter, or of thy daughter's daughter, even their nakedness thou shalt not uncover: for their's is thine own nakedness. [^10] The nakedness of thy father's wife's daughter, begotten of thy father, she is thy sister, thou shalt not uncover her nakedness. [^11] Thou shalt not uncover the nakedness of thy father's sister: she is thy father's near kinswoman. [^12] Thou shalt not uncover the nakedness of thy mother's sister: for she is thy mother's near kinswoman. [^13] Thou shalt not uncover the nakedness of thy father's brother, thou shalt not approach to his wife: she is thine aunt. [^14] Thou shalt not uncover the nakedness of thy daughter in law: she is thy son's wife; thou shalt not uncover her nakedness. [^15] Thou shalt not uncover the nakedness of thy brother's wife: it is thy brother's nakedness. [^16] Thou shalt not uncover the nakedness of a woman and her daughter, neither shalt thou take her son's daughter, or her daughter's daughter, to uncover her nakedness; for they are her near kinswomen: it is wickedness. [^17] Neither shalt thou take a wife to her sister, to vex her, to uncover her nakedness, beside the other in her life time. [^18] Also thou shalt not approach unto a woman to uncover her nakedness, as long as she is put apart for her uncleanness. [^19] Moreover thou shalt not lie carnally with thy neighbour's wife, to defile thyself with her. [^20] And thou shalt not let any of thy seed pass through the fire to Molech, neither shalt thou profane the name of thy God: I am the LORD. [^21] Thou shalt not lie with mankind, as with womankind: it is abomination. [^22] Neither shalt thou lie with any beast to defile thyself therewith: neither shall any woman stand before a beast to lie down thereto: it is confusion. [^23] Defile not ye yourselves in any of these things: for in all these the nations are defiled which I cast out before you: [^24] and the land is defiled: therefore I do visit the iniquity thereof upon it, and the land itself vomiteth out her inhabitants. [^25] Ye shall therefore keep my statutes and my judgments, and shall not commit any of these abominations; neither any of your own nation, nor any stranger that sojourneth among you: [^26] (for all these abominations have the men of the land done, which were before you, and the land is defiled;) [^27] that the land spue not you out also, when ye defile it, as it spued out the nations that were before you. [^28] For whosoever shall commit any of these abominations, even the souls that commit them shall be cut off from among their people. [^29] Therefore shall ye keep mine ordinance, that ye commit not any one of these abominable customs, which were committed before you, and that ye defile not yourselves therein: I am the LORD your God. [^30] 

[[Leviticus - 17|<--]] Leviticus - 18 [[Leviticus - 19|-->]]

---
# Notes
