---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 1 - King James Version"
---
Leviticus - 1 [[Leviticus - 2|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Leviticus]]

# Leviticus - 1

And the LORD called unto Moses, and spake unto him out of the tabernacle of the congregation, saying, [^1] Speak unto the children of Israel, and say unto them, If any man of you bring an offering unto the LORD, ye shall bring your offering of the cattle, even of the herd, and of the flock. [^2] If his offering be a burnt sacrifice of the herd, let him offer a male without blemish: he shall offer it of his own voluntary will at the door of the tabernacle of the congregation before the LORD. [^3] And he shall put his hand upon the head of the burnt offering; and it shall be accepted for him to make atonement for him. [^4] And he shall kill the bullock before the LORD: and the priests, Aaron's sons, shall bring the blood, and sprinkle the blood round about upon the altar that is by the door of the tabernacle of the congregation. [^5] And he shall flay the burnt offering, and cut it into his pieces. [^6] And the sons of Aaron the priest shall put fire upon the altar, and lay the wood in order upon the fire: [^7] and the priests, Aaron's sons, shall lay the parts, the head, and the fat, in order upon the wood that is on the fire which is upon the altar: [^8] but his inwards and his legs shall he wash in water: and the priest shall burn all on the altar, to be a burnt sacrifice, an offering made by fire, of a sweet savour unto the LORD. [^9] And if his offering be of the flocks, namely, of the sheep, or of the goats, for a burnt sacrifice; he shall bring it a male without blemish. [^10] And he shall kill it on the side of the altar northward before the LORD: and the priests, Aaron's sons, shall sprinkle his blood round about upon the altar. [^11] And he shall cut it into his pieces, with his head and his fat: and the priest shall lay them in order on the wood that is on the fire which is upon the altar: [^12] but he shall wash the inwards and the legs with water: and the priest shall bring it all, and burn it upon the altar: it is a burnt sacrifice, an offering made by fire, of a sweet savour unto the LORD. [^13] And if the burnt sacrifice for his offering to the LORD  be of fowls, then he shall bring his offering of turtledoves, or of young pigeons. [^14] And the priest shall bring it unto the altar, and wring off his head, and burn it on the altar; and the blood thereof shall be wrung out at the side of the altar: [^15] and he shall pluck away his crop with his feathers, and cast it beside the altar on the east part, by the place of the ashes: [^16] and he shall cleave it with the wings thereof, but shall not divide it asunder: and the priest shall burn it upon the altar, upon the wood that is upon the fire: it is a burnt sacrifice, an offering made by fire, of a sweet savour unto the LORD. [^17] 

Leviticus - 1 [[Leviticus - 2|-->]]

---
# Notes
