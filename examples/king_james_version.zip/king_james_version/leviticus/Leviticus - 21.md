---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 21 - King James Version"
---
[[Leviticus - 20|<--]] Leviticus - 21 [[Leviticus - 22|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Leviticus]]

# Leviticus - 21

And the LORD said unto Moses, Speak unto the priests the sons of Aaron, and say unto them, There shall none be defiled for the dead among his people: [^1] but for his kin, that is near unto him, that is, for his mother, and for his father, and for his son, and for his daughter, and for his brother, [^2] and for his sister a virgin, that is nigh unto him, which hath had no husband; for her may he be defiled. [^3] But he shall not defile himself, being a chief man among his people, to profane himself. [^4] They shall not make baldness upon their head, neither shall they shave off the corner of their beard, nor make any cuttings in their flesh. [^5] They shall be holy unto their God, and not profane the name of their God: for the offerings of the LORD made by fire, and the bread of their God, they do offer: therefore they shall be holy. [^6] They shall not take a wife that is a whore, or profane; neither shall they take a woman put away from her husband: for he is holy unto his God. [^7] Thou shalt sanctify him therefore; for he offereth the bread of thy God: he shall be holy unto thee: for I the LORD, which sanctify you, am holy. [^8] And the daughter of any priest, if she profane herself by playing the whore, she profaneth her father: she shall be burnt with fire. [^9] And he that is the high priest among his brethren, upon whose head the anointing oil was poured, and that is consecrated to put on the garments, shall not uncover his head, nor rend his clothes; [^10] neither shall he go in to any dead body, nor defile himself for his father, or for his mother; [^11] neither shall he go out of the sanctuary, nor profane the sanctuary of his God; for the crown of the anointing oil of his God is upon him: I am the LORD. [^12] And he shall take a wife in her virginity. [^13] A widow, or a divorced woman, or profane, or an harlot, these shall he not take: but he shall take a virgin of his own people to wife. [^14] Neither shall he profane his seed among his people: for I the LORD do sanctify him. [^15] And the LORD spake unto Moses, saying, [^16] Speak unto Aaron, saying, Whosoever he be of thy seed in their generations that hath any blemish, let him not approach to offer the bread of his God. [^17] For whatsoever man he be that hath a blemish, he shall not approach: a blind man, or a lame, or he that hath a flat nose, or any thing superfluous, [^18] or a man that is brokenfooted, or brokenhanded, [^19] or crookbackt, or a dwarf, or that hath a blemish in his eye, or be scurvy, or scabbed, or hath his stones broken; [^20] no man that hath a blemish of the seed of Aaron the priest shall come nigh to offer the offerings of the LORD made by fire: he hath a blemish; he shall not come nigh to offer the bread of his God. [^21] He shall eat the bread of his God, both of the most holy, and of the holy. [^22] Only he shall not go in unto the vail, nor come nigh unto the altar, because he hath a blemish; that he profane not my sanctuaries: for I the LORD do sanctify them. [^23] And Moses told it unto Aaron, and to his sons, and unto all the children of Israel. [^24] 

[[Leviticus - 20|<--]] Leviticus - 21 [[Leviticus - 22|-->]]

---
# Notes
