---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 3 - King James Version"
---
[[Leviticus - 2|<--]] Leviticus - 3 [[Leviticus - 4|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Leviticus]]

# Leviticus - 3

And if his oblation be a sacrifice of peace offering, if he offer it of the herd; whether it be a male or female, he shall offer it without blemish before the LORD. [^1] And he shall lay his hand upon the head of his offering, and kill it at the door of the tabernacle of the congregation: and Aaron's sons the priests shall sprinkle the blood upon the altar round about. [^2] And he shall offer of the sacrifice of the peace offering an offering made by fire unto the LORD; the fat that covereth the inwards, and all the fat that is upon the inwards, [^3] and the two kidneys, and the fat that is on them, which is by the flanks, and the caul above the liver, with the kidneys, it shall he take away. [^4] And Aaron's sons shall burn it on the altar upon the burnt sacrifice, which is upon the wood that is on the fire: it is an offering made by fire, of a sweet savour unto the LORD. [^5] And if his offering for a sacrifice of peace offering unto the LORD  be of the flock; male or female, he shall offer it without blemish. [^6] If he offer a lamb for his offering, then shall he offer it before the LORD. [^7] And he shall lay his hand upon the head of his offering, and kill it before the tabernacle of the congregation: and Aaron's sons shall sprinkle the blood thereof round about upon the altar. [^8] And he shall offer of the sacrifice of the peace offering an offering made by fire unto the LORD; the fat thereof, and the whole rump, it shall he take off hard by the backbone; and the fat that covereth the inwards, and all the fat that is upon the inwards, [^9] and the two kidneys, and the fat that is upon them, which is by the flanks, and the caul above the liver, with the kidneys, it shall he take away. [^10] And the priest shall burn it upon the altar: it is the food of the offering made by fire unto the LORD. [^11] And if his offering be a goat, then he shall offer it before the LORD. [^12] And he shall lay his hand upon the head of it, and kill it before the tabernacle of the congregation: and the sons of Aaron shall sprinkle the blood thereof upon the altar round about. [^13] And he shall offer thereof his offering, even an offering made by fire unto the LORD; the fat that covereth the inwards, and all the fat that is upon the inwards, [^14] and the two kidneys, and the fat that is upon them, which is by the flanks, and the caul above the liver, with the kidneys, it shall he take away. [^15] And the priest shall burn them upon the altar: it is the food of the offering made by fire for a sweet savour: all the fat is the LORD's. [^16] It shall be a perpetual statute for your generations throughout all your dwellings, that ye eat neither fat nor blood. [^17] 

[[Leviticus - 2|<--]] Leviticus - 3 [[Leviticus - 4|-->]]

---
# Notes
