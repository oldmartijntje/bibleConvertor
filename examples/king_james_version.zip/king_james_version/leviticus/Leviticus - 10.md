---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/leviticus"
  - "#bible/testament/old"
aliases:
  - "Leviticus - 10 - King James Version"
---
[[Leviticus - 9|<--]] Leviticus - 10 [[Leviticus - 11|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[Leviticus]]

# Leviticus - 10

And Nadab and Abihu, the sons of Aaron, took either of them his censer, and put fire therein, and put incense thereon, and offered strange fire before the LORD, which he commanded them not. [^1] And there went out fire from the LORD, and devoured them, and they died before the LORD. [^2] Then Moses said unto Aaron, This is it that the LORD spake, saying, I will be sanctified in them that come nigh me, and before all the people I will be glorified. And Aaron held his peace. [^3] And Moses called Mishael and Elzaphan, the sons of Uzziel the uncle of Aaron, and said unto them, Come near, carry your brethren from before the sanctuary out of the camp. [^4] So they went near, and carried them in their coats out of the camp; as Moses had said. [^5] And Moses said unto Aaron, and unto Eleazar and unto Ithamar, his sons, Uncover not your heads, neither rend your clothes; lest ye die, and lest wrath come upon all the people: but let your brethren, the whole house of Israel, bewail the burning which the LORD hath kindled. [^6] And ye shall not go out from the door of the tabernacle of the congregation, lest ye die: for the anointing oil of the LORD  is upon you. And they did according to the word of Moses. [^7] And the LORD spake unto Aaron, saying, [^8] Do not drink wine nor strong drink, thou, nor thy sons with thee, when ye go into the tabernacle of the congregation, lest ye die: it shall be a statute for ever throughout your generations: [^9] and that ye may put difference between holy and unholy, and between unclean and clean; [^10] and that ye may teach the children of Israel all the statutes which the LORD hath spoken unto them by the hand of Moses. [^11] And Moses spake unto Aaron, and unto Eleazar and unto Ithamar, his sons that were left, Take the meat offering that remaineth of the offerings of the LORD made by fire, and eat it without leaven beside the altar: for it is most holy: [^12] and ye shall eat it in the holy place, because it is thy due, and thy sons' due, of the sacrifices of the LORD made by fire: for so I am commanded. [^13] And the wave breast and heave shoulder shall ye eat in a clean place; thou, and thy sons, and thy daughters with thee: for they be thy due, and thy sons' due, which are given out of the sacrifices of peace offerings of the children of Israel. [^14] The heave shoulder and the wave breast shall they bring with the offerings made by fire of the fat, to wave it for a wave offering before the LORD; and it shall be thine, and thy sons' with thee, by a statute for ever; as the LORD hath commanded. [^15] And Moses diligently sought the goat of the sin offering, and, behold, it was burnt: and he was angry with Eleazar and Ithamar, the sons of Aaron which were left alive, saying, [^16] Wherefore have ye not eaten the sin offering in the holy place, seeing it is most holy, and God hath given it you to bear the iniquity of the congregation, to make atonement for them before the LORD? [^17] Behold, the blood of it was not brought in within the holy place: ye should indeed have eaten it in the holy place, as I commanded. [^18] And Aaron said unto Moses, Behold, this day have they offered their sin offering and their burnt offering before the LORD; and such things have befallen me: and if I had eaten the sin offering to day, should it have been accepted in the sight of the LORD? [^19] And when Moses heard that, he was content. [^20] 

[[Leviticus - 9|<--]] Leviticus - 10 [[Leviticus - 11|-->]]

---
# Notes
