---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 18 - King James Version"
---
[[1 Chronicles - 17|<--]] 1 Chronicles - 18 [[1 Chronicles - 19|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[1 Chronicles]]

# 1 Chronicles - 18

Now after this it came to pass, that David smote the Philistines, and subdued them, and took Gath and her towns out of the hand of the Philistines. [^1] And he smote Moab; and the Moabites became David's servants, and brought gifts. [^2] And David smote Hadarezer king of Zobah unto Hamath, as he went to stablish his dominion by the river Euphrates. [^3] And David took from him a thousand chariots, and seven thousand horsemen, and twenty thousand footmen: David also houghed all the chariot horses, but reserved of them an hundred chariots. [^4] And when the Syrians of Damascus came to help Hadarezer king of Zobah, David slew of the Syrians two and twenty thousand men. [^5] Then David put garrisons in Syria-damascus; and the Syrians became David's servants, and brought gifts. Thus the LORD preserved David whithersoever he went. [^6] And David took the shields of gold that were on the servants of Hadarezer, and brought them to Jerusalem. [^7] Likewise from Tibhath, and from Chun, cities of Hadarezer, brought David very much brass, wherewith Solomon made the brasen sea, and the pillars, and the vessels of brass. [^8] Now when Tou king of Hamath heard how David had smitten all the host of Hadarezer king of Zobah; [^9] he sent Hadoram his son to king David, to enquire of his welfare, and to congratulate him, because he had fought against Hadarezer, and smitten him; (for Hadarezer had war with Tou;) and with him all manner of vessels of gold and silver and brass. [^10] Them also king David dedicated unto the LORD, with the silver and the gold that he brought from all these nations; from Edom, and from Moab, and from the children of Ammon, and from the Philistines, and from Amalek. [^11] Moreover Abishai the son of Zeruiah slew of the Edomites in the valley of salt eighteen thousand. [^12] And he put garrisons in Edom; and all the Edomites became David's servants. Thus the LORD preserved David whithersoever he went. [^13] So David reigned over all Israel, and executed judgment and justice among all his people. [^14] And Joab the son of Zeruiah was over the host; and Jehoshaphat the son of Ahilud, recorder. [^15] And Zadok the son of Ahitub, and Abimelech the son of Abiathar, were the priests; and Shavsha was scribe; [^16] and Benaiah the son of Jehoiada was over the Cherethites and the Pelethites; and the sons of David were chief about the king. [^17] 

[[1 Chronicles - 17|<--]] 1 Chronicles - 18 [[1 Chronicles - 19|-->]]

---
# Notes
