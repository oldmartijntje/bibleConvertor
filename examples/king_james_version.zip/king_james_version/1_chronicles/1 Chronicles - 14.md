---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 14 - King James Version"
---
[[1 Chronicles - 13|<--]] 1 Chronicles - 14 [[1 Chronicles - 15|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[1 Chronicles]]

# 1 Chronicles - 14

Now Hiram king of Tyre sent messengers to David, and timber of cedars, with masons and carpenters, to build him an house. [^1] And David perceived that the LORD had confirmed him king over Israel, for his kingdom was lifted up on high, because of his people Israel. [^2] And David took more wives at Jerusalem: and David begat more sons and daughters. [^3] Now these are the names of his children which he had in Jerusalem; Shammua, and Shobab, Nathan, and Solomon, [^4] and Ibhar, and Elishua, and Elpalet, [^5] and Nogah, and Nepheg, and Japhia, [^6] and Elishama, and Beeliada, and Eliphalet. [^7] And when the Philistines heard that David was anointed king over all Israel, all the Philistines went up to seek David. And David heard of it, and went out against them. [^8] And the Philistines came and spread themselves in the valley of Rephaim. [^9] And David enquired of God, saying, Shall I go up against the Philistines? and wilt thou deliver them into mine hand? And the LORD said unto him, Go up; for I will deliver them into thine hand. [^10] So they came up to Baal-perazim; and David smote them there. Then David said, God hath broken in upon mine enemies by mine hand like the breaking forth of waters: therefore they called the name of that place Baal-perazim. [^11] And when they had left their gods there, David gave a commandment, and they were burned with fire. [^12] And the Philistines yet again spread themselves abroad in the valley. [^13] Therefore David enquired again of God; and God said unto him, Go not up after them; turn away from them, and come upon them over against the mulberry trees. [^14] And it shall be, when thou shalt hear a sound of going in the tops of the mulberry trees, that then thou shalt go out to battle: for God is gone forth before thee to smite the host of the Philistines. [^15] David therefore did as God commanded him: and they smote the host of the Philistines from Gibeon even to Gazer. [^16] And the fame of David went out into all lands; and the LORD brought the fear of him upon all nations. [^17] 

[[1 Chronicles - 13|<--]] 1 Chronicles - 14 [[1 Chronicles - 15|-->]]

---
# Notes
