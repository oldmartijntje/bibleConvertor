---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 23 - King James Version"
---
[[1 Chronicles - 22|<--]] 1 Chronicles - 23 [[1 Chronicles - 24|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[1 Chronicles]]

# 1 Chronicles - 23

So when David was old and full of days, he made Solomon his son king over Israel. [^1] And he gathered together all the princes of Israel, with the priests and the Levites. [^2] Now the Levites were numbered from the age of thirty years and upward: and their number by their polls, man by man, was thirty and eight thousand. [^3] Of which, twenty and four thousand were to set forward the work of the house of the LORD; and six thousand were officers and judges: [^4] moreover four thousand were porters; and four thousand praised the LORD with the instruments which I made, said David, to praise therewith. [^5] And David divided them into courses among the sons of Levi, namely, Gershon, Kohath, and Merari. [^6] Of the Gershonites were, Laadan, and Shimei. [^7] The sons of Laadan; the chief was Jehiel, and Zetham, and Joel, three. [^8] The sons of Shimei; Shelomith, and Haziel, and Haran, three. These were, the chief of the fathers of Laadan. [^9] And the sons of Shimei were, Jahath, Zina, and Jeush, and Beriah. These four were the sons of Shimei. [^10] And Jahath was the chief, and Zizah the second: but Jeush and Beriah had not many sons; therefore they were in one reckoning, according to their father's house. [^11] The sons of Kohath; Amram, Izhar, Hebron, and Uzziel, four. [^12] The sons of Amram; Aaron and Moses: and Aaron was separated, that he should sanctify the most holy things, he and his sons for ever, to burn incense before the LORD, to minister unto him, and to bless in his name for ever. [^13] Now concerning Moses the man of God, his sons were named of the tribe of Levi. [^14] The sons of Moses were, Gershom, and Eliezer. [^15] Of the sons of Gershom, Shebuel was the chief. [^16] And the sons of Eliezer were, Rehabiah the chief. And Eliezer had none other sons; but the sons of Rehabiah were very many. [^17] Of the sons of Izhar; Shelomith the chief. [^18] Of the sons of Hebron; Jeriah the first, Amariah the second, Jahaziel the third, and Jekameam the fourth. [^19] Of the sons of Uzziel; Micah the first, and Jesiah the second. [^20] The sons of Merari; Mahli, and Mushi. The sons of Mahli; Eleazar, and Kish. [^21] And Eleazar died, and had no sons, but daughters: and their brethren the sons of Kish took them. [^22] The sons of Mushi; Mahli, and Eder, and Jeremoth, three. [^23] These were the sons of Levi after the house of their fathers; even the chief of the fathers, as they were counted by number of names by their polls, that did the work for the service of the house of the LORD, from the age of twenty years and upward. [^24] For David said, The LORD God of Israel hath given rest unto his people, that they may dwell in Jerusalem for ever: [^25] and also unto the Levites; they shall no more carry the tabernacle, nor any vessels of it for the service thereof. [^26] For by the last words of David the Levites were numbered from twenty years old and above: [^27] because their office was to wait on the sons of Aaron for the service of the house of the LORD, in the courts, and in the chambers, and in the purifying of all holy things, and the work of the service of the house of God; [^28] both for the shewbread, and for the fine flour for meat offering, and for the unleavened cakes, and for that which is baked in the pan, and for that which is fried, and for all manner of measure and size; [^29] and to stand every morning to thank and praise the LORD, and likewise at even; [^30] and to offer all burnt sacrifices unto the LORD in the sabbaths, in the new moons, and on the set feasts, by number, according to the order commanded unto them, continually before the LORD: [^31] and that they should keep the charge of the tabernacle of the congregation, and the charge of the holy place, and the charge of the sons of Aaron their brethren, in the service of the house of the LORD. [^32] 

[[1 Chronicles - 22|<--]] 1 Chronicles - 23 [[1 Chronicles - 24|-->]]

---
# Notes
