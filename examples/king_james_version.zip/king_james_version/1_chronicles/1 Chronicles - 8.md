---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 8 - King James Version"
---
[[1 Chronicles - 7|<--]] 1 Chronicles - 8 [[1 Chronicles - 9|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[1 Chronicles]]

# 1 Chronicles - 8

Now Benjamin begat Bela his firstborn, Ashbel the second, and Aharah the third, [^1] Nohah the fourth, and Rapha the fifth. [^2] And the sons of Bela were, Addar, and Gera, and Abihud, [^3] and Abishua, and Naaman, and Ahoah, [^4] and Gera, and Shephuphan, and Huram. [^5] And these are the sons of Ehud: these are the heads of the fathers of the inhabitants of Geba, and they removed them to Manahath: [^6] and Naaman, and Ahiah, and Gera, he removed them, and begat Uzza, and Ahihud. [^7] And Shaharaim begat children in the country of Moab, after he had sent them away; Hushim and Baara were his wives. [^8] And he begat of Hodesh his wife, Jobab, and Zibia, and Mesha, and Malcham, [^9] and Jeuz, and Shachia, and Mirma. These were his sons, heads of the fathers. [^10] And of Hushim he begat Abitub, and Elpaal. [^11] The sons of Elpaal; Eber, and Misham, and Shamed, who built Ono, and Lod, with the towns thereof: [^12] Beriah also, and Shema, who were heads of the fathers of the inhabitants of Aijalon, who drove away the inhabitants of Gath: [^13] and Ahio, Shashak, and Jeremoth, [^14] and Zebadiah, and Arad, and Ader, [^15] and Michael, and Ispah, and Joha, the sons of Beriah; [^16] and Zebadiah, and Meshullam, and Hezeki, and Heber, [^17] Ishmerai also, and Jezliah, and Jobab, the sons of Elpaal; [^18] and Jakim, and Zichri, and Zabdi, [^19] and Elienai, and Zilthai, and Eliel, [^20] and Adaiah, and Beraiah, and Shimrath, the sons of Shimhi; [^21] and Ishpan, and Heber, and Eliel, [^22] and Abdon, and Zichri, and Hanan, [^23] and Hananiah, and Elam, and Antothijah, [^24] and Iphedeiah, and Penuel, the sons of Shashak; [^25] and Shamsherai, and Shehariah, and Athaliah, [^26] and Jaresiah, and Eliah, and Zichri, the sons of Jeroham. [^27] These were heads of the fathers, by their generations, chief men. These dwelt in Jerusalem. [^28] And at Gibeon dwelt the father of Gibeon; whose wife's name was Maachah: [^29] and his firstborn son Abdon, and Zur, and Kish, and Baal, and Nadab, [^30] and Gedor, and Ahio, and Zacher. [^31] And Mikloth begat Shimeah. And these also dwelt with their brethren in Jerusalem, over against them. [^32] And Ner begat Kish, and Kish begat Saul, and Saul begat Jonathan, and Malchi-shua, and Abinadab, and Eshbaal. [^33] And the son of Jonathan was Merib-baal; and Merib-baal begat Micah. [^34] And the sons of Micah were, Pithon, and Melech, and Tarea, and Ahaz. [^35] And Ahaz begat Jehoadah; and Jehoadah begat Alemeth, and Azmaveth, and Zimri; and Zimri begat Moza, [^36] and Moza begat Binea: Rapha was his son, Eleasah his son, Azel his son: [^37] and Azel had six sons, whose names are these, Azrikam, Bocheru, and Ishmael, and Sheariah, and Obadiah, and Hanan. All these were the sons of Azel. [^38] And the sons of Eshek his brother were, Ulam his firstborn, Jehush the second, and Eliphelet the third. [^39] And the sons of Ulam were mighty men of valour, archers, and had many sons, and sons' sons, an hundred and fifty. All these are of the sons of Benjamin. [^40] 

[[1 Chronicles - 7|<--]] 1 Chronicles - 8 [[1 Chronicles - 9|-->]]

---
# Notes
