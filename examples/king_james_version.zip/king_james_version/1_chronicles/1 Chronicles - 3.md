---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 3 - King James Version"
---
[[1 Chronicles - 2|<--]] 1 Chronicles - 3 [[1 Chronicles - 4|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[1 Chronicles]]

# 1 Chronicles - 3

Now these were the sons of David, which were born unto him in Hebron; the firstborn Amnon, of Ahinoam the Jezreelitess; the second Daniel, of Abigail the Carmelitess: [^1] the third, Absalom the son of Maachah the daughter of Talmai king of Geshur: the fourth, Adonijah the son of Haggith: [^2] the fifth, Shephatiah of Abital: the sixth, Ithream by Eglah his wife. [^3] These six were born unto him in Hebron; and there he reigned seven years and six months: and in Jerusalem he reigned thirty and three years. [^4] And these were born unto him in Jerusalem; Shimea, and Shobab, and Nathan, and Solomon, four, of Bath-shua the daughter of Ammiel: [^5] Ibhar also, and Elishama, and Eliphelet, [^6] and Nogah, and Nepheg, and Japhia, [^7] and Elishama, and Eliada, and Eliphelet, nine. [^8] These were all the sons of David, beside the sons of the concubines, and Tamar their sister. [^9] And Solomon's son was Rehoboam, Abia his son, Asa his son, Jehoshaphat his son, [^10] Joram his son, Ahaziah his son, Joash his son, [^11] Amaziah his son, Azariah his son, Jotham his son, [^12] Ahaz his son, Hezekiah his son, Manasseh his son, [^13] Amon his son, Josiah his son. [^14] And the sons of Josiah were, the firstborn Johanan, the second Jehoiakim, the third Zedekiah, the fourth Shallum. [^15] And the sons of Jehoiakim: Jeconiah his son, Zedekiah his son. [^16] And the sons of Jeconiah; Assir, Salathiel his son, [^17] Malchiram also, and Pedaiah, and Shenazar, Jecamiah, Hoshama, and Nedabiah. [^18] And the sons of Pedaiah were, Zerubbabel, and Shimei: and the sons of Zerubbabel; Meshullam, and Hananiah, and Shelomith their sister: [^19] and Hashubah, and Ohel, and Berechiah, and Hasadiah, Jushab-hesed, five. [^20] And the sons of Hananiah; Pelatiah, and Jesaiah: the sons of Rephaiah, the sons of Arnan, the sons of Obadiah, the sons of Shechaniah. [^21] And the sons of Shechaniah; Shemaiah: and the sons of Shemaiah; Hattush, and Igeal, and Bariah, and Neariah, and Shaphat, six. [^22] And the sons of Neariah; Elioenai, and Hezekiah, and Azrikam, three. [^23] And the sons of Elioenai were, Hodaiah, and Eliashib, and Pelaiah, and Akkub, and Johanan, and Dalaiah, and Anani, seven. [^24] 

[[1 Chronicles - 2|<--]] 1 Chronicles - 3 [[1 Chronicles - 4|-->]]

---
# Notes
