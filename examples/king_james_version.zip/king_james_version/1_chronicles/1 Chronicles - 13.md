---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 13 - King James Version"
---
[[1 Chronicles - 12|<--]] 1 Chronicles - 13 [[1 Chronicles - 14|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[1 Chronicles]]

# 1 Chronicles - 13

And David consulted with the captains of thousands and hundreds, and with every leader. [^1] And David said unto all the congregation of Israel, If it seem good unto you, and that it be of the LORD our God, let us send abroad unto our brethren every where, that are left in all the land of Israel, and with them also to the priests and Levites which are in their cities and suburbs, that they may gather themselves unto us: [^2] and let us bring again the ark of our God to us: for we enquired not at it in the days of Saul. [^3] And all the congregation said that they would do so: for the thing was right in the eyes of all the people. [^4] So David gathered all Israel together, from Shihor of Egypt even unto the entering of Hemath, to bring the ark of God from Kirjath-jearim. [^5] And David went up, and all Israel, to Baalah, that is, to Kirjath-jearim, which belonged to Judah, to bring up thence the ark of God the LORD, that dwelleth between the cherubims, whose name is called on it. [^6] And they carried the ark of God in a new cart out of the house of Abinadab: and Uzza and Ahio drave the cart. [^7] And David and all Israel played before God with all their might, and with singing, and with harps, and with psalteries, and with timbrels, and with cymbals, and with trumpets. [^8] And when they came unto the threshingfloor of Chidon, Uzza put forth his hand to hold the ark; for the oxen stumbled. [^9] And the anger of the LORD was kindled against Uzza, and he smote him, because he put his hand to the ark: and there he died before God. [^10] And David was displeased, because the LORD had made a breach upon Uzza: wherefore that place is called Perez-uzza to this day. [^11] And David was afraid of God that day, saying, How shall I bring the ark of God home to me? [^12] So David brought not the ark home to himself to the city of David, but carried it aside into the house of Obed-edom the Gittite. [^13] And the ark of God remained with the family of Obed-edom in his house three months. And the LORD blessed the house of Obed-edom, and all that he had. [^14] 

[[1 Chronicles - 12|<--]] 1 Chronicles - 13 [[1 Chronicles - 14|-->]]

---
# Notes
