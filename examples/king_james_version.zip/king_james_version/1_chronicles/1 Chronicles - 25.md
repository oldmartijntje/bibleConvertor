---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 25 - King James Version"
---
[[1 Chronicles - 24|<--]] 1 Chronicles - 25 [[1 Chronicles - 26|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[1 Chronicles]]

# 1 Chronicles - 25

Moreover David and the captains of the host separated to the service of the sons of Asaph, and of Heman, and of Jeduthun, who should prophesy with harps, with psalteries, and with cymbals: and the number of the workmen according to their service was: [^1] of the sons of Asaph; Zaccur, and Joseph, and Nethaniah, and Asarelah, the sons of Asaph under the hands of Asaph, which prophesied according to the order of the king. [^2] Of Jeduthun: the sons of Jeduthun; Gedaliah, and Zeri, and Jeshaiah, Hashabiah, and Mattithiah, six, under the hands of their father Jeduthun, who prophesied with a harp, to give thanks and to praise the LORD. [^3] Of Heman: the sons of Heman; Bukkiah, Mattaniah, Uzziel, Shebuel, and Jerimoth, Hananiah, Hanani, Eliathah, Giddalti, and Romamti-ezer, Joshbekashah, Mallothi, Hothir, and Mahazioth: [^4] all these were the sons of Heman the king's seer in the words of God, to lift up the horn. And God gave to Heman fourteen sons and three daughters. [^5] All these were under the hands of their father for song in the house of the LORD, with cymbals, psalteries, and harps, for the service of the house of God, according to the king's order to Asaph, Jeduthun, and Heman. [^6] So the number of them, with their brethren that were instructed in the songs of the LORD, even all that were cunning, was two hundred fourscore and eight. [^7] And they cast lots, ward against ward, as well the small as the great, the teacher as the scholar. [^8] Now the first lot came forth for Asaph to Joseph: the second to Gedaliah, who with his brethren and sons were twelve: [^9] the third to Zaccur, he, his sons, and his brethren, were twelve: [^10] the fourth to Izri, he, his sons, and his brethren, were twelve: [^11] the fifth to Nethaniah, he, his sons, and his brethren, were twelve: [^12] the sixth to Bukkiah, he, his sons, and his brethren, were twelve: [^13] the seventh to Jesharelah, he, his sons, and his brethren, were twelve: [^14] the eighth to Jeshaiah, he, his sons, and his brethren, were twelve: [^15] the ninth to Mattaniah, he, his sons, and his brethren, were twelve: [^16] the tenth to Shimei, he, his sons, and his brethren, were twelve: [^17] the eleventh to Azareel, he, his sons, and his brethren, were twelve: [^18] the twelfth to Hashabiah, he, his sons, and his brethren, were twelve: [^19] the thirteenth to Shubael, he, his sons, and his brethren, were twelve: [^20] the fourteenth to Mattithiah, he, his sons, and his brethren, were twelve: [^21] the fifteenth to Jeremoth, he, his sons, and his brethren, were twelve: [^22] the sixteenth to Hananiah, he, his sons, and his brethren, were twelve: [^23] the seventeenth to Joshbekashah, he, his sons, and his brethren, were twelve: [^24] the eighteenth to Hanani, he, his sons, and his brethren, were twelve: [^25] the nineteenth to Mallothi, he, his sons, and his brethren, were twelve: [^26] the twentieth to Eliathah, he, his sons, and his brethren, were twelve: [^27] the one and twentieth to Hothir, he, his sons, and his brethren, were twelve: [^28] the two and twentieth to Giddalti, he, his sons, and his brethren, were twelve: [^29] the three and twentieth to Mahazioth, he, his sons, and his brethren, were twelve: [^30] the four and twentieth to Romamti-ezer, he, his sons, and his brethren, were twelve. [^31] 

[[1 Chronicles - 24|<--]] 1 Chronicles - 25 [[1 Chronicles - 26|-->]]

---
# Notes
