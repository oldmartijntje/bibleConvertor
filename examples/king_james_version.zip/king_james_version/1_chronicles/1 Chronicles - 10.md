---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 10 - King James Version"
---
[[1 Chronicles - 9|<--]] 1 Chronicles - 10 [[1 Chronicles - 11|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[1 Chronicles]]

# 1 Chronicles - 10

Now the Philistines fought against Israel; and the men of Israel fled from before the Philistines, and fell down slain in mount Gilboa. [^1] And the Philistines followed hard after Saul, and after his sons; and the Philistines slew Jonathan, and Abinadab, and Malchi-shua, the sons of Saul. [^2] And the battle went sore against Saul, and the archers hit him, and he was wounded of the archers. [^3] Then said Saul to his armourbearer, Draw thy sword, and thrust me through therewith; lest these uncircumcised come and abuse me. But his armourbearer would not; for he was sore afraid. So Saul took a sword, and fell upon it. [^4] And when his armourbearer saw that Saul was dead, he fell likewise on the sword, and died. [^5] So Saul died, and his three sons, and all his house died together. [^6] And when all the men of Israel that were in the valley saw that they fled, and that Saul and his sons were dead, then they forsook their cities, and fled: and the Philistines came and dwelt in them. [^7] And it came to pass on the morrow, when the Philistines came to strip the slain, that they found Saul and his sons fallen in mount Gilboa. [^8] And when they had stripped him, they took his head, and his armour, and sent into the land of the Philistines round about, to carry tidings unto their idols, and to the people. [^9] And they put his armour in the house of their gods, and fastened his head in the temple of Dagon. [^10] And when all Jabesh-gilead heard all that the Philistines had done to Saul, [^11] they arose, all the valiant men, and took away the body of Saul, and the bodies of his sons, and brought them to Jabesh, and buried their bones under the oak in Jabesh, and fasted seven days. [^12] So Saul died for his transgression which he committed against the LORD, even against the word of the LORD, which he kept not, and also for asking counsel of one that had a familiar spirit, to enquire of it; [^13] and enquired not of the LORD: therefore he slew him, and turned the kingdom unto David the son of Jesse. [^14] 

[[1 Chronicles - 9|<--]] 1 Chronicles - 10 [[1 Chronicles - 11|-->]]

---
# Notes
