---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/1_chronicles"
  - "#bible/testament/old"
aliases:
  - "1 Chronicles - 22 - King James Version"
---
[[1 Chronicles - 21|<--]] 1 Chronicles - 22 [[1 Chronicles - 23|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[1 Chronicles]]

# 1 Chronicles - 22

Then David said, This is the house of the LORD God, and this is the altar of the burnt offering for Israel. [^1] And David commanded to gather together the strangers that were in the land of Israel; and he set masons to hew wrought stones to build the house of God. [^2] And David prepared iron in abundance for the nails for the doors of the gates, and for the joinings; and brass in abundance without weight; [^3] also cedar trees in abundance: for the Zidonians and they of Tyre brought much cedar wood to David. [^4] And David said, Solomon my son is young and tender, and the house that is to be builded for the LORD  must be exceeding magnifical, of fame and of glory throughout all countries: I will therefore now make preparation for it. So David prepared abundantly before his death. [^5] Then he called for Solomon his son, and charged him to build an house for the LORD God of Israel. [^6] And David said to Solomon, My son, as for me, it was in my mind to build an house unto the name of the LORD my God: [^7] but the word of the LORD came to me, saying, Thou hast shed blood abundantly, and hast made great wars: thou shalt not build an house unto my name, because thou hast shed much blood upon the earth in my sight. [^8] Behold, a son shall be born to thee, who shall be a man of rest; and I will give him rest from all his enemies round about: for his name shall be Solomon, and I will give peace and quietness unto Israel in his days. [^9] He shall build an house for my name; and he shall be my son, and I will be his father; and I will establish the throne of his kingdom over Israel for ever. [^10] Now, my son, the LORD be with thee; and prosper thou, and build the house of the LORD thy God, as he hath said of thee. [^11] Only the LORD give thee wisdom and understanding, and give thee charge concerning Israel, that thou mayest keep the law of the LORD thy God. [^12] Then shalt thou prosper, if thou takest heed to fulfil the statutes and judgments which the LORD charged Moses with concerning Israel: be strong, and of good courage; dread not, nor be dismayed. [^13] Now, behold, in my trouble I have prepared for the house of the LORD an hundred thousand talents of gold, and a thousand thousand talents of silver; and of brass and iron without weight; for it is in abundance: timber also and stone have I prepared; and thou mayest add thereto. [^14] Moreover there are workmen with thee in abundance, hewers and workers of stone and timber, and all manner of cunning men for every manner of work. [^15] Of the gold, the silver, and the brass, and the iron, there is no number. Arise therefore, and be doing, and the LORD be with thee. [^16] David also commanded all the princes of Israel to help Solomon his son, saying, [^17] Is not the LORD your God with you? and hath he not given you rest on every side? for he hath given the inhabitants of the land into mine hand; and the land is subdued before the LORD, and before his people. [^18] Now set your heart and your soul to seek the LORD your God; arise therefore, and build ye the sanctuary of the LORD God, to bring the ark of the covenant of the LORD, and the holy vessels of God, into the house that is to be built to the name of the LORD. [^19] 

[[1 Chronicles - 21|<--]] 1 Chronicles - 22 [[1 Chronicles - 23|-->]]

---
# Notes
