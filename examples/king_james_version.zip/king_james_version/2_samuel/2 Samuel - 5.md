---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 5 - King James Version"
---
[[2 Samuel - 4|<--]] 2 Samuel - 5 [[2 Samuel - 6|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[2 Samuel]]

# 2 Samuel - 5

Then came all the tribes of Israel to David unto Hebron, and spake, saying, Behold, we are thy bone and thy flesh. [^1] Also in time past, when Saul was king over us, thou wast he that leddest out and broughtest in Israel: and the LORD said to thee, Thou shalt feed my people Israel, and thou shalt be a captain over Israel. [^2] So all the elders of Israel came to the king to Hebron; and king David made a league with them in Hebron before the LORD: and they anointed David king over Israel. [^3] David was thirty years old when he began to reign, and he reigned forty years. [^4] In Hebron he reigned over Judah seven years and six months: and in Jerusalem he reigned thirty and three years over all Israel and Judah. [^5] And the king and his men went to Jerusalem unto the Jebusites, the inhabitants of the land: which spake unto David, saying, Except thou take away the blind and the lame, thou shalt not come in hither: thinking, David cannot come in hither. [^6] Nevertheless David took the strong hold of Zion: the same is the city of David. [^7] And David said on that day, Whosoever getteth up to the gutter, and smiteth the Jebusites, and the lame and the blind, that are hated of David's soul, he shall be chief and captain. Wherefore they said, The blind and the lame shall not come into the house. [^8] So David dwelt in the fort, and called it the city of David. And David built round about from Millo and inward. [^9] And David went on, and grew great, and the LORD God of hosts was with him. [^10] And Hiram king of Tyre sent messengers to David, and cedar trees, and carpenters, and masons: and they built David an house. [^11] And David perceived that the LORD had established him king over Israel, and that he had exalted his kingdom for his people Israel's sake. [^12] And David took him more concubines and wives out of Jerusalem, after he was come from Hebron: and there were yet sons and daughters born to David. [^13] And these be the names of those that were born unto him in Jerusalem; Shammua, and Shobab, and Nathan, and Solomon, [^14] Ibhar also, and Elishua, and Nepheg, and Japhia, [^15] and Elishama, and Eliada, and Eliphalet. [^16] But when the Philistines heard that they had anointed David king over Israel, all the Philistines came up to seek David; and David heard of it, and went down to the hold. [^17] The Philistines also came and spread themselves in the valley of Rephaim. [^18] And David enquired of the LORD, saying, Shall I go up to the Philistines? wilt thou deliver them into mine hand? And the LORD said unto David, Go up: for I will doubtless deliver the Philistines into thine hand. [^19] And David came to Baal-perazim, and David smote them there, and said, The LORD hath broken forth upon mine enemies before me, as the breach of waters. Therefore he called the name of that place Baal-perazim. [^20] And there they left their images, and David and his men burned them. [^21] And the Philistines came up yet again, and spread themselves in the valley of Rephaim. [^22] And when David enquired of the LORD, he said, Thou shalt not go up; but fetch a compass behind them, and come upon them over against the mulberry trees. [^23] And let it be, when thou hearest the sound of a going in the tops of the mulberry trees, that then thou shalt bestir thyself: for then shall the LORD go out before thee, to smite the host of the Philistines. [^24] And David did so, as the LORD had commanded him; and smote the Philistines from Geba until thou come to Gazer. [^25] 

[[2 Samuel - 4|<--]] 2 Samuel - 5 [[2 Samuel - 6|-->]]

---
# Notes
