---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 8 - King James Version"
---
[[2 Samuel - 7|<--]] 2 Samuel - 8 [[2 Samuel - 9|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[2 Samuel]]

# 2 Samuel - 8

And after this it came to pass, that David smote the Philistines, and subdued them: and David took Metheg-ammah out of the hand of the Philistines. [^1] And he smote Moab, and measured them with a line, casting them down to the ground; even with two lines measured he to put to death, and with one full line to keep alive. And so the Moabites became David's servants, and brought gifts. [^2] David smote also Hadadezer, the son of Rehob, king of Zobah, as he went to recover his border at the river Euphrates. [^3] And David took from him a thousand chariots, and seven hundred horsemen, and twenty thousand footmen: and David houghed all the chariot horses, but reserved of them for an hundred chariots. [^4] And when the Syrians of Damascus came to succour Hadadezer king of Zobah, David slew of the Syrians two and twenty thousand men. [^5] Then David put garrisons in Syria of Damascus: and the Syrians became servants to David, and brought gifts. And the LORD preserved David whithersoever he went. [^6] And David took the shields of gold that were on the servants of Hadadezer, and brought them to Jerusalem. [^7] And from Betah, and from Berothai, cities of Hadadezer, king David took exceeding much brass. [^8] When Toi king of Hamath heard that David had smitten all the host of Hadadezer, [^9] then Toi sent Joram his son unto king David, to salute him, and to bless him, because he had fought against Hadadezer, and smitten him: for Hadadezer had wars with Toi. And Joram brought with him vessels of silver, and vessels of gold, and vessels of brass: [^10] which also king David did dedicate unto the LORD, with the silver and gold that he had dedicated of all nations which he subdued; [^11] of Syria, and of Moab, and of the children of Ammon, and of the Philistines, and of Amalek, and of the spoil of Hadadezer, son of Rehob, king of Zobah. [^12] And David gat him a name when he returned from smiting of the Syrians in the valley of salt, being eighteen thousand men. [^13] And he put garrisons in Edom; throughout all Edom put he garrisons, and all they of Edom became David's servants. And the LORD preserved David whithersoever he went. [^14] And David reigned over all Israel; and David executed judgment and justice unto all his people. [^15] And Joab the son of Zeruiah was over the host; and Jehoshaphat the son of Ahilud was recorder; [^16] and Zadok the son of Ahitub, and Ahimelech the son of Abiathar, were the priests; and Seraiah was the scribe; [^17] and Benaiah the son of Jehoiada was over both the Cherethites and the Pelethites; and David's sons were chief rulers. [^18] 

[[2 Samuel - 7|<--]] 2 Samuel - 8 [[2 Samuel - 9|-->]]

---
# Notes
