---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 16 - King James Version"
---
[[2 Samuel - 15|<--]] 2 Samuel - 16 [[2 Samuel - 17|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[2 Samuel]]

# 2 Samuel - 16

And when David was a little past the top of the hill, behold, Ziba the servant of Mephibosheth met him, with a couple of asses saddled, and upon them two hundred loaves of bread, and an hundred bunches of raisins, and an hundred of summer fruits, and a bottle of wine. [^1] And the king said unto Ziba, What meanest thou by these? And Ziba said, The asses be for the king's household to ride on; and the bread and summer fruit for the young men to eat; and the wine, that such as be faint in the wilderness may drink. [^2] And the king said, And where is thy master's son? And Ziba said unto the king, Behold, he abideth at Jerusalem: for he said, To day shall the house of Israel restore me the kingdom of my father. [^3] Then said the king to Ziba, Behold, thine are all that pertained unto Mephibosheth. And Ziba said, I humbly beseech thee that I may find grace in thy sight, my lord, O king. [^4] And when king David came to Bahurim, behold, thence came out a man of the family of the house of Saul, whose name was Shimei, the son of Gera: he came forth, and cursed still as he came. [^5] And he cast stones at David, and at all the servants of king David: and all the people and all the mighty men were on his right hand and on his left. [^6] And thus said Shimei when he cursed, Come out, come out, thou bloody man, and thou man of Belial: [^7] the LORD hath returned upon thee all the blood of the house of Saul, in whose stead thou hast reigned; and the LORD hath delivered the kingdom into the hand of Absalom thy son: and, behold, thou art taken in thy mischief, because thou art a bloody man. [^8] Then said Abishai the son of Zeruiah unto the king, Why should this dead dog curse my lord the king? let me go over, I pray thee, and take off his head. [^9] And the king said, What have I to do with you, ye sons of Zeruiah? so let him curse, because the LORD hath said unto him, Curse David. Who shall then say, Wherefore hast thou done so? [^10] And David said to Abishai, and to all his servants, Behold, my son, which came forth of my bowels, seeketh my life: how much more now may this Benjamite do it? let him alone, and let him curse; for the LORD hath bidden him. [^11] It may be that the LORD will look on mine affliction, and that the LORD will requite me good for his cursing this day. [^12] And as David and his men went by the way, Shimei went along on the hill's side over against him, and cursed as he went, and threw stones at him, and cast dust. [^13] And the king, and all the people that were with him, came weary, and refreshed themselves there. [^14] And Absalom, and all the people the men of Israel, came to Jerusalem, and Ahithophel with him. [^15] And it came to pass, when Hushai the Archite, David's friend, was come unto Absalom, that Hushai said unto Absalom, God save the king, God save the king. [^16] And Absalom said to Hushai, Is this thy kindness to thy friend? why wentest thou not with thy friend? [^17] And Hushai said unto Absalom, Nay; but whom the LORD, and this people, and all the men of Israel, choose, his will I be, and with him will I abide. [^18] And again, whom should I serve? should I not serve in the presence of his son? as I have served in thy father's presence, so will I be in thy presence. [^19] Then said Absalom to Ahithophel, Give counsel among you what we shall do. [^20] And Ahithophel said unto Absalom, Go in unto thy father's concubines, which he hath left to keep the house; and all Israel shall hear that thou art abhorred of thy father: then shall the hands of all that are with thee be strong. [^21] So they spread Absalom a tent upon the top of the house; and Absalom went in unto his father's concubines in the sight of all Israel. [^22] And the counsel of Ahithophel, which he counselled in those days, was as if a man had enquired at the oracle of God: so was all the counsel of Ahithophel both with David and with Absalom. [^23] 

[[2 Samuel - 15|<--]] 2 Samuel - 16 [[2 Samuel - 17|-->]]

---
# Notes
