---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 1 - King James Version"
---
2 Samuel - 1 [[2 Samuel - 2|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[2 Samuel]]

# 2 Samuel - 1

Now it came to pass after the death of Saul, when David was returned from the slaughter of the Amalekites, and David had abode two days in Ziklag; [^1] it came even to pass on the third day, that, behold, a man came out of the camp from Saul with his clothes rent, and earth upon his head: and so it was, when he came to David, that he fell to the earth, and did obeisance. [^2] And David said unto him, From whence comest thou? And he said unto him, Out of the camp of Israel am I escaped. [^3] And David said unto him, How went the matter? I pray thee, tell me. And he answered, That the people are fled from the battle, and many of the people also are fallen and dead; and Saul and Jonathan his son are dead also. [^4] And David said unto the young man that told him, How knowest thou that Saul and Jonathan his son be dead? [^5] And the young man that told him said, As I happened by chance upon mount Gilboa, behold, Saul leaned upon his spear; and, lo, the chariots and horsemen followed hard after him. [^6] And when he looked behind him, he saw me, and called unto me. And I answered, Here am I. [^7] And he said unto me, Who art thou? And I answered him, I am an Amalekite. [^8] He said unto me again, Stand, I pray thee, upon me, and slay me: for anguish is come upon me, because my life is yet whole in me. [^9] So I stood upon him, and slew him, because I was sure that he could not live after that he was fallen: and I took the crown that was upon his head, and the bracelet that was on his arm, and have brought them hither unto my lord. [^10] Then David took hold on his clothes, and rent them; and likewise all the men that were with him: [^11] and they mourned, and wept, and fasted until even, for Saul, and for Jonathan his son, and for the people of the LORD, and for the house of Israel; because they were fallen by the sword. [^12] And David said unto the young man that told him, Whence art thou? And he answered, I am the son of a stranger, an Amalekite. [^13] And David said unto him, How wast thou not afraid to stretch forth thine hand to destroy the LORD's anointed? [^14] And David called one of the young men, and said, Go near, and fall upon him. And he smote him that he died. [^15] And David said unto him, Thy blood be upon thy head; for thy mouth hath testified against thee, saying, I have slain the LORD's anointed. [^16] And David lamented with this lamentation over Saul and over Jonathan his son: [^17] (Also he bade them teach the children of Judah the use of the bow: behold, it is written in the book of Jasher.) [^18] The beauty of Israel is slain upon thy high places:How are the mighty fallen! [^19] Tell it not in Gath,Publish it not in the streets of Askelon;Lest the daughters of the Philistines rejoice,Lest the daughters of the uncircumcised triumph. [^20] Ye mountains of Gilboa,Let there be no dew, neither let there be rain, upon you, nor fields of offerings:For there the shield of the mighty is vilely cast away,The shield of Saul, as though he had not been anointed with oil. [^21] From the blood of the slain, from the fat of the mighty,The bow of Jonathan turned not back,And the sword of Saul returned not empty. [^22] Saul and Jonathan were lovely and pleasant in their lives,And in their death they were not divided:They were swifter than eagles,They were stronger than lions. [^23] Ye daughters of Israel, weep over Saul,Who clothed you in scarlet, with other delights,Who put on ornaments of gold upon your apparel. [^24] How are the mighty fallen in the midst of the battle!O Jonathan, thou wast slain in thine high places. [^25] I am distressed for thee, my brother Jonathan:Very pleasant hast thou been unto me:Thy love to me was wonderful,Passing the love of women. [^26] How are the mighty fallen,And the weapons of war perished! [^27] 

2 Samuel - 1 [[2 Samuel - 2|-->]]

---
# Notes
