---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 6 - King James Version"
---
[[2 Samuel - 5|<--]] 2 Samuel - 6 [[2 Samuel - 7|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[2 Samuel]]

# 2 Samuel - 6

Again, David gathered together all the chosen men of Israel, thirty thousand. [^1] And David arose, and went with all the people that were with him from Baale of Judah, to bring up from thence the ark of God, whose name is called by the name of the LORD of hosts that dwelleth between the cherubims. [^2] And they set the ark of God upon a new cart, and brought it out of the house of Abinadab that was in Gibeah: and Uzzah and Ahio, the sons of Abinadab, drave the new cart. [^3] And they brought it out of the house of Abinadab which was at Gibeah, accompanying the ark of God: and Ahio went before the ark. [^4] And David and all the house of Israel played before the LORD on all manner of instruments made of fir wood, even on harps, and on psalteries, and on timbrels, and on cornets, and on cymbals. [^5] And when they came to Nachon's threshingfloor, Uzzah put forth his hand to the ark of God, and took hold of it; for the oxen shook it. [^6] And the anger of the LORD was kindled against Uzzah; and God smote him there for his error; and there he died by the ark of God. [^7] And David was displeased, because the LORD had made a breach upon Uzzah: and he called the name of the place Perez-uzzah to this day. [^8] And David was afraid of the LORD that day, and said, How shall the ark of the LORD come to me? [^9] So David would not remove the ark of the LORD unto him into the city of David: but David carried it aside into the house of Obed-edom the Gittite. [^10] And the ark of the LORD continued in the house of Obed-edom the Gittite three months: and the LORD blessed Obed-edom, and all his household. [^11] And it was told king David, saying, The LORD hath blessed the house of Obed-edom, and all that pertaineth unto him, because of the ark of God. So David went and brought up the ark of God from the house of Obed-edom into the city of David with gladness. [^12] And it was so, that when they that bare the ark of the LORD had gone six paces, he sacrificed oxen and fatlings. [^13] And David danced before the LORD with all his might; and David was girded with a linen ephod. [^14] So David and all the house of Israel brought up the ark of the LORD with shouting, and with the sound of the trumpet. [^15] And as the ark of the LORD came into the city of David, Michal Saul's daughter looked through a window, and saw king David leaping and dancing before the LORD; and she despised him in her heart. [^16] And they brought in the ark of the LORD, and set it in his place, in the midst of the tabernacle that David had pitched for it: and David offered burnt offerings and peace offerings before the LORD. [^17] And as soon as David had made an end of offering burnt offerings and peace offerings, he blessed the people in the name of the LORD of hosts. [^18] And he dealt among all the people, even among the whole multitude of Israel, as well to the women as men, to every one a cake of bread, and a good piece of flesh, and a flagon of wine. So all the people departed every one to his house. [^19] Then David returned to bless his household. And Michal the daughter of Saul came out to meet David, and said, How glorious was the king of Israel to day, who uncovered himself to day in the eyes of the handmaids of his servants, as one of the vain fellows shamelessly uncovereth himself! [^20] And David said unto Michal, It was before the LORD, which chose me before thy father, and before all his house, to appoint me ruler over the people of the LORD, over Israel: therefore will I play before the LORD. [^21] And I will yet be more vile than thus, and will be base in mine own sight: and of the maidservants which thou hast spoken of, of them shall I be had in honour. [^22] Therefore Michal the daughter of Saul had no child unto the day of her death. [^23] 

[[2 Samuel - 5|<--]] 2 Samuel - 6 [[2 Samuel - 7|-->]]

---
# Notes
