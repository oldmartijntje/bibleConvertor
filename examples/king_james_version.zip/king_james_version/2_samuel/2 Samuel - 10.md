---
translation: King James Version
tags:
  - "#bible/type/chapter"
  - "#bible/book/2_samuel"
  - "#bible/testament/old"
aliases:
  - "2 Samuel - 10 - King James Version"
---
[[2 Samuel - 9|<--]] 2 Samuel - 10 [[2 Samuel - 11|-->]]

Translation: [[bible - King James Version|King James Version]]
Book: [[2 Samuel]]

# 2 Samuel - 10

And it came to pass after this, that the king of the children of Ammon died, and Hanun his son reigned in his stead. [^1] Then said David, I will shew kindness unto Hanun the son of Nahash, as his father shewed kindness unto me. And David sent to comfort him by the hand of his servants for his father. And David's servants came into the land of the children of Ammon. [^2] And the princes of the children of Ammon said unto Hanun their lord, Thinkest thou that David doth honour thy father, that he hath sent comforters unto thee? hath not David rather sent his servants unto thee, to search the city, and to spy it out, and to overthrow it? [^3] Wherefore Hanun took David's servants, and shaved off the one half of their beards, and cut off their garments in the middle, even to their buttocks, and sent them away. [^4] When they told it unto David, he sent to meet them, because the men were greatly ashamed: and the king said, Tarry at Jericho until your beards be grown, and then return. [^5] And when the children of Ammon saw that they stank before David, the children of Ammon sent and hired the Syrians of Beth-rehob, and the Syrians of Zoba, twenty thousand footmen, and of king Maacah a thousand men, and of Ish-tob twelve thousand men. [^6] And when David heard of it, he sent Joab, and all the host of the mighty men. [^7] And the children of Ammon came out, and put the battle in array at the entering in of the gate: and the Syrians of Zoba, and of Rehob, and Ish-tob, and Maacah, were by themselves in the field. [^8] When Joab saw that the front of the battle was against him before and behind, he chose of all the choice men of Israel, and put them in array against the Syrians: [^9] and the rest of the people he delivered into the hand of Abishai his brother, that he might put them in array against the children of Ammon. [^10] And he said, If the Syrians be too strong for me, then thou shalt help me: but if the children of Ammon be too strong for thee, then I will come and help thee. [^11] Be of good courage, and let us play the men for our people, and for the cities of our God: and the LORD do that which seemeth him good. [^12] And Joab drew nigh, and the people that were with him, unto the battle against the Syrians: and they fled before him. [^13] And when the children of Ammon saw that the Syrians were fled, then fled they also before Abishai, and entered into the city. So Joab returned from the children of Ammon, and came to Jerusalem. [^14] And when the Syrians saw that they were smitten before Israel, they gathered themselves together. [^15] And Hadarezer sent, and brought out the Syrians that were beyond the river: and they came to Helam; and Shobach the captain of the host of Hadarezer went before them. [^16] And when it was told David, he gathered all Israel together, and passed over Jordan, and came to Helam. And the Syrians set themselves in array against David, and fought with him. [^17] And the Syrians fled before Israel; and David slew the men of seven hundred chariots of the Syrians, and forty thousand horsemen, and smote Shobach the captain of their host, who died there. [^18] And when all the kings that were servants to Hadarezer saw that they were smitten before Israel, they made peace with Israel, and served them. So the Syrians feared to help the children of Ammon any more. [^19] 

[[2 Samuel - 9|<--]] 2 Samuel - 10 [[2 Samuel - 11|-->]]

---
# Notes
